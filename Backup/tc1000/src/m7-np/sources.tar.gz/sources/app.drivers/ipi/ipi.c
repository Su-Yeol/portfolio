/*
***************************************************************************************************
*
*   FileName : ipi.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/****************************************
 *				Include					*
 ****************************************/
#include "FreeRTOS.h"
#include <sal_com.h>
#include <sal_internal.h>
#include "ipi.h"

/****************************************
 *		  Variable Definitions			*
 ****************************************/
static uint32 MboxSemaID;

static IPIOsFlags_t ipiOSFlags[IPI_Core_MAX];
IPICbFunc_t 		ipicbFunc[IPI_CH_MAX];

static ipi_info_t ipi_info[IPI_CH_MAX] = 
{
	{0U, NULL, {'I','P','C','_','U','\0'},{0,}},
	{0U, NULL, {'I','P','C','_','T','P'},{0,}},
	{0U, NULL, {'I','P','C','_','L','P'},{0,}},

	{0U, NULL, {'I','P','C','_','U','\0'},{0,}},
	{0U, NULL, {'I','P','C','_','T','P'},{0,}},
	{0U, NULL, {'I','P','C','_','L','P'},{0,}},

	{0U, NULL, {'I','P','C','_','U','\0'},{0,}},
	{0U, NULL, {'I','P','C','_','T','P'},{0,}},
	{0U, NULL, {'I','P','C','_','L','P'},{0,}},

	{0U, NULL, {'I','P','C','_','U','\0'},{0,}},
	{0U, NULL, {'I','P','C','_','T','P'},{0,}},
	{0U, NULL, {'I','P','C','_','L','P'},{0,}},	
};

static ipi_mbox_rx_t ipi_mbox_rx[IPI_Core_MAX] = 
{
	{0,0,{{0,},}},
	{0,0,{{0,},}},
	{0,0,{{0,},}},
	{0,0,{{0,},}},
};

/***************************************************
*          Local function prototypes               *
****************************************************/
static void IPI_MBOX_RxIrq_EventCreate(    IpiCoreIds_t CoreId);
static void IPI_MBOX_RxIrq_WaitEvent(    IpiCoreIds_t      CoreId);
static void IPI_MBOX_RxIrq_ClearEvent(    IpiCoreIds_t CoreId);
static void IPI_MBOX_RxIrq_WakeUp(    IpiCoreIds_t     CoreId);

static void ipi_create_mutex(void);
static void ipi_delete_mutex(void);
static void ipi_mbox_lock(void);
static void ipi_mbox_unlock(void);

static MboxChIds_t get_Ipi_Mbox_Ch(    IpiCoreIds_t   CoreId);
static IpiCoreIds_t get_Ipi_Core_Id(    IpiCh_t   siCh);

static void IPI_Cb_Task_CA65_NS(void);
static void ipi_mbox_Rxhandler_CA65_NS(void);

#if ( CORTEX_M7_0 == 0)
static void IPI_Cb_Task_CM7_0(void);
static void ipi_mbox_Rxhandler_CM7_0(void);
#endif
#if ( CORTEX_M7_1 == 0)
static void IPI_Cb_Task_CM7_1(void);
static void ipi_mbox_Rxhandler_CM7_1(void);
#endif
#if ( CORTEX_M7_2 == 0)
static void IPI_Cb_Task_CM7_2(void);
static void ipi_mbox_Rxhandler_CM7_2(void);
#endif
#if ( CORTEX_M7_NP == 0)
static void IPI_Cb_Task_CM7_NP(void);
static void ipi_mbox_Rxhandler_CM7_NP(void);
#endif

static void ipi_mailbox_make_ctlpacket(    ipi_info_t * ipi_info_buf,       const uint32 * puiCmd);


/**************************************************************************************************
*                                          IPI_MBOX_RxIrq_Wait EventCreate
*
* [static] MBOX RxIrq Event Create
*
* @param        CoreId
* @return       void
*
* Notes
*
***************************************************************************************************/

static void IPI_MBOX_RxIrq_EventCreate(    IpiCoreIds_t CoreId)
{
    if(CoreId == IPI_CA65_NS)
    {
        (void) SAL_EventCreate((uint32 *)&(ipiOSFlags[CoreId].ipiMboxRxIrqWaitFlagId), (const uint8 *) "CA65_NS Mbox RxIrq wait flag group", 0);
    }

#if ( CORTEX_M7_0 == 0)
	else if(CoreId == IPI_CM7_0)
    {
        (void) SAL_EventCreate((uint32 *)&(ipiOSFlags[CoreId].ipiMboxRxIrqWaitFlagId), (const uint8 *) "CM7_0 Mbox RxIrq wait flag group", 0);
    }
#endif

#if ( CORTEX_M7_1 == 0)
	else if(CoreId == IPI_CM7_1)
    {
        (void) SAL_EventCreate((uint32 *)&(ipiOSFlags[CoreId].ipiMboxRxIrqWaitFlagId), (const uint8 *) "CM7_1 Mbox RxIrq wait flag group", 0);
    }
#endif

#if ( CORTEX_M7_2 == 0)
	else if(CoreId == IPI_CM7_2)
    {
        (void) SAL_EventCreate((uint32 *)&(ipiOSFlags[CoreId].ipiMboxRxIrqWaitFlagId), (const uint8 *) "CM7_2 Mbox RxIrq wait flag group", 0);
    }
#endif

#if ( CORTEX_M7_NP == 0)
	else if(CoreId == IPI_CM7_NP)
    {
        (void) SAL_EventCreate((uint32 *)&(ipiOSFlags[CoreId].ipiMboxRxIrqWaitFlagId), (const uint8 *) "CM7_NP Mbox RxIrq wait flag group", 0);
    }
#endif
	else{}
}


/**************************************************************************************************
*                                          IPI MBOX RxIrq Wait Event
*
* [static] MBOX RxIrq Event Wait Function
*
* @param        CoreId
* @return       void
*
* Notes
*
***************************************************************************************************/

static void IPI_MBOX_RxIrq_WaitEvent(    IpiCoreIds_t      CoreId)
{
    uint32       retFlag;
    retFlag = 0UL;

    (void) SAL_EventGet(ipiOSFlags[CoreId].ipiMboxRxIrqWaitFlagId, IPI_MBOX_RxIrq_WAIT_FLAG, 0UL, ((uint32) SAL_EVENT_OPT_SET_ANY| (uint32) SAL_OPT_BLOCKING), &retFlag);

}

/**************************************************************************************************
*                                          IPI MBOX RxIrq Clear Event
*
* [static] MBOX RxIrq Event Clear Function
*
* @param        CoreId
* @return       void
*
* Notes
*
***************************************************************************************************/

static void IPI_MBOX_RxIrq_ClearEvent(    IpiCoreIds_t CoreId)
{
    (void) SAL_EventSet(ipiOSFlags[CoreId].ipiMboxRxIrqWaitFlagId, IPI_MBOX_RxIrq_WAIT_FLAG, SAL_EVENT_OPT_CLR_ALL);
}


/**************************************************************************************************
*                                          IPI MBOX RxIrq Wake Event
*
* [static] MBOX RxIrq Event Wakeup Function
*
* @param        CoreId
* @return       void
*
* Notes
*
***************************************************************************************************/

static void IPI_MBOX_RxIrq_WakeUp(    IpiCoreIds_t     CoreId)
{	
    (void) SAL_EventSet(ipiOSFlags[CoreId].ipiMboxRxIrqWaitFlagId, IPI_MBOX_RxIrq_WAIT_FLAG, SAL_EVENT_OPT_FLAG_SET);
}




/**************************************************************************************************
*                            create / delete / lock / unlock Ipi mbox mutex
*
* [Internal] Creat / Delete / Lock / Unlock mutex
*
* @param        void
* @return       void
*
* Notes
*
***************************************************************************************************/

static void ipi_create_mutex(void)
{
	(void)SAL_SemaphoreCreate((uint32 *)&MboxSemaID,(const uint8 *)"IPI Mbox Mutex", 1ul, 0);
}

static void ipi_delete_mutex(void)
{
	(void)SAL_SemaphoreDelete(MboxSemaID);
}

static void ipi_mbox_lock(void)
{
	/*Acquire Mutex*/
	(void)SAL_SemaphoreWait(MboxSemaID, 0UL, SAL_OPT_BLOCKING);
}

static void ipi_mbox_unlock(void)
{
	/*Release Mutex*/
	(void)SAL_SemaphoreRelease(MboxSemaID);
}



/**************************************************************************************************
*                                          Get Mbox Channel
*
* [Internal] Return the channel id for each channel of mailbox
*
* @param        CoreId
* @return       Mbox Ch ID
*
* Notes
*
***************************************************************************************************/

static MboxChIds_t get_Ipi_Mbox_Ch(    IpiCoreIds_t   CoreId)
{
	static MboxChIds_t	Ipi_Mbox_Ch;
	
	if(CoreId == IPI_CA65_NS)
	{
		Ipi_Mbox_Ch = MBOX_CH_A65_NON_SECURE_GP;
	}

#if ( CORTEX_M7_0 == 1)
	else if(CoreId == IPI_CM7_1)
	{
		Ipi_Mbox_Ch = MBOX_CH_M1_HP;
	}
	else if(CoreId == IPI_CM7_2)
	{
		Ipi_Mbox_Ch = MBOX_CH_M2_HP;
	}
	else if(CoreId == IPI_CM7_NP)
	{
		Ipi_Mbox_Ch = MBOX_CH_NP_HP;
	}
#endif

#if ( CORTEX_M7_1 == 1)
	else if(CoreId == IPI_CM7_0)
	{
		Ipi_Mbox_Ch = MBOX_CH_M0_GP;
	}
	else if(CoreId == IPI_CM7_2)
	{
		Ipi_Mbox_Ch = MBOX_CH_M2_HP;
	}
	else if(CoreId == IPI_CM7_NP)
	{
		Ipi_Mbox_Ch = MBOX_CH_NP_HP;
	}
#endif

#if ( CORTEX_M7_2 == 1)
	else if(CoreId == IPI_CM7_0)
	{
		Ipi_Mbox_Ch = MBOX_CH_M0_GP;
	}
	else if(CoreId == IPI_CM7_1)
	{
		Ipi_Mbox_Ch = MBOX_CH_M1_GP;
	}
	else if(CoreId == IPI_CM7_NP)
	{
		Ipi_Mbox_Ch = MBOX_CH_NP_HP;
	}
#endif

#if ( CORTEX_M7_NP == 1)
	else if(CoreId == IPI_CM7_0)
	{
		Ipi_Mbox_Ch = MBOX_CH_M0_GP;
	}
	else if(CoreId == IPI_CM7_1)
	{
		Ipi_Mbox_Ch = MBOX_CH_M1_GP;
	}
	else if(CoreId == IPI_CM7_2)
	{
		Ipi_Mbox_Ch = MBOX_CH_M2_GP;
	}
#endif

	else{}

	return Ipi_Mbox_Ch;
}


/**************************************************************************************************
*                                          Get Ipi Core Id
*
* [Internal] Return the core id for each channel of ipi
*
* @param        CoreId
* @return       Mbox Ch ID
*
* Notes
*
***************************************************************************************************/

static IpiCoreIds_t get_Ipi_Core_Id(    IpiCh_t   siCh)
{
	static IpiCoreIds_t	Ipi_Core_Id;
	
	if((siCh == IPI_CH_CA65_NS_USER) || (siCh == IPI_CH_CA65_NS_TPA) || (siCh == IPI_CH_CA65_NS_LPA))
	{
		Ipi_Core_Id = IPI_CA65_NS;
	}
#if ( CORTEX_M7_0 == 0)
	else if((siCh == IPI_CH_CM7_0_USER) || (siCh == IPI_CH_CM7_0_TPA) || (siCh == IPI_CH_CM7_0_LPA))
	{
		Ipi_Core_Id = IPI_CM7_0;
	}
#endif	
#if ( CORTEX_M7_1 == 0)
	else if((siCh == IPI_CH_CM7_1_USER) || (siCh == IPI_CH_CM7_1_TPA) || (siCh == IPI_CH_CM7_1_LPA))
	{
		Ipi_Core_Id = IPI_CM7_1;
	}
#endif	
#if ( CORTEX_M7_2 == 0)
	else if((siCh == IPI_CH_CM7_2_USER) || (siCh == IPI_CH_CM7_2_TPA) || (siCh == IPI_CH_CM7_2_LPA))
	{
		Ipi_Core_Id = IPI_CM7_2;
	}
#endif	
#if ( CORTEX_M7_NP == 0)
	else if((siCh == IPI_CH_CM7_NP_USER) || (siCh == IPI_CH_CM7_NP_TPA) || (siCh == IPI_CH_CM7_NP_LPA))
	{
		Ipi_Core_Id = IPI_CM7_NP;
	}
#endif	

	else{}

	return Ipi_Core_Id;
}

/**************************************************************************************************
*                                          Ipi Callback Task for CA65_NS Channel
*
* [Task] Execute callback function after checking ipi channel of CA65_NS core
*
* @param        void
* @return       void
*
* Notes
*
***************************************************************************************************/

static void IPI_Cb_Task_CA65_NS(void)
{
	uint8 * scmd;
	uint8 devname[6];
	IpiCh_t IpiCh;

	IpiMessage_t *sIpiMessage_ptr = 0;
	uint32	* posi_head = 0;

    while(1)
    {
		IPI_MBOX_RxIrq_ClearEvent(IPI_CA65_NS);
		IPI_MBOX_RxIrq_WaitEvent(IPI_CA65_NS);

		posi_head = (uint32 *)&ipi_mbox_rx[IPI_CA65_NS].posi_head;
		sIpiMessage_ptr = &ipi_mbox_rx[IPI_CA65_NS].buf[*posi_head];

		(*posi_head)++;
				
		if(*posi_head >= Mbox_buf_num)
		{
			*posi_head = 0;
		}

		scmd    = (uint8 *)sIpiMessage_ptr->Cmd;
		devname[0] = scmd[28];
		devname[1] = scmd[29];
		devname[2] = scmd[30];
		devname[3] = scmd[31];
		devname[4] = scmd[2];
		devname[5] = scmd[3];

		if((devname[0] == 'I') && (devname[1] == 'P') && (devname[2] == 'C') && (devname[3] == '_') && (devname[4] == 'U') && (devname[5] == '\0'))
		{
			IpiCh = IPI_CH_CA65_NS_USER;
		}
		else if((devname[0] == 'I') && (devname[1] == 'P') && (devname[2] == 'C') && (devname[3] == '_') && (devname[4] == 'T') && (devname[5] == 'P'))
		{
			IpiCh = IPI_CH_CA65_NS_TPA;
		}
		else if((devname[0] == 'I') && (devname[1] == 'P') && (devname[2] == 'C') && (devname[3] == '_') && (devname[4] == 'L') && (devname[5] == 'P'))
		{
			IpiCh = IPI_CH_CA65_NS_LPA;
		}
		else
		{
			IpiCh = IPI_CH_MAX;
		}

		if (ipi_info[IpiCh].register_flag == 1)
		{
			ipi_info[IpiCh].rx_cb(sIpiMessage_ptr);
		}
   	}	
}


/**************************************************************************************************
*                                          Ipi Callback Task for CM7_0 Channel
*
* [Task] Execute callback function after checking ipi channel of CM7_0 core
*
* @param        void
* @return       void
*
* Notes
*
***************************************************************************************************/

#if ( CORTEX_M7_0 == 0)
static void IPI_Cb_Task_CM7_0(void)
{
	uint8 * scmd;
	uint8 devname[6];
	IpiCh_t IpiCh;

	IpiMessage_t *sIpiMessage_ptr = 0;
	uint32	* posi_head = 0;

    while(1)
    {
		IPI_MBOX_RxIrq_ClearEvent(IPI_CM7_0);
		IPI_MBOX_RxIrq_WaitEvent(IPI_CM7_0);

		posi_head = (uint32 *)&ipi_mbox_rx[IPI_CM7_0].posi_head;
		sIpiMessage_ptr = &ipi_mbox_rx[IPI_CM7_0].buf[*posi_head];

		(*posi_head)++;
				
		if(*posi_head >= Mbox_buf_num)
		{
			*posi_head = 0;
		}

		scmd    = (uint8 *)sIpiMessage_ptr->Cmd;
		devname[0] = scmd[28];
		devname[1] = scmd[29];
		devname[2] = scmd[30];
		devname[3] = scmd[31];
		devname[4] = scmd[2];
		devname[5] = scmd[3];

		if((devname[0] == 'I') && (devname[1] == 'P') && (devname[2] == 'C') && (devname[3] == '_') && (devname[4] == 'U') && (devname[5] == '\0'))
		{
			IpiCh = IPI_CH_CM7_0_USER;
		}
		else if((devname[0] == 'I') && (devname[1] == 'P') && (devname[2] == 'C') && (devname[3] == '_') && (devname[4] == 'T') && (devname[5] == 'P'))
		{
			IpiCh = IPI_CH_CM7_0_TPA;
		}
		else if((devname[0] == 'I') && (devname[1] == 'P') && (devname[2] == 'C') && (devname[3] == '_') && (devname[4] == 'L') && (devname[5] == 'P'))
		{
			IpiCh = IPI_CH_CM7_0_LPA;
		}
		else
		{
			IpiCh = IPI_CH_MAX;
		}

		if (ipi_info[IpiCh].register_flag == 1)
		{
			ipi_info[IpiCh].rx_cb(sIpiMessage_ptr);
		}
   	}	
}
#endif	


/**************************************************************************************************
*                                          Ipi Callback Task for CM7_1 Channel
*
* [Task] Execute callback function after checking ipi channel of CM7_1 core
*
* @param        void
* @return       void
*
* Notes
*
***************************************************************************************************/
#if ( CORTEX_M7_1 == 0)
static void IPI_Cb_Task_CM7_1(void)
{
	uint8 * scmd;
	uint8 devname[6];
	IpiCh_t IpiCh;

	IpiMessage_t *sIpiMessage_ptr = 0;
	uint32	* posi_head = 0;

    while(1)
    {
		IPI_MBOX_RxIrq_ClearEvent(IPI_CM7_1);
		IPI_MBOX_RxIrq_WaitEvent(IPI_CM7_1);

		posi_head = (uint32 *)&ipi_mbox_rx[IPI_CM7_1].posi_head;
		sIpiMessage_ptr = &ipi_mbox_rx[IPI_CM7_1].buf[*posi_head];

		(*posi_head)++;
				
		if(*posi_head >= Mbox_buf_num)
		{
			*posi_head = 0;
		}

		scmd    = (uint8 *)sIpiMessage_ptr->Cmd;
		devname[0] = scmd[28];
		devname[1] = scmd[29];
		devname[2] = scmd[30];
		devname[3] = scmd[31];
		devname[4] = scmd[2];
		devname[5] = scmd[3];

		if((devname[0] == 'I') && (devname[1] == 'P') && (devname[2] == 'C') && (devname[3] == '_') && (devname[4] == 'U') && (devname[5] == '\0'))
		{
			IpiCh = IPI_CH_CM7_1_USER;
		}
		else if((devname[0] == 'I') && (devname[1] == 'P') && (devname[2] == 'C') && (devname[3] == '_') && (devname[4] == 'T') && (devname[5] == 'P'))
		{
			IpiCh = IPI_CH_CM7_1_TPA;
		}
		else if((devname[0] == 'I') && (devname[1] == 'P') && (devname[2] == 'C') && (devname[3] == '_') && (devname[4] == 'L') && (devname[5] == 'P'))
		{
			IpiCh = IPI_CH_CM7_1_LPA;
		}
		else
		{
			IpiCh = IPI_CH_MAX;
		}

		if (ipi_info[IpiCh].register_flag == 1)
		{
			ipi_info[IpiCh].rx_cb(sIpiMessage_ptr);
		}
   	}	
}
#endif	

/**************************************************************************************************
*                                          Ipi Callback Task for CM7_2 Channel
*
* [Task] Execute callback function after checking ipi channel of CM7_2 core
*
* @param        void
* @return       void
*
* Notes
*
***************************************************************************************************/
#if ( CORTEX_M7_2 == 0)
static void IPI_Cb_Task_CM7_2(void)
{
	uint8 * scmd;
	uint8 devname[6];
	IpiCh_t IpiCh;

	IpiMessage_t *sIpiMessage_ptr = 0;
	uint32	* posi_head = 0;

    while(1)
    {
		IPI_MBOX_RxIrq_ClearEvent(IPI_CM7_2);
		IPI_MBOX_RxIrq_WaitEvent(IPI_CM7_2);

		posi_head = (uint32 *)&ipi_mbox_rx[IPI_CM7_2].posi_head;
		sIpiMessage_ptr = &ipi_mbox_rx[IPI_CM7_2].buf[*posi_head];

		(*posi_head)++;
				
		if(*posi_head >= Mbox_buf_num)
		{
			*posi_head = 0;
		}

		scmd    = (uint8 *)sIpiMessage_ptr->Cmd;
		devname[0] = scmd[28];
		devname[1] = scmd[29];
		devname[2] = scmd[30];
		devname[3] = scmd[31];
		devname[4] = scmd[2];
		devname[5] = scmd[3];

		if((devname[0] == 'I') && (devname[1] == 'P') && (devname[2] == 'C') && (devname[3] == '_') && (devname[4] == 'U') && (devname[5] == '\0'))
		{
			IpiCh = IPI_CH_CM7_2_USER;
		}
		else if((devname[0] == 'I') && (devname[1] == 'P') && (devname[2] == 'C') && (devname[3] == '_') && (devname[4] == 'T') && (devname[5] == 'P'))
		{
			IpiCh = IPI_CH_CM7_2_TPA;
		}
		else if((devname[0] == 'I') && (devname[1] == 'P') && (devname[2] == 'C') && (devname[3] == '_') && (devname[4] == 'L') && (devname[5] == 'P'))
		{
			IpiCh = IPI_CH_CM7_2_LPA;
		}
		else
		{
			IpiCh = IPI_CH_MAX;
		}

		if (ipi_info[IpiCh].register_flag == 1)
		{
			ipi_info[IpiCh].rx_cb(sIpiMessage_ptr);
		}
   	}	
}
#endif	

/**************************************************************************************************
*                                          Ipi Callback Task for CM7_NP Channel
*
* [Task] Execute callback function after checking ipi channel of CM7_NP core
*
* @param        void
* @return       void
*
* Notes
*
***************************************************************************************************/
#if ( CORTEX_M7_NP == 0)
static void IPI_Cb_Task_CM7_NP(void)
{
	uint8 * scmd;
	uint8 devname[6];
	IpiCh_t IpiCh;

	IpiMessage_t *sIpiMessage_ptr = 0;
	uint32	* posi_head = 0;

    while(1)
    {
		IPI_MBOX_RxIrq_ClearEvent(IPI_CM7_NP);
		IPI_MBOX_RxIrq_WaitEvent(IPI_CM7_NP);

		posi_head = (uint32 *)&ipi_mbox_rx[IPI_CM7_NP].posi_head;
		sIpiMessage_ptr = &ipi_mbox_rx[IPI_CM7_NP].buf[*posi_head];

		(*posi_head)++;
				
		if(*posi_head >= Mbox_buf_num)
		{
			*posi_head = 0;
		}

		scmd    = (uint8 *)sIpiMessage_ptr->Cmd;
		devname[0] = scmd[28];
		devname[1] = scmd[29];
		devname[2] = scmd[30];
		devname[3] = scmd[31];
		devname[4] = scmd[2];
		devname[5] = scmd[3];

		if((devname[0] == 'I') && (devname[1] == 'P') && (devname[2] == 'C') && (devname[3] == '_') && (devname[4] == 'U') && (devname[5] == '\0'))
		{
			IpiCh = IPI_CH_CM7_NP_USER;
		}
		else if((devname[0] == 'I') && (devname[1] == 'P') && (devname[2] == 'C') && (devname[3] == '_') && (devname[4] == 'T') && (devname[5] == 'P'))
		{
			IpiCh = IPI_CH_CM7_NP_TPA;
		}
		else if((devname[0] == 'I') && (devname[1] == 'P') && (devname[2] == 'C') && (devname[3] == '_') && (devname[4] == 'L') && (devname[5] == 'P'))
		{
			IpiCh = IPI_CH_CM7_NP_LPA;
		}
		else
		{
			IpiCh = IPI_CH_MAX;
		}

		if (ipi_info[IpiCh].register_flag == 1)
		{
			ipi_info[IpiCh].rx_cb(sIpiMessage_ptr);
		}
   	}	
}
#endif	








/**************************************************************************************************
*                                          ipi_mailbox_make_ctlpacket
*
* [Internal] Make ipi ctl packet
*
* @param        ipi_info_buf, puiCmd
* @return       void
*
* Notes
*
***************************************************************************************************/

static void ipi_mailbox_make_ctlpacket(    ipi_info_t * ipi_info_buf,       const uint32 * puiCmd)
{
    uint8 * scmd;

    scmd    = (uint8 *) ipi_info_buf->ipi_mbox_msg.Cmd;
	scmd[2] = ipi_info_buf->devname[4];
	scmd[3] = ipi_info_buf->devname[5];
	scmd[28] = ipi_info_buf->devname[0];
	scmd[29] = ipi_info_buf->devname[1];
	scmd[30] = ipi_info_buf->devname[2];
	scmd[31] = ipi_info_buf->devname[3];

	ipi_info_buf->ipi_mbox_msg.Cmd[1] = puiCmd[0];
	ipi_info_buf->ipi_mbox_msg.Cmd[2] = puiCmd[1];
	ipi_info_buf->ipi_mbox_msg.Cmd[3] = puiCmd[2];
	ipi_info_buf->ipi_mbox_msg.Cmd[4] = puiCmd[3];
	ipi_info_buf->ipi_mbox_msg.Cmd[5] = puiCmd[4];
	ipi_info_buf->ipi_mbox_msg.Cmd[6] = puiCmd[5];
}




/**************************************************************************************************
*                                          ipi_mbox_Rxhandler_CA65_NS
*
* [Handler] ipi mbox rx handler for CA65_NS
*
* @param        void
* @return       void
*
* Notes
*
***************************************************************************************************/
static void ipi_mbox_Rxhandler_CA65_NS(void)
{
	int32 ret;
	static MboxChIds_t	Ipi_Mbox_Ch;
	MboxMessage_t * sMboxMessage_ptr;
	uint32	* posi_tail;

	Ipi_Mbox_Ch = get_Ipi_Mbox_Ch(IPI_CA65_NS);
	
	posi_tail = (uint32 *)&ipi_mbox_rx[IPI_CA65_NS].posi_tail;
	sMboxMessage_ptr = (MboxMessage_t *)&ipi_mbox_rx[IPI_CA65_NS].buf[*posi_tail];
	
	ret = MBOX_ReadMessage(Ipi_Mbox_Ch, sMboxMessage_ptr);

	if(ret == 0)
	{
		(*posi_tail)++;
		
		if(*posi_tail >= Mbox_buf_num)
		{
			*posi_tail = 0;
		}

		IPI_MBOX_RxIrq_WakeUp(IPI_CA65_NS);
	}
}


/**************************************************************************************************
*                                          ipi_mbox_Rxhandler_CM7_0
*
* [Handler] ipi mbox rx handler for CM7_0
*
* @param        void
* @return       void
*
* Notes
*
***************************************************************************************************/
#if ( CORTEX_M7_0 == 0)
static void ipi_mbox_Rxhandler_CM7_0(void)
{
	int32 ret;
	static MboxChIds_t	Ipi_Mbox_Ch;
	MboxMessage_t * sMboxMessage_ptr;
	uint32	* posi_tail;

	Ipi_Mbox_Ch = get_Ipi_Mbox_Ch(IPI_CM7_0);
	
	posi_tail = (uint32 *)&ipi_mbox_rx[IPI_CM7_0].posi_tail;
	sMboxMessage_ptr = (MboxMessage_t *)&ipi_mbox_rx[IPI_CM7_0].buf[*posi_tail];

	ret = MBOX_ReadMessage(Ipi_Mbox_Ch, sMboxMessage_ptr);

	if(ret == 0)
	{
		(*posi_tail)++;
		
		if(*posi_tail >= Mbox_buf_num)
		{
			*posi_tail = 0;
		}

		IPI_MBOX_RxIrq_WakeUp(IPI_CM7_0);
	}
}
#endif

/**************************************************************************************************
*                                          ipi_mbox_Rxhandler_CM7_1
*
* [Handler] ipi mbox rx handler for CM7_1
*
* @param        void
* @return       void
*
* Notes
*
***************************************************************************************************/
#if ( CORTEX_M7_1 == 0)
static void ipi_mbox_Rxhandler_CM7_1(void)
{
	int32 ret;
	static MboxChIds_t	Ipi_Mbox_Ch;
	MboxMessage_t * sMboxMessage_ptr;
	uint32	* posi_tail;

	Ipi_Mbox_Ch = get_Ipi_Mbox_Ch(IPI_CM7_1);
	
	posi_tail = (uint32 *)&ipi_mbox_rx[IPI_CM7_1].posi_tail;
	sMboxMessage_ptr = (MboxMessage_t *)&ipi_mbox_rx[IPI_CM7_1].buf[*posi_tail];

	ret = MBOX_ReadMessage(Ipi_Mbox_Ch, sMboxMessage_ptr);

	if(ret == 0)
	{
		(*posi_tail)++;
		
		if(*posi_tail >= Mbox_buf_num)
		{
			*posi_tail = 0;
		}

		IPI_MBOX_RxIrq_WakeUp(IPI_CM7_1);
	}
}
#endif


/**************************************************************************************************
*                                          ipi_mbox_Rxhandler_CM7_2
*
* [Handler] ipi mbox rx handler for CM7_2
*
* @param        void
* @return       void
*
* Notes
*
***************************************************************************************************/
#if ( CORTEX_M7_2 == 0)
static void ipi_mbox_Rxhandler_CM7_2(void)
{
	int32 ret;
	static MboxChIds_t	Ipi_Mbox_Ch;
	MboxMessage_t * sMboxMessage_ptr;
	uint32	* posi_tail;

	Ipi_Mbox_Ch = get_Ipi_Mbox_Ch(IPI_CM7_2);
	
	posi_tail = (uint32 *)&ipi_mbox_rx[IPI_CM7_2].posi_tail;
	sMboxMessage_ptr = (MboxMessage_t *)&ipi_mbox_rx[IPI_CM7_2].buf[*posi_tail];
	
	ret = MBOX_ReadMessage(Ipi_Mbox_Ch, sMboxMessage_ptr);

	if(ret == 0)
	{
		(*posi_tail)++;
		
		if(*posi_tail >= Mbox_buf_num)
		{
			*posi_tail = 0;
		}

		IPI_MBOX_RxIrq_WakeUp(IPI_CM7_2);
	}
}

#endif

/**************************************************************************************************
*                                          ipi_mbox_Rxhandler_CM7_NP
*
* [Handler] ipi mbox rx handler for CM7_NP
*
* @param        void
* @return       void
*
* Notes
*
***************************************************************************************************/
#if ( CORTEX_M7_NP == 0)
static void ipi_mbox_Rxhandler_CM7_NP(void)
{
	int32 ret;
	static MboxChIds_t	Ipi_Mbox_Ch;
	MboxMessage_t * sMboxMessage_ptr;
	uint32	* posi_tail;

	Ipi_Mbox_Ch = get_Ipi_Mbox_Ch(IPI_CM7_NP);

	posi_tail = (uint32 *)&ipi_mbox_rx[IPI_CM7_NP].posi_tail;
	sMboxMessage_ptr = (MboxMessage_t *)&ipi_mbox_rx[IPI_CM7_NP].buf[*posi_tail];
	
	ret = MBOX_ReadMessage(Ipi_Mbox_Ch, sMboxMessage_ptr);

	if(ret == 0)
	{
		(*posi_tail)++;
		
		if(*posi_tail >= Mbox_buf_num)
		{
			*posi_tail = 0;
		}

		IPI_MBOX_RxIrq_WakeUp(IPI_CM7_NP);
	}
}

#endif


/**************************************************************************************************
*                                          Ipi driver init
*
* [External] Initialize ipi driver
*
* @param        void
* @return       void
*
* Notes
*
***************************************************************************************************/
void ipi_mailbox_init(void)
{
    static uint32 IPI_CbTaskID[IPI_Core_MAX];
    static uint32 IPI_CbTaskStk[IPI_Core_MAX][IPI_CB_TASK_STK_SIZE];

	static MboxChIds_t	Ipi_Mbox_Ch;

	ipi_create_mutex();
	
	/* mbox channel open for CA65_NS */
	/* register interrupt vector, Enable Interrupt, Flush FIFO, Set Own Terminal State */
	Ipi_Mbox_Ch = get_Ipi_Mbox_Ch(IPI_CA65_NS);
	MBOX_Open(Ipi_Mbox_Ch, NULL_PTR, &ipi_mbox_Rxhandler_CA65_NS, MBOX_CFG_ILEVEL_3);
	IPI_MBOX_RxIrq_EventCreate(IPI_CA65_NS);

    (void) SAL_TaskCreate
	(
		&IPI_CbTaskID[IPI_CA65_NS],
       (const uint8 *) "IpiCbTsk_CA65_NS",
       (SALTaskFunc) &IPI_Cb_Task_CA65_NS,
       (uint32 * const) &IPI_CbTaskStk[IPI_CA65_NS][0],
       IPI_CB_TASK_STK_SIZE,SAL_PRIO_IPI_CB,NULL_PTR
	);


#if (CORTEX_M7_0 == 0)	

	/* mbox channel open for CM7_0 */
	/* register interrupt vector, Enable Interrupt, Flush FIFO, Set Own Terminal State */
	Ipi_Mbox_Ch = get_Ipi_Mbox_Ch(IPI_CM7_0);
	MBOX_Open(Ipi_Mbox_Ch, NULL_PTR, &ipi_mbox_Rxhandler_CM7_0, MBOX_CFG_ILEVEL_3);
	IPI_MBOX_RxIrq_EventCreate(IPI_CM7_0);

    (void) SAL_TaskCreate
	(
		&IPI_CbTaskID[IPI_CM7_0],
       (const uint8 *) "IpiCbTsk_CM7_0",
       (SALTaskFunc) &IPI_Cb_Task_CM7_0,
       (uint32 * const) &IPI_CbTaskStk[IPI_CM7_0][0],
       IPI_CB_TASK_STK_SIZE,SAL_PRIO_IPI_CB,NULL_PTR
	);

#endif

#if (CORTEX_M7_1 == 0)	
	/* mbox channel open for CM7_1 */
	/* register interrupt vector, Enable Interrupt, Flush FIFO, Set Own Terminal State */
	Ipi_Mbox_Ch = get_Ipi_Mbox_Ch(IPI_CM7_1);
	MBOX_Open(Ipi_Mbox_Ch, NULL_PTR, &ipi_mbox_Rxhandler_CM7_1, MBOX_CFG_ILEVEL_3);
	IPI_MBOX_RxIrq_EventCreate(IPI_CM7_1);

    (void) SAL_TaskCreate
	(
		&IPI_CbTaskID[IPI_CM7_1],
       (const uint8 *) "IpiCbTsk_CM7_1",
       (SALTaskFunc) &IPI_Cb_Task_CM7_1,
       (uint32 * const) &IPI_CbTaskStk[IPI_CM7_1][0],
       IPI_CB_TASK_STK_SIZE,SAL_PRIO_IPI_CB,NULL_PTR
	);	
#endif

#if (CORTEX_M7_2 == 0)		
	/* mbox channel open for CM7_2 */
	/* register interrupt vector, Enable Interrupt, Flush FIFO, Set Own Terminal State */
	Ipi_Mbox_Ch = get_Ipi_Mbox_Ch(IPI_CM7_2);
	MBOX_Open(Ipi_Mbox_Ch, NULL_PTR, &ipi_mbox_Rxhandler_CM7_2, MBOX_CFG_ILEVEL_3);
	IPI_MBOX_RxIrq_EventCreate(IPI_CM7_2);

	(void) SAL_TaskCreate
	(
		&IPI_CbTaskID[IPI_CM7_2],
       (const uint8 *) "IpiCbTsk_CM7_2",
       (SALTaskFunc) &IPI_Cb_Task_CM7_2,
       (uint32 * const) &IPI_CbTaskStk[IPI_CM7_2][0],
       IPI_CB_TASK_STK_SIZE,SAL_PRIO_IPI_CB,NULL_PTR
	);	
	
#endif

#if (CORTEX_M7_NP == 0)	
	/* mbox channel open for CM7_NP */
	/* register interrupt vector, Enable Interrupt, Flush FIFO, Set Own Terminal State */
	Ipi_Mbox_Ch = get_Ipi_Mbox_Ch(IPI_CM7_NP);
	MBOX_Open(Ipi_Mbox_Ch, NULL_PTR, &ipi_mbox_Rxhandler_CM7_NP, MBOX_CFG_ILEVEL_3);
	IPI_MBOX_RxIrq_EventCreate(IPI_CM7_NP);

	(void) SAL_TaskCreate
	(
		&IPI_CbTaskID[IPI_CM7_NP],
       (const uint8 *) "IpiCbTsk_CM7_NP",
       (SALTaskFunc) &IPI_Cb_Task_CM7_NP,
       (uint32 * const) &IPI_CbTaskStk[IPI_CM7_NP][0],
       IPI_CB_TASK_STK_SIZE,SAL_PRIO_IPI_CB,NULL_PTR
	);	

#endif

}


/**************************************************************************************************
*                                          Ipi driver init
*
* [External] Registering ipi callback function
*
* @param        ipiCh, cb_func
* @return       ipi ret
*
* Notes
*
***************************************************************************************************/

int32 ipi_register(IpiCh_t ipiCh, IPICallback cb_func)
{
	int32 ret = IPI_RET_ERR_COMMON;

	if((ipi_info[ipiCh].register_flag == 0) && (cb_func != NULL) && (ipiCh < IPI_CH_MAX))
	{
		ipi_info[ipiCh].register_flag = 1;
		/* register interrupt Callback Function */
		ipi_info[ipiCh].rx_cb = cb_func;
		
		ret = IPI_RET_OK;
	}

	return ret;
}

/**************************************************************************************************
*                                          ipi_mailbox_send_message
*
* [External] Send mailbox message
*
* @param        ipiCh, puiCmd, puiData, siLen
* @return       ipi ret
*
* Notes
*
***************************************************************************************************/
#define	RetryNumforSend	200U

int32 ipi_mailbox_send_message(IpiCh_t          ipiCh, const uint32 * puiCmd, const uint32 * puiData, uint32 siLen)
{
	int32 ret = IPI_RET_ERR_COMMON;

	uint32 i = 0;
	uint8	RetryCntforSend = RetryNumforSend;
	static MboxChIds_t	Ipi_Mbox_Ch;
	static IpiCoreIds_t	Ipi_Core_Id;

	ipi_mbox_lock();

	if ((ipi_info[ipiCh].register_flag == 1) && (puiData != (void *)0) && ((siLen <= MBOX_CFG_DATA_FIFO_SIZE) && (siLen > 0)))
    {				
		ipi_mailbox_make_ctlpacket(&ipi_info[ipiCh], puiCmd);

		for(i = 0; i < siLen; i++)
		{
			ipi_info[ipiCh].ipi_mbox_msg.Data[i] = puiData[i];
		}

		ipi_info[ipiCh].ipi_mbox_msg.CmdLen = 8U;
		ipi_info[ipiCh].ipi_mbox_msg.DataLen = siLen;

		Ipi_Core_Id = get_Ipi_Core_Id(ipiCh);
		Ipi_Mbox_Ch = get_Ipi_Mbox_Ch(Ipi_Core_Id);
	
		while(0U < RetryCntforSend)
		{
			
			ret = MBOX_SendMessage(Ipi_Mbox_Ch, (MboxMessage_t *)&ipi_info[ipiCh].ipi_mbox_msg);	
			
			if(ret != SAL_RET_FAILED)
			{				
				break;
			}

			RetryCntforSend--;
		}
    }
    else
    {
        ret = IPI_RET_ERR_COMMON;
    }

	ipi_mbox_unlock();
	
	return ret;
}

/**************************************************************************************************
*                                          ipi_mailbox_send_command
*
* [External] Send mailbox command
*
* @param        ipiCh, puiCmd
* @return       ipi ret
*
* Notes
*
***************************************************************************************************/
int32 ipi_mailbox_send_command(IpiCh_t          ipiCh, const uint32 * puiCmd)
{
	int32 ret = IPI_RET_ERR_COMMON;

	uint8	RetryCntforSend = RetryNumforSend;
	static MboxChIds_t	Ipi_Mbox_Ch;
	static IpiCoreIds_t	Ipi_Core_Id;

	ipi_mbox_lock();

	if ((ipi_info[ipiCh].register_flag == 1) && (puiCmd != (void *)0))
    {
    	ipi_mailbox_make_ctlpacket(&ipi_info[ipiCh], puiCmd);

		ipi_info[ipiCh].ipi_mbox_msg.CmdLen = 8U;

		Ipi_Core_Id = get_Ipi_Core_Id(ipiCh);
		Ipi_Mbox_Ch = get_Ipi_Mbox_Ch(Ipi_Core_Id);

		while(0U < RetryCntforSend)
		{
			ret = MBOX_SendCommand(Ipi_Mbox_Ch, (MboxMessage_t *)&ipi_info[ipiCh].ipi_mbox_msg);
			if(ret != SAL_RET_FAILED)
			{
				break;
			}

			RetryCntforSend--;
		}
    }
    else
    {
        ret = IPI_RET_ERR_COMMON;
    }

	ipi_mbox_unlock();
	
	return ret;
}

/**************************************************************************************************
*                                          ipi_mailbox_send_open command
*
* [External] Send mailbox ipc open command
*
* @param        ipiCh, puiCmd
* @return       ipi ret
*
* Notes
*
***************************************************************************************************/
int32 ipi_mailbox_send_command_open(IpiCh_t		       ipiCh, const uint32 * puiCmd)
{
	int32 ret = IPI_RET_ERR_COMMON;

	static MboxChIds_t	Ipi_Mbox_Ch;
	static IpiCoreIds_t	Ipi_Core_Id;

	static int32   OppTerminalStatus_num[IPI_CH_MAX] = {0, };

	ipi_mbox_lock();

	if ((ipi_info[ipiCh].register_flag == 1) && (puiCmd != (void *)0))
    {   
    	ipi_mailbox_make_ctlpacket(&ipi_info[ipiCh], puiCmd);

		ipi_info[ipiCh].ipi_mbox_msg.CmdLen = 8U;

		Ipi_Core_Id = get_Ipi_Core_Id(ipiCh);
		Ipi_Mbox_Ch = get_Ipi_Mbox_Ch(Ipi_Core_Id);

		if(1 == MBOX_GetOppTerminalStatus(Ipi_Mbox_Ch))
		{
			OppTerminalStatus_num[ipiCh]++;
		}
		else
		{
			OppTerminalStatus_num[ipiCh] = 0;
		}
			
		if(OppTerminalStatus_num[ipiCh] >= 150)
		{
			ret = MBOX_SendCommand(Ipi_Mbox_Ch, (MboxMessage_t *)&ipi_info[ipiCh].ipi_mbox_msg);

			OppTerminalStatus_num[ipiCh] = 0;
		}

    }
    else
    {
        ret = IPI_RET_ERR_COMMON;
    }

	ipi_mbox_unlock();
	
	return ret;
}


