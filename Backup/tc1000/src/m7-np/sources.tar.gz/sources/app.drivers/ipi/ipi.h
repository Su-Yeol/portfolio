/*
***************************************************************************************************
*
*   FileName : ipi.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef TCC_IPI_H
#define TCC_IPI_H

/****************************************
 *				Include					*
 ****************************************/
#include "mbox.h"



/****************************************
 *				Defines					*
 ****************************************/
#define IPI_CB_TASK_STK_SIZE				(256U)
#define IPI_MBOX_RxIrq_WAIT_FLAG            (0x00000001UL)

#define IPI_RET_OK                 		    (0)              /* Success */
#define IPI_RET_ERR_COMMON                  (1)             /* common error*/

#define	Mbox_buf_num						4U 		 // minimum 4


#define	IPI_MBOX_CFG_CMD_FIFO_SIZE		MBOX_CFG_CMD_FIFO_SIZE
#define	IPI_MBOX_CFG_DATA_FIFO_SIZE		MBOX_CFG_DATA_FIFO_SIZE

/****************************************
 *				Enumeration				*
 ****************************************/
typedef enum
{
	IPI_CA65_NS   = 0x00UL,
#if (CORTEX_M7_0 == 0)
	IPI_CM7_0,
#endif
#if (CORTEX_M7_1 == 0)
	IPI_CM7_1,
#endif
#if (CORTEX_M7_2 == 0)
	IPI_CM7_2,
#endif
#if (CORTEX_M7_NP == 0)
	IPI_CM7_NP,
#endif
	IPI_Core_MAX
} IpiCoreIds_t;


typedef enum
{
	IPI_CH_CA65_NS_USER   = 0x00UL,
	IPI_CH_CA65_NS_TPA,
	IPI_CH_CA65_NS_LPA,

#if (CORTEX_M7_0 == 0)
	IPI_CH_CM7_0_USER,
	IPI_CH_CM7_0_TPA,
	IPI_CH_CM7_0_LPA,
#endif

#if (CORTEX_M7_1 == 0)	
	IPI_CH_CM7_1_USER,
	IPI_CH_CM7_1_TPA,
	IPI_CH_CM7_1_LPA,
#endif

#if (CORTEX_M7_2 == 0)	
	IPI_CH_CM7_2_USER,
	IPI_CH_CM7_2_TPA,
	IPI_CH_CM7_2_LPA,
#endif

#if (CORTEX_M7_NP == 0)	
	IPI_CH_CM7_NP_USER,
	IPI_CH_CM7_NP_TPA,
	IPI_CH_CM7_NP_LPA,
#endif

	IPI_CH_MAX
} IpiCh_t;



/****************************************
 *				Typedefs				*
****************************************/
typedef struct IPIOsFlags
{
    uint32			ipiMboxRxIrqWaitFlagId;	
} IPIOsFlags_t;

typedef struct
{
    uint32                              CmdLen;   /* UNIT: WORD */
    uint32                              DataLen;  /* UNIT: WORD */
    uint32                              Cmd[IPI_MBOX_CFG_CMD_FIFO_SIZE];
    uint32                              Data[IPI_MBOX_CFG_DATA_FIFO_SIZE];
}IpiMessage_t;

typedef void (*IPICallback)(const IpiMessage_t *	sIpiMessage);

typedef struct IPICbFunc
{
    IPICallback                         ipiCbFunc;
    void*                               ipiArg1;
    void*                               ipiArg2;
} IPICbFunc_t;

typedef struct ipi_info{
	uint8	register_flag;
	IPICallback rx_cb;
	uint8	devname[6];
	IpiMessage_t ipi_mbox_msg;	
}ipi_info_t;

typedef struct ipi_mbox_rx{
	uint32 posi_head;
	uint32 posi_tail;
	IpiMessage_t buf[Mbox_buf_num];
}ipi_mbox_rx_t;


/***************************************************
*			Function declaration				*
****************************************************/
void ipi_mailbox_init(void);
int32 ipi_register(IpiCh_t ipiCh, IPICallback cb_func);

int32 ipi_mailbox_send_message(IpiCh_t		       ipiCh, const uint32 * puiCmd, const uint32 * puiData, uint32 siLen);
int32 ipi_mailbox_send_command(IpiCh_t		       ipiCh, const uint32 * puiCmd);
int32 ipi_mailbox_send_command_open(IpiCh_t		       ipiCh, const uint32 * puiCmd);

#endif /* _IPC_CMD_H_ */

