/* Copyright (c) Telechips Inc.
 * All rights reserved
 * This source code contains confidential information of Telechips.
 *
 * Any unauthorized use without a written permission of Telechips including
 * not limited to re-distribution in source or binary form is strictly
 * prohibited. This source code is provided “AS IS” and nothing contained
 * in this source code shall constitute any express or implied warranty of
 * any kind, including without limitation, any warranty of merchantability,
 * fitness for a particular purpose or non-infringement of any patent,
 * copyright or other third party intellectual property right. No warranty
 * is made, express or implied, regarding the information’s accuracy,
 * completeness, or performance.
 *
 * In no event shall Telechips be liable for any claim, damages or other
 * liability arising from, out of or in connection with this source code
 * or the use in the source code.
 *
 * This source code is provided subject to the terms of a Mutual Non-Disclosure
 * Agreement between Telechips and Company.
 */

#ifndef T_LOG_H
#define T_LOG_H

#include <stdio.h>

#ifndef NDEBUG
#define DEBUG
#endif

#define TLOG_VBS (5)
#define TLOG_DEBUG (4)
#define TLOG_INFO (3)
#define TLOG_WARNING (2)
#define TLOG_ERROR (1)

#ifndef TLOG_LEVEL
#define TLOG_LEVEL TLOG_INFO
#endif

#ifndef TLOG_TAG
#define TLOG_TAG (__func__)
#endif

//#define COLOR_TAG	(1)

/* clang-format off */
#ifdef COLOR_TAG
#define GRAY_COLOR             "\033[1;30m"
#define NORMAL_COLOR           "\033[0m"
#define RED_COLOR              "\033[1;31m"
#define GREEN_COLOR            "\033[1;32m"
#define MAGENTA_COLOR          "\033[1;35m"
#define YELLOW_COLOR           "\033[1;33m"
#define BLUE_COLOR             "\033[1;34m"
#define DBLUE_COLOR            "\033[0;34m"
#define WHITE_COLOR            "\033[1;37m"
#define COLORERR_COLOR         "\033[1;37;41m"
#define COLORWRN_COLOR         "\033[0;31m"
#define BROWN_COLOR            "\033[0;40;33m"
#define CYAN_COLOR             "\033[0;40;36m"
#define LIGHTGRAY_COLOR        "\033[1;40;37m"
#define BRIGHTRED_COLOR        "\033[0;40;31m"
#define BRIGHTBLUE_COLOR       "\033[0;40;34m"
#define BRIGHTMAGENTA_COLOR    "\033[0;40;35m"
#define BRIGHTCYAN_COLOR       "\033[0;40;36m"
#else
#define GRAY_COLOR             ""
#define NORMAL_COLOR           ""
#define RED_COLOR              ""
#define GREEN_COLOR            ""
#define MAGENTA_COLOR          ""
#define YELLOW_COLOR           ""
#define BLUE_COLOR             ""
#define DBLUE_COLOR            ""
#define WHITE_COLOR            ""
#define COLORERR_COLOR         ""
#define COLORWRN_COLOR         ""
#define BROWN_COLOR            ""
#define CYAN_COLOR             ""
#define LIGHTGRAY_COLOR        ""
#define BRIGHTRED_COLOR        ""
#define BRIGHTBLUE_COLOR       ""
#define BRIGHTMAGENTA_COLOR    ""
#define BRIGHTCYAN_COLOR       ""
#endif

/* no logging */
#define TLOG_NDMSG(...)                 \
	do {                                \
		if (0) {                        \
			mcu_printf(__VA_ARGS__); \
		}                               \
	} while (0)

/* logging */
#ifdef TLOG_NDEBUG
#define TLOG_DMSG(...) TLOG_NDMSG(__VA_ARGS__)
#else
#define TLOG_DMSG(...) mcu_printf(__VA_ARGS__)
#endif

/* Verbose logging */
#if (TLOG_LEVEL >= TLOG_VBS)
#define TLOG_VERBOSE_MSG(...) TLOG_DMSG(__VA_ARGS__)
#else
#define TLOG_VERBOSE_MSG(...) TLOG_NDMSG(__VA_ARGS__)
#endif

/* Debug logging */
#if (TLOG_LEVEL >= TLOG_DEBUG)
#define TLOG_DEBUG_MSG(...) TLOG_DMSG(__VA_ARGS__)
#else
#define TLOG_DEBUG_MSG(...) TLOG_NDMSG(__VA_ARGS__)
#endif

/* Informational logging */
#if (TLOG_LEVEL >= TLOG_INFO)
#define TLOG_INFO_MSG(...) TLOG_DMSG(__VA_ARGS__)
#else
#define TLOG_INFO_MSG(...) TLOG_NDMSG(__VA_ARGS__)
#endif

/* Warning logging */
#if (TLOG_LEVEL >= TLOG_WARNING)
#define TLOG_WARN_MSG(...) TLOG_DMSG(__VA_ARGS__)
#else
#define TLOG_WARN_MSG(...) TLOG_NDMSG(__VA_ARGS__)
#endif

/* Error logging */
#if (TLOG_LEVEL >= TLOG_ERROR)
#define TLOG_ERROR_MSG(...) TLOG_DMSG(__VA_ARGS__)
#else
#define TLOG_ERROR_MSG(...) TLOG_NDMSG(__VA_ARGS__)
#endif

/* Color tagging */
#define TRACE \
	TLOG_DEBUG_MSG(NORMAL_COLOR "[TRACE][%s][%d]\n", TLOG_TAG, __LINE__)

#define TLOG_VBSTAG(fmt, ...) \
	TLOG_VERBOSE_MSG(NORMAL_COLOR "[VERBOSE][%s][%d]" \
		NORMAL_COLOR " " fmt "%s", TLOG_TAG, __LINE__, __VA_ARGS__)

#define TLOG_DBGTAG(fmt, ...) \
	TLOG_DEBUG_MSG(GREEN_COLOR "[DEBUG][%s][%d]" \
		NORMAL_COLOR " " fmt "%s", TLOG_TAG, __LINE__, __VA_ARGS__)

#define TLOG_INFTAG(fmt, ...) \
	TLOG_INFO_MSG(YELLOW_COLOR "[INFO][%s][%d]" \
		NORMAL_COLOR " " fmt "%s", TLOG_TAG, __LINE__, __VA_ARGS__)

#define TLOG_WRNTAG(fmt, ...) \
	TLOG_WARN_MSG(COLORWRN_COLOR "[WARN][%s][%d]" \
		NORMAL_COLOR " " fmt "%s", TLOG_TAG, __LINE__, __VA_ARGS__)

#define TLOG_ERRTAG(fmt, ...) \
	TLOG_ERROR_MSG(COLORERR_COLOR "[ERROR][%s][%d]" \
		NORMAL_COLOR " " fmt "%s", TLOG_TAG, __LINE__, __VA_ARGS__)

#define VLOG(...) TLOG_VBSTAG(__VA_ARGS__, "")
#define DLOG(...) TLOG_DBGTAG(__VA_ARGS__, "")
#define ILOG(...) TLOG_INFTAG(__VA_ARGS__, "")
#define WLOG(...) TLOG_WRNTAG(__VA_ARGS__, "")
#define ELOG(...) TLOG_ERRTAG(__VA_ARGS__, "")
/* clang-format on */

#endif // T_LOG_H
