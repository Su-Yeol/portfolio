/*
***************************************************************************************************
*
*   FileName : hsm_manager.h
*
*   Copyright (c) Telechips Inc.
*
*   Description : HSM MANAGER
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef HSM_MANAGER_HEADER
#define HSM_MANAGER_HEADER

/*
***************************************************************************************************
*                                             INCLUDE FILES
***************************************************************************************************
*/
#include "mbox.h"

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/
// clang-format off
#define REQ_HSM_RUN_AES                         (0x10010000U)
#define REQ_HSM_RUN_AES_BY_KT                   (0x10020000U)
#define REQ_HSM_RUN_SM4                         (0x10030000U)
#define REQ_HSM_RUN_SM4_BY_KT                   (0x10040000U)

#define REQ_HSM_GEN_CMAC                        (0x10110000U)
#define REQ_HSM_GEN_CMAC_BY_KT                  (0x10120000U)
#define REQ_HSM_VERIFY_CMAC                     (0x10130000U)
#define REQ_HSM_VERIFY_CMAC_BY_KT               (0x10140000U)

#define REQ_HSM_GEN_HMAC                        (0x10150000U)
#define REQ_HSM_GEN_HMAC_BY_KT                  (0x10160000U)
#define REQ_HSM_GEN_SM3_HMAC                    (0x10170000U)
#define REQ_HSM_GEN_SM3_HMAC_BY_KT              (0x10180000U)

#define REQ_HSM_GEN_SHA                         (0x10210000U)
#define REQ_HSM_GEN_SM3                         (0x10220000U)

#define REQ_HSM_RUN_ECDSA_SIGN                  (0x10310000U)
#define REQ_HSM_RUN_ECDSA_VERIFY                (0x10320000U)
#define REQ_HSM_RUN_ECDH_PUBKEY_COMPUTE         (0x10330000u)
#define REQ_HSM_RUN_ECDH_PHASE_I                (0x10340000u)
#define REQ_HSM_RUN_ECDH_PHASE_II               (0x10350000u)
#define REQ_HSM_RUN_ECDSA_SIGN_BY_KT            (0x10360000u)
#define REQ_HSM_RUN_ECDSA_VERIFY_BY_KT          (0x10370000u)

#define REQ_HSM_RUN_RSAES_PKCS_ENC				(0x10510000u)
#define REQ_HSM_RUN_RSAES_PKCS_DEC				(0x10520000u)
#define REQ_HSM_RUN_RSAES_OAEP_ENC				(0x10530000u)
#define REQ_HSM_RUN_RSAES_OAEP_DEC			    (0x10540000u)

#define REQ_HSM_RUN_RSASSA_PKCS_SIGN            (0x10550000U)
#define REQ_HSM_RUN_RSASSA_PKCS_VERIFY          (0x10560000U)
#define REQ_HSM_RUN_RSASSA_PSS_SIGN             (0x10570000U)
#define REQ_HSM_RUN_RSASSA_PSS_VERIFY           (0x10580000U)

#define REQ_HSM_RUN_RSAES_PKCS_ENC_BY_KT        (0x10590000u)
#define REQ_HSM_RUN_RSAES_PKCS_DEC_BY_KT        (0x105A0000u)
#define REQ_HSM_RUN_RSAES_OAEP_ENC_BY_KT        (0x105B0000u)
#define REQ_HSM_RUN_RSAES_OAEP_DEC_BY_KT        (0x105C0000u)

#define REQ_HSM_RUN_RSASSA_PKCS_SIGN_BY_KT      (0x105D0000u)
#define REQ_HSM_RUN_RSASSA_PKCS_VERIFY_BY_KT    (0x105E0000u)
#define REQ_HSM_RUN_RSASSA_PSS_SIGN_BY_KT       (0x105F0000u)
#define REQ_HSM_RUN_RSASSA_PSS_VERIFY_BY_KT     (0x10600000u)

#define REQ_HSM_GET_RNG                         (0x10610000U)
#define REQ_HSM_WRITE_OTP                       (0x10710000U)
#define REQ_HSM_WRITE_SNOR                      (0x10720000U)
#define REQ_HSM_SET_KEY_FROM_OTP                (0x10810000U)
#define REQ_HSM_SET_KEY_FROM_SNOR               (0x10820000U)
#define REQ_HSM_SET_MODN_FROM_OTP               (0x10840000u)
#define REQ_HSM_SET_MODN_FROM_SNOR              (0x10850000u)
#define REQ_HSM_BLOCK_AP_SYSTEM                 (0x10910000U)
#define REQ_HSM_GET_VER                         (0x20010000U)

#define MBOX_CID_AP                             (0x0200u)
#define MBOX_CID_HSM                            (0xA000u)
#define MBOX_CID_CM7                            (0xFF00u)

#define MBOX_BSID_BL0                           (0x0042u)
#define MBOX_BSID_BL1                           (0x0043u)
#define MBOX_BSID_BL3                           (0x0045u)
#define MBOX_BSID_KERNEL                        (0x0046u)
#define MBOX_HSM_CMD0 (MBOX_CID_CM7 | MBOX_BSID_KERNEL)


/* HSM Key Size */
#define TCC_HSM_SRC_SIZE (320U)

#define TCC_HSM_AES_KEY_SIZE (32U)
#define TCC_HSM_AES_IV_SIZE (32U)
#define TCC_HSM_AES_TAG_SIZE (32U)
#define TCC_HSM_AES_AAD_SIZE (32U)

#define TCC_HSM_MAC_KEY_SIZE (32U)
#define TCC_HSM_MAC_MSG_SIZE (32U)

#define TCC_HSM_HASH_DIGEST_SIZE (64U)
#define TCC_HSM_ECDSA_KEY_SIZE (64U)
#define TCC_HSM_ECDSA_P521_KEY_SIZE (68U)
#define TCC_HSM_ECDSA_DIGEST_SIZE (64U)
#define TCC_HSM_ECDSA_SIGN_SIZE (64U)

#define TCC_HSM_RSA_MODN_SIZE (128U)
#define TCC_HSM_RSA_DIG_SIZE (64U)
#define TCC_HSM_RSA_SIG_SIZE (128U)

#define HSM_MBOX_MSG_MAXSIZE                    (512U)
#define HSM_CMD_FIFO_SIZE                       (0x0008U)
#define HSM_MBOX_LOCATION_DATA                  (0x0400U)
#define HSM_MBOX_LOCATION_CMD                   (0x0000U)
#define HSM_MBOX_ID_HSM                         (0x4D5348) /* 0x4D5348 = "HSM" */
#define HSM_MBOX_TIMEOUT                        (1000U)

/* Error Code 0x000000XX */
#define TCCHSM_SUCCESS                          (0x00000000u)
#define TCCHSM_ERR                              (0x00000001u)
#define TCCHSM_ERR_INVALID_PARAM                (0x00000002u)
#define TCCHSM_ERR_INVALID_STATE                (0x00000003u)
#define TCCHSM_ERR_INVALID_MEMORY               (0x00000004u)
#define TCCHSM_ERR_UNSUPPORTED_FUNC             (0x00000005u)
#define TCCHSM_ERR_OTP                          (0x00000006u)
#define TCCHSM_ERR_CRYPTO                       (0x00000007u)
#define TCCHSM_ERR_OCCUPIED_RESOURCE            (0x00000008u)
#define TCCHSM_ERR_IMG_INTEGRITY                (0x00000009u)
#define TCCHSM_ERR_RBID_MISMATCH                (0x0000000Au)
#define TCCHSM_ERR_IMGID_MISMATCH               (0x0000000Bu)
#define TCCHSM_ERR_ATTR_MISMATCH                (0x0000000Cu)
#define TCCHSM_ERR_VERSION_MISMATCH             (0x0000000Du)

#define OID_OPMODE_INIT         (0x10000000u)  /* Operation Mode is "Init" */
#define OID_OPMODE_UPDATE       (0x20000000u)  /* Operation Mode is "Update". Used to calculate intermediate results. */
#define OID_OPMODE_FINAL        (0x40000000u)  /* Operation Mode is "Final". The calculations shall be finalized. */
#define OID_OPMODE_SINGLECALL   (0x00000000u)  /* Operation Mode is "Single Call". Mixture of "Init", "Update" and "Final". */

/* HSM Key Size */
#define TCC_HSM_SRC_SIZE (320U)

#define TCC_HSM_AES_KEY_SIZE (32U)
#define TCC_HSM_AES_IV_SIZE (32U)
#define TCC_HSM_AES_TAG_SIZE (32U)
#define TCC_HSM_AES_AAD_SIZE (32U)

#define TCC_HSM_MAC_KEY_SIZE (32U)
#define TCC_HSM_MAC_MSG_SIZE (32U)

#define TCC_HSM_HASH_DIGEST_SIZE (64U)
#define TCC_HSM_ECDSA_KEY_SIZE (64U)
#define TCC_HSM_ECDSA_P521_KEY_SIZE (68U)
#define TCC_HSM_ECDSA_DIGEST_SIZE (64U)
#define TCC_HSM_ECDSA_SIGN_SIZE (64U)

#define TCC_HSM_RSA_MODN_SIZE (128U)
#define TCC_HSM_RSA_DIG_SIZE (64U)
#define TCC_HSM_RSA_SIG_SIZE (128U)

/* HSM key index */
#define HSM_A72_AES_KEY_INDEX (0x0000)
#define HSM_A72_MAC_KEY_INDEX (0x0004)
#define HSM_A53_AES_KEY_INDEX (0x0013)
#define HSM_A53_MAC_KEY_INDEX (0x0017)
#define HSM_R5_AES_KEY_INDEX (0x0026)
#define HSM_R5_MAC_KEY_INDEX (0x0027)
#define HSM_A72_ECDSA_P256_PRIKEY_INDEX (0x0005)
#define HSM_A72_ECDSA_P256_PUBKEY_INDEX (0x0006)
#define HSM_A72_RSASSA_PRIKEY_INDEX (0x000D)
#define HSM_A72_RSASSA_PUBKEY_INDEX (0x000E)
#define HSM_R5_ECDSA_P256_PRIKEY_INDEX (0x0028)
#define HSM_R5_ECDSA_P256_PUBKEY_INDEX (0x0029)
#define HSM_R5_RSASSA_PRIKEY_INDEX (0x002A)
#define HSM_R5_RSASSA_PUBKEY_INDEX (0x002B)

/* HSM key address */
#define HSM_A72_AESKEY_ADDR (0x00100)
#define HSM_A72_MACKEY_ADDR (0x00200)
#define HSM_A53_AESKEY_ADDR (0x10100)
#define HSM_A53_MACKEY_ADDR (0x10200)
#define HSM_R5_AESKEY_ADDR (0x20100)
#define HSM_R5_MACKEY_ADDR (0x20200)
#define HSM_A72_ECDSA_P256_PRIKEY_ADDR (0x01000)
#define HSM_A72_ECDSA_P256_PUBKEY_ADDR (0x01100)
#define HSM_A72_RSASSA_PRIKEY_ADDR (0x02000)
#define HSM_A72_RSASSA_PUBKEY_ADDR (0x02080)
#define HSM_A72_RSASSA_MOD_ADDR (0x02180)
#define HSM_R5_ECDSA_P256_PRIKEY_ADDR (0x21000)
#define HSM_R5_ECDSA_P256_PUBKEY_ADDR (0x21100)
#define HSM_R5_RSASSA_PRIKEY_ADDR (0x22000)
#define HSM_R5_RSASSA_PUBKEY_ADDR (0x22080)
#define HSM_R5_RSASSA_MODN_ADDR (0x22180)

/* HSM OID CMAC */
#define HSM_OID_CMAC_AES128   (0x00101208U)
/* HSM OID HMAC */
#define HSM_OID_HMAC_SHA1_160 (0x00011100U)
#define HSM_OID_HMAC_SHA2_224 (0x00012200U)
#define HSM_OID_HMAC_SHA2_256 (0x00012300U)
#define HSM_OID_HMAC_SHA2_384 (0x00012400U)
#define HSM_OID_HMAC_SHA2_512 (0x00012500U)
#define HSM_OID_HMAC_SHA3_224 (0x00013200U)
#define HSM_OID_HMAC_SHA3_256 (0x00013300U)
#define HSM_OID_HMAC_SHA3_384 (0x00013400U)
#define HSM_OID_HMAC_SHA3_512 (0x00013500U)

/* HSM OID SHA/SM3 */
#define HSM_OID_SHA1_160 (0x00001100U)
#define HSM_OID_SHA2_224 (0x00002200U)
#define HSM_OID_SHA2_256 (0x00002300U)
#define HSM_OID_SHA2_384 (0x00002400U)
#define HSM_OID_SHA2_512 (0x00002500U)
#define HSM_OID_SHA3_224 (0x00003200U)
#define HSM_OID_SHA3_256 (0x00003300U)
#define HSM_OID_SHA3_384 (0x00003400U)
#define HSM_OID_SHA3_512 (0x00003500U)
#define HSM_OID_SM3_256 (0x01002300U)

/* HSM ECC Code */
#define HSM_OID_ECC_P256 (0x00000013U)
#define HSM_OID_ECC_P384 (0x00000014U)
#define HSM_OID_ECC_P521 (0x00000015U)
#define HSM_OID_ECC_BP256 (0x00000053U)
#define HSM_OID_ECC_BP384 (0x00000054U)
#define HSM_OID_ECC_BP512 (0x00000055U)
#define HSM_OID_SM2_256_SM3_256 (0x010023A3U)
#define HSM_RSASSA_PSS_OID_HASH (HSM_OID_SHA2_256)

/* HSM DMA type */
#define HSM_NONE_DMA (0)
#define HSM_DMA (1)

/* HSM ioctl cmd */
#define HSM_RUN_AES                      (0U)
#define HSM_GEN_CMAC                     (1U)
#define HSM_VERIFY_CMAC                  (2U)
#define HSM_GEN_HMAC                     (3U)
#define HSM_GEN_SHA                      (4U)
#define HSM_RUN_ECDSA_SIGN               (5U)
#define HSM_RUN_ECDSA_VERIFY             (6U)
#define HSM_RUN_ECDH_PHASE_I             (7U)
#define HSM_RUN_ECDH_PHASE_II            (8U)
#define HSM_RUN_ECDH_COMPUTE_PUBKEY      (9U)
#define HSM_GET_RNG                      (10U)
#define HSM_GET_VER                      (11U)
#define HSM_FULL                         (12U)
#define HSM_AGING                        (13U)
#define HSM_MAX                          (14U)

/* HSM AES type */
#define HSM_AES_ENCRYPT (0x00000000U)
#define HSM_AES_DECRYPT (0x01000000U)
#define HSM_AES_ECB_128 (0x00100008U)
#define HSM_AES_ECB_192 (0x00180008U)
#define HSM_AES_ECB_256 (0x00200008U)
#define HSM_AES_CBC_128 (0x00100108U)
#define HSM_AES_CBC_192 (0x00180108U)
#define HSM_AES_CBC_256 (0x00200108U)
#define HSM_AES_CTR_128 (0x00100208U)
#define HSM_AES_CTR_192 (0x00180208U)
#define HSM_AES_CTR_256 (0x00200208U)
#define HSM_AES_XTS_128 (0x00100308U)
#define HSM_AES_XTS_256 (0x00200308U)
#define HSM_AES_CCM_128 (0x00101008U)
#define HSM_AES_CCM_192 (0x00181008U)
#define HSM_AES_CCM_256 (0x00201008U)
#define HSM_AES_GCM_128 (0x00101108U)
#define HSM_AES_GCM_192 (0x00181108U)
#define HSM_AES_GCM_256 (0x00201108U)

/* HSM OID SM4 */
#define HSM_OID_SM4_ENCRYPT (0x00000000U)
#define HSM_OID_SM4_DECRYPT (0x01000000U)
#define HSM_OID_SM4_ECB_128 (0x00100008U)
#define HSM_OID_SM4_CBC_128 (0x00100108U)
// clang-format on

typedef struct HSM_Param
{
	MboxMessage_t rx;
	uint32 mbox_received;
} HSMParam_t;

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/
uint32 HSM_SetKey(uint32 uiReq, uint32 uiAddr, uint32 uiDataSize, uint32 uiKeyIndex);
uint32 HSM_SetModN(uint32 uiReq, uint32 uiAddr, uint32 uiDataSize, uint32 uiKeyIndex);
uint32 HSM_RunAes(
	uint32 uiReq, uint32 uiObjId, uint8 *pucKey, uint32 uiKeySize, uint8 *pucIv, uint32 uiIvSize,
	uint32 uiCntSize, uint8 *pucTag, uint32 uiTagSize, uint8 *pucAad, uint32 uiAadSize,
	uint8 *pucSrcAddr, uint32 uiSrcSize, uint8 *pucDstAddr, uint32 uiDstSize);
uint32 HSM_RunAesByKt(
	uint32 uiReq, uint32 uiObjId, uint32 uiKeyIndex, uint8 *pucIv, uint32 uiIvSize,
	uint32 uiCntSize, uint8 *ucTag, uint32 uiTagSize, uint8 *ucAad, uint32 uiAadSize,
	uint8 *pucSrcAddr, uint32 uiSrcSize, uint8 *pucDstAddr, uint32 uiDstSize);
uint32 HSM_RunMac(
	uint32 uiReq, uint32 uiObjId, uint8 *pucKey, uint32 uiKeySize, uint8 *pucSrcAddr,
	uint32 uiSrcSize, uint8 *pucMacAddr, uint32 uiMacSize);
uint32 HSM_GenMacByKt(
	uint32 uiReq, uint32 uiObjId, uint32 uiKeyIndex, uint8 *pucSrcAddr, uint32 uiSrcSize,
	uint8 *pucMacAddr, uint32 uiMacSize);
uint32 HSM_GenHash(
	uint32 uiReq, uint32 uiObjId, uint8 *pucSrcAddr, uint32 uiSrcSize, uint8 *pucDig,
	uint32 uiDigSize);
uint32 HSM_RunEcdsa(
	uint32 uiReq, uint32 uiObjId, uint8 *pucKey, uint32 uiKeySize, uint8 *pucDig, uint32 uiDigSize,
	uint8 *pucSig, uint32 uiSigSize);
uint32 HSM_RunEcdsaByKt(
	uint32 uiReq, uint32 uiObjId, uint32 uiKeyIndex, uint8 *pucDig, uint32 uiDigSize, uint8 *pucSig,
	uint32 uiSigSize);
uint32 HSM_RunEcdhPhaseI(
	uint32 uiReq, uint32 uiObjId, uint32_t uiKeyType, uint8 *priKey, uint32 uiPrikeySize,
	uint8 *pubKey, uint32 uiPubkeySize);
uint32 HSM_RunEcdhPhaseII(
	uint32 uiReq, uint32 uiObjId, uint32_t uiKeyType, uint8 *priKey, uint32 uiPrikeySize,
	uint8 *pubKey, uint32 uiPubkeySize, uint8 *secKey, uint32 uiSeckeySize);
uint32 HSM_RunEcdhComputePubkey(
	uint32 uiReq, uint32 uiObjId, uint32_t uiKeyType, uint8 *priKey, uint32 uiPrikeySize,
	uint8 *pubKey, uint32 uiPubkeySize);
uint32 HSM_RunRsaes(
	uint32 uiReq, uint32 uiObjId, uint8 *pucModN, uint32 uiModNSize, uint8 *pucKey,
	uint32 uiKeySize, uint8 *pucSrc, uint32 uiSrcSize, uint8 *pucDst, uint32 *puiDstSize,
	uint8 *pucLabel, uint32 uiLabelSize);
uint32 HSM_RunRsaesByKt(
	uint32 uiReq, uint32 uiObjId, uint32 uiKeyIndex, uint8 *pucSrc, uint32 uiSrcSize, uint8 *pucDst,
	uint32 *puiDstSize, uint8 *pucLabel, uint32 uiLabelSize);
uint32 HSM_RunRsa(
	uint32 uiReq, uint32 uiObjId, uint8 *pucModN, uint32 uiModNSize, uint8 *pucKey,
	uint32 uiKeySize, uint8 *pucDig, uint32 uiDigSize, uint8 *pucSig, uint32 uiSigSize);
uint32 HSM_RunRsaByKt(
	uint32 uiReq, uint32 uiObjId, uint32 uiKeyIndex, uint8 *pucDig, uint32 uiDigSize, uint8 *pucSig,
	uint32 uiSigSize);
uint32 HSM_Write(uint32 uiReq, uint32 uiAddr, uint8 *pucBuf, uint32 uiBufSize);
uint32 HSM_GetRand(uint32 uiReq, uint32 *pucRng, uint32 uiRngSize);
uint32 HSM_GetVersion(uint32 uiReq, uint32 *uiX, uint32 *uiY, uint32 *uiZ);

void HSM_Mbox_TxIrq(void);
void HSM_Mbox_RxIrq(void);
uint32 HSM_Init(void);
void HSM_DeInit(void);

#endif /* HSM_MANAGER_HEADER */
