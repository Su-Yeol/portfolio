/*
***************************************************************************************************
*
*   FileName : hsm_manager.c
*
*   Copyright (c) Telechips Inc.
*
*   Description : HSM Mannger
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/
#if 0
#define NDEBUG
#endif
#define TLOG_LEVEL (TLOG_DEBUG)
#include "hsm_log.h"

#include <app_cfg.h>
#include <sal_internal.h>
#include <string.h>
#include <stdlib.h>

#include <debug.h>

#include "hsm_manager.h"
#include "mbox.h"
#include "nvic.h"
#include "bsp.h"

/*
***************************************************************************************************
*                                            DEFINITIONS
***************************************************************************************************
*/
#define HSM_REQUIRED_VER_X (0u)
#define HSM_REQUIRED_VER_Y (0u)
#define HSM_REQUIRED_VER_Z (3u)

static HSMParam_t HSM_Param = {0};

/**************************************************************************************************
 *                                           INTERNAL FUNCTION
 ***************************************************************************************************/

/**************************************************************************************************
 * @name                                          HSM_Mbox_SendRecv
 *
 * @brief Communication MCU and HSM usign mailbox
 *
 * @param Message:         Pointer to the transfer buffer to HSM . (MboxMessage_t *)
 *
 * @return uint32
 *
 * @note
 *
 ***************************************************************************************************/
static uint32 HSM_MBOX_SendRecv(MboxMessage_t *Message)
{
	uint32 ret = TCCHSM_SUCCESS;
	SALRetCode_t sal_ret = SAL_RET_FAILED;
	uint32 uiTimeout = 0;

	(void)MBOX_EnableInterrupt(MBOX_CH_HSM_GP, MBOX_CFG_IEN_WRITE);
	(void)MBOX_EnableInterrupt(MBOX_CH_HSM_GP, MBOX_CFG_IEN_READ);
	(void)MBOX_FlushFIFO(MBOX_CH_HSM_GP);

	// Init condition to wait
	SAL_MemSet(&HSM_Param, 0, sizeof(HSM_Param));

	sal_ret = MBOX_SendMessage(MBOX_CH_HSM_GP, Message);
	if (sal_ret != SAL_RET_SUCCESS) {
		ELOG("MBOX SendMessage Failed %d\n", sal_ret);
		ret = TCCHSM_ERR;
		goto out;
	}
	// wait event time out
	while (HSM_Param.mbox_received != 1) {
		uiTimeout++;
		if (uiTimeout >= 300000000) {
			ELOG("HSM Mbox Communication timeout\n");
			ret = TCCHSM_ERR_INVALID_STATE;
			goto out;
		}
	}

	/* Copy received Data from HSM */
	sal_ret = SAL_MemCopy(Message, &HSM_Param.rx, sizeof(MboxMessage_t));
	if (sal_ret != SAL_RET_SUCCESS) {
		ret = TCCHSM_ERR;
		ELOG("SAL_MemCopy is Failed\n");
		goto out;
	}

out:
	return ret;
}

/**************************************************************************************************
 *                                          EXTERNAL FUNCTION
 ***************************************************************************************************/

uint32 HSM_SetKey(uint32 uiReq, uint32 uiAddr, uint32 uiDataSize, uint32 uiKeyIndex)
{
	MboxMessage_t Message = {0};
	uint32 idx = 0;
	uint32 ret = TCCHSM_ERR;

	/* Set cmd FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0;                              // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0;                              // Not used
	Message.Cmd[6] = 0;                              // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"

	/* Set data FIFO */
	Message.Data[idx] = uiAddr;
	idx++;
	Message.Data[idx] = uiDataSize;
	idx++;
	Message.Data[idx] = uiKeyIndex;
	idx++;

	Message.Cmd[4] = (idx * sizeof(uint32)); // data size

	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	ret = Message.Data[0];

out:
	return ret;
}

uint32 HSM_SetModN(uint32 uiReq, uint32 uiAddr, uint32 uiDataSize, uint32 uiKeyIndex)
{
	MboxMessage_t Message = {0};
	uint32 idx = 0;
	uint32 ret = TCCHSM_ERR;

	/* Set cmd FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0;                              // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0;                              // Not used
	Message.Cmd[6] = 0;                              // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"

	/* Set data FIFO */
	Message.Data[idx] = uiAddr;
	idx++;
	Message.Data[idx] = uiDataSize;
	idx++;
	Message.Data[idx] = uiKeyIndex;
	idx++;

	Message.Cmd[4] = (idx * sizeof(uint32)); // data size

	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	ret = Message.Data[0];

out:
	return ret;
}

/**************************************************************************************************
* @name                                          HSM_RunAes
*
* @brief AES Operation

* @param         (void)
*
* @return uint32
*
* @note
*
***************************************************************************************************/
uint32 HSM_RunAes(
	uint32 uiReq, uint32 uiObjId, uint8 *pucKey, uint32 uiKeySize, uint8 *pucIv, uint32 uiIvSize,
	uint32 uiCntSize, uint8 *pucTag, uint32 uiTagSize, uint8 *pucAad, uint32 uiAadSize,
	uint8 *pucSrcAddr, uint32 uiSrcSize, uint8 *pucDstAddr, uint32 uiDstSize)
{
	MboxMessage_t Message = {0};
	// uint32 dataSize = 0;
	uint32 encType = 0;
	uint32 opMode = 0;
	uint32 aesType = 0;
	uint32 idx = 0;
	uint32 ret = TCCHSM_ERR;
	uint32 MessageSize = 0;

	/* Check Mbox Message size  */
	if ((uiKeySize > TCC_HSM_AES_KEY_SIZE) || (uiIvSize > TCC_HSM_AES_IV_SIZE)
		|| (uiTagSize > TCC_HSM_AES_TAG_SIZE) || (uiAadSize > TCC_HSM_AES_AAD_SIZE)
		|| (uiDstSize > HSM_MBOX_MSG_MAXSIZE) || (uiSrcSize > TCC_HSM_SRC_SIZE)) {
		ELOG("Size Can't exceed %d\n", HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}
	MessageSize =
		((8u * sizeof(uint32)) + uiKeySize + uiIvSize + uiTagSize + uiAadSize + uiSrcSize);
	if (MessageSize > HSM_MBOX_MSG_MAXSIZE) {
		ELOG("Mbox Message Size(%d) Can't exceed %d\n", MessageSize, HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}

	/* Set cmd FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0u;                             // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0u;                             // Not used
	Message.Cmd[6] = 0u;                             // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"
	
	encType = (uiObjId & 0x01000000u);
	opMode = (uiObjId & 0xF0000000u);
	aesType = (uiObjId & 0x00FFFFFFu);

	/* Set data FIFO */
	Message.Data[idx] = opMode; // opMode, use SingleCall
	idx++;
	Message.Data[idx] = uiObjId;
	idx++;
	Message.Data[idx] = HSM_NONE_DMA;
	idx++;
	
	if((opMode | OID_OPMODE_INIT) == OID_OPMODE_INIT){
		Message.Data[idx] = uiKeySize;
		idx++;
		if ((pucKey != NULL) && (uiKeySize > 0u)) {
			SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucKey, uiKeySize);
			idx += (uiKeySize + 3u) / sizeof(uint32);
		}
		Message.Data[idx] = uiIvSize;
		idx++;
		if ((pucIv != NULL) && (uiIvSize > 0u)) {
			Message.Data[idx] = uiCntSize;
			idx++;
			SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucIv, uiIvSize);
			idx += (uiIvSize + 3u) / sizeof(uint32);
		}
	
		if (uiReq == REQ_HSM_RUN_AES) {
			Message.Data[idx] = uiAadSize;
			idx++;
			if (uiAadSize > 0u) {
				SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucAad, uiAadSize);
				idx += (uiAadSize + 3u) / sizeof(uint32);
			}
		}
	}

	if((((opMode | OID_OPMODE_INIT) == OID_OPMODE_INIT) ||
	   ((opMode | OID_OPMODE_FINAL) == OID_OPMODE_FINAL)) && 
	   (uiReq == REQ_HSM_RUN_AES)) {
		Message.Data[idx] = uiTagSize;
		idx++;
	}

	if((((opMode | OID_OPMODE_FINAL) == OID_OPMODE_FINAL)) && 
	   (uiReq == REQ_HSM_RUN_AES)) {
		if ((uiTagSize > 0u) && (encType == HSM_AES_DECRYPT)) {
			SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucTag, uiTagSize);
			idx += (uiTagSize + 3u) / sizeof(uint32);
		}
	}

	Message.Data[idx] = uiSrcSize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucSrcAddr, uiSrcSize);
	idx += (uiSrcSize + 3u) / sizeof(uint32);
	Message.Data[idx] = uiDstSize;
	idx++;

	Message.Cmd[4] = (idx * sizeof(uint32)); // data size

	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	ret = Message.Data[0];

	if (ret != TCCHSM_SUCCESS) {
		ELOG("Error result Value(0x%x)\n", Message.Data[0]);
		goto out;
	}

	/* UPDATE */
    if ((opMode | OID_OPMODE_UPDATE) == OID_OPMODE_UPDATE) {
        SAL_MemCopy((void *)pucDstAddr, (const void *)&Message.Data[2], uiDstSize);
    }

    /* FINAL (Type: only AEAD) */
    if (((opMode | OID_OPMODE_FINAL) == OID_OPMODE_FINAL) &&
        ((aesType & 0x00001000u) != 0u) && (encType == HSM_AES_ENCRYPT)) {
        SAL_MemCopy(
            (void *)pucTag, (const void *)&Message.Data[2u + (uiDstSize / sizeof(uint32))], uiTagSize);
    }

out:
    return ret;
}

uint32 HSM_RunAesByKt(
	uint32 uiReq, uint32 uiObjId, uint32 uiKeyIndex, uint8 *pucIv, uint32 uiIvSize,
	uint32 uiCntSize, uint8 *ucTag, uint32 uiTagSize, uint8 *ucAad, uint32 uiAadSize,
	uint8 *pucSrcAddr, uint32 uiSrcSize, uint8 *pucDstAddr, uint32 uiDstSize)
{
	MboxMessage_t Message = {0};
	uint32 dataSize = 0;
	uint32 encType = 0;
	uint32 idx = 0;
	uint32 MessageSize = 0;
	uint32 ret = TCCHSM_ERR;

	/* Check Mbox Message size  */
	if ((uiIvSize > TCC_HSM_AES_IV_SIZE) || (uiTagSize > TCC_HSM_AES_TAG_SIZE)
		|| (uiAadSize > TCC_HSM_AES_AAD_SIZE) || (uiDstSize > HSM_MBOX_MSG_MAXSIZE)
		|| (uiSrcSize > TCC_HSM_SRC_SIZE)) {
		ELOG("Size Can't exceed %d\n", HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}
	MessageSize = ((8u * sizeof(uint32)) + uiIvSize + uiTagSize + uiAadSize + uiSrcSize);
	if (MessageSize > HSM_MBOX_MSG_MAXSIZE) {
		ELOG("Mbox Message Size(%d) Can't exceed %d\n", MessageSize, HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}

	/* Set cmd FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0u;                             // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0u;                             // Not used
	Message.Cmd[6] = 0u;                             // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"

	encType = (uiObjId & 0x01000000u);

	/* Set data FIFO */
	Message.Data[idx] = uiObjId;
	idx++;
	Message.Data[idx] = HSM_NONE_DMA;
	idx++;
	Message.Data[idx] = uiKeyIndex;
	idx++;

	Message.Data[idx] = uiIvSize;
	idx++;
	if ((pucIv != NULL) && (uiIvSize > 0u)) {
		Message.Data[idx] = uiCntSize;
		idx++;
		SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucIv, uiIvSize);
		idx += (uiIvSize + 3u) / sizeof(uint32);
	}

	if (uiReq == REQ_HSM_RUN_AES_BY_KT) {
		Message.Data[idx] = uiTagSize;
		idx++;
		if ((uiTagSize > 0u) && (encType == HSM_AES_DECRYPT)) {
			SAL_MemCopy((void *)&Message.Data[idx], (const void *)ucTag, uiTagSize);
			idx += (uiTagSize + 3u) / sizeof(uint32);
		}

		Message.Data[idx] = uiAadSize;
		idx++;
		if (uiAadSize > 0u) {
			SAL_MemCopy((void *)&Message.Data[idx], (const void *)ucAad, uiAadSize);
			idx += (uiAadSize + 3u) / sizeof(uint32);
		}
	}

	Message.Data[idx] = uiSrcSize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucSrcAddr, uiSrcSize);
	idx += (uiSrcSize + 3u) / sizeof(uint32);
	Message.Data[idx] = uiDstSize;
	idx++;

	Message.Cmd[4] = idx * sizeof(uint32); // data size

	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	ret = Message.Data[0];
	if (ret != TCCHSM_SUCCESS) {
		ELOG("Error result Value(0x%x)\n", ret);
		goto out;
	}

	if (encType == HSM_AES_ENCRYPT) {
		dataSize = uiDstSize + uiTagSize;
	} else {
		dataSize = uiDstSize;
	}

	if (Message.Data[1] != dataSize) {
		ELOG("wrong uiDstSize(%d)\n", Message.Data[1]);
		ret = TCCHSM_ERR_INVALID_STATE;
		goto out;
	}

	SAL_MemCopy((void *)pucDstAddr, (const void *)&Message.Data[2], uiDstSize);

	if ((uiTagSize > 0U) && (uiReq == REQ_HSM_RUN_AES_BY_KT) && (encType == HSM_AES_ENCRYPT)) {
		SAL_MemCopy(
			(void *)ucTag, (const void *)&Message.Data[2u + (uiDstSize / sizeof(uint32))],
			uiTagSize);
	}

out:
	return ret;
}

/**************************************************************************************************
 * @name                                      HSM_GenMac
 *
 * @brief Generate MAC
 *
 * @param cmd    HSM Command Value to select CMAC and HMAC
 * @return       uint32
 *
 * @note
 *
 ***************************************************************************************************/
uint32 HSM_RunMac(
	uint32 uiReq, uint32 uiObjId, uint8 *pucKey, uint32 uiKeySize, uint8 *pucSrcAddr,
	uint32 uiSrcSize, uint8 *pucMacAddr, uint32 uiMacSize)
{
	MboxMessage_t Message = {0};
	uint32 idx = 0;
	uint32 opMode = 0;
	uint32 MessageSize = 0;
	uint32 ret = TCCHSM_ERR;

	/* Check Mbox Message size  */
	if ((uiKeySize > TCC_HSM_MAC_KEY_SIZE) || (uiSrcSize > TCC_HSM_SRC_SIZE)
		|| (uiMacSize > TCC_HSM_MAC_MSG_SIZE)) {
		ELOG("Size Can't exceed %d\n", HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}
	MessageSize = ((5u * sizeof(uint32)) + uiKeySize + uiSrcSize + uiMacSize);
	if (MessageSize > HSM_MBOX_MSG_MAXSIZE) {
		ELOG("Mbox Message Size(%d) Can't exceed %d\n", MessageSize, HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}

	/* Set cmd FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0u;                             // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0u;                             // Not used
	Message.Cmd[6] = 0u;                             // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"

	opMode = (uiObjId & 0xF0000000u);
	Message.Data[idx] = opMode;
	idx++;
	Message.Data[idx] = (uiObjId & 0x0FFFFFFFu);
	idx++;
	Message.Data[idx] = HSM_NONE_DMA;
	idx++;
	if((opMode | OID_OPMODE_INIT) == OID_OPMODE_INIT) {
		Message.Data[idx] = uiKeySize;
		idx++;
		if ((pucKey != NULL) && (uiKeySize > 0u)) {
			SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucKey, uiKeySize);
			idx += (uiKeySize + 3U) / sizeof(uint32);
		}
	}
	Message.Data[idx] = uiSrcSize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucSrcAddr, uiSrcSize);
	idx += (uiSrcSize + 3u) / sizeof(uint32);
	Message.Data[idx] = uiMacSize;
	idx++;
	if ((uiReq == REQ_HSM_VERIFY_CMAC) && ((opMode |OID_OPMODE_FINAL) == OID_OPMODE_FINAL)) {
		SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucMacAddr, uiMacSize);
		idx += (uiMacSize + 3u) / sizeof(uint32);
	}

	Message.Cmd[4] = idx * sizeof(uint32); // data size

	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	ret = Message.Data[0];
	if (ret != TCCHSM_SUCCESS) {
		ELOG("Error result value(0x%x)\n", ret);
		goto out;
	}

	if ((uiReq != REQ_HSM_VERIFY_CMAC) && 
		((opMode | OID_OPMODE_FINAL) == OID_OPMODE_FINAL)) {
		if (Message.Data[1] == uiMacSize) {
			SAL_MemCopy((void *)pucMacAddr, (const void *)&Message.Data[2], uiMacSize);
		} else {
			ELOG("wrong uiDstSize(%d)\n", Message.Data[1]);
			ret = TCCHSM_ERR_INVALID_STATE;
			goto out;
		}
	}

out:
	return ret;
}

uint32 HSM_GenMacByKt(
	uint32 uiReq, uint32 uiObjId, uint32 uiKeyIndex, uint8 *pucSrcAddr, uint32 uiSrcSize,
	uint8 *pucMacAddr, uint32 uiMacSize)
{
	MboxMessage_t Message = {0};
	uint32 idx = 0;
	uint32 MessageSize = 0;
	uint32 ret = TCCHSM_ERR;

	/* Set cmd FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0u;                             // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0u;                             // Not used
	Message.Cmd[6] = 0u;                             // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"

	/* Check Mbox Message size  */
	if ((uiSrcSize > TCC_HSM_SRC_SIZE) || (uiMacSize > TCC_HSM_MAC_MSG_SIZE)) {
		ELOG("Size Can't exceed %d\n", HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}
	MessageSize = ((5u * sizeof(uint32)) + uiSrcSize + uiMacSize);
	if (MessageSize > HSM_MBOX_MSG_MAXSIZE) {
		ELOG("Mbox Message Size(%d) Can't exceed %d\n", MessageSize, HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}

	/* Set data FIFO */
	if ((uiReq == REQ_HSM_GEN_HMAC_BY_KT) || (uiReq == REQ_HSM_GEN_SM3_HMAC_BY_KT)) {
		Message.Data[idx] = uiObjId;
		idx++;
	}
	Message.Data[idx] = HSM_NONE_DMA;
	idx++;
	Message.Data[idx] = uiKeyIndex;
	idx++;

	Message.Data[idx] = uiSrcSize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucSrcAddr, uiSrcSize);
	idx += ((uiSrcSize + 3u) / sizeof(uint32));
	Message.Data[idx] = uiMacSize;
	idx++;
	if (uiReq == REQ_HSM_VERIFY_CMAC_BY_KT) {
		SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucMacAddr, uiMacSize);
		idx += (uiMacSize + 3u) / sizeof(uint32);
	}

	Message.Cmd[4] = idx * sizeof(uint32); // data size

	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	ret = Message.Data[0];
	if (ret != TCCHSM_SUCCESS) {
		ELOG("Error result value(0x%x)\n", ret);
		goto out;
	}

	if (uiReq != REQ_HSM_VERIFY_CMAC_BY_KT) {
		if (Message.Data[1] == uiMacSize) {
			SAL_MemCopy((void *)pucMacAddr, (const void *)&Message.Data[2], uiMacSize);
		} else {
			ELOG("wrong uiDstSize(%d)\n", Message.Data[1]);
			ret = TCCHSM_ERR_INVALID_STATE;
			goto out;
		}
	}

out:
	return ret;
}

/**************************************************************************************************
 * @name                                      HSM_GenHash
 *
 * @brief  Generate Hash
 *
 * @param
 * @return       uint32
 *
 * @note
 *
 ***************************************************************************************************/
uint32 HSM_GenHash(
	uint32 uiReq, uint32 uiObjId, uint8 *pucSrcAddr, uint32 uiSrcSize, uint8 *pucDig,
	uint32 uiDigSize)
{
	MboxMessage_t Message = {0};
	uint32 idx = 0;
	uint32 opMode = 0;
	uint32 MessageSize = 0;
	uint32 ret = TCCHSM_ERR;

	/* Check Mbox Message size  */
	if ((uiSrcSize > TCC_HSM_SRC_SIZE) || (uiDigSize > TCC_HSM_MAC_MSG_SIZE)) {
		ELOG("Size Can't exceed %d\n", HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}
	MessageSize = ((4u * sizeof(uint32)) + uiSrcSize);
	if (MessageSize > HSM_MBOX_MSG_MAXSIZE) {
		ELOG("Mbox Message Size(%d) Can't exceed %d\n", MessageSize, HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}

	/* Set cmd FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0u;                             // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0u;                             // Not used
	Message.Cmd[6] = 0u;                             // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"

	opMode = (uiObjId & 0xF0000000u);
	/* Set data FIFO */
	Message.Data[idx] = opMode;
	idx++;
	Message.Data[idx] = (uiObjId & 0x0FFFFFFFu);
	idx++;
	Message.Data[idx] = HSM_NONE_DMA;
	idx++;

	Message.Data[idx] = uiSrcSize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucSrcAddr, uiSrcSize);
	idx += ((uiSrcSize + 3u) / sizeof(uint32));
	Message.Data[idx] = uiDigSize;
	idx++;

	Message.Cmd[4] = idx * sizeof(uint32); // data size
	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	ret = Message.Data[0];
	if (ret != TCCHSM_SUCCESS) {
		ELOG("Error result value(0x%x)\n", ret);
		goto out;
	}

	if((opMode | OID_OPMODE_FINAL) == OID_OPMODE_FINAL) {
		if (Message.Data[1] == uiDigSize) {
			SAL_MemCopy((void *)pucDig, (const void *)&Message.Data[2], uiDigSize);
		} else {
			ELOG("wrong uiDstSize(%d)\n", Message.Data[1]);
			ret = TCCHSM_ERR_INVALID_STATE;
			goto out;
		}
	}

out:
	return ret;
}

/**************************************************************************************************
 * @name                                    HSM_RunECDSA
 *
 * @brief ECDSA Sign & Verify
 *
 * @param        (void)
 * @return       uint32
 *
 * @note
 *
 ***************************************************************************************************/
uint32 HSM_RunEcdsa(
	uint32 uiReq, uint32 uiObjId, uint8 *pucKey, uint32 uiKeySize, uint8 *pucDig, uint32 uiDigSize,
	uint8 *pucSig, uint32 uiSigSize)
{
	MboxMessage_t Message = {0};
	uint32 idx = 0;
	uint32 MessageSize = 0;
	uint32 ret = TCCHSM_ERR;

	/* Check Mbox Message size  */
	if ((uiKeySize > TCC_HSM_ECDSA_P521_KEY_SIZE) || (uiDigSize > TCC_HSM_ECDSA_DIGEST_SIZE)
		|| (uiSigSize > TCC_HSM_ECDSA_SIGN_SIZE)) {
		ELOG("Size Can't exceed %d\n", HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}
	MessageSize = ((4u * sizeof(uint32)) + uiKeySize + uiDigSize + uiSigSize);
	if (MessageSize > HSM_MBOX_MSG_MAXSIZE) {
		ELOG("Mbox Message Size(%d) Can't exceed %d\n", MessageSize, HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}

	/* Set cmd FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0u;                             // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0u;                             // Not used
	Message.Cmd[6] = 0u;                             // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"

	/* Set data FIFO */
	Message.Data[idx] = uiObjId;
	idx++;
	Message.Data[idx] = uiKeySize;
	idx++;
	if ((pucKey != NULL) && (uiKeySize > 0u)) {
		SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucKey, uiKeySize);
		idx += (uiKeySize + 3u) / sizeof(uint32);
	}

	Message.Data[idx] = uiDigSize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucDig, uiDigSize);
	idx += (uiDigSize + 3u) / sizeof(uint32);

	Message.Data[idx] = uiSigSize;
	idx++;
	if (uiReq == REQ_HSM_RUN_ECDSA_VERIFY) {
		SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucSig, uiSigSize);
		idx += (uiSigSize + 3u) / sizeof(uint32);
	}

	Message.Cmd[4] = idx * sizeof(uint32); // data size
	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	ret = Message.Data[0];
	if (ret != TCCHSM_SUCCESS) {
		ELOG("Error result value(0x%x)\n", ret);
		goto out;
	}

	if (uiReq == REQ_HSM_RUN_ECDSA_SIGN) {
		if (Message.Data[1] == uiSigSize) {
			SAL_MemCopy((void *)pucSig, (const void *)&Message.Data[2], uiSigSize);
		} else {
			ELOG("wrong uiDstSize(%d)\n", Message.Data[1]);
			ret = TCCHSM_ERR_INVALID_STATE;
			goto out;
		}
	}

out:
	return ret;
}

uint32 HSM_RunEcdsaByKt(
	uint32 uiReq, uint32 uiObjId, uint32 uiKeyIndex, uint8 *pucDig, uint32 uiDigSize, uint8 *pucSig,
	uint32 uiSigSize)
{
	MboxMessage_t Message = {0};
	uint32 idx = 0;
	uint32 MessageSize = 0;
	uint32 ret = TCCHSM_ERR;

	/* Check Mbox Message size  */
	if ((uiDigSize > TCC_HSM_ECDSA_DIGEST_SIZE) || (uiSigSize > TCC_HSM_ECDSA_SIGN_SIZE)) {
		ELOG("Size Can't exceed %d\n", HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}
	MessageSize = ((4u * sizeof(uint32)) + uiDigSize + uiSigSize);
	if (MessageSize > HSM_MBOX_MSG_MAXSIZE) {
		ELOG("Mbox Message Size(%d) Can't exceed %d\n", MessageSize, HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}

	/* Set cmd FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0u;                             // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0u;                             // Not used
	Message.Cmd[6] = 0u;                             // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"

	/* Set data FIFO */
	Message.Data[idx] = uiObjId;
	idx++;

	Message.Data[idx] = uiKeyIndex;
	idx++;

	Message.Data[idx] = uiDigSize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucDig, uiDigSize);
	idx += (uiDigSize + 3u) / sizeof(uint32);

	Message.Data[idx] = uiSigSize;
	idx++;
	if (uiReq == REQ_HSM_RUN_ECDSA_VERIFY_BY_KT) {
		SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucSig, uiSigSize);
		idx += (uiSigSize + 3u) / sizeof(uint32);
	}

	Message.Cmd[4] = idx * sizeof(uint32); // data size

	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	ret = Message.Data[0];
	if (ret != TCCHSM_SUCCESS) {
		ELOG("Error result value(0x%x)\n", ret);
		goto out;
	}

	if (uiReq == REQ_HSM_RUN_ECDSA_SIGN_BY_KT) {
		if (Message.Data[1] == uiSigSize) {
			SAL_MemCopy((void *)pucSig, (const void *)&Message.Data[2], uiSigSize);
		} else {
			ELOG("wrong uiDstSize(%d)\n", Message.Data[1]);
			ret = TCCHSM_ERR_INVALID_STATE;
			goto out;
		}
	}

out:
	return ret;
}

uint32 HSM_RunEcdhPhaseI(
	uint32 uiReq, uint32 uiObjId, uint32_t uiKeyType, uint8 *priKey, uint32 uiPrikeySize,
	uint8 *pubKey, uint32 uiPubkeySize)
{
	MboxMessage_t Message = {0};
	uint32 idx = 0;
	uint32 MessageSize = 0;
	uint32 ret = TCCHSM_ERR;

	/* Check Mbox Message size  */
	if ((uiPrikeySize > TCC_HSM_ECDSA_P521_KEY_SIZE) ||
		uiPubkeySize > (TCC_HSM_ECDSA_P521_KEY_SIZE * 2)) {
		ELOG("Size Can't exceed %d\n", HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}
	MessageSize = ((4u * sizeof(uint32)) + uiPrikeySize + uiPubkeySize);
	if (MessageSize > HSM_MBOX_MSG_MAXSIZE) {
		ELOG("Mbox Message Size(%d) Can't exceed %d\n", MessageSize, HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}

	/* Set cmd FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0u;                             // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0u;                             // Not used
	Message.Cmd[6] = 0u;                             // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"

	/* Set data FIFO */
	Message.Data[idx] = uiObjId;
	idx++;
	Message.Data[idx] = uiKeyType;
	idx++;
	Message.Data[idx] = uiPrikeySize;
	idx++;
	Message.Data[idx] = uiPubkeySize;
	idx++;

	Message.Cmd[4] = idx * sizeof(uint32); // data size
	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	idx = 0;
	ret = Message.Data[idx];
	if (ret != TCCHSM_SUCCESS) {
		ELOG("Error result value(0x%x)\n", ret);
		goto out;
	}
	idx++;

	if (Message.Data[idx] == (uiPrikeySize + uiPubkeySize)) {
		idx++;
		SAL_MemCopy((void *)priKey, (const void *)&Message.Data[idx], uiPrikeySize);
		idx += ((uiPrikeySize + 3U) / sizeof(uint32));
		SAL_MemCopy((void *)pubKey, (const void *)&Message.Data[idx], uiPubkeySize);
		idx += ((uiPubkeySize + 3U) / sizeof(uint32));
	} else {
		ELOG("wrong uiKeySize(%d)\n", Message.Data[idx]);
		ret = TCCHSM_ERR_INVALID_STATE;
		goto out;
	}

out:
	return ret;
}

uint32 HSM_RunEcdhPhaseII(
	uint32 uiReq, uint32 uiObjId, uint32_t uiKeyType, uint8 *priKey, uint32 uiPrikeySize,
	uint8 *pubKey, uint32 uiPubkeySize, uint8 *secKey, uint32 uiSeckeySize)
{
	MboxMessage_t Message = {0};
	uint32 idx = 0;
	uint32 MessageSize = 0;
	uint32 ret = TCCHSM_ERR;

	/* Check Mbox Message size  */
	if ((uiPrikeySize > TCC_HSM_ECDSA_P521_KEY_SIZE) ||
		uiPubkeySize > (TCC_HSM_ECDSA_P521_KEY_SIZE * 2)) {
		ELOG("Size Can't exceed %d\n", HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}
	MessageSize = ((4u * sizeof(uint32)) + uiPrikeySize + uiPubkeySize);
	if (MessageSize > HSM_MBOX_MSG_MAXSIZE) {
		ELOG("Mbox Message Size(%d) Can't exceed %d\n", MessageSize, HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}

	/* Set cmd FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0u;                             // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0u;                             // Not used
	Message.Cmd[6] = 0u;                             // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"

	/* Set data FIFO */
	Message.Data[idx] = uiObjId;
	idx++;
	Message.Data[idx] = uiKeyType;
	idx++;
	Message.Data[idx] = uiPrikeySize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)priKey, uiPrikeySize);
	idx += (uiPrikeySize + 3U) / sizeof(uint32);
	Message.Data[idx] = uiPubkeySize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)pubKey, uiPubkeySize);
	idx += (uiPubkeySize + 3U) / sizeof(uint32);
	Message.Data[idx] = uiSeckeySize;
	idx++;

	Message.Cmd[4] = idx * sizeof(uint32); // data size
	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	idx = 0;
	ret = Message.Data[idx];
	if (ret != TCCHSM_SUCCESS) {
		ELOG("Error result value(0x%x)\n", ret);
		goto out;
	}
	idx++;

	if (Message.Data[idx] == uiSeckeySize) {
		idx++;
		SAL_MemCopy((void *)secKey, (const void *)&Message.Data[idx], uiSeckeySize);
		idx += ((uiSeckeySize + 3U) / sizeof(uint32));
	} else {
		ELOG("Wrong uisecKeySize(%d)\n", Message.Data[idx]);
		ret = TCCHSM_ERR_INVALID_STATE;
		goto out;
	}

out:
	return ret;
}

uint32 HSM_RunEcdhComputePubkey(
	uint32 uiReq, uint32 uiObjId, uint32_t uiKeyType, uint8 *priKey, uint32 uiPrikeySize,
	uint8 *pubKey, uint32 uiPubkeySize)
{

	MboxMessage_t Message = {0};
	uint32 idx = 0;
	uint32 MessageSize = 0;
	uint32 ret = TCCHSM_ERR;

	/* Check Mbox Message size  */
	if ((uiPrikeySize > TCC_HSM_ECDSA_P521_KEY_SIZE) ||
		uiPubkeySize > (TCC_HSM_ECDSA_P521_KEY_SIZE * 2)) {
		ELOG("Size Can't exceed %d\n", HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}
	MessageSize = ((4u * sizeof(uint32)) + uiPrikeySize + uiPubkeySize);
	if (MessageSize > HSM_MBOX_MSG_MAXSIZE) {
		ELOG("Mbox Message Size(%d) Can't exceed %d\n", MessageSize, HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}

	/* Set cmd FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0u;                             // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0u;                             // Not used
	Message.Cmd[6] = 0u;                             // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"

	/* Set data FIFO */
	Message.Data[idx] = uiObjId;
	idx++;
	Message.Data[idx] = uiKeyType;
	idx++;
	Message.Data[idx] = uiPrikeySize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)priKey, uiPrikeySize);
	idx += (uiPrikeySize + 3U) / sizeof(uint32);
	Message.Data[idx] = uiPubkeySize;
	idx++;

	Message.Cmd[4] = idx * sizeof(uint32); // data size
	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	idx = 0;
	ret = Message.Data[idx];
	if (ret != TCCHSM_SUCCESS) {
		ELOG("Error result value(0x%x)\n", ret);
		goto out;
	}
	idx++;

	if (Message.Data[idx] == uiPubkeySize) {
		idx++;
		SAL_MemCopy((void *)pubKey, (const void *)&Message.Data[idx], uiPubkeySize);
		idx += ((uiPubkeySize + 3U) / sizeof(uint32));
	} else {
		ELOG("wrong uiKeySize(%d)\n", Message.Data[idx]);
		ret = TCCHSM_ERR_INVALID_STATE;
		goto out;
	}

out:
	return ret;
}

uint32 HSM_RunRsaes(
	uint32 uiReq, uint32 uiObjId, uint8 *pucModN, uint32 uiModNSize, uint8 *pucKey,
	uint32 uiKeySize, uint8 *pucSrc, uint32 uiSrcSize, uint8 *pucDst, uint32 *puiDstSize,
	uint8 *pucLabel, uint32 uiLabelSize)
{
	MboxMessage_t Message = {0};
	uint32 idx = 0;
	uint32 MessageSize = 0;
	uint32 ret = TCCHSM_ERR;

	/* Check Mbox Message size  */
	if ((uiModNSize > TCC_HSM_RSA_MODN_SIZE) || (uiKeySize > TCC_HSM_RSA_MODN_SIZE)
		|| (uiSrcSize > TCC_HSM_RSA_MODN_SIZE) || (uiLabelSize > TCC_HSM_RSA_MODN_SIZE)) {
		ELOG("Size Can't exceed %d\n", HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}
	MessageSize = ((4u * sizeof(uint32)) + uiModNSize + uiKeySize + uiSrcSize + uiLabelSize);
	if (MessageSize > HSM_MBOX_MSG_MAXSIZE) {
		ELOG("Mbox Message Size(%d) Can't exceed %d\n", MessageSize, HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}

	/* Set cmd FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0u;                             // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0u;                             // Not used
	Message.Cmd[6] = 0u;                             // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"

	/* Set data FIFO */
	Message.Data[idx] = uiObjId;
	idx++;
	Message.Data[idx] = HSM_NONE_DMA;
	idx++;
	Message.Data[idx] = uiModNSize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucModN, uiModNSize);
	idx += (uiModNSize + 3u) / sizeof(uint32);

	Message.Data[idx] = uiKeySize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucKey, uiKeySize);
	idx += (uiKeySize + 3u) / sizeof(uint32);

	Message.Data[idx] = uiSrcSize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucSrc, uiSrcSize);
	idx += (uiSrcSize + 3u) / sizeof(uint32);

	if ((uiReq == REQ_HSM_RUN_RSAES_OAEP_ENC) || (uiReq == REQ_HSM_RUN_RSAES_OAEP_DEC)) {
		Message.Data[idx] = uiLabelSize;
		idx++;
		SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucLabel, uiLabelSize);
		idx += (uiLabelSize + 3u) / sizeof(uint32);
	}

	Message.Cmd[4] = idx * sizeof(uint32); // data size
	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	ret = Message.Data[0];
	if (ret != TCCHSM_SUCCESS) {
		ELOG("Error result value(0x%x)\n", ret);
		goto out;
	}

	*puiDstSize = Message.Data[1];
	// SAL_MemCopy((void *)pucDst, (const void *)&Message.Data[2], *puiDstSize);

out:
	return ret;
}

uint32 HSM_RunRsaesByKt(
	uint32 uiReq, uint32 uiObjId, uint32 uiKeyIndex, uint8 *pucSrc, uint32 uiSrcSize, uint8 *pucDst,
	uint32 *puiDstSize, uint8 *pucLabel, uint32 uiLabelSize)
{
	MboxMessage_t Message = {0};
	uint32 idx = 0;
	uint32 MessageSize = 0;
	uint32 ret = TCCHSM_ERR;

	/* Check Mbox Message size  */
	if ((uiSrcSize > TCC_HSM_RSA_MODN_SIZE) || (uiLabelSize > TCC_HSM_RSA_MODN_SIZE)) {
		ELOG("Size Can't exceed %d\n", HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}
	MessageSize = ((3u * sizeof(uint32)) + uiSrcSize + uiLabelSize);
	if (MessageSize > HSM_MBOX_MSG_MAXSIZE) {
		ELOG("Mbox Message Size(%d) Can't exceed %d\n", MessageSize, HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}

	/* Set cmd FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0u;                             // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0u;                             // Not used
	Message.Cmd[6] = 0u;                             // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"

	/* Set data FIFO */
	Message.Data[idx] = uiObjId;
	idx++;
	Message.Data[idx] = HSM_NONE_DMA;
	idx++;

	Message.Data[idx] = uiKeyIndex;
	idx++;

	Message.Data[idx] = uiSrcSize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucSrc, uiSrcSize);
	idx += (uiSrcSize + 3u) / sizeof(uint32);

	if ((uiReq == REQ_HSM_RUN_RSAES_OAEP_ENC_BY_KT)
		|| (uiReq == REQ_HSM_RUN_RSAES_OAEP_DEC_BY_KT)) {
		Message.Data[idx] = uiLabelSize;
		idx++;
		SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucLabel, uiLabelSize);
		idx += (uiLabelSize + 3u) / sizeof(uint32);
	}

	Message.Cmd[4] = idx * sizeof(uint32); // data size
	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	ret = Message.Data[0];
	if (ret != TCCHSM_SUCCESS) {
		ELOG("Error HAL_Read(%d)\n", ret);
		goto out;
	}

	*puiDstSize = Message.Data[1];
	// SAL_MemCopy((void *)pucDst, (const void *)&Message.Data[2], *puiDstSize);

out:
	return ret;
}
/**************************************************************************************************
 * @name                                     HSM_RunRsa
 *
 * @brief RSASSA Sign & Verify
 *
 * @param
 * @return       uint32
 *
 * @note
 *
 ***************************************************************************************************/
uint32 HSM_RunRsa(
	uint32 uiReq, uint32 uiObjId, uint8 *pucModN, uint32 uiModNSize, uint8 *pucKey,
	uint32 uiKeySize, uint8 *pucDig, uint32 uiDigSize, uint8 *pucSig, uint32 uiSigSize)
{
	MboxMessage_t Message = {0};
	uint32 idx = 0;
	uint32 MessageSize = 0;
	uint32 ret = TCCHSM_ERR;

	/* Check Mbox Message size  */
	if ((uiModNSize > TCC_HSM_RSA_MODN_SIZE) || (uiKeySize > TCC_HSM_RSA_MODN_SIZE)
		|| (uiDigSize > TCC_HSM_RSA_DIG_SIZE) || (uiSigSize > TCC_HSM_RSA_SIG_SIZE)) {
		ELOG("Size Can't exceed %d\n", HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}
	MessageSize = ((4u * sizeof(uint32)) + uiModNSize + uiKeySize + uiDigSize + uiSigSize);
	if (MessageSize > HSM_MBOX_MSG_MAXSIZE) {
		ELOG("Mbox Message Size(%d) Can't exceed %d\n", MessageSize, HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}

	/* Set cmd FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0u;                             // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0u;                             // Not used
	Message.Cmd[6] = 0u;                             // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"

	/* Set data FIFO */
	Message.Data[idx] = uiObjId;
	idx++;
	Message.Data[idx] = HSM_NONE_DMA;
	idx++;
	Message.Data[idx] = uiModNSize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucModN, uiModNSize);
	idx += (uiModNSize + 3u) / sizeof(uint32);

	Message.Data[idx] = uiKeySize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucKey, uiKeySize);
	idx += (uiKeySize + 3u) / sizeof(uint32);

	Message.Data[idx] = uiDigSize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucDig, uiDigSize);
	idx += (uiDigSize + 3u) / sizeof(uint32);

	Message.Data[idx] = uiSigSize;
	idx++;
	if ((uiReq == REQ_HSM_RUN_RSASSA_PKCS_VERIFY) || (uiReq == REQ_HSM_RUN_RSASSA_PSS_VERIFY)) {
		SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucSig, uiSigSize);
		idx += (uiSigSize + 3u) / sizeof(uint32);
	}

	Message.Cmd[4] = idx * sizeof(uint32); // data size
	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	ret = Message.Data[0];
	if (ret != TCCHSM_SUCCESS) {
		ELOG("Error result value(0x%x)\n", ret);
		goto out;
	}

	if ((uiReq == REQ_HSM_RUN_RSASSA_PKCS_SIGN) || (uiReq == REQ_HSM_RUN_RSASSA_PSS_SIGN)) {
		if (Message.Data[1] == uiSigSize) {
			SAL_MemCopy((void *)pucSig, (const void *)&Message.Data[2], uiSigSize);
		} else {
			ELOG("wrong uiSigSize(%d)\n", Message.Data[1]);
			ret = TCCHSM_ERR_INVALID_STATE;
			goto out;
		}
	}

out:
	return ret;
}

uint32 HSM_RunRsaByKt(
	uint32 uiReq, uint32 uiObjId, uint32 uiKeyIndex, uint8 *pucDig, uint32 uiDigSize, uint8 *pucSig,
	uint32 uiSigSize)
{
	MboxMessage_t Message = {0};
	uint32 idx = 0;
	uint32 MessageSize = 0;
	uint32 ret = TCCHSM_ERR;

	/* Check Mbox Message size  */
	if ((uiDigSize > TCC_HSM_RSA_DIG_SIZE) || (uiSigSize > TCC_HSM_RSA_SIG_SIZE)) {
		ELOG("Size Can't exceed %d\n", HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}
	MessageSize = ((3u * sizeof(uint32)) + uiDigSize + uiSigSize);
	if (MessageSize > HSM_MBOX_MSG_MAXSIZE) {
		ELOG("Mbox Message Size(%d) Can't exceed %d\n", MessageSize, HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}

	/* Set cmd FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0u;                             // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0u;                             // Not used
	Message.Cmd[6] = 0u;                             // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"

	/* Set data FIFO */
	Message.Data[idx] = uiObjId;
	idx++;
	Message.Data[idx] = HSM_NONE_DMA;
	idx++;

	Message.Data[idx] = uiKeyIndex;
	idx++;

	Message.Data[idx] = uiDigSize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucDig, uiDigSize);
	idx += (uiDigSize + 3u) / sizeof(uint32);

	Message.Data[idx] = uiSigSize;
	idx++;
	if ((uiReq == REQ_HSM_RUN_RSASSA_PKCS_VERIFY_BY_KT)
		|| (uiReq == REQ_HSM_RUN_RSASSA_PSS_VERIFY_BY_KT)) {
		SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucSig, uiSigSize);
		idx += (uiSigSize + 3u) / sizeof(uint32);
	}

	Message.Cmd[4] = idx * sizeof(uint32); // data size
	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	ret = Message.Data[0];
	if (ret != TCCHSM_SUCCESS) {
		ELOG("Error result value(0x%x)\n", ret);
		goto out;
	}

	if ((uiReq == REQ_HSM_RUN_RSASSA_PKCS_SIGN_BY_KT)
		|| (uiReq == REQ_HSM_RUN_RSASSA_PSS_SIGN_BY_KT)) {
		if (Message.Data[1] == uiSigSize) {
			SAL_MemCopy((void *)pucSig, (const void *)&Message.Data[2], uiSigSize);
		} else {
			ELOG("wrong uiSigSize(%d)\n", Message.Data[1]);
			ret = TCCHSM_ERR_INVALID_STATE;
			goto out;
		}
	}

out:
	return ret;
}

uint32 HSM_Write(uint32 uiReq, uint32 uiAddr, uint8 *pucBuf, uint32 uiBufSize)
{
	MboxMessage_t Message = {0};
	uint32 idx = 0;
	uint32 ret = TCCHSM_ERR;

	/* Check Mbox Message size  */
	if ((uiBufSize > HSM_MBOX_MSG_MAXSIZE)) {
		ELOG("Size Can't exceed %d\n", HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}

	/* Set cmd FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0u;                             // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0u;                             // Not used
	Message.Cmd[6] = 0u;                             // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"

	/* Set data FIFO */
	Message.Data[idx] = uiAddr;
	idx++;
	Message.Data[idx] = HSM_NONE_DMA;
	idx++;
	Message.Data[idx] = uiBufSize;
	idx++;
	SAL_MemCopy((void *)&Message.Data[idx], (const void *)pucBuf, uiBufSize);
	idx += (uiBufSize + 3u) / sizeof(uint32);

	Message.Cmd[4] = idx * sizeof(uint32); // data size
	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	ret = Message.Data[0];

out:
	return ret;
}
/**************************************************************************************************
 * @name                                     HSM_GenRand
 *
 * @brief Generate Random number from HSM
 *
 * @param        (void)
 * @return       uint32
 *
 * @note
 *
 ***************************************************************************************************/
uint32 HSM_GetRand(uint32 uiReq, uint32 *pucRng, uint32 uiRngSize)
{
	MboxMessage_t Message = {0};
	uint32 idx = 0;
	uint32 ret = TCCHSM_ERR;

	/* Check Mbox Message size  */
	if ((uiRngSize > HSM_MBOX_MSG_MAXSIZE)) {
		ELOG("Size Can't exceed %d\n", HSM_MBOX_MSG_MAXSIZE);
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}

	/* Set command FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0u;                             // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[5] = 0u;                             // Not used
	Message.Cmd[6] = 0u;                             // Not used
	Message.Cmd[7] = (uint32)HSM_MBOX_ID_HSM;        // mbox id, 0x4D5348 = "HSM"

	Message.Data[idx] = HSM_NONE_DMA;
	idx++;
	Message.Data[idx] = uiRngSize;
	idx++;

	Message.Cmd[4] = idx * sizeof(uint32); // data size
	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = idx;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	ret = Message.Data[0];
	if (ret != TCCHSM_SUCCESS) {
		ELOG("Error result value(0x%x)\n", ret);
		goto out;
	}

	if (Message.Data[1] == uiRngSize) {
		SAL_MemCopy((void *)pucRng, (const void *)&Message.Data[2], uiRngSize);
	} else {
		ELOG("Wrong uiDstSize(%d)\n", Message.Data[1]);
		ret = TCCHSM_ERR_INVALID_STATE;
		goto out;
	}

out:
	return ret;
}

uint32 HSM_GetVersion(uint32 uiReq, uint32 *uiX, uint32 *uiY, uint32 *uiZ)
{
	MboxMessage_t Message = {0};
	uint32 ret = TCCHSM_ERR;

	if ((uiX == NULL) || (uiY == NULL) || (uiZ == NULL)) {
		ELOG("Error invalid param\n");
		ret = TCCHSM_ERR_INVALID_PARAM;
		goto out;
	}

	/* Set command FIFO */
	Message.Cmd[0] = MBOX_HSM_CMD0;                  // multi channel number
	Message.Cmd[1] = uiReq | HSM_MBOX_LOCATION_DATA; // cmd
	Message.Cmd[2] = 0u;                             // dma_addr
	Message.Cmd[3] = HSM_NONE_DMA;                   // trans_type
	Message.Cmd[4] = 0u;                             // data length is 0,
	Message.Cmd[5] = 0u;                             // Not used
	Message.Cmd[6] = 0u;                             // Not used
	Message.Cmd[7] = HSM_MBOX_ID_HSM;                // mbox id, 0x4D5348 = "HSM"

	Message.CmdLen = HSM_CMD_FIFO_SIZE;
	Message.DataLen = 0;

	ret = HSM_MBOX_SendRecv(&Message);
	if (ret != TCCHSM_SUCCESS) {
		ELOG("HSM MBOX SendRecv is failed(%d)\n", ret);
		goto out;
	}

	ret = Message.Data[0];
	if (ret != TCCHSM_SUCCESS) {
		ELOG("Error result value(0x%x)\n", ret);
		goto out;
	}

	if (Message.Data[1] == (sizeof(uint32) * 3u)) {
		*uiX = Message.Data[2];
		*uiY = Message.Data[3];
		*uiZ = Message.Data[4];
	} else {
		ELOG("Wrong rdata size(%d)\n", Message.Data[1]);
		ret = TCCHSM_ERR_INVALID_STATE;
		goto out;
	}

out:
	return ret;
}

/**************************************************************************************************
 * @name                                          MBOX_TxIrqHSM
 *
 * @brief HSM Mailbox Tx Interrupts Handler
 *
 * @return void
 *
 * @note
 *
 ***************************************************************************************************/
// void HSM_Mbox_TxIrq(void)
// {
// 	uint32 ret = 0;
// 	(void)MBOX_ClearTxInterrupt(MBOX_CH_HSM_GP);
// 	ret = MBOX_CheckTxDone(MBOX_CH_HSM_GP);
// 	if (ret != SAL_RET_SUCCESS) {
// 		ELOG("MBOX CheckTxDone Failed %d\n", ret);
// 	}
// }

/**************************************************************************************************
 * @name                                          MBOX_TxIrqHSM
 *
 * @brief HSM Mailbox Rx Interrupts Handler
 *
 * @return void
 *
 * @note
 *
 ***************************************************************************************************/
void HSM_Mbox_RxIrq(void)
{
	uint32 ret;
	/* Read Mbox Message From HSM*/
	ret = MBOX_ReadMessage(MBOX_CH_HSM_GP, &HSM_Param.rx);
	/* Check ReadMessage Success */
	if (ret != TCCHSM_SUCCESS) {
		ELOG("MBOX Read Message is Failed%d\n", ret);
		goto out;
	}
	/* Set Received flag for event timeout */
	HSM_Param.mbox_received = 1;
out:
	return;
}

/**************************************************************************************************
 * @name                                      HSM_Init
 *
 * @brief Initialize HSM
 *
 * @return       void
 *
 * @note
 *   - RX corresponds to 'MBOX_Mx_HSM_SLV_TX_IRQn', and TX corresponds to 'MBOX_Mx_HSM_SLV_RX_IRQn'.
 *
 ***************************************************************************************************/
uint32 HSM_Init(void)
{
	uint32 x = 0;
	uint32 y = 0;
	uint32 z = 0;
	uint32 ret = TCCHSM_SUCCESS;
	SALRetCode_t sal_ret = SAL_RET_SUCCESS;

	/* Initialize IRQ numbers for RX and TX in the Mailbox (MBOX) module. */
	sal_ret = MBOX_Open(MBOX_CH_HSM_GP, NULL_PTR, (IrqHandler_t)&HSM_Mbox_RxIrq, 0);
	if(sal_ret != SAL_RET_SUCCESS) {
		ELOG("MBOX_Open Failed\n");
		ret = TCCHSM_ERR;
		goto out;
	}

	/* Get HSM F/W Version and Check dependency */
	ret = HSM_GetVersion(REQ_HSM_GET_VER, &x, &y, &z);
	if (ret != TCCHSM_SUCCESS) {
	    ELOG("HSM_GetVersion fail(0x%x)\n", ret);
	    goto out;
	}
	if ((x != HSM_REQUIRED_VER_X) || (y != HSM_REQUIRED_VER_Y) || (z < HSM_REQUIRED_VER_Z)) {
	    ELOG(
	        "HSM FW verison(%d.%d.%d) must be higher than equal to %d.%d.%d\n", x, y, z,
	        HSM_REQUIRED_VER_X, HSM_REQUIRED_VER_Y, HSM_REQUIRED_VER_Z);
	    ret = TCCHSM_ERR_VERSION_MISMATCH;
	    goto out;
	}

out:
	return ret;
}

/**************************************************************************************************
 * @name                                      HSM_DeInit
 *
 * @brief Deinitialize HSM
 *
 * @return       void
 *
 * @note
 *
 ***************************************************************************************************/
void HSM_DeInit(void)
{
	MBOX_Close(MBOX_CH_HSM_GP);
}