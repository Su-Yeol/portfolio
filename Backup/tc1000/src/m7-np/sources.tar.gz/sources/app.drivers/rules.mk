###################################################################################################
#
#   FileName : ruls.mk
#
#   Copyright (c) Telechips Inc.
#
#   Description :
#
#
###################################################################################################
#
#   TCC Version 1.0
#
#   This source code contains confidential information of Telechips.
#
#   Any unauthorized use without a written permission of Telechips including not limited to
#   re-distribution in source or binary form is strictly prohibited.
#
#   This source code is provided "AS IS" and nothing contained in this source code shall constitute
#   any express or implied warranty of any kind, including without limitation, any warranty of
#   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
#   or other third party intellectual property right. No warranty is made, express or implied,
#   regarding the information's accuracy,completeness, or performance.
#
#   In no event shall Telechips be liable for any claim, damages or other liability arising from,
#   out of or in connection with this source code or the use in the source code.
#
#   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
#   Telechips and Company.
#   This source code is provided "AS IS" and nothing contained in this source code shall constitute
#   any express or implied warranty of any kind, including without limitation, any warranty
#   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
#   copyright or other third party intellectual property right. No warranty is made, express or
#   implied, regarding the information's accuracy, completeness, or performance.
#   In no event shall Telechips be liable for any claim, damages or other liability arising from,
#   out of or in connection with this source code or the use in the source code.
#   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
#   between Telechips and Company.
#
###################################################################################################

SIC_BSP_APP_DRIVERS_PATH := $(SIC_BSP_BUILD_CURDIR)

# IPI Application Driver
ifeq ($(SIC_BSP_DEV_DRV_MBOX), y)
    include $(SIC_BSP_APP_DRIVERS_PATH)/ipi/rules.mk
endif

# IPC Application Driver
ifeq ($(SIC_BSP_APP_DRIVER_IPC), y)
    include $(SIC_BSP_APP_DRIVERS_PATH)/ipc/rules.mk
endif

# SDM (Safe Display Manager) Application Driver
ifeq ($(SIC_BSP_APP_DRIVER_SDM), y)
    include $(SIC_BSP_APP_DRIVERS_PATH)/sdm/rules.mk
endif

# HSM Manager
ifeq ($(SIC_BSP_APP_DRIVER_HSM), y)
    include $(SIC_BSP_APP_DRIVERS_PATH)/hsm/rules.mk
endif

# Trust RVC
ifeq ($(SIC_BSP_BUILD_FLAGS_T_RVC_INCLUDED), y)
    include $(SIC_BSP_APP_DRIVERS_PATH)/trvc/rules.mk
endif

