/*
***************************************************************************************************
*
*   FileName : ipc.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/
#ifndef TCC_IPC_H
#define TCC_IPC_H

/****************************************
 *				Include					*
 ****************************************/
#include "ipi.h"
#include "ipc_typedef.h"


/****************************************
 *				Defines					*
****************************************/

/*
***********************************************************************************
*   Example : IPC CMD ID - LPA - use in ipc_Sample
***********************************************************************************
*/
#define TCC_IPC_CMD_LPA                 (0x01u) // define for CMD1
#define TCC_IPC_CMD_LPA_CAN             (0x01u) // define for CMD2
#define TCC_IPC_CMD_LPA_LIN       		(0x02u) // define for CMD2


/*
***********************************************************************************
*   Example : IPC CMD ID - TPA - use in ipc_Sample
***********************************************************************************
*/
#define TCC_IPC_CMD_TPA                 (0x20u) // define for CMD1
#define TCC_IPC_CMD_TPA_Ctl             (0x01u) // define for CMD2

/****************************************
 *				Enumeration				*
****************************************/

/****************************************
 *				Typedefs				*
****************************************/

/****************************************
 *		  Variable Definitions			*
 ****************************************/

/***************************************************
*		   		Function declaration				*
****************************************************/
void IPC_RegisterCbFunc(    IPCSvcCh_t siCh,    uint8 ucId, IPCCallback pFunc, void* pArg1, void* pArg2);
int32 IPC_SendPacket(    IPCSvcCh_t siCh, uint16 uiCmd1, uint16 uiCmd2, const uint8* pucData, uint16 uiLength);
int32 IPC_IsReady(    IPCSvcCh_t siCh, uint32* uiIpcReady);


#endif

