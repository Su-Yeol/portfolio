/*
***************************************************************************************************
*
*   FileName : ipc_os.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particULar purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particULar purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/****************************************
 *				Include					*
 ****************************************/
#include "ipc_os.h"


/****************************************
 *		  Variable Definitions			*
 ****************************************/
static IPCOsFlags_t ipcOSFlags[IPC_SVC_CH_MAX];


/***************************************************
*          Local function prototypes               *
****************************************************/
static void IPC_CommonLockInit(    IPCSvcCh_t siCh);
static void IPC_CommonLockDelete(    IPCSvcCh_t siCh);
static void IPC_CreateMutex(    IPCSvcCh_t siCh);
static void IPC_DeleteMutex(    IPCSvcCh_t siCh);
static void IPC_CmdEventCreate(    IPCSvcCh_t siCh);
static void IPC_CmdEventDelete(    IPCSvcCh_t siCh);
static void IPC_ReadEventCreate(    IPCSvcCh_t siCh);
static void IPC_ReadEventDelete(    IPCSvcCh_t siCh);
static void IPC_BufferOverFlowEventCreate(    IPCSvcCh_t siCh);
static void IPC_BufferOverFlowEventDelete(    IPCSvcCh_t siCh);
static void IPC_Parser_EventCreate(    IPCSvcCh_t siCh);
static void IPC_Parser_EventDelete(    IPCSvcCh_t siCh);


/**************************************************************************************************
*                                  IPC_Get msec
*
* [External] Get msec
*
* @param        void
* @return       msec
*
* Notes
*
***************************************************************************************************/
uint32 IPC_GetMsec(    void)
{
    uint32 ret = 0UL;

    (void) SAL_GetTickCount(&ret);

    return (ret * TICK_PER_MS);
}

/**************************************************************************************************
*                                  IPC_Mdelay
*
* [External] Delay msec
*
* @param        uiDly
* @return       void
*
* Notes
*
***************************************************************************************************/
void IPC_Mdelay(    uint32 uiDly)
{
    (void) SAL_TaskSleep(uiDly);
}

/**************************************************************************************************
*                            create / delete / lock / unlock Common mutex
*
* [Internal] Creat / Delete mutex
* [External] Lock / Unlock mutex
*
* @param        siCh
* @return       void
*
* Notes
*
***************************************************************************************************/
static void IPC_CommonLockInit(    IPCSvcCh_t siCh)
{
	uint8 * str = NULL;

	if(siCh == IPC_CH_CA65_NS_USER) 	{	str = (uint8 *)"CA65_NS_USER Common_Mutex";	}
	else if(siCh == IPC_CH_CA65_NS_TPA) {	str = (uint8 *)"CA65_NS_TPA Common_Mutex"; 	}
	else if(siCh == IPC_CH_CA65_NS_LPA) {	str = (uint8 *)"CA65_NS_LPA Common_Mutex"; 	}
#if ( CORTEX_M7_0 == 0)	
	else if(siCh == IPC_CH_CM7_0_USER)	{	str = (uint8 *)"CM7_0_USER Common_Mutex";	}
	else if(siCh == IPC_CH_CM7_0_TPA)	{	str = (uint8 *)"CM7_0_TPA Common_Mutex";	}
	else if(siCh == IPC_CH_CM7_0_LPA)	{	str = (uint8 *)"CM7_0_LPA Common_Mutex";	}
#endif
#if ( CORTEX_M7_1 == 0)	
	else if(siCh == IPC_CH_CM7_1_USER)	{	str = (uint8 *)"CM7_1_USER Common_Mutex";	}
	else if(siCh == IPC_CH_CM7_1_TPA)	{	str = (uint8 *)"CM7_1_TPA Common_Mutex";	}
	else if(siCh == IPC_CH_CM7_1_LPA)	{	str = (uint8 *)"CM7_1_LPA Common_Mutex";	}
#endif
#if ( CORTEX_M7_2 == 0)	
	else if(siCh == IPC_CH_CM7_2_USER)	{	str = (uint8 *)"CM7_2_USER Common_Mutex";	}
	else if(siCh == IPC_CH_CM7_2_TPA)	{	str = (uint8 *)"CM7_2_TPA Common_Mutex";	}
	else if(siCh == IPC_CH_CM7_2_LPA)	{	str = (uint8 *)"CM7_2_LPA Common_Mutex";	}
#endif
#if ( CORTEX_M7_NP == 0)	
	else if(siCh == IPC_CH_CM7_NP_USER) {	str = (uint8 *)"CM7_NP_USER Common_Mutex"; 	}
	else if(siCh == IPC_CH_CM7_NP_TPA)	{	str = (uint8 *)"CM7_NP_TPA Common_Mutex";	}
	else if(siCh == IPC_CH_CM7_NP_LPA)	{	str = (uint8 *)"CM7_NP_LPA Common_Mutex";	}

#endif
	else{}

	(void) SAL_SemaphoreCreate((uint32 *) &(ipcOSFlags[siCh].ipcCommonSemaId), (const uint8 *)str, 1UL, SAL_OPT_BLOCKING);

}

static void IPC_CommonLockDelete(    IPCSvcCh_t siCh)
{
    (void)SAL_SemaphoreDelete(ipcOSFlags[siCh].ipcCommonSemaId);
}

void IPC_CommonLock(    IPCSvcCh_t siCh)
{
    /*Acquire Mutex*/
    (void) SAL_SemaphoreWait(ipcOSFlags[siCh].ipcCommonSemaId, 0, SAL_OPT_BLOCKING);
}

void IPC_CommonUnlock(    IPCSvcCh_t siCh)
{
    /*Release Mutex*/
    (void) SAL_SemaphoreRelease(ipcOSFlags[siCh].ipcCommonSemaId);
}

/**************************************************************************************************
*                            create / delete / lock / unlock Ipc mutex
*
* [Internal] Creat / Delete mutex
* [External] Lock / Unlock mutex
*
* @param        siCh
* @return       void
*
* Notes
*
***************************************************************************************************/
static void IPC_CreateMutex(    IPCSvcCh_t siCh)
{
	uint8 * str1 = NULL;
	uint8 * str2 = NULL;
	uint8 * str3 = NULL;
	uint8 * str4 = NULL;

	if(siCh == IPC_CH_CA65_NS_USER)
	{
		str1 = (uint8 *)"CA65_NS_USER read_func_Mutex";
		str2 = (uint8 *)"CA65_NS_USER write_func_ Mutex";
		str3 = (uint8 *)"CA65_NS_USER read_buffer_Mutex";
		str4 = (uint8 *)"CA65_NS_USER write_buffer_Mutex";
	}		
	else if(siCh == IPC_CH_CA65_NS_TPA)
	{
		str1 = (uint8 *)"CA65_NS_TPA read_func_Mutex";
		str2 = (uint8 *)"CA65_NS_TPA write_func_Mutex";
		str3 = (uint8 *)"CA65_NS_TPA read_buffer_Mutex";
		str4 = (uint8 *)"CA65_NS_TPA write_buffer_Mutex";
	}		
	else if(siCh == IPC_CH_CA65_NS_LPA)
	{
		str1 = (uint8 *)"CA65_NS_LPA read_func_Mutex";
		str2 = (uint8 *)"CA65_NS_LPA write_func_Mutex";
		str3 = (uint8 *)"CA65_NS_LPA read_buffer_Mutex";
		str4 = (uint8 *)"CA65_NS_LPA write_buffer_Mutex";
	}		
#if ( CORTEX_M7_0 == 0)	
	else if(siCh == IPC_CH_CM7_0_USER)
	{
		str1 = (uint8 *)"CM7_0_USER read_func_Mutex";
		str2 = (uint8 *)"CM7_0_USER write_func_Mutex";
		str3 = (uint8 *)"CM7_0_USER read_buffer_Mutex";
		str4 = (uint8 *)"CM7_0_USER write_buffer_Mutex";
	}		
	else if(siCh == IPC_CH_CM7_0_TPA)
	{
		str1 = (uint8 *)"CM7_0_TPA read_func_Mutex";
		str2 = (uint8 *)"CM7_0_TPA write_func_Mutex";
		str3 = (uint8 *)"CM7_0_TPA read_buffer_Mutex";
		str4 = (uint8 *)"CM7_0_TPA write_buffer_Mutex";
	}		
	else if(siCh == IPC_CH_CM7_0_LPA)
	{
		str1 = (uint8 *)"CM7_0_LPA read_func_Mutex";
		str2 = (uint8 *)"CM7_0_LPA write_func_Mutex";
		str3 = (uint8 *)"CM7_0_LPA read_buffer_Mutex";
		str4 = (uint8 *)"CM7_0_LPA write_buffer_Mutex";
	}		
#endif
#if ( CORTEX_M7_1 == 0)	
	else if(siCh == IPC_CH_CM7_1_USER)
	{
		str1 = (uint8 *)"CM7_1_USER read_func_Mutex";
		str2 = (uint8 *)"CM7_1_USER write_func_Mutex";
		str3 = (uint8 *)"CM7_1_USER read_buffer_Mutex";
		str4 = (uint8 *)"CM7_1_USER write_buffer_ Mutex";
	}		
	else if(siCh == IPC_CH_CM7_1_TPA)
	{
		str1 = (uint8 *)"CM7_1_TPA read_func_Mutex";
		str2 = (uint8 *)"CM7_1_TPA write_func_Mutex";
		str3 = (uint8 *)"CM7_1_TPA read_buffer_Mutex";
		str4 = (uint8 *)"CM7_1_TPA write_buffer_Mutex";
	}		
	else if(siCh == IPC_CH_CM7_1_LPA)
	{
		str1 = (uint8 *)"CM7_1_LPA read_func_Mutex";
		str2 = (uint8 *)"CM7_1_LPA write_func_Mutex";
		str3 = (uint8 *)"CM7_1_LPA read_buffer_Mutex";
		str4 = (uint8 *)"CM7_1_LPA write_buffer_Mutex";
	}		
#endif
#if ( CORTEX_M7_2 == 0)	
	else if(siCh == IPC_CH_CM7_2_USER)
	{
		str1 = (uint8 *)"CM7_2_USER read_func_Mutex";
		str2 = (uint8 *)"CM7_2_USER write_func_Mutex";
		str3 = (uint8 *)"CM7_2_USER read_buffer_Mutex";
		str4 = (uint8 *)"CM7_2_USER write_buffer_Mutex";
	}		
	else if(siCh == IPC_CH_CM7_2_TPA)
	{
		str1 = (uint8 *)"CM7_2_TPA read_func_Mutex";
		str2 = (uint8 *)"CM7_2_TPA write_func_Mutex";
		str3 = (uint8 *)"CM7_2_TPA read_buffer_Mutex";
		str4 = (uint8 *)"CM7_2_TPA write_buffer_Mutex";
	}		
	else if(siCh == IPC_CH_CM7_2_LPA)
	{
		str1 = (uint8 *)"CM7_2_LPA read_func_Mutex";
		str2 = (uint8 *)"CM7_2_LPA write_func_Mutex";
		str3 = (uint8 *)"CM7_2_LPA read_buffer_Mutex";
		str4 = (uint8 *)"CM7_2_LPA write_buffer_Mutex";
	}		

#endif
#if ( CORTEX_M7_NP == 0)	
	else if(siCh == IPC_CH_CM7_NP_USER)
	{
		str1 = (uint8 *)"CM7_NP_USER read_func_Mutex";
		str2 = (uint8 *)"CM7_NP_USER write_func_Mutex";
		str3 = (uint8 *)"CM7_NP_USER read_buffer_Mutex";
		str4 = (uint8 *)"CM7_NP_USER write_buffer_Mutex";
	}		
	else if(siCh == IPC_CH_CM7_NP_TPA)
	{
		str1 = (uint8 *)"CM7_NP_TPA read_func_Mutex";
		str2 = (uint8 *)"CM7_NP_TPA write_func_Mutex";
		str3 = (uint8 *)"CM7_NP_TPA read_buffer_Mutex";
		str4 = (uint8 *)"CM7_NP_TPA write_buffer_Mutex";
	}		
	else if(siCh == IPC_CH_CM7_NP_LPA)
	{
		str1 = (uint8 *)"CM7_NP_LPA read_func_Mutex";
		str2 = (uint8 *)"CM7_NP_LPA write_func_Mutex";
		str3 = (uint8 *)"CM7_NP_LPA read_buffer_Mutex";
		str4 = (uint8 *)"CM7_NP_LPA write_buffer_Mutex";
	}		
#endif
	else{}

	(void) SAL_SemaphoreCreate((uint32 *) &(ipcOSFlags[siCh].ipcReadSemaId),  (const uint8 *) str1, 1UL, SAL_OPT_BLOCKING);
	(void) SAL_SemaphoreCreate((uint32 *) &(ipcOSFlags[siCh].ipcWriteSemaId), (const uint8 *) str2, 1UL, SAL_OPT_BLOCKING);
	(void) SAL_SemaphoreCreate((uint32 *) &(ipcOSFlags[siCh].ipcRbufSemaId),  (const uint8 *) str3, 1UL, SAL_OPT_BLOCKING);
	(void) SAL_SemaphoreCreate((uint32 *) &(ipcOSFlags[siCh].ipcWbufSemaId),  (const uint8 *) str4, 1UL, SAL_OPT_BLOCKING);

}

static void IPC_DeleteMutex(    IPCSvcCh_t siCh)
{
    (void) SAL_SemaphoreDelete(ipcOSFlags[siCh].ipcReadSemaId);
    (void) SAL_SemaphoreDelete(ipcOSFlags[siCh].ipcWriteSemaId);
    (void) SAL_SemaphoreDelete(ipcOSFlags[siCh].ipcRbufSemaId);
    (void) SAL_SemaphoreDelete(ipcOSFlags[siCh].ipcWbufSemaId);
}


void IPC_WriteLock(    IPCSvcCh_t siCh)
{
    /*Acquire Mutex*/
    (void) SAL_SemaphoreWait(ipcOSFlags[siCh].ipcWriteSemaId, 0, SAL_OPT_BLOCKING);
}

void IPC_WriteUnlock(    IPCSvcCh_t siCh)
{
    /*Release Mutex*/
    (void) SAL_SemaphoreRelease(ipcOSFlags[siCh].ipcWriteSemaId);
}

void IPC_ReadLock(    IPCSvcCh_t siCh)
{
    /*Acquire Mutex*/
    (void) SAL_SemaphoreWait(ipcOSFlags[siCh].ipcReadSemaId, 0, SAL_OPT_BLOCKING);
}

void IPC_ReadUnlock(    IPCSvcCh_t siCh)
{
    /*Release Mutex*/
    (void) SAL_SemaphoreRelease(ipcOSFlags[siCh].ipcReadSemaId);
}

void IPC_RbufferLock(    IPCSvcCh_t siCh)
{
    /*Acquire Mutex*/
    (void) SAL_SemaphoreWait(ipcOSFlags[siCh].ipcRbufSemaId, 0, SAL_OPT_BLOCKING);
}

void IPC_RbufferUnlock(    IPCSvcCh_t siCh)
{
    /*Release Mutex*/
    (void) SAL_SemaphoreRelease(ipcOSFlags[siCh].ipcRbufSemaId);
}

void IPC_WbufferLock(    IPCSvcCh_t siCh)
{
    /*Acquire Mutex*/
    (void) SAL_SemaphoreWait(ipcOSFlags[siCh].ipcWbufSemaId, 0, SAL_OPT_BLOCKING);
}

void IPC_WbufferUnlock(    IPCSvcCh_t siCh)
{
    /*Release Mutex*/
    (void) SAL_SemaphoreRelease(ipcOSFlags[siCh].ipcWbufSemaId);
}


/**************************************************************************************************
*      					 IPC_Cmd Event Create / Delete / Wait / PreSet / WakeUp
*
* [Internal] Creat / Delete 
* [External] Wait / PreSet / WakeUp
*
* @param        siCh
* @return       void
*
* Notes
*
***************************************************************************************************/
static void IPC_CmdEventCreate(    IPCSvcCh_t siCh)
{
    uint32 cmdId;
	uint8 * str = NULL;

	if(siCh == IPC_CH_CA65_NS_USER) 	{	str = (uint8 *)"CA65_NS_USER command_ack_flag_group";	}
	else if(siCh == IPC_CH_CA65_NS_TPA) {	str = (uint8 *)"CA65_NS_TPA command_ack_flag_group"; 	}
	else if(siCh == IPC_CH_CA65_NS_LPA) {	str = (uint8 *)"CA65_NS_LPA command_ack_flag_group"; 	}
#if ( CORTEX_M7_0 == 0)	
	else if(siCh == IPC_CH_CM7_0_USER)	{	str = (uint8 *)"CM7_0_USER command_ack_flag_group";		}
	else if(siCh == IPC_CH_CM7_0_TPA)	{	str = (uint8 *)"CM7_0_TPA command_ack_flag_group";		}
	else if(siCh == IPC_CH_CM7_0_LPA)	{	str = (uint8 *)"CM7_0_LPA command_ack_flag_group";		}
#endif
#if ( CORTEX_M7_1 == 0)	
	else if(siCh == IPC_CH_CM7_1_USER)	{	str = (uint8 *)"CM7_1_USER command_ack_flag_group";		}
	else if(siCh == IPC_CH_CM7_1_TPA)	{	str = (uint8 *)"CM7_1_TPA command_ack_flag_group";		}
	else if(siCh == IPC_CH_CM7_1_LPA)	{	str = (uint8 *)"CM7_1_LPA command_ack_flag_group";		}
#endif
#if ( CORTEX_M7_2 == 0)	
	else if(siCh == IPC_CH_CM7_2_USER)	{	str = (uint8 *)"CM7_2_USER command_ack_flag_group";		}
	else if(siCh == IPC_CH_CM7_2_TPA)	{	str = (uint8 *)"CM7_2_TPA command_ack_flag_group";		}
	else if(siCh == IPC_CH_CM7_2_LPA)	{	str = (uint8 *)"CM7_2_LPA command_ack_flag_group";		}
#endif
#if ( CORTEX_M7_NP == 0)	
	else if(siCh == IPC_CH_CM7_NP_USER) {	str = (uint8 *)"CM7_NP_USER command_ack_flag_group"; 	}
	else if(siCh == IPC_CH_CM7_NP_TPA)	{	str = (uint8 *)"CM7_NP_TPA command_ack_flag_group";		}
	else if(siCh == IPC_CH_CM7_NP_LPA)	{	str = (uint8 *)"CM7_NP_LPA command_ack_flag_group";		}
#endif
	else{}

	(void) SAL_EventCreate((uint32 *)&(ipcOSFlags[siCh].ipcAckFlags.afEventFlagId), (const uint8 *)str, 0);

    if (siCh < IPC_SVC_CH_MAX)
    {
        for(cmdId = (uint32) CTL_CMD ; cmdId < (uint32) MAX_CMD_TYPE ; cmdId++)
        {
            ipcOSFlags[(uint32) siCh].ipcAckFlags.afWaitAck[cmdId].aiSeqId = 0xFFFFFFFFU;
        }
    }
}

static void IPC_CmdEventDelete(    IPCSvcCh_t siCh)
{
    (void) SAL_EventDelete(ipcOSFlags[siCh].ipcAckFlags.afEventFlagId);
}

int32 IPC_CmdWaitEventTimeOut(    IPCSvcCh_t siCh, IPCCmdType_t cmdType, uint32 uiTimeOut)
{
    int32        ret;
    uint32       retFlag;
    uint32       waitFlag;
    SALRetCode_t err;

    retFlag = 0UL;

    if ((siCh < IPC_SVC_CH_MAX) && (cmdType < MAX_CMD_TYPE)) //Dereference of an invalid pointer value
    {
        switch(cmdType)
        {
            case CTL_CMD :
            {
                waitFlag = CTL_CMD_FLAG;
                break;
            }

            case WRITE_CMD :
            {
                waitFlag = WRITE_CMD_FLAG;
                break;
            }

            default :
            {
                waitFlag = (uint32) 0x00;
                break;
            }
        }

        err = SAL_EventGet
        (
            ipcOSFlags[siCh].ipcAckFlags.afEventFlagId,
            waitFlag,
            uiTimeOut,
            ((uint32) SAL_EVENT_OPT_SET_ANY | (uint32) SAL_EVENT_OPT_CONSUME | (uint32) SAL_OPT_BLOCKING),
            &retFlag
        );

        if((err == SAL_RET_SUCCESS))
        {
            if (retFlag == 0U)
            {
                ret = IPC_ERR_TIMEOUT;  /* time out */
            }
            else
            {
                if (ipcOSFlags[siCh].ipcAckFlags.afWaitAck[cmdType].aiNack == 0U)
                {
                    ret = IPC_SUCCESS;
                }
                else
                {
                    ret = IPC_ERR_RECV_NACK; 
                }
            }
        }
        else
        {
            ret = IPC_ERR_COMMON;
        }
    }
    else
    {
        ret = IPC_ERR_ARGUMENT;
    }

    return ret;
}

void IPC_CmdWakePreSet(    IPCSvcCh_t siCh, IPCCmdType_t cmdType,    uint32 uiSeqID)
{
    uint32 waitFlag;

    if ((siCh < IPC_SVC_CH_MAX) && (cmdType < MAX_CMD_TYPE)) //Dereference of an invalid pointer value
    {
        switch(cmdType)
        {
            case CTL_CMD :
            {
                waitFlag = CTL_CMD_FLAG;
                break;
            }

            case WRITE_CMD :
            {
                waitFlag = WRITE_CMD_FLAG;
                break;
            }

            default :
            {
                waitFlag = (uint32) 0x00;
                break;
            }
        }

        (void)SAL_EventSet(ipcOSFlags[siCh].ipcAckFlags.afEventFlagId, waitFlag, SAL_EVENT_OPT_CLR_ALL); // checking point the meaning of SAL_EVENT_OPT_CLR_ALL
        ipcOSFlags[siCh].ipcAckFlags.afWaitAck[cmdType].aiSeqId = uiSeqID;
        ipcOSFlags[siCh].ipcAckFlags.afWaitAck[cmdType].aiNack = 0U;
    }
}

void IPC_CmdWakeUp(    IPCSvcCh_t siCh, IPCCmdType_t cmdType, uint32 uiSeqID, uint32 uiNack)
{
    uint32 waitFlag;

    if ((siCh < IPC_SVC_CH_MAX) && (cmdType < MAX_CMD_TYPE)) //Dereference of an invalid pointer value
    {
        if(ipcOSFlags[siCh].ipcAckFlags.afWaitAck[cmdType].aiSeqId == uiSeqID)
        {
            switch(cmdType)
            {
                case CTL_CMD :
                {
                    waitFlag = CTL_CMD_FLAG;
                    break;
                }

                case WRITE_CMD :
                {
                    waitFlag = WRITE_CMD_FLAG;	
                    break;
                }

                default :
                {
                    waitFlag = (uint32) 0x00;
                    break;
                }
            }

            ipcOSFlags[siCh].ipcAckFlags.afWaitAck[cmdType].aiNack = uiNack;

            (void) SAL_EventSet(ipcOSFlags[siCh].ipcAckFlags.afEventFlagId, waitFlag, SAL_EVENT_OPT_FLAG_SET);
        }
        else
        {
            ;/* Receive unknown ACK */
        }
    }

}


/**************************************************************************************************
*      					 IPC_Read EventCreate / Delete / Wait / Clear
*
* [Internal] Creat / Delete 
* [External] Wait / Clear
*
* @param        siCh
* @return       void
*
* Notes
*
***************************************************************************************************/
static void IPC_ReadEventCreate(    IPCSvcCh_t siCh)
{
	uint8 * str = NULL;

	if(siCh == IPC_CH_CA65_NS_USER) 	{	str = (uint8 *)"CA65_NS_USER read_wait_flag_group";	}
	else if(siCh == IPC_CH_CA65_NS_TPA) {	str = (uint8 *)"CA65_NS_TPA read_wait_flag_group"; 	}
	else if(siCh == IPC_CH_CA65_NS_LPA) {	str = (uint8 *)"CA65_NS_LPA read_wait_flag_group"; 	}
#if ( CORTEX_M7_0 == 0)	
	else if(siCh == IPC_CH_CM7_0_USER)	{	str = (uint8 *)"CM7_0_USER read_wait_flag_group";	}
	else if(siCh == IPC_CH_CM7_0_TPA)	{	str = (uint8 *)"CM7_0_TPA read_wait_flag_group";	}
	else if(siCh == IPC_CH_CM7_0_LPA)	{	str = (uint8 *)"CM7_0_LPA read_wait_flag_group";	}
#endif
#if ( CORTEX_M7_1 == 0)	
	else if(siCh == IPC_CH_CM7_1_USER)	{	str = (uint8 *)"CM7_1_USER read_wait_flag_group";	}
	else if(siCh == IPC_CH_CM7_1_TPA)	{	str = (uint8 *)"CM7_1_TPA read_wait_flag_group";	}
	else if(siCh == IPC_CH_CM7_1_LPA)	{	str = (uint8 *)"CM7_1_LPA read_wait_flag_group";	}
#endif
#if ( CORTEX_M7_2 == 0)	
	else if(siCh == IPC_CH_CM7_2_USER)	{	str = (uint8 *)"CM7_2_USER read_wait_flag_group";	}
	else if(siCh == IPC_CH_CM7_2_TPA)	{	str = (uint8 *)"CM7_2_TPA read_wait_flag_group";	}
	else if(siCh == IPC_CH_CM7_2_LPA)	{	str = (uint8 *)"CM7_2_LPA read_wait_flag_group";	}
#endif
#if ( CORTEX_M7_NP == 0)	
	else if(siCh == IPC_CH_CM7_NP_USER) {	str = (uint8 *)"CM7_NP_USER read_wait_flag_group"; 	}
	else if(siCh == IPC_CH_CM7_NP_TPA)	{	str = (uint8 *)"CM7_NP_TPA read_wait_flag_group";	}
	else if(siCh == IPC_CH_CM7_NP_LPA)	{	str = (uint8 *)"CM7_NP_LPA read_wait_flag_group";	}
#endif
	else{}

	(void) SAL_EventCreate((uint32 *)&(ipcOSFlags[siCh].ipcReadWaitFlagId), (const uint8 *) str, 0);

}

static void IPC_ReadEventDelete(    IPCSvcCh_t siCh)
{
    (void) SAL_EventDelete(ipcOSFlags[siCh].ipcReadWaitFlagId);
}

int32 IPC_ReadWaitEventTimeOut(    IPCSvcCh_t siCh, uint32 uiTimeOut)
{
    int32        ret;
    SALRetCode_t err;
    uint32       retFlag;

    retFlag = 0UL;

    err = SAL_EventGet(ipcOSFlags[siCh].ipcReadWaitFlagId, READ_WAIT_FLAG, uiTimeOut, ((uint32) SAL_EVENT_OPT_SET_ANY| (uint32) SAL_OPT_BLOCKING), &retFlag);

    if((err == SAL_RET_SUCCESS))
    {
        if (retFlag == 0U)
        {
            ret = IPC_ERR_TIMEOUT;  /* time out */
        }
        else
        {
            ret = IPC_SUCCESS;
        }
    }
    else
    {
        ret = IPC_ERR_COMMON;
    }

    return ret;
}

void IPC_ReadClearEvent(    IPCSvcCh_t siCh)
{
    (void) SAL_EventSet(ipcOSFlags[siCh].ipcReadWaitFlagId, READ_WAIT_FLAG, SAL_EVENT_OPT_CLR_ALL);
}

void IPC_ReadWakeUp(    IPCSvcCh_t siCh)
{
    (void) SAL_EventSet(ipcOSFlags[siCh].ipcReadWaitFlagId, READ_WAIT_FLAG, SAL_EVENT_OPT_FLAG_SET);
}


/**************************************************************************************************
*      					 IPC Buffer OVF Event Create / Delete / Wait / Clear
*
* [Internal] Creat / Delete 
* [External] Wait / WakeUp
*
* @param        siCh
* @return       void
*
* Notes
*
***************************************************************************************************/
static void IPC_BufferOverFlowEventCreate(    IPCSvcCh_t siCh)
{
	uint8 * str = NULL;

	if(siCh == IPC_CH_CA65_NS_USER) 	{	str = (uint8 *)"CA65_NS_USER buffer_overflow_flag_group";	}
	else if(siCh == IPC_CH_CA65_NS_TPA) {	str = (uint8 *)"CA65_NS_TPA buffer_overflow_flag_group"; 	}
	else if(siCh == IPC_CH_CA65_NS_LPA) {	str = (uint8 *)"CA65_NS_LPA buffer_overflow_flag_group"; 	}
#if ( CORTEX_M7_0 == 0)	
	else if(siCh == IPC_CH_CM7_0_USER)	{	str = (uint8 *)"CM7_0_USER buffer_overflow_flag_group";		}
	else if(siCh == IPC_CH_CM7_0_TPA)	{	str = (uint8 *)"CM7_0_TPA buffer_overflow_flag_group";		}
	else if(siCh == IPC_CH_CM7_0_LPA)	{	str = (uint8 *)"CM7_0_LPA buffer_overflow_flag_group";		}
#endif
#if ( CORTEX_M7_1 == 0)	
	else if(siCh == IPC_CH_CM7_1_USER)	{	str = (uint8 *)"CM7_1_USER buffer_overflow_flag_group";		}
	else if(siCh == IPC_CH_CM7_1_TPA)	{	str = (uint8 *)"CM7_1_TPA buffer_overflow_flag_group";		}
	else if(siCh == IPC_CH_CM7_1_LPA)	{	str = (uint8 *)"CM7_1_LPA buffer_overflow_flag_group";		}
#endif
#if ( CORTEX_M7_2 == 0)	
	else if(siCh == IPC_CH_CM7_2_USER)	{	str = (uint8 *)"CM7_2_USER buffer_overflow_flag_group";		}
	else if(siCh == IPC_CH_CM7_2_TPA)	{	str = (uint8 *)"CM7_2_TPA buffer_overflow_flag_group";		}
	else if(siCh == IPC_CH_CM7_2_LPA)	{	str = (uint8 *)"CM7_2_LPA buffer_overflow_flag_group";		}
#endif
#if ( CORTEX_M7_NP == 0)	
	else if(siCh == IPC_CH_CM7_NP_USER) {	str = (uint8 *)"CM7_NP_USER buffer_overflow_flag_group"; 	}
	else if(siCh == IPC_CH_CM7_NP_TPA)	{	str = (uint8 *)"CM7_NP_TPA buffer_overflow_flag_group";		}
	else if(siCh == IPC_CH_CM7_NP_LPA)	{	str = (uint8 *)"CM7_NP_LPA buffer_overflow_flag_group";		}
#endif
	else{}

	(void) SAL_EventCreate((uint32 *)&(ipcOSFlags[siCh].ipcBufOverflowFlagId), (const uint8 *) str, 0);

}

static void IPC_BufferOverFlowEventDelete(    IPCSvcCh_t siCh)
{
    (void)SAL_EventDelete(ipcOSFlags[siCh].ipcBufOverflowFlagId);
}

int32 IPC_BufferOverFlowWaitEventTimeOut(    IPCSvcCh_t siCh, uint32 uiTimeOut)
{
    int32        ret;
    SALRetCode_t err;
    uint32       retFlag;

    ret = 0;
    retFlag = 0UL;

    (void) SAL_EventSet(ipcOSFlags[siCh].ipcBufOverflowFlagId, READ_BUF_CHECK_FLAGS, SAL_EVENT_OPT_CLR_ALL);

    err = SAL_EventGet(ipcOSFlags[siCh].ipcBufOverflowFlagId, READ_BUF_CHECK_FLAGS, uiTimeOut,
                      ((uint32) SAL_EVENT_OPT_SET_ANY| (uint32) SAL_EVENT_OPT_CONSUME| (uint32) SAL_OPT_BLOCKING), &retFlag);

    if((err == SAL_RET_SUCCESS))
    {
        if (retFlag == 0U)
        {
            ret = IPC_ERR_TIMEOUT;  /* time out */
        }
        else
        {
            ret = (int32) retFlag;
        }
    }
    else
    {
        ret = IPC_ERR_COMMON;
    }

    return ret;
}

void IPC_BufferOverFlowWakeUp(    IPCSvcCh_t siCh, uint32 uiFlag)
{
    (void) SAL_EventSet(ipcOSFlags[siCh].ipcBufOverflowFlagId, uiFlag, SAL_EVENT_OPT_FLAG_SET);
}


/**************************************************************************************************
*      					 IPC Parser Event Create / Delete / Wait / Clear / WakeUp
*
* [Internal] Creat / Delete 
* [External] Wait / Clear / WakeUp
*
* @param        siCh
* @return       void
*
* Notes
*
***************************************************************************************************/
static void IPC_Parser_EventCreate(    IPCSvcCh_t siCh)
{
	uint8 * str = NULL;

	if(siCh == IPC_CH_CA65_NS_USER) 	{	str = (uint8 *)"CA65_NS_USER Parser_wait_flag_group";	}
	else if(siCh == IPC_CH_CA65_NS_TPA) {	str = (uint8 *)"CA65_NS_TPA Parser_wait_flag_group";	}
	else if(siCh == IPC_CH_CA65_NS_LPA) {	str = (uint8 *)"CA65_NS_LPA Parser_wait_flag_group";	}
#if ( CORTEX_M7_0 == 0)	
	else if(siCh == IPC_CH_CM7_0_USER)	{	str = (uint8 *)"CM7_0_USER Parser_wait_flag_group";		}
	else if(siCh == IPC_CH_CM7_0_TPA)	{	str = (uint8 *)"CM7_0_TPA Parser_wait_flag_group"; 		}
	else if(siCh == IPC_CH_CM7_0_LPA)	{	str = (uint8 *)"CM7_0_LPA Parser_wait_flag_group"; 		}
#endif
#if ( CORTEX_M7_1 == 0)	
	else if(siCh == IPC_CH_CM7_1_USER)	{	str = (uint8 *)"CM7_1_USER Parser_wait_flag_group";		}
	else if(siCh == IPC_CH_CM7_1_TPA)	{	str = (uint8 *)"CM7_1_TPA Parser_wait_flag_group"; 		}
	else if(siCh == IPC_CH_CM7_1_LPA)	{	str = (uint8 *)"CM7_1_LPA Parser_wait_flag_group"; 		}
#endif
#if ( CORTEX_M7_2 == 0)	
	else if(siCh == IPC_CH_CM7_2_USER)	{	str = (uint8 *)"CM7_2_USER Parser_wait_flag_group";		}
	else if(siCh == IPC_CH_CM7_2_TPA)	{	str = (uint8 *)"CM7_2_TPA Parser_wait_flag_group"; 		}
	else if(siCh == IPC_CH_CM7_2_LPA)	{	str = (uint8 *)"CM7_2_LPA Parser_wait_flag_group"; 		}
#endif
#if ( CORTEX_M7_NP == 0)	
	else if(siCh == IPC_CH_CM7_NP_USER) {	str = (uint8 *)"CM7_NP_USER Parser_wait_flag_group";	}
	else if(siCh == IPC_CH_CM7_NP_TPA)	{	str = (uint8 *)"CM7_NP_TPA Parser_wait_flag_group";		}
	else if(siCh == IPC_CH_CM7_NP_LPA)	{	str = (uint8 *)"CM7_NP_LPA Parser_wait_flag_group";		}
#endif
	else{}

	(void) SAL_EventCreate((uint32 *)&(ipcOSFlags[siCh].ipcParserWaitFlagId), (const uint8 *) str, 0);
}

static void IPC_Parser_EventDelete(    IPCSvcCh_t siCh)
{
    (void) SAL_EventDelete(ipcOSFlags[siCh].ipcParserWaitFlagId);
}

int32 IPC_Parser_WaitEvent(    IPCSvcCh_t siCh)
{
    int32        ret;
    SALRetCode_t err;
    uint32       retFlag;

    retFlag = 0UL;

    err = SAL_EventGet(ipcOSFlags[siCh].ipcParserWaitFlagId, Parser_WAIT_FLAG, 0UL, ((uint32) SAL_EVENT_OPT_SET_ANY| (uint32) SAL_OPT_BLOCKING), &retFlag);

    if((err == SAL_RET_SUCCESS))
    {
        if (retFlag == 0U)
        {
            ret = IPC_ERR_TIMEOUT;  /* time out */
        }
        else
        {
            ret = IPC_SUCCESS;
        }
    }
    else
    {
        ret = IPC_ERR_COMMON;
    }

    return ret;
}

void IPC_Parser_ClearEvent(    IPCSvcCh_t siCh)
{
    (void) SAL_EventSet(ipcOSFlags[siCh].ipcParserWaitFlagId, Parser_WAIT_FLAG, SAL_EVENT_OPT_CLR_ALL);
}

void IPC_Parser_WakeUp(    IPCSvcCh_t siCh)
{	
    (void) SAL_EventSet(ipcOSFlags[siCh].ipcParserWaitFlagId, Parser_WAIT_FLAG, SAL_EVENT_OPT_FLAG_SET);
}


/**************************************************************************************************
*      					 IPC_OsResourceInit
*
* [External] IPC OS Resource Init
*
* @param        siCh
* @return       void
*
* Notes
*
***************************************************************************************************/
void IPC_OsResourceInit(    IPCSvcCh_t siCh)
{
    IPC_CommonLockInit(siCh);
    IPC_CreateMutex(siCh);
    IPC_CmdEventCreate(siCh);
    IPC_ReadEventCreate(siCh);
    IPC_BufferOverFlowEventCreate(siCh);
	IPC_Parser_EventCreate(siCh);
}

/**************************************************************************************************
*      					 IPC_OsResourceRelease
*
* [External] IPC OS Resource Release
*
* @param        siCh
* @return       void
*
* Notes
*
***************************************************************************************************/
void IPC_OsResourceRelease(    IPCSvcCh_t siCh)
{
    IPC_CommonLockDelete(siCh);
    IPC_DeleteMutex(siCh);
    IPC_CmdEventDelete(siCh);
    IPC_ReadEventDelete(siCh);
    IPC_BufferOverFlowWakeUp(siCh, READ_BUF_CLOSE_BIT);
    IPC_BufferOverFlowEventDelete(siCh);
	IPC_Parser_EventDelete(siCh);
}



