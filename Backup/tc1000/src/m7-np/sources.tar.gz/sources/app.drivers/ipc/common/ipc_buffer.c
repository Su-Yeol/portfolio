/*
***************************************************************************************************
*
*   FileName : ipc_buffer.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/****************************************
 *				Include					*
 ****************************************/
#include "ipc_buffer.h"

/**************************************************************************************************
*                                          IPC Buffer Init
*
* [External] IPC Buffer Init
*
* @param        *pBufCtrl, *pucBuff, uiSize
* @return       void
*
* Notes
*
***************************************************************************************************/
void IPC_BufferInit(    IPCRingBuff_t*  pBufCtrl,uint8* pucBuff, uint32 uiSize)
{
    pBufCtrl->rbHead          = 0UL;
    pBufCtrl->rbTail          = 0UL;
    pBufCtrl->rbBuffer        = pucBuff;
    pBufCtrl->rbMaxBufferSize = uiSize;
}

/**************************************************************************************************
*                                          IPC push one byte
*
* [External] IPC push one byte
*
* @param        *pBufCtrl, pucData
* @return       ipc buff ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_PushOneByte(    IPCRingBuff_t*   pBufCtrl, uint8 pucData)
{
    int32  ret;
    uint32 temp;

    if (pBufCtrl != NULL_PTR)
    {
        temp = pBufCtrl->rbTail;
        temp++;
        temp %= pBufCtrl->rbMaxBufferSize;

        if (temp == pBufCtrl->rbHead)
        {
            ret = IPC_BUFFER_FULL;
        }
        else
        {
            pBufCtrl->rbBuffer[pBufCtrl->rbTail] = pucData;
            pBufCtrl->rbTail = (uint32)temp;
            ret = IPC_BUFFER_OK;
        }
    }
    else
    {
        ret = IPC_BUFFER_INVALID_PARAM;
        IPC_ERR("%s Buffer Pointer is NULL\n", __func__);
    }

    return ret;
}

/**************************************************************************************************
*                                          IPC push one byte overwrite
*
* [External] IPC push one byte overwrite
*
* @param        *pBufCtrl, pucData
* @return       ipc buff ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_PushOneByteOverWrite(    IPCRingBuff_t*   pBufCtrl, uint8 pucData)
{
    int32  ret;
    uint32 temp;

    if (pBufCtrl != NULL_PTR)
    {
        temp = pBufCtrl->rbTail;
        temp++;
        temp %= pBufCtrl->rbMaxBufferSize;

        if (temp == pBufCtrl->rbHead)
        {
            pBufCtrl->rbHead++;
            pBufCtrl->rbHead = pBufCtrl->rbHead % pBufCtrl->rbMaxBufferSize;
            pBufCtrl->rbBuffer[pBufCtrl->rbTail] = pucData;
            pBufCtrl->rbTail = (uint32)temp;
            ret = IPC_BUFFER_OK;
        }
        else
        {
            pBufCtrl->rbBuffer[pBufCtrl->rbTail] = pucData;
            pBufCtrl->rbTail = (uint32)temp;
            ret = IPC_BUFFER_OK;
        }
    }
    else
    {
        ret = IPC_BUFFER_INVALID_PARAM;
        IPC_ERR("%s Buffer Pointer is NULL\n", __func__);
    }

    return ret;
}

/**************************************************************************************************
*                                          IPC pop one byte
*
* [External] IPC pop one byte
*
* @param        *pBufCtrl, *pucData
* @return       ipc buff ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_PopOneByte(    IPCRingBuff_t*   pBufCtrl, uint8* pucData)
{
    int32  ret;
    uint32 temp;

    if ((pBufCtrl != NULL_PTR) && (pucData != NULL_PTR))
    {
        if (pBufCtrl->rbTail == pBufCtrl->rbHead)
        {
            ret = IPC_BUFFER_EMPTY;
        }
        else
        {
            temp = pBufCtrl->rbHead;
            temp++;
            temp %= pBufCtrl->rbMaxBufferSize;
            *pucData = pBufCtrl->rbBuffer[pBufCtrl->rbHead];
            pBufCtrl->rbHead = temp;
            ret = IPC_BUFFER_OK;
        }
    }
    else
    {
        ret = IPC_BUFFER_INVALID_PARAM;
        IPC_ERR("%s Buffer Pointer is NULL\n", __func__);
    }

    return ret;
}

/**************************************************************************************************
*                                          IPC buffer flush
*
* [External] IPC buffer flush
*
* @param        *pBufCtrl
* @return       ipc buff ret
*
* Notes
*
***************************************************************************************************/
void IPC_BufferFlush(    IPCRingBuff_t*   pBufCtrl)
{
    if (pBufCtrl != NULL_PTR)
    {
        pBufCtrl->rbHead = 0;
        pBufCtrl->rbTail = 0;
    }
    else
    {
        IPC_ERR("%s Buffer Pointer is NULL\n", __func__);
    }
}

/**************************************************************************************************
*                                          IPC buffer flush byte
*
* [External] IPC buffer flush byte
*
* @param        *pBufCtrl, uiFlushSize
* @return       ipc buff ret
*
* Notes
*
***************************************************************************************************/

void IPC_BufferFlushByte(    IPCRingBuff_t*    pBufCtrl, uint32 uiFlushSize)
{
    uint32 temp;

    if (pBufCtrl != NULL_PTR)
    {
        if (pBufCtrl->rbTail < pBufCtrl->rbHead)
        {
            temp = pBufCtrl->rbHead + uiFlushSize;

            if(temp< pBufCtrl->rbMaxBufferSize)
            {
                pBufCtrl->rbHead = temp;
            }
            else
            {
                temp %= pBufCtrl->rbMaxBufferSize;

                if(pBufCtrl->rbTail <= temp)
                {
                    pBufCtrl->rbHead = pBufCtrl->rbTail;
                }
                else
                {
                    pBufCtrl->rbHead = temp;
                }
            }
        }
        else
        {
            temp = pBufCtrl->rbHead + uiFlushSize;

            if(pBufCtrl->rbTail <= temp)
            {
                pBufCtrl->rbHead = pBufCtrl->rbTail;
            }
            else
            {
                pBufCtrl->rbHead = temp;
            }
        }
    }
    else
    {
        IPC_ERR("%s Buffer Pointer is NULL\n", __func__);
    }
}


/**************************************************************************************************
*                                          IPC buffer data available
*
* [External] check buffer data available
*
* @param        *pBufCtrl
* @return       available data size
*
* Notes
*
***************************************************************************************************/

uint32 IPC_BufferDataAvailable(    const IPCRingBuff_t*      pBufCtrl)
{
    uint32 iRet;
    uint32 iRead;
    uint32 iWrite;

    iRet   = 0UL;
    iRead  = 0UL;
    iWrite = 0UL;

    if (pBufCtrl != NULL_PTR)
    {
        iRead  = pBufCtrl->rbHead;
        iWrite = pBufCtrl->rbTail;

        if (iWrite >= iRead)
        {
            // The read pointer is before the write pointer in the bufer.
            iRet = iWrite - iRead;
        }
        else
        {
            // The write pointer is before the read pointer in the buffer.
            iRet = pBufCtrl->rbMaxBufferSize - (iRead - iWrite);
        }
    }
    else
    {
        IPC_ERR("%s Buffer Pointer is NULL\n", __func__);
    }

    return iRet;
}

/**************************************************************************************************
*                                          IPC buffer free space
*
* [External] check buffer free space
*
* @param        *pBufCtrl
* @return       free space size
*
* Notes
*
***************************************************************************************************/
uint32 IPC_BufferFreeSpace(    const IPCRingBuff_t*      pBufCtrl)
{
    uint32 iRet;
    uint32 iRead;
    uint32 iWrite;

    iRet   = 0UL;
    iRead  = 0UL;
    iWrite = 0UL;

    if (pBufCtrl != NULL_PTR)
    {
        iRead = pBufCtrl->rbHead;
        iWrite = pBufCtrl->rbTail;

        if (iWrite < iRead)
        {
            // The write pointer is before the read pointer in the buffer.
            iRet = iRead - iWrite - 1UL;
        }
        else
        {
            // The read pointer is before the write pointer in the bufer.
            iRet = pBufCtrl->rbMaxBufferSize - (iWrite - iRead) - 1UL;
        }
    }
    else
    {
        IPC_ERR("%s Buffer Pointer is NULL\n", __func__);
    }

    return iRet;
}

/**************************************************************************************************
*                                          IPC buffer set head
*
* [External] set head
*
* @param        *pBufCtrl, uiHead
* @return       void
*
* Notes
*
***************************************************************************************************/
void IPC_BufferSetHead(    IPCRingBuff_t*    pBufCtrl, uint32 uiHead)
{
    if (pBufCtrl != NULL_PTR)
    {
        pBufCtrl->rbHead = uiHead;
    }
    else
    {
        IPC_ERR("%s Buffer Pointer is NULL\n", __func__);
    }
}

/**************************************************************************************************
*                                          IPC buffer set tail
*
* [External] set tail
*
* @param        *pBufCtrl, uiTail
* @return       void
*
* Notes
*
***************************************************************************************************/
void IPC_BufferSetTail(    IPCRingBuff_t* pBufCtrl,    uint32 uiTail)
{
    if (pBufCtrl != NULL_PTR)
    {
        pBufCtrl->rbTail = uiTail;
    }
    else
    {
        IPC_ERR("%s Buffer Pointer is NULL\n", __func__);
    }
}

/**************************************************************************************************
*                                          IPC buffer get head
*
* [External] set head
*
* @param        *pBufCtrl
* @return       head posi
*
* Notes
*
***************************************************************************************************/
uint32 IPC_BufferGetHead(    const IPCRingBuff_t*    pBufCtrl)
{
    return ((pBufCtrl != NULL_PTR) ? pBufCtrl->rbHead : 0UL);
}

/**************************************************************************************************
*                                          IPC buffer get tail
*
* [External] set head
*
* @param        *pBufCtrl
* @return       tail posi
*
* Notes
*
***************************************************************************************************/
uint32 IPC_BufferGetTail(    const IPCRingBuff_t*    pBufCtrl)
{
    return ((pBufCtrl != NULL_PTR) ? pBufCtrl->rbTail : 0UL);
}


/**************************************************************************************************
*                                          IPC push buffer
*
* [External] IPC push buffer
*
* @param        *pBufCtrl, *pucData, uiSize
* @return       ipc buff ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_PushBuffer(    IPCRingBuff_t*  pBufCtrl, const uint8* pucBuffer, uint32 uiSize)
{
    int32  ret;
    uint32 freeSpace;
    uint32 remainSize;
    uint32 continuousSize;

    ret             = IPC_BUFFER_ERROR;
    freeSpace       = 0;
    continuousSize  = 0;
    freeSpace       = IPC_BufferFreeSpace(pBufCtrl);

    if(freeSpace >= uiSize)
    {
        continuousSize = pBufCtrl->rbMaxBufferSize - pBufCtrl->rbTail;

        if(continuousSize >= (uint32) uiSize)
        {
            if (SAL_MemCopy((void *)&pBufCtrl->rbBuffer[pBufCtrl->rbTail], (const void *)pucBuffer, (uint32)uiSize) == SAL_RET_SUCCESS)
            {
                pBufCtrl->rbTail += uiSize;
                pBufCtrl->rbTail = pBufCtrl->rbTail % pBufCtrl->rbMaxBufferSize;
                ret = IPC_BUFFER_OK;
            }
            else
            {
                ret = IPC_BUFFER_ERROR;
            }
        }
        else
        {
            if (SAL_MemCopy((void *)&pBufCtrl->rbBuffer[pBufCtrl->rbTail], (const void *)pucBuffer, (uint32)continuousSize) == SAL_RET_SUCCESS)
            {
                remainSize = uiSize - continuousSize;
                if (SAL_MemCopy((void *)&pBufCtrl->rbBuffer[0], (const void *)&pucBuffer[continuousSize], (uint32)remainSize) == SAL_RET_SUCCESS)
                {
                    pBufCtrl->rbTail = remainSize;
                    pBufCtrl->rbTail = pBufCtrl->rbTail % pBufCtrl->rbMaxBufferSize;
                    ret = IPC_BUFFER_OK;
                }
                else
                {
                    ret = IPC_BUFFER_ERROR;
                }
            }
            else
            {
                ret = IPC_BUFFER_ERROR;
            }
        }
    }
    else
    {
        ret = IPC_BUFFER_FULL;
    }

    return ret;
}

/**************************************************************************************************
*                                          IPC push buffer overwrite
*
* [External] IPC push buffer overwrite
*
* @param        *pBufCtrl, *pucData, uiSize
* @return       ipc buff ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_PushBufferOverWrite(    IPCRingBuff_t*  pBufCtrl, const uint8* pucBuffer, uint32 uiSize)
{
    int32  ret;
    uint32 remainSize;
    uint32 continuousSize;

    ret= IPC_BUFFER_ERROR;

    if(pBufCtrl->rbMaxBufferSize >= uiSize)
    {
        continuousSize = pBufCtrl->rbMaxBufferSize - pBufCtrl->rbTail;

        if(continuousSize >= uiSize)
        {
            (void ) SAL_MemCopy((void *)&pBufCtrl->rbBuffer[pBufCtrl->rbTail], (const void *)pucBuffer, (uint32)uiSize);
            pBufCtrl->rbTail += uiSize;
            pBufCtrl->rbTail = pBufCtrl->rbTail % pBufCtrl->rbMaxBufferSize;
            pBufCtrl->rbHead = (pBufCtrl->rbTail + 1UL) % pBufCtrl->rbMaxBufferSize;
            ret = (int32) uiSize;
        }
        else
        {
            (void) SAL_MemCopy((void *)&pBufCtrl->rbBuffer[pBufCtrl->rbTail], (const void *)pucBuffer, continuousSize);
            remainSize = uiSize - continuousSize;
            (void) SAL_MemCopy((void *)&pBufCtrl->rbBuffer[0], (const void *)&pucBuffer[continuousSize], (uint32)remainSize);
            pBufCtrl->rbTail = remainSize;
            pBufCtrl->rbTail = pBufCtrl->rbTail % pBufCtrl->rbMaxBufferSize;
            pBufCtrl->rbHead = (pBufCtrl->rbTail + 1UL) % pBufCtrl->rbMaxBufferSize;
            ret = (int32) uiSize;
        }
    }
    return ret;
}

/**************************************************************************************************
*                                          IPC pop buffer
*
* [External] IPC pop buffer
*
* @param        *pBufCtrl, *pucData, uiSize
* @return       ipc buff ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_PopBuffer(    IPCRingBuff_t*  pBufCtrl, uint8* pucBuffer, uint32 uiSize)
{
    int32 ret;
    uint32 dataSize;
    uint32 remainSize;
    uint32 continuousSize;

    ret            = IPC_BUFFER_ERROR;
    dataSize       = 0UL;
    continuousSize = 0UL;

    if (pBufCtrl->rbTail == pBufCtrl->rbHead)
    {
        ret = IPC_BUFFER_EMPTY;
    }
    else
    {
        dataSize = IPC_BufferDataAvailable(pBufCtrl);

        if(dataSize >= uiSize)
        {
            continuousSize = pBufCtrl->rbMaxBufferSize - pBufCtrl->rbHead;
            ret = IPC_BUFFER_OK;

            if(continuousSize >= uiSize)
            {
                (void) SAL_MemCopy((void *)pucBuffer, (const void *)&pBufCtrl->rbBuffer[pBufCtrl->rbHead], uiSize);
                pBufCtrl->rbHead += uiSize;
                pBufCtrl->rbHead = pBufCtrl->rbHead % pBufCtrl->rbMaxBufferSize;
            }
            else
            {
                (void) SAL_MemCopy((void *)pucBuffer, (const void *)&pBufCtrl->rbBuffer[pBufCtrl->rbHead], continuousSize);
                remainSize = uiSize - continuousSize;
                (void) SAL_MemCopy((void *)&pucBuffer[continuousSize], (const void *)&pBufCtrl->rbBuffer[0], remainSize);
                pBufCtrl->rbHead= remainSize;
                pBufCtrl->rbHead = pBufCtrl->rbHead % pBufCtrl->rbMaxBufferSize;
            }
        }
    }
    return ret;
}

