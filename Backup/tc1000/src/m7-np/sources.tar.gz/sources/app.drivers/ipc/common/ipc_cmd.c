/*
***************************************************************************************************
*
*   FileName : ipc_cmd.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/****************************************
 *				Include					*
 ****************************************/
//#include <sal_com.h>
//#include <sal_internal.h>

#include "ipi.h"
#include "ipc_cmd.h"
#include "ipc_ctl.h"
#include "ipc_api.h"
#include "ipc_os.h"

/***************************************************
*          Local function prototypes               *
****************************************************/
static uint32 IPC_GetSequentialId(    IPCSvcCh_t siCh);



/**************************************************************************************************
*                               IPC Get sequential ID
*
* [Internal] Get sequential ID
*
* @param        siCh
* @return       sequential ID
*
* Notes
*
***************************************************************************************************/
static uint32 IPC_GetSequentialId(    IPCSvcCh_t siCh)
{
    static uint32 sendSeqId[IPC_SVC_CH_MAX] = {0, };

    IPC_CommonLock(siCh);

    if(sendSeqId[siCh] == 0xFFFFFFFFU)
    {
        sendSeqId[siCh] = 1;
    }
    else
    {
        sendSeqId[siCh]++;
    }

    IPC_CommonUnlock(siCh);

    return sendSeqId[siCh];
}

/**************************************************************************************************
*                               IPC_SendOpen
*
* [External] Send IPC Open
*
* @param        siCh
* @return       IPC_Ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_SendOpen(    IPCSvcCh_t siCh)
{
    int32  ret = SAL_RET_SUCCESS;
    uint32 mmReg[IPI_MBOX_CFG_CMD_FIFO_SIZE];

    mmReg[0] = IPC_GetSequentialId(siCh);
    mmReg[1] = (((uint32) CTL_CMD) << 16U) | ((uint32) IPC_OPEN);
    mmReg[2] = IPC_FLAG_USENAMCK;
    mmReg[3] = 0U;
    mmReg[4] = 0U;

	ret = ipi_mailbox_send_command_open(siCh, mmReg);

    return ret;
}

/**************************************************************************************************
*                               IPC_SendClose
*
* [External] Send IPC Close
*
* @param        siCh
* @return       IPC_Ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_SendClose(    IPCSvcCh_t siCh)
{
    int32 ret;
    uint32 mmReg[IPI_MBOX_CFG_CMD_FIFO_SIZE];

    mmReg[0] = IPC_GetSequentialId(siCh);
    mmReg[1] = ((uint32) CTL_CMD<< 16U) | ((uint32) IPC_CLOSE);
    mmReg[2] = 0;
    mmReg[3] = 0;
    mmReg[4] = 0;

    ret = ipi_mailbox_send_command(siCh, mmReg);

    return ret;
}


/**************************************************************************************************
*                               IPC_SendWrite
*
* [External] Send IPC Write
*
* @param        siCh, *puiCmd, *pucBuff, uiSize, uiIsAck
* @return       IPC_Ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_SendWrite(    IPCSvcCh_t siCh, const uint32* puiCmd, const uint8* pucBuff, const uint32 uiSize, uint32 uiIsAck)
{
    int32  ret;
    uint32 len;
    uint32 mmReg[IPI_MBOX_CFG_CMD_FIFO_SIZE];
    uint32* mmDat = (uint32 *) pucBuff;
	uint8* shm_buffer;

    mmReg[0] = IPC_GetSequentialId(siCh);
    mmReg[1] = puiCmd[1];
    mmReg[2] = puiCmd[2];
    mmReg[3] = puiCmd[3];
    mmReg[4] = puiCmd[4];
    mmReg[5] = puiCmd[5];

    if(uiIsAck == IPC_O_ACK)
    {
        IPC_CmdWakePreSet(siCh, WRITE_CMD, mmReg[0]);
    }

	if(gIPCHandler[siCh].ihIpcOption.isShm == 0)
	{
	    len = ((uiSize % 4U) == 0U) ? (uiSize / 4U) : ((uiSize / 4U) + 1U);

	    if ((len > 0U) && (len <= IPI_MBOX_CFG_DATA_FIFO_SIZE))
	    { 	    	
	        ret = ipi_mailbox_send_message(siCh, mmReg, mmDat, (int32) len);
    	}
	    else
	    {
	        ret = IPC_ERR_INVALID_DL;
	    }
	}
	else
	{
		if ((uiSize > 0U) && (uiSize <= gIPCHandler[siCh].Ipc_Max_Packet_Size))
		{
			shm_buffer = (uint8 *)gIPCHandler[siCh].writeBuffer.startAddr;

			// Data
			SAL_MemCopy(shm_buffer, pucBuff, uiSize);		

			// Cmd
			ret = ipi_mailbox_send_command(siCh, mmReg);
		}
		else
	    {
	        ret = IPC_ERR_INVALID_DL;
	    }
	}

    if((uiIsAck == IPC_O_ACK) && (ret == IPC_SUCCESS))
    {	   
        ret = IPC_CmdWaitEventTimeOut(siCh, WRITE_CMD,ACK_TIMEOUT);
    }

    return ret;
}


/**************************************************************************************************
*                               IPC_SendPing
*
* [External] Send IPC Ping
*
* @param        siCh
* @return       IPC_Ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_SendPing(    IPCSvcCh_t siCh)
{
    int32 ret;
    uint32 mmReg[IPI_MBOX_CFG_CMD_FIFO_SIZE];

    mmReg[0] = IPC_GetSequentialId(siCh);
    mmReg[1] = ((uint32) CTL_CMD << 16U) | ((uint32) IPC_SEND_PING);
    mmReg[2] = 0;
    mmReg[3] = 0;
    mmReg[4] = 0;

    IPC_CmdWakePreSet(siCh, CTL_CMD, mmReg[0]);
    ret = ipi_mailbox_send_command(siCh, mmReg);

    if(ret == IPC_SUCCESS)
    {
        ret = IPC_CmdWaitEventTimeOut(siCh, CTL_CMD, ACK_TIMEOUT);
    }

    return ret;
}

/**************************************************************************************************
*                               IPC_SendAck
*
* [External] Send IPC Ack
*
* @param        siCh, uiSeqID, uiCmdID, cmdType, uiSourcCmd, feature
* @return       IPC_Ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_SendAck(    IPCSvcCh_t siCh, uint32 uiSeqID, IPCCmdId_t uiCmdID, IPCCmdType_t cmdType, uint32 uiSourcCmd, uint32 feature)
{
    int32 ret;
    uint32 mmReg[IPI_MBOX_CFG_CMD_FIFO_SIZE];

    mmReg[0] = uiSeqID;
    mmReg[1] = ((uint32) cmdType << 16U) | ((uint32) uiCmdID);
    mmReg[2] = uiSourcCmd;
    mmReg[3] = feature;
    mmReg[4] = 0;
    mmReg[5] = 0;

    ret = ipi_mailbox_send_command(siCh, mmReg);

    return ret;
}






