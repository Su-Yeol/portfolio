###################################################################################################
#
#   FileName : ruls.mk
#
#   Copyright (c) Telechips Inc.
#
#   Description :
#
#
###################################################################################################
#
#   TCC Version 1.0
#
#   This source code contains confidential information of Telechips.
#
#   Any unauthorized use without a written permission of Telechips including not limited to
#   re-distribution in source or binary form is strictly prohibited.
#
#   This source code is provided "AS IS" and nothing contained in this source code shall constitute
#   any express or implied warranty of any kind, including without limitation, any warranty of
#   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
#   or other third party intellectual property right. No warranty is made, express or implied,
#   regarding the information's accuracy,completeness, or performance.
#
#   In no event shall Telechips be liable for any claim, damages or other liability arising from,
#   out of or in connection with this source code or the use in the source code.
#
#   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
#   Telechips and Company.
#   This source code is provided "AS IS" and nothing contained in this source code shall constitute
#   any express or implied warranty of any kind, including without limitation, any warranty
#   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
#   copyright or other third party intellectual property right. No warranty is made, express or
#   implied, regarding the information's accuracy, completeness, or performance.
#   In no event shall Telechips be liable for any claim, damages or other liability arising from,
#   out of or in connection with this source code or the use in the source code.
#   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
#   between Telechips and Company.
#
###################################################################################################

SIC_BSP_APP_DRIVERS_IPC_PATH := $(SIC_BSP_BUILD_CURDIR)
SIC_BSP_APP_DRIVERS_IPC_COMMON_PATH := $(SIC_BSP_BUILD_CURDIR)common

# Flags
COMMON_FLAGS += -DSIC_BSP_SUPPORT_DRIVER_IPC=1

# Paths
VPATH += $(SIC_BSP_APP_DRIVERS_IPC_PATH)
VPATH += $(SIC_BSP_APP_DRIVERS_IPC_PATH)$(SIC_BSP_CHIPSET_FAMILY_NAME)
VPATH += $(SIC_BSP_APP_DRIVERS_IPC_COMMON_PATH)

# Includes
INCLUDES += -I$(SIC_BSP_APP_DRIVERS_IPC_PATH)
INCLUDES += -I$(SIC_BSP_APP_DRIVERS_IPC_PATH)$(SIC_BSP_CHIPSET_FAMILY_NAME)
INCLUDES += -I$(SIC_BSP_APP_DRIVERS_IPC_COMMON_PATH)

# Sources
SRCS += ipc_os.c
SRCS += ipc_buffer.c
SRCS += ipc_cmd.c
SRCS += ipc_ctl.c
SRCS += ipc_parser.c
SRCS += ipc_api.c
SRCS += ipc.c

