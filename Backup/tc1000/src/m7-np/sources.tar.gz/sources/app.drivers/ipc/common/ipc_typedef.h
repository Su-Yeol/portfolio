/*
***************************************************************************************************
*
*   FileName : ipc_typedef.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef IPC_TYPE_DEF_H
#define IPC_TYPE_DEF_H

#if (DEBUG_ENABLE)
#include "debug.h"
#define IPC_DBG(fmt, args...)           {LOGD(DBG_TAG_MBOX, fmt, ## args)}
#define IPC_ERR(fmt, args...)           {LOGE(DBG_TAG_MBOX, fmt, ## args)}
#else
#define IPC_DBG(fmt, args...)
#define IPC_ERR(fmt, args...)
#endif

/****************************************
 *				Defines					*
****************************************/
#define IPC_SUCCESS                     (0)              /* Success */
#define IPC_ERR_COMMON                  (-1)             /* common error*/
#define IPC_ERR_BUSY                    (-2)             /* IPC is busy. You got the return, After a while you should try.*/
#define IPC_ERR_NOTREADY                (-3)             /* IPC is not ready. Other processor is not ready yet.*/
#define IPC_ERR_TIMEOUT                 (-4)             /* Other process is not responding. */
#define IPC_ERR_WRITE                   (-5)
#define IPC_ERR_READ                    (-6)
#define IPC_ERR_BUFFER                  (-7)
#define IPC_ERR_ARGUMENT                (-8)             /* Invalid argument */
#define IPC_ERR_RECEIVER_NOT_SET        (-9)             /* Receiver processor not set */
#define IPC_ERR_RECEIVER_DOWN           (-10)            /* Mbox is not set */
#define IPC_ERR_RECV_NACK               (-11)            /* AP sent NACK */
#define IPC_ERR_INVALID_DL              (-800)
#define IPC_ERR_NOT_SUPPORTED           (-900)

#define IPC_FLAG_USENAMCK               (0x00000001U)
#define IPC_NACK_REASON_BUFFFUL         (0x00000001U)
#define IPC_NACK_REASON_BUFFERR         (0x00000002U)

/*********IPC Protocol*********/
#define IPC_SYNC                        (0xFF)
#define IPC_START1                      (0x55)
#define IPC_START2                      (0xAA)
#define IPC_RESERVED1                   (0x00)
#define IPC_RESERVED2                   (0x00)
#define IPC_RESERVED3                   (0x00)
//
//  SYNC: 1byte ,  START1: 1byte ,  START2: 1byte ,  CMD1: 2byte ,  CMD2: 2byte ,  LENGTH: 2byte ,  DATA: variable ,  CRC: 2byte
//

/*********Packet Size*********/
#define IPC_SHM_MAX_PACKET_SIZE			(2048U)
#define IPC_MBOX_MAX_PACKET_SIZE		(512U)

#define MAX_IPC_PACKET_SIZE				(IPC_SHM_MAX_PACKET_SIZE)   // 2048
#define MAX_IPC_RING_BUFF_SIZE          (8192U)

#define IPC_PACKET_PREPARE_SIZE         (0x09)
#define IPC_PACKET_PREFIX_SIZE          (0x0B)    // 11
#define IPC_PROCESS_NUM                 (0x100)   // 256


/***********IPC SHM Address Definition****************/
#define IPC_SHM_SRAM_SIZE_per_Ch		(4096UL) // 4k
#define IPC_SHM_SRAM_SIZE_per_Core		(IPC_SHM_SRAM_SIZE_per_Ch * 4U)	// 16k
#define IPC_SHM_SRAM_Start_ADDR			(0x306E0000UL)

#define IPC_SHM_SRAM_Start_ADDR_CA65	(IPC_SHM_SRAM_Start_ADDR)
#define IPC_SHM_SRAM_Start_ADDR_CM7_0	(IPC_SHM_SRAM_Start_ADDR + IPC_SHM_SRAM_SIZE_per_Core)
#define IPC_SHM_SRAM_Start_ADDR_CM7_1	(IPC_SHM_SRAM_Start_ADDR + (IPC_SHM_SRAM_SIZE_per_Core * 2U))
#define IPC_SHM_SRAM_Start_ADDR_CM7_2   (IPC_SHM_SRAM_Start_ADDR + (IPC_SHM_SRAM_SIZE_per_Core * 3U))
#define IPC_SHM_SRAM_Start_ADDR_CM7_NP  (IPC_SHM_SRAM_Start_ADDR + (IPC_SHM_SRAM_SIZE_per_Core * 4U))

#if (CORTEX_M7_0 == 1)
#define IPC_SHARE_CM0_TXTO_CA65_MEM_START_ADDR  	(IPC_SHM_SRAM_Start_ADDR_CM7_0)
#define IPC_SHARE_CM0_TXTO_CM1_MEM_START_ADDR 		(IPC_SHM_SRAM_Start_ADDR_CM7_0 + IPC_SHM_SRAM_SIZE_per_Ch)
#define IPC_SHARE_CM0_TXTO_CM2_MEM_START_ADDR		(IPC_SHM_SRAM_Start_ADDR_CM7_0 + (IPC_SHM_SRAM_SIZE_per_Ch * 2U)) 
#define IPC_SHARE_CM0_TXTO_CMN_MEM_START_ADDR		(IPC_SHM_SRAM_Start_ADDR_CM7_0 + (IPC_SHM_SRAM_SIZE_per_Ch * 3U))

#define IPC_SHARE_CM0_RXFR_CA65_MEM_START_ADDR  	(IPC_SHM_SRAM_Start_ADDR_CA65)
#define IPC_SHARE_CM0_RXFR_CM1_MEM_START_ADDR   	(IPC_SHM_SRAM_Start_ADDR_CM7_1 + IPC_SHM_SRAM_SIZE_per_Ch)
#define IPC_SHARE_CM0_RXFR_CM2_MEM_START_ADDR 	 	(IPC_SHM_SRAM_Start_ADDR_CM7_2 + IPC_SHM_SRAM_SIZE_per_Ch)
#define IPC_SHARE_CM0_RXFR_CMN_MEM_START_ADDR  		(IPC_SHM_SRAM_Start_ADDR_CM7_NP + IPC_SHM_SRAM_SIZE_per_Ch)

#elif (CORTEX_M7_1 == 1)
#define IPC_SHARE_CM1_TXTO_CA65_MEM_START_ADDR  	(IPC_SHM_SRAM_Start_ADDR_CM7_1)
#define IPC_SHARE_CM1_TXTO_CM0_MEM_START_ADDR 		(IPC_SHM_SRAM_Start_ADDR_CM7_1 + IPC_SHM_SRAM_SIZE_per_Ch)
#define IPC_SHARE_CM1_TXTO_CM2_MEM_START_ADDR		(IPC_SHM_SRAM_Start_ADDR_CM7_1 + (IPC_SHM_SRAM_SIZE_per_Ch * 2U))
#define IPC_SHARE_CM1_TXTO_CMN_MEM_START_ADDR		(IPC_SHM_SRAM_Start_ADDR_CM7_1 + (IPC_SHM_SRAM_SIZE_per_Ch * 3U))

#define IPC_SHARE_CM1_RXFR_CA65_MEM_START_ADDR  	(IPC_SHM_SRAM_Start_ADDR_CA65 + IPC_SHM_SRAM_SIZE_per_Ch)
#define IPC_SHARE_CM1_RXFR_CM0_MEM_START_ADDR   	(IPC_SHM_SRAM_Start_ADDR_CM7_0 + IPC_SHM_SRAM_SIZE_per_Ch)
#define IPC_SHARE_CM1_RXFR_CM2_MEM_START_ADDR 	 	(IPC_SHM_SRAM_Start_ADDR_CM7_2 + (IPC_SHM_SRAM_SIZE_per_Ch * 2U))
#define IPC_SHARE_CM1_RXFR_CMN_MEM_START_ADDR  		(IPC_SHM_SRAM_Start_ADDR_CM7_NP + (IPC_SHM_SRAM_SIZE_per_Ch * 2U))

#elif (CORTEX_M7_2 == 1)
#define IPC_SHARE_CM2_TXTO_CA65_MEM_START_ADDR  	(IPC_SHM_SRAM_Start_ADDR_CM7_2)
#define IPC_SHARE_CM2_TXTO_CM0_MEM_START_ADDR 		(IPC_SHM_SRAM_Start_ADDR_CM7_2 + IPC_SHM_SRAM_SIZE_per_Ch)
#define IPC_SHARE_CM2_TXTO_CM1_MEM_START_ADDR		(IPC_SHM_SRAM_Start_ADDR_CM7_2 + (IPC_SHM_SRAM_SIZE_per_Ch * 2U))  
#define IPC_SHARE_CM2_TXTO_CMN_MEM_START_ADDR		(IPC_SHM_SRAM_Start_ADDR_CM7_2 + (IPC_SHM_SRAM_SIZE_per_Ch * 3U))

#define IPC_SHARE_CM2_RXFR_CA65_MEM_START_ADDR  	(IPC_SHM_SRAM_Start_ADDR_CA65 + (IPC_SHM_SRAM_SIZE_per_Ch * 2U))
#define IPC_SHARE_CM2_RXFR_CM0_MEM_START_ADDR   	(IPC_SHM_SRAM_Start_ADDR_CM7_0 + (IPC_SHM_SRAM_SIZE_per_Ch * 2U))
#define IPC_SHARE_CM2_RXFR_CM1_MEM_START_ADDR 	 	(IPC_SHM_SRAM_Start_ADDR_CM7_1 + (IPC_SHM_SRAM_SIZE_per_Ch * 2U))
#define IPC_SHARE_CM2_RXFR_CMN_MEM_START_ADDR  		(IPC_SHM_SRAM_Start_ADDR_CM7_NP + (IPC_SHM_SRAM_SIZE_per_Ch * 3U))

#elif (CORTEX_M7_NP == 1)
#define IPC_SHARE_CMN_TXTO_CA65_MEM_START_ADDR  	(IPC_SHM_SRAM_Start_ADDR_CM7_NP)
#define IPC_SHARE_CMN_TXTO_CM0_MEM_START_ADDR 		(IPC_SHM_SRAM_Start_ADDR_CM7_NP + IPC_SHM_SRAM_SIZE_per_Ch)
#define IPC_SHARE_CMN_TXTO_CM1_MEM_START_ADDR		(IPC_SHM_SRAM_Start_ADDR_CM7_NP + (IPC_SHM_SRAM_SIZE_per_Ch * 2U))  
#define IPC_SHARE_CMN_TXTO_CM2_MEM_START_ADDR		(IPC_SHM_SRAM_Start_ADDR_CM7_NP + (IPC_SHM_SRAM_SIZE_per_Ch * 3U))

#define IPC_SHARE_CMN_RXFR_CA65_MEM_START_ADDR  	(IPC_SHM_SRAM_Start_ADDR_CA65 + (IPC_SHM_SRAM_SIZE_per_Ch * 3U))
#define IPC_SHARE_CMN_RXFR_CM0_MEM_START_ADDR   	(IPC_SHM_SRAM_Start_ADDR_CM7_0 + (IPC_SHM_SRAM_SIZE_per_Ch * 3U))
#define IPC_SHARE_CMN_RXFR_CM1_MEM_START_ADDR 	 	(IPC_SHM_SRAM_Start_ADDR_CM7_1 + (IPC_SHM_SRAM_SIZE_per_Ch * 3U))
#define IPC_SHARE_CMN_RXFR_CM2_MEM_START_ADDR  		(IPC_SHM_SRAM_Start_ADDR_CM7_2 + (IPC_SHM_SRAM_SIZE_per_Ch * 3U))
#endif


/****************************************
 *				Enumeration				*
****************************************/
// IPC Channel
typedef enum IPCSvcCh
{
	IPC_CH_CA65_NS_USER   = 0x00UL,
	IPC_CH_CA65_NS_TPA,
	IPC_CH_CA65_NS_LPA,

#if (CORTEX_M7_0 == 0)
	IPC_CH_CM7_0_USER,
	IPC_CH_CM7_0_TPA,
	IPC_CH_CM7_0_LPA,
#endif

#if (CORTEX_M7_1 == 0)	
	IPC_CH_CM7_1_USER,
	IPC_CH_CM7_1_TPA,
	IPC_CH_CM7_1_LPA,
#endif

#if (CORTEX_M7_2 == 0)	
	IPC_CH_CM7_2_USER,
	IPC_CH_CM7_2_TPA,
	IPC_CH_CM7_2_LPA,
#endif

#if (CORTEX_M7_NP == 0)	
	IPC_CH_CM7_NP_USER,
	IPC_CH_CM7_NP_TPA,
	IPC_CH_CM7_NP_LPA,
#endif

	IPC_SVC_CH_MAX
} IPCSvcCh_t;

// IPC Command
typedef enum IPCCmdType
{
    CTL_CMD                             = 0x0000UL,
    WRITE_CMD,
    MAX_CMD_TYPE,
} IPCCmdType_t;
	
// IPC Command ID
typedef enum IPCCmdId
{
    /* control command */
    IPC_INVALID                         = 0x0000UL,
    IPC_OPEN                            = 0x0001UL,
    IPC_CLOSE,
    IPC_SEND_PING,
    IPC_WRITE,
    IPC_ACK,
    IPC_NACK,
    MAX_CMD_ID,
} IPCCmdId_t;

// IPC IOCtl Command
typedef enum IPCIoCmd
{
    IOCTL_IPC_WRITE                     = 0,
    IOCTL_IPC_READ                      = 1,
    IOCTL_IPC_SET_PARAM                 = 2,
    IOCTL_IPC_GET_PARAM                 = 3,
    IOCTL_IPC_PING_TEST                 = 4,
    IOCTL_IPC_FLUSH                     = 5,
    IOCTL_IPC_ISREADY                   = 6,
} IPCIoCmd_t;

// IPC Channel Status
typedef enum IPCStatus
{
    IPC_NULL                            = 0,
    IPC_INIT,
    IPC_OPENED,
    IPC_READY,                                 /*Buffer setting completed*/
    IPC_MAX_STATUS,
} IPCStatus_t;

// IPC Ping Error Code
typedef enum IPCPingError
{
    IPC_PING_SUCCESS                    = 0,             /* Ping success */
    IPC_PING_ERR_INIT,                                   /* My ipc initialize failed */
    IPC_PING_ERR_NOT_READY,                              /* Other IPC not open */
    IPC_PING_ERR_SENDER_MBOX,                            /* My(sender) mbox is not set or error */
    IPC_PING_ERR_RECEIVER_MBOX,                          /* Receiver mbox is not set or error*/
    IPC_PING_ERR_SEND,                                   /* Can not send data. Maybe receiver mbox interrupt is busy*/
    IPC_PING_ERR_RESPOND,                                /* Receiver does not send respond data. */
    MAX_IPC_PING_ERR,
} IPCPingError_t;


/****************************************
 *				Typedefs				*
****************************************/
// IPC Option
typedef struct IPCOption
{
    uint32                              isBlock;
    uint32                              isAck;
    uint32                              isShm;	
} IPCOption_t;

// IPC Block Mode Parameter
typedef struct IPCCtlParam
{
    uint32                              vMin;            /* Timeout in deciseconds  when blocking mode*/
    uint32                              vTime;           /* Minimum number of characters when blocking mode */
} __attribute__((packed)) IPCCtlParam_t;

// IPC Ring Buffer
typedef struct IPCRingBuff
{
    uint32                              rbHead;     //read position
    uint32                              rbTail;     //write position
    uint32                              rbMaxBufferSize;
    uint8 *                             rbBuffer;
}IPCRingBuff_t;


// IPC SHM Buffer Info
// for SHM mode
typedef struct IpcBufferInfo{
	uint32	startAddr;
	uint32 	bufferSize;
}IpcBufferInfo_t;


// IPC Hnadler
typedef struct IPCHandler
{
    IPCStatus_t                         ihIpcStatus;
    IPCRingBuff_t                       ihReadRingBuffer;
    uint32                              ihIsWait;
    uint32                              ihTime;
    uint32                              ihMin;
    IPCCtlParam_t                       ihSetParam;
    IPCOption_t                         ihIpcOption;
    uint32                              feature;

// for SHM mode		
    IpcBufferInfo_t                     writeBuffer;
    IpcBufferInfo_t                     receiveBuffer;

	uint32								Ipc_Max_Packet_Size;
} IPCHandler_t;

// IPC Ping Info
typedef struct IPCPingInfo
{
    IPCPingError_t                      piPingResult;
    uint32                              piSendByte;
    uint32                              piResponseTime;
    uint32                              piCompareResult; /*Data compare results. */
} __attribute__((packed)) IPCPingInfo_t;

// IPC Callback function Definition
typedef void (*IPCCallback)(    uint16 uiCmd, uint8* pucData, uint16 uiLength);

typedef struct IPCCbFunc
{
    IPCCallback                         ipcCbFunc;
    void*                               ipcArg1;
    void*                               ipcArg2;
} IPCCbFunc_t;


#endif /* _IPC_TYPE_DEF_H_ */

