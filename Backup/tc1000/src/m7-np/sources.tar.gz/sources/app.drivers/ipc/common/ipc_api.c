/*
***************************************************************************************************
*
*   FileName : ipc_api.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/****************************************
 *				Include					*
 ****************************************/
#include "ipi.h"
#include "ipc_api.h"
#include "ipc_ctl.h"
#include "ipc_os.h"


/****************************************
 *		  Variable Definitions			*
 ****************************************/
static IPCChStatus_t    ipcChStatus[IPC_SVC_CH_MAX] = {0, };


/***************************************************
*          Local function prototypes               *
****************************************************/


/**************************************************************************************************
*                                          IPC Open
*
* [External] Open Ipc channel
*
* @param        siCh, uiOptions
* @return       Ipc_ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_Open(uint32 siCh,    uint32 uiOptions)
{
    int32 lRet;

    (void) SAL_CoreCriticalEnter();
    gIPCHandler[siCh].ihIpcOption.isBlock = (uint32)(uiOptions & IPC_O_BLOCK_MASK);
    gIPCHandler[siCh].ihIpcOption.isAck   = (uint32)((uiOptions & IPC_O_ACK_MASK) >> 8U);
	gIPCHandler[siCh].ihIpcOption.isShm   = (uint32)((uiOptions & IPC_O_SHM_MASK) >> 16U);
	
    if(ipcChStatus[siCh].gIPCChIsOpen == 0U)
    {
        lRet = IPC_SUCCESS;
    }
    else
    {
        lRet = IPC_ERR_BUSY;
    }
    (void) SAL_CoreCriticalExit();


    if(lRet == IPC_SUCCESS)
    {
		ipi_register(siCh,Ipi_rx_cb_func[siCh]);
	
        IPC_StructInit((IPCSvcCh_t) siCh, &gIPCHandler[siCh]);

        // open driver
        lRet = IPC_Initialize((IPCSvcCh_t) siCh);

        if(lRet != IPC_SUCCESS)
        {
            lRet = IPC_ERR_NOTREADY;
        }
		else
        {
            ipcChStatus[siCh].gIPCChStatus = IPC_DEVICE_ST_OPENED;
            (void) SAL_CoreCriticalEnter();
            ipcChStatus[siCh].gIPCChCallCount   = 0;
            ipcChStatus[siCh].gIPCChIsOpen      = 1;
            (void) SAL_CoreCriticalExit();
        }
    }

    return lRet;
}

/**************************************************************************************************
*                                          IPC Close
*
* [External] Close Ipc channel
*
* @param        siCh
* @return       Ipc_ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_Close(    uint32 siCh)
{
    int32  lRet;
    uint32 isOpen;
    uint32 callCount;

    lRet = IPC_SUCCESS;

    if (ipcChStatus[siCh].gIPCChStatus != IPC_DEVICE_ST_OPENED)
    {
        lRet = IPC_ERR_NOTREADY;
    }
    else
    {
        ipcChStatus[siCh].gIPCChStatus = IPC_DEVICE_ST_NO_OPEN;

        //close driver
        (void) SAL_CoreCriticalEnter();
        isOpen      = ipcChStatus[siCh].gIPCChIsOpen;
        callCount   = ipcChStatus[siCh].gIPCChCallCount;
        (void) SAL_CoreCriticalExit();

        if((isOpen == 1U ) && (callCount == 0U))
        {
            IPC_Release((IPCSvcCh_t) siCh);
            (void) SAL_CoreCriticalEnter();
            ipcChStatus[siCh].gIPCChIsOpen = 0U;
            (void) SAL_CoreCriticalExit();
        }
        else if (callCount != 0U)
        {
            lRet = IPC_ERR_BUSY;
        }
        else
        {
            lRet = IPC_ERR_COMMON;
        }
    }

    return lRet;
}


/**************************************************************************************************
*                                          IPC Calculate Crc16
*
* [External] Calculate CRC16
*
* @param        pucBuffer, uiLength, uiInit
* @return       crcCode
*
* Notes
*
***************************************************************************************************/
uint16 IPC_CalcCrc16(    const uint8* pucBuffer,  uint32 uiLength, uint16 uiInit)
{
    uint32 i;
    uint16 temp;
    uint16 crcCode;
    static const uint16 crc16Table[256] =
    {
        0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50a5, 0x60c6, 0x70e7,
        0x8108, 0x9129, 0xa14a, 0xb16b, 0xc18c, 0xd1ad, 0xe1ce, 0xf1ef,
        0x1231, 0x0210, 0x3273, 0x2252, 0x52b5, 0x4294, 0x72f7, 0x62d6,
        0x9339, 0x8318, 0xb37b, 0xa35a, 0xd3bd, 0xc39c, 0xf3ff, 0xe3de,
        0x2462, 0x3443, 0x0420, 0x1401, 0x64e6, 0x74c7, 0x44a4, 0x5485,
        0xa56a, 0xb54b, 0x8528, 0x9509, 0xe5ee, 0xf5cf, 0xc5ac, 0xd58d,
        0x3653, 0x2672, 0x1611, 0x0630, 0x76d7, 0x66f6, 0x5695, 0x46b4,
        0xb75b, 0xa77a, 0x9719, 0x8738, 0xf7df, 0xe7fe, 0xd79d, 0xc7bc,
        0x48c4, 0x58e5, 0x6886, 0x78a7, 0x0840, 0x1861, 0x2802, 0x3823,
        0xc9cc, 0xd9ed, 0xe98e, 0xf9af, 0x8948, 0x9969, 0xa90a, 0xb92b,
        0x5af5, 0x4ad4, 0x7ab7, 0x6a96, 0x1a71, 0x0a50, 0x3a33, 0x2a12,
        0xdbfd, 0xcbdc, 0xfbbf, 0xeb9e, 0x9b79, 0x8b58, 0xbb3b, 0xab1a,
        0x6ca6, 0x7c87, 0x4ce4, 0x5cc5, 0x2c22, 0x3c03, 0x0c60, 0x1c41,
        0xedae, 0xfd8f, 0xcdec, 0xddcd, 0xad2a, 0xbd0b, 0x8d68, 0x9d49,
        0x7e97, 0x6eb6, 0x5ed5, 0x4ef4, 0x3e13, 0x2e32, 0x1e51, 0x0e70,
        0xff9f, 0xefbe, 0xdfdd, 0xcffc, 0xbf1b, 0xaf3a, 0x9f59, 0x8f78,
        0x9188, 0x81a9, 0xb1ca, 0xa1eb, 0xd10c, 0xc12d, 0xf14e, 0xe16f,
        0x1080, 0x00a1, 0x30c2, 0x20e3, 0x5004, 0x4025, 0x7046, 0x6067,
        0x83b9, 0x9398, 0xa3fb, 0xb3da, 0xc33d, 0xd31c, 0xe37f, 0xf35e,
        0x02b1, 0x1290, 0x22f3, 0x32d2, 0x4235, 0x5214, 0x6277, 0x7256,
        0xb5ea, 0xa5cb, 0x95a8, 0x8589, 0xf56e, 0xe54f, 0xd52c, 0xc50d,
        0x34e2, 0x24c3, 0x14a0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
        0xa7db, 0xb7fa, 0x8799, 0x97b8, 0xe75f, 0xf77e, 0xc71d, 0xd73c,
        0x26d3, 0x36f2, 0x0691, 0x16b0, 0x6657, 0x7676, 0x4615, 0x5634,
        0xd94c, 0xc96d, 0xf90e, 0xe92f, 0x99c8, 0x89e9, 0xb98a, 0xa9ab,
        0x5844, 0x4865, 0x7806, 0x6827, 0x18c0, 0x08e1, 0x3882, 0x28a3,
        0xcb7d, 0xdb5c, 0xeb3f, 0xfb1e, 0x8bf9, 0x9bd8, 0xabbb, 0xbb9a,
        0x4a75, 0x5a54, 0x6a37, 0x7a16, 0x0af1, 0x1ad0, 0x2ab3, 0x3a92,
        0xfd2e, 0xed0f, 0xdd6c, 0xcd4d, 0xbdaa, 0xad8b, 0x9de8, 0x8dc9,
        0x7c26, 0x6c07, 0x5c64, 0x4c45, 0x3ca2, 0x2c83, 0x1ce0, 0x0cc1,
        0xef1f, 0xff3e, 0xcf5d, 0xdf7c, 0xaf9b, 0xbfba, 0x8fd9, 0x9ff8,
        0x6e17, 0x7e36, 0x4e55, 0x5e74, 0x2e93, 0x3eb2, 0x0ed1, 0x1ef0
    };

    crcCode = uiInit;

    if (pucBuffer != NULL_PTR)
    {
        for (i = 0; i < uiLength; i++)
        {
            temp    = (((crcCode & (uint16) 0xFF00) >> (uint16) 8) ^ pucBuffer[i]) & ((uint16) 0x00FF);
            crcCode = (crc16Table[temp] ^ ((crcCode & (uint16) 0x00FF) << (uint16) 8)) & ((uint16) 0xFFFF);
        }
    }

    return crcCode;
}


/**************************************************************************************************
*                                          IPC Ioctl
*
* [External] IPC Iocmd processing
*
* @param        siCh, uiOpt, pPar1,2,3,4
* @return       Ipc_ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_Ioctl(   uint32 siCh, IPCIoCmd_t uiOpt, void* pPar1, void* pPar2, const void* pPar3, const void* pPar4)
{
    int32           lRet;
    uint8 *         buff;
    uint32          isOpen;
    uint32          size;
    uint32 *        isReady;
    IPCPingInfo_t   pingInfo;
    const uint32 *  cmd;

    (void) pPar4;

    cmd  = NULL;
    buff = NULL;
    lRet = IPC_SUCCESS;
    size = 0UL;
    isReady = NULL;

    if (ipcChStatus[siCh].gIPCChStatus != IPC_DEVICE_ST_OPENED)
    {
        lRet = IPC_ERR_NOTREADY;
    }
    else
    {
        (void) SAL_CoreCriticalEnter();
        isOpen = ipcChStatus[siCh].gIPCChIsOpen;
        ipcChStatus[siCh].gIPCChCallCount++;
        (void) SAL_CoreCriticalExit();

        if(isOpen == 1U)
        {
            switch (uiOpt)
            {
                case IOCTL_IPC_WRITE:
                {
                    if((pPar1 != NULL_PTR) && (pPar2 != NULL_PTR))
                    {                   	
                        (void) SAL_MemCopy(&cmd,  &pPar1, sizeof(void *));
                        (void) SAL_MemCopy(&buff, &pPar2, sizeof(void *));
                        (void) SAL_MemCopy(&size, pPar3, sizeof(uint32));
				
                        lRet = IPC_Write((IPCSvcCh_t) siCh, cmd, buff, size);

                        if(lRet < IPC_SUCCESS)
                        {
                            lRet = IPC_ERR_COMMON;
                        }
                        else
                        {
                            lRet = IPC_SUCCESS;
                        }
                    }
                    else
                    {
                        lRet = IPC_ERR_ARGUMENT;
                    }

                    break;
                }

                case IOCTL_IPC_READ:
                {
                    if ((pPar1 != NULL_PTR) && (pPar2 != NULL_PTR))
                    {
                        (void) SAL_MemCopy(&buff, &pPar1, sizeof(void *));
                        (void) SAL_MemCopy(&size, pPar2, sizeof(uint32));
                        (void) SAL_CoreCriticalEnter();
                        isOpen = ipcChStatus[siCh].gIPCChIsOpen;
                        ipcChStatus[siCh].gIPCChCallCount++;
                        (void) SAL_CoreCriticalExit();
						
                        if(isOpen == 1U)
                        {
                            lRet = IPC_Read((IPCSvcCh_t) siCh, buff, size, gIPCHandler[siCh].ihIpcOption.isBlock);
                        }
                        else
                        {
                            lRet = IPC_ERR_COMMON;
                        }

                        (void) SAL_CoreCriticalEnter();
                        ipcChStatus[siCh].gIPCChCallCount--;
                        (void) SAL_CoreCriticalExit();
                    }
                    else
                    {
                        lRet = IPC_ERR_ARGUMENT;
                    }

                    break;
                }

                case IOCTL_IPC_SET_PARAM:
                {
                    if((pPar1 != NULL_PTR) && (pPar2 != NULL_PTR))
                    {
                        IPC_CommonLock((IPCSvcCh_t) siCh);
                        (void) SAL_MemCopy(&gIPCHandler[siCh].ihSetParam.vTime, pPar1, sizeof(uint32));
                        (void) SAL_MemCopy(&gIPCHandler[siCh].ihSetParam.vMin, pPar2, sizeof(uint32));
                        IPC_CommonUnlock((IPCSvcCh_t) siCh);
                    }
                    else
                    {
                        lRet = IPC_ERR_ARGUMENT;
                    }

                    break;
                }

                case IOCTL_IPC_GET_PARAM:
                {
                    if((pPar1 != NULL_PTR) && (pPar2 != NULL_PTR))
                    {
                        IPC_CommonLock((IPCSvcCh_t) siCh);
                        (void) SAL_MemCopy(pPar1, &gIPCHandler[siCh].ihSetParam.vTime, sizeof(uint32));
                        (void) SAL_MemCopy(pPar2, &gIPCHandler[siCh].ihSetParam.vMin, sizeof(uint32));
                        IPC_CommonUnlock((IPCSvcCh_t) siCh);
                    }
                    else
                    {
                        lRet = IPC_ERR_ARGUMENT;
                    }

                    break;
                }

                case IOCTL_IPC_PING_TEST:
                {
                    pingInfo.piPingResult    = IPC_PING_ERR_INIT;
                    pingInfo.piSendByte      = 0;
                    pingInfo.piResponseTime  = 0;
                    pingInfo.piCompareResult = 0;

                    (void) IPC_PingTest((IPCSvcCh_t) siCh, &pingInfo);

                    if(pingInfo.piPingResult == IPC_PING_SUCCESS)
                    {
                        IPC_DBG("CA65 result value : %d\n", pingInfo.piPingResult);
                        IPC_DBG("CA65 response time : %d\n", pingInfo.piResponseTime);
                    }
                    else
                    {
                        lRet = IPC_ERR_COMMON;
                    }

                    break;
                }

                case IOCTL_IPC_ISREADY:
                {
                    if(pPar1 != NULL_PTR)
                    {
                        (void) SAL_MemCopy(&isReady, &pPar1, sizeof(void *));

                        if(gIPCHandler[siCh].ihIpcStatus < IPC_READY)
                        {
                            if (isReady != NULL)
                            {
                                *isReady = 0;
                            }
                        }
                        else
                        {
                            if (isReady != NULL)
                            {
                                *isReady = 1;
                            }
                        }
                    }
                    else
                    {
                        lRet = IPC_ERR_ARGUMENT;
                    }

                    break;
                }

                default:
                {
                    lRet = IPC_ERR_ARGUMENT;
                    break;
                }
            }
        }
        else
        {
            lRet = IPC_ERR_COMMON;
        }

        (void) SAL_CoreCriticalEnter();
        ipcChStatus[siCh].gIPCChCallCount--;
        (void) SAL_CoreCriticalExit();
    }

    return lRet;
}

/**************************************************************************************************
*                                     IPC_SendPacketWithIPCHeader
*
* [External] Send Packet
*
* @param        siCh, uiCmd1,2, pucData, uiLength
* @return       Ipc_ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_SendPacketWithIPCHeader(    IPCSvcCh_t siCh, uint16 uiCmd1, uint16 uiCmd2, const uint8* pucData, uint16 uiLength)
{
    int32  ret;
    uint16 cnt;
    uint16 crc;
    uint32 packet_size;
    uint32 cmd[8];
    static uint8 packet_send[MAX_IPC_PACKET_SIZE];

    ret         = 0;
    cnt         = 0;
    crc         = 0;
    packet_size = 0;
	
    // packaging the ipc packet
    IPC_WriteLock(siCh);
    packet_send[0] = IPC_SYNC;
    packet_send[1] = IPC_START1;
    packet_send[2] = IPC_START2;
    packet_send[3] = (uint8) ((uiCmd1 & (uint16) 0xFF00) >> (uint16) 8);
    packet_send[4] = (uint8) (uiCmd1 & (uint16) 0x00FF);
    packet_send[5] = (uint8) ((uiCmd2 & (uint16) 0xFF00) >> (uint16) 8);
    packet_send[6] = (uint8) (uiCmd2 & (uint16) 0x00FF);
    packet_send[7] = (uint8) ((uiLength & (uint16) 0xFF00) >> (uint16) 8);
    packet_send[8] = (uint8) (uiLength & (uint8) 0x00FF);

    if ((uiLength == ((uint16) 0)) || (pucData == NULL_PTR))
    {
        packet_send[IPC_PACKET_PREPARE_SIZE] = 0; //dummy data
        cnt = 1; // dummy data length
        packet_size = IPC_PACKET_PREFIX_SIZE + 1;
    }
    else
    {
        for (cnt = 0; cnt < uiLength; cnt++)
        {
            packet_send[((uint16) IPC_PACKET_PREPARE_SIZE) + cnt] = pucData[cnt];
        }
        packet_size = (((uint32) IPC_PACKET_PREFIX_SIZE) + uiLength);
    }
	
    crc = IPC_CalcCrc16(&packet_send[0], (packet_size - 2U), 0);
    packet_send[((uint16) IPC_PACKET_PREPARE_SIZE) + cnt]               = (uint8) ((crc >> ((uint16) 8)) & ((uint16) 0xFF));
    packet_send[((uint16) IPC_PACKET_PREPARE_SIZE) + cnt + ((uint8) 1)] = (uint8) (crc & ((uint16) 0xFF));

    cmd[0] = 0; /* sequence ID */
    cmd[1] = (((uint32) WRITE_CMD) << 16U) | ((uint32) IPC_WRITE);
    cmd[2] = packet_size;
    cmd[3] = 0;
    cmd[4] = 0;
    cmd[5] = 0;

    // send the ipc packet
    ret = IPC_Ioctl((uint32) siCh, IOCTL_IPC_WRITE, (void *)&cmd[0], (void *)&packet_send[0], (void *)&packet_size, NULL_PTR);
    IPC_WriteUnlock(siCh);

    return ret;
}

