/*
***************************************************************************************************
*
*   FileName : ipc.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef IPC_API_H
#define IPC_API_H

#include "ipc_typedef.h"

/****************************************
 *				Defines					*
****************************************/

//IPC block or non block option
#define IPC_O_NONBLOCK                  (0x00000000U)
#define IPC_O_BLOCK                     (0x00000001U)

//IPC ack or non ack option
#define IPC_O_NONACK                    (0x00000000U)
#define IPC_O_ACK_BIT                   (0x00000100U)

//IPC shared or mbox option
#define IPC_O_MBOX                      (0x00000000U)
#define IPC_O_SHM                       (0x00010000U)

//IPC reserved0 option
#define IPC_O_RESERVED0                 (0x00000000U)

#define IPC_O_ACK                       (0x00000001U)
#define IPC_MODE_0_MBOX					(IPC_O_RESERVED0 | IPC_O_MBOX | IPC_O_ACK_BIT | IPC_O_NONBLOCK)
#define IPC_MODE_0_SHM					(IPC_O_RESERVED0 | IPC_O_SHM  | IPC_O_ACK_BIT | IPC_O_NONBLOCK)
#define IPC_MODE_1_MBOX					(IPC_O_RESERVED0 | IPC_O_MBOX | IPC_O_ACK_BIT | IPC_O_BLOCK)
#define IPC_MODE_1_SHM					(IPC_O_RESERVED0 | IPC_O_SHM  | IPC_O_ACK_BIT | IPC_O_BLOCK)

#define IPC_O_BLOCK_MASK				(0x000000FFU)
#define IPC_O_ACK_MASK					(0x0000FF00U)
#define IPC_O_SHM_MASK					(0x00FF0000U)

#define IPC_DEVICE_ST_NO_OPEN           (0UL)
#define IPC_DEVICE_ST_OPENED            (1UL)
#define IPC_DEVICE_ST_ENABLED           (2UL)
#define IPC_DEVICE_ST_DISABLED          (3UL)



/****************************************
 *				Enumeration				*
****************************************/


/****************************************
 *				Typedefs				*
****************************************/

typedef struct IPCChStatus
{
    uint32                              gIPCChStatus;
    uint32                              gIPCChIsOpen;
    uint32                              gIPCChCallCount;
} IPCChStatus_t;




/****************************************
 *		  Variable Definitions			*
 ****************************************/

/***************************************************
*		   		Function declaration				*
****************************************************/
int32 IPC_Open(uint32 siCh,    uint32 uiOptions);
int32 IPC_Close(    uint32 siCh);
int32 IPC_Ioctl(   uint32 siCh, IPCIoCmd_t uiOpt, void* pPar1, void* pPar2, const void* pPar3, const void* pPar4);
int32 IPC_SendPacketWithIPCHeader(    IPCSvcCh_t siCh, uint16        uiCmd1,uint16 uiCmd2, const uint8* pucData, uint16 uiLength);

uint16 IPC_CalcCrc16(    const uint8* pucBuffer,  uint32 uiLength, uint16 uiInit);




#endif /* _IPC_H_ */

