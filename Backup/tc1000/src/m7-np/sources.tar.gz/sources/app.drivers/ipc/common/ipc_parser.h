/*
***************************************************************************************************
*
*   FileName : ipc_parser.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef  IPC_PARSER_H
#define  IPC_PARSER_H

#include "ipc_typedef.h"

/****************************************
 *				Defines					*
****************************************/
#define IPC_PARSER_TASK_STK_SIZE        (256U)
#define IPC_OPEN_TASK_STK_SIZE          (128U)


/****************************************
 *				Typedefs				*
****************************************/
typedef struct IPCChInfo
{
    IPCSvcCh_t                          ipcCh;
    int32                               ipcHandle;
} IPCChInfo_t;



/****************************************
 *		  Variable Definitions			*
 ****************************************/
extern IPCCbFunc_t			cbFunc[IPC_SVC_CH_MAX][IPC_PROCESS_NUM];

/***************************************************
*		   		Function declaration				*
****************************************************/
void IPC_CreateIPCParserTask(    void);


#endif

