/*
***************************************************************************************************
*
*   FileName : ipc_ctl.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef IPC_CTL_H
#define IPC_CTL_H

#include "ipc_typedef.h"

/****************************************
 *				Defines					*
****************************************/
#define MAX_READ_TIMEOUT                (50)      //ms



/****************************************
 *				Enumeration				*
****************************************/



/****************************************
 *				Typedefs				*
****************************************/



/****************************************
 *		  Variable Definitions			*
 ****************************************/
extern IPCHandler_t	gIPCHandler[IPC_SVC_CH_MAX];
extern void *		Ipi_rx_cb_func[IPC_SVC_CH_MAX];



/***************************************************
*		   		Function declaration				*
****************************************************/
int32 IPC_Write(    IPCSvcCh_t siCh, const uint32* puiCmd, const uint8* pucBuff, const uint32 uiSize);
int32 IPC_Read(    IPCSvcCh_t  siCh, uint8* pucBuff,uint32 uiSize, uint32 uiFlag);
int32 IPC_PingTest(    IPCSvcCh_t siCh, IPCPingInfo_t* pPingInfo);
void IPC_Flush(    IPCSvcCh_t siCh);

void IPC_StructInit(    IPCSvcCh_t siCh, IPCHandler_t* pIpcHandler);
void IPC_SetStatus(    IPCSvcCh_t siCh,IPCStatus_t status, uint32 flag);
IPCStatus_t IPC_GetStatus(    IPCSvcCh_t siCh);
int32 IPC_Initialize(    IPCSvcCh_t siCh);
void IPC_Release(    IPCSvcCh_t siCh);

#endif /* _IPC_CTL_H_ */

