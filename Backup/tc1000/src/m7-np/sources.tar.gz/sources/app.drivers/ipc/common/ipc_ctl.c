/*

***************************************************************************************************
*
*   FileName : ipc_ctl.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/****************************************
 *				Include					*
 ****************************************/
#include "ipi.h"

#include "ipc_api.h"
#include "ipc_buffer.h"
#include "ipc_os.h"
#include "ipc_cmd.h"
#include "ipc_ctl.h"


/****************************************
 *		  Variable Definitions			*
 ****************************************/
IPCMboxMsgReg_t   recv[IPC_SVC_CH_MAX] = {0, };


IPCHandler_t             gIPCHandler[IPC_SVC_CH_MAX];
static uint8             gIPCRingBuffer[IPC_SVC_CH_MAX][MAX_IPC_RING_BUFF_SIZE];// __attribute__ ((section(".ipc_mem_sec")));;


uint8 * IPC_Initialize_str[IPC_SVC_CH_MAX] = 
{
	(uint8 *)"IPC_CH_CA65_NS_USER", (uint8 *)"IPC_CH_CA65_NS_TPA", (uint8 *)"IPC_CH_CA65_NS_LPA",
#if ( CORTEX_M7_0 == 0)
	(uint8 *)"IPC_CH_CM7_0_USER", (uint8 *)"IPC_CH_CM7_0_TPA", (uint8 *)"IPC_CH_CM7_0_LPA",
#endif
#if ( CORTEX_M7_1 == 0)
	(uint8 *)"IPC_CH_CM7_1_USER", (uint8 *)"IPC_CH_CM7_1_TPA", (uint8 *)"IPC_CH_CM7_1_LPA",
#endif
#if ( CORTEX_M7_2 == 0)
	(uint8 *)"IPC_CH_CM7_2_USER", (uint8 *)"IPC_CH_CM7_2_TPA", (uint8 *)"IPC_CH_CM7_2_LPA",
#endif
#if ( CORTEX_M7_NP == 0)
	(uint8 *)"IPC_CH_CM7_NP_USER", (uint8 *)"IPC_CH_CM7_NP_TPA", (uint8 *)"IPC_CH_CM7_NP_LPA",
#endif
};

/***************************************************
*          Local function prototypes               *
****************************************************/
static void IPC_Ipi_RxCB_CA65_NS_USER(const IpiMessage_t * sIpiMessage);
static void IPC_Ipi_RxCB_CA65_NS_TPA(const IpiMessage_t * sIpiMessage);
static void IPC_Ipi_RxCB_CA65_NS_LPA(const IpiMessage_t * sIpiMessage);
#if ( CORTEX_M7_0 == 0)
static void IPC_Ipi_RxCB_CM7_0_USER(const IpiMessage_t * sIpiMessage);
static void IPC_Ipi_RxCB_CM7_0_TPA(const IpiMessage_t * sIpiMessage);
static void IPC_Ipi_RxCB_CM7_0_LPA(const IpiMessage_t * sIpiMessage);
#endif
#if ( CORTEX_M7_1 == 0)
static void IPC_Ipi_RxCB_CM7_1_USER(const IpiMessage_t * sIpiMessage);
static void IPC_Ipi_RxCB_CM7_1_TPA(const IpiMessage_t * sIpiMessage);
static void IPC_Ipi_RxCB_CM7_1_LPA(const IpiMessage_t * sIpiMessage);
#endif
#if ( CORTEX_M7_2 == 0)
static void IPC_Ipi_RxCB_CM7_2_USER(const IpiMessage_t * sIpiMessage);
static void IPC_Ipi_RxCB_CM7_2_TPA(const IpiMessage_t * sIpiMessage);
static void IPC_Ipi_RxCB_CM7_2_LPA(const IpiMessage_t * sIpiMessage);
#endif
#if ( CORTEX_M7_NP == 0)
static void IPC_Ipi_RxCB_CM7_NP_USER(const IpiMessage_t * sIpiMessage);
static void IPC_Ipi_RxCB_CM7_NP_TPA(const IpiMessage_t * sIpiMessage);
static void IPC_Ipi_RxCB_CM7_NP_LPA(const IpiMessage_t * sIpiMessage);
#endif
/***********Callback Function Definition*************/
void * Ipi_rx_cb_func[IPC_SVC_CH_MAX] = 
{
	IPC_Ipi_RxCB_CA65_NS_USER,
	IPC_Ipi_RxCB_CA65_NS_TPA,
	IPC_Ipi_RxCB_CA65_NS_LPA,
	
#if ( CORTEX_M7_0 == 0)	
	IPC_Ipi_RxCB_CM7_0_USER,
	IPC_Ipi_RxCB_CM7_0_TPA,
	IPC_Ipi_RxCB_CM7_0_LPA,
#endif
#if ( CORTEX_M7_1 == 0)	
	IPC_Ipi_RxCB_CM7_1_USER,
	IPC_Ipi_RxCB_CM7_1_TPA,
	IPC_Ipi_RxCB_CM7_1_LPA,
#endif
#if ( CORTEX_M7_2 == 0)	
	IPC_Ipi_RxCB_CM7_2_USER,
	IPC_Ipi_RxCB_CM7_2_TPA,
	IPC_Ipi_RxCB_CM7_2_LPA,
#endif
#if ( CORTEX_M7_NP == 0)	
	IPC_Ipi_RxCB_CM7_NP_USER,
	IPC_Ipi_RxCB_CM7_NP_TPA,
	IPC_Ipi_RxCB_CM7_NP_LPA
#endif

};


static int32 IPC_WriteData(    IPCSvcCh_t siCh, const uint32* puiCmd, const uint8* pucBuff, const uint32 uiSize);

static int32 IPC_ReadDataSafe(    IPCSvcCh_t   siCh, uint32 uiSize, uint32 isReadAll, uint8* pucBuff);
static int32 IPC_ReadData(    IPCSvcCh_t  siCh, uint8* pucBuff,uint32 uiSize, uint32 uiFlag);

static IPCPingError_t IPC_PingError(    int32* siError);

static uint32 Get_IPC_SHM_Tx_Start_Addr(    IPCSvcCh_t siCh);
static uint32 Get_IPC_SHM_Rx_Start_Addr(    IPCSvcCh_t siCh);

static void IPC_SetBuffer(    IPCSvcCh_t siCh);

static void IPC_ReceiveCtlCmd(    IPCSvcCh_t siCh,    const IPCMboxMsgReg_t* pMsg);
static int IPC_ReceiveWriteCmdSafe(    IPCSvcCh_t siCh, uint32 seqID, const IPCMboxMsgReg_t* pMsg, uint32 readSize);
static void IPC_ReceiveWriteCmd(    IPCSvcCh_t siCh,    const IPCMboxMsgReg_t* pMsg);
static void IPC_ContorlTask(    IPCSvcCh_t siCh);


/**************************************************************************************************
*                                  Ipi Rx Callback for CA65_NS_USER,TPA,LPA
*
* [Callback] Ipi Rx Callback for CA65_NS_USER,TPA,LPA
*
* @param        sIpiMessage
* @return       void
*
* Notes
*
***************************************************************************************************/
static void IPC_Ipi_RxCB_CA65_NS_USER(const IpiMessage_t * sIpiMessage)
{
	if(sIpiMessage != NULL)
	{
		recv[IPC_CH_CA65_NS_USER].mmReg = (uint32 *)&sIpiMessage->Cmd[1];
		
		if(gIPCHandler[IPC_CH_CA65_NS_USER].ihIpcOption.isShm == 0)
		{
			recv[IPC_CH_CA65_NS_USER].mmDat = (uint32 *)&sIpiMessage->Data;	
		}
		else
		{
			recv[IPC_CH_CA65_NS_USER].mmDat = (uint32 *)gIPCHandler[IPC_CH_CA65_NS_USER].receiveBuffer.startAddr;
		}
	
		IPC_ContorlTask(IPC_CH_CA65_NS_USER);
	}
}

static void IPC_Ipi_RxCB_CA65_NS_TPA(const IpiMessage_t * sIpiMessage)
{
	if(sIpiMessage != NULL)
	{
		recv[IPC_CH_CA65_NS_TPA].mmReg = (uint32 *)&sIpiMessage->Cmd[1];

		if(gIPCHandler[IPC_CH_CA65_NS_TPA].ihIpcOption.isShm == 0)
		{
			recv[IPC_CH_CA65_NS_TPA].mmDat = (uint32 *)&sIpiMessage->Data;	
		}
		else
		{
			recv[IPC_CH_CA65_NS_TPA].mmDat = (uint32 *)gIPCHandler[IPC_CH_CA65_NS_TPA].receiveBuffer.startAddr;
		}

		IPC_ContorlTask(IPC_CH_CA65_NS_TPA);
	}
}

static void IPC_Ipi_RxCB_CA65_NS_LPA(const IpiMessage_t * sIpiMessage)
{
	if(sIpiMessage != NULL)
	{
		recv[IPC_CH_CA65_NS_LPA].mmReg = (uint32 *)&sIpiMessage->Cmd[1];

		if(gIPCHandler[IPC_CH_CA65_NS_LPA].ihIpcOption.isShm == 0)
		{
			recv[IPC_CH_CA65_NS_LPA].mmDat = (uint32 *)&sIpiMessage->Data;	
		}
		else
		{
			recv[IPC_CH_CA65_NS_LPA].mmDat = (uint32 *)gIPCHandler[IPC_CH_CA65_NS_LPA].receiveBuffer.startAddr;
		}

		IPC_ContorlTask(IPC_CH_CA65_NS_LPA);
	}
}


/**************************************************************************************************
*                                  Ipi Rx Callback for C7_0_USER,TPA,LPA
*
* [Callback] Ipi Rx Callback for C7_0_USER,TPA,LPA
*
* @param        sIpiMessage
* @return       void
*
* Notes
*
***************************************************************************************************/
#if ( CORTEX_M7_0 == 0)
static void IPC_Ipi_RxCB_CM7_0_USER(const IpiMessage_t * sIpiMessage)
{
	if(sIpiMessage != NULL)
	{
		recv[IPC_CH_CM7_0_USER].mmReg = (uint32 *)&sIpiMessage->Cmd[1];

		if(gIPCHandler[IPC_CH_CM7_0_USER].ihIpcOption.isShm == 0)
		{
			recv[IPC_CH_CM7_0_USER].mmDat = (uint32 *)&sIpiMessage->Data;	
		}
		else
		{
			recv[IPC_CH_CM7_0_USER].mmDat = (uint32 *)gIPCHandler[IPC_CH_CM7_0_USER].receiveBuffer.startAddr;
		}

		IPC_ContorlTask(IPC_CH_CM7_0_USER);
	}
}

static void IPC_Ipi_RxCB_CM7_0_TPA(const IpiMessage_t * sIpiMessage)
{
	if(sIpiMessage != NULL)
	{
		recv[IPC_CH_CM7_0_TPA].mmReg = (uint32 *)&sIpiMessage->Cmd[1];

		if(gIPCHandler[IPC_CH_CM7_0_TPA].ihIpcOption.isShm == 0)
		{
			recv[IPC_CH_CM7_0_TPA].mmDat = (uint32 *)&sIpiMessage->Data;	
		}
		else
		{
			recv[IPC_CH_CM7_0_TPA].mmDat = (uint32 *)gIPCHandler[IPC_CH_CM7_0_TPA].receiveBuffer.startAddr;
		}	

		IPC_ContorlTask(IPC_CH_CM7_0_TPA);
	}
}
static void IPC_Ipi_RxCB_CM7_0_LPA(const IpiMessage_t * sIpiMessage)
{
		
	if(sIpiMessage != NULL)
	{
		recv[IPC_CH_CM7_0_LPA].mmReg = (uint32 *)&sIpiMessage->Cmd[1];

		if(gIPCHandler[IPC_CH_CM7_0_LPA].ihIpcOption.isShm == 0)
		{
			recv[IPC_CH_CM7_0_LPA].mmDat = (uint32 *)&sIpiMessage->Data;	
		}
		else
		{
			recv[IPC_CH_CM7_0_LPA].mmDat = (uint32 *)gIPCHandler[IPC_CH_CM7_0_LPA].receiveBuffer.startAddr;
		}

		IPC_ContorlTask(IPC_CH_CM7_0_LPA);
	}
}

#endif


/**************************************************************************************************
*                                  Ipi Rx Callback for C7_1_USER,TPA,LPA
*
* [Callback] Ipi Rx Callback for C7_1_USER,TPA,LPA
*
* @param        sIpiMessage
* @return       void
*
* Notes
*
***************************************************************************************************/

#if ( CORTEX_M7_1 == 0)
static void IPC_Ipi_RxCB_CM7_1_USER(const IpiMessage_t * sIpiMessage)
{
	if(sIpiMessage != NULL)
	{
		recv[IPC_CH_CM7_1_USER].mmReg = (uint32 *)&sIpiMessage->Cmd[1];

		if(gIPCHandler[IPC_CH_CM7_1_USER].ihIpcOption.isShm == 0)
		{
			recv[IPC_CH_CM7_1_USER].mmDat = (uint32 *)&sIpiMessage->Data;	
		}
		else
		{
			recv[IPC_CH_CM7_1_USER].mmDat = (uint32 *)gIPCHandler[IPC_CH_CM7_1_USER].receiveBuffer.startAddr;
		}

		IPC_ContorlTask(IPC_CH_CM7_1_USER);
	}
}

static void IPC_Ipi_RxCB_CM7_1_TPA(const IpiMessage_t * sIpiMessage)
{
	if(sIpiMessage != NULL)
	{
		recv[IPC_CH_CM7_1_TPA].mmReg = (uint32 *)&sIpiMessage->Cmd[1];

		if(gIPCHandler[IPC_CH_CM7_1_TPA].ihIpcOption.isShm == 0)
		{
			recv[IPC_CH_CM7_1_TPA].mmDat = (uint32 *)&sIpiMessage->Data;	
		}
		else
		{
			recv[IPC_CH_CM7_1_TPA].mmDat = (uint32 *)gIPCHandler[IPC_CH_CM7_1_TPA].receiveBuffer.startAddr;
		}

		IPC_ContorlTask(IPC_CH_CM7_1_TPA);
	}
}
static void IPC_Ipi_RxCB_CM7_1_LPA(const IpiMessage_t * sIpiMessage)
{
	if(sIpiMessage != NULL)
	{
		recv[IPC_CH_CM7_1_LPA].mmReg = (uint32 *)&sIpiMessage->Cmd[1];

		if(gIPCHandler[IPC_CH_CM7_1_LPA].ihIpcOption.isShm == 0)
		{
			recv[IPC_CH_CM7_1_LPA].mmDat = (uint32 *)&sIpiMessage->Data;	
		}
		else
		{
			recv[IPC_CH_CM7_1_LPA].mmDat = (uint32 *)gIPCHandler[IPC_CH_CM7_1_LPA].receiveBuffer.startAddr;
		}

		IPC_ContorlTask(IPC_CH_CM7_1_LPA);
	}
}

#endif


/**************************************************************************************************
*                                  Ipi Rx Callback for C7_2_USER,TPA,LPA
*
* [Callback] Ipi Rx Callback for C7_2_USER,TPA,LPA
*
* @param        sIpiMessage
* @return       void
*
* Notes
*
***************************************************************************************************/
#if ( CORTEX_M7_2 == 0)
static void IPC_Ipi_RxCB_CM7_2_USER(const IpiMessage_t * sIpiMessage)
{
	if(sIpiMessage != NULL)
	{
		recv[IPC_CH_CM7_2_USER].mmReg = (uint32 *)&sIpiMessage->Cmd[1];

		if(gIPCHandler[IPC_CH_CM7_2_USER].ihIpcOption.isShm == 0)
		{
			recv[IPC_CH_CM7_2_USER].mmDat = (uint32 *)&sIpiMessage->Data;	
		}
		else
		{
			recv[IPC_CH_CM7_2_USER].mmDat = (uint32 *)gIPCHandler[IPC_CH_CM7_2_USER].receiveBuffer.startAddr;
		}

		IPC_ContorlTask(IPC_CH_CM7_2_USER);
	}
}

static void IPC_Ipi_RxCB_CM7_2_TPA(const IpiMessage_t * sIpiMessage)
{
	if(sIpiMessage != NULL)
	{
		recv[IPC_CH_CM7_2_TPA].mmReg = (uint32 *)&sIpiMessage->Cmd[1];

		if(gIPCHandler[IPC_CH_CM7_2_TPA].ihIpcOption.isShm == 0)
		{
			recv[IPC_CH_CM7_2_TPA].mmDat = (uint32 *)&sIpiMessage->Data;	
		}
		else
		{
			recv[IPC_CH_CM7_2_TPA].mmDat = (uint32 *)gIPCHandler[IPC_CH_CM7_2_TPA].receiveBuffer.startAddr;
		}

		IPC_ContorlTask(IPC_CH_CM7_2_TPA);
	}
}
static void IPC_Ipi_RxCB_CM7_2_LPA(const IpiMessage_t * sIpiMessage)
{
	if(sIpiMessage != NULL)
	{
		recv[IPC_CH_CM7_2_LPA].mmReg = (uint32 *)&sIpiMessage->Cmd[1];

		if(gIPCHandler[IPC_CH_CM7_2_LPA].ihIpcOption.isShm == 0)
		{
			recv[IPC_CH_CM7_2_LPA].mmDat = (uint32 *)&sIpiMessage->Data;	
		}
		else
		{
			recv[IPC_CH_CM7_2_LPA].mmDat = (uint32 *)gIPCHandler[IPC_CH_CM7_2_LPA].receiveBuffer.startAddr;
		}

		IPC_ContorlTask(IPC_CH_CM7_2_LPA);
	}
}

#endif

/**************************************************************************************************
*                                  Ipi Rx Callback for C7_NP_USER,TPA,LPA
*
* [Callback] Ipi Rx Callback for C7_NP_USER,TPA,LPA
*
* @param        sIpiMessage
* @return       void
*
* Notes
*
***************************************************************************************************/
#if ( CORTEX_M7_NP == 0)
static void IPC_Ipi_RxCB_CM7_NP_USER(const IpiMessage_t * sIpiMessage)
{
	if(sIpiMessage != NULL)
	{
		recv[IPC_CH_CM7_NP_USER].mmReg = (uint32 *)&sIpiMessage->Cmd[1];

		if(gIPCHandler[IPC_CH_CM7_NP_USER].ihIpcOption.isShm == 0)
		{
			recv[IPC_CH_CM7_NP_USER].mmDat = (uint32 *)&sIpiMessage->Data;	
		}
		else
		{
			recv[IPC_CH_CM7_NP_USER].mmDat = (uint32 *)gIPCHandler[IPC_CH_CM7_NP_USER].receiveBuffer.startAddr;		
		}	

		IPC_ContorlTask(IPC_CH_CM7_NP_USER);
	}
}

static void IPC_Ipi_RxCB_CM7_NP_TPA(const IpiMessage_t * sIpiMessage)
{
	if(sIpiMessage != NULL)
	{
		recv[IPC_CH_CM7_NP_TPA].mmReg = (uint32 *)&sIpiMessage->Cmd[1];

		if(gIPCHandler[IPC_CH_CM7_NP_TPA].ihIpcOption.isShm == 0)
		{
			recv[IPC_CH_CM7_NP_TPA].mmDat = (uint32 *)&sIpiMessage->Data;	
		}
		else
		{
			recv[IPC_CH_CM7_NP_TPA].mmDat = (uint32 *)gIPCHandler[IPC_CH_CM7_NP_TPA].receiveBuffer.startAddr;
		}

		IPC_ContorlTask(IPC_CH_CM7_NP_TPA);
	}
}
static void IPC_Ipi_RxCB_CM7_NP_LPA(const IpiMessage_t * sIpiMessage)
{
	if(sIpiMessage != NULL)
	{
		recv[IPC_CH_CM7_NP_LPA].mmReg = (uint32 *)&sIpiMessage->Cmd[1];

		if(gIPCHandler[IPC_CH_CM7_NP_LPA].ihIpcOption.isShm == 0)
		{
			recv[IPC_CH_CM7_NP_LPA].mmDat = (uint32 *)&sIpiMessage->Data;	
		}
		else
		{
			recv[IPC_CH_CM7_NP_LPA].mmDat = (uint32 *)gIPCHandler[IPC_CH_CM7_NP_LPA].receiveBuffer.startAddr;
		}

		IPC_ContorlTask(IPC_CH_CM7_NP_LPA);
	}
}

#endif




/**************************************************************************************************
*                                  IPC Write Data
*
* [Internal] Send write data
*
* @param        siCh, *puiCmd, *pucBuff, uiSize
* @return       IPC_ret
*
* Notes
*
***************************************************************************************************/
static int32 IPC_WriteData(    IPCSvcCh_t siCh, const uint32* puiCmd, const uint8* pucBuff, const uint32 uiSize)
{
    int32 ret = IPC_ERR_COMMON;

	if((puiCmd != NULL_PTR) && (uiSize <= gIPCHandler[siCh].Ipc_Max_Packet_Size))
    {
		ret = IPC_SendWrite(siCh, puiCmd, pucBuff, uiSize, gIPCHandler[siCh].ihIpcOption.isAck);
		
        if(ret == 0)
        {
            ret = (int32) uiSize;
        }
        else
        {
            ret = IPC_ERR_TIMEOUT;
        }
    }
    return ret;
}

/**************************************************************************************************
*                                  IPC Write Data
*
* [External] Send write data
*
* @param        siCh, *puiCmd, *pucBuff, uiSize
* @return       IPC_ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_Write(    IPCSvcCh_t siCh, const uint32* puiCmd, const uint8* pucBuff, const uint32 uiSize)
{
    int32 ret;

    ret = IPC_ERR_COMMON;

    if((puiCmd != NULL_PTR) && (uiSize > 0U))
    {
        ret = IPC_WriteData(siCh, puiCmd, pucBuff, uiSize);
    }

    return ret;
}


/**************************************************************************************************
*                                  IPC Read Data
*
* [Internal] Read data
*
* @param        siCh, uiSize. isReadAll, *pucBuff
* @return       IPC_ret
*
* Notes
*
***************************************************************************************************/
static int32 IPC_ReadDataSafe(    IPCSvcCh_t   siCh, uint32 uiSize, uint32 isReadAll, uint8* pucBuff)
{
    int32 ret;
    uint32 readSize;
    uint32 dataSize;

    ret      = 0;
    readSize = 0;
    dataSize = 0;

    IPC_RbufferLock(siCh);
    dataSize = (uint32) IPC_BufferDataAvailable(&gIPCHandler[siCh].ihReadRingBuffer);
    IPC_RbufferUnlock(siCh);

    if(dataSize < uiSize)
    {
        if(gIPCHandler[siCh].ihIsWait == 1U)
        {
            if (dataSize < gIPCHandler[siCh].ihMin)
            {
                (void) IPC_ReadWaitEventTimeOut(siCh, gIPCHandler[siCh].ihTime * 100U);
            }

            IPC_RbufferLock(siCh);
            dataSize = (uint32) IPC_BufferDataAvailable(&gIPCHandler[siCh].ihReadRingBuffer);
            IPC_RbufferUnlock(siCh);

            if((dataSize < gIPCHandler[siCh].ihMin) && (isReadAll == 0U))
            {
                readSize = 0;
            }
            else
            {
                if(dataSize <= uiSize)
                {
                    readSize = dataSize;
                }
                else
                {
                    readSize = uiSize;
                }
            }
        }
        else
        {
            readSize = dataSize;
        }
    }
    else
    {
        readSize = uiSize;
    }

    if(readSize != 0U)
    {
        IPC_RbufferLock(siCh);
        ret = IPC_PopBuffer(&gIPCHandler[siCh].ihReadRingBuffer, pucBuff, readSize);
        IPC_RbufferUnlock(siCh);
        if(ret == IPC_BUFFER_OK)
        {
            ret = (int32) readSize;
        }
        else
        {
            ret = IPC_ERR_READ;
        }
    }

    return ret;
}

/**************************************************************************************************
*                                  IPC Read Data
*
* [Internal] Read data
*
* @param        siCh, *pucBuff, uiSize, uiFlag
* @return       IPC_ret
*
* Notes
*
***************************************************************************************************/
static int32 IPC_ReadData(    IPCSvcCh_t  siCh, uint8* pucBuff,uint32 uiSize, uint32 uiFlag)
{
    int32  ret;
    uint32 isReadAll;

    ret       = 0;
    isReadAll = 0;

    if((pucBuff != NULL_PTR) && (uiSize > 0U))
    {
        IPC_CommonLock(siCh);
        gIPCHandler[siCh].ihTime = gIPCHandler[siCh].ihSetParam.vTime;
        gIPCHandler[siCh].ihMin  = gIPCHandler[siCh].ihSetParam.vMin;
        IPC_CommonUnlock(siCh);

        if(IPC_O_BLOCK != (uiFlag & IPC_O_BLOCK))
        {
            gIPCHandler[siCh].ihIsWait = 0;
        }
        else
        {
            if((gIPCHandler[siCh].ihTime == 0U) &&(gIPCHandler[siCh].ihMin == 0U))
            {
                isReadAll                = 1;
                gIPCHandler[siCh].ihTime = MAX_READ_TIMEOUT;
                gIPCHandler[siCh].ihMin  = uiSize;
            }
            else if(gIPCHandler[siCh].ihTime == 0U)
            {
                gIPCHandler[siCh].ihTime = MAX_READ_TIMEOUT;
            }
            else if(gIPCHandler[siCh].ihMin == 0U)
            {
                gIPCHandler[siCh].ihMin = 1;
            }
            else
            {
        	    IPC_DBG("%s, ipc %d read mode ihTime[%d] ihMin[%d]\n", __func__, siCh, gIPCHandler[siCh].ihTime, gIPCHandler[siCh].ihMin);
            }

            gIPCHandler[siCh].ihIsWait = 1U;
        }

        ret = IPC_ReadDataSafe(siCh, uiSize, isReadAll, pucBuff);
    }

    if(gIPCHandler[siCh].ihIsWait == 1U)
    {
        IPC_ReadClearEvent(siCh);
    }

    return ret;
}


/**************************************************************************************************
*                                  IPC Read Data
*
* [External] Read data
*
* @param        siCh, *pucBuff, uiSize, uiFlag
* @return       IPC_ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_Read(    IPCSvcCh_t  siCh, uint8* pucBuff,uint32 uiSize, uint32 uiFlag)
{
    int32 ret;

    ret = IPC_ERR_COMMON;

    if((pucBuff != NULL_PTR) && (uiSize > 0U))
    {
        IPC_ReadLock(siCh);
        ret = IPC_ReadData(siCh, pucBuff, uiSize, uiFlag);
        IPC_ReadUnlock(siCh);
    }

    return ret;
}


/**************************************************************************************************
*                                  IPC ping errer
*
* [Internal] ping error
*
* @param        *siError
* @return       IPCPingError_t
*
* Notes
*
***************************************************************************************************/
static IPCPingError_t IPC_PingError(    int32* siError)
{
    IPCPingError_t ret;

    if (siError != NULL_PTR)
    {
        if(*siError == IPC_ERR_TIMEOUT)
        {
            ret = IPC_PING_ERR_RESPOND;
        }
        else if (*siError == IPC_ERR_RECEIVER_NOT_SET)
        {
            ret = IPC_PING_ERR_RECEIVER_MBOX;
        }
        else if (*siError == IPC_ERR_RECEIVER_DOWN)
        {
            ret = IPC_PING_ERR_SEND;
        }
        else if (*siError == IPC_ERR_NOTREADY)
        {
            ret = IPC_PING_ERR_NOT_READY;
        }
        else
        {
            ret = IPC_PING_ERR_SENDER_MBOX;
        }

        *siError = IPC_ERR_NOTREADY;
    }
    else
    {
        ret = MAX_IPC_PING_ERR;
        IPC_ERR("%s siError is Null\n", __func__);
    }

    return ret;
}

/**************************************************************************************************
*                                  IPC ping test
*
* [External] ping test
*
* @param        siCh, *pPingInfo
* @return       IPCPingError_t
*
* Notes
*
***************************************************************************************************/
int32 IPC_PingTest(    IPCSvcCh_t siCh, IPCPingInfo_t* pPingInfo)
{
    int32                 ret;
    uint32                startTime;
    uint32                endTime;
    const IPCHandler_t *  pIPCHandler;

    ret         = IPC_SUCCESS;
    startTime   = 0UL;
    endTime     = 0UL;
    pIPCHandler = &gIPCHandler[siCh];

    if(pPingInfo != NULL_PTR)
    {
        /* Check IPC */
        if(pIPCHandler->ihIpcStatus <= IPC_INIT)
        {
            pPingInfo->piPingResult = IPC_PING_ERR_INIT;
            ret = IPC_ERR_COMMON;
        }

        if(ret == IPC_SUCCESS)
        {
            startTime = IPC_GetMsec();
            IPC_WriteLock(siCh);
            ret = IPC_SendPing(siCh);

            if(ret == IPC_SUCCESS)
            {
                pPingInfo->piPingResult = IPC_PING_SUCCESS;
            }
            else
            {
                pPingInfo->piPingResult = IPC_PingError(&ret);
            }

            IPC_WriteUnlock(siCh);
            endTime = IPC_GetMsec();
            pPingInfo->piResponseTime = (endTime >= startTime) ? (endTime - startTime) : ((0xFFFFFFFFUL - startTime) + endTime); //msec
        }
    }

    return ret;
}

/**************************************************************************************************
*                                  IPC buffer flush
*
* [External] buffer flush
*
* @param        siCh
* @return       void
*
* Notes
*
***************************************************************************************************/
void IPC_Flush(    IPCSvcCh_t siCh)
{
    IPC_RbufferLock(siCh);
    IPC_BufferFlush(&gIPCHandler[siCh].ihReadRingBuffer);
    IPC_RbufferUnlock(siCh);
}


/**************************************************************************************************
*                               Get IPC SHM Tx Start Addr
*
* [Internal] Get IPC SHM Tx Start Addr
*
* @param        siCh
* @return       IPC SHM Tx Start Addr
*
* Notes
*
***************************************************************************************************/
static uint32 Get_IPC_SHM_Tx_Start_Addr(    IPCSvcCh_t siCh)
{
	uint32	IPC_SHM_Tx_Start_Addr = NULL;

	if((siCh == IPC_CH_CA65_NS_USER) || (siCh == IPC_CH_CA65_NS_TPA) || (siCh == IPC_CH_CA65_NS_LPA))
	{
		#if (CORTEX_M7_0 == 1)
		IPC_SHM_Tx_Start_Addr = (uint32)IPC_SHARE_CM0_TXTO_CA65_MEM_START_ADDR;
		#elif (CORTEX_M7_1 == 1)
		IPC_SHM_Tx_Start_Addr = (uint32)IPC_SHARE_CM1_TXTO_CA65_MEM_START_ADDR;
		#elif (CORTEX_M7_2 == 1)
		IPC_SHM_Tx_Start_Addr = (uint32)IPC_SHARE_CM2_TXTO_CA65_MEM_START_ADDR;
		#elif (CORTEX_M7_NP == 1)
		IPC_SHM_Tx_Start_Addr = (uint32)IPC_SHARE_CMN_TXTO_CA65_MEM_START_ADDR;
		#endif
	}
	
#if (CORTEX_M7_0 == 0)
	else if((siCh == IPC_CH_CM7_0_USER) || (siCh == IPC_CH_CM7_0_TPA) || (siCh == IPC_CH_CM7_0_LPA))
	{
		#if (CORTEX_M7_1 == 1)
		IPC_SHM_Tx_Start_Addr = (uint32)IPC_SHARE_CM1_TXTO_CM0_MEM_START_ADDR;
		#elif (CORTEX_M7_2 == 1)
		IPC_SHM_Tx_Start_Addr = (uint32)IPC_SHARE_CM2_TXTO_CM0_MEM_START_ADDR;
		#elif (CORTEX_M7_NP == 1)
		IPC_SHM_Tx_Start_Addr = (uint32)IPC_SHARE_CMN_TXTO_CM0_MEM_START_ADDR;
		#endif
	}
#endif	

#if (CORTEX_M7_1 == 0)
	else if((siCh == IPC_CH_CM7_1_USER) || (siCh == IPC_CH_CM7_1_TPA) || (siCh == IPC_CH_CM7_1_LPA))
	{
		#if (CORTEX_M7_0 == 1)
		IPC_SHM_Tx_Start_Addr = (uint32)IPC_SHARE_CM0_TXTO_CM1_MEM_START_ADDR;
		#elif (CORTEX_M7_2 == 1)
		IPC_SHM_Tx_Start_Addr = (uint32)IPC_SHARE_CM2_TXTO_CM1_MEM_START_ADDR;
		#elif (CORTEX_M7_NP == 1)
		IPC_SHM_Tx_Start_Addr = (uint32)IPC_SHARE_CMN_TXTO_CM1_MEM_START_ADDR;
		#endif
	}
#endif	

#if ( CORTEX_M7_2 == 0)
	else if((siCh == IPC_CH_CM7_2_USER) || (siCh == IPC_CH_CM7_2_TPA) || (siCh == IPC_CH_CM7_2_LPA))
	{
		#if (CORTEX_M7_0 == 1)
		IPC_SHM_Tx_Start_Addr = (uint32)IPC_SHARE_CM0_TXTO_CM2_MEM_START_ADDR;
		#elif (CORTEX_M7_1 == 1)
		IPC_SHM_Tx_Start_Addr = (uint32)IPC_SHARE_CM1_TXTO_CM2_MEM_START_ADDR;
		#elif (CORTEX_M7_NP == 1)
		IPC_SHM_Tx_Start_Addr = (uint32)IPC_SHARE_CMN_TXTO_CM2_MEM_START_ADDR;
		#endif

	}
#endif	

#if ( CORTEX_M7_NP == 0)
	else if((siCh == IPC_CH_CM7_NP_USER) || (siCh == IPC_CH_CM7_NP_TPA) || (siCh == IPC_CH_CM7_NP_LPA))
	{
		#if (CORTEX_M7_0 == 1)
		IPC_SHM_Tx_Start_Addr = (uint32)IPC_SHARE_CM0_TXTO_CMN_MEM_START_ADDR;
		#elif (CORTEX_M7_1 == 1)
		IPC_SHM_Tx_Start_Addr = (uint32)IPC_SHARE_CM1_TXTO_CMN_MEM_START_ADDR;
		#elif (CORTEX_M7_2 == 1)
		IPC_SHM_Tx_Start_Addr = (uint32)IPC_SHARE_CM2_TXTO_CMN_MEM_START_ADDR;
		#endif
	}
#endif

	else{}

	return IPC_SHM_Tx_Start_Addr;
}


/**************************************************************************************************
*                               Get IPC SHM Rx Start Addr
*
* [Internal] Get IPC SHM Rx Start Addr
*
* @param        siCh
* @return       IPC SHM Rx Start Addr
*
* Notes
*
***************************************************************************************************/
static uint32 Get_IPC_SHM_Rx_Start_Addr(    IPCSvcCh_t siCh)
{
	uint32	IPC_SHM_Rx_Start_Addr = NULL;

	if((siCh == IPC_CH_CA65_NS_USER) || (siCh == IPC_CH_CA65_NS_TPA) || (siCh == IPC_CH_CA65_NS_LPA))
	{
		#if (CORTEX_M7_0 == 1)
		IPC_SHM_Rx_Start_Addr = (uint32)IPC_SHARE_CM0_RXFR_CA65_MEM_START_ADDR;
		#elif (CORTEX_M7_1 == 1)
		IPC_SHM_Rx_Start_Addr = (uint32)IPC_SHARE_CM1_RXFR_CA65_MEM_START_ADDR;
		#elif (CORTEX_M7_2 == 1)
		IPC_SHM_Rx_Start_Addr = (uint32)IPC_SHARE_CM2_RXFR_CA65_MEM_START_ADDR;
		#elif (CORTEX_M7_NP == 1)
		IPC_SHM_Rx_Start_Addr = (uint32)IPC_SHARE_CMN_RXFR_CA65_MEM_START_ADDR;
		#endif
	}
	
#if (CORTEX_M7_0 == 0)
	else if((siCh == IPC_CH_CM7_0_USER) || (siCh == IPC_CH_CM7_0_TPA) || (siCh == IPC_CH_CM7_0_LPA))
	{
		#if (CORTEX_M7_1 == 1)
		IPC_SHM_Rx_Start_Addr = (uint32)IPC_SHARE_CM1_RXFR_CM0_MEM_START_ADDR;
		#elif (CORTEX_M7_2 == 1)
		IPC_SHM_Rx_Start_Addr = (uint32)IPC_SHARE_CM2_RXFR_CM0_MEM_START_ADDR;
		#elif (CORTEX_M7_NP == 1)
		IPC_SHM_Rx_Start_Addr = (uint32)IPC_SHARE_CMN_RXFR_CM0_MEM_START_ADDR;
		#endif
	}
#endif	

#if (CORTEX_M7_1 == 0)
	else if((siCh == IPC_CH_CM7_1_USER) || (siCh == IPC_CH_CM7_1_TPA) || (siCh == IPC_CH_CM7_1_LPA))
	{
		#if (CORTEX_M7_0 == 1)
		IPC_SHM_Rx_Start_Addr = (uint32)IPC_SHARE_CM0_RXFR_CM1_MEM_START_ADDR;
		#elif (CORTEX_M7_2 == 1)
		IPC_SHM_Rx_Start_Addr = (uint32)IPC_SHARE_CM2_RXFR_CM1_MEM_START_ADDR;
		#elif (CORTEX_M7_NP == 1)
		IPC_SHM_Rx_Start_Addr = (uint32)IPC_SHARE_CMN_RXFR_CM1_MEM_START_ADDR;
		#endif
	}
#endif	

#if ( CORTEX_M7_2 == 0)
	else if((siCh == IPC_CH_CM7_2_USER) || (siCh == IPC_CH_CM7_2_TPA) || (siCh == IPC_CH_CM7_2_LPA))
	{
		#if (CORTEX_M7_0 == 1)
		IPC_SHM_Rx_Start_Addr = (uint32)IPC_SHARE_CM0_RXFR_CM2_MEM_START_ADDR;
		#elif (CORTEX_M7_1 == 1)
		IPC_SHM_Rx_Start_Addr = (uint32)IPC_SHARE_CM1_RXFR_CM2_MEM_START_ADDR;
		#elif (CORTEX_M7_NP == 1)
		IPC_SHM_Rx_Start_Addr = (uint32)IPC_SHARE_CMN_RXFR_CM2_MEM_START_ADDR;
		#endif

	}
#endif	

#if ( CORTEX_M7_NP == 0)
	else if((siCh == IPC_CH_CM7_NP_USER) || (siCh == IPC_CH_CM7_NP_TPA) || (siCh == IPC_CH_CM7_NP_LPA))
	{
		#if (CORTEX_M7_0 == 1)
		IPC_SHM_Rx_Start_Addr = (uint32)IPC_SHARE_CM0_RXFR_CMN_MEM_START_ADDR;
		#elif (CORTEX_M7_1 == 1)
		IPC_SHM_Rx_Start_Addr = (uint32)IPC_SHARE_CM1_RXFR_CMN_MEM_START_ADDR;
		#elif (CORTEX_M7_2 == 1)
		IPC_SHM_Rx_Start_Addr = (uint32)IPC_SHARE_CM2_RXFR_CMN_MEM_START_ADDR;
		#endif
	}
#endif

	else{}

	return IPC_SHM_Rx_Start_Addr;
}


/**************************************************************************************************
*                               IPC Struct Init
*
* [External] IPC Struct Init
*
* @param        siCh, *pIpcHandler
* @return       void
*
* Notes
*
***************************************************************************************************/
void IPC_StructInit(    IPCSvcCh_t siCh, IPCHandler_t* pIpcHandler)
{
    pIpcHandler->ihIpcStatus      = IPC_NULL;
    pIpcHandler->ihSetParam.vTime = 0;
    pIpcHandler->ihSetParam.vMin  = 0;
    pIpcHandler->ihTime           = 0;
    pIpcHandler->ihMin            = 0;
    pIpcHandler->ihIsWait         = 0;

	if(pIpcHandler->ihIpcOption.isShm == 1)
	{
		pIpcHandler->writeBuffer.startAddr = Get_IPC_SHM_Tx_Start_Addr(siCh);
		pIpcHandler->writeBuffer.bufferSize = IPC_SHM_SRAM_SIZE_per_Ch;
	    pIpcHandler->receiveBuffer.startAddr = Get_IPC_SHM_Rx_Start_Addr(siCh);
		pIpcHandler->receiveBuffer.bufferSize = IPC_SHM_SRAM_SIZE_per_Ch;

		pIpcHandler->Ipc_Max_Packet_Size = IPC_SHM_MAX_PACKET_SIZE;
	}
	else
	{
		pIpcHandler->Ipc_Max_Packet_Size = IPC_MBOX_MAX_PACKET_SIZE;
	}
}

/**************************************************************************************************
*                               IPC Set Status
*
* [External] Set Status
*
* @param        siCh, status, flag
* @return       void
*
* Notes
*
***************************************************************************************************/
void IPC_SetStatus(    IPCSvcCh_t siCh,IPCStatus_t status, uint32 flag)
{
    gIPCHandler[siCh].ihIpcStatus = status;
    gIPCHandler[siCh].feature     = flag;
}

/**************************************************************************************************
*                               IPC Get Status
*
* [External] Get Status
*
* @param        siCh
* @return       Status
*
* Notes
*
***************************************************************************************************/
IPCStatus_t IPC_GetStatus(    IPCSvcCh_t siCh)
{
    return gIPCHandler[siCh].ihIpcStatus;
}

/**************************************************************************************************
*                               IPC Set buffer
*
* [Internal] Set buffer
*
* @param        siCh
* @return       void
*
* Notes
*
***************************************************************************************************/
static void IPC_SetBuffer(    IPCSvcCh_t siCh)
{
    IPC_WbufferLock(siCh);
    IPC_BufferInit(&gIPCHandler[siCh].ihReadRingBuffer, (uint8*)&(gIPCRingBuffer[siCh]), MAX_IPC_RING_BUFF_SIZE);
    IPC_WbufferUnlock(siCh);
}


/**************************************************************************************************
*                               IPC Receive Control Command
*
* [Internal] Receive Control Command
*
* @param        siCh, *pMsg
* @return       void
*
* Notes
*
***************************************************************************************************/
static void IPC_ReceiveCtlCmd(    IPCSvcCh_t siCh,    const IPCMboxMsgReg_t* pMsg)
{
    uint32        ack;
    uint32        temp;
    uint32        seqID;
    IPCCmdId_t    cmdID;
    IPCCmdId_t    srcIden;
    IPCCmdType_t  cmdType;

    if(pMsg != NULL_PTR)
    {
        seqID   = pMsg->mmReg[0];
        temp    = pMsg->mmReg[1] & CMD_ID_MASK;
        cmdID   = (IPCCmdId_t) temp;
        temp    = (pMsg->mmReg[1] & CMD_TYPE_MASK ) >> 16U;
        cmdType = (IPCCmdType_t) temp;
        temp    = pMsg->mmReg[2] & CMD_ID_MASK;
        srcIden = (IPCCmdId_t) temp;
        ack     = gIPCHandler[siCh].ihIpcOption.isAck;

        switch((IPCCmdId_t) cmdID)
        {
            case IPC_OPEN :
            {
                IPC_SetStatus(siCh, IPC_READY, (uint32) pMsg->mmReg[2]);

                if(ack == IPC_O_ACK)
                {
                   (void) IPC_SendAck(siCh, seqID, IPC_ACK, CTL_CMD, pMsg->mmReg[1], IPC_FLAG_USENAMCK);
                }

                break;
            }

            case IPC_CLOSE :
            {
                gIPCHandler[siCh].ihIpcStatus = IPC_INIT;
                (void) SAL_MemSet((uint8*)&(gIPCRingBuffer[siCh]), 0, MAX_IPC_RING_BUFF_SIZE);
                IPC_BufferOverFlowWakeUp(siCh, READ_BUF_CLOSE_BIT);
                break;
            }

            case IPC_SEND_PING :
            {
                if(ack == IPC_O_ACK)
                {
                    (void) IPC_SendAck(siCh, seqID, IPC_ACK, CTL_CMD, pMsg->mmReg[1], 0U);
                }

                break;
            }

            case IPC_ACK :
            {
                if (ack == IPC_O_ACK)
                {
                    if (srcIden == IPC_OPEN)
                    {
                        (void) IPC_SetStatus(siCh, IPC_READY, (uint32) pMsg->mmReg[2]);
                    }
                    else
                    {
                        (void) IPC_CmdWakeUp(siCh, cmdType, pMsg->mmReg[0], 0U);
                    }
                }
                break;
            }
            case IPC_NACK :
            {
                if (ack == IPC_O_ACK)
                {
                   (void) IPC_CmdWakeUp(siCh, cmdType, pMsg->mmReg[0], 1U);
                }
                break;
            }
            default :
            {
        	    IPC_DBG("%s, ch[%d] cmdID[%d]\n", __func__, siCh, cmdID);
                break;
            }
        }
    }
}

/**************************************************************************************************
*                               IPC Receive Write Command
*
* [Internal] Receive Write Command
*
* @param        siCh, seqID, *pMsg, readSize
* @return       IPC_Ret
*
* Notes
*
***************************************************************************************************/
static int IPC_ReceiveWriteCmdSafe(    IPCSvcCh_t siCh, uint32 seqID, const IPCMboxMsgReg_t* pMsg, uint32 readSize)
{
    int32 ret = IPC_BUFFER_ERROR;

    IPC_RbufferLock(siCh);

    if((readSize > 0U) && (readSize <= MAX_IPC_PACKET_SIZE))
    {
        if(readSize < IPC_BufferFreeSpace(&gIPCHandler[siCh].ihReadRingBuffer))
        {
            ret = IPC_PushBuffer(&gIPCHandler[siCh].ihReadRingBuffer, (const uint8 *) pMsg->mmDat, readSize);

            if (((gIPCHandler[siCh].feature & IPC_FLAG_USENAMCK) == IPC_FLAG_USENAMCK) && (ret < 0))
            {
                if (ret == IPC_BUFFER_FULL)
                {
                    (void) IPC_SendAck(siCh, seqID, IPC_NACK, WRITE_CMD, pMsg->mmReg[1], IPC_NACK_REASON_BUFFFUL);
                }
                else
                {
                    (void) IPC_SendAck(siCh, seqID, IPC_NACK, WRITE_CMD, pMsg->mmReg[1], IPC_NACK_REASON_BUFFERR);
                }
            }
        }
        else
        {
            if ((gIPCHandler[siCh].feature & IPC_FLAG_USENAMCK) == IPC_FLAG_USENAMCK)
            {
                (void) IPC_SendAck(siCh, seqID, IPC_NACK, WRITE_CMD, pMsg->mmReg[1], IPC_NACK_REASON_BUFFFUL);
                ret = IPC_BUFFER_FULL;
            }
            else
            {
                IPC_BufferOverFlowWakeUp(siCh, READ_BUF_OVERFLOW_BIT);
                ret = IPC_PushBufferOverWrite(&gIPCHandler[siCh].ihReadRingBuffer, (const uint8 *) pMsg->mmDat, readSize);

                if (ret < 0)
                {
                    ret = IPC_ERR_BUFFER;
                }
            }
        }
    }
    IPC_RbufferUnlock(siCh);

    return ret;
}

/**************************************************************************************************
*                               IPC Receive Write Command
*
* [Internal] Receive Write Command
*
* @param        siCh, *pMsg
* @return       void
*
* Notes
*
***************************************************************************************************/
static void IPC_ReceiveWriteCmd(    IPCSvcCh_t siCh,    const IPCMboxMsgReg_t* pMsg)
{
    uint32        readSize;
    uint32        seqID;
    uint32        temp;
    uint32        ack;
    IPCCmdId_t    cmdID;
    IPCCmdType_t  cmdType;

    readSize = 0U;
    seqID    = 0U;

    if(pMsg != NULL_PTR)
    {
        seqID    = pMsg->mmReg[0];
        temp     = pMsg->mmReg[1] & CMD_ID_MASK;
        cmdID    = (IPCCmdId_t) temp;
        temp     = (pMsg->mmReg[1] & CMD_TYPE_MASK ) >> 16U;
        cmdType  = (IPCCmdType_t) temp;
        readSize = pMsg->mmReg[2];
        ack      = gIPCHandler[siCh].ihIpcOption.isAck;

        switch((IPCCmdId_t) cmdID)
        {
            case IPC_ACK :
            {
                if (ack == IPC_O_ACK)
                {
                    (void) IPC_CmdWakeUp(siCh, cmdType, pMsg->mmReg[0], 0U);
                }
                break;
            }
            case IPC_NACK :
            {
                if (ack == IPC_O_ACK)
                {
                   (void) IPC_CmdWakeUp(siCh, cmdType, pMsg->mmReg[0], 1U);
                }
                break;
            }

			case IPC_WRITE :
			{						
				if(IPC_BUFFER_OK == IPC_ReceiveWriteCmdSafe(siCh, seqID, pMsg, readSize))
				{	
					if(gIPCHandler[siCh].ihIpcOption.isAck == IPC_O_ACK)
					{				
						if (0L > IPC_SendAck(siCh, seqID, IPC_ACK, WRITE_CMD, pMsg->mmReg[1], 0U))
						{
							IPC_DBG("%s send ack fail\n", __func__);
						}	
					}

					if(gIPCHandler[siCh].ihIsWait == 1U)
					{
						if(gIPCHandler[siCh].ihMin <= (uint32) IPC_BufferDataAvailable(&gIPCHandler[siCh].ihReadRingBuffer))
						{
							IPC_ReadWakeUp(siCh);
						}
					}

					IPC_Parser_WakeUp(siCh);
				}

				break;
			}
            default :
            {
                IPC_DBG("%s cmdID[0x%04X] Received\n", __func__, cmdID);
                break;
            }
        }
    }
}


/**************************************************************************************************
*                               IPC_ContorlTask function
*
* [Internal] ContorlTask function
*
* @param        siCh
* @return       void
*
* Notes
*
***************************************************************************************************/

static void IPC_ContorlTask(    IPCSvcCh_t siCh)
{
    uint32        temp;
    IPCCmdType_t  cmdType;
	
    temp    = (recv[siCh].mmReg[1] & CMD_TYPE_MASK ) >> 16U;
    cmdType = (IPCCmdType_t) temp;

    switch((IPCCmdType_t) cmdType)
    {
        case CTL_CMD :
        {
            IPC_ReceiveCtlCmd(siCh, (const IPCMboxMsgReg_t *) &recv[siCh]);
            break;
        }

        case WRITE_CMD :
        {
            IPC_ReceiveWriteCmd(siCh, (const IPCMboxMsgReg_t *) &recv[siCh]);				
            break;
        }

        default :
        {
            IPC_DBG("%s, cmdType %d\n", __func__, cmdType);
            break;
        }
    }
}



/**************************************************************************************************
*                               IPC_Initialize
*
* [Internal] IPC_Initialize
*
* @param        siCh
* @return       IPC_Ret
*
* Notes
*
***************************************************************************************************/
int32 IPC_Initialize(    IPCSvcCh_t siCh)
{
    int32 ret;

    ret        = IPC_SUCCESS;

    IPC_OsResourceInit(siCh);
    IPC_SetBuffer(siCh);

	if(ret == IPC_SUCCESS)
    {
		gIPCHandler[siCh].ihIpcStatus = IPC_INIT;

		mcu_printf("%s, %s initialized\n", __func__, IPC_Initialize_str[siCh]);
    }

    return ret;
}

/**************************************************************************************************
*                               IPC_Release
*
* [Internal] IPC_Release
*
* @param        siCh
* @return       void
*
* Notes
*
***************************************************************************************************/
void IPC_Release(    IPCSvcCh_t siCh)
{
    IPC_ReadWakeUp(siCh);           /* wake up pending thread */

    (void) IPC_SendClose(siCh);
    IPC_OsResourceRelease(siCh);
}


