/*
***************************************************************************************************
*
*   FileName : system_monitoring.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to 
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute 
*   any express or implied warranty of any kind, including without limitation, any warranty of 
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright 
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute 
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement 
*   between Telechips and Company.
*
***************************************************************************************************
*/
 
#include <app_cfg.h>
 
#if (VNG_APP_IPI_Sample_EN == 1)
 
#include "debug.h"
#include "ipi.h"
#include <ipi_sample.h>
 
/*
***************************************************************************************************
*                                             DEFINITIONS 
***************************************************************************************************
*/
#define IPI_APP_DBG_ENABLE 
#ifdef IPI_APP_DBG_ENABLE 
#define IPI_APP_DBG(fmt, args...) mcu_printf(fmt, ## args)
#else
#define IPI_APP_DBG(fmt, args...)  
#endif

 
/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/

static void IPI_App_Sample_Task 
(
    void *                              pArg
);



/*
***************************************************************************************************
*                                         FUNCTIONS 
***************************************************************************************************
*/

MboxMessage_t  Send_MboxMessage;

static void Make_IPI_Send_Data(uint32 add)
{
    uint32 i;
 
    for (i =0UL; i < (uint32)8; i++)
    {
        Send_MboxMessage.Cmd[i] = add;
    }
	for (i =0UL; i < (uint32)128; i++)
    {
        Send_MboxMessage.Data[i] = add;
    }

	Send_MboxMessage.CmdLen = 8;
	Send_MboxMessage.DataLen = 128;
}


#if ( CORTEX_M7_0 == 0)
static void IPC_MBOX_RxCB_CM7_0_IPC_U(const IpiMessage_t * sIpiMessage)
{

	uint8 * scmd;
	uint8 devname[6];

	static uint32 old_data = 1;
	
	scmd    = (uint8 *)sIpiMessage->Cmd;
	devname[0] = scmd[28];
	devname[1] = scmd[29];
	devname[2] = scmd[30];
	devname[3] = scmd[31];
	devname[4] = scmd[2];
	devname[5] = scmd[3];

	mcu_printf("[%s][%d]: [Devname : %c%c%c%c%c%c], Data : %d\n",__FUNCTION__, __LINE__,devname[0],devname[1],devname[2],devname[3],devname[4],devname[5],sIpiMessage->Data[0]);
}

static void IPC_MBOX_RxCB_CM7_0_IPC_TPA(const IpiMessage_t * sIpiMessage)
{

	uint8 * scmd;
	uint8 devname[6];

	static uint32 old_data = 1;
	
	scmd    = (uint8 *)sIpiMessage->Cmd;
	devname[0] = scmd[28];
	devname[1] = scmd[29];
	devname[2] = scmd[30];
	devname[3] = scmd[31];
	devname[4] = scmd[2];
	devname[5] = scmd[3];

	mcu_printf("[%s][%d]: [Devname : %c%c%c%c%c%c], Data : %d\n",__FUNCTION__, __LINE__,devname[0],devname[1],devname[2],devname[3],devname[4],devname[5],sIpiMessage->Data[0]);
}

static void IPC_MBOX_RxCB_CM7_0_IPC_LPA(const IpiMessage_t * sIpiMessage)
{
	uint8 * scmd;
	uint8 devname[6];

	static uint32 old_data = 1;
	
	scmd    = (uint8 *)sIpiMessage->Cmd;
	devname[0] = scmd[28];
	devname[1] = scmd[29];
	devname[2] = scmd[30];
	devname[3] = scmd[31];
	devname[4] = scmd[2];
	devname[5] = scmd[3];

	mcu_printf("[%s][%d]: [Devname : %c%c%c%c%c%c], Data : %d\n",__FUNCTION__, __LINE__,devname[0],devname[1],devname[2],devname[3],devname[4],devname[5],sIpiMessage->Data[0]);
}
#endif

#if ( CORTEX_M7_1 == 0)
static void IPC_MBOX_RxCB_CM7_1_IPC_U(const IpiMessage_t * sIpiMessage)
{

	uint8 * scmd;
	uint8 devname[6];

	static uint32 old_data = 1;
	
	scmd    = (uint8 *)sIpiMessage->Cmd;
	devname[0] = scmd[28];
	devname[1] = scmd[29];
	devname[2] = scmd[30];
	devname[3] = scmd[31];
	devname[4] = scmd[2];
	devname[5] = scmd[3];

	mcu_printf("[%s][%d]: [Devname : %c%c%c%c%c%c], Data : %d\n",__FUNCTION__, __LINE__,devname[0],devname[1],devname[2],devname[3],devname[4],devname[5],sIpiMessage->Data[0]);
}

static void IPC_MBOX_RxCB_CM7_1_IPC_TPA(const IpiMessage_t * sIpiMessage)
{

	uint8 * scmd;
	uint8 devname[6];

	static uint32 old_data = 1;
	
	scmd    = (uint8 *)sIpiMessage->Cmd;
	devname[0] = scmd[28];
	devname[1] = scmd[29];
	devname[2] = scmd[30];
	devname[3] = scmd[31];
	devname[4] = scmd[2];
	devname[5] = scmd[3];

	mcu_printf("[%s][%d]: [Devname : %c%c%c%c%c%c], Data : %d\n",__FUNCTION__, __LINE__,devname[0],devname[1],devname[2],devname[3],devname[4],devname[5],sIpiMessage->Data[0]);
}

static void IPC_MBOX_RxCB_CM7_1_IPC_LPA(const IpiMessage_t * sIpiMessage)
{
	uint8 * scmd;
	uint8 devname[6];

	static uint32 old_data = 1;
	
	scmd    = (uint8 *)sIpiMessage->Cmd;
	devname[0] = scmd[28];
	devname[1] = scmd[29];
	devname[2] = scmd[30];
	devname[3] = scmd[31];
	devname[4] = scmd[2];
	devname[5] = scmd[3];

	mcu_printf("[%s][%d]: [Devname : %c%c%c%c%c%c], Data : %d\n",__FUNCTION__, __LINE__,devname[0],devname[1],devname[2],devname[3],devname[4],devname[5],sIpiMessage->Data[0]);
}
#endif

#if ( CORTEX_M7_2 == 0)
static void IPC_MBOX_RxCB_CM7_2_IPC_U(const IpiMessage_t * sIpiMessage)
{

	uint8 * scmd;
	uint8 devname[6];

	static uint32 old_data = 1;
	
	scmd    = (uint8 *)sIpiMessage->Cmd;
	devname[0] = scmd[28];
	devname[1] = scmd[29];
	devname[2] = scmd[30];
	devname[3] = scmd[31];
	devname[4] = scmd[2];
	devname[5] = scmd[3];

	mcu_printf("[%s][%d]: [Devname : %c%c%c%c%c%c], Data : %d\n",__FUNCTION__, __LINE__,devname[0],devname[1],devname[2],devname[3],devname[4],devname[5],sIpiMessage->Data[0]);
}

static void IPC_MBOX_RxCB_CM7_2_IPC_TPA(const IpiMessage_t * sIpiMessage)
{

	uint8 * scmd;
	uint8 devname[6];

	static uint32 old_data = 1;
	
	scmd    = (uint8 *)sIpiMessage->Cmd;
	devname[0] = scmd[28];
	devname[1] = scmd[29];
	devname[2] = scmd[30];
	devname[3] = scmd[31];
	devname[4] = scmd[2];
	devname[5] = scmd[3];

	mcu_printf("[%s][%d]: [Devname : %c%c%c%c%c%c], Data : %d\n",__FUNCTION__, __LINE__,devname[0],devname[1],devname[2],devname[3],devname[4],devname[5],sIpiMessage->Data[0]);
}

static void IPC_MBOX_RxCB_CM7_2_IPC_LPA(const IpiMessage_t * sIpiMessage)
{
	uint8 * scmd;
	uint8 devname[6];

	static uint32 old_data = 1;
	
	scmd    = (uint8 *)sIpiMessage->Cmd;
	devname[0] = scmd[28];
	devname[1] = scmd[29];
	devname[2] = scmd[30];
	devname[3] = scmd[31];
	devname[4] = scmd[2];
	devname[5] = scmd[3];

	mcu_printf("[%s][%d]: [Devname : %c%c%c%c%c%c], Data : %d\n",__FUNCTION__, __LINE__,devname[0],devname[1],devname[2],devname[3],devname[4],devname[5],sIpiMessage->Data[0]);
}
#endif

#if ( CORTEX_M7_NP == 0)
static void IPC_MBOX_RxCB_CM7_NP_IPC_U(const IpiMessage_t * sIpiMessage)
{

	uint8 * scmd;
	uint8 devname[6];

	static uint32 old_data = 1;
	
	scmd    = (uint8 *)sIpiMessage->Cmd;
	devname[0] = scmd[28];
	devname[1] = scmd[29];
	devname[2] = scmd[30];
	devname[3] = scmd[31];
	devname[4] = scmd[2];
	devname[5] = scmd[3];

	mcu_printf("[%s][%d]: [Devname : %c%c%c%c%c%c], Data : %d\n",__FUNCTION__, __LINE__,devname[0],devname[1],devname[2],devname[3],devname[4],devname[5],sIpiMessage->Data[0]);
}

static void IPC_MBOX_RxCB_CM7_NP_IPC_TPA(const IpiMessage_t * sIpiMessage)
{

	uint8 * scmd;
	uint8 devname[6];

	static uint32 old_data = 1;
	
	scmd    = (uint8 *)sIpiMessage->Cmd;
	devname[0] = scmd[28];
	devname[1] = scmd[29];
	devname[2] = scmd[30];
	devname[3] = scmd[31];
	devname[4] = scmd[2];
	devname[5] = scmd[3];

	mcu_printf("[%s][%d]: [Devname : %c%c%c%c%c%c], Data : %d\n",__FUNCTION__, __LINE__,devname[0],devname[1],devname[2],devname[3],devname[4],devname[5],sIpiMessage->Data[0]);
}

static void IPC_MBOX_RxCB_CM7_NP_IPC_LPA(const IpiMessage_t * sIpiMessage)
{
	uint8 * scmd;
	uint8 devname[6];

	static uint32 old_data = 1;
	
	scmd    = (uint8 *)sIpiMessage->Cmd;
	devname[0] = scmd[28];
	devname[1] = scmd[29];
	devname[2] = scmd[30];
	devname[3] = scmd[31];
	devname[4] = scmd[2];
	devname[5] = scmd[3];

	mcu_printf("[%s][%d]: [Devname : %c%c%c%c%c%c], Data : %d\n",__FUNCTION__, __LINE__,devname[0],devname[1],devname[2],devname[3],devname[4],devname[5],sIpiMessage->Data[0]);
}
#endif



uint8	IPI_Send_Order = 0;
static void IPI_App_Sample_Task(void * pArg)
{
	uint32	add = 0;

    (void)pArg;
	
#if ( CORTEX_M7_0 == 0)
	ipi_register(IPI_CH_CM7_0_USER,&IPC_MBOX_RxCB_CM7_0_IPC_U);
	ipi_register(IPI_CH_CM7_0_TPA,&IPC_MBOX_RxCB_CM7_0_IPC_TPA);
	ipi_register(IPI_CH_CM7_0_LPA,&IPC_MBOX_RxCB_CM7_0_IPC_LPA);
#endif
#if ( CORTEX_M7_1 == 0)
	ipi_register(IPI_CH_CM7_1_USER,&IPC_MBOX_RxCB_CM7_1_IPC_U);
	ipi_register(IPI_CH_CM7_1_TPA,&IPC_MBOX_RxCB_CM7_1_IPC_TPA);
	ipi_register(IPI_CH_CM7_1_LPA,&IPC_MBOX_RxCB_CM7_1_IPC_LPA);
#endif
#if ( CORTEX_M7_2 == 0)
	ipi_register(IPI_CH_CM7_2_USER,&IPC_MBOX_RxCB_CM7_2_IPC_U);
	ipi_register(IPI_CH_CM7_2_TPA,&IPC_MBOX_RxCB_CM7_2_IPC_TPA);
	ipi_register(IPI_CH_CM7_2_LPA,&IPC_MBOX_RxCB_CM7_2_IPC_LPA);
#endif
#if ( CORTEX_M7_NP == 0)
	ipi_register(IPI_CH_CM7_NP_USER,&IPC_MBOX_RxCB_CM7_NP_IPC_U);
	ipi_register(IPI_CH_CM7_NP_TPA,&IPC_MBOX_RxCB_CM7_NP_IPC_TPA);
	ipi_register(IPI_CH_CM7_NP_LPA,&IPC_MBOX_RxCB_CM7_NP_IPC_LPA);
#endif	

    (void)SAL_TaskSleep(5000);

	while(1)
	{
		add++;
#if ( CORTEX_M7_0 == 1)
		if(IPI_Send_Order == 0)
		{
			Make_IPI_Send_Data(add);
			if(ipi_mailbox_send_message(IPI_CH_CM7_2_USER,&Send_MboxMessage.Cmd, &Send_MboxMessage.Data, Send_MboxMessage.DataLen) == SAL_RET_FAILED)
			{
				mcu_printf("Data : %d, Failure\n  ",add); //QAC
			}
			IPI_Send_Order = 1;
		}
		else if(IPI_Send_Order == 1)
		{
			Make_IPI_Send_Data(add);
			ipi_mailbox_send_message(IPI_CH_CM7_2_TPA,&Send_MboxMessage.Cmd, &Send_MboxMessage.Data, Send_MboxMessage.DataLen);
			IPI_Send_Order = 2;
		}
		else if(IPI_Send_Order == 2)
		{
			Make_IPI_Send_Data(add);
			ipi_mailbox_send_message(IPI_CH_CM7_2_LPA,&Send_MboxMessage.Cmd, &Send_MboxMessage.Data, Send_MboxMessage.DataLen);
			IPI_Send_Order = 3;
		}
		else{}
		
/*
		if(add >= 100)
		{	
			add = 100000;
			IPI_Send_Order = 3;
		}
*/
#elif ( CORTEX_M7_1 == 1)
		if(IPI_Send_Order == 0)
		{
			Make_IPI_Send_Data(add);
			ipi_mailbox_send_message(IPI_CH_CM7_2_USER,&Send_MboxMessage.Cmd, &Send_MboxMessage.Data, Send_MboxMessage.DataLen);
			IPI_Send_Order = 1;
		}
		else if(IPI_Send_Order == 1)
		{
			Make_IPI_Send_Data(add);
			ipi_mailbox_send_message(IPI_CH_CM7_2_TPA,&Send_MboxMessage.Cmd, &Send_MboxMessage.Data, Send_MboxMessage.DataLen);
			IPI_Send_Order = 2;
		}
		else if(IPI_Send_Order == 2)
		{
			Make_IPI_Send_Data(add);
			ipi_mailbox_send_message(IPI_CH_CM7_2_LPA,&Send_MboxMessage.Cmd, &Send_MboxMessage.Data, Send_MboxMessage.DataLen);
			IPI_Send_Order = 3;
		}
		else{}

#elif ( CORTEX_M7_2 == 1)
		if(IPI_Send_Order == 0)
		{
			Make_IPI_Send_Data(add);
			ipi_mailbox_send_message(IPI_CH_CM7_NP_USER,&Send_MboxMessage.Cmd, &Send_MboxMessage.Data, Send_MboxMessage.DataLen);
			IPI_Send_Order = 1;
		}
		else if(IPI_Send_Order == 1)
		{
			Make_IPI_Send_Data(add);
			ipi_mailbox_send_message(IPI_CH_CM7_NP_TPA,&Send_MboxMessage.Cmd, &Send_MboxMessage.Data, Send_MboxMessage.DataLen);
			IPI_Send_Order = 2;
		}
		else if(IPI_Send_Order == 2)
		{
			Make_IPI_Send_Data(add);
			ipi_mailbox_send_message(IPI_CH_CM7_NP_LPA,&Send_MboxMessage.Cmd, &Send_MboxMessage.Data, Send_MboxMessage.DataLen);
			IPI_Send_Order = 3;
		}
		else{}

#elif ( CORTEX_M7_NP == 1)
		if(IPI_Send_Order == 0)
		{		
			Make_IPI_Send_Data(add);
			ipi_mailbox_send_message(IPI_CH_CM7_2_USER,&Send_MboxMessage.Cmd, &Send_MboxMessage.Data, Send_MboxMessage.DataLen);
			IPI_Send_Order = 1;
		}
		else if(IPI_Send_Order == 1)
		{
			Make_IPI_Send_Data(add);
			ipi_mailbox_send_message(IPI_CH_CM7_2_TPA,&Send_MboxMessage.Cmd, &Send_MboxMessage.Data, Send_MboxMessage.DataLen);
			IPI_Send_Order = 2;
		}
		else if(IPI_Send_Order == 2)
		{
			Make_IPI_Send_Data(add);
			ipi_mailbox_send_message(IPI_CH_CM7_2_LPA,&Send_MboxMessage.Cmd, &Send_MboxMessage.Data, Send_MboxMessage.DataLen);
			IPI_Send_Order = 3;
		}
		else{}		
#endif				

		
	    (void)SAL_TaskSleep(10);
	}
}


void IPI_CreateAppTask(void)
{
    static uint32 IPIAppTaskID;
    static uint32 IPIAppTaskStk[ACFG_TASK_MEDIUM_STK_SIZE];

    (void)SAL_TaskCreate(&IPIAppTaskID,
                         (const uint8 *)"IPIAppsample",
                         (SALTaskFunc)&IPI_App_Sample_Task,
                         &IPIAppTaskStk[0],
                         ACFG_TASK_MEDIUM_STK_SIZE,
                         7, NULL_PTR);
                         
}
#endif

