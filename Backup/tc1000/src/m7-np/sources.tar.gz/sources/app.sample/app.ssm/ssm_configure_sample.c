/*
***************************************************************************************************
*
*   FileName : ssm_configure_sample.c
*
*   Copyright (c) Telechips Inc.
*
*   Description : Sample code of Register Duplication Check for SYSTEM SAFETY MECHANISM (SM) CONTROL MODULE
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include "ssm.h"
#include <nvic.h>
#include <debug.h>
#include <ssm_configure_sample.h>

#if ( SIC_BSP_SUPPORT_DRIVER_FMU )
#include "fmu.h"
#endif

#if 0
void SSM_Configure_SampleMain(void);
#endif
/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/
// SSM
#define SSM_SOFT_FAULT_EN_GROUP    (0x00UL) //GRP_EN[0]
#define SSM_SOFT_FAULT_EN_BIT_MAP    (uint32)(0x1UL << 0x0UL) //GRP_EN[0].SRAM0_ECC_ERR_REQ_EN[bit:0]
static uint32 * puiSSMFaultInjectTestReg = (uint32 *)0x1B921000UL;  //GRP_EN[0].SRAM0_ECC_ERR_REQ_EN
//static uint32 * puiSSMFaultInjectTestPsswordReg = (uint32 *)SSM_ECC_IMC_CFG_WR_PW;
static uint32 * puiSSMFaultInjectTestPsswordReg = (uint32 *)0x1B92105CUL;//0x1B921070UL;

static uint32 SSMFMUHandleActivated = 0UL;
static uint32 uiSSMBitToggle = 0UL;

#if ( SIC_BSP_SUPPORT_DRIVER_FMU )
static void SSMConfigureFMUFaultIRQHandlerSample(void * pArg)
{
    (void)pArg;
    (void)FMU_IsrClr(FMU_ID_SYS_SM_CFG);

    //recover by original value
    *(uint32 *)puiSSMFaultInjectTestPsswordReg = SSM_CFG_PSWD;
    *(uint32 *)puiSSMFaultInjectTestReg = uiSSMBitToggle;

    // clear fault status
    (void)SSM_SafetySoftFaultStatusClear(SSM_SOFT_FAULT_EN_GROUP);

    SSMFMUHandleActivated = 1UL;
}
#endif  /* End of SIC_BSP_SUPPORT_DRIVER_FMU */

void SSMSoftFaultCheckTestByUsingFaultInjectionSample(void)
{
    SSMFMUHandleActivated = 0U;

    // Enable SoftFaultCheck for group[0]
    (void)SSM_SafetySoftFaultCheckEnable(SSM_SOFT_FAULT_EN_GROUP, SSM_SOFT_FAULT_EN_BIT_MAP);

#if ( SIC_BSP_SUPPORT_DRIVER_FMU )
    //set fmu handle and enalbe fmu notifying
    (void)FMU_IsrHandler(FMU_ID_SYS_SM_CFG, FMU_SVL_LOW, &SSMConfigureFMUFaultIRQHandlerSample, NULL_PTR);
    (void)FMU_Set(FMU_ID_SYS_SM_CFG);
    (void)FMU_IsrClr(FMU_ID_SYS_SM_CFG);
#endif
    // Enalbe group[0] Fault Injection Test Mode
    (void)SSM_SafetyFaultInjectionTestModeEnable(SSM_SOFT_FAULT_EN_GROUP);

    // Manually Inject Fault into puiCoreFaultInjectTestReg
    *(uint32 *)puiSSMFaultInjectTestPsswordReg = SSM_CFG_PSWD;
    uiSSMBitToggle = *(uint32 *)puiSSMFaultInjectTestReg;
    *(uint32 *)puiSSMFaultInjectTestReg = ~uiSSMBitToggle;

    do
    {
        __asm ("NOP");
    }
    while (SSMFMUHandleActivated == 0UL);


	//Disable SoftFaultCheck for group[0]
	(void)SSM_SafetySoftFaultCheckEnable(SSM_SOFT_FAULT_EN_GROUP, 0);
}

#if 0
void SSM_Configure_SampleMain(void)
{
    //SSM Register Duplication Check
    SSMSoftFaultCheckTestByUsingFaultInjectionSample();

}
#endif

