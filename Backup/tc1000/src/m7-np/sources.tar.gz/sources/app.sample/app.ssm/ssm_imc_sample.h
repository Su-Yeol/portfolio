/*
***************************************************************************************************
*
*   FileName : ssm_imc_sample.h
*
*   Copyright (c) Telechips Inc.
*
*   Description : Sample code of IMC ECC
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/


#ifndef SSM_IMC_SAMPLE_HEADER_H
#define SSM_IMC_SAMPLE_HEADER_H

/*
*********************************************************************************************************
*                                                 DEFINES
*********************************************************************************************************
*/

#define wr_data_32b(addr, data)         (*(volatile uint32*)(addr)) = data


/* memory information */
#define SRAM0_RW_SIZE_BYTE              (2048u)
#define SRAM0_RW_SIZE_WORD              (SRAM0_RW_SIZE_BYTE/4u)
#define SRAM0_LAST_2K_SADDR             (0xC0080000u - SRAM0_RW_SIZE_BYTE)
#define RAM0_START                      (0x60u) //except for vector table
#define RAM0_BASE                       (0xC0000000u) // 512kb
#define RAM1_BASE                       (0xC1000000u) // 64kb
#define RAM0_SIZE                       (512u*1024u)
#define RAM_BLOCK                       (64u*1024u)
#define RAM1_SIZE                       (64u*1024u)
#define ROM_SIZE                        (128u*1024u)

#define MAX_RW_TEST                     (10u)
#define MAX_ECC_TEST                    (20u)

#define IMC_OK                          (0u)
#define IMC_FAIL                        (1u)

typedef volatile uint32 vuint;

typedef enum {
    MEM_TYPE_SRAM0 = 0u,
    MEM_TYPE_SRAM1,
    MEM_TYPE_ROM,
    MAX_MEM_TYPE
} IMC_MEM_TYPE;

/*
*********************************************************************************************************
*                                                 EXTERNS
*********************************************************************************************************
*/
extern void SSMIMC_EccErrorCallback(IMCTypeID_t uiType, uint32 uiStatus);
extern void SSMIMC_TestMain(int32 iTestNum);


#endif /* SSM_IMC_SAMPLE_HEADER_H */

