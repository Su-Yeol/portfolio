/*
***************************************************************************************************
*
*   FileName : ssm_imc_sample.c
*
*   Copyright (c) Telechips Inc.
*
*   Description : Sample code of IMC ECC
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include <sal_internal.h>
#include "ssm.h"
#include <gic.h>
#include "fmu.h"
#include <debug.h>
#include <ssm_imc_sample.h>


static uint32 gImcEccIntFlagSram0 = 0u;
static uint32 gImcEccIntFlagSram1 = 0u;
static uint32 gImcEccIntStatusSram0 = 0u;
static uint32 gImcEccIntStatusSram1 = 0u;

/*
*********************************************************************************************************
*                                                 EXTERNS
*********************************************************************************************************
*/
static void SSMIMC_MemFill(uint32 uiBase, uint32 uiSize, uint32 uiVal);
static uint32 SSMIMC_Check1bitCorrection(uint32 uiFault0, uint32 uiFault1, uint32 uiAddr, uint32 uiData, IMC_MEM_TYPE uiType);
static uint32 SSMIMC_Check2bitDetection(uint32 uiFault0, uint32 uiFault1, uint32 uiAddr, uint32 uiData, IMC_MEM_TYPE uiType);
static uint32 SSMIMC_DataFaultInjection(IMC_MEM_TYPE uiType);
static uint32 SSMIMC_CheckDMEMAddrDetection(uint32 uiFaultAddr, uint32 uiAddr, uint32 uiData, IMC_MEM_TYPE uiType);
static uint32 SSMIMC_CheckEMEMAddrDetection(uint32 uiFaultAddr, uint32 uiAddr, uint32 uiData, IMC_MEM_TYPE uiType);
static uint32 SSMIMC_AddrFaultInjection(IMC_MEM_TYPE uiType);


/*
***************************************************************************************************
*                                          SSMIMC_MemFill
*
* Function to fill data to memory
* @parameter uiBase : address
* @parameter uiSize : data size
* @parameter uiVal : data
* @return
* Notes
*
***************************************************************************************************
*/
static void SSMIMC_MemFill(uint32 uiBase, uint32 uiSize, uint32 uiVal)
{
    uint32 i;

    for( i = 0u; i < (uiSize/4u); i++ )
    {
        wr_data_32b((uiBase + (i*4u)), uiVal);
    }
}

/*
***************************************************************************************************
*                                          SSMIMC_Check1bitCorrection
*
* Function to check 1bit correction
* @parameter uiFault0 : LSB invert
* @parameter uiFault1 : MSB invert
* @parameter iAddr : address
* @parameter uiData : data to write
* @parameter uiType : memory type
* @return : IMC_OK or IMC_FAIL
* Notes
*
***************************************************************************************************
*/
static uint32 SSMIMC_Check1bitCorrection(uint32 uiFault0, uint32 uiFault1, uint32 uiAddr, uint32 uiData, IMC_MEM_TYPE uiType)
{
    uint32 rdata, status;
    uint32 ret = IMC_OK;

    switch(uiType)
    {
        case MEM_TYPE_SRAM0:
            {
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(uiFault0, SSM_ECC_SRAM0_WR_LSB_DATA_INV);      //fault injection
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(uiFault1, SSM_ECC_SRAM0_WR_MSB_DATA_INV);      //fault injection
                *(vuint *)(RAM0_BASE+(uiAddr*4u)) = uiData;                     //write to sram0
                rdata = *(vuint *)(RAM0_BASE+(uiAddr*4u));                      //read from sram0

                if(uiData != rdata) {
                    ret = IMC_FAIL;
                }

                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0x00000000UL, SSM_ECC_SRAM0_WR_LSB_DATA_INV);    //fault injection clear
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0x00000000UL, SSM_ECC_SRAM0_WR_MSB_DATA_INV);    //fault injection clear
                status = SAL_ReadReg(SSM_ECC_SRAM0_ERR_STS);                //read sram0 fault status
                mcu_printf("[IMC TEST] : [SRAM-0] LSB : 0x%08x, MSB : 0x%08x, STATUS : 0x%08x, WDATA : 0x%08x, RDATA : 0x%08x, ADDR : %x, FADDR : 0x%08x\n", uiFault0, uiFault1, status, uiData, rdata, (uiAddr*4u), SAL_ReadReg(SSM_ECC_SRAM0_ERR_ADDR));
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0xffffffff, SSM_ECC_SRAM0_ERR_STS);            //fault status clear
            }
            break;

        case MEM_TYPE_SRAM1:
            {
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(uiFault0, SSM_ECC_SRAM1_WR_LSB_DATA_INV);      //fault injection
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(uiFault1, SSM_ECC_SRAM1_WR_MSB_DATA_INV);      //fault injection
                *(vuint *)(RAM1_BASE+(uiAddr*4u)) = uiData;                     //write to sram1
                rdata = *(vuint *)(RAM1_BASE+(uiAddr*4u));                      //read from sram1

                if(uiData != rdata) {
                    ret = IMC_FAIL;
                }

                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0x00000000, SSM_ECC_SRAM1_WR_LSB_DATA_INV);    //fault injection clear
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0x00000000, SSM_ECC_SRAM1_WR_MSB_DATA_INV);    //fault injection clear
                status = SAL_ReadReg(SSM_ECC_SRAM1_ERR_STS);                //read sram1 fault status
                mcu_printf("[IMC TEST] : [SRAM-1] LSB : 0x%08x, MSB : 0x%08x, STATUS : 0x%08x, WDATA : 0x%08x, RDATA : 0x%08x, ADDR : %x, FADDR : 0x%08x\n", uiFault0, uiFault1, status, uiData, rdata, (uiAddr*4u), SAL_ReadReg(SSM_ECC_SRAM1_ERR_ADDR));
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0xffffffff, SSM_ECC_SRAM1_ERR_STS);            //fault status clear
            }
            break;

        default:
            {
                mcu_printf("unknown memory type\n");
            }
            break;
    }

    return ret;
}

/*
***************************************************************************************************
*                                          SSMIMC_Check2bitDetection
*
* Function to check 2bit detection
* @parameter uiFault0 : LSB invert
* @parameter uiFault1 : MSB invert
* @parameter iAddr : address
* @parameter uiData : data to write
* @parameter uiType : memory type
* @return : IMC_OK or IMC_FAIL
* Notes
*
***************************************************************************************************
*/
static uint32 SSMIMC_Check2bitDetection(uint32 uiFault0, uint32 uiFault1, uint32 uiAddr, uint32 uiData, IMC_MEM_TYPE uiType)
{
    uint32 rdata, status;
    uint32 ret = IMC_OK;

    switch(uiType)
    {
        case MEM_TYPE_SRAM0:
            {
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(uiFault0, SSM_ECC_SRAM0_WR_LSB_DATA_INV);      //fault injection
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(uiFault1, SSM_ECC_SRAM0_WR_MSB_DATA_INV);      //fault injection
                *(vuint *)(RAM0_BASE+(uiAddr*4u)) = uiData;                     //write to sram0
                rdata = *(vuint *)(RAM0_BASE+(uiAddr*4u));                      //read from sram0

                if(uiData == rdata) {
                    ret = IMC_FAIL;
                }

                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0x00000000, SSM_ECC_SRAM0_WR_LSB_DATA_INV);    //fault injection clear
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0x00000000, SSM_ECC_SRAM0_WR_MSB_DATA_INV);    //fault injection clear
                status = SAL_ReadReg(SSM_ECC_SRAM0_ERR_STS);                //read sram0 fault status
                mcu_printf("[IMC TEST] : [SRAM-0] LSB : 0x%08x, MSB : 0x%08x, STATUS : 0x%08x, WDATA : 0x%08x, RDATA : 0x%08x, ADDR : %x, FADDR : 0x%08x\n", uiFault0, uiFault1, status, uiData, rdata, (uiAddr*4u), SAL_ReadReg(SSM_ECC_SRAM0_ERR_ADDR));
                *(vuint *)(RAM0_BASE+(uiAddr*4u)) = uiData;                     //temporary write to sram0
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0xffffffff, SSM_ECC_SRAM0_ERR_STS);            //fault status clear
            }
            break;

        case MEM_TYPE_SRAM1:
            {
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(uiFault0, SSM_ECC_SRAM1_WR_LSB_DATA_INV);      //fault injection
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(uiFault1, SSM_ECC_SRAM1_WR_MSB_DATA_INV);      //fault injection
                *(vuint *)(RAM1_BASE+(uiAddr*4u)) = uiData;                     //write to sram1
                rdata = *(vuint *)(RAM1_BASE+(uiAddr*4u));                      //read from sram1

                if(uiData == rdata) {
                    ret = IMC_FAIL;
                }

                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0x00000000, SSM_ECC_SRAM1_WR_LSB_DATA_INV);    //fault injection clear
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0x00000000, SSM_ECC_SRAM1_WR_MSB_DATA_INV);    //fault injection clear
                status = SAL_ReadReg(SSM_ECC_SRAM1_ERR_STS);                //read sram1 fault status
                mcu_printf("[IMC TEST] : [SRAM-1] LSB : 0x%08x, MSB : 0x%08x, STATUS : 0x%08x, WDATA : 0x%08x, RDATA : 0x%08x, ADDR : %x, FADDR : 0x%08x\n", uiFault0, uiFault1, status, uiData, rdata, (uiAddr*4u), SAL_ReadReg(SSM_ECC_SRAM1_ERR_ADDR));
                *(vuint *)(RAM1_BASE+(uiAddr*4u)) = uiData;                     //temporary write to  sram1
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0xffffffff, SSM_ECC_SRAM1_ERR_STS);            //fault status clear
            }
            break;

        default:
            {
                mcu_printf("unknown memory type\n");
            }
            break;
    }

    return ret;
}

/*
***************************************************************************************************
*                                          SSMIMC_DataFaultInjection
*
* Function to check data fault
* @parameter uiType : memory type
* @return : IMC_OK or IMC_FAIL
* Notes
*
***************************************************************************************************
*/
static uint32 SSMIMC_DataFaultInjection(IMC_MEM_TYPE uiType)
{
    uint8 ucErr = 0u;
    uint32 i, j, k;
    uint32 uiData;
    uint32 uiFault0;
    uint32 uiFault1;
    uint32 ret = IMC_FAIL;

    switch(uiType)
    {
        case MEM_TYPE_SRAM0: //SRAM-0
            {
                /* VECTOR_SIZE = 0x60, DMA_SZIE = 0x2000, ARM_STACK = 0x680 */
                mcu_printf("[IMC TEST] : START!! [SRAM-0], IMCTest Data Fault Injection\n");

                /******************************************* 1 bit error correction test *******************************************/
                mcu_printf("[IMC TEST] : 1bit error correction test\n");

                SSMIMC_MemFill((RAM0_BASE+RAM0_START), RAM0_SIZE, 0x00000000u);
                uiFault0 = 0x00000000u;
                uiFault1 = 0x00000000u;
                uiData = 0xFFFFFFFFu;

                for(i = RAM0_START; i < (MAX_ECC_TEST+RAM0_START); i++)
                {
                    //1bit sweeping
                    for(j=0; j<32u; j++)
                    {
                        uiFault0 = 1u<<j;
                        uiFault1 = 1u<<j;
                        uiData = 0xffffffffu;
                        ret = SSMIMC_Check1bitCorrection(uiFault0, uiFault1, i, uiData, uiType);

                        for(k=0u;k<10000u;k++); //delay for FMU interrupt
                        if((ret != IMC_OK) || (gImcEccIntFlagSram0 != 1u)) {
                            if(ucErr < 0xFFu) {
                                ucErr++;
                            }
                        }
                        gImcEccIntFlagSram0 = 0u;
                    }

                    //each byte 1bit sweeping
                    for(j=0u; j<8u; j++)
                    {
                        uiFault0 = 1u<<(24u+j)|1u<<(16u+j)|1u<<(8u+j)|1u<<j;
                        uiFault1 = 1u<<(24u+j)|1u<<(16u+j)|1u<<(8u+j)|1u<<j;
                        uiData = 0xffffffffu;
                        ret = SSMIMC_Check1bitCorrection(uiFault0, uiFault1, i, uiData, uiType);

                        for(k=0u;k<10000u;k++); //delay for FMU interrupt
                        if((ret != IMC_OK) || (gImcEccIntFlagSram0 != 1u)) {
                            if(ucErr < 0xFFu) {
                                ucErr++;
                            }
                        }
                        gImcEccIntFlagSram0 = 0u;
                    }
                }

                /******************************************* 2 bit error detection test *******************************************/
                mcu_printf("[IMC TEST] : 2bit error detection test\n");

                SSMIMC_MemFill((RAM0_BASE+RAM0_START), RAM0_SIZE, 0x00000000u);
                uiFault0 = 0x00000000u;
                uiFault1 = 0x00000000u;
                uiData = 0xFFFFFFFFu;

                for(i = RAM0_START; i < (MAX_ECC_TEST+RAM0_START); i++)
                {
                    //each byte 2bit sweeping
                    for(j=0u; j<7u; j++)
                    {
                        uiFault0 = 3u<<(24u+j)|3u<<(16u+j)|3u<<(8u+j)|3u<<j;
                        uiFault1 = 3u<<(24u+j)|3u<<(16u+j)|3u<<(8u+j)|3u<<j;
                        uiData = 0xffffffffu;
                        ret = SSMIMC_Check2bitDetection(uiFault0, uiFault1, i, uiData, uiType);

                        for(k=0u;k<10000u;k++); //delay for FMU interrupt
                        if((ret != IMC_OK) || (gImcEccIntFlagSram0 != 1u)) {
                            if(ucErr < 0xFFu) {
                                ucErr++;
                            }
                        }
                        gImcEccIntFlagSram0 = 0u;
                    }
                }

                mcu_printf("[IMC TEST] : END!! [SRAM-0], IMCTest Data Fault Injection\n");
            }
            break;

        case MEM_TYPE_SRAM1: //SRAM-1
            {
                mcu_printf("[IMC TEST] : START!! [SRAM-1], IMCTest Data Fault Injection\n");

                /******************************************* 1 bit error correction test *******************************************/
                mcu_printf("[IMC TEST] : 1bit error correction test\n");

                SSMIMC_MemFill(RAM1_BASE, RAM1_SIZE, 0x00000000u);
                uiFault0 = 0x00000000u;
                uiFault1 = 0x00000000u;
                uiData = 0xFFFFFFFFu;

                for(i = 0u; i < MAX_ECC_TEST; i++)
                {
                    //1bit sweeping
                    for(j=0u; j<32u; j++)
                    {
                        uiFault0 = 1u<<j;
                        uiFault1 = 1u<<j;
                        uiData = 0xffffffffu;
                        ret = SSMIMC_Check1bitCorrection(uiFault0, uiFault1, i, uiData, uiType);

                        for(k=0u;k<10000u;k++); //delay for FMU interrupt
                        if((ret != IMC_OK) || (gImcEccIntFlagSram1 != 1u)) {
                            if(ucErr < 0xFFu) {
                                ucErr++;
                            }
                        }
                        gImcEccIntFlagSram1 = 0u;
                    }

                    //each byte 1bit sweeping
                    for(j=0u; j<8u; j++)
                    {
                        uiFault0 = 1u<<(24u+j)|1u<<(16u+j)|1u<<(8u+j)|1u<<j;
                        uiFault1 = 1u<<(24u+j)|1u<<(16u+j)|1u<<(8u+j)|1u<<j;
                        uiData = 0xffffffffu;
                        ret = SSMIMC_Check1bitCorrection(uiFault0, uiFault1, i, uiData, uiType);

                        for(k=0u;k<10000u;k++); //delay for FMU interrupt
                        if((ret != IMC_OK) || (gImcEccIntFlagSram1 != 1u)) {
                            if(ucErr < 0xFFu) {
                                ucErr++;
                            }
                        }
                        gImcEccIntFlagSram1 = 0u;
                    }
                }

                /******************************************* 2 bit error detection test *******************************************/
                mcu_printf("[IMC TEST] : 2bit error detection test\n");

                SSMIMC_MemFill(RAM1_BASE, RAM1_SIZE, 0x00000000u);
                uiFault0 = 0x00000000u;
                uiFault1 = 0x00000000u;
                uiData = 0xFFFFFFFFu;

                for(i = 0u; i < MAX_ECC_TEST; i++)
                {
                    //each byte 2bit sweeping
                    for(j=0u; j<7u; j++)
                    {
                        uiFault0 = 3u<<(24u+j)|3u<<(16u+j)|3u<<(8u+j)|3u<<j;
                        uiFault1 = 3u<<(24u+j)|3u<<(16u+j)|3u<<(8u+j)|3u<<j;
                        uiData = 0xFFFFFFFFu;
                        ret = SSMIMC_Check2bitDetection(uiFault0, uiFault1, i, uiData, uiType);

                        for(k=0u;k<10000u;k++); //delay for FMU interrupt
                        if((ret != IMC_OK) || (gImcEccIntFlagSram1 != 1u)) {
                            if(ucErr < 0xFFu) {
                                ucErr++;
                            }
                        }
                        gImcEccIntFlagSram1 = 0u;
                    }
                }

                mcu_printf("[IMC TEST] : END!! [SRAM-1], IMCTest Data Fault Injection\n");
            }
            break;

        default:
            {
                mcu_printf("unknown memory type\n");
            }
            break;
    }

    if(ucErr != 0u) {
        ret = IMC_FAIL;
    } else {
        ret = IMC_OK;
    }

    return ret;
}

/*
***************************************************************************************************
*                                          SSMIMC_CheckDMEMAddrDetection
*
* Function to check data memory error detection
* @parameter uiFaultAddr : address for fault
* @parameter uiAddr : memory address
* @parameter uiData : data
* @parameter uiType : memory type
* @return : IMC_OK or IMC_FAIL
* Notes
*
***************************************************************************************************
*/
static uint32 SSMIMC_CheckDMEMAddrDetection(uint32 uiFaultAddr, uint32 uiAddr, uint32 uiData, IMC_MEM_TYPE uiType)
{
    uint32 rdata, raddr, status;
    uint32 ret = IMC_OK;

    switch(uiType)
    {
        case MEM_TYPE_SRAM0:
            {
                /* disable interrupt */
                ( void ) GIC_IntSrcDis( ( uint32 ) GIC_TIMER_0 + SAL_OS_TIMER_ID );
                ( void ) SAL_CoreCriticalEnter();

                (void)SSM_IMCEccPasswordWrite();
                *(vuint *)(RAM0_BASE+(uiAddr*4u)) = uiData;                                 //write to sram0
                SAL_WriteReg(uiFaultAddr, SSM_ECC_SRAM0_DMEM_ADDR_INV);                 //fault address injection
                raddr = ((RAM0_BASE+(uiAddr*4u))^SAL_ReadReg(SSM_ECC_SRAM0_DMEM_ADDR_INV)); //read from sram0
                rdata = *(vuint *)(raddr);                                              //read from sram0

                if(uiData != rdata) {
                    ret = IMC_FAIL;
                }

                status = SAL_ReadReg(SSM_ECC_SRAM0_ERR_STS);                            //read sram0 fault status
                mcu_printf("[IMC TEST] : [SRAM-0] MASK : 0x%08x, STATUS : 0x%08x, WDATA : 0x%08x, RDATA : 0x%08x, WADDR : 0x%08x, RADDR : 0x%08x\n", SAL_ReadReg(SSM_ECC_SRAM0_DMEM_ADDR_INV), status, uiData, rdata, RAM0_BASE+(uiAddr*4u), raddr);
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0x00000000, SSM_ECC_SRAM0_DMEM_ADDR_INV);                  //fault injection clear
                *(vuint *)(RAM0_BASE+(uiAddr*4u)) = uiData;                                 //temporary write to sram0
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0xffffffff, SSM_ECC_SRAM0_ERR_STS);                        //fault status clear
                SAL_CoreCriticalExit();
            }
            break;

        case MEM_TYPE_SRAM1:
            {
                (void)SSM_IMCEccPasswordWrite();
                *(vuint *)(RAM1_BASE+(uiAddr*4u)) = uiData;                                 //write to  sram1
                SAL_WriteReg(uiFaultAddr, SSM_ECC_SRAM1_DMEM_ADDR_INV);                 //fault address injection
                raddr = ((RAM1_BASE+(uiAddr*4u))^SAL_ReadReg(SSM_ECC_SRAM1_DMEM_ADDR_INV)); //read from sram1
                rdata = *(vuint *)(raddr);                                              //read from sram1

                if(uiData != rdata) {
                    ret = IMC_FAIL;
                }

                status = SAL_ReadReg(SSM_ECC_SRAM1_ERR_STS);                            //read sram1 fault status
                mcu_printf("[IMC TEST] : [SRAM-1] MASK : 0x%08x, STATUS : 0x%08x, WDATA : 0x%08x, RDATA : 0x%08x, WADDR : 0x%08x, RADDR : 0x%08x\n", SAL_ReadReg(SSM_ECC_SRAM1_DMEM_ADDR_INV), status, uiData, rdata, RAM1_BASE+(uiAddr*4u), raddr);
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0x00000000, SSM_ECC_SRAM1_DMEM_ADDR_INV);                  //fault injection clear
                *(vuint *)(RAM1_BASE+(uiAddr*4u)) = uiData;                                 //temporary write to sram1
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0xffffffff, SSM_ECC_SRAM1_ERR_STS);                        //fault injection clear
            }
            break;

        default:
            {
                mcu_printf("unknown memory type\n");
            }
            break;
    }

    return ret;
}

/*
***************************************************************************************************
*                                          SSMIMC_CheckEMEMAddrDetection
*
* Function to check ecc memory error detection
* @parameter uiFaultAddr : address for fault
* @parameter iAddr : memory address
* @parameter uiData : data
* @parameter uiType : memory type
* @return : IMC_OK or IMC_FAIL
* Notes
*
***************************************************************************************************
*/
static uint32 SSMIMC_CheckEMEMAddrDetection(uint32 uiFaultAddr, uint32 uiAddr, uint32 uiData, IMC_MEM_TYPE uiType)
{
    uint32 rdata, raddr, status;
    uint32 ret = IMC_OK;

    switch(uiType)
    {
        case MEM_TYPE_SRAM0:
            {
                /* disable interrupt */
                ( void ) GIC_IntSrcDis( ( uint32 ) GIC_TIMER_0 + SAL_OS_TIMER_ID );
                ( void ) SAL_CoreCriticalEnter();

                (void)SSM_IMCEccPasswordWrite();
                *(vuint *)(RAM0_BASE+(uiAddr*4u)) = uiData;                                 //write to sram1
                SAL_WriteReg(uiFaultAddr, SSM_ECC_SRAM0_EMEM_ADDR_INV);                 //fault address injection
                raddr = ((RAM0_BASE+(uiAddr*4u))^SAL_ReadReg(SSM_ECC_SRAM0_EMEM_ADDR_INV)); //read from sram0
                rdata = *(vuint *)(raddr);                                              //read from sram0

                status = SAL_ReadReg(SSM_ECC_SRAM0_ERR_STS);                            //read sram0 fault status
                mcu_printf("[IMC TEST] : [SRAM-0] MASK : 0x%08x, STATUS : 0x%08x, WDATA : 0x%08x, RDATA : 0x%08x, WADDR : 0x%08x, RADDR : 0x%08x\n", SAL_ReadReg(SSM_ECC_SRAM0_EMEM_ADDR_INV), status, uiData, rdata, RAM0_BASE+(uiAddr*4u), raddr);
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0x00000000, SSM_ECC_SRAM0_EMEM_ADDR_INV);                  //fault injection clear
                *(vuint *)(RAM0_BASE+(uiAddr*4u)) = uiData;                                 //temporary write to  sram0
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0xffffffff, SSM_ECC_SRAM0_ERR_STS);                        //fault status clear
                SAL_CoreCriticalExit();
            }
            break;

        case MEM_TYPE_SRAM1:
            {
                (void)SSM_IMCEccPasswordWrite();
                *(vuint *)(RAM1_BASE+(uiAddr*4u)) = uiData;                                 //write to sram1
                SAL_WriteReg(uiFaultAddr, SSM_ECC_SRAM1_EMEM_ADDR_INV);                 //fault address injection
                raddr = ((RAM1_BASE+(uiAddr*4u))^SAL_ReadReg(SSM_ECC_SRAM1_EMEM_ADDR_INV)); //read from sram1
                rdata = *(vuint *)(raddr);                                              //read from sram1

                status = SAL_ReadReg(SSM_ECC_SRAM1_ERR_STS);                            //read sram1 fault status
                mcu_printf("[IMC TEST] : [SRAM-1] MASK : 0x%08x, STATUS : 0x%08x, WDATA : 0x%08x, RDATA : 0x%08x, WADDR : 0x%08x, RADDR : 0x%08x\n", SAL_ReadReg(SSM_ECC_SRAM1_EMEM_ADDR_INV), status, uiData, rdata, RAM0_BASE+(uiAddr*4u), raddr);
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0x00000000, SSM_ECC_SRAM1_EMEM_ADDR_INV);                  //fault injection clear
                *(vuint *)(RAM1_BASE+(uiAddr*4u)) = uiData;                                 //temporary write to sram1
                (void)SSM_IMCEccPasswordWrite();
                SAL_WriteReg(0xffffffff, SSM_ECC_SRAM1_ERR_STS);                        //fault status clear
            }
            break;

        default:
            {
                mcu_printf("unknown memory type\n");
            }
            break;
    }

    return ret;
}

/*
***************************************************************************************************
*                                          SSMIMC_AddrFaultInjection
*
* Function to check address fault
* @parameter uiType : memory type
* @return : IMC_OK or IMC_FAIL
* Notes
*
***************************************************************************************************
*/
static uint32 SSMIMC_AddrFaultInjection(IMC_MEM_TYPE uiType)
{
    uint8 ucErr = 0u;
    uint32 i, j, k;
    uint32 uiData;
    uint32 uiFaultAddr;
    uint32 ret = IMC_FAIL;

    switch(uiType)
    {
        case MEM_TYPE_SRAM0: //SRAM-0
            {
                /* VECTOR_SIZE = 0x60, DMA_SZIE = 0x2000, ARM_STACK = 0x680 */
                mcu_printf("[IMC TEST] : START!! [SRAM-0], IMCTest Address Address Fault Injection\n");

                /******************************************* Data memory error detection test *******************************************/
                mcu_printf("[IMC TEST] : DATA memory error detection test\n");

                SSMIMC_MemFill((RAM0_BASE+RAM0_START), RAM0_SIZE, 0x00000000u);
                uiFaultAddr = 0x00000000u;
                uiData = 0xFFFFFFFFu;

                //Data memory invert
                for(i = RAM0_START; i < (RAM0_START+1u); i++)
                {
                    //1bit sweeping
                    for(j=0u; j<13u; j++)
                    {
                        uiFaultAddr = 8u<<j;
                        uiData = 0xffffffffu;
                        ret = SSMIMC_CheckDMEMAddrDetection(uiFaultAddr, i, uiData, uiType);

                        for(k=0u;k<100000u;k++); //delay for FMU interrupt
                        if((ret != IMC_OK) || (gImcEccIntFlagSram0 != 1u)) {
                            if(ucErr < 0xFFu) {
                                ucErr++;
                            }
                        }
                        gImcEccIntFlagSram0 = 0u;
                    }
                }

                /******************************************* ECC memory error detection test *******************************************/
                mcu_printf("[IMC TEST] : ECC memory error detection test\n");

                //ECC memory invert
                for(i = RAM0_START; i < (RAM0_START+1u); i++)
                {
                    uiFaultAddr = 0xffffffffu;
                    uiData = 0xffffffffu;
                    ret = SSMIMC_CheckEMEMAddrDetection(uiFaultAddr, i, uiData, uiType);

                    for(k=0u;k<100000u;k++); //delay for FMU interrupt
                    if((ret != IMC_OK) || (gImcEccIntFlagSram0 != 1u)) {
                        if(ucErr < 0xFFu) {
                            ucErr++;
                        }
                    }
                    gImcEccIntFlagSram0 = 0u;
                }

                mcu_printf("[IMC TEST] : END!! [SRAM-0], IMCTest Address Address Fault Injection\n");
            }
            break;

        case MEM_TYPE_SRAM1: //SRAM-1
            {
                /* VECTOR_SIZE = 0x60, DMA_SZIE = 0x2000, ARM_STACK = 0x680 */
                mcu_printf("[IMC TEST] : START!! [SRAM-1], IMCTest Address Address Fault Injection\n");

                /******************************************* Data memory error detection test *******************************************/
                mcu_printf("[IMC TEST] : DATA memory error detection test\n");

                SSMIMC_MemFill(RAM1_BASE, RAM1_SIZE, 0x00000000u);
                uiFaultAddr = 0x00000000u;
                uiData = 0xFFFFFFFFu;

                //Data memory invert
                for(i = 0u; i < 1u; i++)
                {
                    //1bit sweeping
                    for(j=0u; j<13u; j++)
                    {
                        uiFaultAddr = 8u<<j;
                        uiData = 0xffffffffu;
                        ret = SSMIMC_CheckDMEMAddrDetection(uiFaultAddr, i, uiData, uiType);

                        for(k=0u;k<100000u;k++); //delay for FMU interrupt
                        if((ret != IMC_OK) || (gImcEccIntFlagSram1 != 1u)) {
                            if(ucErr < 0xFFu) {
                                ucErr++;
                            }
                        }
                        gImcEccIntFlagSram1 = 0u;
                    }
                }

                /******************************************* ECC memory error detection test *******************************************/
                mcu_printf("[IMC TEST] : ECC memory error detection test\n");

                //ECC memory invert
                for(i = 0u; i < 1u; i++)
                {
                    uiFaultAddr = 0xffffffffu;
                    uiData = 0xffffffffu;
                    ret = SSMIMC_CheckEMEMAddrDetection(uiFaultAddr, i, uiData, uiType);

                    for(k=0u;k<100000u;k++); //delay for FMU interrupt
                    if((ret != IMC_OK) || (gImcEccIntFlagSram1 != 1u)) {
                        if(ucErr < 0xFFu) {
                            ucErr++;
                        }
                    }
                    gImcEccIntFlagSram1 = 0u;
                }

                mcu_printf("[IMC TEST] : END!! [SRAM-1], IMCTest Address Address Fault Injection\n");
            }
            break;

        default:
            {
                mcu_printf("unknown memory type\n");
            }
            break;
        }

    if(ucErr != 0u) {
        ret = IMC_FAIL;
    } else {
	    ret = IMC_OK;
    }

    return ret;
}


void SSMIMC_EccErrorCallback(IMCTypeID_t uiType, uint32 uiStatus)
{
    if(uiType == IMC_SRAM0) {
        gImcEccIntFlagSram0 = 1u;
        gImcEccIntStatusSram0 = uiStatus;
        (void)FMU_IsrClr(FMU_ID_SRAM0_ECC);
    } else if(uiType == IMC_SRAM1) {
        gImcEccIntFlagSram1 = 1u;
        gImcEccIntStatusSram1 = uiStatus;
        (void)FMU_IsrClr(FMU_ID_SRAM1_ECC);
    } else {
        mcu_printf("unknown memory type\n");
    }
}

void SSMIMC_TestMain(int32 iTestNum)
{
    uint32 ret = 0u;

    /* SM and FMU enable to handle ECC error */
    (void)SSM_IMCEccEnable();

    /* Set FMU & IMC driver call back for SRAM1 */
#if 0
    (void)FMU_IsrHandler(FMU_ID_SRAM1_ECC, FMU_SVL_LOW, &SSM_IMCEccFmuHandlerForSram1, NULL_PTR);
    (void)FMU_Set(FMU_ID_SRAM1_ECC);
#endif
    /* Set test application call back */
    (void)SSM_IMCEccRegisterFaultHandler(1, SSMIMC_EccErrorCallback);

    switch(iTestNum)
    {
        case 1: //SRAM-1 soft data fault injection test
            ret = SSMIMC_DataFaultInjection(MEM_TYPE_SRAM1);
            if(ret == IMC_OK) {
                mcu_printf("[IMC TEST] : SRAM-1 soft fault injection test - SUCCESS!\n");
            } else {
                mcu_printf("[IMC TEST] : SRAM-1 soft fault injection test - FAIL!\n");
            }
            break;

        case 2: //SRAM-1 soft address fault injection test
            ret = SSMIMC_AddrFaultInjection(MEM_TYPE_SRAM1);
            if(ret == IMC_OK) {
                mcu_printf("[IMC TEST] : SRAM-1 soft address fault injection test - SUCCESS!\n");
            } else {
                mcu_printf("[IMC TEST] : SRAM-1 soft address fault injection test - FAIL!\n");
            }
            break;

        default:
            {
                mcu_printf("unsupported test case\n");
            }
            break;
    }
}

