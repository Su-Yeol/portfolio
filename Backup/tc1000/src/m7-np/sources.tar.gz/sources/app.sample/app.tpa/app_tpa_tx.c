/*
***************************************************************************************************
*
*   FileName : app_tpa_tx.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/**************************************************************************************************
*                                           INCLUDE FILES
**************************************************************************************************/

#include "app_cfg.h"
#include "app_tpa_tx.h"
#include "bsp.h"
#include "debug.h"
#include <stdlib.h>
#include "tpa_drv.h"
#include "demo_tsnc.h"

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/


/**************************************************************************************************
*                                          LOCAL VARIABLES
**************************************************************************************************/
#ifndef TPA_EN
static uint8 TPA_Tx_Task_cnt;
#endif

#if 0
/* ARP Request from 192.168.1.20 to 192.168.1.10 */
static uint8 packet_data[] =
{
0xff,0xff,0xff,0xff,0xff,0xff,0x00,0x01,0x02,0x03,0x04,0x05,0x08,0x06,0x00,0x01,
0x08,0x00,0x06,0x04,0x00,0x01,0x00,0x01,0x02,0x03,0x04,0x05,0xc0,0xa8,0x01,0x14,
0x00,0x00,0x00,0x00,0x00,0x00,0xc0,0xa8,0x01,0x0a
};
#else
/* ARP Request from 192.168.1.5(00:01:02:03:04:10) to 192.168.1.10 */
static uint8 packet_data[] =
{
0xff,0xff,0xff,0xff,0xff,0xff,0x00,0x01,0x02,0x03,0x04,0x10,0x08,0x06,0x00,0x01,
0x08,0x00,0x06,0x04,0x00,0x01,0x00,0x01,0x02,0x03,0x04,0x10,0xc0,0xa8,0x01,0x05,
0x00,0x00,0x00,0x00,0x00,0x00,0xc0,0xa8,0x01,0x0a
};
#endif

static uint16 packet_size = sizeof(packet_data);



/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/
static void TpaTx_Uart_list(void);
static void TPA_TX_Task(void *pArg);

/**************************************************************************************************
*                                             FUNCTIONS
**************************************************************************************************/
//void TPA_TX_Init(void)
//{

//}


void TpaTx_Uart_list(void)
{
	mcu_printf( "=== wrong argument ===\n" );
    mcu_printf( "=== USAGE INFO ===\n\n" );
    mcu_printf( "=== CMD LIST ===\n" );
    mcu_printf( "tpatx send\n" );
    mcu_printf( "tpatx dump\n" );
}

void TPA_TX_UART(uint8 ucArgc, void* const pArgv[])
{
    const uint8 *   pucStr1;
    sint32          ret;

    pucStr1         = NULL_PTR;


    if( pArgv != NULL_PTR )
    {
		pucStr1 = ( const uint8 * ) pArgv[ 0 ];


		if( ucArgc == 1UL )
		{
			if( pucStr1 != NULL_PTR )
			{
				if( ( SAL_StrNCmp( pucStr1, ( const uint8 * ) "send", 4, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
  					mcu_printf("tpa tx");
  					tpa_write(packet_data,packet_size);
                }
                else if( ( SAL_StrNCmp( pucStr1, ( const uint8 * ) "dump", 4, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
  					mcu_printf("tpa register dump");
					tpa_reg_dump();
                }

			}
		}
		else
	    {
			TpaTx_Uart_list();
	    }
    }


}


void TPA_TX_CreateAppTasks(void)
{
    static uint32 uiTPA_TxTaskID;
    static uint32 uiTPA_TxTaskStk[TPA_TX_TASK_STK_SIZE];
#ifdef TPA_EN
    static uint8 ucTPA_TxMsgBuffer[TPA_TX_MSG_QUEUE_NUM * sizeof(TPA_TX_MESSAGE)];
	if(SAL_QueueCreate( &gTpaTxQueueHandle,
						( const uint8 * ) "TpaTxQ",
						( void * )ucTPA_TxMsgBuffer,
						TPA_TX_MSG_QUEUE_NUM,
						sizeof(TPA_TX_MESSAGE)) != SAL_RET_SUCCESS)
						{
							mcu_printf("%s Fatal!! TX Queue Create Fail. \n", __func__);
						}
#endif

    if(SAL_TaskCreate( &uiTPA_TxTaskID,
                   ( const uint8 * ) "TPA TX Task",
                   ( SALTaskFunc ) TPA_TX_Task,
                   ( uint32 * const ) &uiTPA_TxTaskStk[0],
                   TPA_TX_TASK_STK_SIZE,
                   SAL_PRIO_TPA_TX,
                   NULL_PTR) != SAL_RET_SUCCESS)
                   {
				   		mcu_printf("%s Fatal!! Task Create Fail. \n", __func__);
                   }
}

static void TPA_TX_Task(void *pArg)
{
	( void ) pArg;

	uint8 task_exit = 0u;

#ifdef TPA_EN
	TPA_TX_MESSAGE msg;
	uint32 copiedSize = 0U;
#endif

    while( task_exit == 0U)
    {

#ifdef TPA_EN

		if (SAL_QueueGet(gTpaTxQueueHandle, (void *)&msg, &copiedSize, portMAX_DELAY, SAL_OPT_BLOCKING) != SAL_RET_SUCCESS)
		{
			mcu_printf("[%s] Fatal!! Get TX Queue Fail. \n", __func__);
		}

		switch(msg.MsgID)
		{
			case TX_TPA_TSNC_SEND:
				{
					tpa_write((uint8*)&msg.MsgData[0], sizeof(EthFrame_t));
				}
				break;

			case TX_TPA_CMD_EXIT:
				task_exit = 1U;
				break;
		}
#else
		if(TPA_Tx_Task_cnt < 255)
		{
			TPA_Tx_Task_cnt ++;
		}
		else
		{
			TPA_Tx_Task_cnt = 0;
		}

		( void ) SAL_TaskSleep( 1000 );
#endif
    }

#ifdef TPA_EN
    (void)SAL_QueueDelete(gTpaTxQueueHandle);
#endif
}

