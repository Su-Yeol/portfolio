/*
***************************************************************************************************
*
*   FileName : app_tpa_rx.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/**************************************************************************************************
*                                           INCLUDE FILES
**************************************************************************************************/

#include "app_cfg.h"
#include "app_tpa_rx.h"
#include "bsp.h"
#include "debug.h"
#include "tpa_drv.h"

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/
#define OFFSET_ETHER_TYPE (0xc)
#define ETHER_TYPE_ARP (0x0806)

/**************************************************************************************************
*                                          LOCAL VARIABLES
**************************************************************************************************/
#ifdef TPA_EN
uint8 readBuffer[TPA_ETH_BUFFER_SIZE];
#else
static uint8 TPA_Rx_Task_cnt;
#endif
static uint8 TPA_RX_Enable = FALSE;



/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/
static void TPA_RX_Task(void *pArg);
static void TpaRx_Uart_list(void);
static uint16 get_ether_type(uint8* ptr);

static EthtoCANCallback fEthtoCANCB = NULL;

/**************************************************************************************************
*                                             FUNCTIONS
**************************************************************************************************/
void frm_tsnc_setEthtoCANCB(EthtoCANCallback cbFunc)
{
    fEthtoCANCB = cbFunc;
}

//void TPA_RX_Init(void)
//{

//}

void TpaRx_Uart_list(void)
{
	mcu_printf( "=== wrong argument ===\n" );
    mcu_printf( "=== USAGE INFO ===\n\n" );
    mcu_printf( "=== CMD LIST ===\n" );
    mcu_printf( "tparx (x) : 'x' = Disable, 'o' = Enable \n" );
}

void TPA_RX_UART(uint8 ucArgc, void* const pArgv[])
{
    const uint8 *   pucStr1;

    sint32          ret;

    pucStr1         = NULL_PTR;

    if( pArgv != NULL_PTR )
    {
		pucStr1 = ( const uint8 * ) pArgv[ 0 ];

		if( ucArgc == 1UL )
		{
			if( pucStr1 != NULL_PTR )
			{
				if( ( SAL_StrNCmp( pucStr1, ( const uint8 * ) "o", 1, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
					TPA_RX_Enable = TRUE;
                }
                else if( ( SAL_StrNCmp( pucStr1, ( const uint8 * ) "x", 1, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
					TPA_RX_Enable = FALSE;
                }
                else
                {
					mcu_printf("wrong argument only 'o' or 'x'");
                }
			}
		}
		else
	    {
			TpaRx_Uart_list();
	    }
    }


}

static uint16 get_ether_type(uint8* ptr)
{
	uint8* ptr_ether_type;
	uint16 ethertype;

	ptr_ether_type = ptr+OFFSET_ETHER_TYPE;

	ethertype = (*ptr_ether_type)<<8;
	ptr_ether_type++;
	ethertype |= *ptr_ether_type;

	return ethertype;
}


void TPA_RX_CreateAppTasks(void)
{
    static uint32 uiTPA_RxTaskID;
    static uint32 uiTPA_RxTaskStk[TPA_RX_TASK_STK_SIZE];

    if(SAL_TaskCreate( &uiTPA_RxTaskID,
                   ( const uint8 * ) "TPATask",
                   ( SALTaskFunc ) &TPA_RX_Task,
                   ( uint32 * const ) &uiTPA_RxTaskStk[0],
                   TPA_RX_TASK_STK_SIZE,
                   SAL_PRIO_TPA_RX,
                   NULL_PTR) != SAL_RET_SUCCESS)
                   {
				   		mcu_printf("%s Fatal!! Task Create Fail. \n", __func__);
                   }

}

static void TPA_RX_Task(void *pArg)
{
	( void ) pArg;

#ifdef TPA_EN
	eTPA_RET_t tpaRet;
	uint16 readSize;
    TSNC_ETH_DATA eth_data;

	tpaRet = tpa_init();
	tpaRet = tpa_open(xTaskGetCurrentTaskHandle());

    while( 1 )
    {
    	//mcu_printf("wait signal\n");

    	ulTaskNotifyTake( pdTRUE, portMAX_DELAY );

		tpaRet = eTPA_RET_OK;

		while(tpaRet == eTPA_RET_OK)
		{
			readSize = 0;
			tpaRet = tpa_read(&readBuffer[0], TPA_ETH_BUFFER_SIZE, &readSize);
			if(tpaRet == eTPA_RET_OK)
			{
				if(readSize>0)
				{
                    /* for TSNC latency */
                    //SAL_GetTickCount(&tick_tpa_rx);

					mcu_printf("read %dbytes\n", readSize);

					#if 0
					{
						uint16 ethertype;

						ethertype = get_ether_type(&readBuffer[0]);
						if(ethertype == 0x0806)
						{
							TPATEST_DEBUG("ARP received\n");

							tpa_write(packet_data,packet_size);
							//tpaRet = tpa_write(&readBuffer[0], readSize);
						}
					}
					#endif

                    SAL_MemCopy(eth_data.msg_data, readBuffer, sizeof(readBuffer));

                    if ( fEthtoCANCB != NULL)
                    {
                        fEthtoCANCB(&eth_data);
                    }
				}
			}
		}

    }
#else
    while( 1 )
    {
    	if(TPA_Rx_Task_cnt < 255)
    	{
			TPA_Rx_Task_cnt ++;
		}
		else
		{
			TPA_Rx_Task_cnt = 0;
		}

		( void ) SAL_TaskSleep( 1000 );
    }
#endif
}

