/*
***************************************************************************************************
*
*   FileName : app_tpa_tx.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef _APP_TPA_TX_H_
#define _APP_TPA_TX_H_

#include "sal_com.h"
#include "mst_framework.h"

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/
#define TX_TPA_TSNC_SEND					(1U)

/*********** TPA TX message queue ***********/
#define	TPA_TX_MSG_BUFFER_SIZE		(LPA_TX_MAX_FRAME_SIZE)
#define	TPA_TX_MSG_QUEUE_NUM		(64)

/*********** TPA TX message command ***********/
#define TX_TPA_CMD_EXIT						(100U)

#define TPA_TX_TASK_STK_SIZE          (1024)

typedef struct TPA_TX_MESSAGE {
	uint16 MsgID;
	uint8 MsgData[TPA_ETH_BUFFER_SIZE];
}TPA_TX_MESSAGE;

/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/
extern void TPA_TX_CreateAppTasks(void);
extern void TPA_TX_UART(uint8 ucArgc, void* const pArgv[]);
//extern void TPA_TX_Init(void);

#endif /* _APP_TPA_TX_H_ */

