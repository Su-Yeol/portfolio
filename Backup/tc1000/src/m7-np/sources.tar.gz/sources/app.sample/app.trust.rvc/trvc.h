/*
***************************************************************************************************
*
*   FileName : trvc.h
*
*   Copyright (c) Telechips Inc.
*
*   Description : T-RVC Main Application Header
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef TRVCAPP_H
#define TRVCAPP_H

#ifdef SIC_BSP_SUPPORT_DRIVER_FMU
#include <fmu.h>
#endif

/*
*********************************************************************************************************
*                                                 EXTERNS
*********************************************************************************************************
*/
extern void TRVC_CreateAppTasks
(
    void
);

extern boolean bTrvcBigLock;

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/
/**
 * @brief Sleep time for each task in Trusted RVC
 *
 * Event queue handler MUST BE scheduled even more often than other tasks. If not, event queue will
 * be full since other tasks will enqueue items. By default, event handler will be scheduled more
 * frequently in 5 times (since less than 5 items would be inserted into the event queue by
 * detectors). If you add some more detectors, you must take into account the number of queue item
 * to be inserted into event queue at once.
 *
 */
#define TRVC_TASK_EVENT_HANDLER_DELAY   (TRVC_TASK_SCHED_DELAY / 5U)
#define TRVC_TASK_SCHED_DELAY           (50U)
#define TRVC_APP_TASK_PRIO              (3U)
#define TRVC_APP_TASK_STK_SIZE          (256U)

/*
 * Print error message when trying to write register in locked state
 */
#define TRVC_DBG_CHECK_GPSB_LOCK        (FALSE)
#define TRVC_DEFINE_TASK(task_name, task_func, task_delay)              \
    static void task_name(void *pvArg);                                 \
    static void task_name(void *pvArg)                                  \
    {                                                                   \
        void (*func[])(void) = {                                        \
            task_func,                                                  \
            nopTask                                                     \
        };                                                              \
        (void)pvArg;                                                    \
        while (TRUE) {                                                  \
            func[bTrvcBigLock]();                                       \
            SAL_TaskSleep(task_delay);                                  \
        }                                                               \
    }



#endif
