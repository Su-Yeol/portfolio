/*
***************************************************************************************************
*
*   FileName : trvc.c
*
*   Copyright (c) Telechips Inc.
*
*   Description : A main code of Trust RVC
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include <stdlib.h>
#include <gpio.h>
#include <debug.h>
#include <sal_com.h>
#include <console.h>
#include <trvc.h>
#include <trvc_drv.h>
#include <trvc_safe_camera.h>
#include <trvc_receiver.h>
#include <trvc_mailbox.h>
#include <trvc_error_detect.h>
#include <trvc_event_handler.h>
#include <trvc_gpsb.h>
#include <trvc_sender.h>
#include <trvc_checker.h>
#include <trvc_shared.h>

#undef TRVC_DEBUG_NO_TASKS

/**
 * @bTrvcBigLock - Lock all tasks of TRVC
 *
 * This is a simple flag to lock all tasks of T-RVC for debugging. Sometimes, attaching debuggers
 * such as Trace32 results in handover from DDIBUS to SCI.
 */
boolean bTrvcBigLock = FALSE;

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/

/*
***************************************************************************************************
*                                             LOCAL VARIABLES
***************************************************************************************************
*/
static struct TRVCShared                sSharedObj;

/*
***************************************************************************************************
*                                            STATIC FUNCTIONS
***************************************************************************************************
*/

static void nopTask(void)
{
}

static void mailboxTask(void)
{
    (void)sender.psOps->perform(&sender);
    (void)receiver.psOps->perform(&receiver);
}
/* coverity[misra_c_2012_rule_8_13_violation : FALSE] */
/* coverity[misra_c_2012_rule_10_1_violation : FALSE] */
TRVC_DEFINE_TASK(TrvcMailboxTask, mailboxTask, TRVC_TASK_SCHED_DELAY);

/**
 * @brief Isr task handles errors from CIED and DDI Checker, SCI Checker, Timing manager. All errors
 * related to trust rvc are dealt with following task.
 *
 * Notes There are three levels in FMU interrupt. Errors of high & mid levels cannot be handled due
 * to the interrupt handler in mcu, which would block every operations from firmware code.
 */
static void detectorTask(void)
{
    TRVC_DetectErrors(&sSharedObj);
}
/* coverity[misra_c_2012_rule_8_13_violation : FALSE] */
/* coverity[misra_c_2012_rule_10_1_violation : FALSE] */
TRVC_DEFINE_TASK(TrvcDetectorTask, detectorTask, TRVC_TASK_SCHED_DELAY);

/**
 * @brief Since the limitation of SCI Checker and FMU, we need to set-up a new task as a thread to
 * check whether video input is normally inputted as safe camera interface.
 *
 * SCI Checker checks only sync & clock of the signals after framebuffer of Safe Camera Interface.
 * It means that SCIC cannot provide any measure to check video signal except for checking a serious
 * of VIN_MON* registers. Following task is a simple task running as a thread to check the video
 * signal.
 */
static void vinCheckerTask(void)
{
    TRVC_CheckVinIsRunning(&sSharedObj);
}
/* coverity[misra_c_2012_rule_8_13_violation : FALSE] */
/* coverity[misra_c_2012_rule_10_1_violation : FALSE] */
TRVC_DEFINE_TASK(TrvcVinCheckerTask, vinCheckerTask, TRVC_TASK_SCHED_DELAY);

static void evHandlerTask(void)
{
    TRVC_RunEventQueueHandler(&sSharedObj);
    TRVC_CheckFailCounter(&sSharedObj);	  /* check fail-counter and initialize SCI */
    TRVC_CheckIgnoreCounter(&sSharedObj); /* event delay */
}
/* coverity[misra_c_2012_rule_8_13_violation : FALSE] */
/* coverity[misra_c_2012_rule_10_1_violation : FALSE] */
TRVC_DEFINE_TASK(TrvcEvHandlerTask, evHandlerTask, TRVC_TASK_EVENT_HANDLER_DELAY);

/**
 * Create tasks of Trusted RVC
 *
 * @TrvcDetectorTask      Task to detect events
 * @TrvcMailboxTask       Task to handle Mailbox IPC
 * @EvHandlerTask         Task to handle events
 * @TrvcVinCheckerTask    Task to monitor the video signal
 */
void TRVC_CreateAppTasks
(
    void
)
{
#ifndef TRVC_DEBUG_NO_TASKS
    static uint32 TrvcAppTaskID;
    static uint32 TrvcDetectorTaskStk[TRVC_APP_TASK_STK_SIZE];
    static uint32 TrvcVinCheckerTaskStk[TRVC_APP_TASK_STK_SIZE];
    static uint32 TrvcMailboxTaskStk[TRVC_APP_TASK_STK_SIZE];
    static uint32 TrvcEvHandlerStk[TRVC_APP_TASK_STK_SIZE];

    (void)TRVC_Initialize();

    (void)receiver.psOps->open(&receiver);
    sender.sParent.psDevice = receiver.sParent.psDevice;

    receiver.psShared = &sSharedObj;
    sender.psShared = &sSharedObj;

    /* coverity[misra_c_2012_rule_11_5_violation : FALSE] */
    (void)SAL_TaskCreate(&TrvcAppTaskID, (const uint8 *)"TrvcMailboxTask",
                         (SALTaskFunc)&TrvcMailboxTask,
                         (void * const)&TrvcMailboxTaskStk[0],
                         TRVC_APP_TASK_STK_SIZE, TRVC_APP_TASK_PRIO, NULL);

    /* coverity[misra_c_2012_rule_11_5_violation : FALSE] */
    (void)SAL_TaskCreate(&TrvcAppTaskID, (const uint8 *)"TrvcErrorDetector",
                         (SALTaskFunc)&TrvcDetectorTask,
                         (void * const)&TrvcDetectorTaskStk[0],
                         TRVC_APP_TASK_STK_SIZE, TRVC_APP_TASK_PRIO, NULL);

    /* coverity[misra_c_2012_rule_11_5_violation : FALSE] */
    (void)SAL_TaskCreate(&TrvcAppTaskID, (const uint8 *)"TrvcVinCheckerTask",
                         (SALTaskFunc)&TrvcVinCheckerTask,
                         (void * const)&TrvcVinCheckerTaskStk[0],
                         TRVC_APP_TASK_STK_SIZE, TRVC_APP_TASK_PRIO, NULL);

    /* coverity[misra_c_2012_rule_11_5_violation : FALSE] */
    (void)SAL_TaskCreate(&TrvcAppTaskID, (const uint8 *)"TrvcEvHandlerTask",
                         (SALTaskFunc)&TrvcEvHandlerTask,
                         (void * const)&TrvcEvHandlerStk[0],
                         TRVC_APP_TASK_STK_SIZE, TRVC_APP_TASK_PRIO, NULL);

#else
    TRVC_Initialize();
    TRVC_PostInitialize();
#endif /* TRVC_DEBUG_NO_TASKS */
}
