/*
***************************************************************************************************
*
*   FileName : trvc_test.c
*
*   Copyright (c) Telechips Inc.
*
*   Description : A console interface for Trust RVC
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include <app_cfg.h>

#if (ACFG_APP_TRVC_EN == 1)
#include <sal_com.h>
#include <errno.h>
#include <stdlib.h>
#include <gpio.h>
#include <console.h>
#include <reg_phys.h>
#include <trvc.h>
#include <trvc_gpsb.h>
#include <trvc_safe_camera.h>
#include <trvc_checker.h>
#include <trvc_video_mux.h>
#include <trvc_diagnostic.h>
#include <trvc_test.h>
#include <debug.h>
#include <uart.h>
/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/

/*
***************************************************************************************************
*                                             LOCAL VARIABLES
***************************************************************************************************
*/

/*
 * A list of commands used in Trust RVC Console interface
 */

#define TRVC_SPI_IF_HELP                (0U)
#define TRVC_SPI_IF_SPI_READ            (1U)
#define TRVC_SPI_IF_SPI_WRITE           (2U)
#define TRVC_SPI_IF_READ_REG            (3U)
#define TRVC_SPI_IF_WRITE_REG           (4U)
#define TRVC_SPI_IF_MEM_DUMP            (5U)
#define TRVC_SPI_IF_DIAGNOSTIC          (6U)
#define TRVC_SPI_IF_BIGLOCK             (7U)
#define TRVC_SPI_IF_SCI                 (8U)
#define TRVC_SPI_IF_CHECKER             (9U)
#define TRVC_SPI_IF_MAX                 (10U)

#define TRVC_GPSB_DELAY_IN_CMD          (100U)

/* coverity[misra_c_2012_rule_5_9_violation : FALSE] */
static void delay
(
    uint32 usec
)
{
    uint32 i, cnt;
    cnt = usec * 500U;
    for (i = 0; i < cnt; i++) {
        BSP_NOP_DELAY();
    }
}

static const uint8 __attribute__((unused)) * args[TRVC_SPI_IF_MAX] = {
    (const uint8 *)"help",  // [TRVC_SPI_IF_HELP]
    (const uint8 *)"r",     // [TRVC_SPI_IF_SPI_READ]
    (const uint8 *)"w",     // [TRVC_SPI_IF_SPI_WRITE]
    (const uint8 *)"R",     // [TRVC_SPI_IF_READ_REG]
    (const uint8 *)"W",     // [TRVC_SPI_IF_WRITE_REG]
    (const uint8 *)"m",     // [TRVC_SPI_IF_MEM_DUMP]
    (const uint8 *)"d",     // [TRVC_SPI_IF_DIAGNOSTIC]
    (const uint8 *)"t",     // [TRVC_SPI_IF_BIGLOCK]
    (const uint8 *)"i",     // [TRVC_SPI_IF_SCI]
    (const uint8 *)"c",     // [TRVC_SPI_IF_SCI]
};

/* coverity[HIS_metric_violation : FALSE] */
static void handlerForReadingSpi
(
    void * const                        argv[]
)
{
    uint32 __attribute__((unused)) uiAddr;
    uint32 __attribute__((unused)) uiRead;

    if (argv == NULL) {
        LOGE(DBG_TAG_TRVC, "Uninitialized argument\n");
    } else {
        errno = 0;
        /* coverity[misra_c_2012_rule_11_5_violation : FALSE] */
        uiAddr = (uint32)strtoul((char const *)argv[1], NULL, 16);
        if (errno != 0) {
            LOGE(DBG_TAG_TRVC, "Failed on strtoul\n");
        } else {
            if (uiAddr == (uint32)__LONG_MAX__) {
                LOGE(DBG_TAG_TRVC, "Failed to convert argument to address\n");
            } else {
                uiRead = TRVC_GpsbRead(uiAddr);
                LOGD(DBG_TAG_TRVC, "%08x = %08x\n", uiAddr, uiRead);
            }
        }
    }
}

/* coverity[HIS_metric_violation : FALSE] */
static void handlerForWritingSpi
(
    void * const                        argv[]
)
{
    uint32 __attribute__((unused)) uiAddr;
    uint32 __attribute__((unused)) uiValue;
    uint32 __attribute__((unused)) uiBefore;
    uint32 __attribute__((unused)) uiAfter;

    if (argv == NULL) {
        LOGE(DBG_TAG_TRVC, "Uninitialized argument\n");
    } else {
        errno = 0;
        uiAddr = (uint32)strtoul((char const *)argv[1], NULL, 16);
        if (errno != 0) {
            LOGE(DBG_TAG_TRVC, "Failed on strtoul\n");
        }
        if (uiAddr == (uint32)__LONG_MAX__) {
            LOGE(DBG_TAG_TRVC, "Failed to convert argument to uiAddr\n");
        } else {
            /* coverity[misra_c_2012_rule_11_5_violation : FALSE] */
            errno = 0;
            uiValue = (uint32)strtoul((char const *)argv[2], NULL, 16);
            if (errno != 0) {
                LOGE(DBG_TAG_TRVC, "Failed on strtoul\n");
            }
            if (uiValue == (uint32)__LONG_MAX__) {
                LOGE(DBG_TAG_TRVC, "Failed to convert argument to uiValue\n");
            } else {
                uiBefore = TRVC_GpsbRead(uiAddr);
                (void)TRVC_GpsbWrite(uiAddr, uiValue);
                uiAfter = TRVC_GpsbRead(uiAddr);

                LOGD(DBG_TAG_TRVC, "Write 0x%08 to 0x%08 (0x%08x -> 0x%08x)\n", uiValue, uiAddr,
                     uiBefore, uiAfter);
            }
        }
    }
}

static void showHelpMessage
(
    void
)
{
    LOGD(DBG_TAG_TRVC, "\n \
t: toggle big lock of TRVC [temporarily disable/enable TRVC]\n \
r [ADDR]: read a value from SPI register\n \
w [ADDR] [VALUE]: write a value to SPI register\n \
R [ADDR]: read a value from register\n \
W [ADDR] [VALUE]: write a value to register \n \
m [first] [last]: Dump SPI memory from address to address\n \
d: Run diagnostics\n");
}

static void handlerForHelp
(
    void * const                        argv[]
)
{
    if (argv == NULL) {
        LOGD(DBG_TAG_TRVC, "Invalid arguments");
    }
    showHelpMessage();
}

/* coverity[HIS_metric_violation : FALSE] */
static void handlerForWritingRegister
(
    void * const                        argv[]
)
{
    uint32 __attribute__((unused)) uiAddr;
    uint32 __attribute__((unused)) uiValue;

    if (argv == NULL) {
        LOGE(DBG_TAG_TRVC, "Uninitialized argument\n");
    } else {
        errno = 0;
        /* coverity[misra_c_2012_rule_11_5_violation : FALSE] */
        uiAddr = (uint32)(strtoul((char const *)argv[1], NULL, 16) & 0xFFFFFFFFU);
        if (errno != 0) {
            LOGE(DBG_TAG_TRVC, "Failed on strtoul\n");
        }
        errno = 0;
        uiValue = (uint32)(strtoul((char const *)argv[2], NULL, 16) & 0xFFFFFFFFU);
        if (errno != 0) {
            LOGE(DBG_TAG_TRVC, "Failed on strtoul\n");
        }
        /* coverity[cert_int36_c_violation : FALSE] */
        SAL_WriteReg(uiValue, uiAddr);
        LOGD(DBG_TAG_TRVC, "WRITE a VALUE of 0x%08x to ADDR: 0x%08x\n", uiAddr,
             uiValue);
    }
}

/* coverity[HIS_metric_violation : FALSE] */
static void handlerForReadingRegister
(
    void * const                        argv[]
)
{
    uint32 __attribute__((unused)) uiAddr;
    uint32 __attribute__((unused)) uiValue;

    if (argv == NULL) {
        LOGE(DBG_TAG_TRVC, "Uninitialized argument\n");
    } else {
        errno = 0;
        /* coverity[misra_c_2012_rule_11_5_violation : FALSE] */
        uiAddr = (uint32)strtoul((char const *)argv[1], NULL, 16);
        if (errno != 0) {
            LOGE(DBG_TAG_TRVC, "Failed on strtoul\n");
        }
        if (uiAddr == (unsigned)__LONG_MAX__) {
            LOGE(DBG_TAG_TRVC, "Invalid address: %u\n", uiAddr);
        } else {
            /* coverity[cert_int36_c_violation : FALSE] */
            uiValue = SAL_ReadReg(uiAddr);
            LOGD(DBG_TAG_TRVC, "READ a VALUE of 0x%08x from ADDR: 0x%08x\n", uiAddr, uiValue);
        }
    }
}

/* coverity[HIS_metric_violation : FALSE] */
static void handlerForMemoryDump
(
    void * const                        argv[]
)
{
    uint32 __attribute__((unused)) uiRead;
    uint32 __attribute__((unused)) uiCursor;
    uint32 uiFirst, uiLast;

    if (argv == NULL) {
        LOGE(DBG_TAG_TRVC,
             "SPI memory dump: [first address] [last addr]");
    } else {
        errno = 0;
        /* coverity[misra_c_2012_rule_11_5_violation : FALSE] */
        uiFirst = (uint32)strtoul((char const *)argv[1], NULL, 16);
        if (errno != 0) {
            LOGE(DBG_TAG_TRVC, "Failed on strtoul\n");
        }
        errno = 0;
        /* coverity[misra_c_2012_rule_11_5_violation : FALSE] */
        uiLast = (uint32)strtoul((char const *)argv[2], NULL, 16);
        if (errno != 0) {
            LOGE(DBG_TAG_TRVC, "Failed on strtoul\n");
        }
        for (uiCursor = uiFirst; uiCursor <= uiLast; uiCursor += 0x4U) {
            uiRead = TRVC_GpsbRead(uiCursor);
            LOGD(DBG_TAG_TRVC, "[ASD: 0x%08x] 0x%08x\n", uiCursor, uiRead);
            delay(TRVC_GPSB_DELAY_IN_CMD);
        }
    }
}

/* coverity[HIS_metric_violation : FALSE] */
static void handlerForBigLock
(
    void * const                        argv[]
)
{
    if (argv == NULL) {
        LOGE(DBG_TAG_TRVC,
             "SPI memory dump: [first address] [last addr]");
    } else {
        bTrvcBigLock = !bTrvcBigLock;
        mcu_printf("The state of TRVC lock is now: %d\n", bTrvcBigLock);
    }

}


static void handlerForDiagnostic
(
    void * const                        argv[]
)
{
	(void)argv;
	TRVC_RunDiagnostics();
}

static void handlerForSCI
(
    void * const                        argv[]
)
{
	(void)argv;

	(void)TRVC_InitializeChecker(NULL);

	/* Should be unlock register again, since it locked during the checker initialization.  */
	(void)TRVC_UnlockRegister();

	(void)TRVC_EnableWDMA((uint32)FALSE, (uint32)FALSE);
	(void)TRVC_EnableRDMA((uint32)FALSE);
    (void)TRVC_SetSafeCameraPath((uint32)FALSE, (uint32)FALSE, (uint32)FALSE, (uint32)FALSE,
                                 (uint32)FALSE, (uint32)FALSE);
    (void)TRVC_SWResetSafeCameraInterface((uint32)TRUE, (uint32)TRUE, (uint32)TRUE, (uint32)TRUE,
                                          (uint32)TRUE, (uint32)TRUE, (uint32)TRUE);
    (void)TRVC_SWResetSafeCameraInterface((uint32)FALSE, (uint32)FALSE, (uint32)FALSE,
                                          (uint32)FALSE, (uint32)FALSE, (uint32)FALSE,
                                          (uint32)FALSE);
    (void)TRVC_EnableSafeCamera();
}

static void handlerForChecker
(
    void * const                        argv[]
)
{
	(void)argv;
	(void)TRVC_InitializeChecker(NULL);
}

static void __attribute__((unused)) (*handler[TRVC_SPI_IF_MAX])(void * const *argv) = {
    handlerForHelp,                 // [TRVC_SPI_IF_HELP]
    handlerForReadingSpi,           // [TRVC_SPI_IF_SPI_READ]
    handlerForWritingSpi,           // [TRVC_SPI_IF_SPI_WRITE]
    handlerForReadingRegister,      // [TRVC_SPI_IF_READ_REG]
    handlerForWritingRegister,      // [TRVC_SPI_IF_WRITE_REG]
    handlerForMemoryDump,           // [TRVC_SPI_IF_MEM_DUMP]
    handlerForDiagnostic,           // [TRVC_SPI_IF_DIAGNOSTIC]
    handlerForBigLock,              // [TRVC_SPI_IF_BIGLOCK]
    handlerForSCI,
    handlerForChecker,
};

/* coverity[HIS_metric_violation : FALSE] */
void TRVC_ConsoleCommandHandler
(
    uint8                               ucArgc,
    void * const                        pArgv[]
)
{
    uint32 i;
    sint32 ret;
    const uint8 *str;

    if (((gDebugOption >> DBG_TAG_TRVC) & (gDebugOption >> DBG_CHECK_LEVEL) & DBG_CHECK_BIT) == 0U) {
        mcu_printf("Please set T-RVC log option with: log %d on", DBG_TAG_TRVC);
    }

    if ((ucArgc == 0U) || (pArgv == (void *)0)) {
        handler[TRVC_SPI_IF_HELP](NULL);
    } else {
        /* coverity[misra_c_2012_rule_11_5_violation : FALSE] */
        str = (const uint8 *)pArgv[0];

        (void)TRVC_UnlockRegister();
        for (i = 0U; i < TRVC_SPI_IF_MAX; i++) {
            if ((SAL_StrNCmp(str, args[i], 1, &ret) == SAL_RET_SUCCESS) &&
                (ret == 0)) {
                handler[i](pArgv);
                break;
            }
        }
        (void)TRVC_LockRegister();
    }
}
#endif
