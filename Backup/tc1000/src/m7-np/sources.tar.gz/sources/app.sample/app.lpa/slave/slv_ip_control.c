/*
***************************************************************************************************
*
*   FileName : slv_ip_control.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/*undefined_identifier:	identifier "errno" is undefined*/
#include <errno.h>
#include "demo_slv_ip_control.h"
#include "slv_framework.h"
#include "slv_ip_control.h"

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/

/**************************************************************************************************
*                                          LOCAL VARIABLES
**************************************************************************************************/

static MM_RESPONSE mrs_data;
static uint8 CM7_NP_statusFrameBuffer[LPA_TO_HOST_SIZE];

/***Task Queue handle***/
uint32 gLpaSfCtrlHandle = 0U;
/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/

void LPA_SF_ctrl_CreateAppTask(void);

static void IPC_IpcCbFunc_CM7_1
(
    uint16                              uhwCmd,
    uint8 *                             pucData,
    uint16                              uhwLength
); // CS : Dangerous Function Cast

static void IPC_IpcCbFunc_CM7_0
(
    uint16                              uhwCmd,
    uint8 *                             pucData,
    uint16                              uhwLength
);

/*decl_incompatible_with_previous_use:	declaration is incompatible with previous "LPA_SF_ctrl" (declared at line 175)*/
static void sf_lpa_rx_setStatusCB(LpaStatusCallback cbFunc);

/*
***************************************************************************************************
*                                         FUNCTIONS
***************************************************************************************************
*/

/* misra_c_2012_rule_8_4_violation:	Function definition does not have a visible prototype.*/
static void sf_lpa_rx_setStatusCB(LpaStatusCallback cbFunc)
{
    sfLpaStatusCB = cbFunc;
}

/* CM7 -> NP */
void LPA_SF_ctrl(uint16 cmd, uint8 *data)
{
    (void)IPC_SendPacket(IPC_CH_CM7_NP_LPA,(uint8)TCC_IPC_CMD_IP_CTRL, (uint16)cmd, &data[0], sizeof(data));
}

/*misra_c_2012_rule_8_4_violation:	Function definition does not have a visible prototype.*/
void LPA_SF_stat(uint16 cmd, uint8 *data)
{
    (void)IPC_SendPacket(IPC_CH_CM7_NP_LPA, (uint8)TCC_IPC_CMD_IP_STAS, (uint16)cmd, data, 8);
}

/* NP -> CM7 */
static void slv_IpcCbFunc_CM7_NP_Resp(uint16 uhwCmd, uint8 *pucData, uint16 uhwLength)
{
    /*misra_c_2012_rule_9_1_violation:	Using uninitialized value "val" when calling "DBG_SerialPrintf".*/
    uint32 val = 0u;
    LPA_REG_DATA reg;

    if (uhwCmd == TCC_IPC_CMD_RESP_VAL)
    {
        if (pucData != NULL_PTR)
        {
            SAL_MemCopy(&val, (uint32*)pucData, 4U);
            mcu_printf("LPA validation : %08x\n", pucData[0]);
        }
    }
    else if (uhwCmd == TCC_IPC_CMD_RESP_CNT)
    {
        if (pucData != NULL_PTR)
        {
            SAL_MemCopy(&mrs_data, pucData, sizeof(MM_RESPONSE));
            if (mrs_data.type == MM_RESPONSE_TYPE)
            {
                reg.addr  = (mrs_data.data.RD_ADDR0 & 0x00FFu) << 8U;
                reg.addr |= ((mrs_data.data.RD_ADDR0 & 0xFF00u) >> 8U);
                reg.data[0] = lpa_swap32(mrs_data.data.data0);
                reg.data[1] = lpa_swap32(mrs_data.data.data1);
                reg.data[2] = lpa_swap32(mrs_data.data.data2);
                reg.data[3] = lpa_swap32(mrs_data.data.data3);

                slv_print_port_statistics_info(&reg);
            }

            /* send msg to NP, finished queue processing */
            LPA_SF_ctrl(TCC_IPC_CMD_IP_CTRL_QUEUE_FINISHED, NULL);
        }
    }
}

static void slv_IpcCbFunc_CM7_NP_Status(uint16 uhwCmd, uint8 *pucData, uint16 uhwLength)
{
    if(uhwCmd == TCC_IPC_CMD_STAS_SEND)
    {
        SAL_MemCopy(&CM7_NP_statusFrameBuffer[0], pucData, uhwLength);

        sf_parse_status_frame(&CM7_NP_statusFrameBuffer[0]);
    }
}


static void LPA_SF_ctrlTask(void * pArg)
{
    LPA_TX_MESSAGE msg;
    uint32 copiedSize = 0U;
    LPA_REG_DATA reg;

    IPC_RegisterCbFunc(IPC_CH_CM7_NP_LPA, (uint8)TCC_IPC_CMD_RESP, (IPCCallback)&slv_IpcCbFunc_CM7_NP_Resp, NULL_PTR, NULL_PTR);
    IPC_RegisterCbFunc(IPC_CH_CM7_NP_LPA, (uint8)TCC_IPC_CMD_CAN_STAS, (IPCCallback)&slv_IpcCbFunc_CM7_NP_Status, NULL_PTR, NULL_PTR);
    IPC_RegisterCbFunc(IPC_CH_CM7_NP_LPA, (uint8)TCC_IPC_CMD_LIN_STAS, (IPCCallback)&slv_IpcCbFunc_CM7_NP_Status, NULL_PTR, NULL_PTR);

    sf_lpa_rx_setStatusCB(sf_print_status_frame_info);
    mcu_printf("\n Slave Framework v%d.%d.%d\n",
        verInfo.majorVer, verInfo.minorVer, verInfo.patchVer);

    while(1)
    {
        if(SAL_QueueGet(gLpaSfCtrlHandle, (void *)&msg, &copiedSize, portMAX_DELAY, SAL_OPT_BLOCKING) != SAL_RET_SUCCESS)
        {
            mcu_printf("[%s] Fatal!! Get Ctrl Queue Fail. \n", __func__);
        }

        switch(msg.MsgID)
        {
            case SHOW_PORT_STAT:
            SAL_MemCopy(&mrs_data, &msg.MsgData[0], sizeof(MM_RESPONSE));
            if (mrs_data.type == MM_RESPONSE_TYPE)
            {
                reg.addr  = (mrs_data.data.RD_ADDR0 & 0x00FFu) << 8U;
                reg.addr |= ((mrs_data.data.RD_ADDR0 & 0xFF00u) >> 8U);
                reg.data[0] = lpa_swap32(mrs_data.data.data0);
                reg.data[1] = lpa_swap32(mrs_data.data.data1);
                reg.data[2] = lpa_swap32(mrs_data.data.data2);
                reg.data[3] = lpa_swap32(mrs_data.data.data3);

                sf_parse_status_frame((uint8 *)&reg);
            }

                break;
        }

    }
    (void)SAL_QueueDelete(gLpaSfCtrlHandle);

}
void LPA_SF_ctrl_CreateAppTask(void)
{
    static uint32 LPA_sfCtrlTaskId;
    static uint32 LPA_sfCtrlStk[1024];
    static uint8 LPA_sfCtrlBuffer[LPA_SF_CTRL_QUEUE_NUM * sizeof(LPA_TX_MESSAGE)];

    if(SAL_QueueCreate( &gLpaSfCtrlHandle,
                ( const uint8 * ) "LpaSfCtrlQ",
                ( void * )LPA_sfCtrlBuffer,
                LPA_SF_CTRL_QUEUE_NUM,
                sizeof(LPA_TX_MESSAGE)) != SAL_RET_SUCCESS)
    {
        mcu_printf("%s Fatal!! LPA SF Control Queue Create Fail.\n", __func__);
    }

    if(SAL_TaskCreate(&LPA_sfCtrlTaskId,
                         (const uint8 *)"sfAppsampleIp",
                         (SALTaskFunc)&LPA_SF_ctrlTask,
                         &LPA_sfCtrlStk[0],
                         1024,
                         7, NULL_PTR) != SAL_RET_SUCCESS)
    {
        mcu_printf("%s Fatal!! Task Create Fail. \n", __func__);
    }

}
