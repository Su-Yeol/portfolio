/*
***************************************************************************************************
*
*   FileName : demo_tx.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/**************************************************************************************************
*                                           INCLUDE FILES
**************************************************************************************************/
#include <errno.h>
#include <stdlib.h>
#include "demo_tx.h"
#include "debug.h"

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/

/**************************************************************************************************
*                                          LOCAL VARIABLES
**************************************************************************************************/

/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/

/**************************************************************************************************
*                                             FUNCTIONS
**************************************************************************************************/
void LPA_TX_CLI_Help(void)
{
	mcu_printf( "=== wrong argument ===\n" );
    mcu_printf( "=== USAGE INFO ===\n\n" );
    mcu_printf( "=== CMD LIST ===\n" );
    mcu_printf( "lpatx can send (x) (y) (z): x = port number 1~16, y = CAN ID (0 ~ 2047 -> 7ff), z = data length\n" );
    mcu_printf( "lpatx can Extend (x) (y) (z) : x = port number 1~16, y = CAN ExtID (0 ~ 536870911 -> 1fffffff), z = data length\n" );
    mcu_printf( "lpatx canfd send (x) (y) (z) : x = port number 1~16, y = CAN ID (0 ~ 2047 -> 7ff), z = data length\n" );
    mcu_printf( "lpatx canfd Extend (x) (y) (z) : x = port number 1~16, y = CAN ExtID (0 ~ 536870911 -> 1fffffff), z = data length\n" );
    mcu_printf( "lpatx lin send (x) (y) (z) : x = port number 1~8, y = LIN ID (0 ~ 63 -> 3f), z = 't'- transmit, 'r' - receive \n" );
}

void LPA_Tx_CLI(uint8 ucArgc, void* const pArgv[])
{
	(void)ucArgc;
    uint8 *pucStr1;
    uint8 *pucStr2;
    uint8 *pucStr3;
    uint8 *pucStr4;
    uint8 *pucStr5;

    uint32 portN;
    uint32 LinID;
    uint32 CanID  =0;
    uint32 ExtCanID;
    uint32 DataLen = 0;
    uint8 Data[64U];
    uint8 LinOp;
    uint8 i = 0;

    sint32 ret;

    pucStr1 = NULL_PTR;
    pucStr2 = NULL_PTR;
    pucStr3 = NULL_PTR;
    pucStr4 = NULL_PTR;
    pucStr5 = NULL_PTR;

#if 1
	for (i = 0 ; i < 64U; i++)
	{
		Data[i] = (i * 4U) + 3U;
	}
#else
    Data[0] = 0x1A;
    Data[1] = 0x2B;
    Data[2] = 0x3C;
    Data[3] = 0x4D;
#endif

    if( pArgv != NULL_PTR )
    {
		SAL_MemCopy(&pucStr1, &pArgv[0], 4U);
		SAL_MemCopy(&pucStr2, &pArgv[1], 4U);
		SAL_MemCopy(&pucStr3, &pArgv[2], 4U);
		SAL_MemCopy(&pucStr4, &pArgv[3], 4U);
		SAL_MemCopy(&pucStr5, &pArgv[4], 4U);

        if( pucStr1 != NULL_PTR )
        {
            if( ( SAL_StrNCmp( pucStr1, ( const uint8 * ) "canfd", 5, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
            {
                if( ( SAL_StrNCmp( pucStr2, ( const uint8 * ) "send", 4, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
                    errno = 0;
                    portN = strtoul((int8 *)pucStr3, NULL, 10);
                    if (((portN >= 1U) && (portN <= 16U)) && (errno == 0))
                    {
                        errno = 0;
                        CanID = strtoul((int8 *)pucStr4, NULL, 10);
                        if ((CanID < 2048U) && (errno == 0))
                        {
                            errno = 0;
                            DataLen = strtoul((int8 *)pucStr5, NULL, 10);
                            if ((DataLen <= 64U) && (errno == 0))
                            {
                                errno = 0;
                                mcu_printf("port Number :%d, CANFD ID : %d, Data length : %d\n", portN, CanID, DataLen);
                                (void)frm_lpa_sendFrame(FRAME_TYPE_CANFD_BASE, (uint8)portN, CanID, (uint8)DataLen, Data);
                            }
                        }
                    }
                }
                else if( ( SAL_StrNCmp( pucStr2, ( const uint8 * ) "Extend", 6, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
                    errno = 0;
                    portN = strtoul((int8 *)pucStr3, NULL, 10);
                    if (((portN >= 1U) && (portN <= 16U)) && (errno == 0))
                    {
                        errno = 0;
                        ExtCanID = strtoul((int8 *)pucStr4, NULL, 10);
                        if ((ExtCanID < 0x1FFFFFFFUL) && (errno == 0))
                        {
                            errno = 0;
                            DataLen = strtoul((int8 *)pucStr5, NULL, 10);
                            if ((DataLen <= 64U) && (errno == 0))
                            {
                                errno = 0;
                                mcu_printf("port Number :%d, CANFD ExtID : %d, Data length : %d\n", portN, ExtCanID, DataLen);
                                (void)frm_lpa_sendFrame(FRAME_TYPE_CANFD_EXT, (uint8)portN, ExtCanID, (uint8)DataLen, Data);
                            }
                        }
                    }
                }
                else
                {
                    /*** nothing ***/
                }
            }
            else if( ( SAL_StrNCmp( pucStr1, ( const uint8 * ) "can", 3, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
            {
                if( ( SAL_StrNCmp( pucStr2, ( const uint8 * ) "send", 4, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
                    errno = 0;
                    portN = strtoul((int8 *)pucStr3, NULL, 10);
                    if (((portN >= 1U) && (portN <= 16U)) && (errno == 0))
                    {
                        errno = 0;
                        CanID = strtoul((int8 *)pucStr4, NULL, 10);
                        if ((CanID < 2048U) && (errno == 0))
                        {
                            errno = 0;
                            DataLen = strtoul((int8 *)pucStr5, NULL, 10);
                            if ((DataLen <= 8U) && (errno == 0))
                            {
                                errno = 0;
                                mcu_printf("port Number :%d, CAN ID : %d, Data length : %d\n", portN, CanID, DataLen);
                                (void)frm_lpa_sendFrame(FRAME_TYPE_CAN_BASE, (uint8)portN, CanID, (uint8)DataLen, Data);
                            }
                        }
                    }
                }
                else if( ( SAL_StrNCmp( pucStr2, ( const uint8 * ) "Extend", 6, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
                    errno = 0;
                    portN = strtoul((int8 *)pucStr3, NULL, 10);
                    if (((portN >= 1U) && (portN <= 16U)) && (errno == 0))
                    {
                        errno = 0;
                        ExtCanID = strtoul((int8 *)pucStr4, NULL, 10);
                        if ((ExtCanID < 0x1FFFFFFFUL) && (errno == 0))
                        {
                            errno = 0;
                            DataLen = strtoul((int8 *)pucStr5, NULL, 10);
                            if ((DataLen <= 64U) && (errno == 0))
                            {
                                errno = 0;
                                mcu_printf("port Number :%d, CAN ExtID : %d, Data length : %d\n", portN, ExtCanID, DataLen);
                                (void)frm_lpa_sendFrame(FRAME_TYPE_CAN_EXT, (uint8)portN, ExtCanID, (uint8)DataLen, Data);
                            }
                        }
                    }
                }
                else
                {
                    /*** nothing ***/
                }

            }
            else if( ( SAL_StrNCmp( pucStr1, ( const uint8 * ) "lin", 3, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
            {
                if( ( SAL_StrNCmp( pucStr2, ( const uint8 * ) "send", 4, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
                    LPA_FRAME_TYPE type;
                    LinOp = pucStr5[0];

                    if ((LinOp == (uint8)'t') || (LinOp == (uint8)'r'))
                    {
                        DataLen = 8U; //fixed length
                        if (LinOp == (uint8)'t') {
                            type = FRAME_TYPE_LIN_TX;
                        }
                        else {
                            type = FRAME_TYPE_LIN_RX;
                        }

                        errno = 0;
                        portN = strtoul((int8 *)pucStr3, NULL, 10);
                        if (((portN >= 1U) && (portN <= 8U)) && (errno == 0))
                        {
                            errno = 0;
                            LinID = strtoul((int8 *)pucStr4, NULL, 10);
                            if ((LinID < 64U) && (errno == 0))
                            {
                                errno = 0;
                                mcu_printf("port Number :%d, LIN ID : %d, Data length : %d\n", portN, LinID, DataLen);
                                (void)frm_lpa_sendFrame(type, (uint8)portN, LinID, (uint8)DataLen, Data);
                            }
                        }
                    }
                    else
                    {
                        mcu_printf("wrong argument only 't' or 'r'");
                    }
                }
            }
            else
            {
                LPA_TX_CLI_Help();
            }
        }
    }
    else
    {
        LPA_TX_CLI_Help();
    }

}

