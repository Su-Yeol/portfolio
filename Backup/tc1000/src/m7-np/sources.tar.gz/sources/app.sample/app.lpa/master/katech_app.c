/*
 * katech_app.c
 *
 *  Created on: 2024. 4. 17.
 *      Author: jyhan
 */

#include "katech_llce.h"
#include "katech_ipcf.h"
#include "katech_task_manager.h"
#include "katech_can_app.h"


#include "Siul2_Port_Ip.h"
#include "Siul2_Dio_Ip.h"
#include "Siul2_Dio_Ip_Cfg.h"



extern volatile uint32 Can_RxIndication;
extern volatile struct KATECH_SW_CAN_BUFF_BOX katech_sw_rxcan_buff;



extern uint32_t katech_usec;




void katech_pit_run(void)
{

	static uint32 cnt=0;


	cnt++;
}

void katech_pit_run_active(void)
{
	static uint16 cnt=0;
	if(cnt++>=10)
	{

		cnt=0;
	}

}

extern void katech_ipcf_test(void);


void katech_temp_func(void)
{
	static uint32_t katech_temp_func_cnt=0;
	static uint8_t katech_temp_func_cnt_isr;
	if(++katech_temp_func_cnt > 5000)
	{
		if (katech_temp_func_cnt_isr==0)
		{
			katech_temp_func_cnt_isr = 1;
			Siul2_Dio_Ip_WritePin(PTA, 9U, 0U); // ON
			Siul2_Dio_Ip_WritePin(PTA, 11U, 1U); // ON
		}else
		{
			katech_temp_func_cnt_isr = 0;
			Siul2_Dio_Ip_WritePin(PTA, 9U, 1U); // OFF
			Siul2_Dio_Ip_WritePin(PTA, 11U, 0U); // ON
		}
		katech_temp_func_cnt = 0;

	}
}


uint32_t katech_app_init(void)
{
	uint32_t period;
	katech_tmn_init(100,10);
	katech_tmn_task_register(katech_ipcf_test,10);
	katech_tmn_task_register(TxCAN2_WHL_01_10ms,10);
	katech_tmn_task_register(katech_temp_func,10);
    katech_tmn_task_register(TxCAN1_ADAS_CMD_10_20ms,20);
    katech_tmn_task_register(TxCAN1_ADAS_CMD_20_20ms,20);
    katech_tmn_task_register(TxCAN2_ADAS_PRK_20_20ms,20);

    katech_tmn_task_register(TxCAN1_ADAS_CMD_32_50ms,50);
    katech_tmn_task_register(katech_llce_check_bus_err,100);


    katech_llce_init();
    katech_ipcf_init();
    return period;
}

void katech_app_run(void){
	katech_can_app_mode_set(KATECH_CAN_APP_AD_MODE);
    for(;;){
    	katech_tmn_loop(katech_usec);
    }
}



