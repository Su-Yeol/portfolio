/*
 * katech_llce.c
 *
 *  Created on: 2024. 4. 9.
 *      Author: jyhan
 */


#include "katech_llce.h"
#include "katech_can_app.h"
#include "IntCtrl_Ip.h"
#include "IntCtrl_Ip_Cfg.h"

#include "Can_43_LLCE.h"
#include "Can_43_LLCE_IPW.h"
#include "CanIf_Can.h"
#include "CanIf.h"
#include "Std_Types.h"

#include "SchM_Can_43_LLCE.h"
#include <string.h>

#if (CAN_43_LLCE_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif /* (CAN_43_LLCE_DEV_ERROR_DETECT == STD_ON) */


extern ISR(Can_FifoTxAckNotEmptyIsr_0_7);
extern ISR(Can_FifoTxAckNotEmptyIsr_8_15);
extern ISR(Can_FifoRxOutNotEmptyIsr_0_7);
extern ISR(Can_FifoRxOutNotEmptyIsr_8_15);
extern ISR(Can_FifoRxInNotEmptyIsr_0_7);
extern ISR(Can_FifoRxInNotEmptyIsr_8_15);


extern volatile uint32 Can_RxIndication;


static Std_ReturnType katech_llce_can_write_cmd( Can_HwHandleType Hth, const Can_PduType * PduInfo)
{
    /* Variable for return status */
    Std_ReturnType  eReturnValue = E_NOT_OK;

    PduInfoType PduInfoTriggerTransmit;

    /* Enter into EA in order to protect access to Can_au16TransmitHwObjectCnt array */
    SchM_Enter_Can_43_LLCE_CAN_EXCLUSIVE_AREA_02();

    /* Check if the maximum Tx objects for the current HTH has been exhausted */
    //if ( 0U == Can_au16TransmitHwObjectCnt[Hth - CAN_43_LLCE_FIRST_HTH_CONFIGURED] )
    {
        /* No Tx object available */
        //eReturnValue = CAN_BUSY;
    }
    //else
    {
        /* Reserve a new MB in advance, assuming that this flows is E_OK */
        //Can_au16TransmitHwObjectCnt[Hth - CAN_43_LLCE_FIRST_HTH_CONFIGURED]--;

        /* Create the PduInfoTriggerTransmit information */
        PduInfoTriggerTransmit.SduLength = PduInfo->length;
        PduInfoTriggerTransmit.SduDataPtr = (uint8 *)PduInfo->sdu;


            /* Call the IPW function for transmitting data. */
		eReturnValue = Can_43_LLCE_IPW_Write( Hth, PduInfo, PduInfoTriggerTransmit);

        if ((Std_ReturnType)E_OK != eReturnValue)
        {
            /* On the error case, release the buffer reserved in advance. */
            //Can_au16TransmitHwObjectCnt[Hth - CAN_43_LLCE_FIRST_HTH_CONFIGURED]++;
        }

    }
    SchM_Exit_Can_43_LLCE_CAN_EXCLUSIVE_AREA_02();

    return eReturnValue;
}

Std_ReturnType katech_llce_can_write( Can_HwHandleType Hth, const Can_PduType * PduInfo)
{
    /* Variable for return status */
    Std_ReturnType  eReturnValue = E_NOT_OK;

    uint8 u8CtrlId = 0U;
    /* Used to store the FD feature enable or disable. */
    uint8 u8FdEnable;
    uint8 u8BaudrateIndex = 0U;
    const Can_43_LLCE_ControllerDescriptorType * pCanControllerDescriptor;



    /* If Can_43_LLCE_pCurrentConfig is NULL_PTR then the driver was not initialised yet. */
    if ( CAN_43_LLCE_UNINIT == Can_43_LLCE_eDriverStatus )
    {
        (void)Det_ReportError( (uint16)CAN_43_LLCE_MODULE_ID, (uint8)CAN_43_LLCE_INSTANCE, (uint8)CAN_43_LLCE_SID_WRITE, (uint8)CAN_43_LLCE_E_UNINIT);
    }
    else
    {
        if ( (Hth >= CanStatic_43_LLCE_pCurrentConfig->u32CanMaxObjectId) ||
             (CAN_43_LLCE_TRANSMIT != Can_43_LLCE_pCurrentConfig->aHohList[Hth].eMBType)
           )

        {
            (void)Det_ReportError( (uint16)CAN_43_LLCE_MODULE_ID, (uint8)CAN_43_LLCE_INSTANCE, (uint8)CAN_43_LLCE_SID_WRITE, (uint8)CAN_43_LLCE_E_PARAM_HANDLE);
        }
        else
        {
            if ( (NULL_PTR == PduInfo) || (NULL_PTR == PduInfo->sdu) )
            {
                (void)Det_ReportError( (uint16)CAN_43_LLCE_MODULE_ID, (uint8)CAN_43_LLCE_INSTANCE, (uint8)CAN_43_LLCE_SID_WRITE, CAN_43_LLCE_E_PARAM_POINTER);
            }
            else
            {
                u8CtrlId = Can_43_LLCE_pCurrentConfig->aHohList[Hth].u8ControllerId;

                pCanControllerDescriptor = &(Can_43_LLCE_pCurrentConfig->aControllerDescriptors[u8CtrlId]);

                /* Get the index of the current baud rate */
                u8BaudrateIndex = Can_43_LLCE_ControllerBaudRateIndexes[u8CtrlId].u8CurrentBaudRateIndex;

                /* Get the status of the FD feature */
                u8FdEnable = pCanControllerDescriptor->pControllerBaudrateConfigsPtr[u8BaudrateIndex].baudrateConfig.ControllerFD.u8FdEnable;

            /* Report error if length > 8 bytes. */
                if ( \
                        ( (u8FdEnable == (uint8)FALSE) && ((PduInfo->length) > (uint8)8U) ) || \
                        ( (u8FdEnable == (uint8)TRUE) && ((PduInfo->length) > (uint8)64U) ) || \
                        (( (((uint32)PduInfo->id) & (uint32)CAN_LPDU_FD_U32) != CAN_LPDU_FD_U32) && ( (PduInfo->length) > (uint8)8U )) \
                )
                {
                    (void)Det_ReportError( (uint16)CAN_43_LLCE_MODULE_ID, (uint8)CAN_43_LLCE_INSTANCE, (uint8)CAN_43_LLCE_SID_WRITE, CAN_43_LLCE_E_PARAM_DATA_LENGTH);
                    eReturnValue = E_NOT_OK;
                }
                else
                {
                    eReturnValue = katech_llce_can_write_cmd(Hth, PduInfo);
                }
            }
        }
    }

    return eReturnValue;
}


volatile KATECH_CANFD_PDU_BUFF katech_sw_rxcan_buff;

katech_rx_can_func katech_rx_can_func_list[4]={katech_rx_can0,katech_rx_can1,katech_rx_can2,katech_rx_can3};

void CanIf_RxIndication( const Can_HwType* Mailbox, const PduInfoType* PduInfoPtr )
{
	/* Local variable */
	uint8 i = 0U;
	uint16 pos;
	uint32_t id;
	uint8_t ch;
	uint8_t rxdata[64];
	//struct KATECH_SW_CAN_BUFF *buff = &katech_sw_rxcan_buff.buff[pos];
	//Can_PduType *pdu = &buff->pdu;


	for (i = 0; i < PduInfoPtr->SduLength; i++)
	{
		rxdata[i] = PduInfoPtr->SduDataPtr[i];
	}

	for (i = PduInfoPtr->SduLength; i < CAN_FD_FRAME_LEN; i++)
	{

		rxdata[i] = 0;
	}


	Can_RxIndication++;

	ch = Mailbox->ControllerId;
	id = Mailbox->CanId&0x7ff;

	katech_rx_can_func_list[ch](id,rxdata); // 241129 sy.kim when can interrupt, this func run

}

int katech_llce_can_pdu_read2( KATECH_Canfd_PduType * rxpdu)
{
	int ret = -1;
	uint8 i = 0U;
	//for(;;)
	{
		if(katech_sw_rxcan_buff.cnt_read!=katech_sw_rxcan_buff.cnt_write)
		{
			uint16 pos = katech_sw_rxcan_buff.cnt_read%KATECH_CAN_DATA_BUFF_SIZE;
			ret = katech_sw_rxcan_buff.buff[pos].ch;
			KATECH_Canfd_PduType *buff = &katech_sw_rxcan_buff.buff[pos];


			memcpy(rxpdu,buff,sizeof(76));



			katech_sw_rxcan_buff.cnt_read+=1;
			//break;
		}
	}



	return ret;
}

KATECH_Canfd_PduType *katech_llce_can_pdu_read( KATECH_Canfd_PduType * rxpdu)
{
	KATECH_Canfd_PduType* ret = 0;
	uint8 i = 0U;
	//for(;;)
	{
		if(katech_sw_rxcan_buff.cnt_read!=katech_sw_rxcan_buff.cnt_write)
		{
			uint16 pos = katech_sw_rxcan_buff.cnt_read%KATECH_CAN_DATA_BUFF_SIZE;
			ret = katech_sw_rxcan_buff.buff[pos].ch;
			ret = &katech_sw_rxcan_buff.buff[pos];

			katech_sw_rxcan_buff.cnt_read+=1;
			//break;
		}
	}



	return ret;
}


//uint8 katech_llce_init_rx_buff[KATECH_CAN_DATA_BUFF_SIZE][64];
void katech_llce_init(void)
{
    volatile StatusType fail = E_OK;
    Can_ErrorStateType ErrorState;
    Std_ReturnType can_retval = E_NOT_OK;
    uint16 u16MbGlobalIndex = 0U;

    const Can_43_LLCE_ConfigType *Can_Cfg1 = &Can_43_LLCE_Config_BOARD_InitPeripherals;
    katech_sw_rxcan_buff.cnt_write=0;
	katech_sw_rxcan_buff.cnt_read=0;

	/*
	for(int i=0;i<KATECH_CAN_DATA_BUFF_SIZE;i++)
	{

			struct KATECH_SW_CAN_BUFF *buff = &katech_sw_rxcan_buff.buff[i];
			Can_PduType *pdu = &buff->pdu;
			pdu->sdu=katech_llce_init_rx_buff[i];
	}
	*/

    Llce_Firmware_Load();
    Can_43_LLCE_Init(Can_Cfg1);

    /* Reset global flags and counters. */
    Can_CallBackSetUp();

    (void)can_retval;

    can_retval = Can_43_LLCE_SetBaudrate(CONTROLLER0, 0); /* Index 1 corresponds to a baudrate configuration of (500 kbps; 2000 kbps).See Tresos configuration*/
    can_retval = Can_43_LLCE_SetControllerMode(CONTROLLER0, CAN_CS_STARTED);
    can_retval = Can_43_LLCE_GetControllerErrorState(CONTROLLER0, &ErrorState);

    can_retval = Can_43_LLCE_SetBaudrate(CONTROLLER1, 0); /* Index 1 corresponds to a baudrate configuration of (500 kbps; 2000 kbps).See Tresos configuration*/
    can_retval = Can_43_LLCE_SetControllerMode(CONTROLLER1, CAN_CS_STARTED);
    can_retval = Can_43_LLCE_GetControllerErrorState(CONTROLLER1, &ErrorState);

    can_retval = Can_43_LLCE_SetBaudrate(CONTROLLER2, 0); /* Index 1 corresponds to a baudrate configuration of (500 kbps; 2000 kbps).See Tresos configuration*/
    can_retval = Can_43_LLCE_SetControllerMode(CONTROLLER2, CAN_CS_STARTED);
    can_retval = Can_43_LLCE_GetControllerErrorState(CONTROLLER2, &ErrorState);

    can_retval = Can_43_LLCE_SetBaudrate(CONTROLLER3, 0); /* Index 1 corresponds to a baudrate configuration of (500 kbps; 2000 kbps).See Tresos configuration*/
    can_retval = Can_43_LLCE_SetControllerMode(CONTROLLER3, CAN_CS_STARTED);
    can_retval = Can_43_LLCE_GetControllerErrorState(CONTROLLER3, &ErrorState);


    IntCtrl_Ip_InstallHandler(LLCE0_ICSR14_IRQn, Can_FifoRxInNotEmptyIsr_0_7, NULL_PTR);
    IntCtrl_Ip_EnableIrq(LLCE0_ICSR14_IRQn);
    IntCtrl_Ip_InstallHandler(LLCE0_ICSR15_IRQn, Can_FifoRxInNotEmptyIsr_8_15, NULL_PTR);
    IntCtrl_Ip_EnableIrq(LLCE0_ICSR15_IRQn);
    IntCtrl_Ip_InstallHandler(LLCE0_ICSR16_IRQn, Can_FifoRxOutNotEmptyIsr_0_7, NULL_PTR);
    IntCtrl_Ip_EnableIrq(LLCE0_ICSR16_IRQn);
    IntCtrl_Ip_InstallHandler(LLCE0_ICSR17_IRQn, Can_FifoRxOutNotEmptyIsr_8_15, NULL_PTR);
    IntCtrl_Ip_EnableIrq(LLCE0_ICSR17_IRQn);

    IntCtrl_Ip_InstallHandler(LLCE0_ICSR22_IRQn, Can_FifoTxAckNotEmptyIsr_0_7, NULL_PTR);
    IntCtrl_Ip_EnableIrq(LLCE0_ICSR22_IRQn);
    IntCtrl_Ip_InstallHandler(LLCE0_ICSR23_IRQn, Can_FifoTxAckNotEmptyIsr_8_15, NULL_PTR);
    IntCtrl_Ip_EnableIrq(LLCE0_ICSR23_IRQn);


}

int katech_llce_reset_ch(uint8_t controller)
{
    volatile StatusType fail = E_OK;
    Can_ErrorStateType ErrorState;
    Std_ReturnType can_retval = E_OK;
    uint16 u16MbGlobalIndex = 0U;

    katech_sw_rxcan_buff.cnt_write=0;
	katech_sw_rxcan_buff.cnt_read=0;

	//can_retval|=Llce_Firmware_Load();

    const Can_43_LLCE_ConfigType *Can_Cfg1 = &Can_43_LLCE_Config_BOARD_InitPeripherals;


    (void)can_retval;

	Can_43_LLCE_MainFunction_ErrorNotification();
    Can_43_LLCE_SetControllerMode(controller, CAN_CS_STOPPED);
    Can_43_LLCE_SetControllerMode(controller, CAN_CS_UNINIT);

	/*
	for(int i=0;i<KATECH_CAN_DATA_BUFF_SIZE;i++)
	{

			struct KATECH_SW_CAN_BUFF *buff = &katech_sw_rxcan_buff.buff[i];
			Can_PduType *pdu = &buff->pdu;
			pdu->sdu=katech_llce_init_rx_buff[i];
	}
	*/
	Can_43_LLCE_SetBaudrate(controller, 0); /* Index 1 corresponds to a baudrate configuration of (500 kbps; 2000 kbps).See Tresos configuration*/
	Can_43_LLCE_SetControllerMode(controller, CAN_CS_STARTED);
	Can_43_LLCE_GetControllerErrorState(controller, &ErrorState);

    return can_retval;
}


int katech_llce_check_ch_err(uint8_t contorller)
{
	Can_ErrorStateType ErrorState;
	Std_ReturnType can_retval = E_NOT_OK;

	const Can_43_LLCE_ConfigType *Can_Cfg1 = &Can_43_LLCE_Config_BOARD_InitPeripherals;

	can_retval |= Can_Llce_GetControllerErrorState(Can_Cfg1->aControllerDescriptors[contorller].u8HwCtrl, &ErrorState);
	can_retval |= ErrorState;

	return can_retval;
}





int katech_llce_check_bus_err(void)
{
	int ret=0;
	for(int i=0;i<4;i++)
	{
		ret=katech_llce_check_ch_err(i);
		if(ret>0) katech_llce_reset_ch(i);
	}
}


