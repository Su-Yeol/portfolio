/*
***************************************************************************************************
*
*   FileName : demo_rx.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/
/*cert_dcl37_c_violation:	The reserved identifier "_DEMO_RX_H_", which is reserved for use as identifiers with file scope in both the ordinary and tag name spaces, is defined.*/
#ifndef DEMO_RX_H_
#define DEMO_RX_H_

#include "sal_com.h"
#include "mst_framework.h"

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/

/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/
/*misra_c_2012_rule_8_6_violation:	Function "LPA_RX_CLI_Help" is declared but never defined.*/
//void LPA_RX_CLI_Help(void);
//extern void LPA_Rx_CLI(uint8 ucArgc, void* const pArgv[]);

void cb_print_reg_data_info(const LPA_REG_DATA *reg_data);
void cb_print_data_frame_info(const RX_DATA_FRAME *rx_data);
void cb_print_ts_frame_info(const RX_TS_FRAME *rx_ts);
void cb_print_status_frame_info(const RX_STATUS_FRAME *rx_status);
#endif /* DEMO_RX_H_ */

