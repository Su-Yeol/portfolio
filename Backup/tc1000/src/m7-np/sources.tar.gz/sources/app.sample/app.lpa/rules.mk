###################################################################################################
#
#   FileName : ruls.mk
#
#   Copyright (c) Telechips Inc.
#
#   Description :
#
#
###################################################################################################
#
#   TCC Version 1.0
#
#   This source code contains confidential information of Telechips.
#
#   Any unauthorized use without a written permission of Telechips including not limited to
#   re-distribution in source or binary form is strictly prohibited.
#
#   This source code is provided "AS IS" and nothing contained in this source code shall constitute
#   any express or implied warranty of any kind, including without limitation, any warranty of
#   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
#   or other third party intellectual property right. No warranty is made, express or implied,
#   regarding the information's accuracy,completeness, or performance.
#
#   In no event shall Telechips be liable for any claim, damages or other liability arising from,
#   out of or in connection with this source code or the use in the source code.
#
#   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
#   Telechips and Company.
#   This source code is provided "AS IS" and nothing contained in this source code shall constitute
#   any express or implied warranty of any kind, including without limitation, any warranty
#   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
#   copyright or other third party intellectual property right. No warranty is made, express or
#   implied, regarding the information's accuracy, completeness, or performance.
#   In no event shall Telechips be liable for any claim, damages or other liability arising from,
#   out of or in connection with this source code or the use in the source code.
#   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
#   between Telechips and Company.
#
###################################################################################################

SIC_BSP_APP_LPA_PATH := $(SIC_BSP_BUILD_CURDIR)

# Flags
# If you want to use "SIC_BSP_SUPPORT_IPC_DATA_SEND", unannotate the "slv_data_router" at "./slave/rules.mk".
COMMON_FLAGS += -DSIC_BSP_SUPPORT_IPC_DATA_SEND=0

# LPA Master Framework 
ifeq ($(SIC_BSP_APP_SAMPLE_LPA_M), y)
    include $(SIC_BSP_APP_LPA_PATH)/master/rules.mk
endif

# LPA Slave Framework 
ifeq ($(SIC_BSP_APP_SAMPLE_LPA_S), y)
    include $(SIC_BSP_APP_LPA_PATH)/slave/rules.mk
endif

# LPA Master Sample Application
ifeq ($(SIC_BSP_APP_SAMPLE_LPA_MA), y)
    include $(SIC_BSP_APP_LPA_PATH)/master_app/rules.mk
endif

# LPA Slave Sample Application
ifeq ($(SIC_BSP_APP_SAMPLE_LPA_SA), y)
    include $(SIC_BSP_APP_LPA_PATH)/slave_app/rules.mk
endif

# Paths
VPATH += $(SIC_BSP_APP_LPA_PATH)
# Includes
INCLUDES += -I$(SIC_BSP_APP_LPA_PATH)

# Sources
SRCS += frm_lib.c
