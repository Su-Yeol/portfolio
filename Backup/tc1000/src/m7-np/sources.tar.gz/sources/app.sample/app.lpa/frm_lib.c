/*
***************************************************************************************************
*
*   FileName : frm_lib.c
*
*   Copyright (c) Telechips Inc.
*
*   Description : API collection common to master and slave framework
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include <stdlib.h>
#include "FreeRTOS.h"
#include "sal_com.h"
#include "frm_lib.h"

/**************************************************************************************************
*                                          VARIABLES
**************************************************************************************************/
const int8 *PORT_NAME[]={
	" BASE"," NONE"," NONE","  LOG","  SVC"," PROC"," CAN1"," CAN2"," CAN3"," CAN4"," CAN5",
	" CAN6"," CAN7"," CAN8"," CAN9","CAN10","CAN11","CAN12","CAN13","CAN14","CAN15","CAN16",
	" LIN1"," LIN2"," LIN3"," LIN4"," LIN5"," LIN6"," LIN7"," LIN8","  ALL"};

frmVersionInfo_t verInfo = {0, 0, 3};

/**************************************************************************************************
*                                         FUNCTIONS
**************************************************************************************************/
uint32 lpa_swap32(const uint8 *in)
{
	uint32 out = 0U;
	if (in != NULL)
	{
		out  = ((uint32)in[0] << 24);
		out |= ((uint32)in[1] << 16);
		out |= ((uint32)in[2] << 8);
		out |= ((uint32)in[3]);
	}

	return out;
}

void build_CANHeader(uint8 *header_buffer, uint8 Timestamp_onoff, uint32 uCAN_ID, uint8 uFDF, uint8 uIDE, uint8 uBRS)
{
    uint64 can_header_frame = 0u;

    if(uIDE == 1U) // Extended ID
    {
        if(uFDF == 1U) // CAN FD
        {
            can_header_frame = TIMESTAMP(Timestamp_onoff) + PROTOCOL(0U) + CANEXTID(uCAN_ID) + FDF(1U) + RTR(0U) + IDE(1U) + BRS(uBRS);
        }
        else // classic CAN
        {
            can_header_frame = TIMESTAMP(Timestamp_onoff) + PROTOCOL(0U) + CANEXTID(uCAN_ID) + FDF(0U) + RTR(0U) + IDE(1U) + BRS(0U);
        }
    }
    else // Standard ID
    {
        if(uFDF == 1U) // CAN FD
        {
            can_header_frame = TIMESTAMP(Timestamp_onoff) + PROTOCOL(0U) + CANID(uCAN_ID) + FDF(1U) + RTR(0U) + IDE(0U) + BRS(uBRS);
        }
        else // classic CAN
        {
            can_header_frame = TIMESTAMP(Timestamp_onoff) + PROTOCOL(0U) + CANID(uCAN_ID) + FDF(0U) + RTR(0U) + IDE(0U) + BRS(0U);
        }
    }

    header_buffer[0] = (uint8)((can_header_frame&0x00000000FFULL));
    header_buffer[1] = (uint8)((can_header_frame&0x000000FF00ULL)>>8U);
    header_buffer[2] = (uint8)((can_header_frame&0x0000FF0000ULL)>>16U);
    header_buffer[3] = (uint8)((can_header_frame&0x00FF000000ULL)>>24U);
    header_buffer[4] = (uint8)((can_header_frame&0xFF00000000ULL)>>32U);

}

void build_LINHeader(uint8 *header_buffer, uint8 Timestamp_onoff, uint8 uOper, uint8 uchsum, uint8 ulen, uint8 uId)
{
	uint64 lin_header_frame;

	lin_header_frame = TIMESTAMP(Timestamp_onoff) + PROTOCOL(1U) + LINID(uId) + LINLENGTH(ulen) + LINCHECKSUM(uchsum) + LINOPER(uOper) + FDF(0U) + RTR(0U) + IDE(0U) + BRS(0U);

	header_buffer[0] = (uint8)((lin_header_frame&0x00000000FFULL));
	header_buffer[1] = (uint8)((lin_header_frame&0x000000FF00ULL)>>8U);
	header_buffer[2] = (uint8)((lin_header_frame&0x0000FF0000ULL)>>16U);
	header_buffer[3] = (uint8)((lin_header_frame&0x00FF000000ULL)>>24U);
	header_buffer[4] = (uint8)((lin_header_frame&0xFF00000000ULL)>>32U);
}


