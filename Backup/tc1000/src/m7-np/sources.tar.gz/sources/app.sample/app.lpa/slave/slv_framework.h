/*
***************************************************************************************************
*
*   FileName : slv_framework.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SLV_FRAMEWORK_H
#define SLV_FRAMEWORK_H

#include <stdlib.h>
#include <app_cfg.h>
#include "FreeRTOS.h"
#include "task.h"
#include "debug.h"
#include "sal_com.h"
//#include "lpa_drv.h"
//#include "lpa_std.h"
#include "frm_lib.h"
#include "ipc.h"
#include "lpa_framework.h"

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/

#define LPA_RESET       1
#define LPA_INITIAL     2
#define LIN_AUTORX      0
#define LIN_CHECKSUM    1

typedef enum {
    IPC_STAT_BASE = 0,
    IPC_STAT_VAL,
    IPC_STAT_CNT
}IPC_STAT_TYPE;

typedef void (*LpaRegCallback)(const LPA_REG_DATA *reg_data);
typedef void (*LpaDataCallback)(const RX_DATA_FRAME *rx_data);
typedef void (*LpaTsCallback)(const RX_TS_FRAME *rx_ts);
typedef void (*LpaStatusCallback)(const RX_STATUS_FRAME *rx_status);

/******** Ctrl Task message command ******/
#define SHOW_PORT_STAT  (1U)
/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/


void  LPA_SF_ctrl_CreateAppTask(void);
void LPA_SF_CreateAppTask(void);
void LPA_SF_CTRL_CLI(uint8 ucArgc, void* const pArgv[]);
void LPA_SF_CLI(uint8 ucArgc, void* const pArgv[]);

#endif /* SLV_FRAMEWORK_H */
