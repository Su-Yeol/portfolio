/*
***************************************************************************************************
*
*   FileName : ccf_control.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/**************************************************************************************************
*                                           INCLUDE FILES
**************************************************************************************************/

#include "ccf_control.h"

/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/
static uint32 inverse_16(uint32 in);
static uint32 inverse_32(uint32 in);
static uint32 real_normal_ID(uint64 value);
static uint32 real_ext_ID(uint64 value);

/*Event other_declaration:	Another declaration for "frm_find_channel_type".*/
//uint32 frm_find_channel_type(uint64 in[][DATA_SIZE], uint8 ch);
//void frm_CAN_speed_config(uint64 in[][DATA_SIZE], uint8 can_ch, uint8 can_spd, uint8 canFd_spd);
//void frm_LIN_speed_config(uint64 in[][DATA_SIZE], uint8 lin_ch, uint8 lin_spd);
//void frm_CAN_type_config(uint64 in[][DATA_SIZE], uint8 ch, uint8 type);
//void frm_LIN_checksum_config(uint64 in[][DATA_SIZE], uint8 ch, uint8 op, uint8 val);
//void frm_add_routing_port(uint64 in[][DATA_SIZE], uint8 ch, uint8 is_ext, uint32 routing_id, uint8 add_ch);
//void frm_delete_routing_table(uint64 in[][DATA_SIZE], uint8 ch, uint8 is_ext, uint8 delete_id);
//void frm_add_translate_id(uint64 in[][DATA_SIZE], uint8 ch, uint8 src_ch, uint8 src_ext, uint32 src_id, uint8 dst_ext, uint32 dst_id);

/**************************************************************************************************
*                                             FUNCTIONS
**************************************************************************************************/
static uint32 inverse_16(uint32 in)
{
    uint32 out = 0u;
/*misra_c_2012_rule_10_4_violation:	Essential type of the left hand operand "in" (unsigned) is not the same as that of the right operand "0"(signed).*/
    if(in != 0u)
    {
        out |= ((in) & 0xff00u) >> 8u;
        out |= ((in) & 0xffu) << 8u;
    }
    return out;
}

static uint32 inverse_32(uint32 in)
{
    uint32 out = 0u;

    if(in != 0u)
    {
    /*misra_c_2012_rule_7_2_violation:	Numeric literal "4294901760U" is unsigned but does not use a "u" or "U" suffix.*/
        out = ((in) & 0xff000000u) >> 24u;
        out |= (((in) & 0xff0000u) >> 16u) << 8u;
        out |= (((in) & 0xff00u)>>8u) << 16u;
        out |= ((in) & 0xffu) << 24u;
    }
    return out;
}

static uint32 real_ext_ID(uint64 value)
{
	uint32 id;
	/*misra_c_2012_rule_7_2_violation:	Numeric literal "4294901760U" is unsigned but does not use a "u" or "U" suffix.*/
	id = (uint32)((value & 0xffffffff00000000u) >> 32u);
	//mcu_printf("Masking id : 0x%llx\n", id);
	id = inverse_32(id);
	//mcu_printf("inverse id : 0x%llx\n", id);
	id = id & 0x1fffffffu;

	//mcu_printf("real id : 0x%llx\n", id);

	return id;
}

static uint32 real_normal_ID(uint64 value)
{
	uint32 id;
	/*misra_c_2012_rule_7_2_violation:	Numeric literal "4294901760U" is unsigned but does not use a "u" or "U" suffix.*/
	id = (uint32)((value & 0xffff00000000u) >> 32u);
	//mcu_printf("Masking id : 0x%llx\n", id);
	id = inverse_16(id);
	//mcu_printf("inverse id : 0x%llx\n", id);
	id = (id & 0x1ffcu) >> 2u;

	//mcu_printf("real id : 0x%llx\n", id);

	return id;
}



uint32 frm_find_channel_type(uint64 in[][DATA_SIZE], uint8 ch)
{
    uint8 real_ch = 0u;
    uint32 address;
    uint32 type_addr;
    uint32 type_addr_inverse;
    /*misra_c_2012_rule_9_1_violation Declaring variable "is_fd" without initializer*/
    uint32 is_fd = FALSE;

    if(ch > 16u)
    {
        mcu_printf("CAN channel number range over (only 1 ~16) \n");
    }
    else
    {
        real_ch = ch + 2u;
        for(uint32 i = 0u; i < DATA_SIZE; i++)
        {
        /*misra_c_2012_rule_7_2_violation:	Numeric literal "4294901760U" is unsigned but does not use a "u" or "U" suffix.*/
            address = (uint32)(in[real_ch][i] & 0x00000000ffffu);

            if(address == TYPE_ADDR)
            {
                type_addr = (in[real_ch][i] & 0xffff000000000000u) >> 48u;
                type_addr_inverse = inverse_16(type_addr);
                is_fd = (type_addr_inverse & (1u << (ch - 1u))) >> (ch - 1u);
            }
        }
    }
    return is_fd;
}

void frm_CAN_speed_config(uint64 in[][DATA_SIZE], uint8 can_ch, uint8 can_spd, uint8 canFd_spd)
{
	uint8 real_ch = 0u;
	uint8 i;
	uint32 address;
	uint64 spd;
	uint64 fd_spd;
    uint32 is_fd;

	if(can_ch >16u)
	{
		mcu_printf("CAN channel number range over (only 1 ~16) \n");
	}
	else
	{
		real_ch = can_ch + 2u;

		if(can_spd > 4u)
		{
			mcu_printf("CAN speed number range over (only 0 ~ 4)\n");
		}
		else
		{
			for(i=0u; i < DATA_SIZE; i++)
			{
			/*misra_c_2012_rule_7_2_violation:	Numeric literal "4294901760U" is unsigned but does not use a "u" or "U" suffix.*/
				address = (uint32)(in[real_ch][i] & 0x00000000ffffu);

				if(address == CLOCK_ADDR)
				{
					//mcu_printf("[%d] array num : %d, before value : 0x%llx\n", __LINE__, i, in[real_ch][i]);

					spd = (uint64)(can_spd) << 56u;
					in[real_ch][i] = in[real_ch][i] & 0x00ffffffffffffffu; // value reset
					in[real_ch][i] = in[real_ch][i] | spd;
                    is_fd = frm_find_channel_type(in, can_ch);
					/*misra_c_2012_rule_14_4_violation:	The condition expression "is_fd" does not have an essentially boolean type.*/
                    if(is_fd != 0u)
                    {
                        fd_spd = (uint64)(canFd_spd) << 60u;
                        in[real_ch][i] = in[real_ch][i] | fd_spd;
                    }

                    mcu_printf("Successful change of CAN clock\n");
					//mcu_printf("[%d]array num : %d, after value : 0x%llx\n", __LINE__, i, in[real_ch][i]);
				}
			}
		}
	}
}

void frm_LIN_speed_config(uint64 in[][DATA_SIZE], uint8 lin_ch, uint8 lin_spd)
{
	uint8 real_ch = 0u;
	uint8 i;
	uint32 address;
	uint64 spd;

	if(lin_ch > 8u)
	{
		mcu_printf("LIN channel number range over (only 1 ~ 8) \n");
	}
	else
	{
		real_ch = lin_ch + COMSET_OFFSET + CAN_OFFSET;

		if(lin_spd > 4U)
		{
			mcu_printf("LIN speed number range over (only 0 ~ 4)\n");
		}
		else
		{
			for(i=0u; i < DATA_SIZE; i++)
			{
			/*misra_c_2012_rule_7_2_violation:	Numeric literal "4294901760U" is unsigned but does not use a "u" or "U" suffix.*/
				address = (uint32)(in[real_ch][i] & 0x00000000ffffu);

				if(address == CLOCK_ADDR)
				{
					//mcu_printf("[%d] array num : %d, before value : 0x%llx\n", __LINE__, i, in[real_ch][i]);

					spd = (uint64)(lin_spd) << 56u;
					in[real_ch][i] = in[real_ch][i] & 0x00ffffffffffffffu; // value reset
					in[real_ch][i] = in[real_ch][i] | spd;
                    //is_fd = frm_find_channel_type(in, can_ch);

					//mcu_printf("[%d]array num : %d, after value : 0x%llx\n", __LINE__, i, in[real_ch][i]);
                    mcu_printf("Successful change of LIN clock\n");
				}
			}
		}
	}
}

void frm_CAN_type_config(uint64 in[][DATA_SIZE], uint8 ch, uint8 type)
{
    uint8 cetrac_ch = 0u;
    uint8 i;
	uint32 address;

    if(ch > 16U)
    /*misra_c_2012_rule_15_6_violation:	The body of the "then" branch of the "if" statement is not a compound statement.*/
    {
		mcu_printf("CAN channel number range over (only 1 ~16) \n");
	}
    else
    {
        cetrac_ch = ch + COMSET_OFFSET;

        if(type > 1U)
        /*misra_c_2012_rule_15_6_violation:	The body of the "then" branch of the "if" statement is not a compound statement.*/
        {
            mcu_printf("CAN Type range over (only 0, 1)\n");
        }
        else
        {
            for(i = 0U; i < DATA_SIZE; i++)
            {
            /*misra_c_2012_rule_7_2_violation:	Numeric literal "4294901760U" is unsigned but does not use a "u" or "U" suffix.*/
                address = (uint32)(in[cetrac_ch][i] & 0x00000000ffffu);

                if(address == TYPE_ADDR)
                {
                    //printf("[%d]array num : %d, before value : 0x%llx\n", __LINE__, i, in[cetrac_ch][i]);
					/*misra_c_2012_rule_14_4_violation:	The condition expression "type" does not have an essentially boolean type.*/
                    if(type != 0u)
                    {
                        if(ch < 9u)
                        {
                            in[cetrac_ch][i] |= (uint64)type << (55u + ch);
                        }
                        else if (ch >= 9u && ch < 17u)
                        {
                            in[cetrac_ch][i] |= (uint64)type << (47u + ch - 8u);
                        }
                        /*misra_c_2012_rule_15_7_violation:	No non-empty terminating "else" statement.*/
                        else{
                        /*nop*/
                        }
                    }
                    else
                    {
                        if(ch < 9u)
                        {
                            in[cetrac_ch][i] &= ~((uint64) 0x1u << (55u + ch));
                        }
                        else if (ch >= 9u && ch < 17u)
                        {
                            in[cetrac_ch][i] &= ~((uint64) 0x1u << (47u +  ch - 8u));
                        }
                        /*misra_c_2012_rule_15_7_violation:	No non-empty terminating "else" statement.*/
                        else{
                        /*nop*/
                        }
                    }

                    for(uint8 j = 3u; j < 19u; j++)
                    /*misra_c_2012_rule_15_6_violation:	The body of the "for" loop is not a compound statement.*/
                    {
                        in[j][i] = in[cetrac_ch][i];
                    }

                    mcu_printf("Successful change of CAN type\n");
					//printf("[%d] array num : %d, after value : 0x%llx\n", __LINE__, i, in[cetrac_ch][i]);
                }
            }
        }
    }
}

void frm_LIN_checksum_config(uint64 in[][DATA_SIZE], uint8 ch, uint8 op, uint8 val)
{
    uint8 cetrac_ch = 0u;
	uint32 address;
    uint64 autoRx = 0u;

    //mcu_printf("op = %d, val = %d\n", op, val);
    if(ch > 8u)
    /* misra_c_2012_rule_15_6_violation:	The body of the "then" branch of the "if" statement is not a compound statement.*/
    {
		mcu_printf("LIN channel number range over (only 1 ~8) \n");
	}
    else
    {
        cetrac_ch = ch + COMSET_OFFSET + CAN_OFFSET;
        if(op > 1u)
        {
            mcu_printf("[%d] invalid option \n", __LINE__);
        }
        else
        {
            for(uint8 i = 0u; i < DATA_SIZE; i++)
            {
            /*misra_c_2012_rule_7_2_violation:	Numeric literal "4294901760U" is unsigned but does not use a "u" or "U" suffix.*/
                address = (uint32)(in[cetrac_ch][i] & 0x00000000ffffu);
                if(address == TYPE_ADDR)
                {
                    //printf("[%d]array num : %d, before value : 0x%llx\n", __LINE__, i, in[cetrac_ch][i]);

                    if( (op == 0u) && (val <= 7u) )
                    {
                        autoRx = (uint64)(val) << 57u;
                        //mcu_printf("[%d] AutoRx = %llx\n", __LINE__, autoRx);
                        in[cetrac_ch][i] = in[cetrac_ch][i] & 0x1ffffffffffffffu;
                        //mcu_printf("[%d] address = %llx\n", __LINE__, in[cetrac_ch][i]);
                        in[cetrac_ch][i] |= autoRx;

                        mcu_printf("Successful change of LIN autorx\n");
                    }
                    else if ( (op == 1u) && (val <= 1u) )
                    {
                        if(val)
                        /*misra_c_2012_rule_15_6_violation:	The body of the "else" branch of the "if" statement is not a compound statement.*/
						{
                            in[cetrac_ch][i] |= (uint64)val << 56u;
                        }
                        else
                        {
                            in[cetrac_ch][i] &= ~((uint64)!val << 56u);
                        }

                        mcu_printf("Successful change of LIN checksum\n");
                    }
                    else
                    /*misra_c_2012_rule_15_6_violation:	The body of the "else" branch of the "if" statement is not a compound statement.*/
					{
                        mcu_printf("value ERROR!! try again.\n");
                    }

                    //mcu_printf("[%d]array num : %d, after value : 0x%llx\n", __LINE__, i, in[cetrac_ch][i]);
                }
            }
        }
    }
}

void frm_add_routing_port(uint64 in[][DATA_SIZE], uint8 ch, uint8 is_ext, uint32 routing_id, uint8 add_ch)
{
    uint8 real_ch = 0u;
    uint8 i;
    uint32 address = 0u;
    uint32 real_id;
    uint8 rout_id_flag =0u;
	uint8 rout_tbl_flag =0u;
    uint32 match_address;
    uint32 port_address;
    uint32 port_value;
	uint8 tbl_Cnt = 0u;
	uint8 tbl_array;
	uint64 cnt_value;
    uint32 h_byte;
    uint32 l_byte;
    uint32 new_id;
    uint32 cetrac_id;

    if(ch > 24u)
    {
        mcu_printf("channel number range over (only 1 ~ 24 : CAN 1 ~ 16, LIN 17(1) ~ 24(8)) \n");
    }
    else
    {
        real_ch = ch + 2u;

        for(i = 0u; i < DATA_SIZE; i++)
        {
            address = (uint32)(in[real_ch][i] & 0x00ffu);

            //if(address & ROUT_ADDR) // 0x002x
            if((address & ROUT_ADDR) == 0x20u) // 0x002x
            {
                rout_tbl_flag = 1u;

				/*misra_c_2012_rule_7_2_violation:	Numeric literal "4294901760U" is unsigned but does not use a "u" or "U" suffix.*/
				/*misra_c_2012_rule_14_4_violation:	The condition expression "in[real_ch][i] & 0x2000000000ULL" does not have an essentially boolean type.*/
                if((in[real_ch][i] & 0x2000000000u) != 0x0u) // extend flag (If it doesnt working -> 0x2000000)
                {
                    real_id = real_ext_ID(in[real_ch][i]);

                    match_address = (uint32)((in[real_ch][i]) & 0xffffu);

                    if(real_id == routing_id)
                    {
                        rout_id_flag = 1u;
                        //mcu_printf("matching address : 0x%x\n", match_address);
                        port_address = match_address + 0x20u;
                    }
                }
                else
                {
                    real_id = real_normal_ID(in[real_ch][i]);

                    match_address = (uint32)((in[real_ch][i]) & 0xffffu);

                    if(real_id == routing_id)
                    {
                        rout_id_flag = 1u;
                        //mcu_printf("matching address : 0x%x\n", match_address);
                        port_address = match_address + 0x20u;
                        //mcu_printf("Port address : 0x%x\n", port_address);
                    }
                }
				tbl_Cnt ++; // routing table address count
				tbl_array = i;
            }
        }
        //mcu_printf("routing table count : %d, array : %d \n", tbl_Cnt, tbl_array);

        if(rout_tbl_flag == 1u)
        {
			if(rout_id_flag == 1u)
            {
            /*misra_c_2012_rule_2_2_violation:	Assigning value "0UL" to "address" here, but that stored value is overwritten before it can be used*/
                //address = 0;

                for(i = 0u; i < DATA_SIZE; i++)
                {
                    address = (uint32)(in[real_ch][i] & 0xffffu);

                    if(address == port_address)
                    {
                        //mcu_printf("port address array : %d\n", i);
						/*misra_c_2012_rule_7_2_violation:	Numeric literal "4294901760U" is unsigned but does not use a "u" or "U" suffix.*/
                        port_value = (uint32)((in[real_ch][i] & 0xffffffff00000000u) >> 32u);
                        //mcu_printf("port value : 0x%x\n", port_value);

                        port_value = inverse_32(port_value);

                        //mcu_printf("inverse port value : 0x%x\n", port_value);

                        port_value = port_value | ((uint32)(0x1u) << (add_ch + 5u));

                        //mcu_printf("add port value : 0x%x\n", port_value);

                        port_value = inverse_32(port_value);

                        //mcu_printf("inverse add port value : 0x%x\n", port_value);

                        in[real_ch][i] = in[real_ch][i] | (uint64)(port_value) << 32u;

                        //mcu_printf("last value : 0x%llx\n", in[real_ch][i]);
                    }
                }
            }
            else
            {
                /** table count address array shift **/
				address = (uint32)(in[real_ch][tbl_array + 1u] & 0xffffu);  // table count address
				//cnt_value = in[real_ch][tbl_array+1]&0xff000000;
				cnt_value = (((in[real_ch][tbl_array + 1u] & 0xff000000u) >> 24u) + 1u) << 24u;
				cnt_value = cnt_value | address; // table count + address merge

				//mcu_printf("count value 0x%llx\n", cnt_value);

				in[real_ch][tbl_array + 3u] = cnt_value; // table count address 2 shift

				/* routing talbe shift */
				for(i = 0u; i < tbl_Cnt; i++)
				{
					//mcu_printf("routing tbl before value 0x%llx\n", in[real_ch][tbl_array - i + 1]);
					in[real_ch][tbl_array-i+1u] = in[real_ch][tbl_array-i];
					//mcu_printf("routing tbl after value 0x%llx\n", in[real_ch][tbl_array - i + 1]);
				}

                /* add ID */
                if(!is_ext)
                {
                    routing_id = routing_id << 2u;
                    h_byte = (routing_id & 0xff00u) >> 8u;
                    //printf("[%d] h_byte = 0x%llx\n", __LINE__, h_byte);
                    l_byte = routing_id & 0xffu;
                    //printf("[%d] l_byte = 0x%llx\n", __LINE__, l_byte);
                    //l_byte = l_byte << 2;
                    //printf("[%d] l_byte = 0x%llx\n", __LINE__, l_byte);

                    new_id = (l_byte << 8) | h_byte;
                }
                else
                {
                    new_id = inverse_32(routing_id);
                    //printf("[%d] new_id = 0x%llx\n", __LINE__, new_id);

                    //new_id = (2 << 32);
                }
                //new_id = 0x1C00;
                //printf("[%d] new_id = 0x%llx\n", __LINE__, new_id);
                address = (tbl_Cnt << 8u) | 0x20u;
                //printf("[%d] address = 0x%llx\n", __LINE__, address);
                in[real_ch][tbl_array + 2u] = ((uint64)new_id << 32u) | address;
                if(is_ext)
                {
                    in[real_ch][tbl_array + 2u] |= 0x2000000000u;
                }
                //mcu_printf("[%d] address = 0x%llx\n", __LINE__, in[real_ch][tbl_array + 2]);

                /* add PORT */
                /*cert_arr30_c_violation:	"in[real_ch][tbl_array - tbl_Cnt]" evaluates to an address that could be at negative offset of an arra*/
                if(tbl_array >= tbl_Cnt)
                {
					tbl_array = tbl_array - tbl_Cnt;
                }
                else
                {
					tbl_array = 0u;
                }
				/*misra_c_2012_rule_7_2_violation:	Numeric literal "4294901760U" is unsigned but does not use a "u" or "U" suffix.*/
                port_value = (uint32)((in[real_ch][tbl_array] & 0xffffffff00000000u) >> 32u);
                port_value = ((uint32)(0x1u) << (add_ch + 5u));

                port_value = inverse_32(port_value);
                //printf("inverse add port value : 0x%x\n", port_value);

                cetrac_id = ((uint32)(in[real_ch][tbl_array] & 0xffff0000u) >> 16u);
                cetrac_id = inverse_16(cetrac_id) + 1u;
                cetrac_id = inverse_16(cetrac_id);
                //printf("[%d] cetrac_id = 0x%llx, tbl_array = %d, tbl_Cnt = %d\n", __LINE__, cetrac_id, tbl_array, tbl_Cnt);

                address = address + 0x20u;
                //mcu_printf("[%d] address = 0x%llx\n", __LINE__, address);

                in[real_ch][tbl_array + 1u] = ((uint64)port_value << 32u) | (cetrac_id << 16u) | address;
                //mcu_printf("[%d] address = 0x%llx\n", __LINE__, in[real_ch][tbl_array - tbl_Cnt + 1]);
                //in[real_ch][tbl_array - tbl_Cnt + 1] = in[real_ch][i] | (uint64)(port_value) << 32;

            }
        }
        else
		{
			mcu_printf("route table nothing/n");
		}
    }
}
/*misra_c_2012_rule_2_7_violation:	The parameter "is_ext" is not used in the function.*/
//void frm_delete_routing_table(uint64 in[][DATA_SIZE], uint8 ch, uint8 is_ext, uint32 delete_id)
void frm_delete_routing_table(uint64 in[][DATA_SIZE], uint8 ch, uint32 delete_id)
{
    uint8 real_ch = 0u;
    uint8 i;
    uint32 address;
    uint32 real_id;
	uint8 tbl_Cnt = 0u;
    uint8 tbl_end = 0u;
    /*misra_c_2012_rule_9_1_violation Declaring variable "tbl_array" without initializer*/
	uint8 tbl_array = 0u;
	uint8 rout_tbl_flag =0u;
    uint8 rout_id_flag =0u;
    uint8 del_index;

    if(ch > 24u)
    {
        mcu_printf("channel number range over (only 1 ~ 24 : CAN 1 ~ 16, LIN 17(1) ~ 24(8)) \n");
    }
    else
    {
        real_ch = ch + 2u;

        for(i = 0u; i < DATA_SIZE; i++)
        {
            address = (uint32)(in[real_ch][i] & 0x00ffu);

            if((address & ROUT_ADDR) == 0x20u)
            {
                tbl_end = i;
                rout_tbl_flag = 1u;
                real_id = real_normal_ID(in[real_ch][i]);
                if(real_id == delete_id)
                {
                    tbl_array = i;
                    rout_id_flag = 1u;
               	}
                tbl_Cnt++;
            }
        }

        del_index = tbl_array - tbl_Cnt;
        if(rout_tbl_flag == 1u)
        {
            if(rout_id_flag == 1u)
            {
                for(i = 0u; i < tbl_Cnt; i++)
                {
                    //mcu_printf("[%d] array : %d port table before value 0x%llX\n", __LINE__, del_index + i, in[real_ch][del_index + i]);
                    in[real_ch][del_index + i] = in[real_ch][del_index + i + 1u];
                    in[real_ch][del_index + i] = in[real_ch][del_index + i] - 0x0100u;
                    //mcu_printf("[%d] array : %d port table after value 0x%llX\n\n", __LINE__, del_index + i, in[real_ch][del_index + i]);
                }
                for(i = tbl_array - 1; i < tbl_end; i++)
                {
                    //mcu_printf("{%d} array : %d port table before value 0x%llX\n", __LINE__, i, in[real_ch][i]);
                    in[real_ch][i] = in[real_ch][i + 2u];
                    /*misra_c_2012_rule_15_6_violation:	The body of the "else" branch of the "if" statement is not a compound statement.*/
                    if((in[real_ch][i]&0xffffu) != LAST_ADDR)
                    {
                        in[real_ch][i] = in[real_ch][i] - 0x0100u;
					}
                    else
                    {
                        in[real_ch][i] = in[real_ch][i] - 0x1000000u;
					}
                    //mcu_printf("{%d} array : %d port table after value 0x%llX\n\n", __LINE__, i, in[real_ch][i]);
                }
            }
        }
    }
}

void frm_add_translate_id(uint64 in[][DATA_SIZE], uint8 ch, uint8 src_ch, uint8 src_ext, uint32 src_id, uint8 dst_ext, uint32 dst_id)
{
    uint8 real_ch = 0u;
    uint8 i;
    uint32 address;
    uint8 tableCnt = 0u;
    uint8 faketblCnt = 0u;
    uint8 tbl_array;
    uint32 portNum;
    uint64 portNumData;
    /*misra_c_2012_rule_9_1_violation:	Using uninitialized value "srcIdData" "dstIdData".*/
    uint64 srcIdData = 0u;
    uint64 dstIdData = 0u;
    uint8 SrcArray;
    uint8 DstArray;
    uint8 translateFlg = 0u;


    if(ch >24u)
    {
        mcu_printf("channel number range over (only 1 ~ 24 : CAN 1 ~ 16, LIN 17(1) ~ 24(8)) \n");
    }
    else
    {

        real_ch = ch + 2u;

        for(i=0u; i < DATA_SIZE; i++)
        {
            address = (uint32)(in[real_ch][i]&0x00ffu);

            if(address == TRANSLATE_ADDR) // 0xxx78
            {
                translateFlg = 1u;
                tableCnt ++;
                /*misra_c_2012_rule_7_2_violation:	Numeric literal "4294901760U" is unsigned but does not use a "u" or "U" suffix.*/
				/*misra_c_2012_rule_14_4_violation:	The condition expression "in[real_ch][i] & 0x4000000000ULL" does not have an essentially boolean type.*/
                if((in[real_ch][i]&0x4000000000u) != 0u) //fake table
                {
                    faketblCnt ++;
                }
                tbl_array = i;
            }
        }

        //printf("translate table : %d, fake table : %d, table_array: %d\n", tableCnt, faketblCnt, tbl_array);

        portNum = (src_ch + 6u) << 7u;
        portNum = inverse_16(portNum);
        portNumData = (uint64)(portNum) << 24u;

        //printf("portNum : 0x%llx\n",  (uint64)portNumData);

        if(translateFlg == 1u)
        {
            if(src_ext == 1u)
            {
                if(src_id > 0x1fffffffu)
                {
                    mcu_printf("ID Range over\n");
                }
                else
                {
                    src_id = inverse_32(src_id);
                    srcIdData = (uint64)src_id << 32u;
                    srcIdData = srcIdData | 0x2000000000u;
                    //printf("Source ID : 0x%llx\n",  (uint64)srcIdData);
                }
            }
            else
            {
                if(src_id > 0x7ffu)
                {
                    mcu_printf("ID Range over\n");
                }
                else
                {
                    src_id = src_id << 18u;
                    src_id = inverse_32(src_id);
                    srcIdData = (uint64)src_id << 32u;
                    //printf("Source ID : 0x%llx\n",  (uint64)srcIdData);
                }
            }
            /*** make Source tranlate data ***/
            address = (tableCnt - faketblCnt)<<8u | 0x78u;
            SrcArray = tbl_array - faketblCnt + 1u; // last table - fake array -
            in[real_ch][SrcArray] = srcIdData | portNumData | address;
            //printf("source translate data : 0x%llx, array : %d \n", in[real_ch][SrcArray], SrcArray);

            if(dst_ext == 1u)
            {
                if(dst_id > 0x1fffffffu)
                {
                    mcu_printf("ID Range over\n");
                }
                else
                {
                    dst_id = inverse_32(dst_id);
                    dstIdData = (uint64)dst_id << 32u;
                    dstIdData = dstIdData | 0x2000000000u;
                    //printf("Destination ID : 0x%llx\n",  (uint64)dstIdData);
                }
            }
            else
            {
                if(dst_id > 0x7ffu)
                {
                    mcu_printf("ID Range over\n");
                }
                else
                {
                    dst_id = dst_id << 18u;
                    dst_id = inverse_32(dst_id);
                    dstIdData = (uint64)dst_id << 32u;
                    //printf("Destination ID : 0x%llx\n",  (uint64)dstIdData);
                }
            }

            /*** make Destination tranlate data ***/
            address = (tableCnt - faketblCnt)<<8u | 0x7au;
            DstArray = SrcArray + tableCnt; // src table + table value
            in[real_ch][DstArray] = dstIdData | address;
            //printf("Destination translate data : 0x%llx, array : %d \n", in[real_ch][DstArray], DstArray);
        }
        else
        {
            mcu_printf("nothing translate table channel\n");

        }
    }
}
