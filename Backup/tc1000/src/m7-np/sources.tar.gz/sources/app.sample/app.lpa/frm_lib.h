/*
***************************************************************************************************
*
*   FileName : frm_lib.h
*
*   Copyright (c) Telechips Inc.
*
*   Description : API collection common to master and slave framework
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef FRM_LIB_H
#define FRM_LIB_H

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/

#define MM_RESPONSE_TYPE	(0xddddddddddddddddUL)

/* protocol */
#define PROTOCOL_CAN		(0U)
#define PROTOCOL_LIN		(1U)

#define LIN_RX_OPERATON			(0U)
#define LIN_TX_OPERATON			(1U)


/***************** Host frame macro *******************/
#define TIMESTAMP(x) 			(((x)&0x1ULL))
#define PROTOCOL(x)		 		(((x)&0x1ULL)<<6UL)
#define CANEXTID(x)				(((x)&0x1FFFFFFFULL)<<7UL)
#define CANID(x)				(((x)&0x7FFULL)<<7UL)
#define LINOPER(x)		 		(((x)&0x1ULL)<<18UL)
#define LINCHECKSUM(x)	 		(((x)&0x1ULL)<<17UL)
#define LINLENGTH(x)	 		(((x)&0xFULL)<<13UL)
#define LINID(x)		 		(((x)&0x3FULL)<<7UL)
#define FDF(x)		 			(((x)&0x1ULL)<<36UL)
#define RTR(x)		 			(((x)&0x1ULL)<<37UL)
#define IDE(x)		 			(((x)&0x1ULL)<<38UL)
#define BRS(x)		 			(((x)&0x1ULL)<<39UL)

#define	MCAL_TX_CONFIRM_SUPPORT				(1U)
#define	LPA_TX_HDR_SIZE			(5U)
#define LPA_TX_MAX_DATA_SIZE	(64U)
#define LPA_TX_MAX_FRAME_SIZE	(LPA_TX_HDR_SIZE + LPA_TX_MAX_DATA_SIZE)

/*********** TX message queue ***********/
#define	LPA_TX_MSG_BUFFER_SIZE		(LPA_TX_MAX_FRAME_SIZE)
typedef struct LPA_TX_MESSAGE {
#if (MCAL_TX_CONFIRM_SUPPORT == 1)
	uint8 request_core;
	uint8 proto;
	uint8 port;
#endif
	uint16 MsgID;
	uint16 idt;
	uint16 size;
	uint8 MsgData[LPA_TX_MSG_BUFFER_SIZE+1U];
}LPA_TX_MESSAGE;

typedef struct frmVersionInfo
{
    uint8 majorVer;
    uint8 minorVer;
    uint8 patchVer;
}frmVersionInfo_t;

/*********** TX message queue ***********/
#define	LPA_TX_MSG_QUEUE_NUM		(64U)
typedef struct MM_RESPONSE_DATA {
	uint16 RD_ADDR0;
	uint16 dummy0;
	uint8 data0[4];
	uint16 RD_ADDR1;
	uint16 dummy1;
	uint8 data1[4];
	uint16 RD_ADDR2;
	uint16 dummy2;
	uint8 data2[4];
	uint16 RD_ADDR3;
	uint16 dummy3;
	uint8 data3[4];
}MM_RESPONSE_DATA;

typedef struct MM_RESPONSE {
    uint64 reserved1[7];
    uint64 type;
    MM_RESPONSE_DATA data;
    uint64 reserved5[3];
    uint32 reserved6;
    uint32 crc32;
}MM_RESPONSE; /* size: 128 byte */



extern frmVersionInfo_t verInfo;

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/

uint32 lpa_swap32(const uint8 *in);
void build_CANHeader(uint8 *header_buffer, uint8 Timestamp_onoff, uint32 uCAN_ID, uint8 uFDF, uint8 uIDE, uint8 uBRS);
void build_LINHeader(uint8 *header_buffer, uint8 Timestamp_onoff, uint8 uOper, uint8 uchsum, uint8 ulen, uint8 uId);

#endif /* FRM_LIB_H */
