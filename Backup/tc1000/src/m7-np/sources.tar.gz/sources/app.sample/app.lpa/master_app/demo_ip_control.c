/*
***************************************************************************************************
*
*   FileName : demo_ip_control.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/**************************************************************************************************
*                                           INCLUDE FILES
**************************************************************************************************/
#include <errno.h>
#include "demo_lpa_log.h"
#include "demo_ip_control.h"
#include "mst_framework.h"

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/


/**************************************************************************************************
*                                          LOCAL VARIABLES
**************************************************************************************************/

/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/

/**************************************************************************************************
*                                             FUNCTIONS
**************************************************************************************************/

static void LPA_Init_CLI_Help(void)
{
	mcu_printf( "=== wrong argument ===\n" );
    mcu_printf( "=== USAGE INFO ===\n\n" );
    mcu_printf( "=== CMD LIST ===\n" );
    mcu_printf( "lpa [CMD] : 'initial' = ccf initial\n");
    mcu_printf( "            'validation' = show lpa validation\n");
    mcu_printf("             'config'= show ccf parsing\n");
    mcu_printf("             'reset'= lpa reset \n" );
#ifdef CCF_CONTROL
    mcu_printf("             'can [PORT] clock [CLOCK] [FD CLOCK]' = can clock\n");
    mcu_printf("             'can [PORT] type [TYPE]' = can type\n");
    mcu_printf("             'lin [PORT] checksum [VAL]' = lin checksum\n");
    mcu_printf("             'lin [PORT] autorx [VAL]' = lin autorx\n");
    mcu_printf("             'd' = add routing table\n");
    mcu_printf("             'e' = delete routing table\n");
#endif
}

void LPA_Init_CLI(uint8 ucArgc, void * const pArgv [ ])
{
    uint8 *pucStr1;
    sint32 ret;
    uint8 i;
#ifdef CCF_CONTROL
    const uint8 * pucStr2;
    const uint8 * pucStr3;
    const uint8 * pucStr4;
    const uint8 * pucStr5;
    uint8 portN;
    uint8 canSpd;
    uint8 canFdSpd;
    uint8 canType;
    uint8 linSpd;
    uint8 op;
    uint8 val;
    uint8 isExt;
    uint32 routingId;
    uint8 dstPortN;
#endif

    pucStr1 = NULL_PTR;
#ifdef CCF_CONTROL
    pucStr2 = NULL_PTR;
    pucStr3 = NULL_PTR;
    pucStr4 = NULL_PTR;
    pucStr5 = NULL_PTR;
	eLPA_MODE_t mode;
#endif

    if( pArgv != NULL_PTR )
    {
        SAL_MemCopy(&pucStr1, &pArgv[0], 4U);
#ifdef CCF_CONTROL
#if 0
        SAL_MemCopy(&pucStr2, &pArgv[1], 1U);
        SAL_MemCopy(&pucStr3, &pArgv[2], 1U);
        SAL_MemCopy(&pucStr4, &pArgv[3], 1U);
        SAL_MemCopy(&pucStr5, &pArgv[4], 1U);
#else
        pucStr2 = ( const uint8 * ) pArgv[ 1 ];
        pucStr3 = ( const uint8 * ) pArgv[ 2 ];
        pucStr4 = ( const uint8 * ) pArgv[ 3 ];
        pucStr5 = ( const uint8 * ) pArgv[ 4 ];
#endif
#endif

#ifdef CCF_CONTROL
        if( (ucArgc >= 1UL) && (ucArgc <= 5UL))
#else
        if( (ucArgc >= 1UL) && (ucArgc <= 3UL))
#endif
        {
            if( pucStr1 != NULL_PTR )
            {
                if( ( SAL_StrNCmp( pucStr1, ( const uint8 * ) "initial", 7, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
                    (void)frm_lpa_write_ccf(Base_Conf[0]);
                }
                else if( ( SAL_StrNCmp( pucStr1, ( const uint8 * ) "validation", 10, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
                    //LPA_Log_TaskNotifyTp();
                    /*misra_c_2012_rule_17_7_violation: The return value of a non-void function "lpa_getMode" is unused.*/
                    (void)lpa_getMode(&mode);
                }
                else if( ( SAL_StrNCmp( pucStr1, ( const uint8 * ) "config", 6, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
                    for(i = 0; i < (uint8)CONFIG_SIZE; i++)
                    {
                        uint8 *ccf = &pCcf[i*DATA_SIZE*8U];
                        frm_parse_ccf(ccf, DATA_SIZE*8U);
                    }
                }
                else if( ( SAL_StrNCmp( pucStr1, ( const uint8 * ) "reset", 5, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
                    LPA_SW_Reset();
                }
#ifdef CCF_CONTROL
                else if( (SAL_StrNCmp( pucStr1, ( const uint8 * ) "can", 3, &ret) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
                	/*cert_exp40_c_violation: Casting pointer "pucStr2" with type "uint8 const *" to type "char *" allows an object defined with a const-qualified type to be modified through use of an lvalue with non-const-qualified type.*/
                    portN = atoi((const char *)pucStr2);
                    if ((portN < 1U) && (portN > 16U))
                    {
                        mcu_printf("CAN channel number range over (only 1 ~16) \n");
                    }
                    else
                    {
                        if( pucStr3 != NULL_PTR )
                        {
                            if( ( SAL_StrNCmp(pucStr3, ( const uint8 * ) "clock", 5, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                            {
								/*cert_exp40_c_violation: Casting pointer "pucStr4" with type "uint8 const *" to type "char *" allows an object defined with a const-qualified type to be modified through use of an lvalue with non-const-qualified type.*/
                                canSpd = atoi((const char *)pucStr4);
                                //mcu_printf("%s_%d port = %d, canSpd = %d\n", __func__, __LINE__, portN, canSpd);
                                if(frm_find_channel_type(Base_Conf, portN))
                                {
                                    mcu_printf("This channel is FD.\n");
                                    /*cert_exp40_c_violation: Casting pointer "pucStr5" with type "uint8 const *" to type "char *" allows an object defined with a const-qualified type to be modified through use of an lvalue with non-const-qualified type.*/
                                    canFdSpd = atoi((const char *)pucStr5);
                                }
                                else
                                {
                                    mcu_printf("This channel is NOT FD.\n");
                                    canFdSpd = -1;
                                }

                                frm_CAN_speed_config(Base_Conf, portN, canSpd, canFdSpd);
                            }
                            else if( ( SAL_StrNCmp(pucStr3, ( const uint8 * ) "type", 4, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                            {
                            	/*cert_exp40_c_violation: Casting pointer "pucStr4" with type "uint8 const *" to type "char *" allows an object defined with a const-qualified type to be modified through use of an lvalue with non-const-qualified type.*/
                                canType = atoi((const char *)pucStr4);

                                frm_CAN_type_config(Base_Conf, portN, canType);
                            }
                            /*misra_c_2012_rule_15_7_violation:	No non-empty terminating "else" statement.*/
                            else{
                            /*nop*/
                            }
                        }
                        else
                        {
                            mcu_printf("Enter the action to perform on the CAN port\n");
                        }
                    }
                }
                else if( (SAL_StrNCmp( pucStr1, ( const uint8 * ) "lin", 3, &ret) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
                	/*cert_exp40_c_violation: Casting pointer "pucStr2" with type "uint8 const *" to type "char *" allows an object defined with a const-qualified type to be modified through use of an lvalue with non-const-qualified type.*/
                    portN = atoi((const char *)pucStr2);

                    if( pucStr3 != NULL_PTR )
                    {
                        if( ( SAL_StrNCmp( pucStr3, ( const uint8 * ) "clock", 5, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                        {
                        	/*cert_exp40_c_violation: Casting pointer "pucStr4" with type "uint8 const *" to type "char *" allows an object defined with a const-qualified type to be modified through use of an lvalue with non-const-qualified type.*/
                            linSpd = atoi((const char *)pucStr4);
                            frm_LIN_speed_config(Base_Conf, portN, linSpd);
                        }
                        else if( ( SAL_StrNCmp(pucStr3, ( const uint8 * ) "checksum", 8, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                        {
                            op = LIN_CHECKSUM;
                            /*cert_exp40_c_violation: Casting pointer "pucStr4" with type "uint8 const *" to type "char *" allows an object defined with a const-qualified type to be modified through use of an lvalue with non-const-qualified type.*/
                            val = atoi((const char *)pucStr4);

                            frm_LIN_checksum_config(Base_Conf, portN, op, val);
                        }
                        else if( ( SAL_StrNCmp( pucStr3, ( const uint8 * ) "autorx", 6, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                        {
                            op = LIN_AUTO_RX;
                            /*cert_exp40_c_violation: Casting pointer "pucStr4" with type "uint8 const *" to type "char *" allows an object defined with a const-qualified type to be modified through use of an lvalue with non-const-qualified type.*/
                            val = atoi((const char *)pucStr4);

                            frm_LIN_checksum_config(Base_Conf, portN, op, val);
                        }
                        /* misra_c_2012_rule_15_7_violation:	No non-empty terminating "else" statement.*/
                        else{
                        /* nop */
                        }
                    }
                    else
                    {
                        mcu_printf("Enter the action to perform on the LIN port\n");
                    }
                }
                else if( ( SAL_StrNCmp(pucStr1, ( const uint8 * ) "d", 1, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
                	/*cert_exp40_c_violation: Casting pointer "pucStr2" with type "uint8 const *" to type "char *" allows an object defined with a const-qualified type to be modified through use of an lvalue with non-const-qualified type.*/
                    portN = atoi((const char *)pucStr2);
                    isExt = atoi((const char *)pucStr3);
                    routingId = atoi((const char *)pucStr4);
                    dstPortN = atoi((const char *)pucStr5);

                    frm_add_routing_port(Base_Conf, portN, isExt, routingId, dstPortN);
                }
                else if( ( SAL_StrNCmp(pucStr1, ( const uint8 * ) "e", 1, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
                	/*cert_exp40_c_violation: Casting pointer "pucStr2" with type "uint8 const *" to type "char *" allows an object defined with a const-qualified type to be modified through use of an lvalue with non-const-qualified type.*/
                    portN = atoi((const char *)pucStr2);
                    //isExt = atoi((const char *)pucStr3);
                    routingId = atoi((const char *)pucStr4);
                    dstPortN = atoi((const char *)pucStr5);
                    /*misra_c_2012_rule_2_7_violation:	The parameter "is_ext" is not used in the function.*/
                    frm_delete_routing_table(Base_Conf, portN, routingId);
                }
#endif
                else if( ( SAL_StrNCmp(pucStr1, ( const uint8 * ) "status", 6, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
                    if( pucStr2 != NULL_PTR )
                    {
                        if( ( SAL_StrNCmp( pucStr2, ( const uint8 * ) "can", 3, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                        {
                            errno = 0;
                            /*cert_exp40_c_violation: Casting pointer "pucStr3" with type "uint8 const *" to type "char *" allows an object defined with a const-qualified type to be modified through use of an lvalue with non-const-qualified type.*/
                            portN = strtoul((const int8 *)pucStr3, NULL, 10);
                            if (((portN >= 1U) && (portN <= 16U)) && (errno == 0))
                            {
                                errno = 0;
                                mcu_printf("port Number :%d \n", portN);
                                (void)frm_lpa_getCanCnt(portN);
                            }
                        }
                        else if( ( SAL_StrNCmp( pucStr2, ( const uint8 * ) "lin", 3, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                        {
                            errno = 0;
                            /*cert_exp40_c_violation: Casting pointer "pucStr2" with type "uint8 const *" to type "char *" allows an object defined with a const-qualified type to be modified through use of an lvalue with non-const-qualified type.*/
                            portN = strtoul((const int8 *)pucStr3, NULL, 10);

                            if (((portN >= 1U) && (portN <= 8U)) && (errno == 0))
                            {
                                errno = 0;
                                mcu_printf("port Number :%d \n", portN);
                                (void)frm_lpa_getLinCnt(portN);
                            }
                        }
                    }
                }
                /* misra_c_2012_rule_15_7_violation: No non-empty terminating "else" statement.*/
                else{
					/*nop*/
                }
            }
        }
        else
        {
            LPA_Init_CLI_Help();
        }
    }
}

void LPA_SW_Reset(void)
{
	/*
		NOTE:
		This function must be used after creating Log_Task and Rx_Task.
	*/
	uint32 count = 0;
	LPA_Log_TaskNotifyStop();
	while (TRUE) {
		SAL_TaskSleep(1);
		if (LPA_Log_getTaskState() == 0U) {
			break;
		}
		count++;
		//mcu_printf("task state change wait(%d/%d)..%d\n", LPA_Rx_getTaskState(), LPA_Log_getTaskState(), count);
	}

	(void)frm_lpa_reset();
}



