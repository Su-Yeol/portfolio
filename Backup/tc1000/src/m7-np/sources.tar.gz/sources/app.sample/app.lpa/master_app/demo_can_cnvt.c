/*
***************************************************************************************************
*
*   FileName : demo_can_cnvt.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/**************************************************************************************************
*                                           INCLUDE FILES
**************************************************************************************************/

#include "app_cfg.h"
#include "demo_can_cnvt.h"
#include "mst_framework.h"
#include "rt_tbl.h"
#include "route_cfg.h"
#include "bsp.h"
#include <stdlib.h>

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/


/**************************************************************************************************
*                                          LOCAL VARIABLES
**************************************************************************************************/
//static uint8 CanConverter_Task_cnt;
static uint8 expandCycleCount[ROUTING_EXPAND_NUM];
static uint8 send_data[64];
static uint8 isSplit = FALSE;
//uint8 Log_SourcePort;
//uint8 Log_Data[64];
//uint32 Log_ExCAN_ID;
//uint16 log_dataLen = 8;

/*misra_c_2012_rule_8_4_violation : add to static */
static uint8 rx_data[64];
#if (CETRAC_CFG == 1u)
static uint8 chConfig[16] = {CLASSIC, CLASSIC, CLASSIC, CLASSIC, CLASSIC, FD, FD, FD, FD, FD, FD, FD, FD, FD, FD, FD};
#elif (SURESFT_CFG == 1u)
static uint8 chConfig[16] = {CLASSIC, CLASSIC, CLASSIC, CLASSIC, CLASSIC, CLASSIC, CLASSIC, CLASSIC, FD, FD, FD, FD, FD, FD, FD, FD};
#endif

/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/
static void CANCnvt_Uart_list(void);
/* misra_c_2012_rule_5_9_violation:	Identifier "delay" is already used to represent a function with internal linkage*/
//static void delay(uint32 usec);
static void Split_Routing_16(uint8 dst_1ch, uint32 dst_1id, uint8 dst_2ch, uint32 dst_2id);
static void Split_Routing_24(uint8 dst_1ch, uint32 dst_1id, uint8 dst_2ch, uint32 dst_2id, uint8 dst_3ch, uint32 dst_3id);
static void Split_Routing_32(uint8 dst_1ch, uint32 dst_1id, uint8 dst_2ch, uint32 dst_2id, uint8 dst_3ch, uint32 dst_3id, uint8 dst_4ch, uint32 dst_4id);
static void Split_Routing_48(uint8 dst_1ch, uint32 dst_1id, uint8 dst_2ch, uint32 dst_2id, uint8 dst_3ch, uint32 dst_3id,
        uint8 dst_4ch, uint32 dst_4id, uint8 dst_5ch, uint32 dst_5id, uint8 dst_6ch, uint32 dst_6id);
static void Split_Routing_64(uint8 dst_1ch, uint32 dst_1id, uint8 dst_2ch, uint32 dst_2id, uint8 dst_3ch, uint32 dst_3id, uint8 dst_4ch, uint32 dst_4id,
        uint8 dst_5ch, uint32 dst_5id, uint8 dst_6ch, uint32 dst_6id, uint8 dst_7ch, uint32 dst_7id, uint8 dst_8ch, uint32 dst_8id);
static void CANCnvt_Split(uint8 srcPort, uint32 route_id, uint8 len);
//static void CANCnvt_Expand(void);
static void CANCnvt_Task(void *pArg);

/**************************************************************************************************
*                                             FUNCTIONS
**************************************************************************************************/
void CANCnvt_Init(void)
{
    add_CANC_routeTable();
}

static void split_routing(uint8 dst_ch, uint32 dst_id)
{
    uint8 is_ext;
    uint8 fdf;
    uint8 split_area;
    uint32 cnvt_id;

    SAL_MemSet(send_data, 0x0, sizeof(send_data));

    is_ext = (uint8)((dst_id & EXTENDED_ID_OFFSET) >> 31u);

    if(is_ext == 1u)
    {
        cnvt_id = (dst_id ^ EXTENDED_ID_OFFSET);
    }
    else
    {
        cnvt_id = dst_id;
    }

    if(dst_ch >= 1u)
    {
        fdf = chConfig[dst_ch - 1u];
    }
    else
    {
        fdf = 0;
    }

    split_area = (dst_id & 0xf) - 1;

    for(uint8 i = 0u; i < SPLIT_DLC; i++)
    {
        send_data[i] = rx_data[i + (8 * split_area)];
    }

    frm_cnvt_msg_send(dst_ch, fdf, is_ext, dst_id, SPLIT_DLC, send_data);
}

/*misra_c_2012_rule_8_8_violation : missing 'static' */
static void Split_Routing_16(uint8 dst_1ch, uint32 dst_1id, uint8 dst_2ch, uint32 dst_2id)
{
    split_routing(dst_1ch, dst_1id);
    split_routing(dst_2ch, dst_2id);
}

/*misra_c_2012_rule_8_8_violation : missing 'static' */
static void Split_Routing_24(uint8 dst_1ch, uint32 dst_1id, uint8 dst_2ch, uint32 dst_2id, uint8 dst_3ch, uint32 dst_3id)
{
    split_routing(dst_1ch, dst_1id);
    split_routing(dst_2ch, dst_2id);
    split_routing(dst_3ch, dst_3id);
}

/*misra_c_2012_rule_8_8_violation : missing 'static' */
static void Split_Routing_32(uint8 dst_1ch, uint32 dst_1id, uint8 dst_2ch, uint32 dst_2id, uint8 dst_3ch, uint32 dst_3id, uint8 dst_4ch, uint32 dst_4id)
{
    split_routing(dst_1ch, dst_1id);
    split_routing(dst_2ch, dst_2id);
    split_routing(dst_3ch, dst_3id);
    split_routing(dst_4ch, dst_4id);
}

/*misra_c_2012_rule_8_8_violation : missing 'static' */
static void Split_Routing_48(uint8 dst_1ch, uint32 dst_1id, uint8 dst_2ch, uint32 dst_2id, uint8 dst_3ch, uint32 dst_3id,
        uint8 dst_4ch, uint32 dst_4id, uint8 dst_5ch, uint32 dst_5id, uint8 dst_6ch, uint32 dst_6id)
{
    split_routing(dst_1ch, dst_1id);
    split_routing(dst_2ch, dst_2id);
    split_routing(dst_3ch, dst_3id);
    split_routing(dst_4ch, dst_4id);
    split_routing(dst_5ch, dst_5id);
    split_routing(dst_6ch, dst_6id);
}

/*misra_c_2012_rule_8_8_violation : missing 'static' */
static void Split_Routing_64(uint8 dst_1ch, uint32 dst_1id, uint8 dst_2ch, uint32 dst_2id, uint8 dst_3ch, uint32 dst_3id, uint8 dst_4ch, uint32 dst_4id,
        uint8 dst_5ch, uint32 dst_5id, uint8 dst_6ch, uint32 dst_6id, uint8 dst_7ch, uint32 dst_7id, uint8 dst_8ch, uint32 dst_8id)
{
    split_routing(dst_1ch, dst_1id);
    split_routing(dst_2ch, dst_2id);
    split_routing(dst_3ch, dst_3id);
    split_routing(dst_4ch, dst_4id);
    split_routing(dst_5ch, dst_5id);
    split_routing(dst_6ch, dst_6id);
    split_routing(dst_7ch, dst_7id);
    split_routing(dst_8ch, dst_8id);
}

/*misra_c_2012_rule_8_8_violation : missing 'static' */
static void CANCnvt_Split(uint8 srcPort, uint32 route_id, uint8 len)
{
    if((len > 8u) && (len <= 16u))
    {
        for(uint8 i = 0; i < SPLIT16_NUM; i++)
        {
            if((splitTbl_16[i].src_ch == srcPort) && (splitTbl_16[i].src_id == route_id))
            {
                isSplit = (uint8)TRUE;
                Split_Routing_16(splitTbl_16[i].dst_1ch, splitTbl_16[i].dst_1id, splitTbl_16[i].dst_2ch, splitTbl_16[i].dst_2id);
            }
        }
    }
    else if((len > 16u) && (len <= 24u))
    {
        for(uint8 i = 0u; i < SPLIT24_NUM; i++)
        {
            if((splitTbl_24[i].src_ch == srcPort) && (splitTbl_24[i].src_id == route_id))
            {
                isSplit = (uint8)TRUE;
                Split_Routing_24(splitTbl_24[i].dst_1ch, splitTbl_24[i].dst_1id, splitTbl_24[i].dst_2ch, splitTbl_24[i].dst_2id, splitTbl_24[i].dst_3ch, splitTbl_24[i].dst_3id);
            }
        }
    }
    else if((len > 24u) && (len <= 32u))
    {
        for(uint8 i = 0; i < SPLIT32_NUM; i++)
        {
            if((splitTbl_32[i].src_ch == srcPort) && (splitTbl_32[i].src_id == route_id))
            {
                isSplit = (uint8)TRUE;
                Split_Routing_32(splitTbl_32[i].dst_1ch, splitTbl_32[i].dst_1id, splitTbl_32[i].dst_2ch, splitTbl_32[i].dst_2id,
                        splitTbl_32[i].dst_3ch, splitTbl_32[i].dst_3id, splitTbl_32[i].dst_4ch, splitTbl_32[i].dst_4id);
            }
        }
    }
    else if((len > 32u) && (len <= 48u))
    {
        for(uint8 i = 0u; i < SPLIT48_NUM; i++)
        {
            if((splitTbl_48[i].src_ch == srcPort) && (splitTbl_48[i].src_id == route_id))
            {
                isSplit = (uint8)TRUE;
                Split_Routing_48(splitTbl_48[i].dst_1ch, splitTbl_48[i].dst_1id, splitTbl_48[i].dst_2ch, splitTbl_48[i].dst_2id,
                        splitTbl_48[i].dst_3ch, splitTbl_48[i].dst_3id, splitTbl_48[i].dst_4ch, splitTbl_48[i].dst_4id,
                        splitTbl_48[i].dst_5ch, splitTbl_48[i].dst_5id, splitTbl_48[i].dst_6ch, splitTbl_48[i].dst_6id);
            }
        }
    }
    else if((len > 48u) && (len <= 64u))
    {
        for(uint8 i = 0u; i < SPLIT64_NUM; i++)
        {
            if((splitTbl_64[i].src_ch == srcPort) && (splitTbl_64[i].src_id == route_id))
            {
                isSplit = (uint8)TRUE;
                Split_Routing_64(splitTbl_64[i].dst_1ch, splitTbl_64[i].dst_1id, splitTbl_64[i].dst_2ch, splitTbl_64[i].dst_2id,
                        splitTbl_64[i].dst_3ch, splitTbl_64[i].dst_3id, splitTbl_64[i].dst_4ch, splitTbl_64[i].dst_4id, splitTbl_64[i].dst_5ch, splitTbl_64[i].dst_5id,
                        splitTbl_64[i].dst_6ch, splitTbl_64[i].dst_6id, splitTbl_64[i].dst_7ch, splitTbl_64[i].dst_7id, splitTbl_64[i].dst_8ch, splitTbl_64[i].dst_8id);
            }
        }
    }
    else
    {
        // noting.
    }
}

extern void cb_canc_expand(const CNVT_CAN_DATA *canc_data)
{
    uint8 srcPort = canc_data->port - 5u;
    /* misra_c_2012_rule_10_4_violation:	Essential type of the left hand operand "canc_data->len" (unsigned) is not the same as that of the right operand "15"(signed).*/
    uint8 rxDataLen = canc_data->len - 15u;
    uint8 isExt;
    uint8 fdf;
    uint8 isExpand = (uint8)FALSE;
    uint32 cnvt_id;
//    uint8 dst_data[log_dataLen];

    SAL_MemSet(send_data, 0x0, sizeof(send_data));

    SAL_MemCopy(rx_data, canc_data->data, canc_data->len);

    for(uint32 i = 0u; i < ROUTING_EXPAND_NUM; i++)
    {
        if((expandTbl[i].src_ch == srcPort) && (expandTbl[i].src_id == canc_data->id))
        {
            isExpand = (uint8)TRUE;
            expandCycleCount[i]++;
            if(expandTbl[i].period == expandCycleCount[i])
            {
                isExt = (uint8)((expandTbl[i].dst_id & EXTENDED_ID_OFFSET) >> 31);
                if(isExt == 1u)
                {
                    cnvt_id = (expandTbl[i].dst_id ^ EXTENDED_ID_OFFSET);
                }
                else
                {
                    cnvt_id = expandTbl[i].dst_id;
                }

                fdf = chConfig[expandTbl[i].dst_ch - 1];

                for(uint8 len = 0; len < rxDataLen; len++)
                {
                    send_data[len] = rx_data[len];
                }

                CANCnvt_Split(srcPort, canc_data->id, rxDataLen);

                if(isSplit == (uint8)FALSE)
                {
                    frm_cnvt_msg_send(expandTbl[i].dst_ch, fdf, isExt, cnvt_id, rxDataLen, send_data);
                }

                expandCycleCount[i] = 0;
            }
        }
    }
    /*misra_c_2012_rule_10_4_violation:	Essential type of the left hand operand "isExpand" (unsigned) is not the same as that of the right operand "0U"(boolean).*/
    if(isExpand == 0u)
    {
        CANCnvt_Split(srcPort, canc_data->id, rxDataLen);
    }
    /*misra_c_2012_rule_10_3_violation:	Implicit conversion of "0U" from essential type "boolean" to different or narrower essential type "unsigned 8-bit int".*/
    isSplit = (uint8)FALSE;
}
