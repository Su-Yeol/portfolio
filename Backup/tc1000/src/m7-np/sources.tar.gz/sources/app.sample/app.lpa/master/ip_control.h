/*
***************************************************************************************************
*
*   FileName : ip_control.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef IP_CONTROL_H
#define IP_CONTROL_H

//#include "sal_com.h"
//#include "sal_util.h"
#include "mst_framework.h"
#include "ccf.h"
/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/
#define TCN100X_ES_CHIP					(0)
#define TCN100X_CS_CHIP					(1)
#define AXON_VER				(TCN100X_ES_CHIP)
#define LPA_CONFIG_SIZE			(8*128) // 0x400, 1024
#define LPA_CONFIG_READ_SIZE	(8*16) //
#define LPA_CONFIG_RESPONSE_SIZE (1024)

#define MM_WRITE_TYPE		(0xaaaaaaaaaaaaaaaaULL)
#define MM_READ_TYPE		(0xccccccccccccccccULL)

#define CAN_PORT_MASK		(0x2000U)
#define LIN_PORT_MASK		(0x2010U)

extern uint8 gProcRequestBuffer[];
extern uint8 gLogIntMode;
extern uint8 gDataIntMode;
extern uint8 gTimestampMode;

typedef enum eLPA_PORT_NUM {
	LPA_BASE_PORT,
	LPA_NONE0_PORT,
	LPA_NONE1_PORT,
	LPA_LOG_PORT,
	LPA_SVC_PORT,
	LPA_PROC_PORT,
	LPA_CAN1_PORT,
	LPA_CAN2_PORT,
	LPA_CAN3_PORT,
	LPA_CAN4_PORT,
	LPA_CAN5_PORT,
	LPA_CAN6_PORT,
	LPA_CAN7_PORT,
	LPA_CAN8_PORT,
	LPA_CAN9_PORT,
	LPA_CAN10_PORT,
	LPA_CAN11_PORT,
	LPA_CAN12_PORT,
	LPA_CAN13_PORT,
	LPA_CAN14_PORT,
	LPA_CAN15_PORT,
	LPA_CAN16_PORT,
	LPA_LIN1_PORT,
	LPA_LIN2_PORT,
	LPA_LIN3_PORT,
	LPA_LIN4_PORT,
	LPA_LIN5_PORT,
	LPA_LIN6_PORT,
	LPA_LIN7_PORT,
	LPA_LIN8_PORT
}eLPA_PORT_NUM;

/************************************** MM_WRITE Structure ***********************************/
/*    0          8           16           32              48           64                   */
/* 0  |                     RESERVE                                     |                   */
/* 1  |                     RESERVE                                     |                   */
/* 2  |                     RESERVE                                     |                   */
/* 3  |                     RESERVE                                     |                   */
/* 4  |                     RESERVE                                     |                   */
/* 5  |                     RESERVE                                     |                   */
/* 6  |                     RESERVE                                     |                   */
/* 7  |     MM_WRITE[63....0]=AAAAAAAAAAAAAAAAh                         |                   */
/* 8  |     ID REG@          |          Init Data0                      |                   */
/* 9  |     Init Addr1       |          Init Data1                      |                   */
/* 10 |     Init Addr2       |          Init Data2                      |                   */
/* 11 |     Init Addr3       |          Init Data3                      |                   */
/*  :             :                         :                                               */
/* 123|     Init Addr114     |          Init Data115                    |                   */
/* 124|                     RESERVE                                     |                   */
/* 125|                     RESERVE                                     |                   */
/* 126|                     RESERVE                                     |                   */
/* 127|     RESERVE                     |           CRC                 |                   */

typedef struct MM_WRITE {
    uint64 reserved1[7];
    uint64 type;
    uint64 data[116];
    uint64 reserved2[3];
    uint32 reserved3;
    uint32 crc32;
}MM_WRITE ; /* size: 1024 byte */

/************************************** MM_READ Structure ***********************************/
/*    0          8           16           32			  48  	       64					*/
/* 0  |   					RESERVE										|   				*/
/* 1  |   					RESERVE										|   				*/
/* 2  |   					RESERVE										|   				*/
/* 3  |   					RESERVE										|   				*/
/* 4  |   					RESERVE										|   				*/
/* 5  |   					RESERVE										|   				*/
/* 6  |   					RESERVE										|   				*/
/* 7  |   	MM_WRITE[63....0]=CCCCCCCCCCCCCCCCh							|   				*/
/* 8  | 	0x7		   		 |			RESERVED						|   				*/
/* 9  | 	0x4		 		 |			RESERVED						|   				*/
/* 10 |   					RESERVE										|   				*/
/* 11 |   					RESERVE										|   				*/
/* 12 |   					RESERVE										|   				*/
/* 13 |   					RESERVE										|   				*/
/* 14 |   					RESERVE										|   				*/
/* 15 |  	RESERVE			             |			CRC32				|   				*/

typedef struct MM_READ {
    uint64 reserved1[7];
    uint64 type;
    uint16 addr1;
    uint16 reserved2[3];
    uint16 addr2;
    uint16 reserved3[3];
    uint64 reserved4[5];
    uint32 reserved5;
    uint32 crc32;
}MM_READ; /* size: 128 byte */


/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/
//extern int32a LPA_Write_CCF(uint64 *ccf_conf);
/*misra_c_2012_rule_8_5_violation:	Symbol "frm_lpa_write_ccf" is declared more than once.*/
//extern int32a frm_lpa_write_ccf(uint64 *ccf_conf);
extern void frm_lpa_set_trxIC(uint32 can_flag, uint32 lin_flag, uint32 can_mode, uint32 lin_mode);

#endif /* IP_CONTROL_H */
