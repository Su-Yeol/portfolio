/*
***************************************************************************************************
*
*   FileName : demo_lpa_log.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/**************************************************************************************************
*                                           INCLUDE FILES
**************************************************************************************************/
#include "app_cfg.h"
#include "demo_lpa_log.h"
#include "bsp.h"
#include "debug.h"
#include "lpa_drv.h"
#include "mst_framework.h"

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/
#define TP_AVG_TIME			(10000u)

/**************************************************************************************************
*                                          LOCAL VARIABLES
**************************************************************************************************/
static uint32 can_log_tp_count[16]={0u,};
static uint32 can_log_tp_start_time;
static uint32 can_log_tp_timer;

static uint8 LogRequestBuffer[128];
static uint8 LogResponseBuffer[LPA_TO_MEMORY_SIZE];
static uint8 Log_task_state = 0U;	/* 0:idle, 1: normal operation */
static TaskHandle_t Log_Task_Handle;
static LpaLogDataCallback fLpaLogDataCB = NULL;
static LpaLogTsCallback fLpaLogTsCB = NULL;

/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/
static void print_log_data_frame_info(const LOG_DATA_FRAME *data_frame);
static void print_log_ts_frame_info(const LOG_TS_FRAME *ts_frame);

/**************************************************************************************************
*                                             FUNCTIONS
**************************************************************************************************/
void LPA_Log_Init(void)
{
	LPA_Log_setDataCB(print_log_data_frame_info);
	LPA_Log_setTsCB(print_log_ts_frame_info);
}

void LPA_Log_setDataCB(LpaLogDataCallback cbFunc)
{
	fLpaLogDataCB = cbFunc;
}

void LPA_Log_setTsCB(LpaLogTsCallback cbFunc)
{
	fLpaLogTsCB = cbFunc;
}

static void print_log_data_frame_info(const LOG_DATA_FRAME *data_frame)
{
	uint8 i;;
	if (data_frame != NULL)
	{
		mcu_printf(" ======== LOGGING Data Frame ====================\n");
		mcu_printf(" Protocol: %s, Route ID:0x%x, SN:%d, Port:%s, Data length:%d\n",
		/* misra_c_2012_rule_12_1_violation:	Missing explicit parentheses on sub-expression: "data_frame->proto == 0U".*/
			(data_frame->proto == PROTOCOL_CAN)?"CAN":"LIN",
			data_frame->routeID,
			data_frame->sn,
			PORT_NAME[data_frame->port],
			data_frame->data_len);
		switch(data_frame->ftype)
		{
			case FRAME_TYPE_CAN_BASE:
				mcu_printf(" CAN_ID:0x%X\n", data_frame->ID);
				break;
			case FRAME_TYPE_CAN_EXT:
				mcu_printf(" CAN_ID(ext):0x%X\n", data_frame->ID);
				break;
			case FRAME_TYPE_CANFD_BASE:
				mcu_printf(" CANFD_ID:0x%X\n", data_frame->ID);
				break;
			case FRAME_TYPE_CANFD_EXT:
				mcu_printf(" CANFD_ID(ext):0x%X\n", data_frame->ID);
				break;
			case FRAME_TYPE_LIN_RX:
				mcu_printf(" LIN_ID:0x%X\n", data_frame->ID);
				break;
			default:
				/**/
				break;
		}
		mcu_printf(" Timestamp: %d_%u(us), %u(ns) / %u(sec)\n",
			data_frame->ts_us_high,
			data_frame->ts_us_low,
			data_frame->ts_ns,
			data_frame->ts_us_low/1000000U);
		mcu_printf(" Data: ");
		for(i = 0U; i < data_frame->data_len; i++)
		{
			mcu_printf("%02x ", data_frame->Data[i]);
		}
		mcu_printf("\n");
	}
}

static void print_log_ts_frame_info(const LOG_TS_FRAME *ts_frame)
{
	if ( ts_frame != NULL)
	{
		mcu_printf(" ======== LOGGING Timestamp Frame ====================\n");
		mcu_printf(" Port:%s, Route ID:0x%x, SN:%d\n",
			PORT_NAME[ts_frame->port],
			ts_frame->routeID,
			ts_frame->sn);
		mcu_printf(" Timestamp: %u_%u(us), %u(ns) / %u(sec)\n",
			ts_frame->ts_us_high,
			ts_frame->ts_us_low,
			ts_frame->ts_ns,
			ts_frame->ts_us_low/1000000U);
	}
}

static void print_logging_tp_info(void)
{
	uint32 i;
	/*cert_dcl37_c_violation:	The reserved identifier "tot", which is reserved for future library directions in ctype.h, is declared.*/
	//uint32 tot = 0u;
	uint32 logtotime = 0u;
//	mcu_printf("\n\n Logging port throughput information\n");
	for(i = 0u; i < 16u; i++)
	{
		if (can_log_tp_count[i] != 0u)
		{
			logtotime += can_log_tp_count[i];
//			mcu_printf("%d, %d\n", i, can_log_tp_count[i]);
		}
	}
	mcu_printf(" %4u sec, average: %u frame/sec\n", can_log_tp_timer, logtotime/(TP_AVG_TIME/1000u));
	SAL_MemSet(can_log_tp_count, 0, sizeof(can_log_tp_count));
}

static uint32 lpa_get_time_ms(void)
{
	uint32 tick = xTaskGetTickCount();
	uint32 ms = tick * portTICK_PERIOD_MS;
	return ms;
}

static uint8 parse_log_frame(const uint8 *buffer)
{
	uint16 data_length;
	uint32 i;
	LOG_DATA_FRAME data_frame;
	LOG_TS_FRAME ts_frame;
	uint8 ftype;
	uint16 CectaC_ID;
	uint16 sn;
	uint8 fdf;
	uint8 ide;
	uint8 rtr;
	uint8 proto;
	uint32 ts_us_L;
	uint32 ts_us_H;
	uint16 ts_ns;
	uint16 CAN_ID;
	uint16 LIN_ID;
	uint8 SourcePort;
	uint32 ExCAN_ID;
	uint16 log_dataLen;

	ftype = buffer[0] & 0x01u;

	CectaC_ID = (((uint16)buffer[0] & 0xFEu)>>1u) + ((uint16)buffer[1] << 7u);
	sn = ((uint16)buffer[2]) + ((uint16)buffer[3] << 8u);
	SourcePort = buffer[4];

	ts_ns  = ((uint16)buffer[5] * 10U);
	ts_us_L  = ((uint32)buffer[6]);
	ts_us_L |= ((uint32)buffer[7]  << 8u);
	ts_us_L |= ((uint32)buffer[8]  << 16u);
	ts_us_L |= ((uint32)buffer[9]  << 24u);
	ts_us_H  = ((uint32)buffer[10]);
	ts_us_H |= ((uint32)buffer[11]  << 8u);
	ts_us_H |= ((uint32)buffer[12]  << 16u);
	ts_us_H |= ((uint32)buffer[13]  << 24u);

	proto = buffer[14] & 0x01;

	CAN_ID = (((uint16)buffer[14] & 0xfeu)>>1u) + (((uint16)buffer[15] & 0x0fu)<<7u);
	LIN_ID = (((uint16)buffer[14] & 0x7eu)>>1u);
	ExCAN_ID  = (((uint32)buffer[14] & 0xfeu)>>1u);
	ExCAN_ID |= (((uint32)buffer[15])<<7u);
	ExCAN_ID |= (((uint32)buffer[16])<<15u);
	ExCAN_ID |= (((uint32)buffer[17] & 0x3fu)<<23u);

	fdf = (buffer[17] & 0x40u) >> 6u;
	rtr = (buffer[17] & 0x80u) >> 7u;
	ide = buffer[18] & 0x01u;

	data_length = (uint16)(buffer[18] & 0xf0u)>>4u;

	if (ftype == DATA_FRAME)
	{
		if (fdf == CAN_FD)
		{
		/*cert_exp37_c_violation:	Calling function "frm_get_CAN_length(uint8)" with the argument "data_length", which has an incompatible type "uint16" instead of "uint8". */
			log_dataLen = frm_get_CAN_length((uint8)data_length);
		}
		else
		{
			log_dataLen = data_length;
		}

		data_frame.proto = proto;
		data_frame.port = SourcePort;
		data_frame.routeID = CectaC_ID;
		data_frame.sn = sn;
		data_frame.ts_us_high = ts_us_H;
		data_frame.ts_us_low = ts_us_L;
		data_frame.ts_ns = ts_ns;
		data_frame.rtr = rtr;

		for(i = 0U; i < log_dataLen; i++)
		{
			data_frame.Data[i] = buffer[19U+i];
		}
		data_frame.data_len = log_dataLen;
		if (proto == PROTOCOL_CAN)
		{
			if (ide == STANDARD_CAN)
			{
				data_frame.ftype = FRAME_TYPE_CAN_BASE;
				if (fdf == CAN_FD)
				{
					data_frame.ftype = FRAME_TYPE_CANFD_BASE;
				}
				data_frame.ID = CAN_ID;
			}
			else
			{
				data_frame.ftype = FRAME_TYPE_CAN_EXT;
				if (fdf == CAN_FD)
				{
					data_frame.ftype = FRAME_TYPE_CANFD_EXT;
				}
				data_frame.ID = ExCAN_ID;
			}
		}
		else
		{
			data_frame.ftype = FRAME_TYPE_LIN_RX;
			data_frame.ID = LIN_ID;
		}

		if (Log_task_state == 1U)
		{
			if (fLpaLogDataCB != NULL)
			{
				fLpaLogDataCB(&data_frame);
			}
		}
		else
		{
			/* throughput measuring */
			/*misra_c_2012_rule_10_4_violation:	Essential type of the left hand operand "SourcePort" (unsigned) is not the same as that of the right operand "6"(signed).*/
			uint32 a = SourcePort - 6u;
			uint32 curr = lpa_get_time_ms();
			uint32 diff;

			if (curr >= can_log_tp_start_time) {
				diff = curr - can_log_tp_start_time;
			}
			else {
				can_log_tp_start_time = curr;
				diff = 0u;
			}

			can_log_tp_count[a]++;

			if (diff >= TP_AVG_TIME)
			{
				can_log_tp_timer += (TP_AVG_TIME/1000u);
				can_log_tp_start_time = curr;
				print_logging_tp_info();
			}

		}
	}
	else
	{
		ts_frame.port = SourcePort;
		ts_frame.routeID = CectaC_ID;
		ts_frame.sn = sn;
		ts_frame.ts_us_high = ts_us_H;
		ts_frame.ts_us_low = ts_us_L;
		ts_frame.ts_ns = ts_ns;

		if (fLpaLogTsCB != NULL)
		{
			fLpaLogTsCB(&ts_frame);
		}
	}

	return ftype;
}

/* misra_c_2012_rule_8_3_violation : missing ''extern'*/
extern uint8 LPA_Log_getTaskState(void)
{
	return Log_task_state;
}

void LPA_Log_TaskNotifyStop(void)
{
	(void)xTaskNotify( Log_Task_Handle,	(uint32)eLPA_LOG_TASK_NOTIFY_STOP, eSetBits );
}

void LPA_Log_TaskNotifyRestart(void)
{
	(void)xTaskNotify( Log_Task_Handle,	(uint32)eLPA_LOG_TASK_NOTIFY_RESTART, eSetBits );
}

void LPA_Log_TaskNotifyTp(void)
{
	(void)xTaskNotify( Log_Task_Handle,	(uint32)eLPA_LOG_TASK_NOTIFY_TP, eSetBits );
}

static void LPA_Log_Task(const void *pArg)
{
	( void ) pArg;
	uint32 ulInterruptStatus;
	stLPA_REQUEST_t req;
	stLPA_RESPONSE_t resp;

	Log_Task_Handle = xTaskGetCurrentTaskHandle();
	/*misra_c_2012_rule_17_7_violation:	The return value of a non-void function "lpa_startLog" is unused.*/
	(void)lpa_startLog(Log_Task_Handle);

	SAL_MemSet(&req, 0, sizeof(stLPA_REQUEST_t));
	SAL_MemSet(&resp, 0, sizeof(stLPA_RESPONSE_t));

	SAL_MemSet(can_log_tp_count, 0, sizeof(can_log_tp_count));

	req.buffer = LogRequestBuffer;
	resp.buffer = LogResponseBuffer;
	Log_task_state = 1U;
	mcu_printf("[%s] task start\n", __func__);
	// LPA_Log_Init(); // 241205 sy.kim
	/*misra_c_2012_rule_14_4_violation:	The condition expression "1" does not have an essentially boolean type.*/
    while( TRUE )
    {
		if (xTaskNotifyWait(0x00, 0xffffffffUL, &ulInterruptStatus, 0U) != pdTRUE) {
			/**/
		}
		else {
			if ((ulInterruptStatus & (uint32)eLPA_LOG_TASK_NOTIFY_STOP) == (uint32)eLPA_LOG_TASK_NOTIFY_STOP) {
				Log_task_state = 0U;
				mcu_printf("Log task is a sleep state\n");
				continue;
			}
			if ((ulInterruptStatus & (uint32)eLPA_LOG_TASK_NOTIFY_RESTART) == (uint32)eLPA_LOG_TASK_NOTIFY_RESTART) {
				Log_task_state = 1U;
				mcu_printf("Log task is restarted\n");
				continue;
			}
			if ((ulInterruptStatus & (uint32)eLPA_LOG_TASK_NOTIFY_TP) == (uint32)eLPA_LOG_TASK_NOTIFY_TP) {
				if (Log_task_state == 1U) {
					Log_task_state = 2U;
					can_log_tp_start_time = lpa_get_time_ms();
					can_log_tp_timer = 0u;
					mcu_printf("Log task is throughput mode\n");
				}
				else {
					Log_task_state = 1U;
					mcu_printf("Log task is normal mode\n");
				}
			}
		}

		if ((Log_task_state == 1U) ||
			(Log_task_state == 2U)) {
			if (lpa_readLog(&req, &resp) == (int32)eLPA_RET_OK) {
				if (resp.ret == (uint16)eLPA_RET_OK) {
					if (resp.size > 4U) {
						/*misra_c_2012_rule_17_7_violation:	The return value of a non-void function "parse_log_frame" is unused.*/
                        (void)parse_log_frame(LogResponseBuffer);
					}
				}
				else if (resp.ret == (uint16)eLPA_RET_DEV_NO_DATA) {
					(void)SAL_TaskSleep( 1 );
				}
				else {
					/**/
				}
			}
		}
		else {
			(void)SAL_TaskSleep( 10 );
		}
    }
    /*misra_c_2012_rule_2_1_violation:	statement is unreachable*/
    //lpa_stopLog();
}

void LPA_Log_CreateAppTasks(void)
{
    static uint32 uiLPA_LogTaskID;
    static uint32 uiLPA_LogTaskStk[LPA_LOG_TASK_STK_SIZE];

    if(SAL_TaskCreate( &uiLPA_LogTaskID,
                   ( const uint8 * ) "LogTask",
                   ( SALTaskFunc ) &LPA_Log_Task,
                   ( uint32 * const ) &uiLPA_LogTaskStk[0],
                   LPA_LOG_TASK_STK_SIZE,
                   SAL_PRIO_LPA_LOG,
                   NULL_PTR) != SAL_RET_SUCCESS)
                   {
				   		mcu_printf("%s Fatal!! Task Create Fail. \n", __func__);
                   }
}

