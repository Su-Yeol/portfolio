/*
***************************************************************************************************
*
*   FileName : demo_rx.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/**************************************************************************************************
*                                           INCLUDE FILES
**************************************************************************************************/
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include "demo_rx.h"
#include "debug.h"

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/

/**************************************************************************************************
*                                          LOCAL VARIABLES
**************************************************************************************************/

/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/

/**************************************************************************************************
*                                             FUNCTIONS
**************************************************************************************************/
void cb_print_reg_data_info(const LPA_REG_DATA *reg_data)
{
	uint32 port;
	uint32 offset;
	uint32 temp;

	if (reg_data != NULL)
	{
		if (reg_data->addr == LPA_REG_ADDR_IP_VER) {
			mcu_printf("LPA IP ver:%x, state:%d\n", reg_data->data[0], reg_data->data[1]);
			mcu_printf("ID_REQ1:%08x, init_vector:%08x\n", reg_data->data[2], reg_data->data[3]);
		}
		else if ((reg_data->addr >= LPA_REG_ADDR_CAN_PORT_BASE) && (reg_data->addr < LPA_REG_ADDR_LIN_PORT_BASE)) {
			offset = (uint32)reg_data->addr - LPA_REG_ADDR_CAN_PORT_BASE;
			port = offset / 8U;
			temp = port * 8U;

			if ( offset == temp) {
				mcu_printf("== CAN[%d] port statistics ===========\n", port+1U);
				mcu_printf("rx_escape_route1: %d\n", reg_data->data[0]);
				mcu_printf("rx_escape_route2: %d\n", reg_data->data[1]);
				mcu_printf("rx_abort: %d\n", reg_data->data[2]);
				mcu_printf("id_not_found: %d\n", reg_data->data[3]);
			}
			else {
				mcu_printf("rx_frame_counter: %d\n", reg_data->data[2]);
				mcu_printf("tx_frame_counter: %d\n", reg_data->data[3]);
				mcu_printf("======================================\n");
			}
            set_master_ack(1U);
		}
		else if ((reg_data->addr >= LPA_REG_ADDR_LIN_PORT_BASE) && (reg_data->addr < LPA_REG_ADDR_PORT_ATTR_BASE)) {
			offset = (uint32)reg_data->addr - LPA_REG_ADDR_LIN_PORT_BASE;
			port = offset / 8U;
			temp = port * 8U;

			if ( offset == temp) {
				mcu_printf("== LIN[%d] port statistics ===========\n", port+1U);
				mcu_printf("rx_escape_route: %d\n", reg_data->data[0]);
				mcu_printf("rx_abort: %d\n", reg_data->data[2]);
				mcu_printf("id_not_found: %d\n", reg_data->data[3]);
			}
			else {
				mcu_printf("rx_frame_counter: %d\n", reg_data->data[2]);
				mcu_printf("tx_frame_counter: %d\n", reg_data->data[3]);
				mcu_printf("======================================\n");
			}
            set_master_ack(1U);
		}
		else if ((reg_data->addr >= LPA_REG_ADDR_PORT_ATTR_BASE) && (reg_data->addr < 0x300U)) {
			offset = (uint32)reg_data->addr - LPA_REG_ADDR_PORT_ATTR_BASE;
			port = offset / 8U;
			mcu_printf("== Port[%d] attributes info ===========\n", port);
			mcu_printf("port type: %x\n", reg_data->data[0]);
			mcu_printf("port name0: %x\n", reg_data->data[1]);
			mcu_printf("port name1: %x\n", reg_data->data[2]);
			mcu_printf("port name2: %x\n", reg_data->data[3]);
		}
		else {
			mcu_printf("unknown address range: %x\n", reg_data->addr);
		}
	}
}

void cb_print_data_frame_info(const RX_DATA_FRAME *rx_data)
{
	uint8 i;
	if (rx_data != NULL)
	{
		// mcu_printf(" ======== CAN to PROC TX Data Frame ======== \n");
		// mcu_printf(" Protocol: %s, Port:%s, data_len:%d\n",
		// 	(rx_data->proto == PROTOCOL_CAN)?"CAN":"LIN",
		// 	PORT_NAME[rx_data->port],
		// 	rx_data->data_len);
		// switch(rx_data->ftype)
		// {
		// 	case FRAME_TYPE_CAN_BASE:
		// 		mcu_printf(" CAN_ID:0x%X\n", rx_data->ID);
		// 		break;
		// 	case FRAME_TYPE_CAN_EXT:
		// 		mcu_printf(" CAN_ID(ext):0x%X\n", rx_data->ID);
		// 		break;
		// 	case FRAME_TYPE_CANFD_BASE:
		// 		mcu_printf(" CANFD_ID:0x%X\n", rx_data->ID);
		// 		break;
		// 	case FRAME_TYPE_CANFD_EXT:
		// 		mcu_printf(" CANFD_ID(ext):0x%X\n", rx_data->ID);
		// 		break;
		// 	case FRAME_TYPE_LIN_RX:
		// 		mcu_printf(" LIN_ID:0x%X\n", rx_data->ID);
		// 		break;
		// 	default:
		// 		/**/
		// 		break;
		// }
		// mcu_printf(" Timestamp: %u_%u(us), %u(ns) / %u(sec)\n",
		// 	rx_data->ts_us_high,
		// 	rx_data->ts_us_low,
		// 	rx_data->ts_ns,
		// 	rx_data->ts_us_low/1000000U);
		// mcu_printf(" Data: ");
		// for(i = 0U; i < rx_data->data_len; i++)
		// {
		// 	mcu_printf("%02x ", rx_data->Data[i]);
		// }
		// mcu_printf("\n\n");
		
		mcu_printf(" ###### (PROC) TX CAN test\n");
	}

}

void cb_print_ts_frame_info(const RX_TS_FRAME *rx_ts)
{
	if ( rx_ts != NULL)
	{
		// 241205 sy.kim
		// mcu_printf(" ======== CAN RX Timestamp Frame ======== \n");
		// mcu_printf(" Timestamp: %u_%u(us), %u(ns) / %u(sec)\n",
		// 	rx_ts->ts_us_high,
		// 	rx_ts->ts_us_low,
		// 	rx_ts->ts_ns,
		// 	rx_ts->ts_us_low/1000000U);
		// mcu_printf("\n");

		mcu_printf(" ****** (CAN) RX CAN test\n");
	}

}

void cb_print_status_frame_info(const RX_STATUS_FRAME *rx_status)
{
	uint8 i;
	if (rx_status != NULL)
	{
		mcu_printf(" ======== Error Status Frame ======== \n");
		mcu_printf(" Port:%s, Error bit: ", PORT_NAME[rx_status->port]);
		for(i = 0; i < rx_status->error_num; i++) {
			mcu_printf("%d, ", rx_status->error[i]);
		}
		mcu_printf("\n");
	}
}
