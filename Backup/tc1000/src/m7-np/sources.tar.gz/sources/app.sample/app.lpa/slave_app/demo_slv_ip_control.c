/*
***************************************************************************************************
*
*   FileName : demo_slv_ip_control.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/*undefined_identifier:	identifier "errno" is undefined*/
#include <errno.h>
#include "demo_slv_ip_control.h"

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/


/**************************************************************************************************
*                                          LOCAL VARIABLES
**************************************************************************************************/

LpaStatusCallback sfLpaStatusCB = NULL;

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/

static void LPA_SF_CTRL_CLI_Help(void);
void LPA_SF_CTRL_CLI(uint8 ucArgc, void* const pArgv[]);

/*
***************************************************************************************************
*                                         FUNCTIONS
***************************************************************************************************
*/

void sf_print_status_frame_info(const RX_STATUS_FRAME *rx_status)
{
	uint8 i;

	if (rx_status != NULL)
	{
		mcu_printf(" ======== Error Status Frame ====================\n");
		mcu_printf(" Port:%s, Error bit: ", PORT_NAME[rx_status->port]);
		for(i = 0; i < rx_status->error_num; i++) {
			mcu_printf("%d, ", rx_status->error[i]);
		}
		mcu_printf("\n");
	}
}

uint8 sf_parse_status_frame(const uint8 *buffer)
{
    uint8 port;
    uint32 upper32;
    uint32 lower32;
    uint8 i;
    uint8 error_bit;
    uint32 count = 0U;
    uint32 v;
    uint32 mask;
    uint8 flag[32] = {0,};
    RX_STATUS_FRAME st;

    port = buffer[0];
    lower32  = (uint32)buffer[1];
    lower32 |= ((uint32)buffer[2] << 8);
    lower32 |= ((uint32)buffer[3] << 16);
    lower32 |= ((uint32)buffer[4] << 24);
    upper32  = (uint32)buffer[5];
    upper32 |= ((uint32)buffer[6] << 8);
    upper32 |= ((uint32)buffer[7] << 16);
    upper32 |= ((uint32)buffer[8] << 24);

    error_bit = 0;
    st.error_num = 0;
    st.port = port;
    for(i = 0; i < 32U; i++)
    {
        v = 1UL << i;
        mask = lower32 & v;
        if (mask == v)
        {
            flag[count] = i;
            count = count + 1U;
            if (st.error_num <= 3U)
            {
                st.error[st.error_num] = i;
                st.error_num = st.error_num + 1U;
            }
        }
    }
    for(i = 0u; i < 32U; i++)
    {
        v = 1UL << i;
        mask = upper32 & v;
        if (mask == v)
        {
            flag[count] = i + 32U;
            count = count + 1U;

            if (st.error_num <= 3U)
            {
                st.error[st.error_num] = i + 32U;
                st.error_num = st.error_num + 1U;
            }
        }
    }
    error_bit = flag[0];

    for(i = 0; i < st.error_num; i++)
    {
        if (st.error[i] == 29U) {
            error_bit = 29U;
            break;
        }
    }

#if (LPA_MC_TEST == 1)
    if (st.port == 6U)
    {
        write_frame_rxbuf(0U, 2U, sizeof(st), (void *)&st);
    }
    else if (st.port == 7U)
    {
        write_frame_rxbuf(1U, 2U, sizeof(st), (void *)&st);
    }
    else if (st.port == 8U)
    {
        write_frame_rxbuf(2U, 2U, sizeof(st), (void *)&st);
    }
    else
    {
        if (sfLpaStatusCB != NULL)
        {
            sfLpaStatusCB(&st);
        }
    }
#else
    if (sfLpaStatusCB != NULL)
    {
        sfLpaStatusCB(&st);
    }
#endif

    return error_bit;
}

/*misra_c_2012_rule_8_4_violation:	Function definition does not have a visible prototype.*/
void slv_print_port_statistics_info(const LPA_REG_DATA *reg_data)
{
	uint32 port;
	uint32 offset;
	uint32 temp;

	if (reg_data != NULL)
	{
#if 0
		if (reg_data->addr == LPA_REG_ADDR_IP_VER) {
			mcu_printf("LPA IP ver:%x, state:%d\n", reg_data->data[0], reg_data->data[1]);
			mcu_printf("ID_REQ1:%08x, init_vector:%08x\n", reg_data->data[2], reg_data->data[3]);
		}
#endif
		if ((reg_data->addr >= LPA_REG_ADDR_CAN_PORT_BASE) && (reg_data->addr < LPA_REG_ADDR_LIN_PORT_BASE)) {
			offset = (uint32)reg_data->addr - LPA_REG_ADDR_CAN_PORT_BASE;
			port = offset / 8U;
			temp = port * 8U;

			if ( offset == temp) {
				mcu_printf("== CAN[%d] port statistics ===========\n", port+1U);
				mcu_printf("rx_escape_route1: %d\n", reg_data->data[0]);
				mcu_printf("rx_escape_route2: %d\n", reg_data->data[1]);
				mcu_printf("rx_abort: %d\n", reg_data->data[2]);
				mcu_printf("id_not_found: %d\n", reg_data->data[3]);
			}
			else {
				mcu_printf("rx_frame_counter: %d\n", reg_data->data[2]);
				mcu_printf("tx_frame_counter: %d\n", reg_data->data[3]);
				mcu_printf("======================================\n");
			}
		}
		else if ((reg_data->addr >= LPA_REG_ADDR_LIN_PORT_BASE) && (reg_data->addr < LPA_REG_ADDR_PORT_ATTR_BASE)) {
			offset = (uint32)reg_data->addr - LPA_REG_ADDR_LIN_PORT_BASE;
			port = offset / 8U;
			temp = port * 8U;

			if ( offset == temp) {
				mcu_printf("== LIN[%d] port statistics ===========\n", port+1U);
				mcu_printf("rx_escape_route: %d\n", reg_data->data[0]);
				mcu_printf("rx_abort: %d\n", reg_data->data[2]);
				mcu_printf("id_not_found: %d\n", reg_data->data[3]);
			}
			else {
				mcu_printf("rx_frame_counter: %d\n", reg_data->data[2]);
				mcu_printf("tx_frame_counter: %d\n", reg_data->data[3]);
				mcu_printf("======================================\n");
			}
		}
		else if ((reg_data->addr >= LPA_REG_ADDR_PORT_ATTR_BASE) && (reg_data->addr < 0x300U)) {
			offset = (uint32)reg_data->addr - LPA_REG_ADDR_PORT_ATTR_BASE;
			port = offset / 8U;
			mcu_printf("== Port[%d] attributes info ===========\n", port);
			mcu_printf("port type: %x\n", reg_data->data[0]);
			mcu_printf("port name0: %x\n", reg_data->data[1]);
			mcu_printf("port name1: %x\n", reg_data->data[2]);
			mcu_printf("port name2: %x\n", reg_data->data[3]);
		}
		else {
			mcu_printf("unknown address range: %x\n", reg_data->addr);
		}
	}
}

/*misra_c_2012_rule_8_4_violation:	Function definition does not have a visible prototype.*/
static void LPA_SF_CTRL_CLI_Help(void)
{
	mcu_printf( "=== wrong argument ===\n" );
    mcu_printf( "=== USAGE INFO ===\n\n" );
    mcu_printf( "=== CMD LIST ===\n" );
    mcu_printf( "lpa [cmd] : 'reset' = lpa reset, 'validation' = lpa validation\n" );
}

void LPA_SF_CTRL_CLI(uint8 ucArgc, void* const pArgv[])
{
	(void)ucArgc;
    uint8 *pucStr1;
    uint8 *pucStr2;
    uint8 *pucStr3;
    uint8 *pucStr4;
    uint8 *pucStr5;

    pucStr1 = NULL_PTR;
    pucStr2 = NULL_PTR;
    pucStr3 = NULL_PTR;
    pucStr4 = NULL_PTR;
    pucStr5 = NULL_PTR;

    uint32 portN;
    uint32 clockN;
    uint32 fd_clockN;
    uint32 typeN;
    uint8 set_data[3];

	sint32 ret;

    /*
    for (i = 0 ; i < 64U; i++)
	{
		Data[i] = (i * 4U) + 3U;
	}
    */

    SAL_MemSet(&set_data, 0U, sizeof(set_data));

    if( pArgv != NULL_PTR )
    {

    	SAL_MemCopy(&pucStr1, &pArgv[0], 4U);
		SAL_MemCopy(&pucStr2, &pArgv[1], 4U);
		SAL_MemCopy(&pucStr3, &pArgv[2], 4U);
		SAL_MemCopy(&pucStr4, &pArgv[3], 4U);
		SAL_MemCopy(&pucStr5, &pArgv[4], 4U);

		if( ( SAL_StrNCmp( pucStr1, ( const uint8 * ) "reset", 5, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
		{
            set_data[0] = LPA_RESET;
            LPA_SF_ctrl(TCC_IPC_CMD_IP_CTRL_RESET, set_data);
        }
        else if( (SAL_StrNCmp( pucStr1, ( const uint8 * ) "initial", 7, &ret) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
        {
            set_data[0] = LPA_INITIAL;
            LPA_SF_ctrl(TCC_IPC_CMD_IP_CTRL_INITIAL, set_data);
        }
        else if( (SAL_StrNCmp( pucStr1, ( const uint8 * ) "can", 3, &ret) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
        {
            /*cert_err30_c_violation:	The variable "errno" must be tested before calling function "DBG_SerialPrintf".*/
        	errno = 0;
            portN = strtoul((int8 *)pucStr2, NULL, 10);
            if ((portN < 1U) && (portN > 16U))
            {
                mcu_printf("CAN channel number range over (only 1 ~16) \n");
            }
            else
            {
                if( pucStr3 != NULL_PTR )
                {
                    if( ( SAL_StrNCmp( pucStr3, ( const uint8 * ) "clock", 5, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                    {
                        errno = 0;
                        clockN = strtoul((int8 *)pucStr4, NULL, 10);
                        errno = 0;
                        fd_clockN = strtoul((int8 *)pucStr5, NULL, 10);

                        set_data[0] = portN;
                        set_data[1] = clockN;
                        set_data[2] = fd_clockN;

                        LPA_SF_ctrl(TCC_IPC_CMD_IP_CTRL_CLK_CAN, set_data);
                    }
                    else if( ( SAL_StrNCmp( pucStr3, ( const uint8 * ) "type", 4, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                    {
                        typeN = strtoul((int8 *)pucStr4, NULL, 10);

                        set_data[0] = portN;
                        set_data[1] = typeN;
                        LPA_SF_ctrl(TCC_IPC_CMD_IP_CTRL_TYPE, set_data);
                    }
                }
                else
                {
                    mcu_printf("Enter the action to perform on the CAN port\n");
                }
            }
        }
        else if( (SAL_StrNCmp( pucStr1, ( const uint8 * ) "lin", 3, &ret) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
        {
            errno = 0;
            portN = strtoul((int8 *)pucStr2, NULL, 10);
            if ((portN < 1U) && (portN > 8U))
            {
                mcu_printf("LIN channel number range over (only 1 ~ 8) \n");
            }
            else
            {
                if( pucStr3 != NULL_PTR )
                {
                    if( ( SAL_StrNCmp( pucStr3, ( const uint8 * ) "clock", 5, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                    {
                        errno = 0;
                        clockN = strtoul((int8 *)pucStr4, NULL, 10);

                        set_data[0] = portN;
                        set_data[1] = clockN;

                        LPA_SF_ctrl(TCC_IPC_CMD_IP_CTRL_CLK_LIN, set_data);
                    }
                    else if( ( SAL_StrNCmp( pucStr3, ( const uint8 * ) "checksum", 8, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                    {
                        errno = 0;
                        typeN = strtoul((int8 *)pucStr4, NULL, 10);

                        set_data[0] = portN;
                        set_data[1] = LIN_CHECKSUM;
                        set_data[2] = typeN;
                        LPA_SF_ctrl(TCC_IPC_CMD_IP_CTRL_CKSUM, set_data);
                    }
                    else if( ( SAL_StrNCmp( pucStr3, ( const uint8 * ) "autorx", 6, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                    {
                        errno = 0;
                        typeN = strtoul((int8 *)pucStr4, NULL, 10);

                        set_data[0] = portN;
                        set_data[1] = LIN_AUTORX;
                        set_data[2] = typeN;
                        LPA_SF_ctrl(TCC_IPC_CMD_IP_CTRL_AUTORX, set_data);
                    }
                }
            }
        }
        else if( (SAL_StrNCmp( pucStr1, ( const uint8 * ) "validation", 10, &ret) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
        {
            set_data[0] = 1;
            LPA_SF_stat(TCC_IPC_CMD_IP_STAS_VAL, set_data);
        }
        else if( (SAL_StrNCmp( pucStr1, ( const uint8 * ) "status", 6, &ret) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
        {
            if( pucStr2 != NULL_PTR )
            {
                if( ( SAL_StrNCmp( pucStr2, ( const uint8 * ) "can", 3, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
                    portN = strtoul((int8 *)pucStr3, NULL, 10);
                    /*misra_c_2012_rule_10_4_violation:	Essential type of the left hand operand "portN" (unsigned) is not the same as that of the right operand "1"(signed).*/
                    if ((portN < 1u) && (portN > 16u))
                    {
                        mcu_printf("CAN channel number range over (only 1 ~ 16) \n");
                    }
                    else
                    {
                        mcu_printf("port Number :%d \n", portN);
                        LPA_SF_stat(TCC_IPC_CMD_IP_STAS_CNT_CAN, (uint8 *)&portN);
                    }
                }
                else if( ( SAL_StrNCmp( pucStr2, ( const uint8 * ) "lin", 3, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
                {
                    portN = strtoul((int8 *)pucStr3, NULL, 10);

                    /*misra_c_2012_rule_10_4_violation:	Essential type of the left hand operand "portN" (unsigned) is not the same as that of the right operand "1"(signed).*/
                    if ((portN < 1u) && (portN > 8u))
                    {
                        mcu_printf("LIN channel number range over (only 1 ~ 8) \n");
                    }
                    else
                    {
                        mcu_printf("port Number :%d \n", portN);
                        LPA_SF_stat(TCC_IPC_CMD_IP_STAS_CNT_CAN, (uint8 *)&portN);
                    }
                }
            }
        }
    }
    else
    {
        LPA_SF_CTRL_CLI_Help();
    }
}


