/*
***************************************************************************************************
*
*   FileName : route_cfg.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/**************************************************************************************************
*                                           INCLUDE FILES
**************************************************************************************************/
#include "route_cfg.h"

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/
/*misra_c_2012_rule_7_2_violation:	Numeric literal "2435838778U" is unsigned but does not use a "u" or "U" suffix.*/
/* CAN Converter */
expand_t expandTbl[ROUTING_EXPAND_NUM] = {
    {3U, 0x9126ef33U, 9U, 0x9126de3bU, 5U},
    {1U, 0x40U, 3U, 0x80000050U, 4U},
    {9U, 0x20U, 3U, 0x50U, 5U},
    {7U, 0x80000080U, 2U, 0x11U, 4U},
    {8U, 0x912ff33aU, 10U, 0x720U, 2U}
};

split16_t splitTbl_16[SPLIT16_NUM] = {
    {8U, 0x11U, 2U, 0x12U, 2U, 0x13U},
    {9U, 0x20U, 3U, 0x21U, 4U, 0x22U},
    {10U, 0x31U, 5U, 0x41U, 5U, 0x51U},
    {15U, 0x345U, 7U, 0x80000256U, 8U, 0x80000134U}
};

split24_t splitTbl_24[SPLIT24_NUM] = {
    {13U, 0x111U, 3U, 0x112U, 3U, 0x113U, 3U, 0x114U},
    {10U, 0x9fffffffU, 1U, 0x1U, 2U, 0x2U, 3U, 0x3U}
};

split32_t splitTbl_32[SPLIT32_NUM] = {
    {7U, 0x11U, 1U, 0x11U, 1U, 0x12U, 1U, 0x13U, 1U, 0x14U},
    {10U, 0x330U, 1U, 0x311U, 2U, 0x312U, 3U, 0x313U, 4U, 0x314U}
};

split48_t splitTbl_48[SPLIT48_NUM] = {
    {7U, 0x500U, 2U, 0x501U, 2U, 0x502U, 2U, 0x503U, 2U, 0x504U, 2U, 0x505U, 2U, 0x506U}
};

split64_t splitTbl_64[SPLIT64_NUM] = {
    {10U, 0x732U, 1U, 0x110U, 2U, 0x220U, 3U, 0x330U, 4U, 0x440U, 5U, 0x550U, 4U, 0x660U, 3U, 0x770U, 2U, 0x80000880U}
};
/* CAN Converter */

/* TSNC */
// for eth2can
addrInfo_t np_addrInfo[CANV_ETH2CAN_NUM] = {
    /* Network Processor MAC, Network Processor IP */
    {{0x9cU, 0x65U, 0xeeU, 0x76U, 0xeeU, 0x70U}, {40U, 40U, 40U, 40U}}
};

// for can2eth
/*misra_c_2012_rule_8_4_violation:	Object definition does not have a visible prototype.*/
static const addrInfo_t tpa_dstAddr[TPA_EMAC_NUM] = {
    /* Dst MAC, Dst IP */
    {{0x70U, 0x6DU, 0xCCU, 0xF0U, 0xE7U, 0x01U}, {10U, 10U, 10U, 10U}},
    {{0x70U, 0x6DU, 0xCCU, 0xF0U, 0xE7U, 0x02U}, {10U, 10U, 10U, 20U}},
    {{0x70U, 0x6DU, 0xCCU, 0xF0U, 0xE7U, 0x03U}, {10U, 10U, 10U, 30U}},
    {{0x70U, 0x6DU, 0xCCU, 0xF0U, 0xE7U, 0x04U}, {10U, 10U, 10U, 40U}}
};

can2eth_t can2ethTbl[CAN2ETH_NUM] = {
    /* src_ch, src_id, tpa_dst */
    {1U, 0x800U, tpa_dstAddr[TPA_EMAC_1]}, // 241112 sy.kim
    {2U, 0x999U, tpa_dstAddr[TPA_EMAC_2]} // 241112 sy.kim
};
/* TSNC */

/* IPC */
typedef enum IPC_CORE_INDEX{
    A65AE = 0,
    CM7_0,
    CM7_1,
    CM7_2
}IPC_CORE_INDEX;

ipc_info_t ipcTbl[IPC_NUM] = {
    {1U, 0x33U, IPC_CH_CM7_1_LPA},
    {1U, 0x80000033U, IPC_CH_CM7_1_LPA},
    {1U, 0x200U, IPC_CH_CM7_1_LPA},
    {1U, 0x80000300U, IPC_CH_CM7_1_LPA},
    {2U, 0x200U, IPC_CH_CM7_1_LPA},
    {2U, 0x80000300U, IPC_CH_CM7_1_LPA},
    {1U, 0x259U, IPC_CH_CM7_1_LPA},
    {17U, 0x01U, IPC_CH_CM7_1_LPA}	// LIN1
};
/* IPC */
