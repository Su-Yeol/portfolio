/*
***************************************************************************************************
*
*   FileName : slv_data_router.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include <stdlib.h>
#include <errno.h>
#include <app_cfg.h>
#include "debug.h"
#include "ipc.h"
//#include "lpa_std.h"
#include "slv_framework.h"

#if(SIC_BSP_SUPPORT_IPC_DATA_SEND == 1)
/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/
#define IPC_APP_DBG_ENABLE
#ifdef IPC_APP_DBG_ENABLE
#define IPC_APP_DBG(fmt, args...) mcu_printf(fmt, ## args)
#else
#define IPC_APP_DBG(fmt, args...)
#endif


/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/

static void LPA_SF_App_Sample_Task
(
    void *                              pArg
);

// Need Check Later : Remove to avoid compile warning
//static void SMA_ExternSignal
//(
//    void
//);


static void IPC_IpcCbFunc_CM7_1
(
    uint16                              uhwCmd,
    uint8 *                             pucData,
    uint16                              uhwLength
); // CS : Dangerous Function Cast

static void IPC_IpcCbFunc_CM7_0
(
    uint16                              uhwCmd,
    uint8 *                             pucData,
    uint16                              uhwLength
);

/*misra_c_2012_rule_8_4_violation:	Object definition does not have a visible prototype.*/
static uint8 IPC_send_data[512];
/*misra_c_2012_rule_8_4_violation:	Object definition does not have a visible prototype.*/
//uint8 IPC_receive_data[IPC_SVC_CH_MAX][512];
//uint8 IPC_send_flag = FALSE;

static LpaDataCallback sfLpaDataCB = NULL;
static LpaTsCallback sfLpaTsCB = NULL;
static uint8 CM7_NP_ResponseBuffer[LPA_TO_HOST_SIZE];

static void LPA_SF_CLI_Help(void);
void LPA_SF_msgSend(uint8 protocol, uint8 port, uint32 id, uint8 ext_opMode, uint8 data_len, uint8 *pData);

static void slv_IpcCbFunc_CM7_NP(uint16 uhwCmd, uint8 *pucData, uint16 uhwLength);

static void sf_parse_proc_frame(const uint8 *buffer, uint16 data_length);
static void sf_lpa_rx_setDataCB(LpaDataCallback cbFunc);
static void sf_lpa_rx_setTsCB(LpaTsCallback cbFunc);
static void sf_print_ts_frame_info(const RX_TS_FRAME *rx_ts);
static void sf_print_data_frame_info(const RX_DATA_FRAME *rx_data);
static void sf_print_ts_frame_info(const RX_TS_FRAME *rx_ts);


/*
***************************************************************************************************
*                                         FUNCTIONS
***************************************************************************************************
*/
static void sf_lpa_rx_setDataCB(LpaDataCallback cbFunc)
{
	sfLpaDataCB = cbFunc;
}

static void sf_lpa_rx_setTsCB(LpaTsCallback cbFunc)
{
	sfLpaTsCB = cbFunc;
}

/*misra_c_2012_rule_8_8_violation:	missing static storage modifier for "sf_parse_proc_frame" which has internal linkage*/
static void sf_parse_proc_frame(const uint8 *buffer, uint16 data_length)
{
	uint16 i;
	RX_DATA_FRAME data_frame;
	RX_TS_FRAME ts_frame;

	uint8 rx_frame_type;
	uint8 rx_sourcePort;
	uint16 rx_timeStamp_ns;
	uint32 rx_timeStamp_us_L;
	uint32 rx_timeStamp_us_H;
	uint8 rx_protocol_type;
	uint16 rx_can_id;
	uint16 rx_lin_id;
	uint32 rx_extCan_id;
	uint8 rx_fdf;
	uint8 rx_rtr;
	uint8 rx_ide;
	uint32 route_id;

    //mcu_printf("%s_%d\n", __func__, __LINE__);
	rx_frame_type = buffer[0] & 0x01U;
	rx_sourcePort = ((buffer[0] & 0xFEU) >> 1U) + ((buffer[1] & 0x01U) << 7U);

	rx_timeStamp_ns  = (((uint16)buffer[1] & 0xFEU) >> 1U);
	rx_timeStamp_ns |= (((uint16)buffer[2] & 0x01U) << 7U);
	rx_timeStamp_ns *= 10U;

	rx_timeStamp_us_L = ((uint32)buffer[2] >> 1U);
	rx_timeStamp_us_L |= ((uint32)buffer[3] << 7U);
	rx_timeStamp_us_L |= ((uint32)buffer[4] << 15U);
	rx_timeStamp_us_L |= ((uint32)buffer[5] << 23U);
	rx_timeStamp_us_L |= (((uint32)buffer[6] & 0x01U) << 31U);
	rx_timeStamp_us_H = ((uint32)buffer[6] >> 1U);
	rx_timeStamp_us_H |= ((uint32)buffer[7] << 7U);
	rx_timeStamp_us_H |= ((uint32)buffer[8] << 15U);
	rx_timeStamp_us_H |= ((uint32)buffer[9] << 23U);
	rx_timeStamp_us_H |= (((uint32)buffer[10] & 0x01U) << 31U);

	rx_protocol_type = ((buffer[10] & 0x80U) == 0x80U)?1U:0U;

	rx_can_id = (uint16)buffer[11] + (((uint16)buffer[12] & 0x07U) << 8U);
	rx_lin_id = (uint16)buffer[11] & 0x3FU;
	rx_extCan_id  = (uint32)buffer[11];
	rx_extCan_id |= ((uint32)buffer[12] << 8U);
	rx_extCan_id |= ((uint32)buffer[13] << 16U);
	rx_extCan_id |= (((uint32)buffer[14] & 0x1FU) << 24U);


	rx_fdf = ((buffer[14] & 0x20U) == 0x20U)?1U:0U;
	rx_rtr = ((buffer[14] & 0x40U) == 0x40U)?1U:0U;
	rx_ide = ((buffer[14] & 0x80U) == 0x80U)?1U:0U;

    //mcu_printf("%s_%d type = %d\n", __func__, __LINE__, rx_frame_type);
	if (rx_frame_type == DATA_FRAME)
	{
		data_frame.port = rx_sourcePort;
		data_frame.proto = rx_protocol_type;
		data_frame.ts_us_high = rx_timeStamp_us_H;
		data_frame.ts_us_low = rx_timeStamp_us_L;
		data_frame.ts_ns = rx_timeStamp_ns;
		for(i = 15U; i < data_length; i++)
		{
			data_frame.Data[i-15U] = buffer[i];
 		}
		i = data_length - 15U;
		if (i <= 255U)
		{
			data_frame.data_len = (uint8)i;
		}
		else
		{
			data_frame.data_len = 8U;
		}
		if (rx_protocol_type == PROTOCOL_CAN)
		{
			if (rx_ide == STANDARD_CAN)
			{
				data_frame.ftype = FRAME_TYPE_CAN_BASE;
				if (rx_fdf == CAN_FD)
				{
					data_frame.ftype = FRAME_TYPE_CANFD_BASE;
				}
				data_frame.ID = rx_can_id;
                route_id = data_frame.ID;
			}
			else
			{
				data_frame.ftype = FRAME_TYPE_CAN_EXT;
				if (rx_fdf == CAN_FD)
				{
					data_frame.ftype = FRAME_TYPE_CANFD_EXT;
				}
				data_frame.ID = rx_extCan_id;
                route_id = (data_frame.ID | 0x80000000);
			}
		}
		else
		{
			data_frame.ftype = FRAME_TYPE_LIN_RX;
			data_frame.ID = rx_lin_id;
		}

		if (sfLpaDataCB != NULL)
		{
			sfLpaDataCB(&data_frame);
		}
	}
	else
	{
		ts_frame.port = rx_sourcePort;
		ts_frame.ts_us_high = rx_timeStamp_us_H;
		ts_frame.ts_us_low = rx_timeStamp_us_L;
		ts_frame.ts_ns = rx_timeStamp_ns;

		if (sfLpaTsCB != NULL)
		{
			sfLpaTsCB(&ts_frame);
		}
	}
}

static void sf_print_data_frame_info(const RX_DATA_FRAME *rx_data)
{
	uint8 i;
	if (rx_data != NULL)
	{
		mcu_printf(" ======== PROC Data Frame====================\n");
		mcu_printf(" Protocol: %s, Port:%s, data_len:%d\n",
			(rx_data->proto == PROTOCOL_CAN)?"CAN":"LIN",
			PORT_NAME[rx_data->port],
			rx_data->data_len);
		switch(rx_data->ftype)
		{
			case FRAME_TYPE_CAN_BASE:
				mcu_printf(" CAN_ID:0x%X\n", rx_data->ID);
				break;
			case FRAME_TYPE_CAN_EXT:
				mcu_printf(" CAN_ID(ext):0x%X\n", rx_data->ID);
				break;
			case FRAME_TYPE_CANFD_BASE:
				mcu_printf(" CANFD_ID:0x%X\n", rx_data->ID);
				break;
			case FRAME_TYPE_CANFD_EXT:
				mcu_printf(" CANFD_ID(ext):0x%X\n", rx_data->ID);
				break;
			case FRAME_TYPE_LIN_RX:
				mcu_printf(" LIN_ID:0x%X\n", rx_data->ID);
				break;
			default:
				/**/
				break;
		}
		mcu_printf(" Timestamp: %u_%u(us), %u(ns) / %u(sec)\n",
			rx_data->ts_us_high,
			rx_data->ts_us_low,
			rx_data->ts_ns,
			rx_data->ts_us_low/1000000U);
		mcu_printf(" Data: ");
		for(i = 0U; i < rx_data->data_len; i++)
		{
			mcu_printf("%02x ", rx_data->Data[i]);
		}
		mcu_printf("\n");
	}

}

static void sf_print_ts_frame_info(const RX_TS_FRAME *rx_ts)
{
	if ( rx_ts != NULL)
	{
		mcu_printf(" ======== PROC Timestamp Frame ====================\n");
		mcu_printf(" Port:%s\n", PORT_NAME[rx_ts->port]);
		mcu_printf(" Timestamp: %u_%u(us), %u(ns) / %u(sec)\n",
			rx_ts->ts_us_high,
			rx_ts->ts_us_low,
			rx_ts->ts_ns,
			rx_ts->ts_us_low/1000000U);
	}
}

/*misra_c_2012_rule_8_8_violation:	missing static storage modifier for "LPA_SF_CLI_Help" which has internal linkage*/
static void LPA_SF_CLI_Help(void)
{
	mcu_printf( "=== wrong argument ===\n" );
    mcu_printf( "=== USAGE INFO ===\n\n" );
    mcu_printf( "=== CMD LIST ===\n" );
    mcu_printf( "sftx can send (x) (y) (z): x = port number 1~16, y = CAN ID (0 ~ 2047 -> 7ff), z = data length\n" );
    mcu_printf( "sftx lin send (x) (y) (z) : x = port number 1~8, y = LIN ID (0 ~ 63 -> 3f), z = 't'- transmit, 'r' - receive \n" );
}

void LPA_SF_CLI(uint8 ucArgc, void* const pArgv[])
{
	(void)ucArgc;
    uint8 *pucStr1;
    uint8 *pucStr2;
    uint8 *pucStr3;
    uint8 *pucStr4;
    uint8 *pucStr5;

    pucStr1 = NULL_PTR;
    pucStr2 = NULL_PTR;
    pucStr3 = NULL_PTR;
    pucStr4 = NULL_PTR;
    pucStr5 = NULL_PTR;

    uint8 i;

    uint8 LinOp;
    uint32 LinID;

	uint32 portN;
	uint32 CanID  =0;
    uint32 DataLen = 0;
    uint8 Data[64U];
	sint32 ret;

    for (i = 0 ; i < 64U; i++)
	{
		Data[i] = (i * 4U) + 3U;
	}

    if( pArgv != NULL_PTR )
    {
    	SAL_MemCopy(&pucStr1, &pArgv[0], 4U);
		SAL_MemCopy(&pucStr2, &pArgv[1], 4U);
		SAL_MemCopy(&pucStr3, &pArgv[2], 4U);
		SAL_MemCopy(&pucStr4, &pArgv[3], 4U);
		SAL_MemCopy(&pucStr5, &pArgv[4], 4U);

		if( ( SAL_StrNCmp( pucStr1, ( const uint8 * ) "can", 3, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
		{
			if( ( SAL_StrNCmp( pucStr2, ( const uint8 * ) "send", 4, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
			{
                /*cert_err30_c_violation:	The variable "errno" must be tested before calling function "strtoul".*/
				errno = 0;
				portN = strtoul((int8 *)pucStr3, NULL, 10);
				if ((portN >= 1U) && (portN <= 16U))
				{
                    errno = 0;
					CanID = strtoul((int8 *)pucStr4, NULL, 10);
					if (CanID < 2048U)
					{
                        errno = 0;
						DataLen = strtoul((int8 *)pucStr5, NULL, 10);
						if (DataLen <= 8U)
						{
							mcu_printf("port Number :%d, CAN ID : %d, Data length : %d\n", portN, CanID, DataLen);
							(void)LPA_SF_msgSend(PROTOCOL_CAN, (uint8)portN, CanID, 0, (uint8)DataLen, Data);
						}
					}
				}
			}
		}
        else if( ( SAL_StrNCmp( pucStr1, ( const uint8 * ) "lin", 3, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
		{
			if( ( SAL_StrNCmp( pucStr2, ( const uint8 * ) "send", 4, &ret ) == SAL_RET_SUCCESS ) && ( ret == 0 ) )
			{
                LPA_FRAME_TYPE type;
                LinOp = pucStr5[0];

                if ((LinOp == (uint8)'t') || (LinOp == (uint8)'r'))
                {
                    DataLen = 8U; //fixed length
                    if (LinOp == (uint8)'t') {
                        type = LIN_TX_OPERATON;
                    }
                    else {
                        type = LIN_RX_OPERATON;
                    }

                    errno = 0;
                    portN = strtoul((int8 *)pucStr3, NULL, 10);
                    if (((portN >= 1U) && (portN <= 8U)) && (errno == 0))
                    {
                        errno = 0;
                        LinID = strtoul((int8 *)pucStr4, NULL, 10);
                        if ((LinID < 64U) && (errno == 0))
                        {
                            errno = 0;
                            mcu_printf("port Number :%d, LIN ID : %d, Data length : %d\n", portN, LinID, DataLen);
                            (void)LPA_SF_msgSend(PROTOCOL_LIN, (uint8)portN, LinID, type, (uint8)DataLen, Data);
                        }
                    }
                }
                else
                {
                    mcu_printf("wrong argument only 't' or 'r'");
                }
            }
        }

	}
	else
	{
		LPA_SF_CLI_Help();
	}
}

/* CM7 -> NP */
void LPA_SF_msgSend(uint8 protocol, uint8 port, uint32 id, uint8 ext_opMode, uint8 data_len, uint8 *pData)
{
//    uint16 port_cmd;
    uint16 ipc_cmd1 = TCC_IPC_CMD_CAN_MSG;

	if ((pData != NULL) && ( data_len <= 8U))
	{
 //       port_cmd = port;

        if(protocol == PROTOCOL_CAN)
        {
            build_CANHeader(&IPC_send_data[0], TIMESTAMP_ON, (uint32)id, 0U, ext_opMode, 0U);
            mcu_printf("[%s_%d] port=%d, Id=0x%x(ext:%c), size=%d\n", __func__, __LINE__, port, id, (ext_opMode==1U)?'Y':'N', data_len);
        }
        else if(protocol == PROTOCOL_LIN)
        {
        	ipc_cmd1 = TCC_IPC_CMD_LIN_MSG;
            build_LINHeader(&IPC_send_data[0], TIMESTAMP_ON, ext_opMode, 1U, data_len, id);
            mcu_printf("[%s_%d] port=%d, Id=0x%x(%cx), size=%d\n", __func__, __LINE__, port, id, (ext_opMode==LIN_TX_OPERATON)?'T':'R', data_len);
            //port_cmd |= 0x100;
        }
        else
        {
        	/**/
        }
		SAL_MemCopy(&IPC_send_data[LPA_TX_HDR_SIZE], pData, data_len);
        /*misra_c_2012_rule_10_6_violation:	Assigning composite expression "5U + data_len" of width 8 to a target of width 16.*/
		(void)IPC_SendPacket(IPC_CH_CM7_NP_LPA, ipc_cmd1, (uint16)port, &IPC_send_data[0], LPA_TX_HDR_SIZE + (uint16)data_len);
	}
}
/* _CM7 -> NP */

/* NP -> CM7 */
static void slv_IpcCbFunc_CM7_NP(uint16 uhwCmd, uint8 *pucData, uint16 uhwLength)
{
//	uint16 i = 0;

//	LPA_TX_MESSAGE msg;

//	mcu_printf("uhwCmd : %d \n",uhwCmd);

    if (pucData != NULL_PTR)
    {
        //mcu_printf("can received\n ",__FUNCTION__); //QAC
        //mcu_printf("length: %d\n ",uhwLength);

        SAL_MemCopy(&CM7_NP_ResponseBuffer[0], pucData, uhwLength);

        sf_parse_proc_frame(&CM7_NP_ResponseBuffer[0], uhwCmd);

        mcu_printf("\n"); //QAC

    }
    else
    {
		mcu_printf("Empty Data received \n"); //QAC
    }

}
/* _NP -> CM7 */

static void LPA_SF_App_Sample_Task(void * pArg)
{
    (void)pArg;

	IPC_RegisterCbFunc(IPC_CH_CM7_NP_LPA, (uint8)TCC_IPC_CMD_CAN_MSG, (IPCCallback)&slv_IpcCbFunc_CM7_NP, NULL_PTR, NULL_PTR);
	IPC_RegisterCbFunc(IPC_CH_CM7_NP_LPA, (uint8)TCC_IPC_CMD_LIN_MSG, (IPCCallback)&slv_IpcCbFunc_CM7_NP, NULL_PTR, NULL_PTR);

	sf_lpa_rx_setDataCB(sf_print_data_frame_info);
	sf_lpa_rx_setTsCB(sf_print_ts_frame_info);

	while(1)
	{

	    (void)SAL_TaskSleep(100);
	}

}

void LPA_SF_CreateAppTask(void)
{
    static uint32 IPCAppTaskID;
    static uint32 IPCAppTaskStk[ACFG_TASK_MEDIUM_STK_SIZE];

    (void)SAL_TaskCreate(&IPCAppTaskID,
                         (const uint8 *)"sfAppsample",
                         (SALTaskFunc)&LPA_SF_App_Sample_Task,
                         &IPCAppTaskStk[0],
                         ACFG_TASK_MEDIUM_STK_SIZE,
                         7, NULL_PTR);

}
#endif
