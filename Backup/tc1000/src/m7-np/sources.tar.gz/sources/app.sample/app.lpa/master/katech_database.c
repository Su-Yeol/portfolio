#include "katech_database.h"
#include "debug.h" // 241202 sy.kim
#include <memory.h>
#define KATECH_APP_BUFF_SIZE 2

DB_IONIQ_RxCAN0_YRS_01_10ms DB_CAN0_YRS_01_10ms[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN0_IEB_01_10ms DB_CAN0_IEB_01_10ms[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN0_WHL_01_10ms DB_CAN0_WHL_01_10ms[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN0_SAS_01_10ms DB_CAN0_SAS_01_10ms[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN0_Unknown_0x130 DB_CAN0_Unknown_0x130[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN0_ESC_03_20ms DB_CAN0_ESC_03_20ms[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN0_CLU_01_20ms DB_CAN0_CLU_01_20ms[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN0_CLU_02_100ms DB_CAN0_CLU_02_100ms[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN0_RR_C_RDR_01_50ms DB_CAN0_RR_C_RDR_01_50ms[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN1_Unknown_0x35 DB_CAN1_Unknown_0x35[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN1_WHL_01_10ms DB_CAN1_WHL_01_10ms[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN1_ESC_03_20ms DB_CAN1_ESC_03_20ms[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN1_CLU_01_20ms DB_CAN1_CLU_01_20ms[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN1_CLU_01_20ms2 DB_CAN1_CLU_01_20ms2[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN1_RR_C_RDR_02_50ms DB_CAN1_RR_C_RDR_02_50ms[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN1_SWRC_03_20ms DB_CAN1_SWRC_03_20ms[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN1_MFSW_01_200ms DB_CAN1_MFSW_01_200ms[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN2_MDPS_01_10ms DB_CAN2_MDPS_01_10ms[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN2_Unknown_0x377 DB_CAN2_Unknown_0x377[KATECH_APP_BUFF_SIZE];
DB_IONIQ_RxCAN3_ADAS_CMD_32_50ms DB_CAN3_ADAS_CMD_32_50ms[KATECH_APP_BUFF_SIZE];

uint8_t cnt_CAN0_YRS_01_10ms;
uint8_t cnt_CAN0_IEB_01_10ms;
uint8_t cnt_CAN0_WHL_01_10ms;
uint8_t cnt_CAN0_SAS_01_10ms;
uint8_t cnt_CAN0_Unknown_0x130;
uint8_t cnt_CAN0_ESC_03_20ms;
uint8_t cnt_CAN0_CLU_01_20ms;
uint8_t cnt_CAN0_CLU_02_100ms;
uint8_t cnt_CAN0_RR_C_RDR_01_50ms;
uint8_t cnt_CAN1_Unknown_0x35;
uint8_t cnt_CAN1_WHL_01_10ms;
uint8_t cnt_CAN1_ESC_03_20ms;
uint8_t cnt_CAN1_CLU_01_20ms;
uint8_t cnt_CAN1_CLU_01_20ms2;
uint8_t cnt_CAN1_RR_C_RDR_02_50ms;
uint8_t cnt_CAN1_SWRC_03_20ms;
uint8_t cnt_CAN1_MFSW_01_200ms;
uint8_t cnt_CAN2_MDPS_01_10ms;
uint8_t cnt_CAN2_Unknown_0x377;
uint8_t cnt_CAN3_ADAS_CMD_20_20ms;
uint8_t DB_IONIQ_POS[30]={0,};




void *DB_IONIQ_SET[20]={
		DB_CAN0_YRS_01_10ms,
		DB_CAN0_IEB_01_10ms,
		DB_CAN0_WHL_01_10ms,
		DB_CAN0_SAS_01_10ms,
		DB_CAN0_Unknown_0x130,
		DB_CAN0_ESC_03_20ms,
		DB_CAN0_CLU_01_20ms,
		DB_CAN0_CLU_02_100ms,
		DB_CAN0_RR_C_RDR_01_50ms,
		DB_CAN1_Unknown_0x35,
		DB_CAN1_WHL_01_10ms,
		DB_CAN1_ESC_03_20ms,
		DB_CAN1_CLU_01_20ms,
		DB_CAN1_CLU_01_20ms2,
		DB_CAN1_RR_C_RDR_02_50ms,
		DB_CAN1_SWRC_03_20ms,
		DB_CAN1_MFSW_01_200ms,
		DB_CAN2_MDPS_01_10ms,
		DB_CAN2_Unknown_0x377,
		DB_CAN3_ADAS_CMD_32_50ms
};


void *katech_data_base_get_addr(uint32_t name_db, uint8_t pos)
{
	switch(name_db)
	{
		case KATECH_NAME_DB_IONIQ_RxCAN0_YRS_01_10ms:
			return &DB_CAN0_YRS_01_10ms[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN0_IEB_01_10ms:
			return &DB_CAN0_IEB_01_10ms[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN0_WHL_01_10ms:
			return &DB_CAN0_WHL_01_10ms[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN0_SAS_01_10ms:
			return &DB_CAN0_SAS_01_10ms[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN0_Unknown_0x130:
			return &DB_CAN0_Unknown_0x130[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN0_ESC_03_20ms:
			return &DB_CAN0_ESC_03_20ms[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN0_CLU_01_20ms:
			return &DB_CAN0_CLU_01_20ms[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN0_CLU_02_100ms:
			return &DB_CAN0_CLU_02_100ms[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN0_RR_C_RDR_01_50ms:
			return &DB_CAN0_RR_C_RDR_01_50ms[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN1_Unknown_0x35:
			return &DB_CAN1_Unknown_0x35[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN1_WHL_01_10ms:
			return &DB_CAN1_WHL_01_10ms[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN1_ESC_03_20ms:
			return &DB_CAN1_ESC_03_20ms[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN1_CLU_01_20ms:
			return &DB_CAN1_CLU_01_20ms[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN1_CLU_01_20ms2:
			return &DB_CAN1_CLU_01_20ms2[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN1_RR_C_RDR_02_50ms:
			return &DB_CAN1_RR_C_RDR_02_50ms[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN1_SWRC_03_20ms:
			return &DB_CAN1_SWRC_03_20ms[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN1_MFSW_01_200ms:
			return &DB_CAN1_MFSW_01_200ms[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN2_MDPS_01_10ms:
			return &DB_CAN2_MDPS_01_10ms[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN2_Unknown_0x377:
			return &DB_CAN2_Unknown_0x377[pos];
			break;
		case KATECH_NAME_DB_IONIQ_RxCAN3_ADAS_CMD_32_50ms:
			return &DB_CAN3_ADAS_CMD_32_50ms[pos];
			break;

		default:
			break;
	}


}

void katech_database_update(uint32_t name_db)
{
	uint8_t pos;
	pos=(DB_IONIQ_POS[name_db]+1)%KATECH_APP_BUFF_SIZE;
	DB_IONIQ_POS[name_db]=pos;
}

void *katech_database_write_addr_get(uint32_t name_db)
{	
	uint8_t pos;
	pos=(DB_IONIQ_POS[name_db]+1)%KATECH_APP_BUFF_SIZE;
	return katech_data_base_get_addr(name_db,pos);
}
void *katech_database_read_addr_get(uint32_t name_db)
{
	uint8_t pos;
	pos=(DB_IONIQ_POS[name_db]);
	return katech_data_base_get_addr(name_db,pos);

}
float data_baseAX;
void to_autoware(KATECH_CONTROL_V2A *data)
{
	DB_IONIQ_RxCAN0_Unknown_0x130 *dbaddr;
	DB_IONIQ_RxCAN0_YRS_01_10ms *this_DB_CAN0_YRS_01_10ms;
	DB_IONIQ_RxCAN0_WHL_01_10ms *whl_db;
	DB_IONIQ_RxCAN0_SAS_01_10ms *sas_db;
	DB_IONIQ_RxCAN3_ADAS_CMD_32_50ms *adas_db;
	DB_IONIQ_RxCAN0_CLU_01_20ms *clu_db;
	DB_IONIQ_RxCAN1_Unknown_0x35 *unknown_db;
	DB_IONIQ_RxCAN1_MFSW_01_200ms *mfsw_db;
	DB_IONIQ_RxCAN2_MDPS_01_10ms *mdps_db;


	dbaddr = katech_database_read_addr_get(KATECH_NAME_DB_IONIQ_RxCAN0_Unknown_0x130);
	data->GearReport = dbaddr->GearPosition;


	this_DB_CAN0_YRS_01_10ms = katech_database_read_addr_get(KATECH_NAME_DB_IONIQ_RxCAN0_YRS_01_10ms);
	data->HeadingRate = this_DB_CAN0_YRS_01_10ms->YawRate;

	clu_db = katech_database_read_addr_get(KATECH_NAME_DB_IONIQ_RxCAN0_CLU_01_20ms);
	data->LateralVelocity = 0;
	data->LongitudinalVelocity = clu_db->DisplaySpd;

	sas_db=katech_database_read_addr_get(KATECH_NAME_DB_IONIQ_RxCAN0_SAS_01_10ms);
	data->SteeringTireAngle=sas_db->StrAngle;



	mfsw_db = katech_database_read_addr_get(KATECH_NAME_DB_IONIQ_RxCAN1_MFSW_01_200ms);
	if(mfsw_db->LeftTurnFlag==1)
		data->TurnIndicatorsReport=1;
	else if(mfsw_db->RightTurnFlag==1)
		data->TurnIndicatorsReport=2;
	else
		data->TurnIndicatorsReport=0;

	mdps_db = katech_database_read_addr_get(KATECH_NAME_DB_IONIQ_RxCAN2_MDPS_01_10ms);
	data->ControlMode=mdps_db->MDPS_PaModeSta;


	data->energy_level=100;
	data->HazardLightsReport=1;

}


void katech_get_vehicle_interface_info(KATECH_VEHICLE_INTERFACE_INFO *data)
{
	DB_IONIQ_RxCAN0_Unknown_0x130 *dbaddr;
	DB_IONIQ_RxCAN0_YRS_01_10ms *this_DB_CAN0_YRS_01_10ms;
	DB_IONIQ_RxCAN0_WHL_01_10ms *whl_db;
	DB_IONIQ_RxCAN0_SAS_01_10ms *sas_db;
	DB_IONIQ_RxCAN3_ADAS_CMD_32_50ms *adas_db;
	DB_IONIQ_RxCAN0_CLU_01_20ms *clu_db;
	DB_IONIQ_RxCAN1_Unknown_0x35 *unknown_db;
	DB_IONIQ_RxCAN1_MFSW_01_200ms *mfsw_db;
	DB_IONIQ_RxCAN2_MDPS_01_10ms *mdps_db;


	dbaddr = katech_database_read_addr_get(KATECH_NAME_DB_IONIQ_RxCAN0_Unknown_0x130);
	data->GearState = dbaddr->GearPosition;


	this_DB_CAN0_YRS_01_10ms = katech_database_read_addr_get(KATECH_NAME_DB_IONIQ_RxCAN0_YRS_01_10ms);
	data->YawRate = this_DB_CAN0_YRS_01_10ms->YawRate;
	data->LateralAccel = this_DB_CAN0_YRS_01_10ms->LatAccel;
	data->LongitudinalAccel = this_DB_CAN0_YRS_01_10ms->LongAccel;

	whl_db = katech_database_read_addr_get(KATECH_NAME_DB_IONIQ_RxCAN0_WHL_01_10ms);
	data->WheelSpeedFL = whl_db->WheelSpdFL;
	data->WheelSpeedFR = whl_db->WheelSpdFR;
	data->WheelSpeedRL = whl_db->WheelSpdRL;
	data->WheelSpeedRR = whl_db->WheelSpdRR;
	data->WheelPulseFL = whl_db->WheelPulseFL;
	data->WheelPulseFR = whl_db->WheelPulseFR;
	data->WheelPulseRL = whl_db->WheelPulseRL;
	data->WheelPulseRR = whl_db->WheelPulseRR;

	sas_db=katech_database_read_addr_get(KATECH_NAME_DB_IONIQ_RxCAN0_SAS_01_10ms);
	data->HandleAngle=sas_db->StrAngle;
	data->HandleSpd=sas_db->StrSpeed;

	adas_db=katech_database_read_addr_get(KATECH_NAME_DB_IONIQ_RxCAN3_ADAS_CMD_32_50ms);
	data->Distance = adas_db->FrontSCC_ObjDstVal;
	data->Distance = data->Distance*0.1;
	data->RelativeVelocity = adas_db->RadarSCC_ObjRelSpdVal;

	clu_db = katech_database_read_addr_get(KATECH_NAME_DB_IONIQ_RxCAN0_CLU_01_20ms);
	data->ClusterVelocity = clu_db->DisplaySpd;

	unknown_db = katech_database_read_addr_get(KATECH_NAME_DB_IONIQ_RxCAN1_Unknown_0x35);
	data->AccelState = unknown_db->AccelAct;

	mfsw_db = katech_database_read_addr_get(KATECH_NAME_DB_IONIQ_RxCAN1_MFSW_01_200ms);
	data->LeftTurnSwitch = mfsw_db->LeftTurnFlag;
	data->RightTurnSwitch = mfsw_db->RightTurnFlag;

	mdps_db = katech_database_read_addr_get(KATECH_NAME_DB_IONIQ_RxCAN2_MDPS_01_10ms);
	data->MDPSmode=mdps_db->MDPS_PaModeSta;
}

KATECH_CONTROL_A2V katech_vehicle_interface_a2v[KATECH_APP_BUFF_SIZE];
uint8_t cnt_katech_vehicle_interface_control=0;
void katech_set_vehicle_interface_control(KATECH_CONTROL_A2V *data)
{
	int pos;

	pos= (cnt_katech_vehicle_interface_control+1)%KATECH_APP_BUFF_SIZE;
	memcpy(&katech_vehicle_interface_a2v[pos],data,sizeof(KATECH_CONTROL_A2V));
	cnt_katech_vehicle_interface_control = pos;
}

void katech_get_vehicle_interface_control(KATECH_CONTROL_A2V *data)
{
	int pos;

	pos= (cnt_katech_vehicle_interface_control);
	data->Accel=katech_vehicle_interface_a2v[pos].Accel;
	data->SteeringAngle=katech_vehicle_interface_a2v[pos].SteeringAngle;
}

KATECH_CONTROL_A2V *katech_get_addr_vehicle_interface_control(void)
{
	int pos;

	pos= (cnt_katech_vehicle_interface_control);
	return &katech_vehicle_interface_a2v[pos];

}


