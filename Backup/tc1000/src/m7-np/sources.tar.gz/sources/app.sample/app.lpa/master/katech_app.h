/*
 * katech_llce.h
 *
 *  Modified on: 2024. 11. 29.
 *      Author: sy.kim
 */

#ifndef KATECH_LLCE_H_
#define KATECH_LLCE_H_


#include "stubs.h"
#include "Can_43_LLCE.h"
#include "PlatformInit.h"
#include "Llce_Firmware_Load.h"
#include "can_common.h"
#include "S32G274A_COMMON.h"
#include "Can_43_LLCE_Cfg.h"

#define KATECH_CAN_DATA_BUFF_SIZE 0x20


struct KATECH_CAN_DATA{
    uint32 CanId; /**< @brief Standard/Extended CAN ID of CAN L-PDU. */

    uint16  Hoh; /**< @brief ID of the corresponding Hardware Object Range */

    uint8 ControllerId; /**< @brief ControllerId provided by CanIf clearly
                                            identify the corresponding controller */
    uint8 dlc;

    uint8 payload[64];

};
#pragma pack(push, 4)
typedef struct
{
	uint8 ch;
	uint8 hoh;
    Can_IdType id; /**< @brief CAN L-PDU = Data Link Layer Protocol Data Unit.
                                             Consists of Identifier, DLC and Data(SDU)  It is
                                             uint32 for CAN_EXTENDEDID=STD_ON, else is uint16.
                                             */
    PduIdType swPduHandle; /**< @brief The L-PDU Handle = defined and placed
                                                     inside the CanIf module layer. Each handle
                                                     represents an L-PDU, which is a constant
                                                     structure with information for Tx/Rx
                                                     processing. */
    uint8 length; /**< @brief DLC = Data Length Code (part of L-PDU that describes
                                            the SDU length). */
    uint8 sdu[64]; /**< @brief CAN L-SDU = Link Layer Service Data
                                                          Unit. Data that is transported inside
                                                          the L-PDU. */
} KATECH_Canfd_PduType;
#pragma pack(pop)

struct KATECH_SW_CAN_BUFF{
	uint8 hoh;
	uint8 ch;
	Can_PduType pdu;
};

struct KATECH_SW_CAN_BUFF_BOX{

	uint16 cnt_write;
	uint16 cnt_read;
	struct KATECH_SW_CAN_BUFF buff[KATECH_CAN_DATA_BUFF_SIZE];
	//struct KATECH_CAN_DATA data[KATECH_CAN_DATA_BUFF_SIZE];
};


typedef struct
{
	uint16 cnt_write;
	uint16 cnt_read;
	KATECH_Canfd_PduType buff[KATECH_CAN_DATA_BUFF_SIZE];
}KATECH_CANFD_PDU_BUFF;


void katech_llce_init(void);
int katech_llce_check_bus_err(void);

Std_ReturnType katech_llce_can_write( Can_HwHandleType Hth, const Can_PduType * PduInfo);
KATECH_Canfd_PduType *katech_llce_can_pdu_read( KATECH_Canfd_PduType * rxpdu);

#endif /* KATECH_LLCE_H_ */
