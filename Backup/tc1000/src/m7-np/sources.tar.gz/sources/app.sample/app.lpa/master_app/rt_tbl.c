/*
***************************************************************************************************
*
*   FileName : rt_tbl.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/**************************************************************************************************
*                                           INCLUDE FILES
**************************************************************************************************/
#include "rt_tbl.h"
#include "route_cfg.h"

/**************************************************************************************************
*                                             FUNCTIONS
**************************************************************************************************/
void add_CANC_routeTable(void)
{
    uint32 i = 0;

    for(i = 0; i < ROUTING_EXPAND_NUM; i++)
    {
        frm_build_routeTable(expandTbl[i].src_ch, expandTbl[i].src_id, CANC);
    }

    for(i = 0; i < SPLIT16_NUM; i++)
    {
        frm_build_routeTable(splitTbl_16[i].src_ch, splitTbl_16[i].src_id, CANC);
    }

    for(i = 0; i < SPLIT24_NUM; i++)
    {
        frm_build_routeTable(splitTbl_24[i].src_ch, splitTbl_24[i].src_id, CANC);
    }

    for(i = 0; i < SPLIT32_NUM; i++)
    {
        frm_build_routeTable(splitTbl_32[i].src_ch, splitTbl_32[i].src_id, CANC);
    }

    for(i = 0; i < SPLIT48_NUM; i++)
    {
        frm_build_routeTable(splitTbl_48[i].src_ch, splitTbl_48[i].src_id, CANC);
    }

    for(i = 0; i < SPLIT64_NUM; i++)
    {
        frm_build_routeTable(splitTbl_64[i].src_ch, splitTbl_64[i].src_id, CANC);
    }
}

void add_TSNC_routeTable(void)
{
    uint32 i = 0;

    for(i = 0; i < CAN2ETH_NUM; i++)
    {
        frm_build_routeTable(can2ethTbl[i].src_ch, can2ethTbl[i].src_id, TSNC);
    }
}

void add_IPC_routeTable(void)
{
    uint32 i = 0;
    for(i = 0; i < IPC_NUM; i++)
    {
        frm_build_routeTable(ipcTbl[i].src_ch, ipcTbl[i].src_id, IPC);
    }
}
