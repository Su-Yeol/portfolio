/*
***************************************************************************************************
*
*   FileName : app_tsnc.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef DEMO_TSNC_H
#define DEMO_TSNC_H

#include "sal_com.h"
#include "mst_framework.h"
#include "route_cfg.h"

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/
#define TSNC_TASK_STK_SIZE          (512)

extern void TSNC_Init(void);

#define VLAN_ETH_TYPE   0x8100
/* Ethernet Header offset */
/*cert_dcl37_c_violation:	The reserved identifier "ETH_DMAC", which is reserved for future library directions in errno.h, is defined.*/
//#define ETH_DMAC    6
//#define ETH_SMAC    12

/* Ethernet Payload offset */
#if 0
#define CAN_CHANNEL 28
#define CAN_EXTID   29
#define CAN_ID      30
#define CAN_DLC     34
#define CAN_DATA    35
#endif
/*cert_dcl37_c_violation:	The reserved identifier "ETH_HEAD_SIZE", which is reserved for future library directions in errno.h, is defined.*/
//#define ETH_HEAD_SIZE             14
#define IP_UDP_HEAD_SIZE          28
#define CAN_HEAD_SIZE             9

#if 1
typedef struct IPHeader
{
    uint8 versionHeaderLength;        /*  0 + 1 =  1 */
    uint8 service;                    /*  1 + 1 =  2 */
    uint8 length[2];                  /*  2 + 2 =  4 */
    uint8 identification[2];          /*  4 + 2 =  6 */
    uint8 fragmentOffset[2];          /*  6 + 2 =  8 */
    uint8 timeToLive;                 /*  8 + 1 =  9 */
    uint8 protocol;                   /*  9 + 1 = 10 */
    uint8 headerChecksum[2];          /* 10 + 2 = 12 */
    uint8 srcIPAddr[4];               /* 12 + 4 = 16 */
    uint8 dstIPAddr[4];               /* 16 + 4 = 20 */
} IPHeader_t;

typedef struct UDPHeader
{
    uint8 srcPort[2];                   /* 0 + 2 = 2 */
    uint8 dstPort[2];                   /* 2 + 2 = 4 */
    uint8 length[2];                    /* 4 + 2 = 6 */
    uint8 checksum[2];                  /* 6 + 2 = 8 */
} UDPHeader_t;
#endif

typedef struct TransCANMsg
{
    uint8 ecuId;
    uint8 extId;
    uint8 id[4];
//    uint32 id;
    uint8 dlc;
    uint8 data[64U];
} TransCANMsg_t;

typedef struct EthFrame
{
    uint8 dst[6];
    uint8 src[6];
    uint8 type[2];
	IPHeader_t ipHeader;
	UDPHeader_t udpHeader;
   	TransCANMsg_t payload;
    //uint8 data[1500];
} EthFrame_t;

typedef struct CANMessage
{
    uint8 portNum;                  // ECU ID == channel ID
    uint32 mId;
    uint8 mFDFormat;                // FDF
    uint8 mRemoteTransmitRequest;   // RTR
    uint8 mExtendedId;              // IDE
    uint8 mBitRateSwitching;        // BRS
    uint8 mData[CAN_DATA_LENGTH_SIZE];
} CANMessage_t;

/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/
void cb_tsnc_can_to_eth_cnvt(const CNVT_CAN_DATA *can_data);
void cb_tsnc_eth_to_can_cnvt(const TSNC_ETH_DATA *eth_data);
#endif /* DEMO_TSNC_H */

