/*
***************************************************************************************************
*
*   FileName : route_cfg.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef ROUTE_CFG_H
#define ROUTE_CFG_H

/**************************************************************************************************
*                                           INCLUDE FILES
**************************************************************************************************/
#include "mst_framework.h"

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/
/*cert_dcl37_c_violation:	The reserved identifier "EXPAND_NUM", which is reserved for future library directions in errno.h, is defined.*/
#define ROUTING_EXPAND_NUM      5U
#define SPLIT16_NUM     4U
#define SPLIT24_NUM     2U
#define SPLIT32_NUM     2U
#define SPLIT48_NUM     1U
#define SPLIT64_NUM     1U

/*cert_dcl37_c_violation:	The reserved identifier "ETH2CAN_NUM", which is reserved for future library directions in errno.h, is defined.*/
#define CANV_ETH2CAN_NUM     1U
#define TPA_EMAC_NUM    4U
#define CAN2ETH_NUM     6U
#define IPC_NUM         2U

/* TSNC */
typedef enum TPA_ADDR_INDEX {
    TPA_EMAC_1 = 0,
    TPA_EMAC_2,
    TPA_EMAC_3,
    TPA_EMAC_4
}TPA_ADDR_INDEX;

typedef struct addrInfo {
    uint8 dstMac[6];
    uint8 dstIp[4];
} addrInfo_t;

typedef struct can2eth {
    uint8 src_ch;
    uint32 src_id;
    addrInfo_t tpa_dst;
} can2eth_t;

/* CANC */
typedef struct expand {
    uint8 src_ch;
    uint32 src_id;
    uint8 dst_ch;
    uint32 dst_id;
    uint8 period;
} expand_t;

typedef struct split16 {
    uint8 src_ch;
    uint32 src_id;
    uint8 dst_1ch;
    uint32 dst_1id;
    uint8 dst_2ch;
    uint32 dst_2id;
} split16_t;

typedef struct split24 {
    uint8 src_ch;
    uint32 src_id;
    uint8 dst_1ch;
    uint32 dst_1id;
    uint8 dst_2ch;
    uint32 dst_2id;
    uint8 dst_3ch;
    uint32 dst_3id;
} split24_t;

typedef struct split32 {
    uint8 src_ch;
    uint32 src_id;
    uint8 dst_1ch;
    uint32 dst_1id;
    uint8 dst_2ch;
    uint32 dst_2id;
    uint8 dst_3ch;
    uint32 dst_3id;
    uint8 dst_4ch;
    uint32 dst_4id;
} split32_t;

typedef struct split48 {
    uint8 src_ch;
    uint32 src_id;
    uint8 dst_1ch;
    uint32 dst_1id;
    uint8 dst_2ch;
    uint32 dst_2id;
    uint8 dst_3ch;
    uint32 dst_3id;
    uint8 dst_4ch;
    uint32 dst_4id;
    uint8 dst_5ch;
    uint32 dst_5id;
    uint8 dst_6ch;
    uint32 dst_6id;
} split48_t;

typedef struct split64 {
    uint8 src_ch;
    uint32 src_id;
    uint8 dst_1ch;
    uint32 dst_1id;
    uint8 dst_2ch;
    uint32 dst_2id;
    uint8 dst_3ch;
    uint32 dst_3id;
    uint8 dst_4ch;
    uint32 dst_4id;
    uint8 dst_5ch;
    uint32 dst_5id;
    uint8 dst_6ch;
    uint32 dst_6id;
    uint8 dst_7ch;
    uint32 dst_7id;
    uint8 dst_8ch;
    uint32 dst_8id;
} split64_t;
/* CANC */

typedef struct ipc_info{
    uint8 src_ch;
    uint32 src_id;
/* cert_exp37_c_violation:	Calling function "IPC_SendPacket(IPCSvcCh_t, uint16, uint16, uint8 const *, uint16)" with the argument "ipcTbl[i].dst_core", which has an incompatible type "IPC_CORE_INDEX" instead of "IPCSvcCh_t".*/
    IPCSvcCh_t dst_core;
}ipc_info_t;


/**************************************************************************************************
*                                          global VARIABLES
**************************************************************************************************/

/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/
extern expand_t expandTbl[];
extern split16_t splitTbl_16[];
extern split24_t splitTbl_24[];
extern split32_t splitTbl_32[];
extern split48_t splitTbl_48[];
extern split64_t splitTbl_64[];

#define CANC_NUM    (ROUTING_EXPAND_NUM + SPLIT16_NUM + SPLIT24_NUM + SPLIT32_NUM + SPLIT48_NUM + SPLIT64_NUM)
extern can2eth_t can2ethTbl[];
extern addrInfo_t np_addrInfo[];

extern ipc_info_t ipcTbl[];

#endif /* ROUTE_CFG_H */
