/*
***************************************************************************************************
*
*   FileName : lpa_framework.h
*
*   Copyright (c) Telechips Inc.
*
*   Description : API collection common to master and slave framework
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef LPA_FRAMEWORK_H 
#define LPA_FRAMEWORK_H

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/
/************************************** LPA Register Address ***********************************/
#define	LPA_REG_ADDR_IP_VER			(0x0001U)
#define	LPA_REG_ADDR_STATE_REG		(0x0002U)
#define	LPA_REG_ADDR_ID_REG1		(0x0003U)
#define	LPA_REG_ADDR_INIT_VECTOR	(0x0004U)
#define	LPA_REG_ADDR_INIT_COUNT		(0x0005U)
#define	LPA_REG_ADDR_CAN_PORT_BASE	(0x0130U)
#define	LPA_REG_ADDR_LIN_PORT_BASE	(LPA_REG_ADDR_CAN_PORT_BASE + 128U)
#define	LPA_REG_ADDR_PORT_ATTR_BASE	(0x0200U)

/* IDE */
#define STANDARD_CAN		(0U)

/* FDF */
#define CLASSICAL_CAN		(0U)
#define CAN_FD				(1U)

#define	TIMESTAMP_ON			(0U)
#define	TIMESTAMP_OFF			(1U)

#define LPA_TO_HOST_SIZE		(132U)
#define LPA_TO_HOST_HEAD_SIZE	(15U)    // 1+8+72+6+1+29+1+1+1 = 120 bits, 120 / 8 = 15 bytes

/* frame type*/
#define	DATA_FRAME			(1U)
#define	TIMESTAMP_FRAME		(0U)

/*
***********************************************************************************
*   M7 -> NP
***********************************************************************************
*/
/* CMD 1 */
#define TCC_IPC_CMD_CAN_MSG                 (0x10u)
#define TCC_IPC_CMD_LIN_MSG                 (0x11u)
#define TCC_IPC_CMD_IP_CTRL                 (0x20u)
#define TCC_IPC_CMD_IP_STAS                 (0x30u)
#define TCC_IPC_CMD_MCAL_CAN				(0x40u)
#define TCC_IPC_CMD_MCAL_LIN				(0x41u)

/* CMD 2 */
/* TCC_IPC_CMD_MSG_CAN - The message transfer function is port number */
#define TCC_IPC_CMD_MSG_LIN                 (0x0100u)

/* TCC_IPC_CMD_IP_CTRL */
#define TCC_IPC_CMD_IP_CTRL_RESET           (0x0100u)
#define TCC_IPC_CMD_IP_CTRL_CLK_CAN         (0x0200u)
#define TCC_IPC_CMD_IP_CTRL_CLK_LIN         (0x0201u)
#define TCC_IPC_CMD_IP_CTRL_TYPE            (0x0202u)
#define TCC_IPC_CMD_IP_CTRL_CKSUM           (0x0203u)
#define TCC_IPC_CMD_IP_CTRL_AUTORX          (0x0204u)
#define TCC_IPC_CMD_IP_CTRL_ROUTE_ADD       (0x0205u)
#define TCC_IPC_CMD_IP_CTRL_TRNS_ADD        (0x0206u)
#define TCC_IPC_CMD_IP_CTRL_INITIAL         (0x0300u)
#define TCC_IPC_CMD_IP_CTRL_TRCV_SET_MODE	(0x0301u)
#define TCC_IPC_CMD_IP_CTRL_QUEUE_FINISHED	(0x0302u)

/* TCC_IPC_CMD_IP_STAS */
#define TCC_IPC_CMD_IP_STAS_VAL             (0x0100u)
#define TCC_IPC_CMD_IP_STAS_CNT_CAN         (0x0201u)
#define TCC_IPC_CMD_IP_STAS_CNT_LIN         (0x0202u)

/* TCC_IPC_CMD_MCAL_X */
#define TCC_IPC_CMD_MCAL_TX_CONFIRM         (0x0001)

/*
***********************************************************************************
*   NP -> M7
***********************************************************************************
*/
/* CMD 1 */
#define TCC_IPC_CMD_RESP                    (0x20u)
#define TCC_IPC_CMD_CAN_STAS                (0x30u)
#define TCC_IPC_CMD_LIN_STAS                (0x31u)

/* CMD 2 */
#define TCC_IPC_CMD_RESP_VAL                (0x0001u)
#define TCC_IPC_CMD_RESP_CNT                (0x0002u)

#define TCC_IPC_CMD_STAS_SEND               (0x0100u)

typedef enum {
	FRAME_TYPE_CAN_BASE = 0,
	FRAME_TYPE_CAN_EXT,
	FRAME_TYPE_CANFD_BASE,
	FRAME_TYPE_CANFD_EXT,
	FRAME_TYPE_LIN_TX,
	FRAME_TYPE_LIN_RX
}LPA_FRAME_TYPE;

/* callback struct */
typedef struct LPA_REG_DATA {
	uint16 addr;
	uint32 data[4];
}LPA_REG_DATA;

typedef struct RX_DATA_FRAME {
	LPA_FRAME_TYPE ftype;
	uint8 proto; 		// CAN(0) or LIN(1)
	uint8 port;			// rx port number
	uint32 ID;			// frame ID
	uint32 ts_us_high;	// upper value of timestamp(us)
	uint32 ts_us_low;	// lower value of timestamp(us)
	uint16 ts_ns;		// nano second value of timestamp
	uint8 data_len;
	uint8 Data[64U];
}RX_DATA_FRAME;

typedef struct RX_TS_FRAME {
	uint8 port;			// rx port number
	uint32 ts_us_high;	// upper value of timestamp(us)
	uint32 ts_us_low;	// lower value of timestamp(us)
	uint16 ts_ns;		// nano second value of timestamp
	
	// 241209
	uint32 ID;
}RX_TS_FRAME;

typedef struct RX_STATUS_FRAME {
	uint8 port;			// rx port number
	uint8 error_num;
	uint8 error[4];
}RX_STATUS_FRAME;
/* callback struct end */

/**************************************************************************************************
*                                          global VARIABLES
**************************************************************************************************/
extern const int8 *PORT_NAME[];

#endif /* LPA_FRAMEWORK_H */
