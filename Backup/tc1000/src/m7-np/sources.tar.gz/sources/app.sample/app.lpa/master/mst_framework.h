/*
***************************************************************************************************
*
*   FileName : mst_framework.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef MST_FRAMEWORK_H
#define MST_FRAMEWORK_H

#include "FreeRTOS.h"
#include "task.h"
#include "debug.h"
#include "sal_com.h"
#include "lpa_drv.h"
#include "ccf.h"
#include "ipc.h"
#include "frm_lib.h"
#include "lpa_framework.h"

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/
/* for TSNC latency */
/*
extern uint32 tick_canc_tx;

extern uint32 tick_tpa_rx;
extern uint32 tick_lpa_enqueue;

extern uint32 tick_lpa_rx;
extern uint32 tick_tpa_write;
*/

/*************** TPA ****************/
#define TPA_EN
/*(1) Event cert_dcl37_c_violation:	The reserved identifier "ETH_BUFFER_SIZE", which is reserved for future library directions in errno.h, is defined.*/
#define TPA_ETH_BUFFER_SIZE           (256) // max ethernet frame size

#define CCF_CONTROL

/* IDE */
#define STANDARD_CAN		(0U)
//#define EXTENDED_CAN		(1U)


#define CAN_DATA_LENGTH_SIZE      (64U)

extern uint8 *pCcf;
//extern uint8 Rx_Data[64];

typedef enum {
    TSNC = 1,
    CANC,
    IPC
} LPA_DATA_DST;

typedef enum {
    eLPA_SUCCESS    = 0,
    eLPA_FAIL
} eLPA_VAL_t;

typedef struct CNVT_CAN_DATA {
    uint8 port;
    uint8 ide;          // Extended ID or Normal ID
    uint32 id;
    uint16 len;
    uint8 data[64];
}CNVT_CAN_DATA;

#if 0
typedef struct CANC_EXPAND_DATA {
    uint8 port;
    uint32 id;
    uint16 len;
    uint8 data[64];
}CANC_EXPAND_DATA;
#endif

/***** Task Quehandle ***********/
extern uint32 gTpaTxQueueHandle;
extern uint32 gLpaTxQueueHandle;

typedef struct TSNC_ETH_DATA {
    uint8 msg_data[TPA_ETH_BUFFER_SIZE];
}TSNC_ETH_DATA;

/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/
typedef void (*LpaRegCallback)(const LPA_REG_DATA *reg_data);
typedef void (*LpaDataCallback)(const RX_DATA_FRAME *rx_data);
typedef void (*LpaTsCallback)(const RX_TS_FRAME *rx_ts);
typedef void (*LpaStatusCallback)(const RX_STATUS_FRAME *rx_status);

typedef void (*CANCnvtExpandCallback)(const CNVT_CAN_DATA *can_data);
typedef void (*CANtoEthCallback)(const CNVT_CAN_DATA *can_data);
typedef void (*EthtoCANCallback)(const TSNC_ETH_DATA *eth_data);


extern void frm_lpa_rx_setRegCB(LpaRegCallback cbFunc);
extern void frm_lpa_rx_setDataCB(LpaDataCallback cbFunc);
extern void frm_lpa_rx_setTsCB(LpaTsCallback cbFunc);
extern void frm_lpa_rx_setStatusCB(LpaStatusCallback cbFunc);
extern void frm_tsnc_setCANtoEthCB(CANtoEthCallback cbFunc);
extern void frm_canc_setExpandCB(CANCnvtExpandCallback cbFunc);

extern void frm_lpa_init(void);

extern void LPA_Rx_CreateAppTasks(void);
extern void LPA_Tx_CreateAppTasks(void);
extern void LPA_IPC_RxTaskCreate(void);

extern int32a frm_lpa_write_ccf(uint64 *ccf_conf);
extern void frm_parse_ccf(uint8 *in, uint32 size);
extern int8 frm_lpa_reset(void);

extern uint8 frm_lpa_rx_getTaskState(void);
extern void frm_read_lpa_register(uint16 raddr);
//extern int32a frm_lpa_getCanCnt(eLPA_PORT_NUM can_port);
extern int32a frm_lpa_getCanCnt(uint16 portN);
extern int32a frm_lpa_getLinCnt(uint16 portN);

extern void frm_can_cnvt_send(uint8 port_num, uint8 can_type, uint8 is_ext, uint32 id, uint length, const uint8 *data);
extern void frm_lpa_sendFrame(LPA_FRAME_TYPE ftype, uint8 PortNum, uint32 ID, uint8 DataLen, const uint8 *pData);
extern void frm_build_routeTable(uint8 src_ch, uint32 src_id, LPA_DATA_DST type);
extern uint8 frm_get_CAN_length(uint8 dlc);
extern void frm_lpa_write(const stLPA_REQUEST_t *pstRequest, stLPA_RESPONSE_t *pstResponse);

#ifdef CCF_CONTROL
extern uint32 frm_find_channel_type(uint64 in[][DATA_SIZE], uint8 ch);
extern void frm_CAN_speed_config(uint64 in[][DATA_SIZE], uint8 can_ch, uint8 can_spd, uint8 canFd_spd);
extern void frm_LIN_speed_config(uint64 in[][DATA_SIZE], uint8 lin_ch, uint8 lin_spd);
extern void frm_CAN_type_config(uint64 in[][DATA_SIZE], uint8 ch, uint8 type);
extern void frm_LIN_checksum_config(uint64 in[][DATA_SIZE], uint8 ch, uint8 op, uint8 val);
extern void frm_add_routing_port(uint64 in[][DATA_SIZE], uint8 ch, uint8 is_ext, uint32 routing_id, uint8 add_ch);
/*cert_exp37_c_violation:	Calling function "frm_delete_routing_table(uint64 (*)[116], uint8, uint8, uint8)" with the argument "routingId", which has an incompatible type "uint32" instead of "uint8".*/
/*misra_c_2012_rule_2_7_violation:	The parameter "is_ext" is not used in the function.*/
//extern void frm_delete_routing_table(uint64 in[][DATA_SIZE], uint8 ch, uint8 is_ext, uint32 delete_id);
extern void frm_delete_routing_table(uint64 in[][DATA_SIZE], uint8 ch, uint32 delete_id);
extern void frm_add_translate_id(uint64 in[][DATA_SIZE], uint8 ch, uint8 src_ch, uint8 src_ext, uint32 src_id, uint8 dst_ext, uint32 dst_id);
#endif

#endif /* MST_FRAMEWORK_H */
