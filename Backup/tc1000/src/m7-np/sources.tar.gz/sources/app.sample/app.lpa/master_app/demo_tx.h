/*
***************************************************************************************************
*
*   FileName : demo_tx.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/
/*cert_dcl37_c_violation:	The reserved identifier "_DEMO_TX_H_", which is reserved for use as identifiers with file scope in both the ordinary and tag name spaces, is defined.*/
#ifndef DEMO_TX_H_
#define DEMO_TX_H_

#include "sal_com.h"
#include "mst_framework.h"

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/

/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/
void LPA_TX_CLI_Help(void);
extern void LPA_Tx_CLI(uint8 ucArgc, void* const pArgv[]);


#endif /* DEMO_TX_H_ */
