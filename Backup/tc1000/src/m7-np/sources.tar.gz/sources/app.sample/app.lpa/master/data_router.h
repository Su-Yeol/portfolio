/*
***************************************************************************************************
*
*   FileName : data_router.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef DATA_ROUTER_H
#define DATA_ROUTER_H

#include "sal_com.h"
#include "mst_framework.h"

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/
#define LPA_RX_TASK_STK_SIZE          (1024U)
#define LPA_TX_TASK_STK_SIZE          (1024U)
#define LPA_IPC_RX_TASK_STK_SIZE      (1024U)

#define ROUTE_NUM   256

#define NOTI_SIG_ALL	(0xffffffffUL)

/*********** TX message command ***********/
#define TX_LPA_CMD_FRAME_SEND				(1U)
#define TX_LPA_TSNC_FRAME_SEND				(2U)
#define TX_LPA_READ_REG_REQ					(3U)
#define TX_IPC_RESP_SEND                    (4U)
#define TX_LPA_CMD_EXIT						(100U)

/* IPC */
typedef enum IPC_CORE_INDEX{
    A65AE = 0U,
    CM7_0,
    CM7_1,
    CM7_2
}IPC_CORE_INDEX;

typedef enum {
	eLPA_RX_TASK_NOTIFY_DATA_INT   		= 0x00000001,
	eLPA_RX_TASK_NOTIFY_STATUS_INT 		= 0x00000002,
	eLPA_RX_TASK_NOTIFY_STOP  			= 0x00000100,
	eLPA_RX_TASK_NOTIFY_RESTART	  		= 0x00000200,
}eLPA_RX_TASK_NOTIFY_t;

typedef struct LPA_CAN_STAT_DATA {
	uint32 rx_escape_route1;
	uint32 rx_escape_route2;
	uint32 rx_abort;
	uint32 id_not_found;
	uint32 rx_frame_counter;
	uint32 tx_frame_counter;
}LPA_CAN_STAT_DATA;

typedef struct LPA_LIN_STAT_DATA {
	uint32 rx_escape_route;
	uint32 rx_abort;
	uint32 id_not_found;
	uint32 rx_frame_counter;
	uint32 tx_frame_counter;
}LPA_LIN_STAT_DATA;

typedef struct {
    uint16 cmd;
    uint8 *data;
    uint16 length;
} lpaIpcMessage_t;

typedef struct routeTbl{
    uint8 src;
    uint32 id;
    uint8 dst;
} routeTbl_t;

#define	MCAL_TX_CONFIRM_SUPPORT				(1U)


/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/
//Rx API
//void LPA_Rx_Init(void);

//Tx API
//void LPA_Tx_Init(void);
extern void LPA_Tx_readRegRequest(uint16 addr);
extern void frm_lpa_rx_taskNotifyStop(void);
void LPA_Rx_TaskNotifyRestart(void);
void set_slave_ack(uint16 ack);
uint16 get_slave_ack(void);
void set_master_ack(uint16 ack);
uint16 get_master_ack(void);
/*misra_c_2012_rule_8_5_violation:	Symbol "frm_findRouteTbl" is declared more than once*/
uint8 frm_findRouteTbl(uint8 input_port, uint32 input_id, uint8 index);

// 241106 sy.kim
static void NP_IpcCbFunc_A65_Test(uint16 uhwCmd, uint8 *pucData, uint16 uhwLength);

/************************************** 241202 sy.kim IONIQ5 RX ************************************/
/* CAN0(C-CAN) RX 
	0x4A, 0x65, 0xa0, 0x125, 0x130, 0x175, 0x1AA, 0x255, 0x1e5
*/
static void RxCAN0_YRS_01_10ms(uint8 *YRS_RxData);
static void RxCAN0_IEB_01_10ms(uint8 *BrkPedal_RxData);
static void RxCAN0_WHL_01_10ms(uint8 *WHL_RxData);
static void RxCAN0_SAS_01_10ms(uint8 *SAS_RxData);
static void RxCAN0_Unknown_0x130(uint8 *Unknown_RxData);
static void RxCAN0_ESC_03_20ms(uint8 *ESC03_RxData);
static void RxCAN0_CLU_01_20ms(uint8 *CLU_RxData);
static void RxCAN0_CLU_02_100ms(uint8 *CLU2_RxData);
static void RxCAN0_RR_C_RDR_01_50ms(uint8 *RR_C_RDR_01_50ms);
static void katech_rx_can0(uint32 can_id, uint8 *data);

/* CAN1(E-CAN) RX
	0x35, 0xa0, 0x175, 0x1AA, 0x1B5, 0x1BA, 0x1cf, 0x3c1
*/
static void RxCAN1_Unknown_0x35(uint8 *Unknown_0x35);
static void RxCAN1_WHL_01_10ms(uint8 *WHL_01_10ms); 
static void RxCAN1_ESC_03_20ms(uint8 *ESC_03_20ms);
static void RxCAN1_CLU_01_20ms(uint8 *CLU_01_20ms);
static void RxCAN1_CLU_01_20ms2(uint8 *LaneInfoRxData);
static void RxCAN1_RR_C_RDR_02_50ms(uint8 *RR_C_RDR_02_50ms);
static void RxCAN1_SWRC_03_20ms(uint8 *SWRC_03_20ms);
static void RxCAN1_MFSW_01_200ms(uint8 *MFSW_01_200ms);
static void katech_rx_can1(uint32 can_id, uint8 *data);

/* CAN2(MDPS) RX
	0xEA, 0x377, 0x378, 0x379
*/
static void RxCAN2_MDPS_01_10ms(uint8 *MDPS_RxData);
static void RxCAN2_Unknown_0x377(uint8 *CMD_RxData);
static void RxCAN2_Unknown_0x378(uint8 *CMD_RxData);
static void RxCAN2_Unknown_0x379(uint8 *CMD_RxData);
static void katech_rx_can2(uint32 can_id, uint8 *data);

/* CAN3(DRV) RX
	0x1EA, 0x1A0, , 0x165
*/
static void RxCAN3_ADAS_CMD_20_20ms(uint8 *data);
static void RxCAN3_ADAS_CMD_32_50ms(uint8 *ADAS_CMD_20_20ms_Temp);
static void RxCAN3_ADAS_CMD_10_20ms(uint8 *ADAS_CMD_10_20ms);
static void RxCAN0_ADAS_PRK_20_20ms(uint8 *ADAS_PRK_20_20ms);
static void katech_rx_can3(uint32 can_id, uint8 *data);

/***************************************************************************************************/


#endif /* DATA_ROUTER_H */
