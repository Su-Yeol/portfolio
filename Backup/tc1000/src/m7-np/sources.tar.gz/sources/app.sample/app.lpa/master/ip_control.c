/*
***************************************************************************************************
*
*   FileName : ip_control.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/**************************************************************************************************
*                                           INCLUDE FILES
**************************************************************************************************/

#include "string.h"
#include "ip_control.h"
#include "data_router.h"
#include "route_cfg.h"
#include "lpa_std.h"
#include "lpa_transceiver.h"
#ifdef SIC_BSP_SUPPORT_TEST_APP_TPA
#include "app_tpa_rx.h"
#include "app_tpa_tx.h"
#endif


/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/
/*misra_c_2012_rule_8_4_violation:	Object definition does not have a visible prototype.*/
static const eLPA_PORT_NUM can_port2phy[16] = {
	LPA_CAN1_PORT,LPA_CAN2_PORT,LPA_CAN3_PORT,LPA_CAN4_PORT,LPA_CAN5_PORT,LPA_CAN6_PORT,LPA_CAN7_PORT,LPA_CAN8_PORT,
	LPA_CAN9_PORT,LPA_CAN10_PORT,LPA_CAN11_PORT,LPA_CAN12_PORT,LPA_CAN13_PORT,LPA_CAN14_PORT,LPA_CAN15_PORT,LPA_CAN16_PORT
};

static const eLPA_PORT_NUM lin_port2phy[8] = {
	LPA_LIN1_PORT,LPA_LIN2_PORT,LPA_LIN3_PORT,LPA_LIN4_PORT,LPA_LIN5_PORT,LPA_LIN6_PORT,LPA_LIN7_PORT,LPA_LIN8_PORT,
};

typedef struct ROUTE_INFO {
	uint16 route_id;
	uint32 input_id;
	uint8 input_ext;
	uint32 out_port_num;
	uint8 out_port[26];

}ROUTE_INFO;

typedef struct TRANSLATE_INFO {
	uint8 inputExt;
	uint8 outputExt;
	uint8 src_port;
	uint8 tx_format;
	uint32 input_id;
	uint32 output_id;
}TRANSLATE_INFO;

typedef struct BS_Info {
	uint8 nQueue;
	uint8 msgSize;
	uint16 addr;
}BS_Info;

#define	LPA_MAX_TRANSLATION		(32U)
#define	LPA_MAX_ROUTE		(32U)
typedef struct CCF_DATA{
	uint8 cardPhynum;		/* cardPhyNum */
	uint8 ext_time;
	uint8 port_type;		/*[port type] -1:not defined, 0:PROC, 1:CAN, 2:LIN*/
	uint8 data_int;		/*[data interrupt] -1:not defined, 0:No, 1:Yes*/
	uint8 log_int;		/*[log interrupt] -1:not defined, 0:No, 1:Yes*/
	uint8 status_int;		/*[status interrupt] -1:not defined, 0:No, 1:Yes*/
	uint16 escape_id;		/*[escape ID] -1:not defined, */
	uint8 is_canfd;		/*-1:not defined, 1:fd*/
	uint8 can_clock;		/*[can clock] -1:not defined, 0:1M, 1:500k, 2:250k, 3:125k, 4:83.3k*/
	uint8 canfd_clock;	/*[canfd clock] -1:not defined, 0:5M, 1:4M, 2:2M, 3:1M, 4:500k*/
	uint8 lin_clock;		/*[lin clock] -1:not defined, 0:20k, 1:15k, 2:10k, 3:5k, 4:1k*/
	uint8 lin_autorx;		/*[autoRxPeriod] -1:not defined, 0:OFF, 1:250us, 2:500us, 3:1ms, 4:2ms, 5:5ms, 6:10ms, 7:50ms*/
	uint8 lin_chksum;		/*[check_sum type] -1:not defined, 0:standard, 1:enhanced*/
	uint8 self_test;		/*[selTest] -1:not defined, 0:No, 1:Yes*/
	ROUTE_INFO route[LPA_MAX_ROUTE];
	TRANSLATE_INFO trans[LPA_MAX_TRANSLATION];
}CCF_DATA;

static const int8 *CAN_CLOCK[]= {"1M ","500K ","250K ","125K ","83.3K"};
static const int8 *FD_CLOCK[] = {"5M  ","4M  ","2M  ","1M  ", "500K"};
static const int8 *LIN_CLOCK[] = {"20K", "15K","10K","5K ", "1K "};
static const int8 *LIN_AUTORX[] = {"OFF  ","250us","500us","1ms  ","2ms  ","5ms  ","10ms ","50ms "};

/**************************************************************************************************
*                                          GLOBAL VARIABLES
**************************************************************************************************/
uint8 gProcRequestBuffer[1024+32];
uint8 gLogIntMode = 1U; /*0: polling mode, 1: interrupt mode*/
uint8 gDataIntMode = 1U;    /*0: polling mode, 1: interrupt mode*/
uint8 lpp_initialized = 0U; /* 0:not initialized, 1:not initialized */
uint8 gTimestampMode = 0U;  /*0: internal counter, 1: external counter */

/**************************************************************************************************
*                                          LOCAL VARIABLES
**************************************************************************************************/
//eLPA_PORT_NUM can_port2phy[];
static MM_WRITE mwr_data;
uint8 *pCcf = NULL;

/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/
static int32a Write_CCF(uint64 *ccf_conf);
void lpa_getVer(void);

/**************************************************************************************************
*                                             FUNCTIONS
**************************************************************************************************/
#if 0
////////////////////////////////////// Temp code /////////////////////////////////////////////////
#define enable_allInterrupt()	\
{	\
	__asm volatile(	\
					" cpsie i				\n"	\
					" cpsie f				\n"	\
					" nop					\n"	\
				);	\
}

#define disable_allInterrupt()	\
{	\
	__asm volatile(	\
					" cpsid i				\n"	\
					" cpsid f				\n"	\
					" nop					\n"	\
				);	\
}
////////////////////////////////////////////////////////////////////////////////////////////////////
#endif
static void delay(uint32 usec)
{
    uint32 i, cnt;
    cnt = usec * 500U;
    for (i = 0u; i < cnt; i++) {
        BSP_NOP_DELAY();
    }
}


void frm_lpa_init(void)
{
    lpa_trxIC_init();
    lpa_trxIC_set_mode(1U, 1U, 0U, 0U);

    (void)lpa_open();

    (void)Write_CCF(Base_Conf[0]);

	lpa_trxIC_set_mode(1U, 1U, 1U, 1U);
}

static uint8 get_interrupt_mode(const uint64 *ccf_conf)
{
	uint32 j;
	uint8 int_mode = 1U;
	for(j = 0; j < DATA_SIZE; j++)
	{
		if ((ccf_conf[j] & 0x0000FFFFULL) == 0x0A00ULL)
		{
			int_mode = ((ccf_conf[j] & 0x0100000000000000ULL) == 0x0100000000000000ULL)?1U:0U;
			break;
		}
	}
	return int_mode;
}

static int32a Write_CCF(uint64 *ccf_conf)
{
	uint16 i;
	eLPA_MODE_t mode;
	stLPA_REQUEST_t req;
	stLPA_RESPONSE_t resp;
	int32a ret = -1;

	(void)SAL_MemCopy(&pCcf, &ccf_conf, sizeof(uint8 *));

	SAL_MemSet(&req, 0, sizeof(stLPA_REQUEST_t));
	SAL_MemSet(&mwr_data, 0, sizeof(MM_WRITE));
	req.buffer = gProcRequestBuffer;
	resp.buffer = NULL;
	mwr_data.type = MM_WRITE_TYPE;

	mcu_printf("\n==LPA Configuration===============\n");
	for(i = 0; i < CONFIG_SIZE; i++)
	{
//		mcu_printf("[%d]write configuration\n", i);
		req.idt = lpa_u16add(RoutID[i], BASE_IDT); // ccf file comset
		req.sn = i;
		req.data_crc = 0;
		req.size = (uint16)sizeof(MM_WRITE);

		SAL_MemCopy(mwr_data.data, &ccf_conf[i * DATA_SIZE], DATA_SIZE * 8U); // load to mm_write data from ccf
		SAL_UtilCrc32((uint8 *)&mwr_data.crc32, (uint8 *)&mwr_data, sizeof(mwr_data) - sizeof(uint32)); //calculate CRC

		SAL_MemCopy(req.buffer, &mwr_data, sizeof(MM_WRITE)); // load to axi from mm_write

        (void)lpa_write(&req, &resp);
        if (RoutID[i] == 0x0U) {
            if ((ccf_conf[0] & 0x0002000000000000ULL) == 0x0002000000000000ULL) {
                gTimestampMode = 1U;
			}
			else{
				gTimestampMode = 0U;
			}
		}
		else if (RoutID[i] == 0x3U){
            gLogIntMode = get_interrupt_mode(&ccf_conf[i * DATA_SIZE]);
        }
        else if (RoutID[i] == 0x5U){
            gDataIntMode = get_interrupt_mode(&ccf_conf[i * DATA_SIZE]);
		}
		else{
			/**/
		}
	}

	delay(5);
    lpp_initialized = 0U;
    if (lpa_getMode(&mode) == (int32)eLPA_RET_OK) {
        if (mode == eLPA_MODE_OPERATION) {
			lpp_initialized = 1U;
			ret = 0;
		}
		mcu_printf("[%s] LPA mode: %d\n", __func__, (uint32)mode);
	}
	mcu_printf("==LPA Configuration Done==========\n\n");

	mcu_printf("[%s] Log rx mode: %s\n", __func__, (gLogIntMode==1U)?(uint8*)"Interrupt":(uint8*)"Polling");
	mcu_printf("[%s] Proc rx mode: %s\n", __func__, (gDataIntMode==1U)?(uint8*)"Interrupt":(uint8*)"Polling");
	mcu_printf("[%s] Timestamp: %s\n", __func__, (gTimestampMode==1U)?(uint8*)"External":(uint8*)"Internal");
	return ret;
}

int32a frm_lpa_write_ccf(uint64 *ccf_conf)
{
	int32a ret;
	/*
		NOTE:
		This function must be used after creating Log_Task and Rx_Task.
	*/
	ret = Write_CCF(ccf_conf);
	if (lpp_initialized == 1U) {
		/*
			log_task is restarted by app.
		*/
		LPA_Log_TaskNotifyRestart();
		LPA_Rx_TaskNotifyRestart();
	}

	return ret;
}

void frm_parse_ccf(uint8 *in, uint32 size)
{
	uint32 i;
	uint32 j;
	uint32 c;
	uint16 *h = NULL;
	uint16 v;
	uint32 a;
	CCF_DATA ccf;
	BS_Info bs_info[30];
	uint32 route_num = 0;
	uint32 route_input_id_num = 0;
	uint32 id = 0;
	uint16 val;

	(void)memset(&ccf, 0, sizeof(CCF_DATA));
	for(i = 0U; i< LPA_MAX_ROUTE; i++)
	{
		ccf.route[i].out_port_num = 0;
	}
	for(i = 0U; i< LPA_MAX_TRANSLATION; i++)
	{
		ccf.trans[i].input_id = 0xFFFFUL;
	}

	for(i = 0U; i < size; i += 8U) {
		uint8 *t = &in[i];
		SAL_MemCopy(&h, &t, sizeof(uint16 *));
		if (h != NULL) {
			v = 0U;
			v |= ((h[0] & 0x00FFU) << 8U);
			v |= ((h[0] & 0xFF00U) >> 8U);
			if (v == 0x0001U) {
				ccf.ext_time = ((in[i + 6U] & 0x02U) == 0x02U)?1U:0U;
			}
			else if (v == 0x0007U) {
				v = (uint16)in[i + 7U];
				id = (uint32)in[i + 4U];
				if ( v == 0x43U) {
					ccf.port_type = 1U;
				}
				else if ( v == 0x45U) {
					ccf.port_type = 2U;
				}
				else if ( v == 0x21U) {
					ccf.port_type = 0U;
				}
				else {/**/}
			}
			else if (v == 0x000AU) {
				uint8 interrupt;
				uint8 sr_interrupt;
				interrupt = ((in[i + 7U] & 0x1U) == 0x1U)?1U:0U;
				sr_interrupt = ((in[i + 7U] & 0x2U) == 0x2U)?1U:0U;
				if (id == 0x03U) {
					ccf.log_int = (interrupt == 1U)?1U:0U;
				}
				else if (id == 0x05U) {
					ccf.data_int = (interrupt == 1U)?1U:0U;
					ccf.status_int = (sr_interrupt == 1U)?1U:0U;
				}
				else {
					/**/
				}
			}
			else if (v == 0x0035U) {
				v = 0;
				v |= ((uint16)in[i + 6U] << 8U);
				v |= (uint16)in[i + 7U];
				ccf.escape_id = v;
			}
			else if (v == 0x0050u) {
				if (id < 0x16U) {
					ccf.can_clock = in[i + 7U] & 0x0fu;
					ccf.canfd_clock = (in[i + 7U] & 0xf0u) >> 4u;
				}
				else {
					ccf.lin_clock = in[i + 7U] & 0x07U;
				}
			}
			else if (v == 0x051U) {
				if (id >= 0x16U) {
					ccf.lin_autorx = (in[i + 7U] & 0x0eu ) >> 1u;
					ccf.lin_chksum = (in[i + 7U] & 0x01u );
				}
				else if (id >= 0x6U) {
					uint16 flag = (uint16)1U<<(id - 6U);
					v = (uint16)in[i + 6U] << 8U;
					v |= (uint16)in[i + 7U];
					if ((v & flag) == flag) {
						ccf.is_canfd = 1U;
					}
				}
				else {
					/**/
				}
			}
			else if (v == 0x0120U) {
				ccf.self_test = (in[i + 7U] == 0U)?0U:1U;
			}
			else if ((v >= 0x2000U) && (v <= 0x203FU)) {
				uint32 input_id;
				uint8 isInputExtendedId;
				a  = ((uint32)in[i + 4U] << 24U);
				a |= ((uint32)in[i + 5U] << 16U);
				a |= ((uint32)in[i + 6U] << 8U);
				a |= ((uint32)in[i + 7U]);
				if (ccf.route[route_input_id_num].route_id != 0xffff) {
					if ((id >= 0x16U) && (id <= 0x1dU)) {
						if (a != 0x3FU) {
							input_id = a;

							ccf.route[route_input_id_num].input_id = input_id;
							ccf.route[route_input_id_num].input_ext = 0U;
							route_input_id_num = lpa_u32add(route_input_id_num, 1U);
							if (route_input_id_num >= LPA_MAX_ROUTE) {
								route_input_id_num = LPA_MAX_ROUTE - 1U;
							}
						}
					}
					else {
						isInputExtendedId = ((a & 0x20000000U) ==  0x20000000U)?1U:0U;
						if (isInputExtendedId == 1U) {//extended input
							input_id = a & 0x1fffffffU;
						}
						else{
							input_id = (a & 0x1ffc0000U)>>18U;
						}

						ccf.route[route_input_id_num].input_ext = isInputExtendedId;
						ccf.route[route_input_id_num].input_id = input_id;
						route_input_id_num = lpa_u32add(route_input_id_num, 1U);
						if (route_input_id_num >= LPA_MAX_ROUTE) {
							route_input_id_num = LPA_MAX_ROUTE - 1U;
						}
					}
				}
			}
			else if ((v >= 0x4000U) && (v <= 0x403FU)) {
				uint32 s;
				uint32 port;
				v = 0;
				v |= ((uint16)in[i + 2U] << 8U);
				v |= ((uint16)in[i + 3U]);
				a = 0;
				a |= ((uint32)in[i + 4U] << 24U);
				a |= ((uint32)in[i + 5U] << 16U);
				a |= ((uint32)in[i + 6U] << 8U);
				a |= ((uint32)in[i + 7U]);

				for(s = 0U; s < LPA_MAX_ROUTE; s++) {
					if (ccf.route[s].route_id == v) {
						break;
					}
				}
				if (s == LPA_MAX_ROUTE) {
					port = a;
					for(s = 0U; s < 29U; s++) {
						port = port >> 1U;
						if ((port & 0x1U) == 0x01U) {
							if (ccf.route[route_num].out_port_num < 26U) {
								ccf.route[route_num].out_port[ccf.route[route_num].out_port_num] = s + 1U;
								ccf.route[route_num].out_port_num = lpa_u32add(ccf.route[route_num].out_port_num, 1U);
							}
						}
					}
					ccf.route[route_num].route_id = v;
					route_num = lpa_u32add(route_num, 1U);
				}
				if (route_num >= LPA_MAX_ROUTE) {
					route_num = LPA_MAX_ROUTE - 1U;
				}
			}
			else if ((v >= 0x7800U) && (v <= 0x7807U)) {
				uint32 input_id;
				uint32 src_port;
				uint8 isInputExtendedId;
				a  = ((uint32)in[i + 2U] << 16U);
				a |= ((uint32)in[i + 3U] << 8U);
				a |= ((uint32)in[i + 4U]);
				src_port = a >> 7U;
				src_port &= 0x1fU;
				a = 0;
				a |= ((uint32)in[i + 4U] << 24U);
				a |= ((uint32)in[i + 5U] << 16U);
				a |= ((uint32)in[i + 6U] << 8U);
				a |= ((uint32)in[i + 7U]);
				if ((a & 0x40000000U) == 0UL) {
				 	val = v & 0x00ffU;
					isInputExtendedId = ((a & 0x20000000U) == 0x20000000U)?1U:0U;
					if (isInputExtendedId == 1U) {
						input_id = a & 0x1FFFFFFFU;
					}
					else {
						input_id = (a & 0x1FFFFFFFU) >> 18U;
					}
					ccf.trans[val].input_id = input_id;
					ccf.trans[val].inputExt = isInputExtendedId;
					if (src_port == 0x1fU) {
						ccf.trans[val].src_port = 30U;
					}
					else {
						ccf.trans[val].src_port = src_port;
					}
				}
				else {
					val = v & 0x00ffU;
					if (in[i + 7U] != 0x3fU) {
						isInputExtendedId = ((a & 0x20000000U) == 0x20000000U)?1U:0U;
						input_id = a & 0x1FFFFFFFU;

						ccf.trans[val].input_id = input_id;
						ccf.trans[val].inputExt = isInputExtendedId;
						if (src_port == 0x1fU) {
							ccf.trans[val].src_port = 30U;
						}
						else {
							ccf.trans[val].src_port = src_port;
						}
					}
				}
			}
			else if ((v >= 0x7a00U) && (v <= 0x7a07U)) {
				uint8 isOutputExtendedId;
				uint32 trans_id;
				a = 0;
				a |= ((uint32)in[i + 4U] << 24U);
				a |= ((uint32)in[i + 5U] << 16U);
				a |= ((uint32)in[i + 6U] << 8U);
				a |= ((uint32)in[i + 7U]);
				if (a != 0x3FFFFFFFU) {
					val = v & 0x00ffU;
					if ((id >= 0x16U) && (id <= 0x1dU)) {
						if (in[i + 7U] != 0x3fU) {
							isOutputExtendedId = ((a & 0x20000000U) == 0x20000000U)?1U:0U;
							trans_id = a & 0x1FFFFFFFU;
							ccf.trans[val].output_id = trans_id;
							ccf.trans[val].outputExt = isOutputExtendedId;
						}
					}
					else {
						isOutputExtendedId = ((a & 0x20000000U) == 0x20000000U)?1U:0U;
						if (isOutputExtendedId == 1U) {
							trans_id = a & 0x1FFFFFFFU;
						}
						else {
							trans_id = (a & 0x3FFFFFFFU) >> 18U;
						}
						ccf.trans[val].output_id = trans_id;
						ccf.trans[val].outputExt = isOutputExtendedId;
					}
				}
			}
			else if ((v >= 0x8001U) && (v <= 0x801dU)) {
				uint8 c_id = in[i+1U];
				bs_info[c_id].nQueue = in[i+2U];
				bs_info[c_id].msgSize = in[i+3U];
				bs_info[c_id].addr  = (in[i+6U] << 8U);
				bs_info[c_id].addr |= (in[i+7U]);
			}
			else {
				/**/
			}
		}
	}

	if (id == 0U) {
		mcu_printf("--------------------------------------------------------------\n");
		mcu_printf("External Timer:%s \n", (ccf.ext_time == 1U)?"Yes":"No");
#if 0
		for(j = 1U; j < 30u; j++) {
			if (j != 2u) {
				mcu_printf("comset_id: %02X, nQueue: %02X, msgSize: %d, addr: %04X\n",
					j, bs_info[j].nQueue, bs_info[j].msgSize, bs_info[j].addr);
			}
		}
#endif
	}

	if ((id >= 6U) && (id <= 21U)) {//can
		mcu_printf("--------------------------------------------------------------%d\n", ccf.port_type);
		mcu_printf("CAN[%d] Port \n", id - 5U);
		mcu_printf("   Rate:%s, FD:%s, FD Rate:%s, SelfTest:%s, Escape Id:0x%04X\n", CAN_CLOCK[ccf.can_clock], (ccf.is_canfd==1U)?"Yes":"No",
			(ccf.is_canfd==1U)?FD_CLOCK[ccf.canfd_clock]:"-   ", (ccf.self_test==0U)?"No":"Yes", ccf.escape_id);
		for(j = 0u;j < LPA_MAX_TRANSLATION; j++) {
			if (ccf.trans[j].input_id != 0xFFFFUL) {
				if (j == 0U) {
					mcu_printf("   Tranalation: %s, 0x%X%s -> 0x%X%s\n",
						PORT_NAME[ccf.trans[j].src_port],
						ccf.trans[j].input_id,
						(ccf.trans[j].inputExt==1U)?"(ext)":"",
						ccf.trans[j].output_id,
						(ccf.trans[j].outputExt==1U)?"(ext)":"");
				}
				else {
					mcu_printf("                %s, 0x%X%s -> 0x%X%s\n",
						PORT_NAME[ccf.trans[j].src_port],
						ccf.trans[j].input_id,
						(ccf.trans[j].inputExt==1U)?"(ext)":"",
						ccf.trans[j].output_id,
						(ccf.trans[j].outputExt==1U)?"(ext)":"");
				}
			}
			else {
				break;
			}
		}
	}

	if ((id >= 22U) && (id <= 29U)) //lin
	{
		mcu_printf("--------------------------------------------------------------%d\n", ccf.port_type);
		mcu_printf("LIN[%d] Port\n", id - 21U);
		mcu_printf("   Rate:%s, AutoRx:%s, Checksum:%s, Escape Id:0x%04X\n",
			LIN_CLOCK[ccf.lin_clock],
			LIN_AUTORX[ccf.lin_autorx],
			(ccf.lin_chksum==1U)?"Enhanced":"Classic",
			ccf.escape_id);
		for(j = 0u;j < LPA_MAX_TRANSLATION; j++) {
			if (ccf.trans[j].input_id != 0xFFFFUL) {
				if (j == 0U) {
					mcu_printf("   Tranalation: 0x%X%s -> 0x%X%s\n",
						ccf.trans[j].input_id,
						(ccf.trans[j].inputExt==1U)?"(ext)":"",
						ccf.trans[j].output_id,
						(ccf.trans[j].outputExt==1U)?"(ext)":"");
				}
				else {
					mcu_printf("                0x%X%s -> 0x%X%s\n",
						ccf.trans[j].input_id,
						(ccf.trans[j].inputExt==1U)?"(ext)":"",
						ccf.trans[j].output_id,
						(ccf.trans[j].outputExt==1U)?"(ext)":"");
				}
			}
			else {
				break;
			}
		}
	}

	if (id == 5U) //proc
	{
		mcu_printf("--------------------------------------------------------------\n");
		mcu_printf("PROC Port\n");
		mcu_printf("   Data Int.:%s, Status Int.:%s \n",
			(ccf.data_int==1U)?"Yes":"No",
			(ccf.status_int==1U)?"Yes":"No");
		for(j = 0u;j < LPA_MAX_TRANSLATION; j++) {
			if (ccf.trans[j].input_id != 0xFFFFUL) {
				if (j == 0U) {
					mcu_printf("   Tranalation: 0x%X%s -> 0x%X%s\n",
						ccf.trans[j].input_id,
						(ccf.trans[j].inputExt==1U)?"(ext)":"",
						ccf.trans[j].output_id,
						(ccf.trans[j].outputExt==1U)?"(ext)":"");
				}
				else {
					mcu_printf("                0x%X%s -> 0x%X%s\n",
						ccf.trans[j].input_id,
						(ccf.trans[j].inputExt==1U)?"(ext)":"",
						ccf.trans[j].output_id,
						(ccf.trans[j].outputExt==1U)?"(ext)":"");
				}
			}
			else {
				break;
			}
		}
	}

	if (id == 3U) //log
	{
		mcu_printf("--------------------------------------------------------------\n");
		mcu_printf("LOG Port\n");
		mcu_printf("   Log Int.:%s\n", (ccf.log_int==1U)?"Yes":"No");
	}

	c = 0u;
	if (id != 4U)
	{
		for(j = 0U;j < LPA_MAX_ROUTE; j++)
		{
			for (i = 0U; i < ccf.route[j].out_port_num; i++)
			{
				if (c == 0U)
				{
					mcu_printf("   Route:[%02d] %s, Route ID:0x%X, Input ID%s:0x%X\n",
						c,
						PORT_NAME[ccf.route[j].out_port[i]],
						ccf.route[j].route_id,
						(ccf.route[j].input_ext==1U)?"(ext)":"",
						ccf.route[j].input_id);
				}
				else
				{
					mcu_printf("         [%02d] %s, Route ID:0x%X, Input ID%s:0x%X\n",
						c,
						PORT_NAME[ccf.route[j].out_port[i]],
						ccf.route[j].route_id,
						(ccf.route[j].input_ext==1U)?"(ext)":"",
						ccf.route[j].input_id);
				}
				c++;
			}
		}
	}
}

// LPP Statistics

void frm_read_lpa_register(uint16 raddr)
{
	LPA_Tx_readRegRequest(raddr);
}

void lpa_getVer(void)
{
	frm_read_lpa_register(LPA_REG_ADDR_IP_VER);
}

int32a frm_lpa_getCanCnt(uint16 portN)
{
    int32a ret = -1;
    eLPA_PORT_NUM can_port;
    uint16 port;
    uint16 addr;

	/*Indexing array "can_port2phy" of size 16 with "portN" minus an offset.*/
	if(portN >= 1u)
	{
    	portN = portN - 1U;
    }
    else
    {
		portN = 0u;
    }

	can_port = can_port2phy[portN];

    if ((can_port >= LPA_CAN1_PORT) && (can_port <= LPA_CAN16_PORT))
    {
        port = (uint16)can_port - (uint16)LPA_CAN1_PORT;
        addr = LPA_REG_ADDR_CAN_PORT_BASE + (port * 8U);
        frm_read_lpa_register(addr);

         /* Waits for a response after processing the data from the queue on the slave */
        while((get_slave_ack() == 0U) && (get_master_ack() == 0U))
        {
            SAL_TaskSleep(1);
        }

        frm_read_lpa_register(addr + 4U);
        set_slave_ack(0U);
        set_master_ack(0U);
        ret = 0;
    }

    return ret;
}

int32a frm_lpa_getLinCnt(uint16 portN)
{
	int32a ret = -1;
    eLPA_PORT_NUM lin_port;
    uint16 port;
	uint16 addr;

	/*Indexing array "lin_port2phy" of size 16 with "portN" minus an offset.*/
	/*misra_c_2012_rule_10_4_violation:	Essential type of the left hand operand "portN" (unsigned) is not the same as that of the right operand "1"(signed).*/
	if(portN >= 1u)
	{
    	portN = portN - 1U;
    }
    else
    {
		portN = 0u;
    }

	lin_port = lin_port2phy[portN];

	if ((lin_port >= LPA_LIN1_PORT) && (lin_port <= LPA_LIN8_PORT))
	{
		port = (uint16)lin_port - (uint16)LPA_LIN1_PORT;
		addr = LPA_REG_ADDR_LIN_PORT_BASE + (port * 8U);
		frm_read_lpa_register(addr);
         /* Waits for a response after processing the data from the queue on the slave */
        while((get_slave_ack() == 0U) && (get_master_ack() == 0U))
        {
            SAL_TaskSleep(1);
        }

		frm_read_lpa_register(addr + 4U);
        set_slave_ack(0U);
        set_master_ack(0U);
		ret = 0;
	}

	return ret;
}

int8 frm_lpa_reset(void)
{
    eLPA_VAL_t ret = eLPA_SUCCESS;

	lpp_initialized = 0U;

    frm_lpa_rx_taskNotifyStop();
	SAL_TaskSleep(1);
	while (frm_lpa_rx_getTaskState() == 0U) {
		break;
	}

    if(eLPA_SUCCESS == lpa_reset())
    {
        mcu_printf("LPA Reset SUCCESS!\n");
    }
    else
    {
        mcu_printf("LPA Reset FAIL!\n");
    }

    return ret;
}

void frm_lpa_set_trxIC(uint32 can_flag, uint32 lin_flag, uint32 can_mode, uint32 lin_mode)
{
	lpa_trxIC_set_mode(can_flag, lin_flag, can_mode, lin_mode);
}

