/*
***************************************************************************************************
*
*   FileName : demo_can_cnvt.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef DEMO_CAN_CVNT_H
#define DEMO_CAN_CVNT_H

#include "sal_com.h"
#include "mst_framework.h"

/**************************************************************************************************
*                                            DEFINITIONS
**************************************************************************************************/
#define CANCnvt_TASK_STK_SIZE          (512U)

#define CETRAC_CFG      1
#define SURESFT_CFG     0

#define CLASSIC     0U
#define FD          1U

#define SPLIT_DLC   8U

/*cert_dcl37_c_violation:	The reserved identifier "EXT_ID_OFFSET", which is reserved for future library directions in errno.h, is defined.*/
#define EXTENDED_ID_OFFSET	(0x80000000U)
#define SPLIT_AREA          (0x8U)

/**************************************************************************************************
*                                        FUNCTION PROTOTYPES
**************************************************************************************************/
/*misra_c_2012_rule_8_8_violation : missing 'extern' */
extern void cb_canc_expand(const CNVT_CAN_DATA *canc_data);
/* misra_c_2012_rule_8_6_violation : delete */
//extern void CANCnvt_UART(uint8 ucArgc, void* const pArgv[]);
extern void CANCnvt_Init(void);
#endif /* DEMO_CAN_CVNT_H */

