/*
 * katech_can_app.h
 *
 *  Modified on: 2024. 11. 29.
 *      Author: sy.kim
 */
#ifndef _KATECH_CAN_APP_H_
#define _KATECH_CAN_APP_H_
#include <stdint.h>

#define KATECH_APP_BUFF_SIZE 2
#define KATECH_CAN_APP_GATEWAY_MODE 0
#define KATECH_CAN_APP_AD_MODE 1


typedef void (*katech_rx_can_func)(uint32, uint8 *);

/*
 * tx CAN1
 */
// can1 - 0x1A0
void TxCAN1_ADAS_CMD_32_50ms(void);
// can1 - 0x1EA
void TxCAN1_ADAS_CMD_20_20ms(void);
// can1 - 0x160
void TxCAN1_ADAS_CMD_10_20ms(void);
/*
 * tx CAN2
 */
// can2 - 0xA0
void TxCAN2_WHL_01_10ms(void);
// // can2 - 0x165
void TxCAN2_ADAS_PRK_20_20ms(void);

// void TxCAN0_DEBUG(void);

// void katech_rx_can0(uint32_t can_id, uint8_t *data);
// void katech_rx_can1(uint32_t can_id, uint8_t *data);
// void katech_rx_can2(uint32_t can_id, uint8_t *data);
// void katech_rx_can3(uint32_t can_id, uint8_t *data);
// void katech_can_app_mode_set(uint8_t mode);

#endif // _KATECH_CAN_APP_H_


