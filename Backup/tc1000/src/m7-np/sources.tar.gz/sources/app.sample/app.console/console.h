/*
***************************************************************************************************
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef CONSOLE_H
#define CONSOLE_H

#define TCC_NUL_KEY                      ((uint8) 0x00)
#define TCC_BACK_SPACE                   ((uint8) 0x08)    // Back space
#define TCC_DEL_KEY                      ((uint8) 0x7F)    // Delete
#define TCC_ESC_KEY                      ((uint8) 0x1B)    // ESC
#define TCC_NAK_KEY                      ((uint8) 0x15)
#define TCC_SPACE_BAR                    ((uint8) 0x20)
#define TCC_LBRACKET                     ((uint8) 0x5B)
#define TCC_RBRACKET                     ((uint8) 0x5D)
#define TCC_UPPERCASE_A                  ((uint8) 0x41)    // ^ (up)
#define TCC_UPPERCASE_B                  ((uint8) 0x42)    // v (down)
#define TCC_UPPERCASE_C                  ((uint8) 0x43)    // > (right)
#define TCC_UPPERCASE_D                  ((uint8) 0x44)    // < (left)
#define TCC_ARRIAGE_RETURN               (uint8)('\r')
#define TCC_LINE_FEED                    (uint8)('\n')  // Enter
#define TCC_CRLF                         ("\r\n\0")

#define CSL_TASK_STK_SIZE               (2048UL)

#define CSL_CMD_BUFF_SIZE               (64UL)
#define CSL_CMD_PROMPT_SIZE             (2UL)
#define CSL_CMD_NUM_MAX                 (42UL)
#define CSL_ARGUMENT_MAX                (10UL)
#define CSL_SPACE_1COUNT                (1UL)
#define CSL_HISTORY_COUNT               (10UL)

#define CSL_LOG_NUM_MAX                 (3UL)

#define CMD_ENABLE                      (1UL)
#define CMD_DISABLE                     (0UL)

#ifndef ON
#define ON                              (1UL)
#define OFF                             (0UL)
#endif

#define CSL_MAX_INT                     (0xFFFFFFFFUL)

/* For checking booting time */
/* FIX_TIME: 14,000 us - From (B+ ON) to (Timer Start at BL0) */
#define BOOT_INITIAL_FIX_TIME           (14000)
#define BOOTTIME_ADDR_START             (0x0607F800UL)
#define BOOTTIME_ADDR_END               (0x0607F828UL)

typedef void                            (*CmdLogFunc) (void * const pArgv[]);
typedef struct CLSConsoleLogFunc
{
    CmdLogFunc                          clFunc;
} CLSConsoleLogFunc_t;

enum
{
    CSL_NOINPUT,
    CSL_INPUTING,
    CSL_EXECUTE
};

typedef void (CmdFuncType)(uint8 argc, void * const argv[]);

// Console Command List
typedef struct CLSConsoleCmdList
{
    uint32                              clEnable;
    const uint8                         *clName;
    CmdFuncType                         *clFunc;

} CLSConsoleCmdList_t;

/*
***************************************************************************************************
*                                         EXTERN FUNCTION
***************************************************************************************************
*/

extern void CreateConsoleTask(void);

#endif
