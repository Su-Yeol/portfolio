/*
***************************************************************************************************
*
*   FileName : console.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <uart.h>
#include <clock.h>
#include <console.h>
#include <main.h>

#include <app_cfg.h>
#include "debug.h"

#if ( SIC_BSP_SUPPORT_TEST_APP_FMU )
#include <fmu_test.h>
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_TIMER == 1 )
#include <timer_test.h>
#endif // ( SIC_BSP_SUPPORT_TEST_APP_TIMER == 1 )

#if ( SIC_BSP_SUPPORT_TEST_APP_NVIC == 1 )
#include <nvic_test.h>
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_NVIC == 1 )

#if ( SIC_BSP_SUPPORT_DRIVER_PMIO == 1 )
    #include <pmio.h>
#endif // ( SIC_BSP_SUPPORT_DRIVER_PMIO == 1 )

#if ( SIC_BSP_SUPPORT_DRIVER_RTC == 1 )
    #include <rtc.h>
    static void RTCTestHandler(void);
#endif // ( SIC_BSP_SUPPORT_DRIVER_RTC == 1 )

#if ( SIC_BSP_SUPPORT_DRIVER_WDT == 1 )
    #include "wdt.h"
/*
    #include "nvic.h"
    #include "fmu.h"

    static void WDTTest_FmuHandler(void* pArg);
*/
#endif  // ( SIC_BSP_SUPPORT_DRIVER_WDT == 1 )

#if ( SIC_BSP_SUPPORT_DRIVER_SWDT == 1 )
    #include "swdt.h"
#endif  // ( SIC_BSP_SUPPORT_DRIVER_SWDT == 1 )

#if ( SIC_BSP_SUPPORT_TEST_APP_SWDT == 1 )
    #include <swdt_test.h>
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_SWDT == 1 )

#if ( SIC_BSP_SUPPORT_DRIVER_SSM & SIC_BSP_SUPPORT_TEST_APP_SSM )
    #include "ssm.h"
    #include "isolation_test.h"
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_GDMA == 1 )
    #include "gdma_test.h"
    #include "gdma_ip_test.h"
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_GDMA == 1 )

#if ( SIC_BSP_SUPPORT_TEST_APP_DSE )
    #include "dse_test.h"
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_GPIO == 1 )
    #include "gpio_test.h"
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_GPIO == 1 )

#if ( SIC_BSP_SUPPORT_DRIVER_SDM & SIC_BSP_SUPPORT_TEST_APP_SDM )
    #include <sdm_test.h>
#endif

#ifdef  SIC_BSP_T_RVC_INCLUDED
    #include <trvc_test.h>
#endif  // SIC_BSP_T_RVC_INCLUDED

#if ( SIC_BSP_SUPPORT_TEST_APP_GPSB == 1 )
    #include "gpsb_test.h"
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_GPSB == 1 )

#if ( SIC_BSP_SUPPORT_TEST_APP_PDM == 1 )
    #include "pdm_test.h"
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_PDM == 1 )

#if ( SIC_BSP_SUPPORT_TEST_APP_ICTC == 1 )
    #include "ictc_test.h"
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_ICTC == 1 )

#if ( SIC_BSP_SUPPORT_TEST_APP_TOP == 1 )
    #include <mc_top.h>
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_TOP == 1 )

#if ( SIC_BSP_SUPPORT_TEST_APP_CRD == 1 )
    #include <crd_test.h>
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_CRD == 1 )

#if ( SIC_BSP_SUPPORT_TEST_APP_SWRAP == 1 )
    #include <swrp_test.h>
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_SWRAP == 1 )

#if ( SIC_BSP_SUPPORT_DRIVER_HSM == 1 )
    #include "hsm_test.h"
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_HSM == 1 )

#if (SIC_BSP_SUPPORT_TEST_APP_I2C == 1)
    #include "i2c_test.h"
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_I2C == 1 )

#if (SIC_BSP_SYS_PV_SFMC == 1)
    #include "sfmc_test.h"
#endif  // ( SIC_BSP_SYS_PV_SFMC == 1 )

#if (SIC_BSP_SYS_PV_SUBSYS == 1)
    #include "subsys_test.h"
#endif  // ( SIC_BSP_SYS_PV_SUBSYS == 1 )

#if (SIC_BSP_SUPPORT_TEST_APP_MBOX)
    #include "mbox_test.h"
#endif
#if ( SIC_BSP_SUPPORT_APP_ETH == 1 )
    #include "eth_test.h"
	#include "eth.h"
#endif  // ( SIC_BSP_SUPPORT_APP_ETH == 1 )

#if ( SIC_BSP_SUPPORT_DRIVER_ADC == 1 )
    #include "adc.h"
#endif  // ( SIC_BSP_SUPPORT_APP_ADC == 1 )

#if ( SIC_BSP_SUPPORT_CAN_DEMO == 1 )
    #include "can_demo.h"
#endif  // ( SIC_BSP_SUPPORT_CAN_DEMO == 1 )

#if ( SIC_BSP_SUPPORT_APP_AP_SYSTEM_RESET == 1 )
#include <ap_sys_rst.h>
#endif

#ifdef IP_VERIFICATION_DEFINED_GDMA_MIDF_TOP_CRD
    #include <mid_filter_test.h>
#endif

#if (SIC_BSP_SUPPORT_TEST_APP_LPA_MA == 1)
#include "demo_ip_control.h"
#include "demo_rx.h"
#include "demo_tx.h"
#endif

#if (SIC_BSP_SUPPORT_TEST_APP_LPA_SA == 1)
#include "slv_framework.h"
#endif

#if (SIC_BSP_SUPPORT_TEST_APP_TPA == 1)
#include "app_tpa_tx.h"
#endif

#if (SIC_BSP_SUPPORT_PV_LPA == 1)
#include "lpa_ip_test.h"
#endif

#if (SIC_BSP_SUPPORT_DRIVER_LPA_TEST == 1)
#include "lpa_drv_test.h"
#endif

//#define USE_HSM_TEST
//#define USE_MIDF_TEST
//#define USE_I2C_TEST
//#define USE_CAN_TEST
//#define USE_LIN_TEST
//#define USE_ICTC_TEST
//#define USE_PDM_TEST
//#define USE_ADC_TEST
//#define USE_GIC_TEST
//#define USE_FWUG_TEST
//#define USE_SFMC_TEST
//#define USE_MIDF_TEST


/****************************************************************************************************/
/*                                       STATIC FUNCTIONS                                           */
/****************************************************************************************************/

static CLSConsoleCmdList_t *pGetConsoleCmdList
(
    uint32                              uiIndex
);

static void CSL_HelpList
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);

static uint32 CSL_StringToHex
(
    const int8                          *pucData
);

static void CSL_ReadMemory
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);

static void CSL_WriteMemory
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);

static void CSL_BootTime
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);

static void CSL_ClockInfo
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);


#if ( SIC_BSP_SUPPORT_APP_AP_RESET == 1 )
static void CSL_Reset
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif

static void CSL_SetAliveMessage
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);

static void CSL_DeviceUart
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#if (SIC_BSP_SUPPORT_TEST_APP_MBOX)
static void CSL_DeviceMbox
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif
#if ( SIC_BSP_SUPPORT_TEST_APP_GPIO == 1 )
static void CSL_DeviceGpio
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_GPIO == 1 )

#if ( SIC_BSP_SUPPORT_TEST_APP_TIMER == 1 )
static void CSL_DeviceTmr
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif // ( SIC_BSP_SUPPORT_TEST_APP_TIMER == 1 )

#if ( SIC_BSP_SUPPORT_DRIVER_PMIO)
static void CSL_DevicePmio
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif /* End of SIC_BSP_SUPPORT_DRIVER_PMIO*/

#if ( SIC_BSP_SUPPORT_DRIVER_RTC)
static void CSL_DeviceRtc
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif /* End of SIC_BSP_SUPPORT_DRIVER_RTC*/

#if ( SIC_BSP_SUPPORT_DRIVER_WDT)
static void CSL_DeviceWdt
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif /* End of SIC_BSP_SUPPORT_DRIVER_WDT*/

#if ( SIC_BSP_SUPPORT_DRIVER_SWDT & SIC_BSP_SUPPORT_TEST_APP_SWDT )
static void CSL_DeviceSwdt
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif /* End of SIC_BSP_SUPPORT_DRIVER_SWDT & SIC_BSP_SUPPORT_TEST_APP_SWDT */

static void CSL_DeviceMpu
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);

#if ( SIC_BSP_SUPPORT_TEST_APP_FMU )
static void CSL_DeviceFmu
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_PDM )
static void CSL_DevicePdm
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_ICTC )
static void CSL_DeviceIctc
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_GPSB )
static void CSL_DeviceGpsb
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_NVIC == 1 )
static void CSL_DeviceNvic
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_NVIC == 1 )

static void CSL_DeviceCkc
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);

#if ( SIC_BSP_SUPPORT_TEST_APP_GDMA == 1 )
static void CSL_DeviceGdma
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_GDMA == 1 )

#if ( SIC_BSP_SUPPORT_DRIVER_SDM & SIC_BSP_SUPPORT_TEST_APP_SDM )
static void CSL_DeviceSdm
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif

#if ( SIC_BSP_SUPPORT_APP_ETH == 1 )
static void CSL_DeviceGmac
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif  // ( SIC_BSP_SUPPORT_APP_ETH == 1 )

static void CSL_DeviceTrvc
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);

static void CSL_DevicePmu
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);

#if ( SIC_BSP_SUPPORT_TEST_APP_TOP == 1 )
static void CSL_DeviceTOP
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif  //  ( SIC_BSP_SUPPORT_TEST_APP_TOP == 1 )

#if (SIC_BSP_SYS_PV_SFMC == 1)
static void CSL_DeviceSfmc
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif  // ( SIC_BSP_SYS_PV_SFMC == 1 )

#if (SIC_BSP_SYS_PV_SUBSYS == 1)
static void CSL_DeviceSubsys
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif  // ( SIC_BSP_SYS_PV_SUBSYS == 1 )

#if ( SIC_BSP_SUPPORT_TEST_APP_I2C == 1 )
static void CSL_DeviceI2c
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_SWRAP == 1 )
static void CSL_DeviceSwrp
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif  //  ( SIC_BSP_SUPPORT_TEST_APP_SWRAP == 1 )

#if ( SIC_BSP_SUPPORT_TEST_APP_DSE )
static void CSL_DeviceDse
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif

#if ( SIC_BSP_SUPPORT_DRIVER_SSM & SIC_BSP_SUPPORT_TEST_APP_SSM )
static void CSL_DeviceSsm
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif

static void CSL_DeviceMidf
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);

static void CSL_EnableLog
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);

#if ( SIC_BSP_SUPPORT_DRIVER_HSM == 1 )
static void CSL_DeviceHsm
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_HSM == 1 )

#if ( SIC_BSP_SUPPORT_DRIVER_ADC == 1 )
static void CSL_DeviceAdc
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif

#if ( SIC_BSP_SUPPORT_CAN_DEMO == 1 )
static void CSL_DeviceCan
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif

static sint32 CSL_EmptyHistoryList
(
    void
);

static uint32 CSL_PullHistoryList
(
    uint8 *                             pucCmdBuf,
    uint32                              uiOldCmdSize
);

static void CSL_PushHistoryList
(
    const uint8 *                       pucBuf,
    uint32                              uiCmdSize
);

static void ConsoleTask
(
    void *                              pArg
);

static uint32 CSL_GetOneWordLength
(
    const uint8 *                       puiCmdBuf,
    uint32                              uiCmdLength
);

static uint32 CSL_GetCommandLength
(
    const uint8 *                       puiCmdBuf
);

static void CSL_ExecuteCommand
(
    uint8 *                             puiCmdBuf,
    uint32                              uiCmdLength
);

static void CSL_LogCmdType01
(
    void * const                        pArgv[]
);

static void CSL_LogCmdType02
(
    void * const                        pArgv[]
);

static void CSL_LogCmdType03
(
    void * const                        pArgv[]
);

static void CSL_UsageLogCmd
(
    uint8 ucInfo,
    uint8 ucHelp
);

static void CSL_ShowLogInfo
(
    void
);

#if ( SIC_BSP_SUPPORT_TEST_APP_LPA_MA == 1 )
static void CSL_DeviceLpaIni
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);

static void CSL_DeviceLpaTx
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);

static void CSL_DeviceCanConverter
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_LPA_SA == 1 )
#if ( SIC_BSP_SUPPORT_IPC_DATA_SEND == 1 )
static void CSL_DeviceLpaSfTx
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif
static void CSL_DeviceLpaSfCtrl
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_TPA == 1 )
static void CSL_DeviceTpaTx
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);

static void CSL_DeviceTpaRx
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);

static void CSL_DeviceTSNC
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif

#if (SIC_BSP_SUPPORT_PV_LPA == 1)
static void CSL_DeviceLpaPv
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif

#if (SIC_BSP_SUPPORT_DRIVER_LPA_TEST == 1)
static void CSL_DeviceLpaDrvTest
(
    uint8                               ucArgc,
    void * const                        pArgv[]
);
#endif

/*
***************************************************************************************************
*                                        DEFINITIONS
***************************************************************************************************
*/
//{ CMD_ENABLE, (uint8 *)string you want,  will be executed function}

static CLSConsoleCmdList_t ConsoleCmdList[CSL_CMD_NUM_MAX] =
{
    { CMD_ENABLE,   (const uint8 *)"help",     CSL_HelpList},
    { CMD_ENABLE,   (const uint8 *)"md",       CSL_ReadMemory},
    { CMD_ENABLE,   (const uint8 *)"mm",       CSL_WriteMemory},
    { CMD_ENABLE,   (const uint8 *)"boottime", CSL_BootTime},
    { CMD_ENABLE,   (const uint8 *)"clkinfo",  CSL_ClockInfo},
#if ( SIC_BSP_SUPPORT_APP_AP_RESET == 1 )
    { CMD_ENABLE,   (const uint8 *)"reset",    CSL_Reset},
#endif
    { CMD_ENABLE,   (const uint8 *)"alive",    CSL_SetAliveMessage},
    { CMD_ENABLE,   (const uint8 *)"uart",     CSL_DeviceUart},
#if (SIC_BSP_SUPPORT_TEST_APP_MBOX)
    { CMD_ENABLE,   (const uint8 *)"mbox",     CSL_DeviceMbox},
#endif
#if ( SIC_BSP_SUPPORT_TEST_APP_GPIO == 1 )
    { CMD_ENABLE,   (const uint8 *)"gpio",     CSL_DeviceGpio},
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_GPIO == 1 )
#if ( SIC_BSP_SUPPORT_TEST_APP_TIMER == 1 )
    { CMD_ENABLE,   (const uint8 *)"tmr",      CSL_DeviceTmr},
#endif // ( SIC_BSP_SUPPORT_TEST_APP_TIMER == 1 )
#if ( SIC_BSP_SUPPORT_DRIVER_PMIO)
    { CMD_ENABLE,   (const uint8 *)"pmio",      CSL_DevicePmio},
#endif /* End of SIC_BSP_SUPPORT_DRIVER_PMIO*/
#if ( SIC_BSP_SUPPORT_DRIVER_RTC)
    { CMD_ENABLE,   (const uint8 *)"rtc",      CSL_DeviceRtc},
#endif /* End of SIC_BSP_SUPPORT_DRIVER_RTC*/
#if ( SIC_BSP_SUPPORT_DRIVER_WDT)
    { CMD_ENABLE,   (const uint8 *)"wdt",      CSL_DeviceWdt},
#endif /* End of SIC_BSP_SUPPORT_DRIVER_WDT*/
#if ( SIC_BSP_SUPPORT_DRIVER_SWDT & SIC_BSP_SUPPORT_TEST_APP_SWDT )
    { CMD_ENABLE,   (const uint8 *)"swdt",     CSL_DeviceSwdt},
#endif /* End of SIC_BSP_SUPPORT_DRIVER_WDT & SIC_BSP_SUPPORT_TEST_APP_WDT */
    { CMD_ENABLE,   (const uint8 *)"mpc",      CSL_DeviceMpu},
#if ( SIC_BSP_SUPPORT_TEST_APP_FMU )
    { CMD_ENABLE,   (const uint8 *)"fmu",      CSL_DeviceFmu},
#endif
#if ( SIC_BSP_SUPPORT_TEST_APP_PDM == 1 )
    { CMD_ENABLE,   (const uint8 *)"pdm",      CSL_DevicePdm},
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_ICTC == 1 )
    { CMD_ENABLE,   (const uint8 *)"ictc",     CSL_DeviceIctc},
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_GPSB == 1 )
    { CMD_ENABLE,   (const uint8 *)"gpsb",     CSL_DeviceGpsb},
#endif
#if ( SIC_BSP_SUPPORT_TEST_APP_I2C == 1 )
    { CMD_ENABLE,   (const uint8 *)"i2c",      CSL_DeviceI2c},
#endif
#if ( SIC_BSP_SUPPORT_TEST_APP_NVIC == 1 )
    { CMD_ENABLE,   (const uint8 *)"nvic",     CSL_DeviceNvic},
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_NVIC == 1 )
    { CMD_ENABLE,   (const uint8 *)"ckc",      CSL_DeviceCkc},
#if ( SIC_BSP_SUPPORT_TEST_APP_GDMA == 1 )
    { CMD_ENABLE,   (const uint8 *)"gdma",     CSL_DeviceGdma},
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_GDMA == 1 )
#if ( SIC_BSP_SUPPORT_DRIVER_SDM & SIC_BSP_SUPPORT_TEST_APP_SDM )
    { CMD_ENABLE,   (const uint8 *)"sdm",      CSL_DeviceSdm},
#endif
#if ( SIC_BSP_SUPPORT_TEST_APP_DSE )
    { CMD_ENABLE,   (const uint8 *)"dse",      CSL_DeviceDse},
#endif

#if ( SIC_BSP_SUPPORT_APP_ETH == 1 )
    { CMD_ENABLE,   (const uint8 *)"gmac",     CSL_DeviceGmac},
#endif  // ( SIC_BSP_SUPPORT_APP_ETH == 1 )

#if ( SIC_BSP_SUPPORT_DRIVER_SSM & SIC_BSP_SUPPORT_TEST_APP_SSM )
    { CMD_ENABLE,   (const uint8 *)"ssm",      CSL_DeviceSsm},
#endif
    { CMD_ENABLE,   (const uint8 *)"midf",     CSL_DeviceMidf},
    { CMD_ENABLE,   (const uint8 *)"log",      CSL_EnableLog},
#if ( SIC_BSP_SUPPORT_DRIVER_HSM == 1 )
    { CMD_ENABLE,   (const uint8 *)"hsm",      CSL_DeviceHsm},
#endif  // ( SIC_BSP_SUPPORT_DRIVER_HSM == 1 )
    { CMD_ENABLE,   (const uint8 *)"trvc",     CSL_DeviceTrvc},
    { CMD_ENABLE,   (const uint8 *)"pmu",      CSL_DevicePmu},
#if ( SIC_BSP_SUPPORT_TEST_APP_TOP == 1 )
    { CMD_ENABLE,   (const uint8 *)"top",      CSL_DeviceTOP},
#endif   //  ( SIC_BSP_SUPPORT_TEST_APP_TOP == 1 )
#if (SIC_BSP_SYS_PV_SFMC == 1)
    { CMD_ENABLE,   (const uint8 *)"sfmc",     CSL_DeviceSfmc},
#endif  // ( SIC_BSP_SYS_PV_SFMC == 1 )

#if (SIC_BSP_SYS_PV_SUBSYS == 1)
    { CMD_ENABLE,   (const uint8 *)"subsys",     CSL_DeviceSubsys},
#endif  // ( SIC_BSP_SYS_PV_SUBSYS == 1 )

#if ( SIC_BSP_SUPPORT_TEST_APP_ADC == 1 )
    { CMD_ENABLE,   (const uint8 *)"adc",     CSL_DeviceAdc},
#endif
#if ( SIC_BSP_SUPPORT_CAN_DEMO == 1 )
    { CMD_ENABLE,   (const uint8 *)"can",     CSL_DeviceCan},
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_SWRAP == 1 )
    { CMD_ENABLE,   (const uint8 *)"swrp",     CSL_DeviceSwrp},
#endif  //  ( SIC_BSP_SUPPORT_TEST_APP_SWRAP == 1 )

#if ( SIC_BSP_SUPPORT_TEST_APP_LPA_MA == 1 )
    { CMD_ENABLE,   (const uint8 *)"lpa",   CSL_DeviceLpaIni},
    { CMD_ENABLE,   (const uint8 *)"lpatx",    CSL_DeviceLpaTx},
    { CMD_ENABLE,   (const uint8 *)"convert",  CSL_DeviceCanConverter},
#endif
#if ( SIC_BSP_SUPPORT_TEST_APP_LPA_SA == 1 )
#if ( SIC_BSP_SUPPORT_IPC_DATA_SEND == 1 )
    { CMD_ENABLE,   (const uint8 *)"sftx",   CSL_DeviceLpaSfTx},
#endif
    { CMD_ENABLE,   (const uint8 *)"lpa",   CSL_DeviceLpaSfCtrl},
#endif
#if ( SIC_BSP_SUPPORT_TEST_APP_TPA == 1 )
    { CMD_ENABLE,   (const uint8 *)"tpatx",    CSL_DeviceTpaTx},
#endif
#if (SIC_BSP_SUPPORT_PV_LPA == 1)
    { CMD_ENABLE,   (const uint8 *)"lpapv",  CSL_DeviceLpaPv},
#endif
#if (SIC_BSP_SUPPORT_DRIVER_LPA_TEST == 1)
	{ CMD_ENABLE,	(const uint8 *)"lpadrv",  CSL_DeviceLpaDrvTest},
#endif
    { CMD_DISABLE,  (const uint8 *)"",         NULL}
};

static CLSConsoleLogFunc_t ConsoleLogFunc[CSL_LOG_NUM_MAX] =
{
    {CSL_LogCmdType01},
    {CSL_LogCmdType02},
    {CSL_LogCmdType03}
};


/*
***************************************************************************************************
*                                    FUNCTION PROTOTYPES
***************************************************************************************************
*/

static CLSConsoleCmdList_t *pGetConsoleCmdList(uint32 uiIndex)
{
    return &ConsoleCmdList[uiIndex];
}

static void CSL_HelpList(uint8 ucArgc, void * const pArgv[])
{
    uint8 uMsg[51] = {0, };

    (void)  ucArgc;
    (void)  pArgv;

    (void) SAL_MemSet(uMsg, 0x00, 51);
    (void) SAL_StrCopy(uMsg, (const uint8 *) "\r\n================================================\0");
    (void) UART_Write(UART_DEBUG_CH, (const uint8 *) uMsg, 50);


    (void) SAL_MemSet(uMsg, 0x00, 51);
    (void) SAL_StrCopy(uMsg, (const uint8 *) "\r\n============== How to use command ==============\0");
    (void) UART_Write(UART_DEBUG_CH, (const uint8 *) uMsg, 50);

    (void) SAL_MemSet(uMsg, 0x00, 51);
    (void) SAL_StrCopy(uMsg, (const uint8 *) "\r\n================================================\0");
    (void) UART_Write(UART_DEBUG_CH, (const uint8 *) uMsg, 50);

    (void) SAL_MemSet(uMsg, 0x00, 51);
    (void) SAL_StrCopy(uMsg, (const uint8 *) "\r\n [command_string] [arg1] ... [arg10]\0");
    (void) UART_Write(UART_DEBUG_CH, (const uint8 *) uMsg, 38);

    (void) SAL_MemSet(uMsg, 0x00, 51);
    (void) SAL_StrCopy(uMsg, (const uint8 *) "\n\0");
    (void) UART_Write(UART_DEBUG_CH, (const uint8 *)uMsg, 1);

    (void) SAL_MemSet(uMsg, 0x00, 51);
    (void) SAL_StrCopy(uMsg, (const uint8 *) "\r\n 1. display alive message : [alive] [on/off]\0");
    (void) UART_Write(UART_DEBUG_CH, (const uint8 *) uMsg, 46);

    (void) SAL_MemSet(uMsg, 0x00, 51);
    (void) SAL_StrCopy(uMsg, (const uint8 *) "\n\0");
    (void) UART_Write(UART_DEBUG_CH, (const uint8 *) uMsg, 1);
}

static void CSL_BootTime(uint8 ucArgc, void * const pArgv[])
{
    uint32  uiAddr;
    uint32  uiValue;
    uint32  uiCnt;
    uint8   uiTitle[32][32] =
            {
                "Setup BL         ",
                "Initailize Device",
                "Post-Initialize  ",
                "Load MCERT       ",
                "Load HSM F/W     ",
                "Load SIC H/W HDR ",
                "Load SIC F/W     ",
                "Wait HSM F/W ver.",
                "SIC F/W ver.     ",
                "Set HSM Ready    "
            };

    uiAddr      = 0U;
    uiValue     = 0U;
    uiCnt       = 0UL;

    mcu_printf("\n* Report Boot timestamp (B+ on ~ SIC F/W ) *\n\n");

    mcu_printf("From BU ON ~\n");

    for(uiAddr = BOOTTIME_ADDR_START; uiAddr < BOOTTIME_ADDR_END; uiAddr += 4U)
    {
        uiValue = SAL_ReadReg(uiAddr);

        mcu_printf("  Until %s \t %d (us)\n", uiTitle[uiCnt++], uiValue + BOOT_INITIAL_FIX_TIME);
    }

    mcu_printf("\n  * SIC F/W start time    \t about %d (us)\n", uiValue + BOOT_INITIAL_FIX_TIME);

}

static void CSL_ClockInfo(uint8 ucArgc, void * const pArgv[])
{
    char * clk_src_name[11] =
    {
        "PLL0    ",
        "PLL1    ",
        "PLL2    ",
        "PLL3    ",
        "Reserved",
        "XIN     ",
        "Div_PLL0",
        "Div_PLL1",
        "Div_PLL2",
        "Div_PLL3",
        "Div_XIN "
    };

    char * ctrl_src_name[11] =
    {
        "SMU Sub system    ",
        "CPU Sub system    ",
        "MCU-0 Wrapper     ",
        "MCU-1 Wrapper     ",
        "MCU-2 Wrapper     ",
        "LPDDR             ",
        "HSIO Sub system   ",
        "EPP system        ",
        "Network Sub system",
        "IO Sub system     ",
        "HSM Sub system"
        //"PCIe Sub system",
        //"SDMMC Sub system",
    };

	mcu_printf("====== Clock Source Information =======================\n");
    for(uint8 src_id = 0; src_id < 10; src_id++)
    {
        mcu_printf("[%d] %s \t: %u MHz \n", src_id, clk_src_name[src_id], CLOCK_GetPllRate(src_id) / 1000000UL);
    }

	mcu_printf("====== Bus Clock Information ==========================\n");
    for(uint8 ctrl_id = 0; ctrl_id < 11; ctrl_id++)
    {
        mcu_printf("[%d] %s \t: %u MHz\n", ctrl_id, ctrl_src_name[ctrl_id], CLOCK_GetClkCtrlRate(ctrl_id) / 1000000UL);
    }
	mcu_printf("====== Memory Clock Information =======================\n");
	mcu_printf("DDR Clock: %u MHz\n", (CLOCK_GetClkCtrlRate(5) / 1000000UL));
	mcu_printf("MEM Clock: %u MHz\n", (CLOCK_GetClkCtrlRate(5) / 1000000UL) / 2UL);
	mcu_printf("MEM_SVC Clock: %u MHz\n", (CLOCK_GetClkCtrlRate(5) / 1000000UL) / 4UL);
	mcu_printf("=======================================================\n");

}


#if ( SIC_BSP_SUPPORT_APP_AP_RESET == 1 )
static void CSL_Reset
(
    uint8                               ucArgc,
    void * const                        pArgv[]
)
{
    const uint8 *str;
#if ( SIC_BSP_SUPPORT_APP_AP_SYSTEM_RESET == 1 )
    sint32 ret;
#endif

    (void) ucArgc;

    str = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str, &pArgv[0], sizeof(uint8 *));

        if (str != NULL)
        {
#if ( SIC_BSP_SUPPORT_APP_AP_SYSTEM_RESET == 1 )
            if((SAL_StrNCmp(str, (uint8 *)"cold", 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                (void)RESET_Cold();
            }
            else if((SAL_StrNCmp(str, (uint8 *)"ap1", 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                (void)RESET_WarmApWithSafety();
            }
            else if((SAL_StrNCmp(str, (uint8 *)"ap2", 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                (void)RESET_WarmApWithoutSafety();
            }
            else
            {
                mcu_printf("\nWrong argument : %s\n", str);
            }
#endif
        }
        else
        {
            mcu_printf("\nInvalid argument\n");
        }
    }
}
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_LPA_MA == 1 )
static void CSL_DeviceLpaIni(uint8 ucArgc, void * const pArgv[])
{
	LPA_Init_CLI(ucArgc, pArgv);
}

static void CSL_DeviceLpaTx(uint8 ucArgc, void * const pArgv[])
{
	LPA_Tx_CLI(ucArgc, pArgv);
}

static void CSL_DeviceCanConverter(uint8 ucArgc, void * const pArgv[])
{
//	CANCnvt_UART(ucArgc, pArgv);
}
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_LPA_SA == 1 )
#if ( SIC_BSP_SUPPORT_IPC_DATA_SEND == 1 )
static void CSL_DeviceLpaSfTx(uint8 ucArgc, void * const pArgv[])
{
	LPA_SF_CLI(ucArgc, pArgv);
}
#endif

static void CSL_DeviceLpaSfCtrl(uint8 ucArgc, void * const pArgv[])
{
	LPA_SF_CTRL_CLI(ucArgc, pArgv);
}

#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_TPA == 1 )
static void CSL_DeviceTpaTx(uint8 ucArgc, void * const pArgv[])
{
	TPA_TX_UART(ucArgc, pArgv);
}

//static void CSL_DeviceTpaRx(uint8 ucArgc, void * const pArgv[])
//{
//	TPA_RX_UART(ucArgc, pArgv);
//}

//static void CSL_DeviceTSNC(uint8 ucArgc, void * const pArgv[])
//{
//	TSNC_UART(ucArgc, pArgv);
//}
#endif

#if (SIC_BSP_SUPPORT_PV_LPA == 1)
static void CSL_DeviceLpaPv(uint8 ucArgc, void * const pArgv[])
{
    const uint8 *str;
    int32 ret;
	uint32 test_id;

    (void)ucArgc;

    str = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str, &pArgv[0], sizeof(uint8 *));

        if (str != NULL)
        {
            if ((SAL_StrNCmp(str, (const uint8 *)"dma", 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {

                test_id = strtoul(pArgv[1], NULL, 10);

                ret = lpa_dma_iptest_main(test_id);

                if ( ret < 0)
                {
					mcu_printf("Result: FAIL \n");
                }
                else
                {
					mcu_printf("Result: PASS \n");
                }
				mcu_printf("===================================================================\n");
            }
            else if ((SAL_StrNCmp(str, (const uint8 *)"lpp", 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {

                test_id = strtoul(pArgv[1], NULL, 10);

                ret = lpa_lpp_iptest_main(test_id);

                if ( ret < 0)
                {
					mcu_printf("Result: FAIL \n");
                }
                else
                {
                    mcu_printf("Result: PASS \n");
                }
				mcu_printf("===================================================================\n");
            }
            else
            {
                mcu_printf("\nWrong argument : %s\n", str);
            }
        }
        else
        {
            mcu_printf("Invalid argument\n");
        }
    }
}
#endif

#if (SIC_BSP_SUPPORT_DRIVER_LPA_TEST == 1)
static void CSL_DeviceLpaDrvTest(uint8 ucArgc, void * const pArgv[])
{
	uint32 test_id;

    (void)ucArgc;

    if (pArgv != NULL_PTR)
    {
        test_id = strtoul(pArgv[0], NULL, 10);

        lpa_drv_test_main(test_id);
    }
}
#endif



#if ( SIC_BSP_SUPPORT_DRIVER_HSM == 1 )
static void CSL_DeviceHsm(uint8 ucArgc, void * const pArgv[])
{
    uint32 ret = 1;
    const int8 * cmd = NULL;

    (void) ucArgc;
    if (pArgv != NULL_PTR)
    {
        if (pArgv[0] != NULL)
        {
            (void) SAL_MemCopy(&cmd, &pArgv[0], sizeof(void *));
            if (cmd != NULL)
            {
                ret = HSM_Test(cmd);
                if(ret != 0UL){
                    mcu_printf("\n HSM_Test Fail(%d)\n", ret);
                }
            }
        }
        else
        {
            (void)mcu_printf("\n Wrong argument, argv(%s)\n", pArgv[0]);
        }
    }
}
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_HSM == 1 )

static void CSL_CopyPointer(uint8 *btmp, const int8 *pucData)
{
    (void) SAL_MemSet(btmp, 0x00, sizeof(int32));
    (void) SAL_MemCopy(&btmp[0], pucData, sizeof(uint8));
}

static uint32 CSL_StringToHex(const int8 *pucData)
{
    uint32 hex = 0;
    uint32 tmp = 0;
    uint8 *btmp = NULL;
    uint32 count = 0UL;
    uint32 i;

    if (pucData != NULL_PTR)
    {
        btmp = (uint8 *) &tmp;
        (void)SAL_StrLength(pucData, (SALSize *)&count);

        for (i = 0UL ; i < count; i++)
        {
            if((pucData[i] >= '0') && (pucData[i] <= '9'))
            {
                CSL_CopyPointer(btmp, &pucData[i]);
                if (((CSL_MAX_INT / 16UL) >= tmp) && (hex <= ((CSL_MAX_INT / 16UL) - tmp)))
                {
                    hex = (((hex * 16UL) + tmp) - 0x30UL); // 0x30 == '0'
                }
                else
                {
                    mcu_printf("%s int overflow\n", __func__);
                }
            }
            else if ((pucData[i] >= 'A') && (pucData[i] <= 'F'))
            {
                CSL_CopyPointer(btmp, &pucData[i]);
                if (((CSL_MAX_INT / 16UL) >= tmp) && (hex <= ((CSL_MAX_INT / 16UL) - tmp)))
                {
                    hex = ((((hex * 16UL) + tmp) - 0x41UL) + 10UL); // 0x41 == 'A'
                }
                else
                {
                    mcu_printf("%s int overflow\n", __func__);
                }
            }
            else if ((pucData[i] >= 'a') && (pucData[i] <= 'f'))
            {
                CSL_CopyPointer(btmp, &pucData[i]);
                if (((CSL_MAX_INT / 16UL) >= tmp) && (hex <= ((CSL_MAX_INT / 16UL) - tmp)))
                {
                    hex = ((((hex * 16UL) + tmp) - 0x61UL) + 10UL); // 0x61 == 'a'
                }
                else
                {
                    mcu_printf("%s int overflow\n", __func__);
                }
            }
            else
            {
                ; // Invalid value
            }

        }
    }

    return hex;
}

static void CSL_ReadMemory(uint8 ucArgc, void * const pArgv[])
{
    uint32* addr;
    uint32 ret;
    uint32 reg;
    const int8 * str;

    (void) ucArgc;

    addr = NULL;
    ret = 0L;
    reg = 0UL;
    str = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str, &pArgv[0], sizeof(int8 *));

        if (str != NULL)
        {
            ret = CSL_StringToHex(str);
            SAL_MemCopy(&addr, &ret, sizeof(uint32 *));

            if (addr != NULL)
            {
                reg = SAL_ReadReg(addr);
                mcu_printf("\n          0x%08x    ==>    0x%08x\n", addr, reg);
            }
        }
        else
        {
            mcu_printf("\n Wrong argument\n");
            mcu_printf("\n [md] [hex address] \n");
        }
    }
}

static void CSL_WriteMemory(uint8 ucArgc, void * const pArgv[])
{
    uint32   ret;
    uint32* addr;
    uint32  val;
    uint32  reg;
    const int8 * str0;
    const int8 * str1;

    (void) ucArgc;

    ret = 0L;
    addr = NULL;
    val = 0UL;
    reg = 0UL;
    str0 = NULL;
    str1 = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str0, &pArgv[0], sizeof(int8 *));
        (void) SAL_MemCopy(&str1, &pArgv[1], sizeof(int8 *));

        if ((str0 != NULL) && (str1 != NULL))
        {
            ret = CSL_StringToHex(str0);
            SAL_MemCopy(&addr, &ret, sizeof(uint32 *));
            ret = CSL_StringToHex(str1);
            SAL_MemCopy(&val, &ret, sizeof(uint32));

            if (addr != NULL)
            {
                SAL_WriteReg(val, addr);
                reg = SAL_ReadReg(addr);
                mcu_printf("\n          0x%x    ==>    0x%x\n", addr, reg);
            }
        }
        else
        {
            mcu_printf("\n Wrong argument\n");
            mcu_printf("\n [mm] [hex address] [value] \n");
        }
    }
}


static void CSL_SetAliveMessage(uint8 ucArgc, void * const pArgv[])
{
    const uint8 *str;
    const uint8 onbuf[2]    = "on";
    const uint8 offbuf[3]   = "off";
    sint32 ret;

    (void)ucArgc;

    str = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str, &pArgv[0], sizeof(uint8 *));

        if (str != NULL)
        {
            if((SAL_StrNCmp(str, onbuf, 2, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                gALiveMsgOnOff  = ON;
            }
            else if((SAL_StrNCmp(str, offbuf, 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                gALiveMsgOnOff  = OFF;
            }
            else
            {
                mcu_printf("Wrong argument : on or off %s\n", str);
            }
        }
        else
        {
            mcu_printf("Invalid argument\n");
        }
    }
}

static void CSL_DeviceUart(uint8 ucArgc, void * const pArgv[])
{
    (void) ucArgc;
    (void) pArgv;
}

#if (SIC_BSP_SUPPORT_TEST_APP_MBOX)
static void CSL_DeviceMbox(uint8 ucArgc, void * const pArgv[])
{
    uint8 *str;
    sint32 num = 0;

    (void) ucArgc;

    str = NULL;
    if (pArgv[0] != NULL_PTR)
    {

        (void) SAL_MemCopy(&str, &pArgv[0], sizeof(int8 *));

        errno = 0;
        if ((errno == 0))
        {
            errno = 0;
#if (TCN100x)
            num = str[0] - '0';
            MBOX_TEST_Start(num);
#else
            do_mboxtest(str);
#endif
        }
        else
        {
            mcu_printf("%s strtol fail\n", __func__);
        }
    }
    else
    {
        mcu_printf("Invalid argument\n");
    }
}
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_GPIO == 1 )
static void CSL_DeviceGpio(uint8 ucArgc, void * const pArgv[])
{
    const int8 * str;
    int32   siMode;

    (void)ucArgc;

    str = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str, &pArgv[0], sizeof(int8 *));

        if (str != NULL)
        {
            errno = 0;
            siMode  = strtol(str, NULL_PTR, 10);
            if ((siMode != 0L) || (errno == 0))
            {
                errno = 0;
                GPIO_StartGpioTest(siMode);
            }
            else
            {
                mcu_printf("%s strtol fail\n", __func__);
            }
        }
        else
        {
            mcu_printf("Invalid argument\n");
        }
    }
}
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_GPIO == 1 )

#if ( SIC_BSP_SUPPORT_TEST_APP_TIMER == 1 )
static void CSL_DeviceTmr(uint8 ucArgc, void * const pArgv[])
{
    sint32 ret;

    if (pArgv != NULL_PTR)
    {

        if (pArgv[0] != NULL)
        {

            if((SAL_StrNCmp(pArgv[0], (const uint8 *)"test", 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                if(ucArgc == 3u)
                {
                    TIMER_StartTimerTest(strtoul(pArgv[1], NULL_PTR, 10), strtoul(pArgv[2], NULL_PTR, 10));
                }
                else if(ucArgc == 2u)
                {
                    TIMER_StartTimerTest(strtoul(pArgv[1], NULL_PTR, 10), 0);
                }
                else
                {
                    mcu_printf("Invalid arguments\n");
                }
            }
            else
            {
                mcu_printf("Invalid arguments\n");
            }
        }
        else
        {
            mcu_printf("Invalid arguments\n");
        }
    }
    else
    {
        mcu_printf("Invalid arguments\n");
    }

}
#endif // ( SIC_BSP_SUPPORT_TEST_APP_TIMER == 1 )


#if ( SIC_BSP_SUPPORT_DRIVER_PMIO)
static void CSL_DevicePmio(uint8 ucArgc, void * const pArgv[])
{
    uint32      uiParam1;
    uint32      uiParam2;
    uint32      uiParam3;
    const uint8 *str;
    const uint8 ucInit[4] = "init";
    const uint8 ucPd[9] = "powerdown";
    const uint8 ucPort[4] = "port";
    const uint8 ucIntr[4] = "intr";
    const uint8 ucWkup[4] = "wkup";
    const uint8 ucGetWkup[9] = "getwakeup";
    const uint8 ucSetBack[9] = "setbackup";
    const uint8 ucGetBack[9] = "getbackup";
    sint32      ret;
    sint32      iCmdExecution = 0;

    (void)ucArgc;

    if (pArgv[0] != NULL_PTR)
    {
        str     = (const uint8 *)pArgv[0];

        if((SAL_StrNCmp(str, ucInit, 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            iCmdExecution ++;
            PMIO_Init();
        }

        if((SAL_StrNCmp(str, ucPd, 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            iCmdExecution ++;
            PMIO_PowerDown();
        }

        if((SAL_StrNCmp(str, ucPort, 2, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            if(ucArgc == 3U)
            {
                iCmdExecution ++;
                uiParam1   = strtol(pArgv[1], NULL_PTR, 16UL);
                uiParam2   = strtol(pArgv[2], NULL_PTR, 10UL);

                PMIO_SetPortType(uiParam1, uiParam2);//port32, sel type
            }
        }

        if((SAL_StrNCmp(str, ucIntr, 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            if(ucArgc == 3U)
            {
                iCmdExecution ++;
                uiParam1   = strtol(pArgv[1], NULL_PTR, 16UL);
                uiParam2   = strtol(pArgv[2], NULL_PTR, 10UL);

                PMIO_SetPortIntr(uiParam1, uiParam2, &PMIO_PowerDown);//port32, intr type
            }
        }

        if((SAL_StrNCmp(str, ucWkup, 2, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            if(ucArgc == 3U)
            {
                iCmdExecution ++;
                uiParam1   = strtol(pArgv[1], NULL_PTR, 16UL);
                uiParam2   = strtol(pArgv[2], NULL_PTR, 10UL);

                PMIO_SetPortWkup(uiParam1, uiParam2);//port32, wkup type
            }
        }

        if((SAL_StrNCmp(str, ucGetWkup, 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            if(ucArgc == 2U)
            {
                iCmdExecution ++;
                uiParam1   = strtol(pArgv[1], NULL_PTR, 16UL);

                mcu_printf("wakeup status 0x%08x\n", PMIO_GetPortWkup(uiParam1)); //port32
            }
        }

        if((SAL_StrNCmp(str, ucSetBack, 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            if(ucArgc == 4U)
            {
                iCmdExecution ++;
                uiParam1   = strtol(pArgv[1], NULL_PTR, 16UL);
                uiParam2   = strtol(pArgv[2], NULL_PTR, 10UL);
                uiParam3   = strtol(pArgv[3], NULL_PTR, 16UL);

                PMIO_SetBackupRam(uiParam1, uiParam2, uiParam3);//addr, size, value
            }
        }

        if((SAL_StrNCmp(str, ucGetBack, 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            if(ucArgc == 2U)
            {
                iCmdExecution ++;
                uiParam1   = strtol(pArgv[1], NULL_PTR, 16UL);

                mcu_printf("read backupram: 0x%08x\n", PMIO_GetBackupRam(uiParam1));
            }
        }
    }

    if(iCmdExecution == 0L)
    {
        mcu_printf("\ncmd list\n");
        mcu_printf("    pmio init\n");
        mcu_printf("    pmio powerdown\n");
        mcu_printf("    pmio port [port32:h] [sel_type:d]\n");
        mcu_printf("        [sel_type]  : PMIO_PORT_DISABLE        = 0\n");
        mcu_printf("        [sel_type]  : PMIO_PORT_GPIO           = 1\n");
        mcu_printf("        [sel_type]  : PMIO_PORT_PM_IN          = 2\n");
        mcu_printf("        [sel_type]  : PMIO_PORT_PM_OUT_L       = 3\n");
        mcu_printf("        [sel_type]  : PMIO_PORT_PM_OUT_H       = 4\n");
        mcu_printf("        [sel_type]  : PMIO_PORT_PU             = 5\n");
        mcu_printf("        [sel_type]  : PMIO_PORT_PD             = 6\n");
        mcu_printf("    pmio intr [port32:h] [intr_type:d]\n");
        mcu_printf("        [sel_type]  : PMIO_INTR_R_EDGE = 0\n");
        mcu_printf("        [sel_type]  : PMIO_INTR_F_EDGE = 1\n");
        mcu_printf("        [sel_type]  : PMIO_INTR_B_EDGE = 2\n");
        mcu_printf("        [sel_type]  : PMIO_INTR_R_LEVEL= 3\n");
        mcu_printf("        [sel_type]  : PMIO_INTR_F_LEVEL= 4\n");
        mcu_printf("    pmio wkup [port32:h] [wkup_type:d]\n");
        mcu_printf("        [sel_type]  : PMIO_WKUP_R_EDGE = 0\n");
        mcu_printf("        [sel_type]  : PMIO_WKUP_F_EDGE = 1\n");
        mcu_printf("    pmio getwakeup [port32:h]\n");
        mcu_printf("    pmio setbackup [addr:h] [size:d] [value:h]\n");
        mcu_printf("    pmio getbackup [addr:h]\n");
        mcu_printf("        [addr    ]  : 0x000 ~ 0x3FC\n");
        mcu_printf("        [size    ]  : 0x000\n");
    }
}

#endif /* End of SIC_BSP_SUPPORT_DRIVER_PMIO*/

#if ( SIC_BSP_SUPPORT_DRIVER_RTC)
static void CSL_DeviceRtc(uint8 ucArgc, void * const pArgv[])
{
    uint32      uiParam[7] = {0,0,0,0,0,0,0};
    uint32      uiPrevParam[7] = {0,0,0,0,0,0,0};
    uint32      uiIdx;
    uint32      uiParamMax=7UL;
    uint32      uiPrintCnt = 0UL;
    static uint32 uiInit = 0UL;
    const uint8 *str;
    const uint8 ucAlarm[5] = "alarm";
    sint32      ret;
    sint32      iCmdExecution = 0;

    (void)ucArgc;

    if(uiInit == 0UL)
    {
        RTC_Init();
        uiInit++;
    }

    if (pArgv[0] != NULL_PTR)
    {
        str     = (const uint8 *)pArgv[0];

        if((SAL_StrNCmp(str, ucAlarm, 2, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            iCmdExecution ++;

            RTC_EnableAlarm(RTC_IRQ_DISABLE);

            RTC_ClearAlarm();

            RTC_SetTime(2024,6,30,RTC_DAY_SUN,12,59,45);

            RTC_SetAlarm(2024,6,30,RTC_DAY_SUN,12,59,50, &RTCTestHandler);

            RTC_EnableAlarm(RTC_IRQ_ALARM);

            while(uiPrintCnt < 5UL)
            {
                RTC_GetTime(
                        &(uiParam[0]),     //*uiYear,
                        &(uiParam[1]),     //*uiMon,
                        &(uiParam[2]),     //*uiDate,
                        &(uiParam[3]),     //*uiDay,
                        &(uiParam[4]),     //*uiHour,
                        &(uiParam[5]),     //*uiMin,
                        &(uiParam[6])     //*uiSec
                        );

                if(uiParam[6] != uiPrevParam[6])
                {
                    mcu_printf("current time %d-%d-%d(%d), %d:%d:%d\n",
                            uiParam[0],
                            uiParam[1],
                            uiParam[2],
                            uiParam[3],
                            uiParam[4],
                            uiParam[5],
                            uiParam[6]
                            );

                    uiPrintCnt++;

                    for(uiIdx = 0UL ; uiIdx < uiParamMax ; uiIdx++)
                    {
                        uiPrevParam[uiIdx]   = uiParam[uiIdx];
                    }
                }
            }
        }
    }

    if(iCmdExecution == 0L)
    {
        mcu_printf("\ncmd list\n");
        mcu_printf("    rtc alarm\n");
    }
}

static void RTCTestHandler
(
    void
)
{
    RTC_ClearAlarm();
    RTC_EnableAlarm(RTC_IRQ_DISABLE);
    mcu_printf("rtc alarm!\n");
}
#endif /* End of SIC_BSP_SUPPORT_DRIVER_PMIO*/

#if ( SIC_BSP_SUPPORT_DRIVER_WDT)
static void CSL_DeviceWdt(uint8 ucArgc, void * const pArgv[])
{
    uint32      uiParam1;
    uint32      uiParam2;
    uint32      uiParam3;
    const uint8 *str;
    const uint8 ucBufEn[6] = "enable";
    const uint8 ucBufDis[7] = "disable";
    /*
    const uint8 ucBufSm[2] = "sm";
    const uint8 ucBufNoKick[6] = "nokick";
    */
    sint32      ret;

    (void)ucArgc;

    if (pArgv != NULL_PTR)
    {
        str     = (const uint8 *)pArgv[0];

        if((SAL_StrNCmp(str, ucBufEn, 2, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            uiParam1   = strtol(pArgv[1], NULL_PTR, 10UL);
            uiParam2   = strtol(pArgv[2], NULL_PTR, 10UL);
            uiParam3  = strtol(pArgv[3], NULL_PTR, 10UL);

            (void)WDT_Enable(uiParam1, WDT_SEC(uiParam2), WDT_SEC(uiParam3));
        }
        else if((SAL_StrNCmp(str, ucBufDis, 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            uiParam1   = strtol(pArgv[1], NULL_PTR, 10UL);

            (void)WDT_Disable(uiParam1);
        }
        /*
        else if((SAL_StrNCmp(str, ucBufSm, 2, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            uiParam1   = strtol(pArgv[1], NULL_PTR, 10UL);
            uiParam2   = strtol(pArgv[2], NULL_PTR, 10UL);
            uiParam3  = strtol(pArgv[3], NULL_PTR, 10UL);

            (void)WDT_Disable(uiParam1);

            if(uiParam3 == 0)
            {
                uiParam3 = (uint32)WDT_SM_SIG_PMU_RST;
            }
            else if(uiParam3 == 1)
            {
                uiParam3 = (uint32)WDT_SM_SIG_FMU_HANDSHAKE;

                //FMU_SVL_LOW  = 0U,
                //FMU_SVL_MID  = 1U,
                //FMU_SVL_HIGH = 2U,

                (void)FMU_IsrHandler(
                                       (FMUFaultid_t)55U,
                                       FMU_SVL_LOW,
                                       (FMUIntFnctPtr)&WDTTest_FmuHandler,
                                       NULL_PTR
                                    );

                (void)FMU_IsrHandler(
                                       (FMUFaultid_t)67U,
                                       FMU_SVL_LOW,
                                       (FMUIntFnctPtr)&WDTTest_FmuHandler,
                                       NULL_PTR
                                    );

                (void)FMU_IsrHandler(
                                       (FMUFaultid_t)79U,
                                       FMU_SVL_LOW,
                                       (FMUIntFnctPtr)&WDTTest_FmuHandler,
                                       NULL_PTR
                                    );

                (void)FMU_Set((FMUFaultid_t)55U);
                (void)FMU_Set((FMUFaultid_t)67U);
                (void)FMU_Set((FMUFaultid_t)79U);
            }
            else
            {
                uiParam3 = (uint32)WDT_SM_SIG_FMU_NO_HANDSHAKE;
            }

            (void)WDT_SmMode(uiParam1, (WDTSmVote_t)uiParam2, (WDTSmSig_t)uiParam3);

            (void)WDT_Enable(uiParam1, WDT_SEC(1UL),WDT_SEC(1UL));
        }
        else if((SAL_StrNCmp(str, ucBufNoKick, 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            (void)NVIC_IntSrcDis(M7_0_WDT_IRQn);
            (void)NVIC_IntSrcDis(M7_1_WDT_IRQn);
            (void)NVIC_IntSrcDis(M7_2_WDT_IRQn);
        }
        */
        else
        {
            mcu_printf("\nWrong argument : %s\n", pArgv[0]);
        }
    }
}

/*
static void WDTTest_FmuHandler
(
    void *                              pArg
)
{
    (void)pArg;

    mcu_printf("Handshake with FMU\n");
    (void)FMU_IsrClr((FMUFaultid_t)55);
    (void)FMU_IsrClr((FMUFaultid_t)67);
    (void)FMU_IsrClr((FMUFaultid_t)79);
}
*/
#endif /* End of SIC_BSP_SUPPORT_DRIVER_WDT & SIC_BSP_SUPPORT_TEST_APP_WDT */

#if ( SIC_BSP_SUPPORT_DRIVER_SWDT & SIC_BSP_SUPPORT_TEST_APP_SWDT )
static void CSL_DeviceSwdt(uint8 ucArgc, void * const pArgv[])
{
    int32       iMode;
    const uint8 *str;
    const uint8 ucBufTest[4] = "test";
    sint32      ret;

    (void)ucArgc;

    if (pArgv != NULL_PTR)
    {
        str     = (const uint8 *)pArgv[0];
        iMode   = strtol(pArgv[1], NULL_PTR, 10UL);

        if((SAL_StrNCmp(str, ucBufTest, 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            SWDT_StartTest(iMode);
        }
        else
        {
            mcu_printf("\nWrong argument : %s\n", pArgv[0]);
        }
    }
}
#endif /* End of SIC_BSP_SUPPORT_DRIVER_SWDT & SIC_BSP_SUPPORT_TEST_APP_SWDT */

static void CSL_DeviceMpu(uint8 ucArgc, void * const pArgv[])
{
    (void)ucArgc;
    (void)pArgv;
}

#if ( SIC_BSP_SUPPORT_TEST_APP_FMU )
static void CSL_DeviceFmu(uint8 ucArgc, void * const pArgv[])
{
    const int8 *str0;
    int32 siMode;

    (void)ucArgc;

    str0 = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str0, &pArgv[0], sizeof(int8 *));

        if (str0 != NULL)
        {
            errno = 0;
            siMode  = strtol(str0, NULL_PTR, 10);
            if ((siMode != 0L) || (errno == 0))
            {
                errno = 0;
                FMU_TEST_Start(siMode);
            }
            else
            {
                mcu_printf("%s strtol fail\n", __func__);
            }
        }
        else
        {
            mcu_printf("Invalid argument\n");
        }
    }
}
#endif  /* End of SIC_BSP_SUPPORT_TEST_APP_FMU */

#if ( SIC_BSP_SUPPORT_TEST_APP_PDM == 1 )
static void CSL_DevicePdm(uint8 ucArgc, void * const pArgv[])
{
    uint32   ucMode;

    (void)ucArgc;

    if (pArgv != NULL_PTR)
    {
        ucMode  = strtoul(pArgv[0], NULL_PTR, 10UL);
        PDM_SelectTestCase(ucMode);
    }
}
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_ICTC == 1 )
static void CSL_DeviceIctc(uint8 ucArgc, void * const pArgv[])
{
    uint32   ucMode;

    (void)ucArgc;

    if (pArgv != NULL_PTR)
    {
        ucMode  = strtoul(pArgv[0], NULL_PTR, 10UL);
        ICTC_SelectTestCase(ucMode);
    }
}
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_GPSB == 1 )
static void CSL_DeviceGpsb(uint8 ucArgc, void * const pArgv[])
{
    const uint8 *str;
    const uint8 ucBufTest[4] = "test";
	const uint8 ucBufExternal_Port_Output[4] = "port";
    sint32          ret;

    (void)ucArgc;

    str = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str, &pArgv[0], sizeof(uint8 *));

        if (str != NULL)
        {
            if((SAL_StrNCmp(str, ucBufTest, 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                GPSB_Test();
            }
			else if((SAL_StrNCmp(str, ucBufExternal_Port_Output, 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
			{
				GPSB_External_Communication_Test();
			}
            else
            {
                mcu_printf("\nWrong argument : %s\n", pArgv[0]);
            }
        }
        else
        {
            mcu_printf("Invalid argument\n");
        }
    }
}
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_I2C == 1 )
static void CSL_DeviceI2c(uint8 ucArgc, void * const pArgv[])
{
    const uint8 *str;
    const uint8 ucBufTest[4] = "test";
    sint32 ret;

    mcu_printf("[%s]\n", __func__);

    (void)ucArgc;

    if (pArgv != NULL_PTR)
    {
        str     = (const uint8 *)pArgv[0];

        if((SAL_StrNCmp(str, ucBufTest, 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            I2C_TestMain();
        }
        else
        {
            mcu_printf("\nWrong argument : %s\n", pArgv[0]);
        }
    }
}
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_I2C == 1 )

#if ( SIC_BSP_SUPPORT_TEST_APP_NVIC == 1 )
static void CSL_DeviceNvic(uint8 ucArgc, void * const pArgv[])
{
    const uint8 *str;
    const uint8 ucBufTest[4]    = "test";

    sint32 ret;

    (void)ucArgc;

    str = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str, &pArgv[0], sizeof(uint8 *));

        if (str != NULL)
        {
            if((SAL_StrNCmp(str, ucBufTest, 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                NVIC_Test_SmInt();
            }
            else
            {
                mcu_printf("\nWrong argument : %s\n", str);
            }
        }
        else
        {
            mcu_printf("Invalid argument\n");
        }
    }

    return;
}
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_NVIC == 1 )


static void CSL_DeviceCkc(uint8 ucArgc, void * const pArgv[])
{
    const uint8 *str;
    const uint8 ucBufTest[4]    = "info";
    sint32 ret;

    (void)ucArgc;

    str = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str, &pArgv[0], sizeof(uint8 *));
        if (str != NULL)
        {
            if ((SAL_StrNCmp(str, ucBufTest, 1, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                mcu_printf("Pll0 : %d MHz\n", CLOCK_GetPllRate((sint32) 0)/1000UL/1000UL);
                mcu_printf("Pll1 : %d MHz\n", CLOCK_GetPllRate((sint32) 1)/1000UL/1000UL);

            }
            else
            {
                mcu_printf("\n i (info): print clock info\n");
            }
        }
        else
        {
            mcu_printf("Invalid argument\n");
        }
    }

}

#if ( SIC_BSP_SUPPORT_TEST_APP_GDMA == 1 )
static void CSL_DeviceGdma(uint8 ucArgc, void * const pArgv[])
{
    const uint8 *str;
    const uint8 ucBufTest[4]    = "test";
    sint32 ret;
	uint32 test_id;
	sint32 err;

    (void)ucArgc;

    str = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str, &pArgv[0], sizeof(uint8 *));

        if (str != NULL)
        {
            if ((SAL_StrNCmp(str, ucBufTest, 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                GDMA_SampleForM2M();
            }
             else if ((SAL_StrNCmp(str, (const uint8 *)"verf", 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {

                err = 0;
                test_id = strtoul(pArgv[1], NULL, 10);
                if ((test_id != 0UL) || (err == 0))
                {
                    err = 0;
                    ret = GDMA_IPTest(test_id);
                    if ( ret == 0)
                    {
                        mcu_printf("PASS \n");
                    }
                    else
                    {
                        mcu_printf("FAIL \n");
                    }
                }
                else
                {
                    mcu_printf("%s strtoul fail\n", __func__);
                }
            }
            else
            {
                mcu_printf("\nWrong argument : %s\n", str);
            }
        }
        else
        {
            mcu_printf("Invalid argument\n");
        }
    }
}
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_GDMA == 1 )

#if ( SIC_BSP_SUPPORT_DRIVER_SDM & SIC_BSP_SUPPORT_TEST_APP_SDM )
static void CSL_DoDeviceSdm(const uint8 * str0, void * const pArgv[])
{
    const uint8 ucClear[]             = "clear\0";
    const uint8 ucStatus[]            = "status\0";
    const uint8 ucFailDet[]           = "faildet\0";
    const uint8 ucTelltale[]          = "telltale\0";
    const uint8 ucMuxSrc[]            = "mux\0";
    const uint8 ucRead[]              = "read\0";
    const uint8 ucWrite[]             = "write\0";
    const uint8* ucStr1               = NULL;
    const uint8* ucStr2               = NULL;
    static uint8 ucFailDetStart       = (uint8) 0;
    static uint8 ucTelltaleStart      = (uint8) 0;
    static uint8 ucMuxSrcType         = (uint8) 2; //DDI
    sint32       ret;
    uint32       uiAddress;
    uint32       uiValue;

    ret         = 0UL;
    uiAddress   = 0UL;
    uiValue     = 0UL;

    if ((SAL_StrNCmp(str0, ucStatus, 1, &ret) == SAL_RET_SUCCESS) && (ret == 0))
    {
        mcu_printf(" [SDM TEST] \t Check the error status\n");

        SDM_TEST_CheckErrStatus(1U);
    }
    else if ((SAL_StrNCmp(str0, ucClear, 1, &ret) == SAL_RET_SUCCESS) && (ret == 0))
    {
        mcu_printf(" [SDM TEST] \t Clear the error status\n");

        SDM_TEST_ClearAllErrStatus();
    }
    else if ((SAL_StrNCmp(str0, ucFailDet, 1, &ret) == SAL_RET_SUCCESS) && (ret == 0))
    {
        mcu_printf(" [SDM TEST] \t Error Detection\n");

        ucFailDetStart = (ucFailDetStart + ((uint8) 1)) % ((uint8) 2);

        SDM_TEST_StartFailDet(ucFailDetStart);
    }
    else if ((SAL_StrNCmp(str0, ucTelltale, 1, &ret) == SAL_RET_SUCCESS) && (ret == 0))
    {
        mcu_printf(" [SDM TEST] \t Telltale Operation\n");

        ucTelltaleStart = (ucTelltaleStart + ((uint8) 1)) % ((uint8) 2);

        SDM_TEST_StartTelltale(ucTelltaleStart);
    }
    else if ((SAL_StrNCmp(str0, ucMuxSrc, 1, &ret) == SAL_RET_SUCCESS) && (ret == 0))
    {
        mcu_printf(" [SDM TEST] \t Change Mux\n");

        ucMuxSrcType = (ucMuxSrcType > ((uint8) 2)) ? ((uint8) 2) : ucMuxSrcType;
        ucMuxSrcType = (((uint8) 2) - (ucMuxSrcType - ((uint8) 1))) % ((uint8) 3);

        SDM_TEST_SetMuxSrc(ucMuxSrcType);
    }
    else if ((SAL_StrNCmp(str0, ucRead, 1, &ret) == SAL_RET_SUCCESS) && (ret == 0))
    {
        (void) SAL_MemCopy(&ucStr1, &pArgv[1], sizeof(uint8 *));

        if(ucStr1 != NULL)
        {
            uiAddress   = strtoul((int8 *)ucStr1, NULL, 16);

            SDM_TEST_ReadReg(uiAddress);
        }
    }
    else if ((SAL_StrNCmp(str0, ucWrite, 1, &ret) == SAL_RET_SUCCESS) && (ret == 0))
    {
        (void) SAL_MemCopy(&ucStr1, &pArgv[1], sizeof(uint8 *));
        (void) SAL_MemCopy(&ucStr2, &pArgv[2], sizeof(uint8 *));

        if((ucStr1 != NULL) && (ucStr2 != NULL))
        {
            uiAddress   = strtoul((int8 *)ucStr1, NULL, 16);
            uiValue     = strtoul((int8 *)ucStr2, NULL, 16);

            SDM_TEST_WriteData(uiAddress, uiValue);
        }
    }
    else
    {
        mcu_printf("\n=== SDM COMMAND INFO. ===\n");
        mcu_printf("> sdm read  [Addr]\n");
        mcu_printf("> sdm write [Addr] [value]\n");
        mcu_printf("> sdm clear\n");
        mcu_printf("> sdm faildet\n");
        mcu_printf("> sdm telltale\n");
        mcu_printf("> sdm mux\n\n");
    }
}


static void CSL_DeviceSdm(uint8 ucArgc, void * const pArgv[])
{
    const uint8 ucCmdNum              = ucArgc;
    const uint8 * str0                = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str0, &pArgv[0], sizeof(uint8 *));

        if(str0 != NULL)
        {
            mcu_printf("\nSDM TEST cmd length %d, str0 %s\n", ucCmdNum, str0); //Misra : ucIdx -> 0
            CSL_DoDeviceSdm(str0, pArgv);
        }
        else
        {
            mcu_printf("Invalid argument\n");
        }
    }
}

#endif /* End of (SIC_BSP_SUPPORT_DRIVER_SDM & SIC_BSP_SUPPORT_TEST_APP_SDM) */


static void CSL_DeviceTrvc(uint8 ucArgc, void * const pArgv[])
{
#if (ACFG_APP_TRVC_EN == 1)
    if (pArgv != NULL_PTR)
    {
        TRVC_ConsoleCommandHandler(ucArgc, pArgv);
    }
#else
    (void) ucArgc;
    (void) pArgv;
#endif
}

static void CSL_DevicePmu(uint8 ucArgc, void * const pArgv[])
{
    (void) ucArgc;
    (void) pArgv;
}

#if ( SIC_BSP_SUPPORT_TEST_APP_TOP == 1 )
static void CSL_DeviceTOP(uint8 ucArgc, void * const pArgv[])
{
#ifdef MC_TOP_TEST // if you want to use mc top test fucntion, please check including mc_top.h header file
    int32 isAll =0;
    sint32 ret;

    (void) ucArgc;

    // For the futrue to expand test part
    if ((SAL_StrNCmp(pArgv[0], (const uint8 *)"all", 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))
    {
        isAll = 1;
    }

    if ((isAll ==1) || ((SAL_StrNCmp(pArgv[0], (const uint8 *)"mcudsei", 7, &ret) == SAL_RET_SUCCESS) && (ret == 0))) // mcu default slave error
    {
        mc_top_hbic03_mc_sub_tb_addr_dec_test();
    }
    if ((isAll ==1) || ((SAL_StrNCmp(pArgv[0], (const uint8 *)"peri", 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))) // peri access test
    {
        mc_top_mc_cr5_tb_peri_access_test();
    }
    if ((isAll ==1) || ((SAL_StrNCmp(pArgv[0], (const uint8 *)"apdsei", 6, &ret) == SAL_RET_SUCCESS) && (ret == 0))) // wait for default slave error interrrupt, when ap access invalid address of mcu
    {
        mc_top_mc_cr5_wait_for_AP_default_error();
    }
    if ((isAll ==1) || ((SAL_StrNCmp(pArgv[0], (const uint8 *)"sr", 2, &ret) == SAL_RET_SUCCESS) && (ret == 0))) //secure wrapper isr wait
    {
        mc_top_hbic03_mc_nsaid();
    }
    if ((isAll ==1) || ((SAL_StrNCmp(pArgv[0], (const uint8 *)"bus", 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))) // bus access teset
    {
        mcu_printf("MC_TOP :mc_top_03_mc_tb_sub_bus_test \n");
        ret = mc_top_03_mc_tb_sub_bus_test();
        if ( ret == 0)
                mcu_printf("TEST PASS\n");
        else
                mcu_printf("TEST FAIL\n");
    }
    if ((isAll ==1) || ((SAL_StrNCmp(pArgv[0], (const uint8 *)"iso", 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))) // bus isolation test
    {
        mc_top_hbic03_mc_sub_bus_iso_test();
    }
#if ( SIC_BSP_SUPPORT_DRIVER_FMU )
    if ((isAll ==1) || ((SAL_StrNCmp(pArgv[0], (const uint8 *)"cfg", 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))) // mc cfg
    {
        mcu_printf("MC_TOP :mc_top_mc_cfg_test \n");
        ret = mc_top_mc_cfg_test();
        if ( ret == 0)
                mcu_printf("TEST PASS\n");
        else
                mcu_printf("TEST FAIL\n");
    }
#endif  /* End of SIC_BSP_SUPPORT_DRIVER_FMU */
    if ((isAll ==1) || ((SAL_StrNCmp(pArgv[0], (const uint8 *)"alias", 5, &ret) == SAL_RET_SUCCESS) && (ret == 0))) // address alias test
    {
        mc_top_xbic_tb_addr_alias_test();
    }

    if ((SAL_StrNCmp(pArgv[0], (const uint8 *)"dsei", 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
    {
        uint32 access_addr;
        uint32 data;
        if ((SAL_StrNCmp(pArgv[1], (const uint8 *)"wait", 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
                topDSEIWaitThreadCreate();
        }

        if ((SAL_StrNCmp(pArgv[1], (const uint8 *)"read", 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            errno = 0;
                access_addr = strtoul(pArgv[2], NULL, 16);
            if ((access_addr != 0UL) || (errno == 0))
            {
                errno = 0;
                    data = *(uint32 *)access_addr;
                    mcu_printf("read : 0x%x  value : 0x%x\n", access_addr, data);
            }
            else
            {
                mcu_printf("%s strtoul fail\n", __func__);
            }
        }
    }
#else
    (void) ucArgc;
    (void) pArgv;
    mcu_printf("Test Not Avaliable. Check MC_TOP_TEST feature.\r\n");
#endif
}
#endif  //  ( SIC_BSP_SUPPORT_TEST_APP_TOP == 1 )


#if (SIC_BSP_SYS_PV_SFMC == 1)
static void CSL_DeviceSfmc(uint8 ucArgc, void * const pArgv[])
{

    sint32 ret;

    (void) ucArgc;


    if (pArgv != NULL_PTR)
    {

        if (pArgv[0] != NULL)
        {
            if((SAL_StrNCmp(pArgv[0], (const uint8 *)"aes", 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                if((ucArgc > 1u) && (SAL_StrNCmp(pArgv[1], (const uint8 *)"ecc", 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))
                {
                    SFMCTEST_AESECC_TestStart();
                }
                else
                {
                    SFMCTEST_AES_TestStart();
                }
            }
            else if((SAL_StrNCmp(pArgv[0], (const uint8 *)"ecc", 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                if((ucArgc > 1u) && (SAL_StrNCmp(pArgv[1], (const uint8 *)"aes", 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))
                {
                    SFMCTEST_AESECC_TestStart();
                }
                else
                {
                    SFMCTEST_ECC_TestStart();
                }
            }
            else
            {
                mcu_printf("\nWrong argument : %s\n", pArgv[0]);
            }
        }
        else
        {
            mcu_printf("\nInvalid argument\n");
        }
    }

}
#endif  // ( SIC_BSP_SYS_PV_SFMC == 1 )


#if (SIC_BSP_SYS_PV_SUBSYS == 1)
static void CSL_DeviceSubsys(uint8 ucArgc, void * const pArgv[])
{
    const uint8 *str;
    const uint8 ucBufTest[4]    = "test";
    const uint8 ucBufTest1[4]   = "umwd";
    const uint8 ucBufTest2[2]   = "pw";
    sint32 ret;

    (void) ucArgc;

    str = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str, &pArgv[0], sizeof(uint8 *));
        if (str != NULL)
        {
            if((SAL_StrNCmp(str, ucBufTest, 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                SUBSYS_busClkResetTest();
            }
            else if((SAL_StrNCmp(str, ucBufTest1, 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                SUBSYS_UMWDTest();
            }
            else if((SAL_StrNCmp(str, ucBufTest2, 2, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                SUBSYS_busClkPwTest();
            }
            else
            {
                mcu_printf("\nWrong argument : %s\n", str);
            }
        }
        else
        {
            mcu_printf("\nInvalid argument\n");
        }
    }

    return;
}

#endif //  (SIC_BSP_SYS_PV_SUBSYS == 1)


#if ( SIC_BSP_SUPPORT_TEST_APP_SWRAP == 1 )
static void CSL_DeviceSwrp(uint8 ucArgc, void * const pArgv[])
{
    const int8 *ucStr1;
    const int8 *ucStr2;
    const int8 *pucStr;
    uint32      uiOn;

    (void)ucArgc;

    ucStr1 = NULL;
    ucStr2 = NULL;
    pucStr = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&pucStr, &pArgv[0], sizeof(uint8 *));
        (void) SAL_MemCopy(&ucStr1, &pArgv[1], sizeof(int8 *));
        (void) SAL_MemCopy(&ucStr2, &pArgv[2], sizeof(int8 *));

        if ((pucStr != NULL) && (ucStr1 != NULL) && (ucStr2 != NULL))
        {
            uiOn   = strtoul(pucStr, NULL_PTR, 10);
            if (uiOn != 0UL)
            {
#if ( SIC_BSP_SUPPORT_DRIVER_FMU )
				Swrp_Test(0);
#endif
            }
            else
            {
                mcu_printf("%s strtoul fail uiOn[%u]\n", __func__, uiOn);
            }
        }
        else
        {
            mcu_printf("\nInvalid argument\n");
        }
    }
}
#endif  //  ( SIC_BSP_SUPPORT_TEST_APP_SWRAP == 1 )

#if ( SIC_BSP_SUPPORT_APP_ETH == 1 )
static void CSL_DeviceGmac(uint8 ucArgc, void * const pArgv[])
{
    const uint8 *str;
    sint32 ret;
    const uint8 ucMacTest[5] = "maclb";
    const uint8 ucPhyTest[5] = "phylb";
    const uint8 ucInit[4] = "init";
    const uint8 ucSend[4] = "send";
    const uint8 ucIPInit[6] = "ipinit";
    const uint8 ucPread_0[6] = "pread0";
    const uint8 ucPwrite_0[7] = "pwrite0";
    const uint8 ucPread_1[6] = "pread1";
    const uint8 ucPwrite_1[7] = "pwrite1";

    (void)ucArgc;

    if (pArgv != NULL_PTR)
    {
        str     = (const uint8 *)pArgv[0];

        if((SAL_StrNCmp(str, ucMacTest, 5, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            uint32 index = CSL_StringToHex(pArgv[1]);
            ETH_TestInit((uint32)PHY_OpMode_Loopback_MAC, index);
        }
        else if((SAL_StrNCmp(str, ucPhyTest, 5, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            uint32 index = CSL_StringToHex(pArgv[1]);
            ETH_TestInit((uint32)PHY_OpMode_Loopback_PHY, index);
        }
        else if((SAL_StrNCmp(str, ucInit, 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            uint32 index = CSL_StringToHex(pArgv[1]);
            ETH_TestInit((uint32)PHY_OpMode_Normal, index);
        }
        else if((SAL_StrNCmp(str, ucSend, 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            uint32 index = CSL_StringToHex(pArgv[2]);
            ETH_TestSend(index ,strtoul(pArgv[1], NULL, 10));
        }
        else if((SAL_StrNCmp(str, ucIPInit, 6, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            ETH_TestIPInit();
        }
        else if((SAL_StrNCmp(str, ucPread_1, 6, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            if((pArgv[1] != NULL) && (pArgv[2] != NULL))
            {
                uint32 dev = CSL_StringToHex(pArgv[1]);
                uint32 addr = CSL_StringToHex(pArgv[2]);
                uint16 reg = 0;

                PHY_88Q2220_Read(dev, addr, &reg);

                mcu_printf("PHY Read Usage : gmac pread [reg dev] [addr] \n");
                mcu_printf("PHY Read (dev %d addr 0x%x) : 0x%x\n", dev, addr, reg);
            }
        }
        else if((SAL_StrNCmp(str, ucPwrite_1, 7, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            if((pArgv[1] != NULL) && (pArgv[2] != NULL) && (pArgv[3] != NULL))
            {
                uint32 dev = CSL_StringToHex(pArgv[1]);
                uint32 addr = CSL_StringToHex(pArgv[2]);
                uint16 reg = CSL_StringToHex(pArgv[3]);
                uint16 reg1 = 0;

                mcu_printf("PHY Write Usage : gmac pwrite [reg dev] [add] [value]\n");
                PHY_88Q2220_Write(dev, addr, reg);
                mcu_printf("PHY Write (dev 0x%x , addr 0x%x) : data 0x%x \n", dev, addr, reg);
                PHY_88Q2220_Read(dev, addr, &reg1);
                mcu_printf("PHY Read  (dev 0x%x , addr 0x%x) : data 0x%x \n", dev, addr, reg1);
            }
        }
        else if((SAL_StrNCmp(str, ucPread_0, 6, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            if((pArgv[1] != NULL) && (pArgv[2] != NULL))
            {
                uint32 dev = CSL_StringToHex(pArgv[1]);
                uint32 addr = CSL_StringToHex(pArgv[2]);
                uint16 reg = 0;

                PHY_88E1512_Read(dev, addr, &reg);

                mcu_printf("PHY Read Usage : gmac pread [reg page] [addr] \n");
                mcu_printf("PHY Read (dev %d addr 0x%x) : 0x%x\n", dev, addr, reg);
            }
        }
        else if((SAL_StrNCmp(str, ucPwrite_0, 7, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            if((pArgv[1] != NULL) && (pArgv[2] != NULL) && (pArgv[3] != NULL))
            {
                uint32 dev = CSL_StringToHex(pArgv[1]);
                uint32 addr = CSL_StringToHex(pArgv[2]);
                uint16 reg = CSL_StringToHex(pArgv[3]);
                uint16 reg1 = 0;

                mcu_printf("PHY Write Usage : gmac pwrite [reg page] [reg addr] [value]\n");
                PHY_88E1512_Write(dev, addr, reg);
                mcu_printf("PHY Write (dev 0x%x , addr 0x%x) : data 0x%x \n", dev, addr, reg);
                PHY_88E1512_Read(dev, addr, &reg1);
                mcu_printf("PHY Read  (dev 0x%x , addr 0x%x) : data 0x%x \n", dev, addr, reg1);
            }
        }
        else
        {
            mcu_printf("\nWrong argument : %s\n", pArgv[0]);
        }
    }

}
#endif  // ( SIC_BSP_SUPPORT_APP_ETH == 1 )

#if ( SIC_BSP_SUPPORT_TEST_APP_DSE )
static void CSL_DeviceDse(uint8 ucArgc, void * const pArgv[])
{
    const uint8 *str;
    sint32 ret;

    (void) ucArgc;

    str = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str, &pArgv[0], sizeof(uint8 *));

        if (str != NULL)
        {
            if((SAL_StrNCmp(str, (uint8 *)"enable", 6, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                DSE_TEST_Enable();
            }
            else if((SAL_StrNCmp(str, (uint8 *)"disable", 7, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                DSE_TEST_Disable();
            }
            else if((SAL_StrNCmp(str, (uint8 *)"test", 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                DSE_TEST_AccessDefault();
            }
#if ( SIC_BSP_SUPPORT_DRIVER_FMU )
            else if((SAL_StrNCmp(str, (uint8 *)"fault", 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                DSE_TEST_Fault();
            }
#endif
            else
            {
                mcu_printf("\nWrong argument : %s\n", str);
            }
        }
        else
        {
            mcu_printf("\nInvalid argument\n");
        }
    }

    return;
}
#endif /* End of ( SIC_BSP_SUPPORT_TEST_APP_DSE ) */

#if ( SIC_BSP_SUPPORT_DRIVER_SSM & SIC_BSP_SUPPORT_TEST_APP_SSM )
static void CSL_DeviceSsm(uint8 ucArgc, void * const pArgv[])
{
    sint32          ret;
    const uint8 *   strCategory     = NULL;
    const uint8 *   strAction       = NULL;
    const int8 *    str2            = NULL;
    int32           uiMode          = 0;
#ifdef CRD_TEST_ENABLE
    uint32          isAll           = 0;
#endif

    (void)ucArgc;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&strCategory, &pArgv[0], sizeof(uint8 *));
        (void) SAL_MemCopy(&strAction, &pArgv[1], sizeof(uint8 *));
        (void) SAL_MemCopy(&str2, &pArgv[2], sizeof(int8 *));

        if ((strCategory != NULL) && (strAction != NULL))
        {
            if ((SAL_StrNCmp(strCategory, (uint8 *)"iso", 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                uiMode      = strtol((int8 *)strAction, NULL_PTR, 10);

                ISO_TEST_Start(uiMode);
            }
#ifdef CRD_TEST_ENABLE
            else if ((SAL_StrNCmp(strCategory, (uint8 *)"crd", 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                uiMode      = strtol(str2, NULL_PTR, 10);

                if ((SAL_StrNCmp(strAction, (uint8 *)"all", 3, &ret) == SAL_RET_SUCCESS) && (ret == 0))
                {
                    isAll = 1;
                }
                // uiMode(Severity Level : 0 : Low, 1 : Mid, 2: High
                if ((isAll) || ((SAL_StrNCmp(strAction, (uint8 *)"subsys", 6, &ret) == SAL_RET_SUCCESS) && (ret == 0)))
                {
                    Crd_Test(0, uiMode);
                }
                if ((isAll) || ((SAL_StrNCmp(strAction, (uint8 *)"m0p", 3, &ret) == SAL_RET_SUCCESS) && (ret == 0)))
                {
                    Crd_Test(1, uiMode);
                }
                if ((isAll) || ((SAL_StrNCmp(strAction, (uint8 *)"mid", 3, &ret) == SAL_RET_SUCCESS) && (ret == 0)))
                {
                    Crd_Test(2, uiMode);
                }
                if ((isAll) || ((SAL_StrNCmp(strAction, (uint8 *)"sm", 2, &ret) == SAL_RET_SUCCESS) && (ret == 0)))
                {
                    Crd_Test(3, uiMode);
                }
            }
#endif
            else if ((SAL_StrNCmp(strCategory, (uint8 *)"sram", 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                mcu_printf("\n[SRAM] SRAM ECC test is not supported\n\n");
            }
            else
            {
                mcu_printf("\t[SSM TEST] Wrong argument : %s\n", pArgv[0]);
                mcu_printf("\t SSM command information\n");
                mcu_printf("\t > ssm iso [mode]\n");
                mcu_printf("\t > ssm crd [action] [mode]\n");
                mcu_printf("\t > ssm sram\n\n");
            }
        }
        else
        {
            mcu_printf("[SSM TEST] Invalid argument\n");
        }
    }
}
#endif /* End of SIC_BSP_SUPPORT_DRIVER_SSM & SIC_BSP_SUPPORT_TEST_APP_SSM */


#if ( SIC_BSP_SUPPORT_DRIVER_ADC == 1 )
static void CSL_DeviceAdc(uint8 ucArgc, void * const pArgv[])
{
    const uint8 *str;
    const uint8 ucBufTest[4] = "test";
    SALRetCode_t ret;
    mcu_printf("[%s]\n", __func__);

    (void)ucArgc;

    if (pArgv != NULL_PTR)
    {
        str     = (const uint8 *)pArgv[0];

        if((SAL_StrNCmp(str, ucBufTest, 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
        {
            ret = ADC_Enable();
            if(ret == 0)
            {
                ADC_GetAllData();
            }
        }
        else
        {
            mcu_printf("\nWrong argument : %s\n", pArgv[0]);
        }
    }

}
#endif  // ( SIC_BSP_SUPPORT_TEST_APP_ADC == 1 )

#if ( SIC_BSP_SUPPORT_CAN_DEMO == 1 )
static void CSL_DeviceCan(uint8 ucArgc, void * const pArgv[])
{
    CAN_DemoTest(ucArgc, pArgv);
}
#endif  // ( MCU_BSP_SUPPORT_CAN_DEMO == 1 )

static void CSL_DeviceMidf(uint8 ucArgc, void * const pArgv[])
{
#ifdef USE_MIDF_TEST
    const uint8 *str0;
    sint32 ret;
    uint32 uiMemoryBase = 0xC1000000UL; //SRAM1
    uint32 uiSize                       = 0x1000UL; // 4KB
    uint32 uiID                 = MIDF_ID_CAN0;
    uint32 uiType                       =(MIDF_TYPE_READ|MIDF_TYPE_WRITE);

    (void) ucArgc;

    str0 = NULL;
    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str0, &pArgv[0], sizeof(uint8 *));

        if (str0 != NULL)
        {
            if((SAL_StrNCmp(str0, (const uint8 *)"init", 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                MIDF_FilterInitialize();
            }
            else if((SAL_StrNCmp(str0, (const uint8 *)"reg", 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                (void) MIDF_RegisterFilterRegion(uiMemoryBase, uiSize, uiID, uiType);
            }
            else if ((SAL_StrNCmp(str0, (const uint8 *)"del", 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
                (void) MIDF_UnregisterFilterRegion(uiMemoryBase, uiSize, uiID, uiType);
            }
                else if ((SAL_StrNCmp(str0, (const uint8 *)"verf", 4, &ret) == SAL_RET_SUCCESS) && (ret == 0))
            {
#ifdef MIDF_IP_TEST
                uint32 test_id;
                int32 ret;
                const int8 *str1 = NULL;

                (void) SAL_MemCopy(&str1, &pArgv[1], sizeof(int8 *));

                if (str1 != NULL)
                {
                    errno = 0;
                    test_id = (uint32)strtoul(pArgv[1], NULL, 10);

                    if ((test_id != 0UL) || (errno == 0))
                    {
                        errno = 0;
                                ret = MIDF_IPTest(test_id);
                                if (ret == 0)
                                {
                                        mcu_printf("PASS \n");
                                }
                                else
                                {
                                        mcu_printf("FAIL \n");
                                }
                    }
                    else
                    {
                        mcu_printf("%s strtol fai errno[%d]\n", __func__, errno);
                    }
                }
                else
                {
                    mcu_printf("Invalid argument\n");
                }
#else
                mcu_printf("Need to check MIDF_IP_TEST feature  \n");
#endif
            }
            else
            {
                mcu_printf("\nWrong argument : %s\n", str0);
            }
        }
        else
        {
            mcu_printf("Invalid argument\n");
        }
    }
#endif
    return;
}

static void CSL_EnableLog(uint8 ucArgc, void * const pArgv[])
{
    if (pArgv != NULL_PTR)
    {
        if(DBG_VALID_ARGCOUNT(ucArgc))
        {
            ConsoleLogFunc[DBG_CNT_TO_IDX(ucArgc)].clFunc(pArgv);
        }
        else
        {
            CSL_UsageLogCmd(DBG_ENABLE, DBG_DISABLE);
        }
    }
}

static sint32 CSL_DoLogCmdType01(const uint8 *str)
{
    sint32 ret;

    ret = 0L;

    if((SAL_StrNCmp(str,  (const uint8 *)"help", DBG_HELP_LEN, &ret) == SAL_RET_SUCCESS) && DBG_EQUALS(ret, DBG_ERR_NONE))
    {
        CSL_UsageLogCmd(DBG_ENABLE, DBG_ENABLE);
    }
    else if((SAL_StrNCmp(str, (const uint8 *)"on", DBG_ON_LEN, &ret) == SAL_RET_SUCCESS) && DBG_EQUALS(ret, DBG_ERR_NONE))
    {
        gDebugOption = DBG_ENABLE_ALL;
    }
    else if((SAL_StrNCmp(str, (const uint8 *)"off", DBG_OFF_LEN, &ret) == SAL_RET_SUCCESS) && DBG_EQUALS(ret, DBG_ERR_NONE))
    {
        gDebugOption = DBG_DISABLE_ALL;
    }
    else if((SAL_StrNCmp(str, (const uint8 *)"debug", DBG_LEVEL_LEN, &ret) == SAL_RET_SUCCESS) && DBG_EQUALS(ret, DBG_ERR_NONE))
    {
        gDebugOption = (gDebugOption & ~DBG_LEVEL_POSITION) | DBG_LEVEL_DEBUG;
    }
    else if((SAL_StrNCmp(str, (const uint8 *)"error", DBG_LEVEL_LEN, &ret) == SAL_RET_SUCCESS) && DBG_EQUALS(ret, DBG_ERR_NONE))
    {
        gDebugOption = (gDebugOption & ~DBG_LEVEL_POSITION) | DBG_LEVEL_ERROR;
    }
    else if((SAL_StrNCmp(str, (const uint8 *)"info", DBG_INFO_LEN, &ret) == SAL_RET_SUCCESS) && DBG_EQUALS(ret, DBG_ERR_NONE))
    {
        CSL_ShowLogInfo();
    }
    else
    {
        CSL_UsageLogCmd(DBG_ENABLE, DBG_DISABLE);
    }

    return ret;
}

static void CSL_LogCmdType01(void * const pArgv[])
{
    const uint8 *str;

    str = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str, &pArgv[0], sizeof(uint8 *));

        if (str != NULL)
        {
            (void) CSL_DoLogCmdType01(str);
        }
        else
        {
            mcu_printf("Invalid argument\n");
        }
    }
}

static sint32 CSL_DoLogCmdType02(const int8 *str0, const uint8 *str1)
{
    sint32 ret;
    uint32  tagIdx;

    ret = 0L;
    errno = 0;
    tagIdx = strtoul(str0, NULL_PTR, 10);

    if(((tagIdx != 0UL) || (errno == 0)) && DBG_VALID_TAGIDX(tagIdx))
    {
        errno = 0;
        if((SAL_StrNCmp(str1, (const uint8 *)"on", DBG_ON_LEN, &ret) == SAL_RET_SUCCESS) && DBG_EQUALS(ret, DBG_ERR_NONE))
        {
            gDebugOption = gDebugOption | (DBG_TAG_BIT(tagIdx));
        }
        else if((SAL_StrNCmp(str1, (const uint8 *)"off", DBG_OFF_LEN, &ret) == SAL_RET_SUCCESS) && DBG_EQUALS(ret, DBG_ERR_NONE))
        {
            gDebugOption = gDebugOption & ~(DBG_TAG_BIT(tagIdx));
        }
        else
        {
            errno = 0;
            CSL_UsageLogCmd(DBG_ENABLE, DBG_DISABLE);
        }
    }
    else
    {
        errno = 0;
        CSL_UsageLogCmd(DBG_DISABLE, DBG_ENABLE);
    }

    return ret;
}

static void CSL_LogCmdType02(void * const pArgv[])
{
    const int8 * str0;
    const uint8 * str1;

    str0 = NULL;
    str1 = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str0, &pArgv[0], sizeof(int8 *));
        (void) SAL_MemCopy(&str1, &pArgv[1], sizeof(uint8 *));

        if ((str0 != NULL) && (str1 != NULL))
        {
            (void) CSL_DoLogCmdType02(str0, str1);
        }
        else
        {
            mcu_printf("Invalid argument\n");
        }
    }
}

static sint32 CSL_DoLogCmdType03(const uint8 *str2)
{
    sint32 ret;

    ret = 0L;

    if(DBG_EQUALS(SAL_StrNCmp(str2, (const uint8 *)"debug", DBG_LEVEL_LEN, &ret), SAL_RET_SUCCESS) && DBG_EQUALS(ret, DBG_ERR_NONE))
    {
        gDebugOption = (gDebugOption & ~(DBG_LEVEL_POSITION)) | DBG_LEVEL_DEBUG;
    }
    else if(DBG_EQUALS(SAL_StrNCmp(str2, (const uint8 *)"error", DBG_LEVEL_LEN, &ret), SAL_RET_SUCCESS) && DBG_EQUALS(ret, DBG_ERR_NONE))
    {
        gDebugOption = (gDebugOption & ~(DBG_LEVEL_POSITION)) | DBG_LEVEL_ERROR;
    }
    else
    {
        CSL_UsageLogCmd(DBG_ENABLE, DBG_DISABLE);
    }

    return ret;
}

static void CSL_LogCmdType03(void * const pArgv[])
{
    const int8 * str0;
    const uint8 * str1;
    const uint8 * str2;
    uint32  tagIdx;
    sint32 ret;

    str0 = NULL;
    str1 = NULL;
    str2 = NULL;

    if (pArgv != NULL_PTR)
    {
        (void) SAL_MemCopy(&str0, &pArgv[0], sizeof(int8 *));
        (void) SAL_MemCopy(&str1, &pArgv[1], sizeof(uint8 *));
        (void) SAL_MemCopy(&str2, &pArgv[2], sizeof(uint8 *));

        if ((str0 != NULL) && (str1 != NULL) && (str2 != NULL))
        {
            errno = 0;
            tagIdx = strtoul(str0, NULL_PTR, 10);
            if(((tagIdx != 0UL) || (errno == 0)) && DBG_VALID_TAGIDX(tagIdx))
            {
                errno = 0;
                if(DBG_EQUALS(SAL_StrNCmp(str1, (const uint8 *)"on", DBG_ON_LEN, &ret), SAL_RET_SUCCESS) && DBG_EQUALS(ret, DBG_ERR_NONE))
                {
                    gDebugOption = gDebugOption | (DBG_TAG_BIT(tagIdx));
                    (void) CSL_DoLogCmdType03(str2);
                }
                else if(DBG_EQUALS(SAL_StrNCmp(str1, (const uint8 *)"off", DBG_OFF_LEN, &ret), SAL_RET_SUCCESS) && DBG_EQUALS(ret, DBG_ERR_NONE))
                {
                    gDebugOption = gDebugOption & ~(DBG_TAG_BIT(tagIdx));
                    (void) CSL_DoLogCmdType03(str2);
                }
                else
                {
                    errno = 0;
                    CSL_UsageLogCmd(DBG_ENABLE, DBG_DISABLE);
                }
            }
            else
            {
                errno = 0;
                CSL_UsageLogCmd(DBG_DISABLE, DBG_ENABLE);
            }
        }
        else
        {
            mcu_printf("Invalid argument\n");
        }
    }
}

static void CSL_UsageLogCmd(uint8 ucInfo, uint8 ucHelp)
{
    uint32 idx;

    if(DBG_EQUALS(ucInfo, DBG_ENABLE))
    {
        mcu_printf("=== USAGE INFO ===\n");
        mcu_printf("log [Index] on/off debug/error\n");
        mcu_printf("log [Index] on/off\n");
        mcu_printf("log on/off\n");
        mcu_printf("log debug/error\n");
        mcu_printf("log info\n");
        mcu_printf("log help\n");
    }

    if(DBG_EQUALS(ucHelp, DBG_ENABLE))
    {
        mcu_printf("\n=== INDEX INFO ===\n");

        for(idx = 0 ; idx < DBG_MAX_TAGS ; idx++)
        {
            mcu_printf("[%-5s] : [%2d]\n", dbgTags[idx].dlTag, idx);
        }
    }
}

static void CSL_ShowLogInfo(void)
{
    uint32 idx;
    uint32 check = 0;
    uint32 cnt   = 0;

    mcu_printf("Enabled :");

    for(idx = 0 ; idx < (DBG_MAX_TAGS - 2UL) ; idx++)
    {
        check = (gDebugOption >> idx) & ~DBG_LEVEL_POSITION;

        if((check & DBG_CHECK_BIT) == DBG_CHECK_BIT)
        {
            mcu_printf(" %s(%2d) ", dbgTags[idx].dlTag, idx);
            cnt++;
        }
    }

    if(cnt == DBG_ZERO)
    {
        mcu_printf(" None ");
    }

    mcu_printf("\nLevel   :");
    check = (gDebugOption & DBG_LEVEL_POSITION);

    if(check == 0UL)
    {
        mcu_printf(" Error\n");
    }
    else
    {
        mcu_printf(" Debug\n");
    }
}


/*****************************************************************************/
/*                                 FUNCTIONS                                 */
/*****************************************************************************/

static void CSL_StrCopyTb(uint8 *uMsg)
{
    (void) SAL_MemSet(uMsg, 0x00, 5);
    (void) SAL_StrCopy(uMsg, (const uint8 *) "\b \b\0");
}

static void ConsoleTask(void *pArg)
{
    uint8   cmdBuffer[CSL_CMD_BUFF_SIZE + CSL_CMD_PROMPT_SIZE];
    uint32  cmdLength   = 0;
    uint8   cmdStatus   = (uint8)CSL_NOINPUT;
    sint8   getc_err;
    sint32  ret         =0;
    uint8   c           =0;
    uint32  tmp         =0;
    uint32  idx;
    uint8   uMsg[5] = {0, };

    (void)pArg;

    for(;;)
    {
        ret = UART_GetChar(UART_DEBUG_CH, 0, (sint8 *)&getc_err);
//		ret = uart_getc(UART_DEBUG_CH, 0);

        if(ret > 0)
        {
            (void) SAL_MemCopy(&tmp, &ret, sizeof(uint32));
            c   = (uint8)(tmp & 0xFFUL);

            switch(c)
            {
                case TCC_ARRIAGE_RETURN:
                case TCC_LINE_FEED:
                {
                    cmdStatus = (uint8)CSL_EXECUTE;
                    break;
                }

                case TCC_BACK_SPACE:
                {
                    if (cmdLength > 0UL)
                    {
                        cmdStatus = (uint8)CSL_INPUTING;
                        cmdLength--;
                        CSL_StrCopyTb(uMsg);
                        //(void) SAL_MemSet(uMsg, 0x00, 5);
                        //(void) SAL_StrCopy(uMsg, (const uint8 *) "\b \b\0");
                        (void) UART_Write(UART_DEBUG_CH, (const uint8 *) uMsg, 3UL);
                    }

                    break;
                }

                case TCC_NAK_KEY:
                {

                    /* Remove current command in command buffer */
                    for(idx = 0UL; idx < cmdLength; idx ++)
                    {
                        CSL_StrCopyTb(uMsg);
                        (void) UART_Write(UART_DEBUG_CH, (const uint8 *) uMsg, 3UL);
                    }

                    cmdStatus   = (uint8)CSL_INPUTING;
                    cmdLength   = 0UL;
                    break;
                }

                case TCC_ESC_KEY:
                {
                    break;
                }
                default:
                {
                    if(cmdLength < (CSL_CMD_BUFF_SIZE-1UL))
                    {
                        cmdStatus               = (uint8)CSL_INPUTING;
                        cmdBuffer[cmdLength]    = c;
                        cmdLength++;
                        (void) UART_Write(UART_DEBUG_CH, &c, 1UL);
                    }

                    break;
                }
            }

            if(cmdStatus == (uint8)CSL_EXECUTE)
            {
                cmdStatus = (uint8)CSL_NOINPUT;
                (void) SAL_MemSet(uMsg, 0x00, 5);
                (void) SAL_StrCopy(uMsg, (const uint8 *) TCC_CRLF);
                (void) UART_Write(UART_DEBUG_CH, (const uint8 *) uMsg, 2UL);
                CSL_ExecuteCommand(cmdBuffer, cmdLength);
                (void) UART_Write(UART_DEBUG_CH, (const uint8 *) uMsg, 2UL);
                (void) SAL_MemSet(uMsg, 0x00, 5);
                (void) SAL_StrCopy(uMsg, (const uint8 *) "> \0");
                (void) UART_Write(UART_DEBUG_CH, (const uint8 *) uMsg, 2UL);  //Prompt

                if(cmdLength != 0UL)
                {
                    cmdLength   = 0UL;
                }
            }
        }
        else
        {
            (void)SAL_TaskSleep(5);
            //mcu_printf("ERROR NO ACK\n");
        }
    }
}

static uint32 CSL_GetOneWordLength(const uint8 * puiCmdBuf, uint32 uiCmdLength)
{
    uint32  idx;
    uint8   key;

    for(idx = 0UL ; idx < uiCmdLength ; idx++)
    {
        key = puiCmdBuf[idx];

        if(key == TCC_SPACE_BAR)
        {
            break;
        }
    }

    return idx;
}

static uint32 CSL_GetCommandLength(const uint8 * puiCmdBuf)
{
    uint32  idx = 0UL;
    uint8   key;

    if (puiCmdBuf != NULL_PTR)
    {
        for( ; idx < CSL_CMD_BUFF_SIZE ; idx++)
        {
            key = puiCmdBuf[idx];

            if(key == TCC_NUL_KEY)
            {
                break;
            }
        }
    }

    return idx;
}


static void CSL_ExecuteCommand(uint8 * puiCmdBuf, uint32 uiCmdLength)
{
    uint32                      idx;
    uint32                      totalCnt        = 0;
    uint32                      realCmdLength   = 0;
    uint32                      paramLength     = 0;
    uint32                      clNameLength;   // name length in command list
    uint8                       ucArgc;
    void *                      pArgv[CSL_ARGUMENT_MAX];
    uint32                      curPosition     =0;
    sint32                      ret;
    const CLSConsoleCmdList_t * pConsoleCommand;

    if (puiCmdBuf != NULL_PTR)
    {
        realCmdLength   = CSL_GetOneWordLength(puiCmdBuf, uiCmdLength);
        curPosition     = realCmdLength;

        if(uiCmdLength > 0UL)
        {
            for(ucArgc = (uint8) 0; ucArgc < (uint8) CSL_ARGUMENT_MAX ; ucArgc++)
            {
                if(uiCmdLength <= curPosition)
                {
                    break;
                }
                else
                {
                    curPosition += CSL_SPACE_1COUNT;
                    paramLength = CSL_GetOneWordLength(&puiCmdBuf[curPosition], uiCmdLength - curPosition);

                    if(paramLength != 0UL)
                    {
                        pArgv[ucArgc]   = (void *) &puiCmdBuf[curPosition];
                        puiCmdBuf[curPosition+paramLength] = 0; // Exchange SPACE to NULL
                        curPosition     += paramLength;
                    }
                }
            }

            totalCnt = sizeof(ConsoleCmdList) / sizeof(ConsoleCmdList[0]);

            for(idx = 0UL ; idx < totalCnt ; idx++)
            {
                pConsoleCommand = pGetConsoleCmdList(idx);

                if(pConsoleCommand->clEnable == CMD_ENABLE)
                {
                    clNameLength    = CSL_GetCommandLength(pConsoleCommand->clName);

                    if(clNameLength == realCmdLength)
                    {
                        if((SAL_StrNCmp(pConsoleCommand->clName, puiCmdBuf, realCmdLength, &ret) == SAL_RET_SUCCESS) && (ret == 0))
                        {
                            pConsoleCommand->clFunc(ucArgc, pArgv);
                        }
                    }
                }
            }
        }
    }
}

void CreateConsoleTask(void)
{
    static uint32   ConsoleTaskID = 0UL;
    static uint32   ConsoleTaskStk[CSL_TASK_STK_SIZE];

    (void)SAL_TaskCreate
    (
        &ConsoleTaskID,
        (const uint8 *)"Console Task",
        (SALTaskFunc)&ConsoleTask,
        &ConsoleTaskStk[0],
        CSL_TASK_STK_SIZE,
        SAL_PRIO_LOWEST,
        NULL
    );
}

