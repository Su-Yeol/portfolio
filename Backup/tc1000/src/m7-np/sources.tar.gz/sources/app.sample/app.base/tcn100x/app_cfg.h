/*
***************************************************************************************************
*
*   FileName : app_cfg.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef APP_CFG_HEADER
#define APP_CFG_HEADER

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/
/* TASK STACK SIZES : Size of the task stacks (# of WARD entries)                   */
#define ACFG_TASK_USER_STK_SIZE         (128U)

/* normal measn that task has no deep fucnction call or large local variable/array  */
#define ACFG_TASK_NORMAL_STK_SIZE       (128U)

/* medium measn that task has some fucnction call or small local variables/arrays   */
#define ACFG_TASK_MEDIUM_STK_SIZE       (386U)

/* Sample Application                                                               */

/* System monitoring applicaiton                                                    */
#define ACFG_APP_SYSTEM_MONITORING_EN   (0)

/* Trust RVC application                                                            */
#define ACFG_APP_TRVC_EN                (0)

/* Drvier Application                                                               */
/* Inter processor Communication service                                            */

#define ACFG_DRV_HSMMANAGER_EN          (1)

/* LPA LOG application															*/
#define LPA_LOG_EN						(1)

/* TSNC & CANC application															*/
#if (SIC_BSP_SUPPORT_TEST_APP_LPA_MA == 1)
#define TSNC_EN							(1)
#define CANC_EN							(1)
#define IPC_EN                          (1)
#else
#define TSNC_EN							(0)
#define CANC_EN							(0)
#define IPC_EN                          (0)
#endif

#if (TSNC_EN == 1)
#if (SIC_BSP_SUPPORT_TEST_APP_TPA != 1) || (SIC_BSP_SUPPORT_TEST_APP_LPA_MA != 1)
#error To use TSNC, both TPA and LPA must be enabled.
#endif
#endif

#if (SIC_BSP_SUPPORT_TEST_APP_LPA_M == 1) || (SIC_BSP_SUPPORT_TEST_APP_LPA_MA == 1)
#if (SIC_BSP_SUPPORT_TEST_APP_LPA_S == 1) || (SIC_BSP_SUPPORT_TEST_APP_LPA_SA == 1)
#error Neither 'Master Framework' nor 'Slave Framework' can be enabled
#endif
#endif

/* IPC App sample                                                    */
#define VNG_APP_IPC_Sample_EN  		 (0)

/* IPI App sample                                                    */
#define VNG_APP_IPI_Sample_EN  		 (0)

#endif  // _APP_CFG_HEADER_

