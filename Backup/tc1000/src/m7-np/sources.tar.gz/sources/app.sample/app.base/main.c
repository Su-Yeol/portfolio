/*
***************************************************************************************************
*
*   FileName : main.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include <main.h>

#include <sal_api.h>
#include <app_cfg.h>
#include <debug.h>
#include <bsp.h>

#if (ACFG_APP_SYSTEM_MONITORING_EN ==1)
#   include <system_monitoring.h>
#endif
#if (SIC_BSP_SUPPORT_CONSOLE == 1)
#   include <console.h>
#endif
#if ( SIC_BSP_SUPPORT_CAN_DEMO == 1 )
    #include "can_demo.h"
#endif
#if (SIC_BSP_SUPPORT_DRIVER_SDM)
#   include <sdm.h>
#endif
#if (SIC_BSP_SUPPORT_DRIVER_IPC)
#include "ipc_parser.h"
#endif
#if (ACFG_APP_TRVC_EN == 1)
#   include <trvc.h>
#endif
#if (SIC_BSP_SYS_PV_SFMC == 1)
#include "sfmc_test.h"
#endif

#if (SIC_BSP_SUPPORT_APP_AP_RESET == 1)
#   include "ap_rst.h"
#endif

#if (SIC_BSP_SUPPORT_TEST_APP_LPA_M == 1)
#include "mst_framework.h"
#endif

#if (SIC_BSP_SUPPORT_TEST_APP_LPA_MA == 1)
#include "demo_rx.h"
#include "demo_tx.h"
#if (LPA_LOG_EN == 1)
#include "demo_lpa_log.h"
#endif
#if (TSNC_EN == 1)
#include "demo_tsnc.h"
#endif
#if (CANC_EN == 1)
#include "demo_can_cnvt.h"
#endif
#if (IPC_EN == 1)
#include "rt_tbl.h"
#endif
#endif

#if (SIC_BSP_SUPPORT_TEST_APP_LPA_S == 1)
#include "slv_framework.h"
#endif
#if (SIC_BSP_SUPPORT_TEST_APP_TPA == 1)
#include "app_tpa_rx.h"
#include "app_tpa_tx.h"
#endif

#if (ACFG_APP_IPC_Sample_EN == 1)
   #include "ipc_sample.h"
#endif

// 241202 sy.kim
#include "katech_can_app.h"

/*
***************************************************************************************************
*                                         GLOBAL VARIABLES
***************************************************************************************************
*/
uint32                                  gALiveMsgOnOff;
static uint32                                  gALiveCount;

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/

static void Main_StartTask
(
    void *                              pArg
);

static void AppTaskCreate
(
    void
);

static void DisplayAliveLog
(
    void
);


/*
***************************************************************************************************
*                                         FUNCTIONS
***************************************************************************************************
*/
/*
***************************************************************************************************
*                                          cmain
*
* This is the standard entry point for C code.
*
* Notes
*   It is assumed that your code will call main() once you have performed all necessary
*   initialization.
*
***************************************************************************************************
*/
void cmain (void)
{
    static uint32           AppTaskStartID = 0;
    static uint32           AppTaskStartStk[ACFG_TASK_MEDIUM_STK_SIZE];
    SALRetCode_t            err;
    SALMcuVersionInfo_t     versionInfo = {0,0,0,0};

#if ( SIC_BSP_SUPPORT_TEST_APP_CPU == 1 )
    /* To avoid affected from OS resources */
    main_dhrystone_1();
#endif

    (void)SAL_Init();

    BSP_PreInit(); /* Initialize basic BSP functions */

#if ( SIC_BSP_SUPPORT_CAN_DEMO == 1 )
    (void)CAN_DemoInitialize();
#endif  // ( MCU_BSP_SUPPORT_CAN_DEMO == 1 )

    BSP_Init(); /* Initialize BSP functions */

    (void)SAL_GetVersion(&versionInfo);
    mcu_printf("\nSIC BSP Version: V%d.%d.%d\n",
           versionInfo.viMajorVersion,
           versionInfo.viMinorVersion,
           versionInfo.viPatchVersion);

    // create the first app task...
    err = (SALRetCode_t)SAL_TaskCreate(&AppTaskStartID,
                         (const uint8 *)"App Task Start",
                         (SALTaskFunc) &Main_StartTask,
                         &AppTaskStartStk[0],
                         ACFG_TASK_MEDIUM_STK_SIZE,
                         SAL_PRIO_APP_CFG,
                         NULL);

    if (err == SAL_RET_SUCCESS) 
    {
        // start woring os.... never return from this function
        (void)SAL_OsStart();
    }
}

static void Lpa_Start(void) 
{
#if ((CORTEX_M7_NP == 1) && (SIC_BSP_SUPPORT_TEST_APP_LPA_M == 1))
	
    frm_lpa_init();

	frm_lpa_rx_setRegCB(cb_print_reg_data_info);
	frm_lpa_rx_setDataCB(cb_print_data_frame_info);
	frm_lpa_rx_setTsCB(cb_print_ts_frame_info);
	frm_lpa_rx_setStatusCB(cb_print_status_frame_info);

	frm_canc_setExpandCB(cb_canc_expand);
#if (SIC_BSP_SUPPORT_TEST_APP_TPA == 1)
	frm_tsnc_setCANtoEthCB(cb_tsnc_can_to_eth_cnvt);
	frm_tsnc_setEthtoCANCB(cb_tsnc_eth_to_can_cnvt);
#endif
#endif
}


/*
***************************************************************************************************
*                                          Main_StartTask
*
* This is an example of a startup task.
*
* Notes
*   As mentioned in the book's text, you MUST initialize the ticker only once multitasking has
*   started.
*
*   1) The first line of code is used to prevent a compiler warning because 'pArg' is not used.
*      The compiler should not generate any code for this statement.
*
***************************************************************************************************
*/
static void Main_StartTask(void * pArg)
{
    (void)pArg;
    (void)SAL_OsInitFuncs();

	Lpa_Start();

#if (SIC_BSP_SUPPORT_APP_AP_RESET == 1)
#if ((SIC_BSP_SUPPORT_APP_AP_CORE_RESET_AUTORUN == 1) || \
        (SIC_BSP_SUPPORT_APP_AP_SYSTEM_RESET_AUTORUN == 1))
    RESET_CreateApRstApp();
#endif
#endif

    /* Service Init*/
#if (SIC_BSP_SUPPORT_DRIVER_IPC)
    IPC_CreateIPCParserTask();
#endif

#if (SIC_BSP_SUPPORT_DRIVER_SDM)
    (void)SDM_Init();
#endif

    /* Create application tasks */
    AppTaskCreate();

    // 241205 sy.kim
    uint32 lastTick_10ms, lastTick_20ms, lastTick_50ms;
    uint32 currentTick;

    SAL_GetTickCount(&lastTick_10ms);
    SAL_GetTickCount(&lastTick_20ms);
    SAL_GetTickCount(&lastTick_50ms);

    while (TRUE)
    {  /* Task body, always written as an infinite loop. */
        DisplayAliveLog();

        // 241205 sy.kim
        SAL_GetTickCount(&currentTick);
        if ((currentTick - lastTick_10ms) >= 10)
        {
            TxCAN2_WHL_01_10ms(); // CAN ID: 0xA0, RX: CAN 3 (MDPS)
            lastTick_10ms = currentTick;
        }
        if ((currentTick - lastTick_20ms) >= 20)
        {
            TxCAN1_ADAS_CMD_10_20ms(); // CAN ID: 0x160, RX: CAN 2 (E-CAN)
            TxCAN1_ADAS_CMD_20_20ms(); // CAN ID: 0x1EA, RX: CAN 2 (E-CAN)
            TxCAN2_ADAS_PRK_20_20ms(); // CAN ID: 0x165, RX: CAN 3 (MDPS)
            lastTick_20ms = currentTick;
        }
        if ((currentTick - lastTick_50ms) >= 50)
        {
            TxCAN1_ADAS_CMD_32_50ms(); // CAN ID: 0x1A0, RX: CAN 2 (E-CAN)
            lastTick_50ms = currentTick;
        }

        //mcu_printf("\n MCU Idle !!!");
        (void)SAL_TaskSleep(1); // 241209 sy.kim 5000 -> 1
    }
}


static void AppTaskCreate(void)
{
#if (SIC_BSP_SUPPORT_CONSOLE == 1)
    CreateConsoleTask();
#endif

#if ( SIC_BSP_SUPPORT_CAN_DEMO == 1 )
    CAN_DemoCreateApp();
#endif

#if (ACFG_APP_SYSTEM_MONITORING_EN == 1)
    SM_CreateAppTask();
#endif

#if (ACFG_APP_TRVC_EN == 1)
    TRVC_CreateAppTasks();
#endif

#if (SIC_BSP_SYS_PV_SFMC == 1)
    SFMCTEST_CreateTask();
#endif

#if (SIC_BSP_SUPPORT_TEST_APP_LPA_M == 1)
	LPA_Rx_CreateAppTasks();
	LPA_Tx_CreateAppTasks();
    LPA_IPC_RxTaskCreate();
#if (LPA_LOG_EN == 1)
	LPA_Log_CreateAppTasks();
#endif
#endif

#if (SIC_BSP_SUPPORT_TEST_APP_LPA_S == 1)
#if (SIC_BSP_SUPPORT_IPC_DATA_SEND == 1)
    LPA_SF_CreateAppTask();
#endif
    LPA_SF_ctrl_CreateAppTask();
#endif

#if (SIC_BSP_SUPPORT_TEST_APP_TPA == 1)
	TPA_RX_CreateAppTasks();
	TPA_TX_CreateAppTasks();
#endif
#if (TSNC_EN == 1)
    TSNC_Init();
#endif
#if (CANC_EN == 1)
    CANCnvt_Init();
#endif
#if (IPC_EN == 1)
    add_IPC_routeTable();
#endif
#if (VNG_APP_IPC_Sample_EN == 1)
	IPC_CreateAppTask();
#endif
#if (VNG_APP_IPI_Sample_EN == 1)
	IPI_CreateAppTask();
#endif


}

static void DisplayAliveLog(void)
{
    if (gALiveMsgOnOff != 0U)
    {
        mcu_printf("\n %d", gALiveCount);

        if(gALiveCount >= MAIN_UINT_MAX_NUM)
        {
            gALiveCount = 0;
        }
        else
        {
            gALiveCount++;
        }
    }
    else
    {
        gALiveCount = 0;
    }
}

