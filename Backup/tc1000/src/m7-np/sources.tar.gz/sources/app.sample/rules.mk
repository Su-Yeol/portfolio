###################################################################################################
#
#   FileName : ruls.mk
#
#   Copyright (c) Telechips Inc.
#
#   Description :
#
#
###################################################################################################
#
#   TCC Version 1.0
#
#   This source code contains confidential information of Telechips.
#
#   Any unauthorized use without a written permission of Telechips including not limited to
#   re-distribution in source or binary form is strictly prohibited.
#
#   This source code is provided "AS IS" and nothing contained in this source code shall constitute
#   any express or implied warranty of any kind, including without limitation, any warranty of
#   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
#   or other third party intellectual property right. No warranty is made, express or implied,
#   regarding the information's accuracy,completeness, or performance.
#
#   In no event shall Telechips be liable for any claim, damages or other liability arising from,
#   out of or in connection with this source code or the use in the source code.
#
#   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
#   Telechips and Company.
#   This source code is provided "AS IS" and nothing contained in this source code shall constitute
#   any express or implied warranty of any kind, including without limitation, any warranty
#   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
#   copyright or other third party intellectual property right. No warranty is made, express or
#   implied, regarding the information's accuracy, completeness, or performance.
#   In no event shall Telechips be liable for any claim, damages or other liability arising from,
#   out of or in connection with this source code or the use in the source code.
#   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
#   between Telechips and Company.
#
###################################################################################################

SIC_BSP_APP_SAMPLE_PATH := $(SIC_BSP_BUILD_CURDIR)

# Main
include $(SIC_BSP_APP_SAMPLE_PATH)/app.base/rules.mk

# CAN Demo Application
ifeq ($(SIC_BSP_APP_SAMPLE_CAN_DEMO), y)
    include $(SIC_BSP_APP_SAMPLE_PATH)/app.can.demo/rules.mk
endif

# Console Application
ifeq ($(SIC_BSP_APP_SAMPLE_CONSOLE), y)
    include $(SIC_BSP_APP_SAMPLE_PATH)/app.console/rules.mk
endif

# FWUG Application
#include $(SIC_BSP_APP_SAMPLE_PATH)/app.fwug/rules.mk

# System Monitoring Application
#include $(SIC_BSP_APP_SAMPLE_PATH)/app.system.monitoring/rules.mk

# Boot Control Application
#include $(SIC_BSP_APP_SAMPLE_PATH)/app.boot.ctrl/rules.mk

# Trust RVC application
ifeq ($(SIC_BSP_BUILD_FLAGS_T_RVC_INCLUDED), y)
    include $(SIC_BSP_APP_SAMPLE_PATH)/app.trust.rvc/rules.mk
endif

# Reset Application
ifeq ($(SIC_BSP_APP_SAMPLE_AP_RESET), y)
    include $(SIC_BSP_APP_SAMPLE_PATH)/app.reset/rules.mk
endif

# GDMA Sample Application
ifeq ($(SIC_BSP_APP_SAMPLE_GDMA), y)
    include $(SIC_BSP_APP_SAMPLE_PATH)/app.gdma/rules.mk
endif

# System Safety Mechanism (SSM) : Isolation, ssm-configuration
ifeq ($(SIC_BSP_SYS_PV_SSM), y)
include $(SIC_BSP_APP_SAMPLE_PATH)/app.ssm/rules.mk
endif 

# LPA Sample Application
ifeq ($(SIC_BSP_APP_SAMPLE_LPA_M), y)
    include $(SIC_BSP_APP_SAMPLE_PATH)/app.lpa/rules.mk
else
ifeq ($(SIC_BSP_APP_SAMPLE_LPA_S), y)
    include $(SIC_BSP_APP_SAMPLE_PATH)/app.lpa/rules.mk
endif   
endif

# TPA Sample Application
ifeq ($(SIC_BSP_DEV_DRV_TPA), y)
    include $(SIC_BSP_APP_SAMPLE_PATH)/app.tpa/rules.mk
endif

# IPC App sample
ifeq ($(SIC_BSP_APP_DRIVER_IPC), y)
include $(SIC_BSP_APP_SAMPLE_PATH)/app.ipc/rules.mk
endif

# IPI App sample
ifeq ($(SIC_BSP_APP_DRIVER_IPI), y)
include $(SIC_BSP_APP_SAMPLE_PATH)/app.ipi/rules.mk
endif