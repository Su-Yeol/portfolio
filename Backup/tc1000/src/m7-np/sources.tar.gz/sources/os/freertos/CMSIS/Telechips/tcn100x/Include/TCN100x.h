// SPDX-License-Identifier: MIT
/*
 * Copyright (C) Telechips Inc.
 */

#ifndef __TCC100X_H__
#define __TCC100X_H__

/*
* ==========================================================================
* --------------------- __NVIC_PRIO_BITS -----------------------------------
* ==========================================================================
*/
#ifndef __NVIC_PRIO_BITS
#define __NVIC_PRIO_BITS (7)
#endif

/*
* ==========================================================================
* ----------------------------- M0+ Stuff -----------------------------------
* ==========================================================================
*/

#define __CM7_REV                 0x0000   /*!< Cortex-M7 revision r0p0                       */
#define __MPU_PRESENT             1       /*!< CM7 provides an MPU                           */
#define __Vendor_SysTickConfig    0       /*!< Set to 1 if different SysTick Config is used  */
#define __FPU_PRESENT             1       /*!< FPU present                                   */
#define __ICACHE_PRESENT          1       /*!< CM7 instruction cache present                 */
#define __DCACHE_PRESENT          1       /*!< CM7 data cache present                        */

typedef enum IRQn
{
	/******  Cortex-M7 Processor Exceptions Numbers **********************************/
	NMI_IRQn                    = -14,      /*!<  2 Non Maskable Interrupt                */
	MemManage_IRQn              = -12,      /*!<  4 Cortex-M0+ Memory Management Interrupt */
	BusFault_IRQn               = -11,      /*!<  5 Cortex-M0+ Bus Fault Interrupt         */
	UsageFault_IRQn             = -10,      /*!<  6 Cortex-M0+ Usage Fault Interrupt       */
	SVC_IRQn                    = -5,       /*!< 11 Cortex-M0+ SV Call Interrupt           */
	DebugMon_IRQn               = -4,       /*!< 12 Cortex-M0+ Debug Monitor Interrupt     */
	PendSV_IRQn                 = -2,       /*!< 14 Cortex-M0+ Pend SV Interrupt           */
	SysTick_IRQn                = -1,       /*!< 15 Cortex-M0+ System Tick Interrupt       */

    A65AE_0_IRQn                =   0,
    A65AE_1_IRQn                =   1,
    A65AE_2_IRQn                =   2,
    A65AE_3_IRQn                =   3,
    A65AE_4_IRQn                =   4,
    A65AE_5_IRQn                =   5,
    A65AE_6_IRQn                =   6,
    A65AE_7_IRQn                =   7,
    A65AE_8_IRQn                =   8,
    A65AE_9_IRQn                =   9,
    A65AE_10_IRQn               =  10,
    A65AE_11_IRQn               =  11,
    A65AE_12_IRQn               =  12,
    A65AE_13_IRQn               =  13,
    A65AE_PMU_IRQn              =  14,
    NOC_NIU_IRQn                =  15,
    A65AE_WDT0_IRQn             =  16,
    A65AE_WDT1_IRQn             =  17,
    A65AE_WDT2_IRQn             =  18,
    A65AE_WDT3_IRQn             =  19,
    A65AE_WDT4_IRQn             =  20,
    A65AE_WDT5_IRQn             =  21,

    MBOX_A65_M0_S_SLV_TX_IRQn   =  22,
    MBOX_A65_M0_S_SLV_RX_IRQn   =  23,
    MBOX_A65_M1_S_SLV_TX_IRQn   =  24,
    MBOX_A65_M1_S_SLV_RX_IRQn   =  25,
    MBOX_A65_M2_S_SLV_TX_IRQn   =  26,
    MBOX_A65_M2_S_SLV_RX_IRQn   =  27,
    MBOX_A65_HSM_S_SLV_TX_IRQn  =  28,
    MBOX_A65_HSM_S_SLV_RX_IRQn  =  29,
    MBOX_A65_MX_S_SLV_TX_IRQn   =  30,
    MBOX_A65_MX_S_SLV_RX_IRQn   =  31,
    MBOX_A65_M0_S_MST_TX_IRQn   =  32,
    MBOX_A65_M0_S_MST_RX_IRQn   =  33,
    MBOX_A65_M1_S_MST_TX_IRQn   =  34,
    MBOX_A65_M1_S_MST_RX_IRQn   =  35,
    MBOX_A65_M2_S_MST_TX_IRQn   =  36,
    MBOX_A65_M2_S_MST_RX_IRQn   =  37,
    MBOX_A65_HSM_S_MST_TX_IRQn  =  38,
    MBOX_A65_HSM_S_MST_RX_IRQn  =  39,
    MBOX_A65_MX_S_MST_TX_IRQn   =  40,
    MBOX_A65_MX_S_MST_RX_IRQn   =  41,
    MBOX_A65_M0_NS_SLV_TX_IRQn  =  42,
    MBOX_A65_M0_NS_SLV_RX_IRQn  =  43,
    MBOX_A65_M1_NS_SLV_TX_IRQn  =  44,
    MBOX_A65_M1_NS_SLV_RX_IRQn  =  45,
    MBOX_A65_M2_NS_SLV_TX_IRQn  =  46,
    MBOX_A65_M2_NS_SLV_RX_IRQn  =  47,
    MBOX_A65_HSM_NS_SLV_TX_IRQn =  48,
    MBOX_A65_HSM_NS_SLV_RX_IRQn =  49,
    MBOX_A65_MX_NS_SLV_TX_IRQn  =  50,
    MBOX_A65_MX_NS_SLV_RX_IRQn  =  51,
    MBOX_A65_M0_NS_MST_TX_IRQn  =  52,
    MBOX_A65_M0_NS_MST_RX_IRQn  =  53,
    MBOX_A65_M1_NS_MST_TX_IRQn  =  54,
    MBOX_A65_M1_NS_MST_RX_IRQn  =  55,
    MBOX_A65_M2_NS_MST_TX_IRQn  =  56,
    MBOX_A65_M2_NS_MST_RX_IRQn  =  57,
    MBOX_A65_HSM_NS_MST_TX_IRQn =  58,
    MBOX_A65_HSM_NS_MST_RX_IRQn =  59,
    MBOX_A65_MX_NS_MST_TX_IRQn  =  60,
    MBOX_A65_MX_NS_MST_RX_IRQn  =  61,

    GIC_600AE_F_REQ_IRQn        =  62,
    GIC_600AE_E_REQ_IRQn        =  63,
    GIC_600AE_PMU_REQ_IRQn      =  64,
    GIC_600AE_FMU_F_REQ_IRQn    =  65,
    GIC_600AE_FMU_E_REQ_IRQn    =  66,
    NOC_I_REQ_IRQn              =  67,
    M7_0_WDT_IRQn               =  68,

    MBOX_M0_A65_S_SLV_TX_IRQn   =  69,
    MBOX_M0_A65_S_SLV_RX_IRQn   =  70,
    MBOX_M0_A65_NS_SLV_TX_IRQn  =  71,
    MBOX_M0_A65_NS_SLV_RX_IRQn  =  72,
    MBOX_M0_M1_SLV_TX_IRQn      =  73,
    MBOX_M0_M1_SLV_RX_IRQn      =  74,
    MBOX_M0_M2_SLV_TX_IRQn      =  75,
    MBOX_M0_M2_SLV_RX_IRQn      =  76,
    MBOX_M0_HSM_SLV_TX_IRQn     =  77,
    MBOX_M0_HSM_SLV_RX_IRQn     =  78,
    MBOX_M0_MX_SLV_TX_IRQn      =  79,
    MBOX_M0_MX_SLV_RX_IRQn      =  80,
    MBOX_M0_A65_S_MST_TX_IRQn   =  81,
    MBOX_M0_A65_S_MST_RX_IRQn   =  82,
    MBOX_M0_A65_NS_MST_TX_IRQn  =  83,
    MBOX_M0_A65_NS_MST_RX_IRQn  =  84,
    MBOX_M0_M1_MST_TX_IRQn      =  85,
    MBOX_M0_M1_MST_RX_IRQn      =  86,
    MBOX_M0_M2_MST_TX_IRQn      =  87,
    MBOX_M0_M2_MST_RX_IRQn      =  88,
    MBOX_M0_HSM_MST_TX_IRQn     =  89,
    MBOX_M0_HSM_MST_RX_IRQn     =  90,
    MBOX_M0_MX_MST_TX_IRQn      =  91,
    MBOX_M0_MX_MST_RX_IRQn      =  92,

    M7_0_IRQ_MERGE_IRQn         =  93,
    M7_1_WDT_IRQn               =  94,

    MBOX_M1_A65_S_SLV_TX_IRQn   =  95,
    MBOX_M1_A65_S_SLV_RX_IRQn   =  96,
    MBOX_M1_A65_NS_SLV_TX_IRQn  =  97,
    MBOX_M1_A65_NS_SLV_RX_IRQn  =  98,
    MBOX_M1_M0_SLV_TX_IRQn      =  99,
    MBOX_M1_M0_SLV_RX_IRQn      = 100,
    MBOX_M1_M2_SLV_TX_IRQn      = 101,
    MBOX_M1_M2_SLV_RX_IRQn      = 102,
    MBOX_M1_HSM_SLV_TX_IRQn     = 103,
    MBOX_M1_HSM_SLV_RX_IRQn     = 104,
    MBOX_M1_MX_SLV_TX_IRQn      = 105,
    MBOX_M1_MX_SLV_RX_IRQn      = 106,
    MBOX_M1_A65_S_MST_TX_IRQn   = 107,
    MBOX_M1_A65_S_MST_RX_IRQn   = 108,
    MBOX_M1_A65_NS_MST_TX_IRQn  = 109,
    MBOX_M1_A65_NS_MST_RX_IRQn  = 110,
    MBOX_M1_M0_MST_TX_IRQn      = 111,
    MBOX_M1_M0_MST_RX_IRQn      = 112,
    MBOX_M1_M2_MST_TX_IRQn      = 113,
    MBOX_M1_M2_MST_RX_IRQn      = 114,
    MBOX_M1_HSM_MST_TX_IRQn     = 115,
    MBOX_M1_HSM_MST_RX_IRQn     = 116,
    MBOX_M1_MX_MST_TX_IRQn      = 117,
    MBOX_M1_MX_MST_RX_IRQn      = 118,


    M7_1_IRQ_MERGE_IRQn         = 119,
    M7_2_WDT_IRQn               = 120,

    MBOX_M2_A65_S_SLV_TX_IRQn   = 121,
    MBOX_M2_A65_S_SLV_RX_IRQn   = 122,
    MBOX_M2_A65_NS_SLV_TX_IRQn  = 123,
    MBOX_M2_A65_NS_SLV_RX_IRQn  = 124,
    MBOX_M2_M0_SLV_TX_IRQn      = 125,
    MBOX_M2_M0_SLV_RX_IRQn      = 126,
    MBOX_M2_M1_SLV_TX_IRQn      = 127,
    MBOX_M2_M1_SLV_RX_IRQn      = 128,
    MBOX_M2_HSM_SLV_TX_IRQn     = 129,
    MBOX_M2_HSM_SLV_RX_IRQn     = 130,
    MBOX_M2_MX_SLV_TX_IRQn      = 131,
    MBOX_M2_MX_SLV_RX_IRQn      = 132,
    MBOX_M2_A65_S_MST_TX_IRQn   = 133,
    MBOX_M2_A65_S_MST_RX_IRQn   = 134,
    MBOX_M2_A65_NS_MST_TX_IRQn  = 135,
    MBOX_M2_A65_NS_MST_RX_IRQn  = 136,
    MBOX_M2_M0_MST_TX_IRQn      = 137,
    MBOX_M2_M0_MST_RX_IRQn      = 138,
    MBOX_M2_M1_MST_TX_IRQn      = 139,
    MBOX_M2_M1_MST_RX_IRQn      = 140,
    MBOX_M2_HSM_MST_TX_IRQn     = 141,
    MBOX_M2_HSM_MST_RX_IRQn     = 142,
    MBOX_M2_MX_MST_TX_IRQn      = 143,
    MBOX_M2_MX_MST_RX_IRQn      = 144,

    M7_2_IRQ_MERGE_IRQn         = 145,
    HSM_OUT_INT0_IRQn           = 146,
    HSM_OUT_INT1_IRQn           = 147,
    HSM_OUT_INT2_IRQn           = 148,
    HSM_OUT_INT3_IRQn           = 149,
    HSM_OUT_INT4_IRQn           = 150,
    HSM_OUT_INT5_IRQn           = 151,
    HSM_OUT_INT6_IRQn           = 152,
    HSM_OUT_INT7_IRQn           = 153,

    MBOX_HSM_A65_S_SLV_RX_IRQn  = 154,
    MBOX_HSM_A65_S_SLV_TX_IRQn  = 155,
    MBOX_HSM_A65_NS_SLV_RX_IRQn = 156,
    MBOX_HSM_A65_NS_SLV_TX_IRQn = 157,
    MBOX_HSM_M0_SLV_TX_IRQn     = 158,
    MBOX_HSM_M0_SLV_RX_IRQn     = 159,
    MBOX_HSM_M1_SLV_TX_IRQn     = 160,
    MBOX_HSM_M1_SLV_RX_IRQn     = 161,
    MBOX_HSM_M2_SLV_TX_IRQn     = 162,
    MBOX_HSM_M2_SLV_RX_IRQn     = 163,
    MBOX_HSM_MX_SLV_TX_IRQn     = 164,
    MBOX_HSM_MX_SLV_RX_IRQn     = 165,
    MBOX_HSM_A65_S_MST_RX_IRQn  = 166,
    MBOX_HSM_A65_S_MST_TX_IRQn  = 167,
    MBOX_HSM_A65_NS_MST_RX_IRQn = 168,
    MBOX_HSM_A65_NS_MST_TX_IRQn = 169,
    MBOX_HSM_M0_MST_TX_IRQn     = 170,
    MBOX_HSM_M0_MST_RX_IRQn     = 171,
    MBOX_HSM_M1_MST_TX_IRQn     = 172,
    MBOX_HSM_M1_MST_RX_IRQn     = 173,
    MBOX_HSM_M2_MST_TX_IRQn     = 174,
    MBOX_HSM_M2_MST_RX_IRQn     = 175,
    MBOX_HSM_MX_MST_TX_IRQn     = 176,
    MBOX_HSM_MX_MST_RX_IRQn     = 177,


    SEC_DMA_INT_IRQn            = 178,
    DPI_MERGE_INT_IRQn          = 179,
    DPI_CIE_RES_RED0_IRQn       = 180,
    DPI_CIE_RES_RED1_IRQn       = 181,
    DPI_CIE_RES_RED2_IRQn       = 182,
    DPI_CIE_RES_RED3_IRQn       = 183,
    DPI_CIE_OQM_INT0_IRQn       = 184,
    DPI_CIE_OQM_INT1_IRQn       = 185,
    DPI_CIE_OQM_INT2_IRQn       = 186,
    DPI_CIE_OQM_INT3_IRQn       = 187,
    DPI_CIE_DELAY_INT0_IRQn     = 188,
    DPI_CIE_DELAY_INT1_IRQn     = 189,
    DPI_CIE_DELAY_INT2_IRQn     = 190,
    DPI_CIE_DELAY_INT3_IRQn     = 191,
    DPI_CIE_TMR_INT0_IRQn       = 192,
    DPI_CIE_TMR_INT1_IRQn       = 193,
    DPI_CIE_TMR_INT2_IRQn       = 194,
    DPI_CIE_TMR_INT3_IRQn       = 195,

    GDMA_0_IRQn                 = 196,
    GDMA_1_IRQn                 = 197,
    GDMA_2_IRQn                 = 198,
    GDMA_3_IRQn                 = 199,
    GDMA_4_IRQn                 = 200,
    GDMA_5_IRQn                 = 201,
    GDMA_6_IRQn                 = 202,
    GDMA_7_IRQn                 = 203,
    GDMA_8_IRQn                 = 204,
    GDMA_9_IRQn                 = 205,
    GDMA_10_IRQn                = 206,
    GDMA_11_IRQn                = 207,
    GDMA_12_IRQn                = 208,
    GDMA_13_IRQn                = 209,
    GDMA_14_IRQn                = 210,
    GDMA_15_IRQn                = 211,
    GDMA_16_IRQn                = 212,
    GDMA_17_IRQn                = 213,
    GDMA_18_IRQn                = 214,
    GDMA_19_IRQn                = 215,
    GDMA_20_IRQn                = 216,
    GDMA_21_IRQn                = 217,
    GDMA_22_IRQn                = 218,
    GDMA_23_IRQn                = 219,
    GDMA_24_IRQn                = 220,
    GDMA_25_IRQn                = 221,
    GDMA_26_IRQn                = 222,
    GDMA_27_IRQn                = 223,
    GDMA_28_IRQn                = 224,
    GDMA_29_IRQn                = 225,
    GDMA_30_IRQn                = 226,
    GDMA_31_IRQn                = 227,
    GDMA_ABORT_IRQn             = 228,
    SFMC0_IRQn                  = 229,
    SFMC0_ECC_IRQn              = 230,
    SFMC1_IRQn                  = 231,
    SFMC1_ECC_IRQn              = 232,

    DDR_PHY0_OVER_TMP_IRQn      = 233,
    DDR_PHY0_HIGH_TMP_IRQn      = 234,
    DDR_PHY0_LOW_TMP_IRQn       = 235,
    DDR_PHY0_CORRECTION_IRQn    = 236,
    DDR_PHY0_DOU_BIT_ERR_IRQn   = 237,
    DDR_PHY0_ADDR_PROT_IRQn     = 238,
    DDR_PHY0_SCRAMBLER_IRQn     = 239,
    DDR_PHY0_IVALID_ACCESS_IRQn = 240,
    DDR_PHY1_OVER_TMP_IRQn      = 241,
    DDR_PHY1_HIGH_TMP_IRQn      = 242,
    DDR_PHY1_LOW_TMP_IRQn       = 243,
    DDR_PHY1_CORRECTION_IRQn    = 244,
    DDR_PHY1_DOU_BIT_ERR_IRQn   = 245,
    DDR_PHY1_ADDR_PROT_IRQn     = 246,
    DDR_PHY1_SCRAMBLER_IRQn     = 247,
    DDR_PHY1_IVALID_ACCESS_IRQn = 248,
    SRAM_0_FAULT_IRQn           = 249,
    SRAM_1_FAULT_IRQn           = 250,
    SRAM_2_FAULT_IRQn           = 251,
    SRAM_3_FAULT_IRQn           = 252,
    SRAM_4_FAULT_IRQn           = 253,
    SRAM_5_FAULT_IRQn           = 254,
    SRAM_6_FAULT_IRQn           = 255,
    SRAM_7_FAULT_IRQn           = 256,
    SRAM_8_FAULT_IRQn           = 257,
    SRAM_9_FAULT_IRQn           = 258,
    SRAM_10_FAULT_IRQn          = 259,
    SRAM_11_FAULT_IRQn          = 260,
    SRAM_12_FAULT_IRQn          = 261,
    SRAM_13_FAULT_IRQn          = 262,
    SRAM_14_FAULT_IRQn          = 263,
    SRAM_15_FAULT_IRQn          = 264,
    ROM_FAULT_IRQn              = 265,
    SRAM_INIT_DONE_IRQn         = 266,
    IMC_NOC_IRQn                = 267,
    SOC400_SEC_IRQn             = 268,
    SOC400_HSSTP0_IRQn          = 269,
    MEM_NOC_MERGER_IRQn         = 270,
    MEM_NOC_ALARM_MERGER_IRQn   = 271,
    SOC400_HSSTP1_IRQn          = 272,
    MX_WDT_IRQn                 = 273,

    MBOX_MX_A65_S_MST_TX_IRQn   = 274,
    MBOX_MX_A65_S_MST_RX_IRQn   = 275,
    MBOX_MX_A65_NS_MST_TX_IRQn  = 276,
    MBOX_MX_A65_NS_MST_RX_IRQn  = 277,
    MBOX_MX_M0_MST_TX_IRQn      = 278,
    MBOX_MX_M0_MST_RX_IRQn      = 279,
    MBOX_MX_M1_MST_TX_IRQn      = 280,
    MBOX_MX_M1_MST_RX_IRQn      = 281,
    MBOX_MX_M2_MST_TX_IRQn      = 282,
    MBOX_MX_M2_MST_RX_IRQn      = 283,
    MBOX_MX_HSM_MST_TX_IRQn     = 284,
    MBOX_MX_HSM_MST_RX_IRQn     = 285,
    MBOX_MX_A65_S_SLV_TX_IRQn   = 286,
    MBOX_MX_A65_S_SLV_RX_IRQn   = 287,
    MBOX_MX_A65_NS_SLV_TX_IRQn  = 288,
    MBOX_MX_A65_NS_SLV_RX_IRQn  = 289,
    MBOX_MX_M0_SLV_TX_IRQn      = 290,
    MBOX_MX_M0_SLV_RX_IRQn      = 291,
    MBOX_MX_M1_SLV_TX_IRQn      = 292,
    MBOX_MX_M1_SLV_RX_IRQn      = 293,
    MBOX_MX_M2_SLV_TX_IRQn      = 294,
    MBOX_MX_M2_SLV_RX_IRQn      = 295,
    MBOX_MX_HSM_SLV_TX_IRQn     = 296,
    MBOX_MX_HSM_SLV_RX_IRQn     = 297,

    MX_WRAPPER_NOC_IRQn         = 298,
    TPA_EPP_INT0_IRQn           = 299,
    TPA_EPP_INT1_IRQn           = 300,
    TPA_EPP_INT9_IRQn           = 301,
    TPA_EPP_INT16_IRQn          = 302,
    TPA_EPP_INT17_IRQn          = 303,
    TPA_EPP_INT18_IRQn          = 304,
    TPA_GMAC0_MCI_IRQn          = 305,
    TPA_GMAC0_SBD_SFTY_IRQn     = 306,
    TPA_GMAC1_MCI_IRQn          = 307,
    TPA_GMAC1_SBD_SFTY_IRQn     = 308,
    TPA_XGMAC0_SBD_IRQn         = 309,
    TPA_XGMAC0_SBD_SFTY_IRQn    = 310,
    TPA_XGMAC1_SBD_IRQn         = 311,
    TPA_XGMAC1_SBD_SFTY_IRQn    = 312,
    TPA_XPCS0_SBD_IRQn          = 313,
    TPA_XPCS0_SBD_SFTY_IRQn     = 314,
    TPA_XPCS1_SBD_IRQn          = 315,
    TPA_XPCS1_SBD_SFTY_IRQn     = 316,
    LPA_DMA_ERROR_IRQn          = 317,
    LPA_DMA_COUNT_IRQn          = 318,
    LPA_DMA_COMBINE_IRQn        = 319,
    NET_SUB_NOC                 = 320,
    LPA_HOST_AXI_IRQn           = 321,
    LPA_LOG_AXI_IRQn            = 322,
    LPA_ERROR_AXI_IRQn          = 323,
    RESETVED1_IRQn              = 324,
    RESETVED2_IRQn              = 325,
    RESETVED3_IRQn              = 326,
    RESETVED4_IRQn              = 327,
    RESETVED5_IRQn              = 328,
    SD_EMMC_IRQn                = 329,
    SD_EMMC_WAKEUP_IRQn         = 330,

    GMAC0_SB_IRQn               = 331,
    GMAC0_SB_RX_CH0_IRQn        = 332,
    GMAC0_SB_RX_CH1_IRQn        = 333,
    GMAC0_SB_RX_CH2_IRQn        = 334,
    GMAC0_SB_TX_CH0_IRQn        = 335,
    GMAC0_SB_TX_CH1_IRQn        = 336,
    GMAC0_SB_TX_CH2_IRQn        = 337,
    GMAC0_F0_IRQn               = 338,
    GMAC0_F1_IRQn               = 339,
    GMAC0_F2_IRQn               = 340,
    GMAC1_SB_IRQn               = 341,
    GMAC1_SB_RX_CH0_IRQn        = 342,
    GMAC1_SB_RX_CH1_IRQn        = 343,
    GMAC1_SB_RX_CH2_IRQn        = 344,
    GMAC1_SB_TX_CH0_IRQn        = 345,
    GMAC1_SB_TX_CH1_IRQn        = 346,
    GMAC1_SB_TX_CH2_IRQn        = 347,
    GMAC1_F0_IRQn               = 348,
    GMAC1_F1_IRQn               = 349,
    GMAC1_F2_IRQn               = 350,
    USB20_OTG_IRQn              = 351,
    USB20_OTG_PHY_IRQn          = 352,
    HSIO_NOC_IRQn               = 353,
    PCIE_LINK0_IRQn             = 354,
    PCIE_LINK0_EDMA_IRQn        = 355,
    PCIE_LINK1_IRQn             = 356,
    PCIE_LINK1_EDMA_IRQn        = 357,
    PCIE_MMU_TCU_PMU_IRQn       = 358,
    PCIE_MMU_TCU_RAS_IRQn       = 359,
    PCIE_MMU_TCU_G_SEC_IRQn     = 360,
    PCIE_MMU_TCU_G_NONSEC_IRQn  = 361,
    PCIE_MMU_TCU_SEC_SYNC_IRQn  = 362,
    PCIE_MMU_TCU_NONSEC_SYNC_IRQn = 363,
    PCIE_MMU_TCU_PRI_IRQn       = 364,
    PCIE_MMU_TCU_SEC_QUE_IRQn   = 365,
    PCIE_MMU_TCU_NONSEC_QUE_IRQn  = 366,
    PCIE_MMU_TBU0_PMU_IRQn      = 367,
    PCIE_MMU_TBU0_RAS_IRQn      = 368,
    PCIE_MMU_TBU1_PMU_IRQn      = 369,
    PCIE_MMU_TBU1_RAS_IRQn      = 370,
    PCIE_MMU_TCU_FMU_F_IRQn     = 371,
    PCIE_MMU_TCU_FMU_E_IRQn     = 372,
    PCIE_NOC_IRQn               = 373,
    I2C_M_CH0_IRQn              = 374,
    I2C_M_CH1_IRQn              = 375,
    I2C_M_CH2_IRQn              = 376,
    I2C_M_CH3_IRQn              = 377,
    I2C_M_CH4_IRQn              = 378,
    I2C_VS_CH0_IRQn             = 379,
    I2C_VS_CH1_IRQn             = 380,
    I2C_VS_CH2_IRQn             = 381,
    I2C_VS_CH3_IRQn             = 382,
    I2C_VS_CH4_IRQn             = 383,
    GPSB_C0_IRQn                = 384,
    GPSB_C1_IRQn                = 385,
    GPSB_C2_IRQn                = 386,
    GPSB_C3_IRQn                = 387,
    GPSB_C4_IRQn                = 388,
    GPSB_C5_IRQn                = 389,
    GPSB_DMA_C0_IRQn            = 390,
    GPSB_DMA_C1_IRQn            = 391,
    GPSB_DMA_C2_IRQn            = 392,
    GPSB_DMA_C3_IRQn            = 393,
    GPSB_DMA_C4_IRQn            = 394,
    GPSB_DMA_C5_IRQn            = 395,
    UART_C0_IRQn                = 396,
    UART_C1_IRQn                = 397,
    UART_C2_IRQn                = 398,
    UART_C3_IRQn                = 399,
    UART_DMA_C0_IRQn            = 400,
    UART_DMA_C1_IRQn            = 401,
    UART_DMA_C2_IRQn            = 402,
    UART_DMA_C3_IRQn            = 403,
    CAN_C0_0_IRQn               = 404,
    CAN_C0_1_IRQn               = 405,
    CAN_C1_0_IRQn               = 406,
    CAN_C1_1_IRQn               = 407,
    CAN_C2_0_IRQn               = 408,
    CAN_C2_1_IRQn               = 409,
    CAN_C3_0_IRQn               = 410,
    CAN_C3_1_IRQn               = 411,
    ADC_IRQn                    = 412,
    IC_TC0_IRQn                 = 413,
    IC_TC1_IRQn                 = 414,
    IC_TC2_IRQn                 = 415,
    NOC0_IRQn                   = 416,
    TMR0_16_0_IRQn              = 417,
    TMR0_16_1_IRQn              = 418,
    TMR0_16_2_IRQn              = 419,
    TMR0_16_3_IRQn              = 420,
    TMR0_20_0_IRQn              = 421,
    TMR0_20_1_IRQn              = 422,
    TMR0_WDT_IRQn               = 423,
    TMR0_32_IRQn                = 424,
    TMR1_16_0_IRQn              = 425,
    TMR1_16_1_IRQn              = 426,
    TMR1_16_2_IRQn              = 427,
    TMR1_16_3_IRQn              = 428,
    TMR1_20_0_IRQn              = 429,
    TMR1_20_1_IRQn              = 430,
    TMR1_WDT_IRQn               = 431,
    TMR1_32_IRQn                = 432,
    TSC_IRQn                    = 433,
    RTC_IRQn                    = 434,
    TRNG_IRQn                   = 435,
    TRNG_F_IRQn                 = 436,
    TRNG_DUAL_FF_IRQn           = 437,
    TRNG_WDT_IRQn               = 438,
    TRNG_LOCKSTEP_F_IRQn        = 439,
    TRNG_F_LAD_QF_IRQn          = 440,
    TRNG_F_LAD_QL_IRQn          = 441,
    NOC1_IRQn                   = 442,
    GPIOEX0_IRQn                = 443,
    GPIOEX1_IRQn                = 444,
    GPIOEX2_IRQn                = 445,
    GPIOEX3_IRQn                = 446,
    GPIOEX4_IRQn                = 447,
    GPIOEX5_IRQn                = 448,
    GPIOEX6_IRQn                = 449,
    GPIOEX7_IRQn                = 450,
    GPIOEX8_IRQn                = 451,
    GPIOEX9_IRQn                = 452,
    GPIOEX10_IRQn               = 453,
    GPIOEX11_IRQn               = 454,
    GPIOEX12_IRQn               = 455,
    GPIOEX13_IRQn               = 456,
    GPIOEX14_IRQn               = 457,
    GPIOEX15_IRQn               = 458,
    GPIOEX0_NEG_IRQn            = 459,
    GPIOEX1_NEG_IRQn            = 460,
    GPIOEX2_NEG_IRQn            = 461,
    GPIOEX3_NEG_IRQn            = 462,
    GPIOEX4_NEG_IRQn            = 463,
    GPIOEX5_NEG_IRQn            = 464,
    GPIOEX6_NEG_IRQn            = 465,
    GPIOEX7_NEG_IRQn            = 466,
    GPIOEX8_NEG_IRQn            = 467,
    GPIOEX9_NEG_IRQn            = 468,
    GPIOEX10_NEG_IRQn           = 469,
    GPIOEX11_NEG_IRQn           = 470,
    GPIOEX12_NEG_IRQn           = 471,
    GPIOEX13_NEG_IRQn           = 472,
    GPIOEX14_NEG_IRQn           = 473,
    GPIOEX15_NEG_IRQn           = 474,
    PMU_WDT_IRQn                = 475,
    RESETVED6_IRQn              = 476,
    RESETVED7_IRQn              = 477,
    FMU_IRQ_IRQn                = 478,
    FMU_FIQ_IRQn                = 479,
    IRQn_MAX                    = 480,
}IRQn_Type;


/*
* ==========================================================================
* ----------- Processor and Core Peripheral Section ------------------------
* ==========================================================================
*/

#if 0
/** Macro to write new value to the bits in register */
#define WR_REG(reg, mask, pos, val) {  \
                     reg &= ~(mask);\
                     reg |= (val << pos) & mask;\
                    }

/** Macro to read the bits in register */
#define RD_REG(reg, mask, pos)            (((reg)&mask) >> pos)
/** Macro to set the particular bit in register */
#define SET_BIT(reg, pos)                 (reg) |= (1U<<pos)
/** Macro to clear the particular bit in register */
#define CLR_BIT(reg, pos)                 (reg) &= ~(1U<<pos)
#endif
#include <core_cm7.h>                 /*!< Cortex-M7 processor and core peripherals      */
//#include <core_cm0plus.h>
//#include "reg.h"

#if 0
/* CPU Bus Registers */
#define CPU_CA72_CFG_BASE_ADDR	0x77100000
#define CPU_CA53_CFG_BASE_ADDR	0x77200000
 #define CPU_CA72_53_AXI_BUSCFG	0x10
  #define CPU_AXI_BUSCFG_STSACK_SHIFT	1
  #define CPU_AXI_BUSCFG_PDREQ_SHIFT	15
#define CPU_CFG_BASE_ADDR		0x77000000
 #define CPU_CFG_SWRESETN		0x4
  #define CPU_CFG_SWRESET_WDT0_SHIFT	0
  #define CPU_CFG_SWRESET_WDT4_SHIFT	4
  #define CPU_CFG_SWRESET_CA72_SHIFT	15
  #define CPU_CFG_SWRESET_CA53_SHIFT	17

/* MEM Bus Registers */
#define MEM_BUS_BASE_ADDR		0x73500000
 #define MEM_BUS_SWRESET0		0xC

/* MBOX Registers */
#define MBOX_NS_CA72_REG_BASE		0x7D260000
#define MBOX_NS_CA53_REG_BASE		0x7D261000
#define MBOX_NS_SC100_REG_BASE		0x7D262000
#define MBOX_S_CA72_REG_BASE		0x7D263000
#define MBOX_S_CA53_REG_BASE		0x7D264000
#define MBOX_S_SC100_REG_BASE		0x7D265000
#define MBOX_HSM_REG_BASE			0x7E120000

/* SDMMC Registers */
#define SDHC_REG_BASE				0x7D2A0000
#define SDHC_CHCTRL_REG_BASE		0x7D2D1000

/* GPIO Registers */
#define GPIO_SD0_BASE				0x74200200
#define GPIO_MD_BASE				0x74200780

/* Boot time stamps */
#define SC_BOOT_TIME_DATA_ADDR		0x7D03F800

/* Boot configurations */
#define SC_BOOT_CONFIG_DATA_ADDR	0x7D03FA00
#define CA72_BOOT_CONFIG_DATA_ADDR	0xF003FA00
#define CA53_BOOT_CONFIG_DATA_ADDR	0xF103FA00

/* SC Sub */
#define STRG_CFG_REG_BASE			0x7D2C0000
#define STRG_CFG_CM_REMAP0				0x40
#define STRG_CFG_CM_REMAP1				0x44
#define STRG_CFG_BUS_PROTECT			0xB8

/* MEM BUS */
#define MEMBUS_CFG_REG_BASE			0x73500000
#define MEMBUS_CFG_BYTE_MASK00		0x70
#define MEMBUS_CFG_BYTE_MASK_NUM	8

/* SMU_PMU Timer */
#define SMU_PMU_TIMER_BASE			0x74300000

/* SMU_PMU PIC */
#define SMU_PMU_PIC_POL_BASE		0x74100000
#define SMU_PMU_PIC_STRG_BASE			0x74900000
 #define SMU_PMU_PIC_STRG_STS_BASE(X)	(SMU_PMU_PIC_STRG_BASE + (X * 4))
 #define SMU_PMU_PIC_STRG_EN_BASE(X)	(SMU_PMU_PIC_STRG_BASE + 0x40 + (X * 4))

/* Boot mode */
#define BOOTMODE_FWDN_USB20			0x0
#define BOOTMODE_SNOR_eMMC			0x2
#define BOOTMODE_eMMC_Only			0x5
#define	BOOTMODE_FWDN_USB30			0x8
#define BOOTMODE_SNOR_UFS			0xA
#define	BOOTMODE_UFS_Only			0xD

#endif
#endif
