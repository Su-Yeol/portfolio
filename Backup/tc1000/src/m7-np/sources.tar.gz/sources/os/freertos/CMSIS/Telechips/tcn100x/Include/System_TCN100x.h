// SPDX-License-Identifier: MIT
/*
 * Copyright (C) Telechips Inc.
 */


#ifndef __SYSTEM_TCN100X_H
#define __SYSTEM_TCN100X_H

#include <stdint.h>

#define VERSION_BUILD_ID_SIZE	16 /* in byte */

extern char VersionBuildInfo[];
extern char VersionBuildID[];
extern char VersionBuildTime[];

extern uint32_t ulVersionMajor;
extern uint32_t ulVersionMinor;
extern uint32_t ulVersionPatch;

extern uint32_t EmmcSrcClk;

/**
 * Initialize the system
 *
 * @param  none
 * @return none
 *
 * @brief  Setup the microcontroller system.
 *         Initialize the System.
 */
extern void SystemInit (void);

/**
 * Update SystemCoreClock variable
 *
 * @param  none
 * @return none
 *
 * @brief  Updates the SystemCoreClock with current core Clock
 *         retrieved from cpu registers.
 */
extern void SystemCoreClockUpdate (void);

/**
 * Update MEMBUS byte access mask registers
 *
 * @param  none
 * @return none
 *
 * @brief  Update MEMBUS byte access mask registers
 */
extern void SystemByteMaskSetup(void);

/**
 * Update boot-time stamps to reserved sram
 *
 * @param  none
 * @return none
 *
 * @brief  Update boot-time stamps to reserved sram
 */
extern void SystemAddBootStamp(uint32_t ulIndex);

/**
 * Update PMU access control register configurations
 *
 * @param  none
 * @return none
 *
 * @brief  Update PMU access control register configurations
 */
extern void SystemAccessCtrlSetup(void);

/**
 * Update reset mask configurations
 *
 * @param  none
 * @return none
 *
 * @brief  Update reset mask configurations
 */
extern void SystemResetMaskSetup(void);

/**
 * Update reset status configurations
 *
 * @param  none
 * @return none
 *
 * @brief  Update reset mask configurations
 */
extern void SystemResetStatusSetup(void);

/**
 * Initialize PMU user status register
 *
 * @param  none
 * @return none
 *
 * @brief  Initialize PMU user status register
 */
extern void SystemPMUUserStatSetup(void);

/*
 * mandatory clock parameters **************************************************
 */

#define CLOCK_XIN			24000000
#define CLOCK_DEF_PLL		2600000000 /* PLL: 2.6GHz (same as chipboot) */
#define CLOCK_DEF_PLL_DIV0	325000000 /* PLL_DIV0 : 325MHz (for STRBUS) */
#define CLOCK_DEF_PLL_DIV1	200000000 /* PLL_DIV1 : 200MHz (for SDMMC) */
#define CLOCK_DEF_PLL_DIV2	162500000 /* PLL_DIV2 : 162.5MHz (for UFS) */
#define CLOCK_DEF_PLL_DIV3	26000000 /* PLL_DIV3 : 26MHz (for UFS) */
#define BL0_CPU_CLOCK		600000000 /* 600MHz */


/*
 * boot time stamp parameters **************************************************
 */

#define BOOT_TIME_RESERVED_NUM			8
#define BOOT_TIME_MAX_NUM				128
#define BOOT_TIME_MAX_INDEX				(BOOT_TIME_MAX_NUM - 1)

#define BOOT_TIME_IDX_SET_SC_READY		9
#define BOOT_TIME_IDX_RCV_CA72_BL1_REQ	10
#define BOOT_TIME_IDX_RCV_CA72_BL1_CMPL	11
#define BOOT_TIME_IDX_RCV_CA53_BL1_REQ	12
#define BOOT_TIME_IDX_RCV_CA53_BL1_CMPL	13


/*
 * MMC operation Mode **************************************************
 */
/* define MMC_SUPPORT_INT_MODE */

#endif
