/*
***************************************************************************************************
*
*   FileName : pdm.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_PDM_HEADER
#define SIC_BSP_PDM_HEADER

/****************************************************************************************************
*                                             INCLUDE FILES
****************************************************************************************************/
#include "clock.h"
#include "clock_dev.h"
#include "pdm_reg.h"

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/

#if (DEBUG_ENABLE)
    #include "debug.h"

    #define PDM_D(fmt, args...)         {LOGD(DBG_TAG_PDM, fmt, ## args)}
    #define PDM_Err(fmt, args...)       {LOGE(DBG_TAG_PDM, fmt, ## args)}
#else
    #define PDM_D(fmt, args...)
    #define PDM_Err(fmt, args...)
#endif

#if 1
#define PDM_SAFETY_CONFIG_ENABLE
#define PDM_TIMEOUT                     (10000U)
#endif

#define PDM_ON                          (1UL)
#define PDM_OFF                         (0UL)

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/

void PDM_Init
(
    void
);

void PDM_Deinit
(
    void
);

SALRetCode_t PDM_SetOutputToIdle
(
    uint32                              uiChannel
);

SALRetCode_t PDM_ChannelEnable
(
    uint32                              uiChannel
);

SALRetCode_t PDM_ChannelDisable
(
    uint32                              uiChannel
);

SALRetCode_t PDM_Config
(
    PDMChannelConfig_t *                pChannelConfig
);

SALRetCode_t PDM_Enable
(
    PDMChannelConfig_t *                pChannelConfig

);

SALRetCode_t PDM_Disable
(
    uint32                              uiChannel
);

#endif  // SIC_BSP_PDM_HEADER

