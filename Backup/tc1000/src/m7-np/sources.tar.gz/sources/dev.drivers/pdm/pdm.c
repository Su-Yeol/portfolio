/*
***************************************************************************************************
*
*   FileName : pdm.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#if ( SIC_BSP_SUPPORT_DRIVER_PDM == 1 )

#include "bsp.h"
#include "gpio.h"
#include "pdm.h"

/*
***************************************************************************************************
*                                         LOCAL VARIABLES
***************************************************************************************************
*/

static PDMChannelDescriptor_t           sPDMDescriptor[PDM_TOTAL_CHANNELS];
extern PDMPortConfig_t                  sPdmPort[PDM_TOTAL_CHANNELS];
extern PDMRegister_t *                  sPdmRegisterMap;


/*
***************************************************************************************************
*                                       INTERNAL FUNCTION
***************************************************************************************************
*/

static void PDM_Delay1u
(
    uint32                              uiTime
)
{
    uint32 uiDelayCnt = 0;

    for (uiDelayCnt = 0; uiDelayCnt < uiTime; uiDelayCnt++)
    {
         BSP_NOP_DELAY();
    }
}

static void PDM_EnableClock
(
    void
)
{
    (void)CLOCK_SetPeriRate((sint32)CLOCK_PERI_PDM, PDM_PERI_CLOCK);
    (void)CLOCK_EnablePeri((sint32)CLOCK_PERI_PDM);

    PDM_D("\n PDM peri clk >> %dHz \n", CLOCK_GetPeriRate((sint32)CLOCK_PERI_PDM));
}

static void PDM_DisableClock
(
    void
)
{
    (void)CLOCK_DisablePeri((sint32)CLOCK_PERI_PDM);
}

static void PDM_InitDescriptor
(
    uint32                              uiChannel
)
{
    /* Initialize pdm descriptor */
    sPDMDescriptor[uiChannel].chChannelId                       = uiChannel;
    sPDMDescriptor[uiChannel].chEnable                          = PDM_OFF;
    sPDMDescriptor[uiChannel].chPortIdx                         = 0UL;
    sPDMDescriptor[uiChannel].chOperationMode                   = PDM_MODE_PHASE1;

    sPDMDescriptor[uiChannel].chPeriod1Tick                     = 0UL;
    sPDMDescriptor[uiChannel].chDuty1Tick                       = 0UL;
    sPDMDescriptor[uiChannel].chPeriod2Tick                     = 0UL;
    sPDMDescriptor[uiChannel].chDuty2Tick                       = 0UL;

    sPDMDescriptor[uiChannel].chIdlePolarity                    = PDM_IDLE_LOW;
    sPDMDescriptor[uiChannel].chPolarity                        = PDM_POL_LOW;

    /* Initialize user configuration parameter */
    sPDMDescriptor[uiChannel].chChannelCfgInfo.ccChannelId      = uiChannel;
    sPDMDescriptor[uiChannel].chChannelCfgInfo.ccPortIdx        = 0UL;
    sPDMDescriptor[uiChannel].chChannelCfgInfo.ccOperationMode  = PDM_MODE_PHASE1;

    sPDMDescriptor[uiChannel].chChannelCfgInfo.ccDutyCycle1     = 0UL;
    sPDMDescriptor[uiChannel].chChannelCfgInfo.ccPeriod1        = 0UL;
    sPDMDescriptor[uiChannel].chChannelCfgInfo.ccDutyCycle2     = 0UL;
    sPDMDescriptor[uiChannel].chChannelCfgInfo.ccPeriod2        = 0UL;

    sPDMDescriptor[uiChannel].chChannelCfgInfo.ccOutputPattern1 = 0UL;
    sPDMDescriptor[uiChannel].chChannelCfgInfo.ccOutputPattern2 = 0UL;
    sPDMDescriptor[uiChannel].chChannelCfgInfo.ccOutputPattern3 = 0UL;
    sPDMDescriptor[uiChannel].chChannelCfgInfo.ccOutputPattern4 = 0UL;
    sPDMDescriptor[uiChannel].chChannelCfgInfo.ccMaxCount       = 0UL;

    sPDMDescriptor[uiChannel].chChannelCfgInfo.ccLoopCount      = 0UL;
    sPDMDescriptor[uiChannel].chChannelCfgInfo.ccChannelDivider = PDM_CH_DIV_2;
    sPDMDescriptor[uiChannel].chChannelCfgInfo.ccIdlePolarity   = PDM_IDLE_LOW;
    sPDMDescriptor[uiChannel].chChannelCfgInfo.ccPolarity       = PDM_POL_LOW;
}

static uint32 PDM_GetChannelStatus
(
    uint32                              uiChannel
)
{
    uint32  stVal   = 0;
    uint32  ret     = PDM_REG_MAX_VALUE;

    if(uiChannel < PDM_TOTAL_CHANNELS)
    {
        stVal = sPdmRegisterMap->rPdmSt & PDM_ST_BUSY(uiChannel);
        ret = ((stVal >> uiChannel) & 0x01UL);
    }

    return ret;
}

static void PDM_CalPeriodAndDutyTick
(
    uint32                              uiChannel,
    PDMPhaseWaveform_t                  uiWaveform
)
{
    uint32  clockFreq;
    uint32  period;
    uint16  dutyCycle;
    uint32  actPeriod;
    uint32  actDuty;
    uint32  actDutyCycle;
    uint32  actDutyCycleCorrection;

    /* Divide Clock by the configured divder, 0 means divided by 2 */
    clockFreq = PDM_PERI_CLOCK >> (sPDMDescriptor[uiChannel].chChannelCfgInfo.ccChannelDivider + 1U);

    if(uiWaveform == PDM_PHASE_WAVEFORM_1)
    {
        dutyCycle   = sPDMDescriptor[uiChannel].chChannelCfgInfo.ccDutyCycle1;
        period      = sPDMDescriptor[uiChannel].chChannelCfgInfo.ccPeriod1;
    }
    else
    {
        dutyCycle   = sPDMDescriptor[uiChannel].chChannelCfgInfo.ccDutyCycle2;
        period      = sPDMDescriptor[uiChannel].chChannelCfgInfo.ccPeriod2;
    }

    /* Actual Period ticks = period / clockTns */
    if((period % (PDM_ONE_SECOND_TO_NANO / clockFreq)) != 0UL)
    {
        PDM_D("There is difference in calculation. It may affect the output pulse\n");
    }

    actPeriod = period / (PDM_ONE_SECOND_TO_NANO / clockFreq);

    /*
       If the period is set to zero the setting of the duty-cycle is not relevant.
       In this case the output shall be zero (zero percent duty-cycle).
    */
    if(actPeriod == 0U)
    {
        actDuty = 0U;
    }
    else
    {
        /*
           [Act Duty Cnt] : [ActPeriod] == [100 times of Req Duty percent] : [100 times of Max percent]
           [Act Duty Cnt] = [period] / [10000] * [100 times of Req Duty percent]

           (Divid first to prevent 32bit overflow)
        */
        actDutyCycle = (actPeriod / 10000UL) * dutyCycle;

        /*
           (Multiply first with remainder to saveing loss value divided by 100 times of the percent)
        */
        actDutyCycleCorrection = ((actPeriod % 10000UL) * dutyCycle) / 10000UL;

        /*
            All time units used within the API services of the PDM module shall be
            of the unit ticks.
        */
        actDuty = actDutyCycle + actDutyCycleCorrection;

        if(actPeriod < actDuty)
        {
            actDuty = 0U;
        }
    }

    /* Save the Period and Duty of PDM */
    if(uiWaveform == PDM_PHASE_WAVEFORM_1)
    {
        sPDMDescriptor[uiChannel].chPeriod1Tick = actPeriod;
        sPDMDescriptor[uiChannel].chDuty1Tick   = actDuty;
    }
    else
    {
        sPDMDescriptor[uiChannel].chPeriod2Tick = actPeriod;
        sPDMDescriptor[uiChannel].chDuty2Tick   = actDuty;
    }
}

static SALRetCode_t PDM_SetPhaseMode1
(
    uint32                              uiChannel
)
{
    uint32          pdmModeVal;
    uint32          pdmLoopVal;
    uint32          setVal1;
    uint32          unSetVal1;

    SALRetCode_t    ret = SAL_RET_SUCCESS;

    if(sPDMDescriptor[uiChannel].chChannelCfgInfo.ccPeriod1 == 0UL)
    {
       PDM_Err("Invalid period. Check the configuration \n");
       ret = SAL_RET_FAILED;
    }
    else if(sPDMDescriptor[uiChannel].chChannelCfgInfo.ccDutyCycle1 > PDM_DUTY_CYCLE_MAX_VALUE)
    {
        PDM_Err("Invalid duty cycle. Check the configuration \n");
        ret = SAL_RET_FAILED;
    }
    else
    {
        /* Set operation mode */
        pdmModeVal = sPdmRegisterMap->rPdmMode;
        pdmModeVal &= ~PDM_MODE_MASK(uiChannel);
        pdmModeVal |= PDM_MODE(uiChannel, PDM_MODE_PHASE1);

        /* Set PDM channel clock divider */
        pdmModeVal &= ~PDM_MODE_DIV_MASK(uiChannel);
        pdmModeVal |= PDM_MODE_DIV(uiChannel, sPDMDescriptor[uiChannel].chChannelCfgInfo.ccChannelDivider);

        sPdmRegisterMap->rPdmMode = pdmModeVal;

        /* Set loop count */
        pdmLoopVal = sPdmRegisterMap->rPdmLoop;
        pdmLoopVal &= ~PDM_LOOP_MASK(uiChannel);
        pdmLoopVal |= sPDMDescriptor[uiChannel].chChannelCfgInfo.ccLoopCount;

        sPdmRegisterMap->rPdmLoop = pdmLoopVal;

        /* Calculate PDM period and duty tick */
        PDM_CalPeriodAndDutyTick(uiChannel, PDM_PHASE_WAVEFORM_1);

        if(sPDMDescriptor[uiChannel].chDuty1Tick == 0UL)
        {
            setVal1 = 0UL;
            unSetVal1 = 0UL;
        }
        else
        {
            setVal1 = sPDMDescriptor[uiChannel].chDuty1Tick;
            unSetVal1 = sPDMDescriptor[uiChannel].chPeriod1Tick - sPDMDescriptor[uiChannel].chDuty1Tick;
        }

        /* Convert the PDM DutyCycle Value to valid register value */
        if(sPDMDescriptor[uiChannel].chPeriod1Tick == 0U)
        {
            /* Set the Idle state to Low Level due to 0 ActDutyCycle */
            sPdmRegisterMap->rPdmMode &= ~PDM_MODE_IDLE_OUT(uiChannel);

            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn1 = PDM_OUTPUT_PATTERN_LOW;
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn2 = PDM_OUTPUT_PATTERN_HIGH;
        }
        else if(setVal1 < PDM_HW_LIMIT_VALUE_2) /*The minimal pstn is 2*/
        {
            if (PDM_POL_LOW == sPDMDescriptor[uiChannel].chPolarity)
            {
                /* Set the Idle state to High Level due to 0 ActDutyCycle */
                sPdmRegisterMap->rPdmMode |= PDM_MODE_IDLE_OUT(uiChannel);
            }
            else
            {
                /* Set the Idle state to Low Level due to 0 ActDutyCycle */
                sPdmRegisterMap->rPdmMode &= ~PDM_MODE_IDLE_OUT(uiChannel);
            }

            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn1 = PDM_OUTPUT_PATTERN_LOW;
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn2 = PDM_OUTPUT_PATTERN_HIGH;
        }
        else if(unSetVal1 < PDM_HW_LIMIT_VALUE_2) /*The minimal pstn is 2*/
        {
            if (PDM_POL_LOW == sPDMDescriptor[uiChannel].chPolarity)
            {
                /* Set the Idle state to Low Level due to 100U ActDutyCycle */
                sPdmRegisterMap->rPdmMode &= ~PDM_MODE_IDLE_OUT(uiChannel);
            }
            else
            {
                /* Set the Idle state to High Level due to 100U ActDutyCycle */
                sPdmRegisterMap->rPdmMode |= PDM_MODE_IDLE_OUT(uiChannel);
            }

            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn1 = PDM_OUTPUT_PATTERN_HIGH;
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn2 = PDM_OUTPUT_PATTERN_LOW;
        }
        else
        {
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn1 = setVal1 - PDM_HW_LIMIT_VALUE_2;
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn2 = unSetVal1 - PDM_HW_LIMIT_VALUE_2;

            if (PDM_POL_HIGH == sPDMDescriptor[uiChannel].chPolarity)
            {
                sPdmRegisterMap->rPdmMode |= PDM_MODE_INV(uiChannel);
            }
            else
            {
                sPdmRegisterMap->rPdmMode &= ~PDM_MODE_INV(uiChannel);
            }
        }

        sPdmRegisterMap->rPdmPstn[uiChannel].pPstn3 = 0U;   // Reset pstn3 (Not used in Phase mode 1)
        sPdmRegisterMap->rPdmPstn[uiChannel].pPstn4 = 0U;   // Reset pstn4 (Not used in Phase mode 1)
    }

    return ret;
}

static SALRetCode_t PDM_SetPhaseMode2
(
    uint32                              uiChannel
)
{
    uint32          pdmModeVal;
    uint32          pdmLoopVal;
    uint32          setVal1;
    uint32          unSetVal1;
    uint32          setVal2;
    uint32          unSetVal2;

    SALRetCode_t    ret = SAL_RET_SUCCESS;

    if(sPDMDescriptor[uiChannel].chChannelCfgInfo.ccPeriod1 == 0UL)
    {
       PDM_Err("Invalid period 1. Check the configuration \n");
       ret = SAL_RET_FAILED;
    }
    else if(sPDMDescriptor[uiChannel].chChannelCfgInfo.ccPeriod2 == 0UL)
    {
       PDM_Err("Invalid period 2. Check the configuration \n");
       ret = SAL_RET_FAILED;
    }
    else if(sPDMDescriptor[uiChannel].chChannelCfgInfo.ccDutyCycle1 > PDM_DUTY_CYCLE_MAX_VALUE)
    {
        PDM_Err("Invalid duty cycle 1. Check the configuration \n");
        ret = SAL_RET_FAILED;
    }
    else if(sPDMDescriptor[uiChannel].chChannelCfgInfo.ccDutyCycle2 > PDM_DUTY_CYCLE_MAX_VALUE)
    {
        PDM_Err("Invalid duty cycle 2. Check the configuration \n");
        ret = SAL_RET_FAILED;
    }
    else
    {
        /* Set operation mode */
        pdmModeVal = sPdmRegisterMap->rPdmMode;
        pdmModeVal &= ~PDM_MODE_MASK(uiChannel);
        pdmModeVal |= PDM_MODE(uiChannel, PDM_MODE_PHASE2);

        /* Set PDM channel clock divider */
        pdmModeVal &= ~PDM_MODE_DIV_MASK(uiChannel);
        pdmModeVal |= PDM_MODE_DIV(uiChannel, sPDMDescriptor[uiChannel].chChannelCfgInfo.ccChannelDivider);

        sPdmRegisterMap->rPdmMode = pdmModeVal;

        /* Set loop count */
        pdmLoopVal = sPdmRegisterMap->rPdmLoop;
        pdmLoopVal &= ~PDM_LOOP_MASK(uiChannel);
        pdmLoopVal |= sPDMDescriptor[uiChannel].chChannelCfgInfo.ccLoopCount;

        sPdmRegisterMap->rPdmLoop = pdmLoopVal;

        /* Calculate PDM period and duty tick */
        PDM_CalPeriodAndDutyTick(uiChannel, PDM_PHASE_WAVEFORM_1);
        PDM_CalPeriodAndDutyTick(uiChannel, PDM_PHASE_WAVEFORM_2);

        /* Phase mode 2 Pulse 1 */
        if(sPDMDescriptor[uiChannel].chDuty1Tick == 0UL)
        {
            setVal1 = 0UL;
            unSetVal1 = 0UL;
        }
        else
        {
            setVal1 = sPDMDescriptor[uiChannel].chDuty1Tick;
            unSetVal1 = sPDMDescriptor[uiChannel].chPeriod1Tick - sPDMDescriptor[uiChannel].chDuty1Tick;
        }

        /* Phase mode 2 Pulse 2 */
        if(sPDMDescriptor[uiChannel].chDuty2Tick == 0UL)
        {
            setVal2 = 0UL;
            unSetVal2 = 0UL;
        }
        else
        {
            setVal2 = sPDMDescriptor[uiChannel].chDuty2Tick;
            unSetVal2 = sPDMDescriptor[uiChannel].chPeriod2Tick - sPDMDescriptor[uiChannel].chDuty2Tick;
        }

        /* Convert the PDM DutyCycle Value to valid register value */
        if((sPDMDescriptor[uiChannel].chPeriod1Tick == 0U) && (sPDMDescriptor[uiChannel].chPeriod2Tick == 0U))
        {
            /* Set the Idle state to Low Level due to 0 ActDutyCycle */
            sPdmRegisterMap->rPdmMode &= ~PDM_MODE_IDLE_OUT(uiChannel);

            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn1 = PDM_OUTPUT_PATTERN_LOW;
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn2 = PDM_OUTPUT_PATTERN_HIGH;
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn3 = PDM_OUTPUT_PATTERN_LOW;
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn4 = PDM_OUTPUT_PATTERN_HIGH;
        }
        else if((setVal1 < PDM_HW_LIMIT_VALUE_2) || (setVal2 < PDM_HW_LIMIT_VALUE_2)) /*The minimal pstn is 2*/
        {
            if (PDM_POL_LOW == sPDMDescriptor[uiChannel].chPolarity)
            {
                /* Set the Idle state to High Level due to 0 ActDutyCycle */
                sPdmRegisterMap->rPdmMode |= PDM_MODE_IDLE_OUT(uiChannel);
            }
            else
            {
                /* Set the Idle state to Low Level due to 0 ActDutyCycle */
                sPdmRegisterMap->rPdmMode &= ~PDM_MODE_IDLE_OUT(uiChannel);
            }

            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn1 = PDM_OUTPUT_PATTERN_LOW;
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn2 = PDM_OUTPUT_PATTERN_HIGH;
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn3 = PDM_OUTPUT_PATTERN_LOW;
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn4 = PDM_OUTPUT_PATTERN_HIGH;
        }
        else if((unSetVal1 < PDM_HW_LIMIT_VALUE_2) || (unSetVal2 < PDM_HW_LIMIT_VALUE_2)) /*The minimal pstn is 2*/
        {
            if (PDM_POL_LOW == sPDMDescriptor[uiChannel].chPolarity)
            {
                /* Set the Idle state to Low Level due to 100U ActDutyCycle */
                sPdmRegisterMap->rPdmMode &= ~PDM_MODE_IDLE_OUT(uiChannel);
            }
            else
            {
                /* Set the Idle state to High Level due to 100U ActDutyCycle */
                sPdmRegisterMap->rPdmMode |= PDM_MODE_IDLE_OUT(uiChannel);
            }

            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn1 = PDM_OUTPUT_PATTERN_HIGH;
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn2 = PDM_OUTPUT_PATTERN_LOW;
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn3 = PDM_OUTPUT_PATTERN_HIGH;
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn4 = PDM_OUTPUT_PATTERN_LOW;
        }
        else
        {
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn1 = setVal1 - PDM_HW_LIMIT_VALUE_2;
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn2 = unSetVal1 - PDM_HW_LIMIT_VALUE_2;
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn3 = setVal2 - PDM_HW_LIMIT_VALUE_2;
            sPdmRegisterMap->rPdmPstn[uiChannel].pPstn4 = unSetVal2 - PDM_HW_LIMIT_VALUE_2;

            if (PDM_POL_HIGH == sPDMDescriptor[uiChannel].chPolarity)
            {
                sPdmRegisterMap->rPdmMode |= PDM_MODE_INV(uiChannel);
            }
            else
            {
                sPdmRegisterMap->rPdmMode &= ~PDM_MODE_INV(uiChannel);
            }
        }
    }

    return ret;
}

static SALRetCode_t PDM_SetRegisterMode
(
    uint32                              uiChannel
)
{
    uint32          opMode;
    uint32          pdmModeVal;
    uint32          pdmLoopVal;
    SALRetCode_t    ret = SAL_RET_SUCCESS;

    opMode = sPDMDescriptor[uiChannel].chOperationMode;

    /* Set operation mode */
    pdmModeVal = sPdmRegisterMap->rPdmMode;
    pdmModeVal &= ~PDM_MODE_MASK(uiChannel);
    pdmModeVal |= PDM_MODE(uiChannel, opMode);

    /* Set PDM channel clock divider */
    pdmModeVal &= ~PDM_MODE_DIV_MASK(uiChannel);
    pdmModeVal |= PDM_MODE_DIV(uiChannel, sPDMDescriptor[uiChannel].chChannelCfgInfo.ccChannelDivider);

    sPdmRegisterMap->rPdmMode = pdmModeVal;

    /* Set loop count */
    pdmLoopVal = sPdmRegisterMap->rPdmLoop;
    pdmLoopVal &= ~PDM_LOOP_MASK(uiChannel);
    pdmLoopVal |= sPDMDescriptor[uiChannel].chChannelCfgInfo.ccLoopCount;

    sPdmRegisterMap->rPdmLoop = pdmLoopVal;

    switch(opMode)
    {
        case PDM_MODE_REGISTEROUT1:
        {
            sPdmRegisterMap->rPdmOutReg[uiChannel].opOutReg1    = sPDMDescriptor[uiChannel].chChannelCfgInfo.ccOutputPattern1;
            sPdmRegisterMap->rPdmOutReg[uiChannel].opOutReg2    = 0U;
            sPdmRegisterMap->rPdmOutReg[uiChannel].opOutReg3    = 0U;
            sPdmRegisterMap->rPdmOutReg[uiChannel].opOutReg4    = 0U;
            sPdmRegisterMap->rPdmCntMax                         = 0U;   // Reset Max Count (Not used in Register out mode 1)

            break;
        }
        case PDM_MODE_REGISTEROUT2:
        {
            sPdmRegisterMap->rPdmOutReg[uiChannel].opOutReg1    = sPDMDescriptor[uiChannel].chChannelCfgInfo.ccOutputPattern1;
            sPdmRegisterMap->rPdmOutReg[uiChannel].opOutReg2    = sPDMDescriptor[uiChannel].chChannelCfgInfo.ccOutputPattern2;
            sPdmRegisterMap->rPdmOutReg[uiChannel].opOutReg3    = sPDMDescriptor[uiChannel].chChannelCfgInfo.ccOutputPattern3;
            sPdmRegisterMap->rPdmOutReg[uiChannel].opOutReg4    = sPDMDescriptor[uiChannel].chChannelCfgInfo.ccOutputPattern4;
            sPdmRegisterMap->rPdmCntMax                         = 0U;   // Reset Max Count (Not used in Register out mode 2)

            break;
        }
        case PDM_MODE_REGISTEROUT3:
        {
            sPdmRegisterMap->rPdmOutReg[uiChannel].opOutReg1    = sPDMDescriptor[uiChannel].chChannelCfgInfo.ccOutputPattern1;
            sPdmRegisterMap->rPdmOutReg[uiChannel].opOutReg2    = sPDMDescriptor[uiChannel].chChannelCfgInfo.ccOutputPattern2;
            sPdmRegisterMap->rPdmOutReg[uiChannel].opOutReg3    = sPDMDescriptor[uiChannel].chChannelCfgInfo.ccOutputPattern3;
            sPdmRegisterMap->rPdmOutReg[uiChannel].opOutReg4    = sPDMDescriptor[uiChannel].chChannelCfgInfo.ccOutputPattern4;

            if(sPDMDescriptor[uiChannel].chChannelCfgInfo.ccMaxCount > PDM_MAX_CNT_MAX)
            {
                PDM_D("Invaild MaxCount value. Set MaxCount to '127' (Range of MaxCnt value: 1 to 127)\n");
                sPdmRegisterMap->rPdmCntMax                     = PDM_MAX_CNT_MAX;
            }
            else
            {
                sPdmRegisterMap->rPdmCntMax                     = sPDMDescriptor[uiChannel].chChannelCfgInfo.ccMaxCount;
            }

            break;
        }
        default:
        {
            PDM_Err("Invalid operation mode \n");
            ret = SAL_RET_FAILED;
            break;
        }
    }

    if(ret == SAL_RET_SUCCESS)
    {
        if (PDM_POL_HIGH == sPDMDescriptor[uiChannel].chPolarity)
        {
            sPdmRegisterMap->rPdmMode |= PDM_MODE_INV(uiChannel);
        }
        else
        {
            sPdmRegisterMap->rPdmMode &= ~PDM_MODE_INV(uiChannel);
        }
    }

    return ret;
}

static void PDM_SetPort
(
    uint32                              uiChannel,
    uint32                              uiPort
)
{
    (void)GPIO_Config(sPdmPort[uiPort].pcPort, (sPdmPort[uiPort].pcPortFs | GPIO_OUTPUT | GPIO_DS(0x3UL)));
    (void)GPIO_PortSel(GPIO_GPMUX_PDM_0, uiPort);

    sPDMDescriptor[uiChannel].chPortIdx = uiPort;
}

static void PDM_ClearPort
(
    uint32                              uiChannel,
    uint32                              uiPort
)
{
    (void)GPIO_Config(sPdmPort[uiPort].pcPort, GPIO_FUNC(0UL));
    (void)GPIO_PortSel(GPIO_GPMUX_PDM_0, PDM_GPMUX_RESET);

    sPDMDescriptor[uiChannel].chPortIdx = 0U;
}


/*
***************************************************************************************************
*                                       USER API FUNCTION
***************************************************************************************************
*/

/*
***************************************************************************************************
*                                          PDM_Init
*
* Initialize PDM descriptor, enable PDM peripheral clock
*
* @param
* @return
*
* Notes
*
***************************************************************************************************
*/
void PDM_Init
(
    void
)
{
    uint32 channel = 0;

    for(channel = 0UL; channel < PDM_TOTAL_CHANNELS; channel++)
    {
        PDM_InitDescriptor(channel);
    }

    PDM_EnableClock();
}

/*
***************************************************************************************************
*                                          PDM_Deinit
*
* De-Initialize PDM descriptor, disable PDM peripheral clock
*
* @param
* @return
*
* Notes
*
***************************************************************************************************
*/
void PDM_Deinit
(
    void
)
{
    PDM_DisableClock();

    (void)SAL_MemSet(sPDMDescriptor, 0, (sizeof(PDMChannelDescriptor_t) * PDM_TOTAL_CHANNELS));
}

/*
***************************************************************************************************
*                                          PDM_SetOutputToIdle
*
* Set PDM output to idle (Available only Phase Mode 1 & 2)
*
* @param    uiChannel:  channel number PDM_CH_PDM0_A ~ PDM_CH_PDM0_D
* @return   SALRetCode_t
*
* Notes
*
***************************************************************************************************
*/
SALRetCode_t PDM_SetOutputToIdle
(
    uint32                              uiChannel
)
{
    SALRetCode_t ret = SAL_RET_SUCCESS;

    if(uiChannel >= PDM_CH_MAX)
    {
        PDM_Err("Invalid channel number \n");
        ret = SAL_RET_FAILED;
    }
    else if(sPDMDescriptor[uiChannel].chEnable == PDM_OFF)
    {
        PDM_Err("PDM channel is not enabled \n");
        ret = SAL_RET_FAILED;
    }
    else
    {
        if(sPDMDescriptor[uiChannel].chOperationMode == PDM_MODE_PHASE1)
        {
            if(sPDMDescriptor[uiChannel].chIdlePolarity == PDM_IDLE_HIGH)
            {
                /* Set the Idle state to High Level */
                sPdmRegisterMap->rPdmMode |= PDM_MODE_IDLE_OUT(uiChannel);

                sPdmRegisterMap->rPdmPstn[uiChannel].pPstn1 = PDM_OUTPUT_PATTERN_LOW;
                sPdmRegisterMap->rPdmPstn[uiChannel].pPstn2 = PDM_OUTPUT_PATTERN_HIGH;
            }
            else    // sPDMDescriptor[uiChannel].chIdlePolarity == PDM_IDLE_LOW
            {
                /* Set the Idle state to Low Level */
                sPdmRegisterMap->rPdmMode &= ~PDM_MODE_IDLE_OUT(uiChannel);

                sPdmRegisterMap->rPdmPstn[uiChannel].pPstn1 = PDM_OUTPUT_PATTERN_HIGH;
                sPdmRegisterMap->rPdmPstn[uiChannel].pPstn2 = PDM_OUTPUT_PATTERN_LOW;
            }

            /* Enable PDM Channel */
            ret = PDM_ChannelEnable(uiChannel);

        }
        else if(sPDMDescriptor[uiChannel].chOperationMode == PDM_MODE_PHASE2)
        {
            if(sPDMDescriptor[uiChannel].chIdlePolarity == PDM_IDLE_HIGH)
            {
                /* Set the Idle state to High Level */
                sPdmRegisterMap->rPdmMode |= PDM_MODE_IDLE_OUT(uiChannel);

                sPdmRegisterMap->rPdmPstn[uiChannel].pPstn1 = PDM_OUTPUT_PATTERN_HIGH;
                sPdmRegisterMap->rPdmPstn[uiChannel].pPstn2 = PDM_OUTPUT_PATTERN_LOW;
                sPdmRegisterMap->rPdmPstn[uiChannel].pPstn3 = PDM_OUTPUT_PATTERN_HIGH;
                sPdmRegisterMap->rPdmPstn[uiChannel].pPstn4 = PDM_OUTPUT_PATTERN_LOW;
            }
            else    // sPDMDescriptor[uiChannel].chIdlePolarity == PDM_IDLE_LOW
            {
                /* Set the Idle state to Low Level */
                sPdmRegisterMap->rPdmMode &= ~PDM_MODE_IDLE_OUT(uiChannel);

                sPdmRegisterMap->rPdmPstn[uiChannel].pPstn1 = PDM_OUTPUT_PATTERN_LOW;
                sPdmRegisterMap->rPdmPstn[uiChannel].pPstn2 = PDM_OUTPUT_PATTERN_HIGH;
                sPdmRegisterMap->rPdmPstn[uiChannel].pPstn3 = PDM_OUTPUT_PATTERN_LOW;
                sPdmRegisterMap->rPdmPstn[uiChannel].pPstn4 = PDM_OUTPUT_PATTERN_HIGH;
            }

            /* Enable PDM Channel */
            ret = PDM_ChannelEnable(uiChannel);
        }
        else
        {
            PDM_Err("PDM channel IDLE state is available only in Phase mode 1 & 2 \n");
            ret = SAL_RET_FAILED;
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          PDM_ChannelEnable
*
* Enable PDM channel (PdmEn)
*
* @param    uiChannel:      channel number PDM_CH_PDM0_A ~ PDM_CH_PDM0_D.
* @return   SALRetCode_t
*
* Notes
*
***************************************************************************************************
*/
SALRetCode_t PDM_ChannelEnable
(
    uint32                              uiChannel
)
{
    SALRetCode_t ret = SAL_RET_SUCCESS;

    if(uiChannel >= PDM_CH_MAX)
    {
        PDM_Err("Invalid channel number \n");
        ret = SAL_RET_FAILED;
    }
    else
    {
        sPdmRegisterMap->rPdmEn |= PDM_EN_VALUE_UP(uiChannel);

        sPdmRegisterMap->rPdmEn |= PDM_EN(uiChannel);

        /* At least 1 Cycle delay required based on 'Peripheral_Clock/DIV_x' in 7.5.1 PDM Programming Guide */
        PDM_Delay1u(1UL);

        if(PDM_GetChannelStatus(uiChannel) != PDM_ON)
        {
            sPdmRegisterMap->rPdmEn |= PDM_EN_TRIG(uiChannel);
        }

        /* Set PDM Descriptor enable status */
        sPDMDescriptor[uiChannel].chEnable = PDM_ON;
    }

    return ret;
}

/*
***************************************************************************************************
*                                          PDM_ChannelDisable
*
* Disable PDM channel (PdmEn)
*
* @param    uiChannel:      channel number PDM_CH_PDM0_A ~ PDM_CH_PDM0_D
* @return   SALRetCode_t
*
* Notes
*
***************************************************************************************************
*/
SALRetCode_t PDM_ChannelDisable
(
    uint32                              uiChannel
)
{
#ifdef PDM_SAFETY_CONFIG_ENABLE
    uint32          timeout = 0U;
#endif
    SALRetCode_t    ret = SAL_RET_SUCCESS;

    if(uiChannel >= PDM_CH_MAX)
    {
        PDM_Err("Invalid channel number \n");
        ret = SAL_RET_FAILED;
    }
    else
    {
        /* Clear EN bit */
        sPdmRegisterMap->rPdmEn &= ~PDM_EN(uiChannel);

#ifdef PDM_SAFETY_CONFIG_ENABLE
        while(PDM_GetChannelStatus(uiChannel))
        {
            PDM_Delay1u(10U);
            timeout++;
            if(timeout > PDM_TIMEOUT)
            {
                PDM_Err("[%s:%d] ERROR! PDM is not disabled\n", __func__, __LINE__);
                ret = SAL_RET_FAILED;
                break;
            }
        }
#endif

#ifdef PDM_SAFETY_CONFIG_ENABLE
        if(ret == SAL_RET_SUCCESS)
        {
#endif
            /* Set PDM Descriptor enable status */
            sPDMDescriptor[uiChannel].chEnable = PDM_OFF;
#ifdef PDM_SAFETY_CONFIG_ENABLE
        }
#endif
    }

    return ret;
}

/*
***************************************************************************************************
*                                          PDM_Config
*
* Configurate PDM channel
*
* @param    pChannelConfig: pdm channel configuration pointer
* @return   SALRetCode_t
*
* Notes
*
***************************************************************************************************
*/
SALRetCode_t PDM_Config
(
    PDMChannelConfig_t *                pChannelConfig
)
{
    uint32          channel;
    SALRetCode_t    ret = SAL_RET_SUCCESS;

    if(pChannelConfig == (PDMChannelConfig_t *)NULL)
    {
        PDM_Err("Invalid configuration pointer \n");
        ret = SAL_RET_FAILED;
    }
    else if(pChannelConfig->ccChannelId >= PDM_CH_MAX)
    {
        PDM_Err("Invalid channel number \n");
        ret = SAL_RET_FAILED;
    }
#ifdef PDM_SAFETY_CONFIG_ENABLE
    else if(PDM_ON == PDM_GetChannelStatus(pChannelConfig->ccChannelId))
    {
        PDM_Err("A PDM waveform is being output\n");
        ret = SAL_RET_FAILED;
    }
#endif
    else
    {
        if(pChannelConfig->ccLoopCount > PDM_LOOP_MAX)
        {
            PDM_D("Invaild LoopCount value. Set LoopCount to '0' (Infinite)\n");
            pChannelConfig->ccLoopCount = 0UL;
        }

        channel = pChannelConfig->ccChannelId;

        sPDMDescriptor[channel].chChannelId = channel;
        sPDMDescriptor[channel].chOperationMode = pChannelConfig->ccOperationMode;
        sPDMDescriptor[channel].chPolarity = pChannelConfig->ccPolarity;
        SAL_MemCopy(&(sPDMDescriptor[channel].chChannelCfgInfo), pChannelConfig, sizeof(PDMChannelConfig_t));

        switch(sPDMDescriptor[channel].chOperationMode)
        {
            case PDM_MODE_PHASE1:
            {
                sPDMDescriptor[channel].chIdlePolarity = pChannelConfig->ccIdlePolarity;
                ret = PDM_SetPhaseMode1(channel);
                break;
            }
            case PDM_MODE_PHASE2:
            {
                sPDMDescriptor[channel].chIdlePolarity = pChannelConfig->ccIdlePolarity;
                ret = PDM_SetPhaseMode2(channel);
                break;
            }
            case PDM_MODE_REGISTEROUT1:
            case PDM_MODE_REGISTEROUT2:
            case PDM_MODE_REGISTEROUT3:
            {
                ret = PDM_SetRegisterMode(channel);
                break;
            }
            default:
            {
                PDM_Err("Invalid PDM Operation Mode \n");
                ret = SAL_RET_FAILED;
                break;
            }
        }

        if(ret == SAL_RET_SUCCESS)
        {
            /* Enable PDM Channel */
            ret = PDM_ChannelEnable(channel);
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          PDM_Enable
*
* Enable PDM channel and generate output waveform
*
* @param    pChannelConfig: pdm channel configuration pointer
* @return   SALRetCode_t
*
* Notes
*
***************************************************************************************************
*/
SALRetCode_t PDM_Enable
(
    PDMChannelConfig_t *                pChannelConfig

)
{
    SALRetCode_t ret = SAL_RET_SUCCESS;

    if(pChannelConfig == (PDMChannelConfig_t *)NULL)
    {
        PDM_Err("Invalid configuration pointer \n");
        ret = SAL_RET_FAILED;
    }
    else if(pChannelConfig->ccChannelId >= PDM_CH_MAX)
    {
        PDM_Err("Invalid channel number \n");
        ret = SAL_RET_FAILED;
    }
    else if(pChannelConfig->ccPortIdx >= PDM_PORT_MAX)
    {
        PDM_Err("Invalid port index \n");
        ret = SAL_RET_FAILED;
    }
    else if(sPDMDescriptor[pChannelConfig->ccChannelId].chEnable == PDM_ON)
    {
        PDM_Err("PDM channel is already enabled \n");
        ret = SAL_RET_FAILED;
    }
    else
    {
        /* Set PDM port */
        PDM_SetPort(pChannelConfig->ccChannelId, pChannelConfig->ccPortIdx);

        /* Configure PDM channel, generate output waveform */
        ret = PDM_Config(pChannelConfig);
    }

    return ret;
}

/*
***************************************************************************************************
*                                          PDM_Disable
*
* Disable PDM channel
*
* @param    uiChannel:      channel number PDM_CH_PDM0_A ~ PDM_CH_PDM0_D
* @return   SALRetCode_t
*
* Notes
*
***************************************************************************************************
*/
SALRetCode_t PDM_Disable
(
    uint32                              uiChannel
)
{
    SALRetCode_t ret = SAL_RET_SUCCESS;

    if(uiChannel >= PDM_CH_MAX)
    {
        PDM_Err("Invalid channel number \n");
        ret = SAL_RET_FAILED;
    }
    else
    {
        /* PDM channel discriptor */
        (void)PDM_ChannelDisable(uiChannel);

        /* Clear PDM port */
        PDM_ClearPort(uiChannel, sPDMDescriptor[uiChannel].chPortIdx);

        /* Reset PDM descriptor */
        PDM_InitDescriptor(uiChannel);
    }

    return ret;
}

#endif  // ( SIC_BSP_SUPPORT_DRIVER_PDM == 1 )

