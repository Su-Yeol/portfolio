/*
***************************************************************************************************
*
*   FileName : pdm_reg.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_PDM_REG_HEADER
#define SIC_BSP_PDM_REG_HEADER

#include "reg_phys.h"

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/

#define PDM_HW_LIMIT_VALUE_2            (2UL)   /* In PHASE_MODE, output count value : pstnX + '2' */

#define PDM_STATE_BUSY                  (1UL)
#define PDM_STATE_IDLE                  (0UL)

#define PDM_OUTPUT_PATTERN_HIGH         (0xFFFFFFFFUL)
#define PDM_OUTPUT_PATTERN_LOW          (0x00000000UL)

#define PDM_REG_MAX_VALUE               (0xFFFFFFFFUL)
#define PDM_DUTY_CYCLE_MAX_VALUE        (10000UL)

#define PDM_LOOP_MAX                    (0xFUL)
#define PDM_MAX_CNT_MAX                 (0x7FUL)

#define PDM_TOTAL_MODULES               (1UL)
#define PDM_TOTAL_CH_PER_MODULE         (4UL)
#define PDM_TOTAL_CHANNELS              (PDM_TOTAL_MODULES * PDM_TOTAL_CH_PER_MODULE)

#define PDM_CH_MAX                      (4UL)
#define PDM_PORT_MAX                    (69UL)
#define PDM_GPMUX_RESET                 (0x7FUL)

#define PDM_ONE_SECOND_TO_NANO          (1000UL * 1000UL * 1000UL)  /* express 1 second to nano-second */

/* PDM MAX clk 400Mhz */
// 1sec / (2MHz/2div) = 1000 ns = 1ms tick
#define PDM_PERI_CLOCK_2M               (2UL * 1000UL * 1000UL)
// 1sec / (20MHz/2div) = 100 ns tick
#define PDM_PERI_CLOCK_20M              (20UL * 1000UL * 1000UL)
// 1sec / (200MHz/2div) = 10 ns tick
#define PDM_PERI_CLOCK_200M             (200UL * 1000UL * 1000UL)
// 1sec / (400MHz/2div) = 5 ns tick
#define PDM_PERI_CLOCK_400M             (400UL * 1000UL * 1000UL)

#define PDM_PERI_CLOCK                  (PDM_PERI_CLOCK_200M)

/****************************************************************************
 * Define - PDM Register.
****************************************************************************/

#define PDM_BASE_ADDR                   (SIC_BSP_PWM_BASE)

/* PdmSt Register Macros */
#define PDM_ST_BUSY(ch)                 (1U << (ch))
#define PDM_ST_BUSY_A                   (1U << 0U)
#define PDM_ST_BUSY_B                   (1U << 1U)
#define PDM_ST_BUSY_C                   (1U << 2U)
#define PDM_ST_BUSY_D                   (1U << 3U)

/* PdmEn Register Macros */
#define PDM_EN(ch)                      (1U << (ch))
#define PDM_EN_A                        (1U << 0U)
#define PDM_EN_B                        (1U << 1U)
#define PDM_EN_C                        (1U << 2U)
#define PDM_EN_D                        (1U << 3U)

#define PDM_EN_VALUE_UP(ch)             (1U << ((ch) + 4U))
#define PDM_EN_VALUE_UP_A               (1U << 4U)
#define PDM_EN_VALUE_UP_B               (1U << 5U)
#define PDM_EN_VALUE_UP_C               (1U << 6U)
#define PDM_EN_VALUE_UP_D               (1U << 7U)

#define PDM_EN_TRIG(ch)                 (1U << ((ch) + 16U))
#define PDM_EN_TRIG_A                   (1U << 16U)
#define PDM_EN_TRIG_B                   (1U << 17U)
#define PDM_EN_TRIG_C                   (1U << 18U)
#define PDM_EN_TRIG_D                   (1U << 19U)

/* PdmMode Register Macros */
#define PDM_MODE_PHASE1                 (0x01U)
#define PDM_MODE_REGISTEROUT1           (0x02U)
#define PDM_MODE_REGISTEROUT2           (0x04U)
#define PDM_MODE_REGISTEROUT3           (0x06U)
#define PDM_MODE_PHASE2                 (0x09U)

#define PDM_MODE_MASK(ch)               (0x0FU << ((ch) * 4U))
#define PDM_MODE_MASK_A                 (0x0FU << 0U)
#define PDM_MODE_MASK_B                 (0x0FU << 4U)
#define PDM_MODE_MASK_C                 (0x0FU << 8U)
#define PDM_MODE_MASK_D                 (0x0FU << 12U)

#define PDM_MODE(ch,x)                  (((x) << ((ch) * 4U)) & PDM_MODE_MASK(ch))
#define PDM_MODE_A(x)                   (((x) << 0U) & PDM_MODE_MASK_A)
#define PDM_MODE_B(x)                   (((x) << 4U) & PDM_MODE_MASK_B)
#define PDM_MODE_C(x)                   (((x) << 8U) & PDM_MODE_MASK_C)
#define PDM_MODE_D(x)                   (((x) << 12U) & PDM_MODE_MASK_D)

#define PDM_MODE_INV(ch)                (1U << (16U + (ch)))
#define PDM_MODE_INV_A                  (1U << 16U)
#define PDM_MODE_INV_B                  (1U << 17U)
#define PDM_MODE_INV_C                  (1U << 18U)
#define PDM_MODE_INV_D                  (1U << 19U)

#define PDM_MODE_IDLE_OUT(ch)           (1U << (20U + (ch)))
#define PDM_MODE_IDLE_OUT_A             (1U << 20U)
#define PDM_MODE_IDLE_OUT_B             (1U << 21U)
#define PDM_MODE_IDLE_OUT_C             (1U << 22U)
#define PDM_MODE_IDLE_OUT_D             (1U << 23U)

#define PDM_MODE_DIV_MASK(ch)           (0x03U << (24U + (2U * (ch))))
#define PDM_MODE_DIV_MASK_A             (0x03U << 24U)
#define PDM_MODE_DIV_MASK_B             (0x03U << 26U)
#define PDM_MODE_DIV_MASK_C             (0x03U << 28U)
#define PDM_MODE_DIV_MASK_D             (0x03U << 30U)

#define PDM_MODE_DIV(ch,x)              (((x) << (24U + (2U * (ch)))))
#define PDM_MODE_DIV_A(x)               (((x) << 24U) & PDM_MODE_DIV_MASK_A)
#define PDM_MODE_DIV_B(x)               (((x) << 26U) & PDM_MODE_DIV_MASK_B)
#define PDM_MODE_DIV_C(x)               (((x) << 28U) & PDM_MODE_DIV_MASK_C)
#define PDM_MODE_DIV_D(x)               (((x) << 30U) & PDM_MODE_DIV_MASK_D)

/* PdmLoop Register Macros */
#define PDM_LOOP(ch,x)                  ((x) << ((ch) * 4U))

#define PDM_LOOP_MASK(ch)               (0xFU << ((ch) * 4U))
#define PDM_LOOP_MASK_A                 (0xFU << 0U)
#define PDM_LOOP_MASK_B                 (0xFU << 4U)
#define PDM_LOOP_MASK_C                 (0xFU << 8U)
#define PDM_LOOP_MASK_D                 (0xFU << 12U)

/* PdmCntMax Register Macros */
#define PDM_CNT_MAX(ch,x)               ((x) << ((ch) * 8U))

#define PDM_CNT_MAX_MASK(ch)            (0x7FU << ((ch) * 8U))
#define PDM_CNT_MAX_MASK_A              (0x7FU << 0U)
#define PDM_CNT_MAX_MASK_B              (0x7FU << 8U)
#define PDM_CNT_MAX_MASK_C              (0x7FU << 16U)
#define PDM_CNT_MAX_MASK_D              (0x7FU << 24U)


/*
***************************************************************************************************
*                                             ENUMERTAIONS
***************************************************************************************************
*/

/******************************************************************************
 * DataType name:  PDMIdleState_t
 * Description:    Enumeration Data type for PDM idle state
 * Remarks:        Target DataType.
 * Requirements:   None
 ******************************************************************************/

typedef enum PDMIdleState
{
    PDM_IDLE_HIGH                       = 0U,
    PDM_IDLE_LOW
} PDMIdleState_t;

/******************************************************************************
 * DataType name:  PDMPolarity_t
 * Description:    Enumeration Data type for PDM polarity
 * Remarks:        Target DataType.
 * Requirements:   None
 ******************************************************************************/

typedef enum PDMPolarity
{
    PDM_POL_HIGH                        = 0U,
    PDM_POL_LOW
} PDMPolarity_t;

/******************************************************************************
 * DataType name:  PDMChannelDivider_t
 * Description:    Enumeration Data type for PDM channel divider
 * Remarks:        Target DataType.
 * Requirements:   None
 ******************************************************************************/

typedef enum PDMChannelDivider
{
    PDM_CH_DIV_2                        = 0U,
    PDM_CH_DIV_4,
    PDM_CH_DIV_8,
    PDM_CH_DIV_16
} PDMChannelDivider_t;


/******************************************************************************
 * DataType name:  PDMPhaseWaveform_t
 * Description:    Enumeration Data type for PDM phase mode waveform
 * Remarks:        Target DataType.
 * Requirements:   None
 ******************************************************************************/

typedef enum PDMPhaseWaveform
{
    PDM_PHASE_WAVEFORM_1                = 0U,
    PDM_PHASE_WAVEFORM_2
} PDMPhaseWaveform_t;

/******************************************************************************
 * DataType name:
 * Description:    Enumeration for PDM channel hardware ID
 * Remarks:        Target DataType.
 * Requirements:   None
 ******************************************************************************/

enum PDMChannel
{
    PDM_CH_PDM0_A                       = 0U,
    PDM_CH_PDM0_B,
    PDM_CH_PDM0_C,
    PDM_CH_PDM0_D,
};


/*
***************************************************************************************************
*                                             STRUCTURES
***************************************************************************************************
*/

/******************************************************************************
 * DataType name:  PDMPosition_t
 * Description:    Structure for PDM Channel Phase mode Position Registers.
 * Remarks:        Target DataType.
 * Requirements:   None.
 ******************************************************************************/

typedef struct PDMPosition
{
    volatile uint32                     pPstn1;         /* 0x0000 */
    volatile uint32                     pPstn2;         /* 0x0004 */
    volatile uint32                     pPstn3;         /* 0x0008 */
    volatile uint32                     pPstn4;         /* 0x000C */
} PDMPosition_t;

/******************************************************************************
 * DataType name:  PDMOutputPattern_t
 * Description:    Structure for PDM Channel Register out mode Output Pattern Registers.
 * Remarks:        Target DataType.
 * Requirements:   None.
 ******************************************************************************/

typedef struct PDMOutputPattern
{
    volatile uint32                     opOutReg1;      /* 0x0000 */
    volatile uint32                     opOutReg2;      /* 0x0004 */
    volatile uint32                     opOutReg3;      /* 0x0008 */
    volatile uint32                     opOutReg4;      /* 0x000C */
} PDMOutputPattern_t;

/******************************************************************************
 * DataType name:  PDMRegister_t
 * Description:    Structure for Register Map of PDM Module.
 * Remarks:        Target DataType.
 * Requirements:   None.
 ******************************************************************************/

typedef struct PDMRegister
{
    volatile uint32                     rPdmSt;         /* 0x0000 */
    volatile uint32                     rPdmEn;         /* 0x0004 */
    volatile uint32                     rPdmMode;       /* 0x0008 */
    volatile uint32                     rPdmLoop;       /* 0x000c */
    volatile PDMPosition_t              rPdmPstn[4];    /* 0x0010 */
    volatile PDMOutputPattern_t         rPdmOutReg[4];  /* 0x0050 */
    volatile uint32                     rPdmCntMax;     /* 0x0090 */
} PDMRegister_t;

/******************************************************************************
 * DataType name:  PDMPortConfig_t
 * Description:    Structure for PDM Module Port Configuration.
 * Remarks:        Target DataType.
 * Requirements:   None.
 ******************************************************************************/

typedef struct PDMPortConfig
{
    uint32                              pcPortIdx;      /* PDM port index */
    uint32                              pcPort;         /* GPIO index, GPIO_X(a) */
    uint32                              pcPortFs;       /* Port Function Select */
} PDMPortConfig_t;

/******************************************************************************
 * DataType name:  PDMChannelConfig_t
 * Description:    Structure for Pwm channel configuration.
 * Remarks:        Target DataType.
 * Requirements:   None
 ******************************************************************************/

typedef struct PDMChannelConfig
{
    uint32                              ccChannelId;            /* PDM channel hardware ID */
    uint32                              ccPortIdx;              /* PDM channel port index */
    uint32                              ccOperationMode;        /* Operation Mode */

    uint16                              ccDutyCycle1;           /* Duty cycle 1 for Phase mode 1 & 2. 0 means 0.00%, 10000 means 100.00% */
    uint32                              ccPeriod1;              /* Period 1 for Phase mode 1 & 2, in nanosec */
    uint16                              ccDutyCycle2;           /* Duty cycle 2 for Phase mode 2. 0 means 0.00%, 10000 means 100.00% */
    uint32                              ccPeriod2;              /* Period 2 for Phase mode 2, in nanosec */

    uint32                              ccOutputPattern1;       /* Output pattern 1 for Register out mode 1, 2, 3 */
    uint32                              ccOutputPattern2;       /* Output pattern 2 for Register out mode 2, 3 */
    uint32                              ccOutputPattern3;       /* Output pattern 3 for Register out mode 2, 3 */
    uint32                              ccOutputPattern4;       /* Output pattern 4 for Register out mode 2, 3 */
    uint32                              ccMaxCount;             /* Max count for Register out mode 3 */

    uint32                              ccLoopCount;            /* Step repetition value */
    PDMChannelDivider_t                 ccChannelDivider;       /* Channel clock divider */
    PDMIdleState_t                      ccIdlePolarity;         /* Output signal polarity in IDLE state (Available only Phase Mode 1 & 2) */
    PDMPolarity_t                       ccPolarity;             /* PDM channel output polarity at the beginning of the cycle
                                                                   (Output is reversed when the duty count is reached) */
} PDMChannelConfig_t;

/******************************************************************************
 * DataType name:  PDMChannelDescriptor_t
 * Description:    Structure for Pwm channel descriptor
 * Remarks:        Target DataType.
 * Requirements:   None
 ******************************************************************************/

typedef struct PDMChannelDescriptor_t
{
    uint32                              chChannelId;            /* PDM channel hardware ID */
    uint32                              chEnable;               /* Channel output enable */
    uint32                              chPortIdx;              /* PDM channel port index */
    uint32                              chOperationMode;        /* Operation Mode */

    uint32                              chPeriod1Tick;          /* PDM channel period 1 tick */
    uint32                              chDuty1Tick;            /* PDM channel duty 1 tick */
    uint32                              chPeriod2Tick;          /* PDM channel period 2 tick (Phase Mode 2) */
    uint32                              chDuty2Tick;            /* PDM channel duty 2 tick (Phase Mode 2) */

    PDMIdleState_t                      chIdlePolarity;         /* Output signal polarity in IDLE state (Available only Phase Mode 1 & 2) */
    PDMPolarity_t                       chPolarity;             /* PDM channel output polarity at the beginning of the cycle */

    PDMChannelConfig_t                  chChannelCfgInfo;       /* PDM channel configuration info */
} PDMChannelDescriptor_t;

#endif  // SIC_BSP_PDM_REG_HEADER

