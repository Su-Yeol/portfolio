/*
***************************************************************************************************
*
*   FileName : pdm_reg.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#if ( SIC_BSP_SUPPORT_DRIVER_PDM == 1 )

#include "gpio.h"
#include "pdm.h"

volatile PDMRegister_t *    sPdmRegisterMap = (volatile PDMRegister_t *)(PDM_BASE_ADDR);

const PDMPortConfig_t       sPdmPort[PDM_PORT_MAX] =
{
    { 0UL,     GPIO_GPA(15UL),    GPIO_FUNC(7UL) },
    { 1UL,     GPIO_GPA(17UL),    GPIO_FUNC(7UL) },
    { 2UL,     GPIO_GPA(19UL),    GPIO_FUNC(7UL) },

    { 3UL,     GPIO_GPB(15UL),    GPIO_FUNC(7UL) },
    { 4UL,     GPIO_GPB(17UL),    GPIO_FUNC(7UL) },
    { 5UL,     GPIO_GPB(19UL),    GPIO_FUNC(7UL) },

    { 6UL,     GPIO_GPC(15UL),    GPIO_FUNC(7UL) },
    { 7UL,     GPIO_GPC(17UL),    GPIO_FUNC(7UL) },
    { 8UL,     GPIO_GPC(19UL),    GPIO_FUNC(7UL) },

    { 9UL,     GPIO_GPD(15UL),    GPIO_FUNC(7UL) },
    { 10UL,    GPIO_GPD(17UL),    GPIO_FUNC(7UL) },
    { 11UL,    GPIO_GPD(19UL),    GPIO_FUNC(7UL) },

    { 12UL,    GPIO_GPE(0UL),     GPIO_FUNC(7UL) },
    { 13UL,    GPIO_GPE(2UL),     GPIO_FUNC(7UL) },
    { 14UL,    GPIO_GPE(4UL),     GPIO_FUNC(7UL) },
    { 15UL,    GPIO_GPE(6UL),     GPIO_FUNC(7UL) },
    { 16UL,    GPIO_GPE(8UL),     GPIO_FUNC(7UL) },
    { 17UL,    GPIO_GPE(10UL),    GPIO_FUNC(7UL) },
    { 18UL,    GPIO_GPE(12UL),    GPIO_FUNC(7UL) },
    { 19UL,    GPIO_GPE(14UL),    GPIO_FUNC(7UL) },

    { 20UL,    GPIO_GPF(0UL),     GPIO_FUNC(7UL) },
    { 21UL,    GPIO_GPF(2UL),     GPIO_FUNC(7UL) },
    { 22UL,    GPIO_GPF(4UL),     GPIO_FUNC(7UL) },
    { 23UL,    GPIO_GPF(6UL),     GPIO_FUNC(7UL) },
    { 24UL,    GPIO_GPF(8UL),     GPIO_FUNC(7UL) },
    { 25UL,    GPIO_GPF(10UL),    GPIO_FUNC(7UL) },
    { 26UL,    GPIO_GPF(12UL),    GPIO_FUNC(7UL) },
    { 27UL,    GPIO_GPF(14UL),    GPIO_FUNC(7UL) },

    { 28UL,    GPIO_GPG(0UL),     GPIO_FUNC(7UL) },
    { 29UL,    GPIO_GPG(2UL),     GPIO_FUNC(7UL) },
    { 30UL,    GPIO_GPG(4UL),     GPIO_FUNC(7UL) },
    { 31UL,    GPIO_GPG(6UL),     GPIO_FUNC(7UL) },
    { 32UL,    GPIO_GPG(8UL),     GPIO_FUNC(7UL) },
    { 33UL,    GPIO_GPG(10UL),    GPIO_FUNC(7UL) },
    { 34UL,    GPIO_GPG(12UL),    GPIO_FUNC(7UL) },
    { 35UL,    GPIO_GPG(14UL),    GPIO_FUNC(7UL) },

    { 36UL,    GPIO_GPH(0UL),     GPIO_FUNC(7UL) },
    { 37UL,    GPIO_GPH(2UL),     GPIO_FUNC(7UL) },
    { 38UL,    GPIO_GPH(4UL),     GPIO_FUNC(7UL) },
    { 39UL,    GPIO_GPH(6UL),     GPIO_FUNC(7UL) },
    { 40UL,    GPIO_GPH(8UL),     GPIO_FUNC(7UL) },
    { 41UL,    GPIO_GPH(10UL),    GPIO_FUNC(7UL) },
    { 42UL,    GPIO_GPH(12UL),    GPIO_FUNC(7UL) },
    { 43UL,    GPIO_GPH(14UL),    GPIO_FUNC(7UL) },

    { 44UL,    GPIO_GPI(0UL),     GPIO_FUNC(7UL) },
    { 45UL,    GPIO_GPI(2UL),     GPIO_FUNC(7UL) },
    { 46UL,    GPIO_GPI(4UL),     GPIO_FUNC(7UL) },
    { 47UL,    GPIO_GPI(6UL),     GPIO_FUNC(7UL) },
    { 48UL,    GPIO_GPI(8UL),     GPIO_FUNC(7UL) },
    { 49UL,    GPIO_GPI(10UL),    GPIO_FUNC(7UL) },
    { 50UL,    GPIO_GPI(12UL),    GPIO_FUNC(7UL) },
    { 51UL,    GPIO_GPI(14UL),    GPIO_FUNC(7UL) },

    { 52UL,    GPIO_GPJ(0UL),     GPIO_FUNC(7UL) },
    { 53UL,    GPIO_GPJ(2UL),     GPIO_FUNC(7UL) },
    { 54UL,    GPIO_GPJ(4UL),     GPIO_FUNC(7UL) },
    { 55UL,    GPIO_GPJ(6UL),     GPIO_FUNC(7UL) },
    { 56UL,    GPIO_GPJ(8UL),     GPIO_FUNC(7UL) },
    { 57UL,    GPIO_GPJ(10UL),    GPIO_FUNC(7UL) },
    { 58UL,    GPIO_GPJ(12UL),    GPIO_FUNC(7UL) },
    { 59UL,    GPIO_GPJ(14UL),    GPIO_FUNC(7UL) },

    { 60UL,    GPIO_GPL(0UL),     GPIO_FUNC(7UL) },
    { 61UL,    GPIO_GPL(2UL),     GPIO_FUNC(7UL) },
    { 62UL,    GPIO_GPL(4UL),     GPIO_FUNC(7UL) },
    { 63UL,    GPIO_GPL(6UL),     GPIO_FUNC(7UL) },
    { 64UL,    GPIO_GPL(8UL),     GPIO_FUNC(7UL) },
    { 65UL,    GPIO_GPL(10UL),    GPIO_FUNC(7UL) },
    { 66UL,    GPIO_GPL(12UL),    GPIO_FUNC(7UL) },
    { 67UL,    GPIO_GPL(14UL),    GPIO_FUNC(7UL) },
    { 68UL,    GPIO_GPL(16UL),    GPIO_FUNC(7UL) }
};
#endif  // ( SIC_BSP_SUPPORT_DRIVER_PDM == 1 )

