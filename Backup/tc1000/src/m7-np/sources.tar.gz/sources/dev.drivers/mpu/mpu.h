/*
***************************************************************************************************
*
*   FileName : mpu.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_MPU_HEADER
#define SIC_BSP_MPU_HEADER

#include <sal_api.h>

/* Ref to : https://developer.arm.com/documentation/dui0662/b/Cortex-M0--Peripherals/Memory-Protection-Unit?lang=en */
#define MPU_REGION_32B                  (0x00000004U)
#define MPU_REGION_64B                  (0x00000005U)
#define MPU_REGION_128B                 (0x00000006U)
#define MPU_REGION_256B                 (0x00000007U)
#define MPU_REGION_512B                 (0x00000008U)
#define MPU_REGION_1KB                  (0x00000009U)
#define MPU_REGION_2KB                  (0x0000000AU)
#define MPU_REGION_4KB                  (0x0000000BU)
#define MPU_REGION_8KB                  (0x0000000CU)
#define MPU_REGION_16KB                 (0x0000000DU)
#define MPU_REGION_32KB                 (0x0000000EU)
#define MPU_REGION_64KB                 (0x0000000FU)
#define MPU_REGION_128KB                (0x00000010U)
#define MPU_REGION_256KB                (0x00000011U)
#define MPU_REGION_512KB                (0x00000012U)
#define MPU_REGION_1MB                  (0x00000013U)
#define MPU_REGION_2MB                  (0x00000014U)
#define MPU_REGION_4MB                  (0x00000015U)
#define MPU_REGION_8MB                  (0x00000016U)
#define MPU_REGION_16MB                 (0x00000017U)
#define MPU_REGION_32MB                 (0x00000018U)
#define MPU_REGION_64MB                 (0x00000019U)
#define MPU_REGION_128MB                (0x0000001AU)
#define MPU_REGION_256MB                (0x0000001BU)
#define MPU_REGION_512MB                (0x0000001CU)
#define MPU_REGION_1GB                  (0x0000001DU)
#define MPU_REGION_2GB                  (0x0000001EU)
#define MPU_REGION_4GB                  (0x0000001FU)

#define MPU_REGION_EN                   (0x00000001U)
#define MPU_REGION_DISABLE              (0x00000000U)


/* S : Shareable, C : Cacheable, B :  Bufferable */

/* TEX : 0b000 */

/* For Strongly-ordered and Device memory, the S bit is ignored. */
#define MPU_SCB_STRONG_ORDERED_SHARED       (0x00000000U << 16U)           // S=0, C=0, B=0 : strongly ordered, always shareable
#define MPU_SCB_DEVICE_SHARED               (0x00000001U << 16U)           // S=0, C=0, B=1 : device, shareable

#define MPU_SCB_NORM_NSHARED_WT_NWA         (0x00000002U << 16U)           // S=0, C=1, B=0 : Normal, Not shareable, Outer and Inner write-through, no write-allocate.
#define MPU_SCB_NORM_SHARED_WT_NWA          (0x00000006U << 16U)           // S=1, C=1, B=0 : Normal, Shareable, Outer and Inner write-through, no write-allocate.

#define MPU_SCB_NORM_NSHARED_WB_NWA         (0x00000003U << 16U)           // S=0, C=1, B=1 : Normal, Not shareable, Outer and Inner write-back, no write-allocate.
#define MPU_SCB_NORM_SHARED_WB_NWA          (0x00000007U << 16U)           // S=1, C=1, B=1 : Normal, Shareable, Outer and Inner write-back, no write-allocate.

/* TEX : 0b001 */
#define MPU_SCB_NORM_NSHARED_NCACHE         (0x00000008U << 16U)           // S=0, C=0, B=0 : Normal, Not shareable, Outer and inner Non-cacheable.
#define MPU_SCB_NORM_SHARED_NCACHE          (0x0000000CU << 16U)           // S=1, C=0, B=0 : Normal, Shareable, Outer and inner Non-cacheable.

#define MPU_SCB_NORM_NSHARED_WB_WRA         (0x0000000BU << 16U)           // S=0, C=1, B=1 : Normal, Not shareable, Outer and inner Write-Back. Write and read allocate.
#define MPU_SCB_NORM_SHARED_WB_WRA          (0x0000000FU << 16U)           // S=1, C=1, B=1 : Normal, Shareable, OOuter and inner Write-Back. Write and read allocate.

/* AP : Access permission field */
#define MPU_AP_NO_ACCESS                   ( 0x00000000UL << 24U )   // No access
#define MPU_AP_PRIV_RW_USER_NA             ( 0x00000001UL << 24U )   // Privileged access only
#define MPU_AP_PRIV_RW_USER_RO             ( 0x00000002UL << 24U )   // Writes in User mode generate permission faults
#define MPU_AP_PRIV_RW_USER_RW             ( 0x00000003UL << 24U )   // Full Access
#define MPU_AP_PRIV_RO_USER_NA             ( 0x00000005UL << 24U )   // Privileged Read only
#define MPU_AP_PRIV_RO_USER_RO             ( 0x00000006UL << 24U )   // Privileged/User read-only

#define MPU_SRD_ENABLE                  ( 0x00000000UL << 8U )   // Corresponding sub-region is enabled.
#define MPU_SRD_DISABLE                 ( 0x00000001UL << 8U )   // Corresponding sub-region is disabled.

#define MPU_XN_ENABLE                   ( 0x00000000UL << 28U )   // Instruction access enable bit:
#define MPU_XN_DISABLE                  ( 0x00000001UL << 28U )   // Instruction access disable bit:

/* DMA */
extern uint32 __nc_dmastart;
/* CAN */
extern uint32 __nc_dmacanstart;
/* ETH */
extern uint32 __nc_dmaethstart;


typedef struct MPUConfig
{
    uint32                              uiRegionEnable;
    uint32                              uiRegionBase;
    uint32                              uiRegionSize;
    uint32                              uiRegionAttr;
} MPUConfig_t;

/*
***************************************************************************************************
*                                       MPU_Init
*
* Initialize MPU.
*
* @param    none
* @return   void
*
* Notes
*
***************************************************************************************************
*/

void MPU_Init
(
    void
);

/*
***************************************************************************************************
*                                       MPU_GetDMABaseAddress
*
* Registers  functions needed by specific application.
*
* @param    none
* @return   uint32 DMA Base Address.
*
* Notes
*
***************************************************************************************************
*/

uint32 MPU_GetDMABaseAddress
(
    void
);

/*
***************************************************************************************************
*                                       MPU_GetCANMessageRAMAddress
*
* Registers  functions needed by specific application.
*
* @param    none
* @return   uint32 CAN Message RAM Base Address.
*
* Notes
*
***************************************************************************************************
*/

uint32 MPU_GetCANBaseAddress
(
    void
);
uint32 MPU_GetETHBaseAddress
(
    void
);

void MPU_SetRegion
(
    uint32 uiRegionAddr,
    uint32 uiRegionAttr
);

void MPU_DisableRegion
(
    uint32                              uiRegionNumber
);

void MPU_Enable
(
    void
);

void MPU_Disable
(
    void
);

#endif /* __MPU_HEADER__ */

