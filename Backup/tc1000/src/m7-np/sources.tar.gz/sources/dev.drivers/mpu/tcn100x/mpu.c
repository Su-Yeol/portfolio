/*
***************************************************************************************************
*
*   FileName : mpu.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

//#include <cache.h>
#include <bsp.h>
#include <mpu.h>
//#include <reg_phys.h>

#ifdef __MPU_ENABLED__
/* M0P MPU specific constants. */

/* Constants required to access and manipulate the MPU. */
#define MPU_TYPE_REG                        ( * ( ( volatile uint32 * ) 0xe000ed90 ) )
#define MPU_REGION_NUMBER_REG               ( * ( ( volatile uint32 * ) 0xe000ed98 ) )
#define MPU_REGION_BASE_ADDRESS_REG         ( * ( ( volatile uint32 * ) 0xe000ed9C ) )
#define MPU_REGION_ATTRIBUTE_REG            ( * ( ( volatile uint32 * ) 0xe000edA0 ) )
#define MPU_CTRL_REG                        ( * ( ( volatile uint32 * ) 0xe000ed94 ) )

// MPU DEFAULT DEFINES
#if ( CORTEX_M7_NP==1 )
#define MPU_MAX_REGION                    (7U)
#else
#define MPU_MAX_REGION                    (7U)
#endif


// MPU START ADDR
#define MPU_BOOT_ADDR                   (0x00000000U)
#define MPU_MIRRORSRAM_ADDR             (0x00000000U)

#define MPU_SRAM0_0_ADDR                (0x30000000U)
#define MPU_SRAM0_1_ADDR                (0x30080000U)
#define MPU_SRAM1_0_ADDR                (0x30100000U)
#define MPU_SRAM1_1_ADDR                (0x30180000U)
#define MPU_SRAM2_0_ADDR                (0x30200000U)
#define MPU_SRAM2_1_ADDR                (0x30280000U)
#define MPU_SRAM3_0_ADDR                (0x30300000U)
#define MPU_SRAM3_1_ADDR                (0x30380000U)
#define MPU_SRAM4_0_ADDR                (0x30400000U)
#define MPU_SRAM4_1_ADDR                (0x30480000U)
#define MPU_SRAM5_0_ADDR                (0x30500000U)
#define MPU_SRAM5_1_ADDR                (0x30580000U)
#define MPU_SRAM6_0_ADDR                (0x30600000U)
#define MPU_SRAM6_1_ADDR                (0x30680000U)
#define MPU_SRAM7_0_ADDR                (0x30700000U)
#define MPU_SRAM7_1_ADDR                (0x30780000U)

#define MPU_SNOR0_ADDR                  (0x10000000U)
#define MPU_SNOR1_ADDR                  (0x18000000U)

#define MPU_M70_DTCM_ADDR               (0x31000000U)
#define MPU_M71_DTCM_ADDR               (0x32000000U)
#define MPU_M72_DTCM_ADDR               (0x33000000U)
#define MPU_NP_DTCM_ADDR                (0x34000000U)

#define MPU_M70_WRAP_ADDR               (0x41000000U)
#define MPU_M71_WRAP_ADDR               (0x42000000U)
#define MPU_M72_WRAP_ADDR               (0x43000000U)
#define MPU_NP_WRAP_ADDR                (0x47000000U)

#define MPU_CPU_SUBSYS_ADDR             (0x40000000U)
#define MPU_SECU_SUBSYS_ADDR            (0x44000000U)
#define MPU_MEM_SUBSYS_ADDR             (0x45000000U)
#define MPU_NET_SUBSYS_ADDR             (0x46000000U)

#define MPU_HSIO_SUBSYS_ADDR            (0x48000000U)
#define MPU_PCIe_SUBSYS_ADDR            (0x49000000U)
#define MPU_IO_SUBSYS_ADDR              (0x4A000000U)
#define MPU_SYS_SUBSYS_ADDR             (0x4B000000U)
#define MPU_DAP_SUBSYS_ADDR             (0x4E000000U)

#define MPU_SUBSYS_ADDR                 (0x48000000U)
#define MPU_PERI_ADDR                   (0x4A000000U)

#define MPU_IPC_SHM_ADDR          (0x306E0000UL)


/****************************************************************************
*                               USER SETTING
****************************************************************************/

/*** 1. SELECT DMA SIZE - CHOICE ONLY ONE ***/

#define MPU_REGION_DMA                  (MPU_REGION_128KB)   // DMA NC region + ETH desc region + CAN + LPA

#if ( CORTEX_M7_0==1 )
#define MPU_SRAM_END                    (MPU_SRAM2_0_ADDR)
#elif ( CORTEX_M7_1==1 )
#define MPU_SRAM_END                    (MPU_SRAM3_0_ADDR)
#elif ( CORTEX_M7_2==1 )
#define MPU_SRAM_END                    (MPU_SRAM4_0_ADDR)
#elif ( CORTEX_M7_NP==1 )
#define MPU_SRAM_END                    (MPU_SRAM6_0_ADDR)
#endif

#if ( MPU_REGION_DMA == MPU_REGION_4KB )
    #define MPU_DMA_ADDR                (MPU_SRAM_END - 0x1000U)
#elif ( MPU_REGION_DMA == MPU_REGION_8KB )
    #define MPU_DMA_ADDR                (MPU_SRAM_END - 0x2000U)
#elif ( MPU_REGION_DMA == MPU_REGION_16KB )
    #define MPU_DMA_ADDR                (MPU_SRAM_END - 0x4000U)
#elif ( MPU_REGION_DMA == MPU_REGION_32KB )
    #define MPU_DMA_ADDR                (MPU_SRAM_END - 0x8000U)
#elif ( MPU_REGION_DMA == MPU_REGION_64KB )
    #define MPU_DMA_ADDR                (MPU_SRAM_END - 0x10000U)
#elif ( MPU_REGION_DMA == MPU_REGION_128KB )
    #define MPU_DMA_ADDR                (MPU_SRAM_END - 0x20000U)
#endif


/*** 2. SET REGION ATTRIBUTES ***/
static const MPUConfig_t sMPUTable[ MPU_MAX_REGION ] =
{
#if ( CORTEX_M7_NP==0 )
    { MPU_REGION_EN,  MPU_BOOT_ADDR,        MPU_REGION_1MB,     MPU_SCB_NORM_NSHARED_WT_NWA   | MPU_AP_PRIV_RW_USER_RW },
#else
    { MPU_REGION_EN,  MPU_BOOT_ADDR,        MPU_REGION_2MB,     MPU_SCB_NORM_NSHARED_WT_NWA   | MPU_AP_PRIV_RW_USER_RW },
#endif
    { MPU_REGION_EN,  MPU_SNOR1_ADDR,       MPU_REGION_256MB,   MPU_SCB_NORM_NSHARED_WT_NWA   | MPU_AP_PRIV_RW_USER_RW },
#if ( CORTEX_M7_0==1 )
    { MPU_REGION_EN,  MPU_SRAM1_0_ADDR,     MPU_REGION_1MB,     MPU_SCB_NORM_NSHARED_WT_NWA   | MPU_AP_PRIV_RW_USER_RW },
#elif ( CORTEX_M7_1==1 )
    { MPU_REGION_EN,  MPU_SRAM2_0_ADDR,     MPU_REGION_1MB,     MPU_SCB_NORM_SHARED_WB_NWA    | MPU_AP_PRIV_RW_USER_RW },
#elif ( CORTEX_M7_2==1 )
    { MPU_REGION_EN,  MPU_SRAM3_0_ADDR,     MPU_REGION_1MB,     MPU_SCB_NORM_SHARED_WB_NWA    | MPU_AP_PRIV_RW_USER_RW },
#elif ( CORTEX_M7_NP==1 )
    { MPU_REGION_EN,  MPU_SRAM4_0_ADDR,     MPU_REGION_4MB,     MPU_SCB_NORM_SHARED_WB_NWA    | MPU_AP_PRIV_RW_USER_RW },
#endif
    { MPU_REGION_EN,  MPU_IPC_SHM_ADDR,     MPU_REGION_128KB,   MPU_SCB_STRONG_ORDERED_SHARED    | MPU_AP_PRIV_RW_USER_RW },
    { MPU_REGION_EN,  MPU_DMA_ADDR,         MPU_REGION_DMA,     MPU_SCB_STRONG_ORDERED_SHARED | MPU_AP_PRIV_RW_USER_RW },
    /* MPU_CPU_SUBSYS_ADDR + MPU_REGION_128MB : 0x40000000 ~ 0x47FFFFFF */
    { MPU_REGION_EN,  MPU_CPU_SUBSYS_ADDR,  MPU_REGION_128MB,   MPU_SCB_DEVICE_SHARED | MPU_AP_PRIV_RW_USER_RW | MPU_XN_DISABLE },
    /* MPU_HSIO_SUBSYS_ADDR + MPU_REGION_128MB : 0x48000000 ~ 0x4FFFFFFF */
    { MPU_REGION_EN,  MPU_HSIO_SUBSYS_ADDR, MPU_REGION_128MB,   MPU_SCB_DEVICE_SHARED | MPU_AP_PRIV_RW_USER_RW | MPU_XN_DISABLE }
};

static void MPU_EnableRegion
(
    uint32                              uiRegionNumber,
    uint32                              uiAddr,
    uint32                              uiSize,
    uint32                              uiAttr
);

static void MPU_EnableRegion
(
    uint32                              uiRegionNumber,
    uint32                              uiAddr,
    uint32                              uiSize,
    uint32                              uiAttr
)
{
    if ( uiRegionNumber < MPU_MAX_REGION ) //QAC : Dereference of an invalid pointer value of uiRegionNumber
    {
        // Setup procedure for each region
        MPU_REGION_NUMBER_REG  = uiRegionNumber;
        MPU_REGION_BASE_ADDRESS_REG = (uiAddr & 0xFFFFFFE0);// | (uiRegionNumber & 0xF) | 0x10;
        MPU_REGION_ATTRIBUTE_REG = (uiAttr | ((uiSize & 0x1F)<<1) | MPU_REGION_EN);
    }
    else
    {
        // Error Print
    }
}

// Function to disable an unused region
void MPU_DisableRegion
(
    uint32                              uiRegionNumber
)
{
    MPU_REGION_NUMBER_REG    = uiRegionNumber;
    MPU_REGION_ATTRIBUTE_REG = MPU_REGION_DISABLE;
}

void MPU_Init
(
    void
)
{
    uint32      uiIndex;
    for( uiIndex = 0; uiIndex < MPU_MAX_REGION ; uiIndex++ )
    {
        if(sMPUTable[ uiIndex ].uiRegionEnable == MPU_REGION_EN)
        {
            MPU_EnableRegion( uiIndex, sMPUTable[ uiIndex ].uiRegionBase, sMPUTable[ uiIndex ].uiRegionSize, sMPUTable[ uiIndex ].uiRegionAttr);
        }
    }
}

uint32 MPU_GetDMABaseAddress
(
    void
)
{
    uint32  uiStart;

    uiStart  = ( uint32 )( &__nc_dmastart ); // Physical Offset for SRAM for execution zero base

    return uiStart;
}

uint32 MPU_GetCANBaseAddress
(
    void
)
{
    uint32  uiStart;

    uiStart  = ( uint32 )( &__nc_dmacanstart ); // Physical Offset for SRAM for execution zero base

    return uiStart;
}

uint32 MPU_GetETHBaseAddress
(
    void
)
{
    uint32  uiStart;

    uiStart  = ( uint32 )( &__nc_dmaethstart ); // Physical Offset for SRAM for execution zero base

    return uiStart;
}

void MPU_SetRegion
(
    uint32 uiRegionAddr,
    uint32 uiRegionAttr
)
{
    uint32      uiIndex;

    for( uiIndex = 0; uiIndex < MPU_MAX_REGION ; uiIndex++ )
    {
        if(sMPUTable[ uiIndex ].uiRegionBase == uiRegionAddr)
        {
            MPU_EnableRegion( uiIndex, sMPUTable[ uiIndex ].uiRegionBase, sMPUTable[ uiIndex ].uiRegionSize, uiRegionAttr);
        }
    }
}

void MPU_Enable
(
    void
)
{
	/* Enable MPU */
	MPU_CTRL_REG = 0x1;

}

void MPU_Disable
(
    void
)
{
	/* Disable MPU */
	MPU_CTRL_REG = 0x0;
}

#endif

