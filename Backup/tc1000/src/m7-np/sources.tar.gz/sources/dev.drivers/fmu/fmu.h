/*
***************************************************************************************************
*
*   FileName : fmu.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef  SIC_BSP_FMU_DRIVER_HEADER
#define  SIC_BSP_FMU_DRIVER_HEADER

#if ( SIC_BSP_SUPPORT_DRIVER_FMU )

/**************************************************************************************************
*                                           INCLUDE HEADER
***************************************************************************************************/
#include <sal_internal.h>
#include <debug.h>
#include <nvic.h>
#include <bsp.h>
#include <fmu_reg.h>

/**************************************************************************************************
*                                           EXTERNAL FUNCTION
***************************************************************************************************/
#if defined(TCN100x)
/**************************************************************************************************
*                                          NMI_Handler
*
* [TEMPARARY]
*
* @param
* @return
*
* Notes
*
***************************************************************************************************/
/*****************************  TBD: Should be reviewed befor CS **********************************/
/**************************************************************************************************/
void NMI_Handler
(
    void
);
#endif

/**************************************************************************************************
*                                          FMU_GetFaultId
*
* [External] Get the FMU ID according to fault signal type
*
* @param        FmuSignal_t
* @return       FmuId
*
* Notes
*
***************************************************************************************************/
uint32 FMU_GetFaultId
(
    FmuSignal_t                         uiType
);

/**************************************************************************************************
*                                          FMU_WritePassword
*
* [External] Write password
*
* @param
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t FMU_WritePassword
(
    void
);

/**************************************************************************************************
*                                          FMU_IsrHandler
*
* [External] Register the severity level and callback function on FMU vector table
*
* @param        FmuIds_t            FmuLevel_t
*               FmuCallbackFunc     Argument
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t FMU_IsrHandler
(
    FmuIds_t                            uiFmuId,
    FmuLevel_t                          uiFmuLevel,
    FmuCallbackFunc                     cbFunc,
    void *                              pArg
);

/**************************************************************************************************
*                                          FMU_IsrClr
*
* [External] Clear the fault status according to FMU ID
*
* @param        FmuIds_t
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t FMU_IsrClr
(
    FmuIds_t                            uiFmuId
);

/**************************************************************************************************
*                                          FMU_UnSet
*
* [External] Unset the severity level and enable field based on FMU ID
*
* @param        FmuIds_t
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t FMU_UnSet
(
    FmuIds_t                            uiFmuId
);

/**************************************************************************************************
*                                          FMU_Set
*
* [Internal] Set the severity level and enable field based on FMU ID
*
* @param        FmuIds_t
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t FMU_Set
(
    FmuIds_t                            uiFmuId
);

/**************************************************************************************************
*                                          FMU_Deinit
*
* [External] De-initialize the FMU (Disable the interrupt)
*
* @param
* @return
*
* Notes
*
***************************************************************************************************/
void FMU_Deinit
(
    void
);

/**************************************************************************************************
*                                          FMU_Init
*
* [External] Initialize the FMU (Set fault signal, Enable the interrupt)
*
* @param
* @return
*
* Notes
*
***************************************************************************************************/
void FMU_Init
(
    void
);

#endif  /* End of SIC_BSP_SUPPORT_DRIVER_FMU */

#endif  /* End of SIC_BSP_FMU_DRIVER_HEADER */
