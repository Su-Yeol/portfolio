/*
***************************************************************************************************
*
*   FileName : fmu_reg.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef  SIC_BSP_FMU_REGISTER_HEADER
#define  SIC_BSP_FMU_REGISTER_HEADER

#if ( SIC_BSP_SUPPORT_DRIVER_FMU )

/**************************************************************************************************
*                                           DEFINITION
***************************************************************************************************/
#define FMU_ON                          ( 1UL)
#define FMU_OFF                         ( 0UL)

#define FMU_ARRAY_NUM                   ( 6UL)
#define FMU_ARRAY_SLV_NUM               (12UL)

#define FMU_ADDR_BASE                   (0x4B210000UL)
#define FMU_CFG_PW                      (0x5AFEACE5UL)

#define FMU_CFG_F_FAULT                 (1UL <<  0UL)
#define FMU_CFG_SW_RESET                (1UL <<  1UL)
#define FMU_CFG_FINI_EN                 (1UL <<  2UL)
#define FMU_CFG_SF_EN                   (1UL <<  3UL)
#define FMU_CFG_FP_EN                   (1UL <<  4UL)

/* Register value to configure the external fault timing */
#define FMU_CFG_FAULT_POL_LOW           (0UL <<  0UL)
#define FMU_CFG_UFALT_POL_HIGH          (1UL <<  0UL)
#define FMU_CFG_LOW_TIMING              (11UL<<  4UL)
#define FMU_CFG_HIGH_TIMING             (7UL <<  8UL)

#define FMU_MASK_1BIT                   (0x01UL)
#define FMU_MASK_2BIT                   (0x03UL)
#define FMU_MASK_3BIT                   (0x07UL)
#define FMU_MASK_4BIT                   (0x0FUL)
#define FMU_MASK_5BIT                   (0x1FUL)

/**************************************************************************************************
*
***************************************************************************************************/
typedef enum
{
    FMU_SIGNAL_IRQ                      = 0,
    FMU_SIGNAL_FIQ,
    FMU_SIGNAL_FAULT
}FmuSignal_t;

typedef enum
{
    FMU_SVL_LOW                         = 0,
    FMU_SVL_MID                         = 1,
    FMU_SVL_HIGH                        = 2
}FmuLevel_t;

typedef enum
{
    FMU_ID_CP0_ERR0                     =   0,
    FMU_ID_CP0_ERR1                     =   1,
    FMU_ID_CP1_ERR0                     =   2,
    FMU_ID_CP1_ERR1                     =   3,
    FMU_ID_CP2_ERR0                     =   4,
    FMU_ID_CP2_ERR1                     =   5,
    FMU_ID_CP0_RAS0                     =   6,
    FMU_ID_CP0_RAS1                     =   7,
    FMU_ID_CP1_RAS0                     =   8,
    FMU_ID_CP1_RAS1                     =   9,
    FMU_ID_CP2_RAS0                     =  10,
    FMU_ID_CP2_RAS1                     =  11,
    FMU_ID_CD0_DLS0                     =  12,
    FMU_ID_CD0_DLS1                     =  13,
    FMU_ID_CD1_DLS0                     =  14,
    FMU_ID_CD1_DLS1                     =  15,
    FMU_ID_CLUSTER_DLS0                 =  16,
    FMU_ID_CLUSTER_DLS1                 =  17,
    FMU_ID_MERGER0                      =  18,
    FMU_ID_MERGER1                      =  19,

    FMU_ID_NOC_NIU0                     =  20,
    FMU_ID_NOC_NIU1                     =  21,
    FMU_ID_A65_DLS0                     =  22,
    FMU_ID_A65_DLS1                     =  23,
    FMU_ID_A65_REMAP                    =  24,
    FMU_ID_CMU_PLL0                     =  25,
    FMU_ID_CMU_PLL1                     =  26,
    FMU_ID_CMU_PLL2                     =  27,
    FMU_ID_CMU_PLL3                     =  28,
    FMU_ID_CMU_A65_C0                   =  29,
    FMU_ID_CMU_A65_C1                   =  30,
    FMU_ID_CMU_A65_C2                   =  31,
    FMU_ID_CMU_A65_C3                   =  32,
    FMU_ID_CMU_A65_C4                   =  33,
    FMU_ID_CMU_A65_C5                   =  34,
    FMU_ID_CMU_DSU                      =  35,
    FMU_ID_CMU_APB                      =  36,
    FMU_ID_CMU_ATB                      =  37,
    FMU_ID_CMU_GIC                      =  38,
    FMU_ID_CMU_PERI                     =  39,
    FMU_ID_CMU_DLS                      =  40,

    FMU_ID_MBOX_S0                      =  41,
    FMU_ID_MBOX_S1                      =  42,
    FMU_ID_MBOX_NS0                     =  43,
    FMU_ID_MBOX_NS1                     =  44,
    FMU_ID_WDT0                         =  45,
    FMU_ID_WDT1                         =  46,
    FMU_ID_WDT2                         =  47,
    FMU_ID_WDT3                         =  48,
    FMU_ID_WDT4                         =  49,
    FMU_ID_WDT5                         =  50,
    FMU_ID_NOC                          =  51,
    FMU_ID_NOC_MERGER                   =  52,
    FMU_ID_SUB_DLS0                     =  53,
    FMU_ID_SUB_DLS1                     =  54,

    FMU_ID_M7_0_WDT                     =  55,
    FMU_ID_M7_0_MBOX_MST                =  56,
    FMU_ID_M7_0_MBOX_SLV                =  57,
    FMU_ID_M7_0_DTCM0                   =  58,
    FMU_ID_M7_0_DTCM1                   =  59,
    FMU_ID_M7_0_DLS0                    =  60,
    FMU_ID_M7_0_DLS1                    =  61,
    FMU_ID_M7_0_REMAP                   =  62,
    FMU_ID_M7_0_NOC0                    =  63,
    FMU_ID_M7_0_NOC1                    =  64,
    FMU_ID_M7_0_IRQ0                    =  65,
    FMU_ID_M7_0_IRQ1                    =  66,

    FMU_ID_M7_1_WDT                     =  67,
    FMU_ID_M7_1_MBOX_MST                =  68,
    FMU_ID_M7_1_MBOX_SLV                =  69,
    FMU_ID_M7_1_DTCM0                   =  70,
    FMU_ID_M7_1_DTCM1                   =  71,
    FMU_ID_M7_1_DLS0                    =  72,
    FMU_ID_M7_1_DLS1                    =  73,
    FMU_ID_M7_1_REMAP                   =  74,
    FMU_ID_M7_1_NOC0                    =  75,
    FMU_ID_M7_1_NOC1                    =  76,
    FMU_ID_M7_1_IRQ0                    =  77,
    FMU_ID_M7_1_RIQ1                    =  78,

    FMU_ID_M7_2_WDT                     =  79,
    FMU_ID_M7_2_MBOX_MST                =  80,
    FMU_ID_M7_2_MBOX_SLV                =  81,
    FMU_ID_M7_2_DTCM0                   =  82,
    FMU_ID_M7_2_DTCM1                   =  83,
    FMU_ID_M7_2_DLS0                    =  84,
    FMU_ID_M7_2_DLS1                    =  85,
    FMU_ID_M7_2_REMAP                   =  86,
    FMU_ID_M7_2_NOC0                    =  87,
    FMU_ID_M7_2_NOC1                    =  88,
    FMU_ID_M7_2_IRQ0                    =  89,
    FMU_ID_M7_2_IRQ1                    =  90,

    FMU_ID_HSM                          =  91,
    FMU_ID_MBOX_MST                     =  92,
    FMU_ID_MBOX_SLV                     =  93,
    FMU_ID_WDT_DLS                      =  94,
    FMU_ID_SEC_NOC0                     =  95,
    FMU_ID_SEC_NOC1                     =  96,
    FMU_ID_SEC_CFG0                     =  97,
    FMU_ID_SEC_CFG1                     =  98,
    FMU_ID_SEC_WDT0                     =  99,
    FMU_ID_SEC_WDT1                     = 100,
    FMU_ID_SFMC0                        = 101,
    FMU_ID_SFMC1                        = 102,
    FMU_ID_SFMC2                        = 103,
    FMU_ID_SFMC3                        = 104,
    FMU_ID_SFMC4                        = 105,
    FMU_ID_SFMC5                        = 106,
    FMU_ID_SFMC6                        = 107,
    FMU_ID_SFMC7                        = 108,
    FMU_ID_SFMC8                        = 109,
    FMU_ID_SFMC9                        = 110,
    FMU_ID_SFMC10                       = 111,
    FMU_ID_SFMC11                       = 112,
    FMU_ID_SFMC12                       = 113,
    FMU_ID_SFMC13                       = 114,
    FMU_ID_SFMC14                       = 115,
    FMU_ID_SFMC15                       = 116,
    FMU_ID_ROM                          = 117,
    FMU_ID_IMC0                         = 118,
    FMU_ID_IMC1                         = 119,
    FMU_ID_IMC2                         = 120,
    FMU_ID_SFMC0_CODE                   = 121,
    FMU_ID_SFMC0_STG                    = 122,
    FMU_ID_SFMC1_CODE                   = 123,
    FMU_ID_SFMC1_STG                    = 124,
    FMU_ID_NET_NOC0                     = 125,
    FMU_ID_NET_NOC1                     = 126,
    FMU_ID_OMC0                         = 127,
    FMU_ID_OMC1                         = 128,
    FMU_ID_MEM_SUB0                     = 129,
    FMU_ID_MEM_SUB1                     = 130,
    FMU_ID_DMA0                         = 131,
    FMU_ID_DMA1                         = 132,
    FMU_ID_MX_NOC                       = 133,
    FMU_ID_MX_WDT                       = 134,
    FMU_ID_MX_MBOX0                     = 135,
    FMU_ID_MX_MBOX1                     = 136,
    FMU_ID_MX_DTCM0                     = 137,
    FMU_ID_MX_DTCM1                     = 138,
    FMU_ID_MX_REMAP                     = 139,
    FMU_ID_TPA_EPP0                     = 140,
    FMU_ID_TPA_EPP1                     = 141,
    FMU_ID_TPA_GMAC0                    = 142,
    FMU_ID_TPA_GMAC1                    = 143,
    FMU_ID_TPA_XGMAC0                   = 144,
    FMU_ID_TPA_XGMAC1                   = 145,
    FMU_ID_TPA_XPCS0                    = 146,
    FMU_ID_TPA_XPCS1                    = 147,
    FMU_ID_TPA_CON0                     = 148,
    FMU_ID_TPA_CON1                     = 149,
    FMU_ID_NET_SUB0                     = 150,
    FMU_ID_NET_SUB1                     = 151,
    FMU_ID_LPA                          = 152,
    FMU_ID_GMAC0_CE                     = 153,
    FMU_ID_GMAC0_UE                     = 154,
    FMU_ID_GMAC0_DAT                    = 155,
    FMU_ID_GMAC0_DLY                    = 156,
    FMU_ID_GMAC0_CFG                    = 157,
    FMU_ID_GMAC1_CE                     = 158,
    FMU_ID_GMAC1_UE                     = 159,
    FMU_ID_GMAC1_DAT                    = 160,
    FMU_ID_GMAC1_DLY                    = 161,
    FMU_ID_GMAC1_CFG                    = 162,
    FMU_ID_HSIO_SUB                     = 163,
    FMU_ID_PCIE_SUB                     = 164,
    FMU_ID_GPSB0                        = 165,
    FMU_ID_GPSB1                        = 166,
    FMU_ID_GPSB2                        = 167,
    FMU_ID_GPSB3                        = 168,
    FMU_ID_GPSB4                        = 169,
    FMU_ID_GPSB5                        = 170,
    FMU_ID_ADC                          = 171,
    FMU_ID_IO_SUB                       = 172,
    FMU_ID_CMU_PLL0_OUT                 = 173,
    FMU_ID_CMU_PLL1_OUT                 = 174,
    FMU_ID_CMU_PLL2_OUT                 = 175,
    FMU_ID_CMU_PLL3_OUT                 = 176,
    FMU_ID_CMU_BUS                      = 177,
    FMU_ID_CMU_PERI_CLK                 = 178,
    FMU_ID_SMU_SUB0                     = 179,
    FMU_ID_SMU_SUB1                     = 180,
    FMU_ID_SMU_SUB2                     = 181,
    FMU_ID_SMU_SUB3                     = 182,
    FMU_ID_PMU0                         = 183,
    FMU_ID_PMU1                         = 184,
    FMU_ID_OSC                          = 185,
    FMU_ID_ECID                         = 186,

    FMU_ID_SOFT_FAULT                   = 191
}FmuIds_t;

typedef void (*FmuCallbackFunc)(void * pArg);

typedef struct
{
    volatile uint32                     FMU_CTRL;                           /* 0x0000 */
    volatile uint32                     FMU_FAULT_EN[FMU_ARRAY_NUM];        /* 0x0004 ~ 0x0018 */
    volatile uint32                     FMU_EXT_FAULT_CTRL;                 /* 0x001C */
    volatile uint32                     FMU_FAULT_SLV[FMU_ARRAY_SLV_NUM];   /* 0x0020 ~ 0x004C */
    volatile uint32                     IRQ_MASK[FMU_ARRAY_NUM];            /* 0x0050 ~ 0x0064 */
    volatile uint32                     IRQ_CLR[FMU_ARRAY_NUM];             /* 0x0068 ~ 0x007C */
    volatile uint32                     FIQ_MASK[FMU_ARRAY_NUM];            /* 0x0080 ~ 0x0094 */
    volatile uint32                     FIQ_CLR[FMU_ARRAY_NUM];             /* 0x0098 ~ 0x00AC */
    volatile uint32                     FAULT_MASK[FMU_ARRAY_NUM];          /* 0x00B0 ~ 0x00C4 */
    volatile uint32                     FAULT_CLR[FMU_ARRAY_NUM];           /* 0x00C8 ~ 0x00DC */
    volatile uint32                     IRQ_STATUS[FMU_ARRAY_NUM];          /* 0x00E0 ~ 0x00F4 */
    volatile uint32                     FIQ_STATUS[FMU_ARRAY_NUM];          /* 0x00F8 ~ 0x010C */
    volatile uint32                     FAULT_STATUS[FMU_ARRAY_NUM];        /* 0x0110 ~ 0x0124 */
    volatile uint32                     CLK_SEL;                            /* 0x0128 */
    volatile uint32                     OUT_STATUS;                         /* 0x012C */
    volatile uint32                     WR_PW_ADDR;                         /* 0x0130 */
}FmuRegister_t;

typedef struct
{
     FmuLevel_t                         mLevel;
     FmuCallbackFunc                    mFunc;
     void *                             mArg;
} FmuVectorTable_t;

#endif  /* End of SIC_BSP_SUPPORT_DRIVER_FMU */

#endif  /* End of SIC_BSP_FMU_REGISTER_HEADER */
