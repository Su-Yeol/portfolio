/*
***************************************************************************************************
*
*   FileName : fmu.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#if ( SIC_BSP_SUPPORT_DRIVER_FMU )

/**************************************************************************************************
*                                           INCLUDE HEADER
***************************************************************************************************/
#include <fmu.h>

/**************************************************************************************************
*                                           LOCAL VARIABLES
**************************************************************************************************/
static volatile FmuRegister_t * FMURegister = ((volatile FmuRegister_t *)FMU_ADDR_BASE);

static FmuVectorTable_t         FMUVectorTable[(uint32)FMU_ID_SOFT_FAULT + 1UL];

/**************************************************************************************************
*                                           INTERNAL FUNCTION
***************************************************************************************************/
/**************************************************************************************************
*                                          FMU_GetLevelInfo
*
* [Internal] Get the level (LOW, MID, HIGH) information accroding to FMU ID
*
* @param        FmuIds_t
* @return       FmuLevel_t (LOW, MID, HIGH)
*
* Notes
*
***************************************************************************************************/
static FmuLevel_t FMU_GetLevelInfo
(
    FmuIds_t                            uiFmuId
)
{
    uint32          uiLevel;
    uint32          uiLvArrIdx;
    uint32          uiLvBit;

    uiLevel     = 0UL;
    uiLvArrIdx  = ((uint32)uiFmuId >> 4UL);                     /* FmuId / 16UL       */
    uiLvBit     = ((uint32)uiFmuId & FMU_MASK_4BIT) << 1U;      /* (FmuID % 16UL) x 2 */

    if(uiLvBit < 30UL)
    {
        uiLevel     = ((FMURegister->FMU_FAULT_SLV[uiLvArrIdx] >> uiLvBit) & FMU_MASK_2BIT);
    }

    return (FmuLevel_t)uiLevel;
}

/**************************************************************************************************
*                                          FMU_GetEnableInfo
*
* [Internal] Get the Enable/Disable information accroding to FMU ID
*
* @param        FmuIds_t
* @return       Enable / Disable (1 / 0)
*
* Notes
*
***************************************************************************************************/
static uint32 FMU_GetEnableInfo
(
    FmuIds_t                            uiFmuId
)
{
    uint32          uiEn;
    uint32          uiEnArrIdx;
    uint32          uiEnBit;

    uiEnArrIdx  = ((uint32)uiFmuId >> 5UL);                     /* FmuId / 32UL */
    uiEnBit     = ((uint32)uiFmuId & FMU_MASK_5BIT);            /* FmuId % 32UL */

    uiEn        = (FMURegister->FMU_FAULT_EN[uiEnArrIdx] >> uiEnBit) & FMU_MASK_1BIT;

    return uiEn;
}

/**************************************************************************************************
*                                          FMU_SetExtFaultTiming
*
* [Internal] Set the external fault timing configuration
*
* @param
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
static SALRetCode_t FMU_SetExtFaultTiming
(
    void
)
{
    SALRetCode_t    ucRet;
    uint32          uiValue;

    uiValue = (FMU_CFG_FAULT_POL_LOW | FMU_CFG_LOW_TIMING | FMU_CFG_HIGH_TIMING);

    ucRet   = FMU_WritePassword();

    if(SAL_RET_SUCCESS == ucRet)
    {
        FMURegister->FMU_EXT_FAULT_CTRL |= uiValue;

        if(FMU_OFF == (FMURegister->FMU_EXT_FAULT_CTRL ^ uiValue))
        {
            ucRet = SAL_RET_SUCCESS;
        }
    }

    return ucRet;
}

/**************************************************************************************************
*                                          FMU_IrqHandler
*
* [Internal] Interrupt handler of IRQ
*
* @param
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
static void FMU_IrqHandler
(
    void
)
{
    uint32          uiFmuId;

    uiFmuId = FMU_GetFaultId(FMU_SIGNAL_IRQ);

    if(NULL_PTR != FMUVectorTable[uiFmuId].mFunc)
    {
        (*FMUVectorTable[uiFmuId].mFunc)(FMUVectorTable[uiFmuId].mArg);
    }
}

/**************************************************************************************************
*                                          FMU_FiqHandler
*
* [Internal] Interrupt handler of FIQ
*
* @param
* @return
*
* Notes
*
***************************************************************************************************/
static void FMU_FiqHandler
(
    void
)
{
    uint32          uiFmuId;

    uiFmuId = FMU_GetFaultId(FMU_SIGNAL_FIQ);

    if(NULL_PTR != FMUVectorTable[uiFmuId].mFunc)
    {
        (*FMUVectorTable[uiFmuId].mFunc)(FMUVectorTable[uiFmuId].mArg);
    }
}

#if defined(TCN100x)
/**************************************************************************************************
*                                          NMI_Handler
*
* [TEMPARARY]
*
* @param
* @return
*
* Notes
*
***************************************************************************************************/
/*****************************  TBD: Should be reviewed befor CS **********************************/
/**************************************************************************************************/
void NMI_Handler
(
    void
)
{
    uint32          uiFmuId;

    /* For the test */
#if ( CORTEX_M7_0 == 1 )
    mcu_printf("[NMI] FIQ occur [CM7-0]\n");
#elif ( CORTEX_M7_1 == 1)
    mcu_printf("[NMI] FIQ occur [CM7-1]\n");
#elif ( CORTEX_M7_2 == 1)
    mcu_printf("[NMI] FIQ occur [CM7-2]\n");
#elif ( CORTEX_M7_NP == 1)
    mcu_printf("[NMI] FIQ occur [CM7-NP]\n");
#endif

    uiFmuId = FMU_GetFaultId(FMU_SIGNAL_FIQ);

    if(NULL_PTR != FMUVectorTable[uiFmuId].mFunc)
    {
        (*FMUVectorTable[uiFmuId].mFunc)(FMUVectorTable[uiFmuId].mArg);
    }

}
#endif

/**************************************************************************************************
*                                          FMU_Reset
*
* [Internal] Set the external fault timing configuration
*
* @param
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
static SALRetCode_t FMU_Reset
(
    void
)
{
    SALRetCode_t    ucRet;

    ucRet = FMU_WritePassword();

    if(SAL_RET_SUCCESS == ucRet)
    {
        FMURegister->FMU_CTRL   |= FMU_CFG_SW_RESET;

        ucRet = FMU_WritePassword();

        if(SAL_RET_SUCCESS == ucRet)
        {
            FMURegister->FMU_CTRL   &= ~(FMU_CFG_SW_RESET);

            ucRet   = SAL_RET_SUCCESS;
        }
    }

    return ucRet;
}

/**************************************************************************************************
*                                          FMU_GetFaultId
*
* [External] Get the FMU ID according to fault signal type
*
* @param        FmuSignal_t
* @return       FmuId
*
* Notes
*
***************************************************************************************************/
uint32 FMU_GetFaultId
(
    FmuSignal_t                         uiType
)
{
    uint32          uiFmuId;
    uint32          uiValue;
    uint32          uiArrIdx;
    uint32          uiBit;

    uiFmuId     = 0UL;
    uiValue     = 0UL;
    uiArrIdx    = 0UL;
    uiBit       = 0UL;

    if(FMU_SIGNAL_FAULT < uiType)
    {
        mcu_printf("[%s] ERROR! Wrong Argument (Type: %d)\n\n", __func__, uiType);
    }
    else
    {
        switch(uiType)
        {
            case    FMU_SIGNAL_IRQ:
            {
                for(uiArrIdx = 0UL; uiArrIdx < FMU_ARRAY_NUM; uiArrIdx++)
                {
                    if(FMU_OFF != FMURegister->IRQ_STATUS[uiArrIdx])
                    {
                        uiValue = FMURegister->IRQ_STATUS[uiArrIdx];

                        break;
                    }
                }

                break;
            }

            case    FMU_SIGNAL_FIQ:
            {
                for(uiArrIdx = 0UL; uiArrIdx < FMU_ARRAY_NUM; uiArrIdx++)
                {
                    if(FMU_OFF != FMURegister->FIQ_STATUS[uiArrIdx])
                    {
                        uiValue = FMURegister->FIQ_STATUS[uiArrIdx];

                        break;
                    }
                }

                break;
            }

            default : /* FMU_SIGNAL_FAULT */
            {
                for(uiArrIdx = 0UL; uiArrIdx < FMU_ARRAY_NUM; uiArrIdx++)
                {
                    if(FMU_OFF != FMURegister->FAULT_STATUS[uiArrIdx])
                    {
                        uiValue = FMURegister->FAULT_STATUS[uiArrIdx];

                        break;
                    }
                }

                break;
            }
        }

        for(uiBit = 0UL; uiBit < 32UL; uiBit++)
        {
            if(FMU_ON == (uiValue & FMU_MASK_1BIT))
            {
                break;
            }

            uiValue >>= 1UL;
        }

        /* ID = (32UL * uiArrIdx) + uiField */
        uiFmuId = (uiArrIdx << 5UL) + uiBit;
    }

    return uiFmuId;
}


/**************************************************************************************************
*                                           EXTERNAL FUNCTION
***************************************************************************************************/
/**************************************************************************************************
*                                          FMU_WritePassword
*
* [External] Write password
*
* @param
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t FMU_WritePassword
(
    void
)
{
    SALRetCode_t    ucRet;

    ucRet   = SAL_RET_FAILED;

    FMURegister->WR_PW_ADDR     = FMU_CFG_PW;

    if((uint32)TRUE == FMURegister->WR_PW_ADDR)
    {
        ucRet   = SAL_RET_SUCCESS;
    }

    return ucRet;
}

/**************************************************************************************************
*                                          FMU_IsrHandler
*
* [External] Register the severity level and callback function on FMU vector table
*
* @param        FmuIds_t            FmuLevel_t
*               FmuCallbackFunc     Argument
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t FMU_IsrHandler
(
    FmuIds_t                            uiFmuId,
    FmuLevel_t                          uiFmuLevel,
    FmuCallbackFunc                     cbFunc,
    void *                              pArg
)
{
    SALRetCode_t    ucRet;

    ucRet   = SAL_RET_FAILED;

    if(FMU_ID_SOFT_FAULT < uiFmuId)
    {
        mcu_printf("[%s] ERROR! Wrong Argument (FmuId: %d)\n\n", __func__, uiFmuId);
    }
    else if(FMU_SVL_HIGH < uiFmuLevel)
    {
        mcu_printf("[%s] ERROR! Wrong Argument (FmuLevel: %d)\n\n", __func__, uiFmuLevel);
    }
    else if(NULL_PTR == cbFunc)
    {
        mcu_printf("[%s] ERROR! Wrong Argument (CallbackFunc NULL_PTR)\n\n", __func__);
    }
    else
    {
        FMUVectorTable[uiFmuId].mLevel  = uiFmuLevel;
        FMUVectorTable[uiFmuId].mFunc   = cbFunc;
        FMUVectorTable[uiFmuId].mArg    = pArg;

        ucRet = SAL_RET_SUCCESS;
    }

    return ucRet;
}

/**************************************************************************************************
*                                          FMU_IsrClr
*
* [External] Clear the fault status according to FMU ID
*
* @param        FmuIds_t
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t FMU_IsrClr
(
    FmuIds_t                            uiFmuId
)
{
    SALRetCode_t    ucRet;
    uint32          uiArrIdx;
    uint32          uiBit;

    ucRet       = SAL_RET_FAILED;

    if(FMU_ID_SOFT_FAULT < uiFmuId)
    {
        mcu_printf("[%s] ERROR! Wrong Argument (FmuId: %d)\n\n", __func__, uiFmuId);
    }
    else
    {
        uiArrIdx    = (uint32)uiFmuId >> 5UL;                   /* FmuId / 32UL */
        uiBit       = ((uint32)uiFmuId & FMU_MASK_5BIT);        /* FmuId % 32UL */

        switch(FMUVectorTable[uiFmuId].mLevel)
        {
            case    FMU_SVL_LOW:
            {
                (void)FMU_WritePassword();

                FMURegister->IRQ_CLR[uiArrIdx]  |= (FMU_ON << uiBit);

                (void)FMU_WritePassword();

                FMURegister->IRQ_CLR[uiArrIdx]  &= ~(FMU_ON << uiBit);

                break;
            }

            case    FMU_SVL_MID:
            {
                (void)FMU_WritePassword();

                FMURegister->FIQ_CLR[uiArrIdx]  |= (FMU_ON << uiBit);

                (void)FMU_WritePassword();

                FMURegister->FIQ_CLR[uiArrIdx]  &= ~(FMU_ON << uiBit);

                break;
            }

            case    FMU_SVL_HIGH:
            {

                (void)FMU_WritePassword();

                FMURegister->FIQ_CLR[uiArrIdx]      |= (FMU_ON << uiBit);

                (void)FMU_WritePassword();

                FMURegister->FIQ_CLR[uiArrIdx]      &= ~(FMU_ON << uiBit);

                (void)FMU_WritePassword();

                FMURegister->FAULT_CLR[uiArrIdx]    |= (FMU_ON << uiBit);

                (void)FMU_WritePassword();

                FMURegister->FAULT_CLR[uiArrIdx]    &= ~(FMU_ON << uiBit);

                break;
            }

            default:
            {
                ucRet   = SAL_RET_FAILED;
                break;
            }
        }
    }

    return ucRet;
}

/**************************************************************************************************
*                                          FMU_UnSet
*
* [External] Unset the severity level and enable field based on FMU ID
*
* @param        FmuIds_t
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t FMU_UnSet
(
    FmuIds_t                            uiFmuId
)
{
    SALRetCode_t    ucRet;
    uint32          uiEnArrIdx;
    uint32          uiEnBit;
    uint32          uiLvArrIdx;
    uint32          uiLvBit;

    ucRet       = SAL_RET_FAILED;

    if(FMU_ID_SOFT_FAULT < uiFmuId)
    {
        mcu_printf("[%s] ERROR! Wrong Argument (FmuId: %d)\n\n", __func__, uiFmuId);
    }
    else
    {
        uiLvArrIdx  = ((uint32)uiFmuId >> 4UL);                 /* FmuId / 16UL         */
        uiLvBit     = ((uint32)uiFmuId & FMU_MASK_4BIT) << 1U;  /* (FmuID % 16UL) x 2   */
        uiEnArrIdx  = ((uint32)uiFmuId >> 5UL);                 /* FmuId / 32UL         */
        uiEnBit     = ((uint32)uiFmuId & FMU_MASK_5BIT);        /* FmuId % 32UL         */

        if(uiLvBit < 30UL)
        {
            /* Clear Level bit according to FMU ID */
            (void)FMU_WritePassword();
            FMURegister->FMU_FAULT_SLV[uiLvArrIdx] &= ~(FMU_MASK_2BIT << uiLvBit);
        }

        /* Clear Enable bit according to FMU ID */
        (void)FMU_WritePassword();

        FMURegister->FMU_FAULT_EN[uiEnArrIdx] &= ~(FMU_ON << uiEnBit);

        FMUVectorTable[uiFmuId].mLevel  = FMU_SVL_LOW;
        FMUVectorTable[uiFmuId].mFunc   = NULL_PTR;
        FMUVectorTable[uiFmuId].mArg    = NULL_PTR;

        ucRet   = SAL_RET_SUCCESS;
    }

    return ucRet;
}

/**************************************************************************************************
*                                          FMU_Set
*
* [External] Set the severity level and enable field based on FMU ID
*
* @param        FmuIds_t
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t FMU_Set
(
    FmuIds_t                            uiFmuId
)
{
    SALRetCode_t    ucRet;
    uint32          uiEnArrIdx;
    uint32          uiEnBit;
    uint32          uiLvArrIdx;
    uint32          uiLvBit;

    ucRet       = SAL_RET_FAILED;

    if(FMU_ID_SOFT_FAULT < uiFmuId)
    {
        mcu_printf("[%s] ERROR! Wrong Argument (FmuId: %d)\n\n", __func__, uiFmuId);

    }
    else
    {
        uiLvArrIdx  = ((uint32)uiFmuId >> 4UL);                 /* FmuId / 16UL         */
        uiLvBit     = ((uint32)uiFmuId & FMU_MASK_4BIT) << 1UL;  /* (FmuID % 16UL) x 2   */

        if(uiLvBit < 30UL)
        {
            /* Clear Level bit according to FMU ID */
            (void)FMU_WritePassword();
            FMURegister->FMU_FAULT_SLV[uiLvArrIdx] &= ~(FMU_MASK_2BIT << uiLvBit);

            /* Set Level bit according to FMU ID */
            (void)FMU_WritePassword();
            FMURegister->FMU_FAULT_SLV[uiLvArrIdx] |= ((uint32)FMUVectorTable[uiFmuId].mLevel << uiLvBit);
        }

        if(FMU_GetLevelInfo(uiFmuId) == FMUVectorTable[uiFmuId].mLevel)
        {
            uiEnArrIdx  = ((uint32)uiFmuId >> 5UL);                 /* FmuId / 32UL */
            uiEnBit     = ((uint32)uiFmuId & FMU_MASK_5BIT);        /* FmuId % 32UL */

#if defined(TCN100x)
        switch(FMUVectorTable[uiFmuId].mLevel)
        {
            case    FMU_SVL_LOW:
            {
                (void)FMU_WritePassword();
                FMURegister->IRQ_MASK[uiEnArrIdx]   &= ~(FMU_ON << uiEnBit);

                (void)FMU_WritePassword();
                FMURegister->IRQ_MASK[uiEnArrIdx]   |= (FMU_ON << uiEnBit);

                break;
            }
            case    FMU_SVL_MID:
            {
                (void)FMU_WritePassword();
                FMURegister->FIQ_MASK[uiEnArrIdx]   &= ~(FMU_ON << uiEnBit);

                (void)FMU_WritePassword();
                FMURegister->FIQ_MASK[uiEnArrIdx]   |= (FMU_ON << uiEnBit);

                break;
            }
            default :   /* FMU_SVL_HIGH */
            {
                (void)FMU_WritePassword();
                FMURegister->FIQ_MASK[uiEnArrIdx]   &= ~(FMU_ON << uiEnBit);

                (void)FMU_WritePassword();
                FMURegister->FIQ_MASK[uiEnArrIdx]   |= (FMU_ON << uiEnBit);

                (void)FMU_WritePassword();
                FMURegister->FAULT_MASK[uiEnArrIdx] &= ~(FMU_ON << uiEnBit);

                (void)FMU_WritePassword();
                FMURegister->FAULT_MASK[uiEnArrIdx] |= (FMU_ON << uiEnBit);

                break;
            }
        }
#endif

            /* Clear Enable bit according to FMU ID */
            (void)FMU_WritePassword();
            FMURegister->FMU_FAULT_EN[uiEnArrIdx] &= ~(FMU_ON << uiEnBit);

            /* Set Level bit according to FMU ID */
            (void)FMU_WritePassword();
            FMURegister->FMU_FAULT_EN[uiEnArrIdx] |= (FMU_ON << uiEnBit);

            if(FMU_GetEnableInfo(uiFmuId) == FMU_ON)
            {
                ucRet = SAL_RET_SUCCESS;
            }
        }
        else
        {
            ucRet   = SAL_RET_FAILED;
        }
    }

    return ucRet;
}

/**************************************************************************************************
*                                          FMU_Deinit
*
* [External] De-initialize the FMU (Disable the interrupt)
*
* @param
* @return
*
* Notes
*
***************************************************************************************************/
void FMU_Deinit
(
    void
)
{
    (void)FMU_Reset();

    (void)NVIC_IntSrcDis(FMU_IRQ_IRQn);

    (void)NVIC_IntSrcDis(FMU_FIQ_IRQn);
}

/**************************************************************************************************
*                                          FMU_Init
*
* [External] Initialize the FMU (Set fault signal, Enable the interrupt)
*
* @param
* @return
*
* Notes
*
***************************************************************************************************/
void FMU_Init
(
    void
)
{
    (void)FMU_Reset();

    (void)FMU_SetExtFaultTiming();

    (void)NVIC_IntVectSet(FMU_IRQ_IRQn, (IrqHandler_t)&FMU_IrqHandler);

    (void)NVIC_IntSrcEn(FMU_IRQ_IRQn);

    (void)NVIC_IntVectSet(FMU_FIQ_IRQn, (IrqHandler_t)&FMU_FiqHandler);

    (void)NVIC_IntSrcEn(FMU_FIQ_IRQn);
}

#endif  /* End of SIC_BSP_SUPPORT_DRIVER_FMU */
