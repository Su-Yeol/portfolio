/*
***************************************************************************************************
*
*   FileName : ssm.h
*
*   Copyright (c) Telechips Inc.
*
*   Description : Header file of System Safety Mechnism Driver
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SSM_HEADER_H
#define SSM_HEADER_H

/* SSM Configuration Register Safety Mechanism */
#include <ssm_configure.h>
/* SSM Bus-Isolation Safety Mechanism */
#include <ssm_isolation.h>
/* SSM IMC-ECC Safety Mechanism */
#include <ssm_imc_ecc.h>
/* SSM SNOR-ECC Safety Mechanism */
#include <ssm_snor_ecc.h>
/* SSM MBOX-ECC Safety Mechanism */
#include <ssm_mbox_ecc.h>

#if (DEBUG_ENABLE)
    #include "debug.h"

    #define SSM_D(fmt,args...)          {LOGD(DBG_TAG_SSM, fmt, ## args)}
    #define SSM_E(fmt,args...)          {LOGE(DBG_TAG_SSM, fmt, ## args)}
#else
    #define SSM_D(fmt,args...)
    #define SSM_E(fmt,args...)
#endif

#endif  /* SSM_HEADER_H */

