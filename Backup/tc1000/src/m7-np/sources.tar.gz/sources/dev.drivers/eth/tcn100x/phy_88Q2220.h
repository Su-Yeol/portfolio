/*
***************************************************************************************************
*
*   FileName : phy_88Q2220.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_ETH_88Q2220_HEADER
#define SIC_BSP_ETH_88Q2220_HEADER

#if (CONFIG_PHY_88Q2220 == 1)

#include "eth.h"

#define MRVL_Q2220_ID                   0xB20

#define MRVL_Q222X_AN_ENABLE            (1 << 12)
#define MRVL_Q222X_AN_COMPLETE          (1 << 5)
#define MRVL_Q222X_AN_PREFER_MASTER     (1 << 4)

static void delay1us
(
   uint32                              uiUs
);

static void PHY_88Q2220_Config
(
    PHY_MS_Mode_t                       MS_Mode,
    PHY_OP_Mode_t                       OP_Mode,
    PHY_Speed_Mode_t                    SpeedMode
);

static PHY_Status_t PHY_88Q2220_GetDeviceInfo
(
    void
);

static void PHY_88Q2220_SwReset
(
    void
);

static void PHY_88Q2220_SetMasterSlave
(
    PHY_MS_Mode_t                       MS_mode
);

static PHY_Bool_t PHY_88Q2220_CheckIsMaster
(
    void
);

static PHY_Bool_t PHY_88Q2220_CheckLink
(
    void
);

static PHY_Bool_t PHY_88Q2220_GetRealTimeLinkStatus
(
    void
);

static PHY_Bool_t PHY_88Q2220_GetLatchedLinkStatus
(
    void
);

static PHY_Bool_t PHY_88Q2220_GetAnegEnabled
(
    void
);

static PHY_Bool_t PHY_88Q2220_GetAnegDone
(
    void
);

static PHY_Speed_Mode_t PHY_88Q2220_GetSpeed
(
    void
);

static void PHY_88Q2220_SetAneg
(
    PHY_MS_Mode_t                       MS_mode
);

void PHY_88Q2220_Read
(
    uint32                              uiAddr,
    uint32                              uiReg,
    uint16 *                            Ret
);

void PHY_88Q2220_Write
(
    uint32                              uiAddr,
    uint32                              uiReg,
    uint16                              usData
);

void  PHY_88Q2220_ReadStatus
(
    void
);

void PHY_88Q2220_Init
(
    ETHDev_t *                          pMac
);

#endif  // ( CONFIG_PHY_88Q2220 == 1 )

#endif  // SIC_BSP_ETH_88Q2220_HEADER

