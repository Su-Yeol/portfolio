/*
***************************************************************************************************
*
*   FileName : eth_reg.h
*
*   Copyright (c) Telechips Inc.
*
*   Description : Ethernet Driver
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_ETH_TARGET_HEADER
#define SIC_BSP_ETH_TARGET_HEADER

#if (CONFIG_FREERTOS_NETWORK == 1)
    #include <FreeRTOS.h>
    #include <task.h>
    #include "FreeRTOS_IP.h"
    #include "FreeRTOS_IP_Private.h"
    #include "NetworkBufferManagement.h"
#endif

#include <debug.h>
#include <bsp.h>
#include <clock.h>
#include <nvic.h>
#include <mpu.h>
#include <clock_dev.h>
#include <gpio.h>
#include <sal_internal.h>

#define NUM_OF_ETH_CON                              (2)
#define ETH_RDES_NUM                                (8)
#define ETH_TDES_NUM                                (8)
#define ETH_DESC_SIZE                               (4)   // 32bit * 4 (desc0~desc3)

// PHY Device Index
#define ETH_PHY_88EA1512                            (0)
#define ETH_PHY_88Q2220                             (1)

#define ETH_CON_0                                   (0)
#define ETH_CON_1                                   (1)

#define ETH_BASE_ADDR(x)                            (0x48200000UL + (0x100000UL * x))

// MAC Delay Register
#define ETH_DLY_REG_OFFSET                          (0x2000)
#define ETH_DLY0_OFFSET                             (0x00)  // TXCLK , TXER , TXEN
#define ETH_DLY1_OFFSET                             (0x04)  // TXD0 ~ TXD3
#define ETH_DLY2_OFFSET                             (0x08)  // TXD4 ~ TXD7
#define ETH_DLY3_OFFSET                             (0x0C)  // RXCLK , RXER , RXDV
#define ETH_DLY4_OFFSET                             (0x10)  // RXD0 ~ RXD3
#define ETH_DLY5_OFFSET                             (0x14)  // RXD4 ~ RXD7
#define ETH_DLY6_OFFSET                             (0x18)  // CRS , COL

#define ETH_DLY_TXC_I_SHIFT                         (0)
#define ETH_DLY_TXC_I_INV_SHIFT                     (7)
#define ETH_DLY_TXC_O_SHIFT                         (8)
#define ETH_DLY_TXC_O_INV_SHIFT                     (15)
#define ETH_DLY_TXEN_SHIFT                          (16)
#define ETH_DLY_TXER_SHIFT                          (24)

#define ETH_DLY_TXD0_SHIFT                          (0)
#define ETH_DLY_TXD1_SHIFT                          (8)
#define ETH_DLY_TXD2_SHIFT                          (16)
#define ETH_DLY_TXD3_SHIFT                          (24)

#define ETH_DLY_RXC_I_SHIFT                         (0)
#define ETH_DLY_RXC_I_INV_SHIFT                     (7)
#define ETH_DLY_RXDV_SHIFT                          (16)
#define ETH_DLY_RXER_SHIFT                          (24)

#define ETH_DLY_RXD0_SHIFT                          (0)
#define ETH_DLY_RXD1_SHIFT                          (8)
#define ETH_DLY_RXD2_SHIFT                          (16)
#define ETH_DLY_RXD3_SHIFT                          (24)

// MAC Configuration Register
#define ETH_CFG_REG_OFFSET                          (0x3000)
#define ETH_CFG0_OFFSET                             (0x00)
#define ETH_CFG1_OFFSET                             (0x04)
    #define ETH_CFG1_CE                             BIT(28)
    #define ETH_CFG1_PHY_INFSEL_SHIFT               (24)
    #define ETH_CFG1_PHY_INFSEL_MASK                (0x7)
    #define ETH_CFG1_FCTRL_SHIFT                    (20)
    #define ETH_CFG1_FCTRL_MASK                     (0x7)
    #define ETH_CFG1_TCO                            BIT(16)

#endif // SIC_BSP_ETH_TARGET_HEADER

