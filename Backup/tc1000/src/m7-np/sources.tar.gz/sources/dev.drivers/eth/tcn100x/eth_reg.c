/*
***************************************************************************************************
*
*   FileName : eth_reg.c
*
*   Copyright (c) Telechips Inc.
*
*   Description : Ethernet Driver
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#if ( SIC_BSP_SUPPORT_DRIVER_ETH == 1 )

#include <eth_reg.h>
#include <eth_typedef.h>

const Eth_PhyInfo_t Eth_PhyDeviceInfo[NUM_OF_ETH_CON] =
{
    // See Identifier Register : Device1 , Register 0x2 and 0x3.
    // 0x3 : High OUI (ignore)
    // 0x2 : Low OUI + Model Number + Revision Number(ignore)

    // See HW circuit doc.
    // 1. PhyAddr : 0x111
    //  - GPIO = !PHY_ADDR[2] , RXD[1] = !PHY_ADDR[1] , RXD[0] = !PHY_ADDR[0]
    {
        0xDD0,  0x111
    },
    // See Identifier Register : Device1 , Register 0x2 and 0x3.
    // 0x3 : High OUI (ignore)
    // 0x2 : Low OUI + Model Number + Revision Number(ignore)

    // See HW circuit doc.
    // 1. PhyAddr : 0x101
    //  - GPIO = !PHY_ADDR[2] , RXD[1] = !PHY_ADDR[1] , RXD[0] = !PHY_ADDR[0]
    // 2. 100/1000 Base T1 Selection
    //  - RXD[3] -> 0 : 100 Base-T1 , 1 : 1000 Base-T1
    // 3. Master / Slave Selection
    //  - RXD[2] -> 0 : Master , 1 : Slave
    {
        0xB20,  0x101
    },
};


const Eth_Port_t Eth_PortCfg[NUM_OF_ETH_CON] =
{
    // For GMAC Controller 0
    {
        // MDC          MDIO            PHY_IRQ
        GPIO_GPA(1),    GPIO_GPA(2),    0,
        // TXCLK        TXD0            TXD1            TXD2            TXD3            TXEN
        GPIO_GPA(0),    GPIO_GPA(5),    GPIO_GPA(6),    GPIO_GPA(11),   GPIO_GPA(12),   GPIO_GPA(7),
        // RXCLK        RXD0            RXD1            RXD2            RXD3            RXDV
        GPIO_GPA(13),   GPIO_GPA(3),    GPIO_GPA(4),    GPIO_GPA(9),    GPIO_GPA(10),   GPIO_GPA(8),
        // FUNC Select
        GPIO_FUNC(1),
        // PHYRST
        GPIO_GPA(18),
    },

    {
        // MDC          MDIO            PHY_IRQ
        GPIO_GPB(1),    GPIO_GPB(2),    GPIO_GPB(14),
        // TXCLK        TXD0            TXD1            TXD2            TXD3            TXEN
        GPIO_GPB(0),    GPIO_GPB(5),    GPIO_GPB(6),    GPIO_GPB(11),   GPIO_GPB(12),   GPIO_GPB(7),
        // RXCLK        RXD0            RXD1            RXD2            RXD3            RXDV
        GPIO_GPB(13),   GPIO_GPB(3),    GPIO_GPB(4),    GPIO_GPB(9),    GPIO_GPB(10),   GPIO_GPB(8),
        // FUNC Select
        GPIO_FUNC(1),
        // PHYRST
        GPIO_GPB(18),
    },
};

#endif
