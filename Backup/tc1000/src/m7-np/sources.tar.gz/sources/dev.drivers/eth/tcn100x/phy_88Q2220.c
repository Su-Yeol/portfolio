/*
***************************************************************************************************
*
*   FileName : phy_88Q2220.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#if (CONFIG_PHY_88Q2220 == 1)

#include <phy_88Q2220.h>

/*************************************************************************************************/
/*                                      LOCAL VARIABLES                                          */
/*************************************************************************************************/

static ETHDev_t *                                   pmac;
PHY_Speed_Mode_t                                    g_8220_speed = PHY_SpeedMode_1000;
PHY_OP_Mode_t                                       g_8220_op_mode = PHY_OpMode_Normal;

/*
***************************************************************************************************
*                                      FUNCTION PROTOTYPES
***************************************************************************************************
*/

/*
***************************************************************************************************
*                                          delay1us
* Function to generate delay.
*
* @param    [In] uiUs  :  time value
* @return   None
* Notes
***************************************************************************************************
*/

static void delay1us
(
   uint32                                           uiUs
)
{
   uint32                              i;
   uint32                              sec;

   i = 0xffUL;
   sec = 0;
   sec = uiUs * (uint32)500UL;

   for (i = 0; i < sec; i++)
   {
       BSP_NOP_DELAY();
   }

   return;
}

/*
***************************************************************************************************
*                                          PHY_88Q2220_Read
* Function to read phy register.
*
* @param    [In] uiAddr : phy register device address
* @param    [In] uiReg : phy register address
* @return
* Notes
*       phy read / write data : 16bit
*       Marvell phy mdio interface between GMAC : clause 22 to 45
*
***************************************************************************************************
*/

void PHY_88Q2220_Read
(
    uint32                                          uiAddr,
    uint32                                          uiReg,
    uint16 *                                        Ret
)
{
    uint32      uiRet = 0;

    ETH_MdioWrite(ETH_CON_1, MMD_ACCESS_CTRL,((OPERATION_ADDR << OPERATION_BIT_SHIFT) | uiAddr));
    ETH_MdioWrite(ETH_CON_1, MMD_ACCESS_ADDR_DATA, uiReg);
    ETH_MdioWrite(ETH_CON_1, MMD_ACCESS_CTRL,((OPERATION_RW << OPERATION_BIT_SHIFT) | uiAddr));

    uiRet = ETH_MdioRead(ETH_CON_1, MMD_ACCESS_ADDR_DATA);

    *Ret = uiRet;

    return;
}

/*
***************************************************************************************************
*                                          PHY_88Q2220_Write
* Function to read phy register.
*
* @param    [In] uiAddr : phy register device address
* @param    [In] uiReg : phy register address
* @param    [In] usData : Data
* @return
* Notes
*       phy read / write data : 16bit
*       Marvell phy mdio interface between GMAC : clause 22 to 45
*
***************************************************************************************************
*/

void PHY_88Q2220_Write
(
    uint32                                          uiAddr,
    uint32                                          uiReg,
    uint16                                          usData
)
{
    ETH_MdioWrite(ETH_CON_1, MMD_ACCESS_CTRL,(OPERATION_ADDR + uiAddr));
    ETH_MdioWrite(ETH_CON_1, MMD_ACCESS_ADDR_DATA, uiReg);
    // ETH_MdioWrite(ETH_CON_1, MMD_ACCESS_CTRL,(OPERATION_RW + dev_addr));
    ETH_MdioWrite(ETH_CON_1, MMD_ACCESS_CTRL,((OPERATION_RW << OPERATION_BIT_SHIFT) | uiAddr));
    ETH_MdioWrite(ETH_CON_1, MMD_ACCESS_ADDR_DATA, usData);

    return;
}

void PHY_88Q2220_Config
(
    PHY_MS_Mode_t                                   MS_Mode,
    PHY_OP_Mode_t                                   OP_Mode,
    PHY_Speed_Mode_t                                SpeedMode
)
{
    uint16                              reg;

    // Fix speed to 1000 BASE T1 Mode according to RXD3 Pull-up.
    
    PHY_88Q2220_GetDeviceInfo();

    if(SpeedMode == PHY_SpeedMode_100)
    {
        mcu_printf("[%s] Configuration for link speed 100.\n", __func__);
        delay1us(2000);

        PHY_88Q2220_Write(1, 0x0, 0x840);
        PHY_88Q2220_Write(3, 0xFE1B, 0x48);
        PHY_88Q2220_Write(3, 0xFFE4, 0x6B6);
        PHY_88Q2220_Write(1, 0x0000, 0x0000);
        PHY_88Q2220_Write(3, 0x0000, 0x0000);

        delay1us(4000);

        PHY_88Q2220_Write(3, 0xFDEC, 0xDBF7);
        PHY_88Q2220_Write(3, 0xFE00, 0x20);
        PHY_88Q2220_Write(3, 0xFE49, 0x807);
        PHY_88Q2220_Write(3, 0xFE50, 0xF28);
        PHY_88Q2220_Write(3, 0xFE4A, 0x12B);
        PHY_88Q2220_Write(3, 0xFE4B, 0x1D34);
        PHY_88Q2220_Write(3, 0xFE07, 0x224A);
        PHY_88Q2220_Write(3, 0xFE4C, 0x4006);
        PHY_88Q2220_Write(3, 0xFE5A, 0x40D5);
        PHY_88Q2220_Write(3, 0xFE5B, 0x46C0);
        PHY_88Q2220_Write(3, 0xFE5C, 0x008);
        PHY_88Q2220_Write(3, 0xFE07, 0x704A);
        PHY_88Q2220_Write(3, 0xFE06, 0x2044);
        PHY_88Q2220_Write(3, 0xFFF3, 0x2002);
        PHY_88Q2220_Write(3, 0x802C, 0xA1B0);
        PHY_88Q2220_Write(3, 0xFE73, 0x4190);
        PHY_88Q2220_Write(3, 0xFE04, 0x1F);
        PHY_88Q2220_Write(3, 0xFE5F, 0xE8);
        PHY_88Q2220_Write(7, 0x8032, 0x64);
        PHY_88Q2220_Write(7, 0x8031, 0xA17);
        PHY_88Q2220_Write(7, 0x8031, 0xC17);
        PHY_88Q2220_Write(3, 0xFE6B, 0x4632);
        PHY_88Q2220_Write(3, 0xFE6C, 0x8800);
        PHY_88Q2220_Write(3, 0xFFDB, 0xFC10);
        PHY_88Q2220_Write(3, 0x8019, 0x00FF);
        PHY_88Q2220_Write(3, 0xFE41, 0x0000);
        PHY_88Q2220_Write(4, 0x80AB, 0x0001);
        PHY_88Q2220_Write(4, 0x80AD, 0x0000);
        PHY_88Q2220_Write(4, 0x80AC, 0x0042);
        PHY_88Q2220_Write(4, 0x80AE, 0x144A);
        PHY_88Q2220_Write(4, 0x80AC, 0x0050);
        PHY_88Q2220_Write(4, 0x80AE, 0xF800);
        PHY_88Q2220_Write(4, 0x80AC, 0x0051);
        PHY_88Q2220_Write(4, 0x80AE, 0x0970);
        PHY_88Q2220_Write(4, 0x80AC, 0x0043);
        PHY_88Q2220_Write(4, 0x80AE, 0x56AD);
        PHY_88Q2220_Write(3, 0xFE73, 0x7D90);
        PHY_88Q2220_Write(3, 0xFE05, 0x3D52);
        PHY_88Q2220_Write(3, 0xFE74, 0x4218);
        PHY_88Q2220_Write(3, 0xFBBF, 0x0C0A);

        PHY_88Q2220_SwReset();
    }
    else    // SPEED_1000
    {
        mcu_printf("[%s] Configuration for link speed 1000.\n", __func__);
        delay1us(2000);

        PHY_88Q2220_Write(1, 0x0, 0x840);
        PHY_88Q2220_Write(3, 0xFE1B, 0x48);
        PHY_88Q2220_Write(3, 0xFFE4, 0x6B6);
        PHY_88Q2220_Write(1, 0x0000, 0x0000);
        PHY_88Q2220_Write(3, 0x0000, 0x0000);

        delay1us(4000);

        PHY_88Q2220_Write(3, 0xFDEC, 0xDBF7);
        PHY_88Q2220_Write(7, 0x8032, 0x0);
        PHY_88Q2220_Write(7, 0x8031, 0xA01);
        PHY_88Q2220_Write(7, 0x8031, 0xC01);
        PHY_88Q2220_Write(7, 0x8032, 0x0);
        PHY_88Q2220_Write(7, 0x8031, 0xA02);
        PHY_88Q2220_Write(7, 0x8031, 0xC02);
        PHY_88Q2220_Write(7, 0x8032, 0x2020);
        PHY_88Q2220_Write(7, 0x8031, 0xA29);
        PHY_88Q2220_Write(7, 0x8031, 0xC29);
        PHY_88Q2220_Write(7, 0x8032, 0x3846);
        PHY_88Q2220_Write(7, 0x8031, 0xA2C);
        PHY_88Q2220_Write(7, 0x8031, 0xC2C);
        PHY_88Q2220_Write(7, 0x8032, 0x3846);
        PHY_88Q2220_Write(7, 0x8031, 0xA35);
        PHY_88Q2220_Write(7, 0x8031, 0xC35);
        PHY_88Q2220_Write(7, 0x8032, 0x7);
        PHY_88Q2220_Write(7, 0x8031, 0xA1C);
        PHY_88Q2220_Write(7, 0x8031, 0xC1C);
        PHY_88Q2220_Write(7, 0x8032, 0x0);
        PHY_88Q2220_Write(7, 0x8031, 0xA27);
        PHY_88Q2220_Write(7, 0x8031, 0xC27);
        PHY_88Q2220_Write(7, 0x8032, 0x2020);
        PHY_88Q2220_Write(7, 0x8031, 0xA28);
        PHY_88Q2220_Write(7, 0x8031, 0xC28);
        PHY_88Q2220_Write(3, 0xFE60, 0x5E);
        PHY_88Q2220_Write(3, 0xFE49, 0x807);
        PHY_88Q2220_Write(3, 0xFE50, 0xF28);
        PHY_88Q2220_Write(3, 0xFE4A, 0x12B);
        PHY_88Q2220_Write(3, 0xFE4B, 0x1D34);
        PHY_88Q2220_Write(3, 0xFE07, 0x224A);
        PHY_88Q2220_Write(3, 0xFE73, 0x420C);
        PHY_88Q2220_Write(3, 0xFE05, 0x7572);
        PHY_88Q2220_Write(3, 0x800C, 0x2E);
        PHY_88Q2220_Write(3, 0xFC10, 0x0);
        PHY_88Q2220_Write(3, 0xFC11, 0x34);
        PHY_88Q2220_Write(3, 0xFC12, 0xC);
        PHY_88Q2220_Write(3, 0xFC13, 0x1F);
        PHY_88Q2220_Write(3, 0xFC30, 0x3434);
        PHY_88Q2220_Write(3, 0xFC31, 0x3434);
        PHY_88Q2220_Write(3, 0xFCA1, 0x800);
        PHY_88Q2220_Write(3, 0xFCC7, 0xFFFF);
        PHY_88Q2220_Write(3, 0xFC15, 0x35C0);
        PHY_88Q2220_Write(3, 0xFC7D, 0x5388);
        PHY_88Q2220_Write(3, 0xFC91, 0x2);
        PHY_88Q2220_Write(3, 0xFCC8, 0xFFFF);
        PHY_88Q2220_Write(3, 0xFCC6, 0xCF94);
        PHY_88Q2220_Write(3, 0xFCCB, 0x14);
        PHY_88Q2220_Write(3, 0xFCCC, 0x3F05);
        PHY_88Q2220_Write(3, 0xFC17, 0x25);
        PHY_88Q2220_Write(3, 0xFC69, 0xE4DC);
        PHY_88Q2220_Write(3, 0xFC6A, 0xD4D0);
        PHY_88Q2220_Write(3, 0xFC6B, 0x9006);
        PHY_88Q2220_Write(3, 0xFCA0, 0xA06);
        PHY_88Q2220_Write(3, 0xFC03, 0x3CC);
        PHY_88Q2220_Write(3, 0xFC04, 0x33);
        PHY_88Q2220_Write(3, 0xFC03, 0x3CD);
        PHY_88Q2220_Write(3, 0xFC04, 0x22);
        PHY_88Q2220_Write(3, 0xFC03, 0x3CE);
        PHY_88Q2220_Write(3, 0xFC04, 0x22);
        PHY_88Q2220_Write(3, 0xFC03, 0x3CF);
        PHY_88Q2220_Write(3, 0xFC04, 0x22);
        PHY_88Q2220_Write(3, 0xFC03, 0x3D0);
        PHY_88Q2220_Write(3, 0xFC04, 0x22);
        PHY_88Q2220_Write(3, 0xFC03, 0x3D1);
        PHY_88Q2220_Write(3, 0xFC04, 0x22);
        PHY_88Q2220_Write(3, 0xFC03, 0x3E4);
        PHY_88Q2220_Write(3, 0xFC04, 0x33);
        PHY_88Q2220_Write(3, 0xFC03, 0x3E5);
        PHY_88Q2220_Write(3, 0xFC04, 0x22);
        PHY_88Q2220_Write(3, 0xFC03, 0x3E6);
        PHY_88Q2220_Write(3, 0xFC04, 0x22);
        PHY_88Q2220_Write(3, 0xFC03, 0x3E7);
        PHY_88Q2220_Write(3, 0xFC04, 0x22);
        PHY_88Q2220_Write(3, 0xFC03, 0x3E8);
        PHY_88Q2220_Write(3, 0xFC04, 0x22);
        PHY_88Q2220_Write(3, 0xFC03, 0x3E9);
        PHY_88Q2220_Write(3, 0xFC04, 0x22);
        PHY_88Q2220_Write(3, 0xFC19, 0xE01);
        PHY_88Q2220_Write(3, 0xFC1A, 0xE10);
        PHY_88Q2220_Write(3, 0xFC1B, 0xC10);
        PHY_88Q2220_Write(3, 0xFC1C, 0x303);
        PHY_88Q2220_Write(3, 0xFC3A, 0x2725);
        PHY_88Q2220_Write(3, 0xFC61, 0x2627);
        PHY_88Q2220_Write(3, 0xFC89, 0x0);
        PHY_88Q2220_Write(3, 0xFC89, 0x4);
        PHY_88Q2220_Write(3, 0xFC22, 0x55);
        PHY_88Q2220_Write(3, 0xFCB3, 0xF4F0);
        PHY_88Q2220_Write(3, 0xFCB4, 0xE4E0);
        PHY_88Q2220_Write(3, 0xFCB5, 0x900D);
        PHY_88Q2220_Write(3, 0xFCA0, 0x1406);
        PHY_88Q2220_Write(3, 0xFC03, 0x3D7);
        PHY_88Q2220_Write(3, 0xFC04, 0x0);
        PHY_88Q2220_Write(3, 0xFC03, 0x3D8);
        PHY_88Q2220_Write(3, 0xFC04, 0x0);
        PHY_88Q2220_Write(3, 0xFC03, 0x3D9);
        PHY_88Q2220_Write(3, 0xFC04, 0x0);
        PHY_88Q2220_Write(3, 0xFC03, 0x3DA);
        PHY_88Q2220_Write(3, 0xFC04, 0x0);
        PHY_88Q2220_Write(3, 0xFC03, 0x3DB);
        PHY_88Q2220_Write(3, 0xFC04, 0x0);
        PHY_88Q2220_Write(3, 0xFC03, 0x3EA);
        PHY_88Q2220_Write(3, 0xFC04, 0x0);
        PHY_88Q2220_Write(3, 0xFC03, 0x3EB);
        PHY_88Q2220_Write(3, 0xFC04, 0x0);
        PHY_88Q2220_Write(3, 0xFC03, 0x3EC);
        PHY_88Q2220_Write(3, 0xFC04, 0x0);
        PHY_88Q2220_Write(3, 0xFC03, 0x3ED);
        PHY_88Q2220_Write(3, 0xFC04, 0x0);
        PHY_88Q2220_Write(3, 0xFC03, 0x3EE);
        PHY_88Q2220_Write(3, 0xFC04, 0x0);
        PHY_88Q2220_Write(3, 0xFC89, 0x4);
        PHY_88Q2220_Write(3, 0xFC89, 0x84);
        PHY_88Q2220_Write(3, 0xFC03, 0x540);
        PHY_88Q2220_Write(3, 0xFC04, 0x64);
        PHY_88Q2220_Write(3, 0xFC03, 0x541);
        PHY_88Q2220_Write(3, 0xFC04, 0x2710);
        PHY_88Q2220_Write(3, 0xFC03, 0x542);
        PHY_88Q2220_Write(3, 0xFC04, 0x5);
        PHY_88Q2220_Write(3, 0xFC03, 0x543);
        PHY_88Q2220_Write(3, 0xFC04, 0xF);
        PHY_88Q2220_Write(3, 0xFC03, 0x544);
        PHY_88Q2220_Write(3, 0xFC04, 0x5);
        PHY_88Q2220_Write(3, 0xFC03, 0x545);
        PHY_88Q2220_Write(3, 0xFC04, 0x5);
        PHY_88Q2220_Write(3, 0xFC03, 0x546);
        PHY_88Q2220_Write(3, 0xFC04, 0x19);
        PHY_88Q2220_Write(3, 0xFC03, 0x547);
        PHY_88Q2220_Write(3, 0xFC04, 0x64);
        PHY_88Q2220_Write(3, 0xFC03, 0x548);
        PHY_88Q2220_Write(3, 0xFC04, 0x2710);
        PHY_88Q2220_Write(3, 0xFC03, 0x549);
        PHY_88Q2220_Write(3, 0xFC04, 0x5);
        PHY_88Q2220_Write(3, 0xFC03, 0x54A);
        PHY_88Q2220_Write(3, 0xFC04, 0xF);
        PHY_88Q2220_Write(3, 0xFC03, 0x54B);
        PHY_88Q2220_Write(3, 0xFC04, 0x5);
        PHY_88Q2220_Write(3, 0xFC03, 0x54C);
        PHY_88Q2220_Write(3, 0xFC04, 0x5);
        PHY_88Q2220_Write(3, 0xFC03, 0x54D);
        PHY_88Q2220_Write(3, 0xFC04, 0x19);
        PHY_88Q2220_Write(3, 0xFCC1, 0xC63);
        PHY_88Q2220_Write(3, 0xFCC2, 0x1020);
        PHY_88Q2220_Write(3, 0xFCC3, 0x40);
        PHY_88Q2220_Write(3, 0xFCC4, 0x1014);
        PHY_88Q2220_Write(3, 0xFCC5, 0x2328);
        PHY_88Q2220_Write(3, 0xFCB1, 0xC26);
        PHY_88Q2220_Write(3, 0xFC5C, 0x7F);
        PHY_88Q2220_Write(3, 0xFE4C, 0x4006);
        PHY_88Q2220_Write(3, 0xFE5A, 0x40D5);
        PHY_88Q2220_Write(3, 0xFE5B, 0x46C0);
        PHY_88Q2220_Write(3, 0xFE5C, 0x008);
        PHY_88Q2220_Write(3, 0xFE07, 0x704A);
        PHY_88Q2220_Write(3, 0xFE06, 0x2044);
        PHY_88Q2220_Write(3, 0xFFF3, 0x2002);
        PHY_88Q2220_Write(3, 0x802C, 0xA1B0);
        PHY_88Q2220_Write(3, 0xFE2A, 0xBC2C);
        PHY_88Q2220_Write(3, 0xFE37, 0x0011);
        PHY_88Q2220_Write(3, 0xFE04, 0x1F);
        PHY_88Q2220_Write(3, 0xFE5F, 0xE8);
        PHY_88Q2220_Write(7, 0x8032, 0x64);
        PHY_88Q2220_Write(7, 0x8031, 0xA17);
        PHY_88Q2220_Write(7, 0x8031, 0xC17);
        PHY_88Q2220_Write(3, 0xFCAB, 0x1050);
        PHY_88Q2220_Write(3, 0xFCAC, 0x1C0D);
        PHY_88Q2220_Write(3, 0xFCAD, 0x7020);
        PHY_88Q2220_Write(3, 0xFE6B, 0x4632);
        PHY_88Q2220_Write(3, 0xFE6C, 0x8800);
        PHY_88Q2220_Write(3, 0xFFDB, 0xFC10);
        PHY_88Q2220_Write(3, 0xFE1B, 0x41);
        PHY_88Q2220_Write(3, 0x8019, 0x00FF);
        PHY_88Q2220_Write(7, 0x8035, 0x32B8);
        PHY_88Q2220_Write(7, 0x8036, 0x25);
        PHY_88Q2220_Write(3, 0xFE41, 0x0000);
        PHY_88Q2220_Write(4, 0x80AB, 0x0001);
        PHY_88Q2220_Write(4, 0x80AD, 0x0000);
        PHY_88Q2220_Write(4, 0x80AC, 0x0042);
        PHY_88Q2220_Write(4, 0x80AE, 0x144A);
        PHY_88Q2220_Write(4, 0x80AC, 0x0050);
        PHY_88Q2220_Write(4, 0x80AE, 0xF800);
        PHY_88Q2220_Write(4, 0x80AC, 0x0051);
        PHY_88Q2220_Write(4, 0x80AE, 0x0970);
        PHY_88Q2220_Write(4, 0x80AC, 0x0043);
        PHY_88Q2220_Write(4, 0x80AE, 0x56AD);
        PHY_88Q2220_Write(3, 0xFE73, 0x5E0C);
        PHY_88Q2220_Write(3, 0xFE05, 0x7952);
        PHY_88Q2220_Write(3, 0xFE74, 0x4218);
        PHY_88Q2220_Write(3, 0xFC5D, 0x06FB);
        PHY_88Q2220_Write(3, 0xFC34, 0x1FA3);

        PHY_88Q2220_SwReset();
    }

    PHY_88Q2220_CheckIsMaster();

    if(OP_Mode == PHY_OpMode_Loopback_PHY)
    {
        mcu_printf("[%s] Loopback mode enable.\n", __func__);

        // Enable Loopback Mode
        // Device 1 , Register 0x0
        PHY_88Q2220_Read(1, 0x0000, &reg);

        reg |= 0x1; // PMA Loopback Bit
        PHY_88Q2220_Write(1, 0x0000, reg);

        PHY_88Q2220_Read(1, 0x0000, &reg);
        ETH_D("[%s] PHY control register : 0x%x \n", __func__ , reg);
    }

    return;
}

static PHY_Status_t PHY_88Q2220_GetDeviceInfo
(
    void
)
{
    uint16                              device_id = 0;
    PHY_Status_t                        ret = PHY_STATUS_ERR;


    pmac[ETH_CON_1].PhyAddr = 0;

    ETH_D("[%s] Try to find valid phy address \n", __func__);
    while(1)
    {
        PHY_88Q2220_Read(1, 0x0003, &device_id);

        if(device_id != 0xffff)
        {
            ETH_D("[%s] device id : %x , phy addr : %x \n", __func__, device_id, pmac[ETH_CON_1].PhyAddr);
            break;
        }
        else
        {
            pmac[ETH_CON_1].PhyAddr++; // Find valid phy addr.
        }

        if(pmac[ETH_CON_1].PhyAddr > 0xFFF)
        {
            ETH_D("[%s] escape loop \n", __func__);
            break;
        }
    }
    
    mcu_printf("[%s] Phy Addr : 0x%x \n", pmac[ETH_CON_1].PhyAddr);

    PHY_88Q2220_Read(1, 0x0003, &device_id);

    if (MRVL_Q2220_ID == (device_id & 0xfff0))   // ignore Revision number
    {
        ret = PHY_STATUS_OK;
        mcu_printf("[%s] Device Id. expected : 0x%x , result : 0x%x\n",
                                __func__, MRVL_Q2220_ID, (device_id & 0xfff0));
    }
    else
    {
        ret = PHY_STATUS_ERR;
        mcu_printf("[%s] Invalid device id : %x \n", __func__, (device_id & 0xfff0));
    }

    return ret;
}

static void PHY_88Q2220_SwReset
(
    void
)
{
    PHY_88Q2220_Write(3, 0x0900, 0x8000);
    PHY_88Q2220_Write(3, 0xFFE4, 0x000C);
    return;
}

static void PHY_88Q2220_SetMasterSlave
(
    PHY_MS_Mode_t                                   MS_mode
)
{
    uint16                              reg;

    PHY_88Q2220_Read(1, 0x0834, &reg);

    if(MS_mode == PHY_MS_Mode_Master)
    {
        // Master
        reg |= 0x4000;
    }
    else
    {
        // Slave
        reg &= 0xBFFF;
    }

    PHY_88Q2220_Write(1, 0x0834, reg);

    return;
}

static PHY_Bool_t PHY_88Q2220_CheckIsMaster
(
    void
)
{
    uint16                              reg = 0;
    PHY_Bool_t                          ret = 0;

    PHY_88Q2220_Read(7, 0x8001, &reg);
    reg = ((reg >> 14) & 0x0001);

    if (reg == PHY_MS_Mode_Master)
    {
        mcu_printf("[%s] Master mode \n", __func__);
        ret = PHY_TRUE;
    }
    else
    {
        mcu_printf("[%s] Slave mode \n", __func__);
        ret = PHY_FALSE;
    }

    return ret;
}

static PHY_Bool_t PHY_88Q2220_CheckLink
(
    void
)
{
    uint16                              reg1, reg2, reg3 = 0;
    PHY_Bool_t                          ret = PHY_FALSE;


    if(g_8220_speed == PHY_SpeedMode_1000)
    {
        PHY_88Q2220_Read(3, 0x0901, &reg1);  // Read twice
        PHY_88Q2220_Read(3, 0x0901, &reg1);  // link latches low status
        PHY_88Q2220_Read(7, 0x8001, &reg2);  // local and remote receiver status
        PHY_88Q2220_Read(3, 0xFD9D, &reg3);  // local receiver status 2

        ETH_D("[%s] Speed1000 Status, reg1 : 0x%x , reg2: 0x%0x , reg3 : 0x%0x \n", __func__, reg1, reg2, reg3);
        ret = (0x0004 == (reg1 & (1<<2)))
                && (0x3000 == (reg2 & 0x3000))
                && (0x0010 == (reg3 & 0x0010)) ? PHY_TRUE : PHY_FALSE;
    }
    else
    {
        PHY_88Q2220_Read(3, 0x8109, &reg1);  // link
        PHY_88Q2220_Read(3, 0x8108, &reg2);  // local and remote receiver status
        PHY_88Q2220_Read(3, 0x8230, &reg3);  // local receiver status 2

        ETH_D("[%s] Speed100 Status, reg1 : 0x%x , reg2: 0x%0x , reg3 : 0x%0x \n", __func__, reg1, reg2, reg3);
        ret = (0x0004 == (reg1 & 0x0004))
                && (0x3000 == (reg2 & 0x3000))
                && (0x1 == (reg3 & 0x1)) ? PHY_TRUE : PHY_FALSE;
    }

    return ret;
}

static PHY_Bool_t PHY_88Q2220_GetRealTimeLinkStatus
(
    void
)
{
    uint16                              reg = 0;
    PHY_Bool_t                          ret = PHY_FALSE;

    if (g_8220_speed == PHY_SpeedMode_1000)
    {
        PHY_88Q2220_Read(3, 0x0901, &reg);
        PHY_88Q2220_Read(3, 0x0901, &reg);    // 0xead twice: register latches low regVal
    }
    else
    {
        PHY_88Q2220_Read(3, 0x8109, &reg);
    }

    ret = (0x0 != (reg & 0x0004)) ? PHY_TRUE : PHY_FALSE;
    return ret;
}

static PHY_Bool_t PHY_88Q2220_GetLatchedLinkStatus
(
    void
)
{
    uint16                              reg = 0;
    PHY_Bool_t                          ret = PHY_FALSE;

    PHY_88Q2220_Read(7, 0x0201, &reg);

    ret = (0x0 != (reg & 0x0004)) ? PHY_TRUE : PHY_FALSE;
    return ret;
}

static PHY_Bool_t PHY_88Q2220_GetAnegEnabled
(
    void
)
{
    uint16                              reg = 0;
    PHY_Bool_t                          ret = PHY_FALSE;

    PHY_88Q2220_Read(7, 0x0200, &reg);

    ret = (0x0 != (reg & MRVL_Q222X_AN_ENABLE)) ? PHY_TRUE : PHY_FALSE;
    return ret;
}

static PHY_Bool_t PHY_88Q2220_GetAnegDone
(
    void
)
{
    uint16                              reg = 0;
    PHY_Bool_t                          ret = PHY_FALSE;

    PHY_88Q2220_Read(7, 0x0201, &reg);

    ret = (0x0 != (reg & MRVL_Q222X_AN_COMPLETE)) ? PHY_TRUE : PHY_FALSE;
    return ret;
}

static PHY_Speed_Mode_t PHY_88Q2220_GetSpeed
(
    void
)
{
    uint16                              reg = 0;
    PHY_Bool_t                          isEnable = 0;
    PHY_Speed_Mode_t                    ret = PHY_SpeedMode_None;

    isEnable = PHY_88Q2220_GetAnegEnabled();

    if (isEnable)
    {
        PHY_88Q2220_Read(7, 0x801a, &reg);
        reg = (reg & 0x4000) >> 14;
    }
    else
    {
        PHY_88Q2220_Read(1, 0x0834, &reg);
        reg &= 0x0001;
    }

    if (0 == reg)
    {
        ret = PHY_SpeedMode_100;
    }
    else
    {
        ret = PHY_SpeedMode_1000;
    }

    return ret;
}

static void PHY_88Q2220_SetAneg
(
    PHY_MS_Mode_t                                   MS_mode
)
{
    uint16  reg, anAbility = 0;

    if (MS_mode == PHY_MS_Mode_Master)
    {
        anAbility = MRVL_Q222X_AN_PREFER_MASTER;
    }

    PHY_88Q2220_Write(7, 0x0203, 0x0);
    PHY_88Q2220_Write(7, 0x0202, 0x0001);
    PHY_88Q2220_Write(7, 0x0200, 0x8000);

    PHY_88Q2220_Write(3, 0xfe04, 0x12);
    PHY_88Q2220_Write(3, 0xfe5f, 0xE8);

    PHY_88Q2220_Write(7, 0x8032, 0x0064);
    PHY_88Q2220_Write(7, 0x8031, 0x0a17);
    PHY_88Q2220_Write(7, 0x8031, 0x0c17);

    // Set Ability registers
    PHY_88Q2220_Write(7, 0x0203, anAbility);

    // Force master if needed
    PHY_88Q2220_Read(7, 0x0202, &reg);

    if (MS_mode == PHY_MS_Mode_Master)
    {
        reg |= 0x1000;
    }
    else
    {
        reg &= 0xEFFF;
    }

    PHY_88Q2220_Write(7, 0x0202, reg);

    return;
}

/*
***************************************************************************************************
*                                          PHY_ReadStatus
* Function to get link status and set operating info.
*
* @param    None
* @return
* Notes
*
***************************************************************************************************
*/

void  PHY_88Q2220_ReadStatus
(
    void
)
{
    if(pmac[ETH_CON_1].Mode == PHY_OpMode_Loopback_PHY)
    {
        pmac[ETH_CON_1].LinkInfo.Link = 1;
    }
    else
    {
        pmac[ETH_CON_1].LinkInfo.Link = PHY_88Q2220_CheckLink();
    }

    pmac[ETH_CON_1].LinkInfo.CurSpeed = g_8220_speed;
    pmac[ETH_CON_1].LinkInfo.CurDuplex = (uint32)PHY_Duplex_Full;

    ETH_D("[%s] Link : %s , Speed : %d, Duplex : %s\n",
                    __func__,
                    pmac[ETH_CON_1].LinkInfo.Link == 1 ? "Up" : "Down",
                    pmac[ETH_CON_1].LinkInfo.CurSpeed,
                    pmac[ETH_CON_1].LinkInfo.CurDuplex == 1 ? "Full Duplex" : "Half Duplex"
                    );

    return;
}


void PHY_88Q2220_Init
(
    ETHDev_t *                                      pMac
)
{
    PHY_Config func1 = &PHY_88Q2220_Config;
    PHY_ReadStatus func2 = &PHY_88Q2220_ReadStatus;
    PHY_Read func3 = &PHY_88Q2220_Read;
    PHY_Write func4 = &PHY_88Q2220_Write;

    pmac = pMac;

    // If register function ptr directly to struct, It work unexpectly. (jump wrong PC)
    pmac[ETH_CON_1].PhyOps.Config = func1;
    pmac[ETH_CON_1].PhyOps.ReadStatus = func2;
    pmac[ETH_CON_1].PhyOps.Read = func3;
    pmac[ETH_CON_1].PhyOps.Write = func4;

    return;
}
#endif  // ( CONFIG_PHY_88Q2220 == 1 )
