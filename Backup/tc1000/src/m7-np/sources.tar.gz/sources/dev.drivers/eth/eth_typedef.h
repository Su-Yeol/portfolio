/*
***************************************************************************************************
*
*   FileName : eth_typedef.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_ETH_TYPEDEF_HEADER
#define SIC_BSP_ETH_TYPEDEF_HEADER

#include <eth_reg.h>

typedef enum
{
    PHY_FALSE   = 0,
    PHY_TRUE    = 1
} PHY_Bool_t;

typedef enum
{
    PHY_STATUS_OK   = 0,
    PHY_STATUS_ERR  = 1,
    PHY_STATUS_MAX
} PHY_Status_t;

typedef enum
{
    PHY_MS_Mode_Slave   = 0,
    PHY_MS_Mode_Master  = 1,
    PHY_MS_Mode_MAX
} PHY_MS_Mode_t;

typedef enum
{
    PHY_OpMode_Normal       = 0,
    PHY_OpMode_Loopback_MAC = 1,
    PHY_OpMode_Loopback_PHY = 2,
    PHY_OpMode_MAX
} PHY_OP_Mode_t;

typedef enum
{
    PHY_SpeedMode_None  = 0,
    PHY_SpeedMode_10    = 10,
    PHY_SpeedMode_100   = 100,
    PHY_SpeedMode_1000  = 1000
} PHY_Speed_Mode_t;

typedef enum
{
    PHY_Duplex_Half = 0,
    PHY_Duplex_Full = 1,
    PHY_Duplex_MAX
} PHY_Duplex_Mode_t;

typedef void (*PHY_Config)(PHY_MS_Mode_t MS_Mode, PHY_OP_Mode_t OP_Mode, PHY_Speed_Mode_t SpeedMode);
typedef void (*PHY_ReadStatus)(void);
typedef void (*PHY_Read)(uint32 uiAddr, uint32 uiReg, uint16 * Ret);
typedef void (*PHY_Write)(uint32 uiAddr, uint32 uiReg, uint16 usData);

typedef void                            (*ETHRecvCallback)(uint32 uiLength);

typedef struct ETHLink
{
    uint32                              Oldlink;
    uint32                              Link;

    uint32                              CurDuplex;
    uint32                              OldDuplex;
    uint32                              Duplex;

    uint32                              OldSpeed;
    uint32                              CurSpeed;
    uint32                              Speed10;
    uint32                              Speed100;
    uint32                              Speed1000;
    uint32                              SpeedMask;
} ETH_Link_t;

typedef struct ETHMii
{
    uint32                              Addr;
    uint32                              Data;
    uint32                              AddrShift;
    uint32                              AddrMask;
    uint32                              RegShift;
    uint32                              RegMask;
    uint32                              CsrShift;
    uint32                              CsrMask;
    uint32                              Csr;
} ETH_Mii_t;

typedef struct ETHDelay
{
    // for RGMII interface
    uint32                              Txc;
    uint32                              TxcInv;
    uint32                              Txd0;
    uint32                              Txd1;
    uint32                              Txd2;
    uint32                              Txd3;
    uint32                              Txen;

    uint32                              Rxc;
    uint32                              RxcInv;
    uint32                              Rxd0;
    uint32                              Rxd1;
    uint32                              Rxd2;
    uint32                              Rxd3;
    uint32                              Rxdv;
} ETH_Delay_t;

typedef struct Eth_PortConfig
{
    uint32                              Mdc;
    uint32                              Mdio;
    uint32                              Phy_irq;

    uint32                              Txclk;
    uint32                              Txd_0;
    uint32                              Txd_1;
    uint32                              Txd_2;
    uint32                              Txd_3;
    uint32                              Txen;

    uint32                              Rxclk;
    uint32                              Rxd_0;
    uint32                              Rxd_1;
    uint32                              Rxd_2;
    uint32                              Rxd_3;
    uint32                              Rxdv;

    uint32                              Func_sel;
    uint32                              PhyRst;
} Eth_Port_t;

typedef struct Eth_PhyInfo
{
    uint32                              phy_id;
    uint32                              phy_addr;
} Eth_PhyInfo_t;

typedef struct ETH_TxDesc
{
    uint32                              Tdes0;
    uint32                              Tdes1;
    uint32                              Tdes2;
    uint32                              Tdes3;
#if ETH_ENH_DESC    // TODO
    // ?
#endif
} ETH_TxDesc_t;

typedef struct ETH_RxDesc
{
    uint32                              Rdes0;
    uint32                              Rdes1;
    uint32                              Rdes2;
    uint32                              Rdes3;
#if ETH_ENH_DESC    // TODO : ehn desc for Timestamp
    // Rdes4
    // Rdes5
    // Rdes6
    // Rdes7
#endif
} ETH_RxDesc_t;

typedef struct ETH_Desc
{
    ETH_RxDesc_t *                      Rdesc_base;
    ETH_TxDesc_t *                      Tdesc_base;
    uint32                              CurRx;
    uint32                              CurTx;
} ETH_Desc_t;

typedef struct ETH_Phy_Ops
{
    PHY_Config                          Config;
    PHY_ReadStatus                      ReadStatus;
    PHY_Read                            Read;
    PHY_Write                           Write;
} ETH_PhyOps_t;

typedef struct ETH_Dev
{
    uint32                              BaseAddr;
    uint32                              Mode;
    uint32                              PhyAddr;

    ETH_PhyOps_t                        PhyOps;
    Eth_Port_t                          PortCfg;
    Eth_PhyInfo_t                       PhyInfo;
    ETH_Desc_t                          Desc;
    ETH_Link_t                          LinkInfo;
    ETH_Mii_t                           MiiInfo;
    ETH_Delay_t                         DelayInfo;

    uint32                              RxTotalLen;
    uint32                              RxFrameLen;

    uint8 *                             MacAddrPtr;
    volatile uint8 *                    RxBuff;
    uint32                              RxBuffSize;

    ETHRecvCallback                     RecvCallback;

    uint32                              Overflow_err;
    uint32                              Overflow_cnt;
    boolean                             Initialized;
    boolean                             Setup_flag;
    uint32                              Backup_rxbuf_addr[ETH_RDES_NUM];

#if (CONFIG_FREERTOS_NETWORK == 1)
    TaskHandle_t                        xTask;
#endif
} ETHDev_t;

typedef struct ETHRxDescriptor
{
    uint32                              DataLength;
    uint8 *                             EthBufferPtr;
    uint32                              Overflow;
} ETHRxDescriptor_t;

#endif // SIC_BSP_ETH_TYPEDEF_HEADER
