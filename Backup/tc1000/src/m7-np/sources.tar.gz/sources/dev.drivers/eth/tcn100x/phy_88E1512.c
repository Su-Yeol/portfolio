/*
***************************************************************************************************
*
*   FileName : phy_88E1512.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#if (CONFIG_PHY_88E1512 == 1)

#include "phy_88E1512.h"

/*************************************************************************************************/
/*                                      LOCAL VARIABLES                                          */
/*************************************************************************************************/

static ETHDev_t *                                   pmac;

/*
***************************************************************************************************
*                                      FUNCTION PROTOTYPES
***************************************************************************************************
*/

/*
***************************************************************************************************
*                                          delay1us
* Function to generate delay.
*
* @param    [In] uiUs  :  time value
* @return   None
* Notes
***************************************************************************************************
*/

static void delay1us
(
   uint32                                           uiUs
)
{
   uint32                              i;
   uint32                              sec;

   i = 0xffUL;
   sec = 0;
   sec = uiUs * (uint32)500UL;

   for (i = 0; i < sec; i++)
   {
       BSP_NOP_DELAY();
   }

   return;
}

/*
***************************************************************************************************
*                                          PHY_88E1512_Read
* Function to read phy register.
*
* @param    [In] uiAddr : phy register device address
* @param    [In] uiReg  : phy register address
* @param    [Out] Ret   : Register data
* @return
* Notes
*       phy read / write data : 16bit
*       Marvell phy mdio interface between GMAC : clause 22
*
***************************************************************************************************
*/

void PHY_88E1512_Read
(
    uint32                                          uiAddr,
    uint32                                          uiReg,
    uint16 *                                        Ret
)
{
    uint32                              uiRet;

    uiRet = 0;

    ETH_MdioWrite(ETH_CON_0, PHY_88E1512_REG_PAGE, uiAddr);
    uiRet = ETH_MdioRead(ETH_CON_0, uiReg);

    *Ret = uiRet;

    return;
}

/*
***************************************************************************************************
*                                          PHY_88E1512_Write
* Function to read phy register.
*
* @param    [In] uiAddr : phy register device address
* @param    [In] uiReg : phy register address
* @param    [In] usData : Data
* @return
* Notes
*       phy read / write data : 16bit
*       Marvell phy mdio interface between GMAC : clause 22
*
***************************************************************************************************
*/

void PHY_88E1512_Write
(
    uint32                                          uiAddr,
    uint32                                          uiReg,
    uint16                                          usData
)
{
    ETH_MdioWrite(ETH_CON_0, PHY_88E1512_REG_PAGE, uiAddr);
    ETH_MdioWrite(ETH_CON_0, uiReg, usData);

    return;
}

void PHY_88E1512_Config
(
    PHY_MS_Mode_t                                   MS_Mode,
    PHY_OP_Mode_t                                   OP_Mode,
    PHY_Speed_Mode_t                                SpeedMode
)
{
    uint16                  reg = 0;

    PHY_88E1512_GetDeviceInfo();

    // RGMII to copper
    // Doc : 88E1512 Getting started guide. Chapter 8.1
    PHY_88E1512_Read(0x12, 20, &reg);

    reg &= ~(0x7);
    PHY_88E1512_Write(0x12, 20, reg);

    reg |= (1<<15);
    PHY_88E1512_Write(0x12, 20, reg);

    //PHY_88E1512_SwReset();

    return;
}

static PHY_Status_t PHY_88E1512_GetDeviceInfo
(
    void
)
{
    uint16                              device_id = 0;
    PHY_Status_t                        ret = PHY_STATUS_ERR;

    pmac[ETH_CON_0].PhyAddr = 0;

    ETH_D("[%s] Try to find valid phy address \n", __func__);
    while(1)
    {
        PHY_88E1512_Read(1, 0x0003, &device_id);

        if((device_id != 0xffff) && (device_id != 0x0))
        {
            ETH_D("[%s] device id : %x , phy addr : %x \n", __func__, device_id, pmac[ETH_CON_0].PhyAddr);
            break;
        }
        else
        {
            pmac[ETH_CON_0].PhyAddr++; // Find valid phy addr.
        }

        if(pmac[ETH_CON_0].PhyAddr > 0xFFF)
        {
            ETH_D("[%s] escape loop \n", __func__);
            break;
        }
    }

    mcu_printf("[%s] Phy Addr : 0x%x \n", pmac[ETH_CON_0].PhyAddr);

    PHY_88E1512_Read(1, 0x0003, &device_id);

    if (MRVL_E1512_ID == (device_id & 0xfff0))   // ignore Revision number
    {
        ret = PHY_STATUS_OK;
        mcu_printf("[%s] Device Id. expected : 0x%x , result : 0x%x\n",
                                __func__, MRVL_E1512_ID, (device_id & 0xfff0));
    }
    else
    {
        ret = PHY_STATUS_ERR;
        mcu_printf("[%s] Invalid device id : %x \n", __func__, (device_id & 0xfff0));
    }

    return ret;
}

static void PHY_88E1512_SwReset
(
    void
)
{
    uint16          reg = 0;
    uint32          timeout = 0;

    // Reset PHY
    PHY_88E1512_Write(0, 0, 0x8000);

    while(1)
    {
        PHY_88E1512_Read(0, 0, &reg);
        if((reg & 0x8000) == 0x0)
        {
            break;
        }

        timeout++;
        if(timeout > 100000)
        {
            mcu_printf("PHY SW reset timeout.\n");
            break;
        }
    }
    return;
}

/*
***************************************************************************************************
*                                          PHY_ReadStatus
* Function to get link status and set operating info.
*
* @param    None
* @return
* Notes
*
***************************************************************************************************
*/

void  PHY_88E1512_ReadStatus
(
    void
)
{
    uint16                              status = 0;

    PHY_88E1512_Read(0, PHY_88E1512_REG_STATUS, &status);

    // Link
    if(status & PHY_88E1512_BIT_LINK)
    {
        pmac[ETH_CON_0].LinkInfo.Link = PHY_TRUE;
    }
    else
    {
        pmac[ETH_CON_0].LinkInfo.Link = PHY_FALSE;
    }

    // Speed
    switch(status & PHY_88E1512_MASK_SPEED)
    {
        case PHY_88E1512_BIT_SPEED_10:
            pmac[ETH_CON_0].LinkInfo.CurSpeed = PHY_SpeedMode_10;
            break;
        case PHY_88E1512_BIT_SPEED_100:
            pmac[ETH_CON_0].LinkInfo.CurSpeed = PHY_SpeedMode_100;
            break;
        case PHY_88E1512_BIT_SPEED_1000:
            pmac[ETH_CON_0].LinkInfo.CurSpeed = PHY_SpeedMode_1000;
            break;
        default:
            pmac[ETH_CON_0].LinkInfo.CurSpeed = PHY_SpeedMode_None;
            mcu_printf("Invaild link speed\n");
            break;
    }

    // Duplex
    if(status & PHY_88E1512_BIT_DUPLEX)
    {
        pmac[ETH_CON_0].LinkInfo.CurDuplex = PHY_Duplex_Full;
    }
    else
    {
        pmac[ETH_CON_0].LinkInfo.CurDuplex = PHY_Duplex_Half;
    }

    ETH_D("[%s] Link : %s , Speed : %d, Duplex : %s\n",
                    __func__,
                    pmac[ETH_CON_0].LinkInfo.Link == 1 ? "Up" : "Down",
                    pmac[ETH_CON_0].LinkInfo.CurSpeed,
                    pmac[ETH_CON_0].LinkInfo.CurDuplex == 1 ? "Full Duplex" : "Half Duplex"
                    );

    return;
}

void PHY_88E1512_Init
(
    ETHDev_t *                                      pMac
)
{
    PHY_Config func1 = &PHY_88E1512_Config;
    PHY_ReadStatus func2 = &PHY_88E1512_ReadStatus;
    PHY_Read func3 = &PHY_88E1512_Read;
    PHY_Write func4 = &PHY_88E1512_Write;

    pmac = pMac;

    // If register function ptr directly to struct, It work unexpectly. (jump wrong PC)
    pmac[ETH_CON_0].PhyOps.Config = func1;
    pmac[ETH_CON_0].PhyOps.ReadStatus = func2;
    pmac[ETH_CON_0].PhyOps.Read = func3;
    pmac[ETH_CON_0].PhyOps.Write = func4;

    return;
}
#endif  // ( CONFIG_PHY_88E1512 == 1 )
