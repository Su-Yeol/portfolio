/*
***************************************************************************************************
*
*   FileName : eth.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_ETH_HEADER
#define SIC_BSP_ETH_HEADER

#if ( SIC_BSP_SUPPORT_DRIVER_ETH == 1 )

#include "eth_mii.h"
#include "eth_mac.h"
#include "eth_dma.h"
#include "eth_desc.h"
#include "eth_reg.h"
#include "eth_typedef.h"

#include "phy_88Q2220.h"
#include "phy_88E1512.h"

#define ETH_FUNC_DBG_ENABLE

/* Option */
//#define ETH_FIXED_LINK
//#define ETH_EXTEND_DESC
//#define ETH_MII_INTR_ENABLE

#ifdef ETH_FUNC_DBG_ENABLE
#define ETH_FUNC_DBG                                mcu_printf("[%s] line %d\n", __func__, __LINE__);
#endif


#ifdef DEBUG_ENABLE
    #define ETH_D(fmt, args...)                     {LOGD(DBG_TAG_GMAC, fmt, ## args)}
    #define ETH_E(fmt, args...)                     {LOGE(DBG_TAG_GMAC, fmt, ## args)}
#else
    #define ETH_D(fmt, args...)
    #define ETH_E(fmt, args...)
#endif

#define BIT(nr)                                     (1UL << (nr))
#define BIT_ULL(nr)                                 (1ULL << (nr))
#define BIT_MASK(nr)                                (1UL << ((nr) % BITS_PER_LONG))
#define BIT_WORD(nr)                                ((nr) / BITS_PER_LONG)
#define BIT_ULL_MASK(nr)                            (1ULL << ((nr) % BITS_PER_LONG_LONG))
#define BIT_ULL_WORD(nr)                            ((nr) / BITS_PER_LONG_LONG)
#define BITS_PER_BYTE                               (8)
#define BITS_PER_LONG                               (32)
#define BITS_PER_LONG_LONG                          (64)

#define GENMASK(h, l) \
   (((~0UL) - (1UL << (l)) + 1) & (~0UL >> (BITS_PER_LONG - 1 - (h))))
#define GENMASK_ULL(h, l) \
   (((~0ULL) - (1ULL << (l)) + 1) & \
    (~0ULL >> (BITS_PER_LONG_LONG - 1 - (h))))

/* ===================== Common ===================== */

#define ETH_TASK_STACK_SIZE                         (1024)
#define ETH_MAX_PACKET_SIZE                         (1514)

/* RX Buffer size must be multiple of 4/8/16 bytes */
#define BUF_SIZE_16KiB                              (16 * 1024)
#define BUF_SIZE_8KiB                               (8 * 1024)
#define BUF_SIZE_4KiB                               (4 * 1024)
#define BUF_SIZE_2KiB                               (2 * 1024)

#define BUFF_SIZE                                   BUF_SIZE_2KiB
#define DEFAULT_MTU                                 (1500)

#define SPEED_1000                                  (1000)
#define SPEED_100                                   (100)
#define SPEED_10                                    (10)

/* Duplex, half or full. */
#define DUPLEX_HALF                                 (0x00)
#define DUPLEX_FULL                                 (0x01)

/* These need to be power of two, and >= 4 */
#define DMA_TX_SIZE                                 (8)
#define DMA_RX_SIZE                                 (8)

/* CSR Frequency Access Defines*/
#define CSR_F_35M                                   (35000000)
#define CSR_F_60M                                   (60000000)
#define CSR_F_100M                                  (100000000)
#define CSR_F_150M                                  (150000000)
#define CSR_F_250M                                  (250000000)
#define CSR_F_300M                                  (300000000)

/* MDC Clock Selection define*/
/* Target MDC clock rate : 1.0 MHz ~ 2.5 MHz */
#define CSR_60_100M                                 (0x0) /* MDC = clk_scr_i/42 */
#define CSR_100_150M                                (0x1) /* MDC = clk_scr_i/62 */
#define CSR_20_35M                                  (0x2) /* MDC = clk_scr_i/16 */
#define CSR_35_60M                                  (0x3) /* MDC = clk_scr_i/26 */
#define CSR_150_250M                                (0x4) /* MDC = clk_scr_i/102 */
#define CSR_250_300M                                (0x5) /* MDC = clk_scr_i/122 */
#define CSR_300_500M                                (0x6) /* MDC = clk_scr_i/204 */
#define CSR_500_800M                                (0x7) /* MDC = clk_scr_i/324 */

/* Test Mode index */
#define RGMII_MODE                                  (1)
#define RMII_MODE                                   (4)
#define MII_MODE                                    (0)
#define PHY_INF_SEL                                 RGMII_MODE

#define ETH_MODE_NORMAL                             (0)
#define ETH_MODE_MAC_LOOPBACK                       (1)
#define ETH_MODE_PHY_LOOPBACK                       (2)

/* Flow Control defines */
#define FLOW_OFF                                    (0)
#define FLOW_RX                                     (1)
#define FLOW_TX                                     (2)
#define FLOW_AUTO                                   (FLOW_TX | FLOW_RX)

#define DEFAULT_DMA_PBL                             (8)

/* DMA STORE-AND-FORWARD Operation Mode */
#define SF_DMA_MODE                                 (1)

#define RGMII_PERICLK_RATE                          (125*1000*1000)
#define RMII_PERICLK_RATE                           (50*1000*1000)
#define MII_PERICLK_RATE                            (125*1000*1000)

static void delay1us
(
    uint32                                          uiUs
);

static void ETH_PhyReset
(
    uint32                                          index
);

static void ETH_SetFilter
(
    uint32                                          index
);

static void ETH_DmaReset
(
    uint32                                          index
);

static void ETH_DmaStartTx
(
    uint32                                          index,
    uint32                                          uiChan
);

static void ETH_DmaStopTx
(
    uint32                                          index,
    uint32                                          uiChan
);

static void ETH_DmaStartRx
(
    uint32                                          index,
    uint32                                          uiChan
);

static void ETH_DmaStopRx
(
    uint32                                          index,
    uint32                                          uiChan
);

static void ETH_DmaInit
(
    uint32                                          index
);

static void ETH_DmaInterrupt
(
    uint32                                          index
);

static void ETH_Isr
(
    uint32                                          index
);

static void ETH_Tx
(
    uint32                                          index,
    uint8 *                                         pBuff,
    uint32                                          uiLen
);

static uint32 ETH_GetIPVersion
(
    uint32                                          uiId
);

static void ETH_SetDefaultInfo
(
    void
);

static void ETH_SetClock
(
    uint32                                          index
);

static void ETH_CoreInit
(
    uint32                                          index,
    uint32                                          uiMode
);

static void ETH_SetPort
(
    uint32                                          index
);

static void ETH_SetSignalDelay
(
    uint32                                          index
);

static void ETH_SetOpmode
(
    uint32                                          index
);

static void ETH_DescInit
(
    uint32                                          index
);

static void ETH_TxRxEnable
(
    uint32                                          index
);

static void ETH_TxRxDisable
(
    uint32                                          index
);

static uint32 ETH_CheckRxOwn
(
    uint32                                          index
);

static void ETH_PlatformInit
(
    uint32                                          index
);

static void ETH_RecvTask_1
(
    void *                                          pArg
);

uint32 ETH_MiiBusyCheck
(
    uint32                                          index
);

uint32 ETH_MdioRead
(
    uint32                                          index,
    uint32                                          uiReg
);

uint32 ETH_MdioWrite
(
    uint32                                          index,
    uint32                                          uiReg,
    uint16                                          uiData
);

/*
***************************************************************************************************
*                                          ETH_PrintPkt
* Function to debug packet data.
*
* @param    [In] pBuf  : Buffer pointer
*           [In] uiLen : Data Length
*           [In] uiDir : TX/RX Direction
* @return   None
* Notes
***************************************************************************************************
*/

void ETH_PrintPkt
(
    uint32                                          index,
    uint8 *                                         pBuf,
    uint32                                          uiLen,
    uint32                                          uiDir
);

/*
***************************************************************************************************
*                                          ETH_DmaStopRx
* Function to update link information from PHY status register.
*
* @param    None
* @return   None
*
***************************************************************************************************
*/

void ETH_UpdateLink
(
    uint32                                          index
);

/*
***************************************************************************************************
*                                          ETH_GetLinkStatus
* Function to get current link status.
*
* @param    None
* @return   LinkStatus (1 : up, 0 : down)
*
***************************************************************************************************
*/

uint32 ETH_GetLinkStatus
(
    uint32                                          index
);

/*
***************************************************************************************************
*                                          ETH_SetMacAddress
* Function to set MAC ADDRESS.
*
* @param    [In] pAddr : Pointer of MAC address data buffer
* @return
* Notes
*
***************************************************************************************************
*/

void ETH_SetMacAddress
(
    uint32                                          index,
    uint8 *                                         pAddr
);

/*
***************************************************************************************************
*                                          ETH_Send
* Function to transmit ethernet packet.
*
* @param    [In] pBuff : Tx data buffer ptr
* @param    [In] uiLen : Tx data length
* @return   None
* Notes
*
***************************************************************************************************
*/

void ETH_Send
(
    uint32                                          index,
    uint8 *                                         pBuff,
    uint32                                          uiLen
);

/*
***************************************************************************************************
*                                          ETH_Rx
* Function to control RX descriptor.
*
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/
void ETH_Rx
(
    uint32                                          index
);

/*
***************************************************************************************************
*                                          ETH_Recv
* Function to transmit ethernet packet.
*
* @param    None
* @return   ETHRxDescriptor_t * : Pointer of Descriptor
* Notes
*
***************************************************************************************************
*/

ETHRxDescriptor_t * ETH_Recv
(
    uint32                                          index
);

/*
***************************************************************************************************
*                                          ETH_SetRecvBuff
* Function to set ptr of recv buffer.
*
* @param    [In] pBuff : Rx data buffer ptr
* @param    [In] uiSize : Rx buffer size
* @return   None
* Notes
*
***************************************************************************************************
*/

void ETH_SetRecvBuff
(
    uint32                                          index,
    uint32                                          desc_idx,
    uint8 *                                         pBuff
);

/*
***************************************************************************************************
*                                          ETH_RegisterTask
* Function to store task info.
*
* @param    [In] xTask : task handle ptr
* @return   None
* Notes
*
***************************************************************************************************
*/

#ifdef CONFIG_FREERTOS_NETWORK
void ETH_RegisterTask
(
    uint32                                          index,
    TaskHandle_t                                    xTask
);
#endif

/*
***************************************************************************************************
*                                          ETH_CreateRecvTask
* Function to create ethernet packet recv task for test.
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/
void ETH_CreateRecvTask_0
(
    uint32                                          uiMode
);

void ETH_CreateRecvTask_1
(
    uint32                                          uiMode
);

/*
***************************************************************************************************
*                                          ETH_SetRecvCallback
* Function to set callback function pointer.
* @param    [In] function : callback function pointer
* @return   None
* Notes
*
***************************************************************************************************
*/

void ETH_SetRecvCallback
(
    uint32                                          index,
    ETHRecvCallback                                 function
);

/*
***************************************************************************************************
*                                          ETH_Prepare
* Function to initailize ethernet.
* @param    [In] uiMode : mode
* @return   None
* Notes
*
***************************************************************************************************
*/

SALRetCode_t ETH_Prepare
(
    uint32                                          index,
    uint32                                          uiMode
);

/*
***************************************************************************************************
*                                          ETH_Init
* Function to initailize ethernet and start tasks.
*
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/

void ETH_Init
(
    void
);

#endif  // ( SIC_BSP_SUPPORT_DRIVER_ETH == 1 )

#endif  // SIC_BSP_ETH_HEADER

