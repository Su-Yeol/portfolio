###################################################################################################
#
#   FileName : ruls.mk
#
#   Copyright (c) Telechips Inc.
#
#   Description :
#
#
###################################################################################################
#
#   TCC Version 1.0
#
#   This source code contains confidential information of Telechips.
#
#   Any unauthorized use without a written permission of Telechips including not limited to
#   re-distribution in source or binary form is strictly prohibited.
#
#   This source code is provided "AS IS" and nothing contained in this source code shall constitute
#   any express or implied warranty of any kind, including without limitation, any warranty of
#   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
#   or other third party intellectual property right. No warranty is made, express or implied,
#   regarding the information's accuracy,completeness, or performance.
#
#   In no event shall Telechips be liable for any claim, damages or other liability arising from,
#   out of or in connection with this source code or the use in the source code.
#
#   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
#   Telechips and Company.
#   This source code is provided "AS IS" and nothing contained in this source code shall constitute
#   any express or implied warranty of any kind, including without limitation, any warranty
#   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
#   copyright or other third party intellectual property right. No warranty is made, express or
#   implied, regarding the information's accuracy, completeness, or performance.
#   In no event shall Telechips be liable for any claim, damages or other liability arising from,
#   out of or in connection with this source code or the use in the source code.
#   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
#   between Telechips and Company.
#
###################################################################################################

SIC_BSP_DEV_DRIVERS_ETH_PATH := $(SIC_BSP_BUILD_CURDIR)

# Paths
VPATH += $(SIC_BSP_DEV_DRIVERS_ETH_PATH)
VPATH += $(SIC_BSP_DEV_DRIVERS_ETH_PATH)/$(SIC_BSP_CHIPSET_FAMILY_NAME)

COMMON_FLAGS += -DSIC_BSP_SUPPORT_DRIVER_ETH=1
# Includes
INCLUDES += -I$(SIC_BSP_DEV_DRIVERS_ETH_PATH)
INCLUDES += -I$(SIC_BSP_DEV_DRIVERS_ETH_PATH)/$(SIC_BSP_CHIPSET_FAMILY_NAME)

SRCS += eth.c
SRCS += eth_reg.c

ifeq ($(SIC_BSP_PHY_88EA1512), y)
COMMON_FLAGS += -DCONFIG_PHY_88E1512=1
SRCS += phy_88E1512.c
endif

ifeq ($(SIC_BSP_PHY_88Q2220), y)
COMMON_FLAGS += -DCONFIG_PHY_88Q2220=1
SRCS += phy_88Q2220.c
endif

