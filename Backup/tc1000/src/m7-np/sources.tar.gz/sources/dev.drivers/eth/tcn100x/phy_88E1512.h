/*
***************************************************************************************************
*
*   FileName : phy_88E1512.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_ETH_88E1512_HEADER
#define SIC_BSP_ETH_88E1512_HEADER

#if (CONFIG_PHY_88E1512 == 1)

#include "eth.h"

#define MRVL_E1512_ID                               (0xDD0)

#define PHY_88E1512_REG_PAGE                        (0x22)

#define PHY_88E1512_REG_STATUS                      (0x11)
    #define PHY_88E1512_MASK_SPEED                  (0xc000)
    #define PHY_88E1512_BIT_SPEED_1000              (0x8000)
    #define PHY_88E1512_BIT_SPEED_100               (0x4000)
    #define PHY_88E1512_BIT_SPEED_10                (0x0)
    #define PHY_88E1512_BIT_DUPLEX                  (0x2000)
    #define PHY_88E1512_BIT_SPDDONE                 (0x0800)
    #define PHY_88E1512_BIT_LINK                    (0x0400)

#define PHY_88E1512_PHY_SCR                         (0x10)
#define PHY_88E1512_PHY_MDI_X_AUTO                  (0x0060)

/* 88E151x PHY defines */
/* Page 2 registers */
#define PHY_88E1512_PHY_MSCR                        (21)
#define PHY_88E1512_RGMII_RX_DELAY                  (1<<5)
#define PHY_88E1512_RGMII_TX_DELAY                  (1<<4)
#define PHY_88E1512_RGMII_RXTX_DELAY                ((1<<5) | (1<<4))

/* Page 3 registers */
#define PHY_88E1512_LED_FUNC_CTRL                   (16)
#define PHY_88E1512_LED_FLD_SZ                      (4)
#define PHY_88E1512_LED0_OFFS                       (0 * PHY_88E1512_LED_FLD_SZ)
#define PHY_88E1512_LED1_OFFS                       (1 * PHY_88E1512_LED_FLD_SZ)
#define PHY_88E1512_LED0_ACT                        (3)
#define PHY_88E1512_LED1_100_1000_LINK              (6)
#define PHY_88E1512_LED_TIMER_CTRL                  (18)
#define PHY_88E1512_INT_EN_OFFS                     (7)

/* Page 18 registers */
#define PHY_88E1512_GENERAL_CTRL                    (20)
#define PHY_88E1512_MODE_SGMII                      (1)
#define PHY_88E1512_RESET_OFFS                      (15)

static void delay1us
(
   uint32                                           uiUs
);

void PHY_88E1512_Read
(
    uint32                                          uiAddr,
    uint32                                          uiReg,
    uint16 *                                        Ret
);

void PHY_88E1512_Write
(
    uint32                                          uiAddr,
    uint32                                          uiReg,
    uint16                                          usData
);

void PHY_88E1512_Config
(
    PHY_MS_Mode_t                                   MS_Mode,
    PHY_OP_Mode_t                                   OP_Mode,
    PHY_Speed_Mode_t                                SpeedMode
);

static PHY_Status_t PHY_88E1512_GetDeviceInfo
(
    void
);

static void PHY_88E1512_SwReset
(
    void
);

void  PHY_88E1512_ReadStatus
(
    void
);

void PHY_88E1512_Init
(
    ETHDev_t *                                      pMac
);

#endif  // ( CONFIG_PHY_88E1512 == 1 )

#endif  // SIC_BSP_ETH_88E1512_HEADER

