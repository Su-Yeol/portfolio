/*
***************************************************************************************************
*
*   FileName : eth.c
*
*   Copyright (c) Telechips Inc.
*
*   Description : Ethernet Driver
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#if ( SIC_BSP_SUPPORT_DRIVER_ETH == 1 )

// for GMAC 5.1a (DWC-ETHERNET-QOS)
#include "eth.h"
#include "debug.h"

//#define ETH_RAW_THP_TEST
// raw packet throughput test (between MAC Layer)
// Call ETH_CreateSendTask(), ETH_CreateRecvTask() in main.c

/*************************************************************************************************/
/*                                      LOCAL VARIABLES                                          */
/*************************************************************************************************/

#define DIRECTION_RX                                (0U)
#define DIRECTION_TX                                (1U)

extern Eth_Port_t                                   Eth_PortCfg[NUM_OF_ETH_CON];
extern Eth_PhyInfo_t                                Eth_PhyDeviceInfo[NUM_OF_ETH_CON];

ETHDev_t                                            h_mac[NUM_OF_ETH_CON];
ETHRxDescriptor_t                                   RxDesc;

// Caution : Consider memory region size before to decide number of descriptor.
//__attribute__((section(".nc_dma_eth"))) ETH_RxDesc_t  RxDesc_0[ETH_RDES_NUM];
//__attribute__((section(".nc_dma_eth"))) ETH_TxDesc_t  TxDesc_0[ETH_TDES_NUM];
//__attribute__((section(".nc_dma_eth"))) ETH_RxDesc_t  RxDesc_1[ETH_RDES_NUM];
//__attribute__((section(".nc_dma_eth"))) ETH_TxDesc_t  TxDesc_1[ETH_TDES_NUM];

// Using buffer allocated in nc_dma_eth section because of FreeRTOS network buffer allocation problem.
//__attribute__((section(".nc_dma_eth"))) uint8         Recv_Buff_0[ETH_RDES_NUM][BUF_SIZE_2KiB];
//__attribute__((section(".nc_dma_eth"))) uint8         Recv_Buff_1[ETH_RDES_NUM][BUF_SIZE_2KiB];


//Ethernet DMA Part Num
/*
 * DMA ETH 48KB
    (ETH0_RDES 16B * 8 = 128 B (0x80))
    (ETH0_TDES 16B * 8 = 128 B (0x80))
    (ETH1_RDES 16B * 8 = 128 B (0x80))
    (ETH1_TDES 16B * 8 = 128 B (0x80))
    (ETH0_FIFO 2KB * 8 = 16 KB (0x4000))
    (ETH1_FIFO 2KB * 8 = 16 KB (0x4000))
*/
#if ( CORTEX_M7_0==1 )
#define ETH_REMAP_PADDR                             (0x30100000UL)
#elif ( CORTEX_M7_1==1 )
#define ETH_REMAP_PADDR                             (0x30200000UL)
#elif ( CORTEX_M7_2==1 )
#define ETH_REMAP_PADDR                             (0x30300000UL)
#elif ( CORTEX_M7_NP==1 )
#define ETH_REMAP_PADDR                             (0x30400000UL)
#endif

typedef enum
{
    ETH_DPN_ETH0_RDESC   = 0UL,
    ETH_DPN_ETH0_TDESC   = 1UL,
    ETH_DPN_ETH1_RDESC   = 2UL,
    ETH_DPN_ETH1_TDESC   = 3UL,
    ETH_DPN_ETH0_FIFO    = 4UL,
    ETH_DPN_ETH1_FIFO    = 5UL,
}ETH_DPN_t;
/*
***************************************************************************************************
*                                      FUNCTION PROTOTYPES
***************************************************************************************************
*/

static uint32 ETH_GetDmaPartition
(
    ETH_DPN_t                                       tPart
);

/*
***************************************************************************************************
*                                          delay1us
* Function to generate delay.
*
* @param    [In] uiUs  :  time value
* @return   None
* Notes
***************************************************************************************************
*/

static void delay1us
(
   uint32                                           uiUs
)
{
   uint32                               uiCnt;
   uint32                               uiSec;

   uiCnt = 0xffUL;
   uiSec = 0;

   uiSec = uiUs * (uint32)500UL;

   for (uiCnt = 0; uiCnt < uiSec; uiCnt++)
   {
       BSP_NOP_DELAY();
   }
}

/*
***************************************************************************************************
*                                          pucGetRXBuffer
* Function to alllocate network buffer.
*
* @param    [In] uxSize  :  buffer size
* @return   None
* Notes
***************************************************************************************************
*/
#ifdef CONFIG_FREERTOS_NETWORK
static uint8_t * pucGetRXBuffer
(
    size_t                                          uxSize
)
{
    TickType_t                          uxBlockTimeTicks = ( 10U );
    NetworkBufferDescriptor_t *         pxBufferDescriptor;
    uint8_t *                           pucReturn = NULL;

    pxBufferDescriptor = pxGetNetworkBufferWithDescriptor(uxSize, uxBlockTimeTicks );

    if( pxBufferDescriptor != NULL )
    {
        pucReturn = pxBufferDescriptor->pucEthernetBuffer;
    }

    return pucReturn;
}
#endif /* NEVER */

#ifdef ETH_RAW_THP_TEST
/*
***************************************************************************************************
*                                          ETH_SendTask
* Function to send packet for throughput test.
*
* @param    None
* @return   None
* Notes
***************************************************************************************************
*/

static void ETH_SendTask_1
(
    void *                                          pArg
)
{
    uint32                              packet_length = 1536;
    const uint8                         test_buf[1536] =
                                        {
                                            0x00, 0x11, 0x22, 0x33, 0x44, 0x55, // dst addr 6 byte
                                            0x00, 0x12, 0x34, 0x56, 0x78, 0x66, // src addr 6 byte
                                            0x08, 0x06,                         // Ether type 2 byte
                                            0x00, 0x01, 0x08, 0x00, 0xee, 0xee, 0xee, 0xee, //data
                                            0x00, 0x12, 0x34, 0x56, 0xff, 0xff, 0xff, 0xff,
                                            0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                            0xc0, 0xa8, 0x01, 0x64,
                                        };

    while(1)
    {
        if(ETH_GetLinkStatus(ETH_CON_1) == 0)
        {
            mcu_printf("Link Down.. waiting for link up.. \n");
            (void) ETH_UpdateLink(ETH_CON_1);
            vTaskDelay(1);
        }
        else
        {
            ETH_Send(ETH_CON_1, &test_buf[0], packet_length);
        }
        // There is no delay to send the packet as much as possible.
    }
}

/*
***************************************************************************************************
*                                          ETH_CreateSendTask
* Function to create send task for throughput test.
*
* @param    None
* @return   None
* Notes
***************************************************************************************************
*/

void ETH_CreateSendTask
(
    uint32                                          index
)
{
    uint8                               ucMacAddress[6] = {0, };
    uint32                              idx = 0;
    uint8 *                             pucbuf;
    SALRetCode_t                        ret = 0;

    ucMacAddress[0] = 0x00;
    ucMacAddress[1] = 0x11;
    ucMacAddress[2] = 0x22;
    ucMacAddress[3] = 0x33;
    ucMacAddress[4] = 0x44;
    ucMacAddress[5] = 0x66 + index;


    ETH_Prepare(index, ETH_MODE_NORMAL);
    ETH_SetMacAddress(index, (uint8 *) &ucMacAddress[0]);

    if(index == ETH_CON_0)
    {
    }
    else if(index == ETH_CON_1)
    {
        uint32                              EthTxTaskId_1 = 0;
        uint32                              EthTxTaskStack_1[ETH_TASK_STACK_SIZE];

        if((SAL_TaskCreate(&EthTxTaskId_1,  (const uint8 *)"ETH 1 Send Task", \
                                 (SALTaskFunc)&ETH_SendTask_1, \
                                 &(EthTxTaskStack_1[0]), \
                                 (uint32)ETH_TASK_STACK_SIZE, \
                                 2, \ // High priority
                                 NULL)) != SAL_RET_SUCCESS)
        {
            ETH_D("Create ETH Send Task : FAIL.\n");
        }
    }
    else
    {
    }
}
#endif

/*
***************************************************************************************************
*                                          ETH_PrintPkt
* Function to debug packet data.
*
* @param    [In] pBuf  : Buffer pointer
*           [In] uiLen : Data Length
*           [In] uiDir : TX/RX Direction
* @return   None
* Notes
***************************************************************************************************
*/

void ETH_PrintPkt
(
    uint32                                          index,
    uint8 *                                         pBuf,
    uint32                                          uiLen,
    uint32                                          uiDir
)
{
    uint32  uiCnt;

    mcu_printf("GMAC %d Packet debug log.\n", index);
    mcu_printf("%s desc index : %d, len = %d byte, buf addr: 0x%x , %s total len : %d byte\n", uiDir == DIRECTION_RX ? "rx" : "tx",
                                        h_mac[index].Desc.CurRx, uiLen, pBuf, uiDir == DIRECTION_RX ? "rx" : "tx", h_mac[index].RxTotalLen);

    for(uiCnt = 0; uiCnt < uiLen; uiCnt++)
    {
        if ((uiCnt % 16) == 0)
        {
            mcu_printf("\n %03x:", uiCnt);
        }

        mcu_printf(" %02x", pBuf[uiCnt]);
    }

    mcu_printf("\n\n");
}

/*
***************************************************************************************************
*                                          ETH_PhyReset
* Function to reset phy device via GPIO control. (hardware reset)
*
* @param    None
* @return   None
* Notes
***************************************************************************************************
*/

static void ETH_PhyReset
(
    uint32                                          index
)
{
    (void)GPIO_Config(h_mac[index].PortCfg.PhyRst, GPIO_FUNC(0)|GPIO_OUTPUT|GPIO_DS(3));

    (void)GPIO_Set(h_mac[index].PortCfg.PhyRst, 0);
    delay1us(10000);
    (void)GPIO_Set(h_mac[index].PortCfg.PhyRst, 1);
}

uint32 ETH_MiiBusyCheck
(
    uint32                                          index
)
{
    uint32  count = 0;
    uint32  base_addr = ETH_BASE_ADDR(index);
    uint32  addr = base_addr + h_mac[index].MiiInfo.Addr;

    while(count < 1000)
    {
        if((SAL_ReadReg(addr) & MII_BUSY) == 1)
        {
            count++;

            if(count == 1000)
            {
                return 1;
            }
        }
        else
        {
            break;
        }
    }

    return 0;
}

/*
***************************************************************************************************
*                                          ETH_MdioRead
* Function to communicate between MAC and PHY.
*
* @param    [In] uiReg : phy register address
* @return   read data
* Notes
*       phy read / write data : 16bit
*       Marvell phy mdio interface between GMAC : clause 22 to 45
*
***************************************************************************************************
*/

uint32 ETH_MdioRead
(
    uint32                                          index,
    uint32                                          uiReg
)
{
    uint32                              uiData;
    uint32                              uiValue;
    uint32                              uiRet;
    uint32                              base_addr = ETH_BASE_ADDR(index);
    uint32                              addr = 0;

    uiData = 0;
    uiValue = MII_BUSY;
    uiRet = 0;

    uiValue |= (h_mac[index].PhyAddr << h_mac[index].MiiInfo.AddrShift) & h_mac[index].MiiInfo.AddrMask;
    uiValue |= (uiReg << h_mac[index].MiiInfo.RegShift) & h_mac[index].MiiInfo.RegMask;
    uiValue |= (h_mac[index].MiiInfo.Csr << h_mac[index].MiiInfo.CsrShift) & h_mac[index].MiiInfo.CsrMask;

    // gmac4
    uiValue |= MII_GMAC4_READ;

    uiRet = ETH_MiiBusyCheck(index);

    if(uiRet != 0)
    {
        mcu_printf("[%s] MDIO BUSY CHECK FAIL. \n ", __func__);
    }

    addr = base_addr + h_mac[index].MiiInfo.Addr;
    SAL_WriteReg(uiValue, addr);

    uiRet = ETH_MiiBusyCheck(index);

    if(uiRet != 0)
    {
        mcu_printf("[%s] MDIO BUSY CHECK FAIL. \n ", __func__);
    }

    /* Read the data from the MII data register */
    addr = base_addr + h_mac[index].MiiInfo.Data;
    uiData = SAL_ReadReg(addr);

    return uiData;
}

/*
***************************************************************************************************
*                                          ETH_MdioWrite
* Function to communicate between MAC and PHY.
*
* @param    [In] uiReg : phy register address
* @param    [In] uiData : data
* @return   result
* Notes
*       phy read / write data : 16bit
*       Marvell phy mdio interface between GMAC : clause 22 to 45
*
***************************************************************************************************
*/

uint32 ETH_MdioWrite
(
    uint32                                          index,
    uint32                                          uiReg,
    uint16                                          uiData
)
{
    uint32                              uiValue;
    uint32                              uiRet;
    uint32                              base_addr = ETH_BASE_ADDR(index);
    uint32                              addr = 0;

    uiValue = MII_BUSY;
    uiRet = 0;

    uiValue |= (h_mac[index].PhyAddr << h_mac[index].MiiInfo.AddrShift)
                & h_mac[index].MiiInfo.AddrMask;
    uiValue |= (uiReg << h_mac[index].MiiInfo.RegShift) & h_mac[index].MiiInfo.RegMask;
    uiValue |= (h_mac[index].MiiInfo.Csr << h_mac[index].MiiInfo.CsrShift)
                & h_mac[index].MiiInfo.CsrMask;

    // for gmac4
    uiValue |= MII_GMAC4_WRITE;

    /* Wait until any existing MII operation is complete */
    uiRet = ETH_MiiBusyCheck(index);

    if(uiRet != 0)
    {
        mcu_printf("[%s] MDIO BUSY CHECK FAIL. \n ", __func__);
    }

    /* Set the MII address register to write */
    addr = base_addr + h_mac[index].MiiInfo.Data;
    SAL_WriteReg(uiData, addr);
    addr = base_addr + h_mac[index].MiiInfo.Addr;
    SAL_WriteReg(uiValue, addr);

    uiRet = ETH_MiiBusyCheck(index);

    if(uiRet != 0)
    {
        mcu_printf("[%s] MDIO BUSY CHECK FAIL. \n ", __func__);
    }

    return uiRet;
}

/*
***************************************************************************************************
*                                          ETH_SetFilter
* Function to set RX packet filter type.
*
* @param    None
* @return   None
* Notes

***************************************************************************************************
*/

static void ETH_SetFilter
(
    uint32                                          index
)
{
    // Packet filtter setting.
    // default : receive all
    (void)SAL_WriteReg(ETH_PKT_RECV_ALL, h_mac[index].BaseAddr + ETH_MAC_PACKET_FILTER);
}

/*
***************************************************************************************************
*                                          ETH_DmaReset
* Function to reset dma channel.
*
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/

static void ETH_DmaReset
(
    uint32                                          index
)
{
    uint32                              uiValue;
    uint32                              uiLimit;

    uint32                              base_addr = h_mac[index].BaseAddr;
    uint32                              addr = 0;

    uiLimit = 100;

    addr = base_addr + DMA_BUS_MODE;
    uiValue = SAL_ReadReg(addr);

    /* DMA SW reset */
    uiValue |= DMA_BUS_MODE_SFT_RESET;
    (void)SAL_WriteReg(uiValue, addr);

    while (uiLimit--)
    {
        if (!(SAL_ReadReg(addr) & DMA_BUS_MODE_SFT_RESET))
        {
            break;
        }

        delay1us(10);
    }

    if (uiLimit == 0)
    {
        mcu_printf("[GMAC %d] SW RESET FAIL. \n", index);
    }
    else
    {
        ETH_D("[GMAC %d] DMA SW RESET DONE. \n", index);
    }
}

/*
***************************************************************************************************
*                                          ETH_DmaStartTx
* Function to start dma channel for tx.
*
* @param    [In] uiChan : Channel index [0~1]
* @return   None
* Notes

*
***************************************************************************************************
*/

static void ETH_DmaStartTx
(
    uint32                                          index,
    uint32                                          uiChan
)
{
    uint32                              base_addr = h_mac[index].BaseAddr;
    uint32                              addr = 0;
    uint32                              uiReg;
    uiReg = 0;

    // Start TX DMA
    addr = base_addr + DMA_CHAN_TX_CONTROL(uiChan);
    uiReg = SAL_ReadReg(addr);
    uiReg |= DMA_CONTROL_ST;
    (void)SAL_WriteReg(uiReg, addr);

    // Interrupt Enable
    addr = base_addr + DMA_CHAN_INTR_ENA(uiChan);
    uiReg = SAL_ReadReg(addr);
    uiReg = DMA_CHAN_INTR_DEFAULT_MASK_4_10;
    (void)SAL_WriteReg(uiReg, addr);
}

/*
***************************************************************************************************
*                                          ETH_DmaStopTx
* Function to stop dma channel for tx.
*
* @param    [In] uiChan : Channel index [0~1]
* @return   None
* Notes
*
***************************************************************************************************
*/

static void ETH_DmaStopTx
(
    uint32                                          index,
    uint32                                          uiChan
)
{
    uint32                              base_addr = h_mac[index].BaseAddr;
    uint32                              addr = 0;
    uint32                              uiReg;

    // Stop TX DMA
    addr = base_addr + DMA_CHAN_TX_CONTROL(uiChan);
    uiReg = SAL_ReadReg(addr);
    uiReg &= ~DMA_CONTROL_ST;
    (void)SAL_WriteReg(uiReg, addr);

    // Interrupt Disable
    addr = base_addr + DMA_CHAN_INTR_ENA(uiChan);
    uiReg = 0;
    (void)SAL_WriteReg(uiReg, addr);
}

/*
***************************************************************************************************
*                                          ETH_DmaStartRx
* Function to start dma channel for rx.
*
* @param    [In] uiChan : Channel index [0~1]
* @return   None
* Notes
*
***************************************************************************************************
*/

static void ETH_DmaStartRx
(
    uint32                                          index,
    uint32                                          uiChan
)
{
    uint32                              base_addr = h_mac[index].BaseAddr;
    uint32                              addr = 0;
    uint32                              uiReg;

    // Start RX DMA
    addr = base_addr + DMA_CHAN_RX_CONTROL(uiChan);
    uiReg = SAL_ReadReg(addr);
    uiReg |= DMA_CONTROL_SR;
    (void)SAL_WriteReg(uiReg, addr);
}

/*
***************************************************************************************************
*                                          ETH_DmaStopRx
* Function to stop dma channel for rx.
*
* @param    [In] uiChan : Channel index [0~1]
* @return   None
* Notes
*
***************************************************************************************************
*/

static void ETH_DmaStopRx
(
    uint32                                          index,
    uint32                                          uiChan
)
{
    uint32                              base_addr = h_mac[index].BaseAddr;
    uint32                              addr = 0;
    uint32                              uiReg;

    // Stop RX DMA
    addr = base_addr + DMA_CHAN_RX_CONTROL(uiChan);
    uiReg = SAL_ReadReg(addr);
    uiReg &= ~DMA_CONTROL_SR;
    (void)SAL_WriteReg(uiReg, addr);
}

/*
***************************************************************************************************
*                                          ETH_DmaInit
* Function to intialize dma channel.
*
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/

static void ETH_DmaInit
(
    uint32                                          index
)
{
    uint32                              uiValue;
    uint32                              base_addr = h_mac[index].BaseAddr;
    uint32                              addr;

    addr = base_addr + DMA_SYS_BUS_MODE;
    uiValue = SAL_ReadReg(addr);

    /* Set the Fixed burst mode */
    uiValue |= DMA_SYS_BUS_FB;

    /* Mixed Burst has no effect when fb is set */
    uiValue |= DMA_SYS_BUS_MB;

    uiValue |= DMA_SYS_BUS_AAL;

    (void)SAL_WriteReg(uiValue, addr);

    uiValue = SAL_ReadReg(addr);
}

/*
***************************************************************************************************
*                                          ETH_DmaInterrupt
* Function to process dma interrupt.
*
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/

static void ETH_DmaInterrupt
(
    uint32                                          index
)
{
    uint32                              base_addr = h_mac[index].BaseAddr;
    uint32                              addr = 0;
    uint32                              uiChan;

    uiChan = 0; // Controller-[index] DMA Channel_X
#if (CONFIG_FREERTOS_NETWORK == 1)
    BaseType_t xHigherPriorityTaskWoken;
#endif

    uint32                              uiStatus;

    uiChan = 0;
    addr = base_addr + DMA_CHAN_STATUS(uiChan);
    uiStatus = SAL_ReadReg(addr);

    ETH_D("DMA intr_status: %08x\n", SAL_ReadReg(base_addr + DMA_STATUS));
    ETH_D("DMA %d intr_status: %08x\n", uiChan, uiStatus);

    /* ABNORMAL interrupts */
    if ((uiStatus & DMA_CHAN_STATUS_AIS))
    {
        if((uiStatus & DMA_CHAN_STATUS_RBU))
        {
            ETH_D("[%s] status : %x (DMA_CHAN_STATUS_RBU) \n", __func__, uiStatus);
        }

        if((uiStatus & DMA_CHAN_STATUS_RPS))
        {
            ETH_D("[%s] status : %x (DMA_CHAN_STATUS_RPS) \n", __func__, uiStatus);
        }

        if((uiStatus & DMA_CHAN_STATUS_RWT))
        {
            ETH_D("[%s] status : %x (DMA_CHAN_STATUS_RWT) \n", __func__, uiStatus);
        }

        if((uiStatus & DMA_CHAN_STATUS_ETI))
        {
            ETH_D("[%s] status : %x (DMA_CHAN_STATUS_ETI) \n", __func__, uiStatus);
        }

        if((uiStatus & DMA_CHAN_STATUS_TPS))
        {
            ETH_D("[%s] status : %x (DMA_CHAN_STATUS_TPS) \n", __func__, uiStatus);
        }

        if((uiStatus & DMA_CHAN_STATUS_FBE))
        {
            ETH_D("[%s] status : %x (DMA_CHAN_STATUS_FBE) \n", __func__, uiStatus);
        }
    }


    /* TX/RX NORMAL interrupts */
    if((uiStatus & DMA_CHAN_STATUS_NIS))
    {
        if((uiStatus & DMA_CHAN_STATUS_RI))
        {
            ETH_D("--RI interrupt\n");
#ifndef ETH_RAW_THP_TEST
#if (CONFIG_FREERTOS_NETWORK == 1)
            if(xIPIsNetworkTaskReady() == pdTRUE)
            {
                xHigherPriorityTaskWoken = pdFALSE;
                vTaskNotifyGiveFromISR(h_mac[index].xTask, &xHigherPriorityTaskWoken);
            }
#endif
#endif
        }

        if((uiStatus & DMA_CHAN_STATUS_TI))
        {
            ETH_D("--TI interrupt\n");
        }
    }

    /* Clear the interrupt by writing a logic 1 to the chanX interrupt
     * status [21-0] expect reserved bits [5-3]
     */
    addr = base_addr + DMA_CHAN_STATUS(uiChan);
    (void)SAL_WriteReg(0xffff, addr);
}

/*
***************************************************************************************************
*                                          ETH_Isr
* Function to handle ethernet interrupt.
*
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/

static void ETH_Isr_0
(
    void *                                          pArg
)
{
    (void)pArg;
    ETH_Isr(ETH_CON_0);
}

static void ETH_Isr_1
(
    void *                                          pArg
)
{
    (void)pArg;

    ETH_Isr(ETH_CON_1);
}

static void ETH_Isr
(
    uint32                                          index
)
{
#ifdef ETH_MII_INTR_ENABLE
    uint32 addr = h_mac[index].BaseAddr + ETH_MAC_INT_STATUS;
    uint32 reg = SAL_ReadReg(addr);

    //ETH_D("ETH_Isr %d , MAIS : 0x%x\n", index, reg);
#endif
    /* To handle DMA interrupts */
    (void)ETH_DmaInterrupt(index);
}

/*
***************************************************************************************************
*                                          ETH_DmaStopRx
* Function to update link information from PHY status register.
*
* @param    None
* @return   None
*
***************************************************************************************************
*/

void ETH_UpdateLink
(
    uint32                                          index
)
{
    uint32                              base_addr = h_mac[index].BaseAddr;
    uint32                              addr = 0;
    uint32                              uiCtrl = 0;
    uint32                              uiNewState;

    uiNewState = 0;

    h_mac[index].PhyOps.ReadStatus();

    if(h_mac[index].Mode > ETH_MODE_NORMAL)
    {
        h_mac[index].LinkInfo.Link = 1;
    }
    if(h_mac[index].LinkInfo.Link)
    {
        addr = base_addr + MAC_CTRL_REG;
        uiCtrl = SAL_ReadReg(addr);

        /* Now we make sure that we can be in full duplex mode.
         * If not, we operate in half-duplex mode. */
        if (h_mac[index].LinkInfo.CurDuplex != h_mac[index].LinkInfo.OldDuplex)
        {
            uiNewState = 1;

            if(!h_mac[index].LinkInfo.CurDuplex)
            {
                uiCtrl &= ~h_mac[index].LinkInfo.Duplex;
            }
            else
            {
                uiCtrl |= h_mac[index].LinkInfo.Duplex;
            }

            h_mac[index].LinkInfo.OldDuplex = h_mac[index].LinkInfo.CurDuplex;
        }

        if (h_mac[index].LinkInfo.OldSpeed != h_mac[index].LinkInfo.CurSpeed)
        {
            uiNewState = 1;
            uiCtrl &= ~h_mac[index].LinkInfo.SpeedMask;

            switch(h_mac[index].LinkInfo.CurSpeed)
            {
                case SPEED_1000:
                    uiCtrl |= h_mac[index].LinkInfo.Speed1000;
                    break;
                case SPEED_100:
                    uiCtrl |= h_mac[index].LinkInfo.Speed100;
                    break;
                case SPEED_10:
                    uiCtrl |= h_mac[index].LinkInfo.Speed10;
                    break;
                default:
                    h_mac[index].LinkInfo.CurSpeed = 0;
                    break;
            }

            h_mac[index].LinkInfo.OldSpeed = h_mac[index].LinkInfo.CurSpeed;
        }

        // addr = base_addr + MAC_CTRL_REG;
        (void)SAL_WriteReg(uiCtrl, addr);

        if (!h_mac[index].LinkInfo.Oldlink)
        {
            uiNewState = 1;
            h_mac[index].LinkInfo.Oldlink = h_mac[index].LinkInfo.Link;
        }
    }
    else if(h_mac[index].LinkInfo.Oldlink)
    {
        uiNewState = 1;
        h_mac[index].LinkInfo.Oldlink = 0;
        h_mac[index].LinkInfo.OldSpeed = 0;
        h_mac[index].LinkInfo.OldDuplex = 0;
    }

    if(uiNewState)
    {
        mcu_printf("Ethernet Link %s [%d Mbps %s-Duplex]\n"
                        , (h_mac[index].LinkInfo.Oldlink == 1) ? "Up" : "Down"
                        , h_mac[index].LinkInfo.OldSpeed
                        , (h_mac[index].LinkInfo.OldDuplex) == 1 ? "Full" : "Half");
    }

}

/*
***************************************************************************************************
*                                          ETH_GetLinkStatus
* Function to get current link status.
*
* @param    None
* @return   LinkStatus (1 : up, 0 : down)
*
***************************************************************************************************
*/

uint32 ETH_GetLinkStatus
(
    uint32                                          index
)
{
    return h_mac[index].LinkInfo.Link;
}

/*
***************************************************************************************************
*                                          ETH_Rx
* Function to control RX descriptor.
*
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/

void ETH_Rx
(
    uint32                                          index
)
{
    uint32                              Cur_Rx = h_mac[index].Desc.CurRx;
    ETH_RxDesc_t *                      pRdes_ptr;

    pRdes_ptr = (ETH_RxDesc_t *) (&h_mac[index].Desc.Rdesc_base[Cur_Rx]);

    ETH_D("DMA Rx start, Rdes ptr : %x \n" , pRdes_ptr);

    pRdes_ptr->Rdes0 = (uint32)h_mac[index].Backup_rxbuf_addr[Cur_Rx];
    pRdes_ptr->Rdes1 = 0;
    pRdes_ptr->Rdes2 = 0;
    pRdes_ptr->Rdes3 = 0;
    pRdes_ptr->Rdes3 |= RDES3_INT_ON_COMPLETION_EN | RDES3_BUFFER1_VALID_ADDR;
    pRdes_ptr->Rdes3 |= RDES3_OWN;

    if(Cur_Rx == (ETH_RDES_NUM -1))
    {
        // Ring tail pointer
        (void)SAL_WriteReg(h_mac[index].Desc.Rdesc_base, h_mac[index].BaseAddr + DMA_CHAN_RX_END_ADDR(0));
    }
    else
    {
        // Ring tail pointer
        (void)SAL_WriteReg((uint32)(&h_mac[index].Desc.Rdesc_base[Cur_Rx]), h_mac[index].BaseAddr + DMA_CHAN_RX_END_ADDR(0));
    }

    h_mac[index].Desc.CurRx++;

    if(h_mac[index].Desc.CurRx >= ETH_RDES_NUM)
    {
        h_mac[index].Desc.CurRx = h_mac[index].Desc.CurRx - ETH_RDES_NUM;
    }
}


/*
***************************************************************************************************
*                                          ETH_Tx
* Function to control TX descriptor to process transmit packet.
*
* @param    [In] pBuff : Buffer pointer
*           [In] uiLen : Data Length
* @return
* Notes
*
***************************************************************************************************
*/

static void ETH_Tx
(
    uint32                                          index,
    uint8 *                                         pBuff,
    uint32                                          uiLen
)
{
    uint32                              Cur_Tx = h_mac[index].Desc.CurTx;
    ETH_TxDesc_t *                      pTdes_ptr;
    uint32                              uiSize;

    uiSize = uiLen;

    pTdes_ptr = (ETH_TxDesc_t *)(&h_mac[index].Desc.Tdesc_base[Cur_Tx]);

    pTdes_ptr->Tdes0 = (uint32)&pBuff[0];

    if(pTdes_ptr->Tdes0 < ETH_REMAP_PADDR)
    {
        pTdes_ptr->Tdes0 += ETH_REMAP_PADDR;
    }

    pTdes_ptr->Tdes1 = 0x0;
    pTdes_ptr->Tdes2 = (uiSize);
    pTdes_ptr->Tdes2 |= TDES2_INTERRUPT_ON_COMPLETION; // Interrupt Enabled on Completion
    pTdes_ptr->Tdes3 |= TDES3_OWN |  TDES3_FIRST_DESCRIPTOR | TDES3_LAST_DESCRIPTOR | uiSize;

    if(Cur_Tx == (ETH_TDES_NUM -1))
    {
        // Ring tail pointer
        (void)SAL_WriteReg((uint32)h_mac[index].Desc.Tdesc_base, h_mac[index].BaseAddr + DMA_CHAN_TX_END_ADDR(0));
    }
    else
    {
        // Ring tail pointer
        (void)SAL_WriteReg((uint32)(&h_mac[index].Desc.Tdesc_base[Cur_Tx+1]), h_mac[index].BaseAddr + DMA_CHAN_TX_END_ADDR(0));
    }

#if 0 // Dump TX/RX Descriptors for Debug
    for(int i = 0; i < ETH_TDES_NUM; i++)
    {
        pTdes_ptr = (volatile uint32 *)(tdes_base + i * ETH_DESC_SIZE);
        mcu_printf("TDesc %d : %x %x %x %x\n ",i, pTdes_ptr[0], pTdes_ptr[1],pTdes_ptr[2], pTdes_ptr[3]);
    }
    for(int i = 0; i < ETH_RDES_NUM; i++)
    {
        volatile uint32 * pRdes_ptr;
        pRdes_ptr = (volatile uint32 *)(rdes_base + i * ETH_DESC_SIZE);
        mcu_printf("RDesc %d : %x %x %x %x\n ",i, pRdes_ptr[0], pRdes_ptr[1],pRdes_ptr[2], pRdes_ptr[3]);
    }
#endif

    h_mac[index].Desc.CurTx++;

    if(h_mac[index].Desc.CurTx == ETH_TDES_NUM)
    {
        h_mac[index].Desc.CurTx = 0;
    }
}

/*
***************************************************************************************************
*                                          ETH_GetIPVersion
* Function to get IP version value.
*
* @param    [In] uiId : Value of GMAC Version register value
* @return   Synopsys ID
* Notes
*
***************************************************************************************************
*/

static uint32 ETH_GetIPVersion
(
    uint32                                          index
)
{

    /* Check Synopsys Id (not available on old chips) */
    uint32                              uiUserId;
    uint32                              uiSynpsId;

    uint32                              base_addr = h_mac[index].BaseAddr;
    uint32                              addr = 0;
    uint32                              reg = 0;

    // MAC Version Check
    addr = base_addr + ETH_MAC_VERSION;
    reg = SAL_ReadReg(addr);

    uiUserId = ((reg & 0x0000ff00) >> 8);
    uiSynpsId = (reg & 0x000000ff);

    mcu_printf("user ID: 0x%x, Synopsys ID (version): 0x%x\n", uiUserId, uiSynpsId);

    return uiSynpsId;
}

static uint32 ETH_GetDmaPartition
(
    ETH_DPN_t                                       tPart
)
{
    const uint32 uiDmaBase = MPU_GetETHBaseAddress();

    uint32 uiDmaAddr;

/*
 * DMA ETH 48KB
    (ETH0_RDES 16B * 8 = 128 B (0x80))
    (ETH0_TDES 16B * 8 = 128 B (0x80))
    (ETH1_RDES 16B * 8 = 128 B (0x80))
    (ETH1_TDES 16B * 8 = 128 B (0x80))
    (ETH0_FIFO 2KB * 8 = 16 KB (0x4000))
    (ETH1_FIFO 2KB * 8 = 16 KB (0x4000))
*/

    //part 0 : rdesc of eth0
    uiDmaAddr = uiDmaBase;

    if((uint32)tPart >= 1UL)
    {
        //part 1 : tdesc of eth0
        uiDmaAddr += (sizeof(ETH_RxDesc_t) * ETH_RDES_NUM);
    }

    if((uint32)tPart >= 2UL)
    {
        //part 2 : rdesc of eth1
        uiDmaAddr += (sizeof(ETH_TxDesc_t) * ETH_TDES_NUM);
    }

    if((uint32)tPart >= 3UL)
    {
        //part 3 : tdesc of eth1
        uiDmaAddr += (sizeof(ETH_RxDesc_t) * ETH_RDES_NUM);
    }

    if((uint32)tPart >= 4UL)
    {
        //part 4 : fifo of eth0
        uiDmaAddr += (sizeof(ETH_TxDesc_t) * ETH_TDES_NUM);
    }

    if((uint32)tPart >= 5UL)
    {
        //part 5 : fifo of eth1
        uiDmaAddr += (ETH_RDES_NUM * BUF_SIZE_2KiB);
    }

    return uiDmaAddr;
}
/*
***************************************************************************************************
*                                          ETH_SetDefaultInfo
* Function to set default value of structure.
*
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/

static void ETH_SetDefaultInfo
(
    void
)
{
    for(uint8 index = 0; index < NUM_OF_ETH_CON; index++)
    {
        SAL_MemSet(&h_mac[index], 0, sizeof(ETHDev_t));

        h_mac[index].BaseAddr               = ETH_BASE_ADDR(index);
        h_mac[index].PortCfg                = Eth_PortCfg[index];
        h_mac[index].PhyAddr                = Eth_PhyDeviceInfo[index].phy_addr;

        if(index == ETH_CON_0)
        {
            h_mac[index].Desc.Rdesc_base    = (ETH_RxDesc_t *)ETH_GetDmaPartition(ETH_DPN_ETH0_RDESC);
            h_mac[index].Desc.Tdesc_base    = (ETH_TxDesc_t *)ETH_GetDmaPartition(ETH_DPN_ETH0_TDESC);
        }
        else if(index == ETH_CON_1)
        {
            h_mac[index].Desc.Rdesc_base    = (ETH_RxDesc_t *)ETH_GetDmaPartition(ETH_DPN_ETH1_RDESC);
            h_mac[index].Desc.Tdesc_base    = (ETH_TxDesc_t *)ETH_GetDmaPartition(ETH_DPN_ETH1_TDESC);
        }

        h_mac[index].LinkInfo.Duplex        = ETH_MAC_CONFIG_DM;
        h_mac[index].LinkInfo.Speed10       = ETH_MAC_CONFIG_PS;
        h_mac[index].LinkInfo.Speed100      = ETH_MAC_CONFIG_FES | ETH_MAC_CONFIG_PS;
        h_mac[index].LinkInfo.Speed1000     = 0;
        h_mac[index].LinkInfo.SpeedMask     = ETH_MAC_CONFIG_FES | ETH_MAC_CONFIG_PS;
        h_mac[index].MiiInfo.Addr           = ETH_MAC_MDIO_ADDR;
        h_mac[index].MiiInfo.Data           = ETH_MAC_MDIO_DATA;
        h_mac[index].MiiInfo.AddrShift      = 21;
        h_mac[index].MiiInfo.AddrMask       = GENMASK(25, 21);
        h_mac[index].MiiInfo.RegShift       = 16;
        h_mac[index].MiiInfo.RegMask        = GENMASK(20, 16);
        h_mac[index].MiiInfo.CsrShift       = 8;
        h_mac[index].MiiInfo.CsrMask        = GENMASK(11, 8);
        h_mac[index].MiiInfo.Csr            = CSR_250_300M;
    }
}

/*
***************************************************************************************************
*                                          ETH_SetMacAddress
* Function to set MAC ADDRESS.
*
* @param    [In] pAddr : Pointer of MAC address data buffer
* @return
* Notes
*
***************************************************************************************************
*/

void ETH_SetMacAddress
(
    uint32                                          index,
    uint8 *                                         pAddr
)
{
    uint8                               default_mac_0[6] = {0x00, 0x12, 0x34, 0x56, 0x78, 0x90};    // GMAC 0 MAC address
    uint8                               default_mac_1[6] = {0x00, 0x12, 0x34, 0x56, 0x78, 0x99};    // GMAC 1 MAC address
    uint32                              uiData;
    uint32                              base_addr = h_mac[index].BaseAddr;
    uint32                              addr = 0;

    uiData = 0;

    if(pAddr == NULL_PTR)
    {
        if(index == ETH_CON_0)
        {
            h_mac[index].MacAddrPtr = default_mac_0;
        }
        else if(index == ETH_CON_1)
        {
            h_mac[index].MacAddrPtr = default_mac_1;
        }
    }
    else
    {
        h_mac[index].MacAddrPtr = pAddr;
    }

    uiData = (h_mac[index].MacAddrPtr[5] << 8) | h_mac[index].MacAddrPtr[4];

    /* For MAC Addr registers se have to set the Address Enable (AE)
     * bit that has no effect on the High Reg 0 where the bit 31 (MO)
     * is RO.
     */

    uiData |= (0 << GMAC_HI_DCS_SHIFT);
    addr = base_addr + ETH_MAC_ADDR_HIGH(0);
    (void)SAL_WriteReg(uiData | GMAC_HI_REG_AE, addr);

    uiData = (h_mac[index].MacAddrPtr[3] << 24) | (h_mac[index].MacAddrPtr[2] << 16)
                | (h_mac[index].MacAddrPtr[1] << 8) | h_mac[index].MacAddrPtr[0];
    addr = base_addr + ETH_MAC_ADDR_LOW(0);
    (void)SAL_WriteReg(uiData, addr);


    // TODO : Make to register additional mac address for controller (ex) add MAC address function)
    // ETH_MAC_ADDR_HIGH(x) , ETH_MAC_ADDR_LOW(x) -> multi mac address + AE bit(address enable)
}


/*
***************************************************************************************************
*                                          ETH_SetPeriClock
* Function to set peri clock rate and enable peri clock.
*
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/

static void ETH_SetClock
(
    uint32                                          index
)
{
    uint32                              uiPhyInf;
    uint32 reg = 0;
    uint32 addr = 0;
    uiPhyInf = PHY_INF_SEL;

    // HSIO Bus Reset and Enable
    addr = 0x48e00000;  // HSIO Sub-System Base
    reg = SAL_ReadReg(addr);

    if(index == 0)
    {
        reg |= (1<<3); // GMAC 0 mask enable
        SAL_WriteReg(reg, addr);
    }
    else if(index == 1)
    {
        reg |= (1<<4); // GMAC 1 mask enable
        SAL_WriteReg(reg, addr);
    }
    else
    {
        // Do nothing. (Invalid index)
    }

    addr += 0x4;    // SW Reset register
    reg = SAL_ReadReg(addr);
    if(index == 0)
    {
        reg |= (1<<3) | (1<<4) | (1<<5);
        SAL_WriteReg(reg, addr);
    }
    else if(index == 1)
    {
        reg |= (1<<6) | (1<<7) | (1<<8);
        SAL_WriteReg(reg, addr);
    }
    else
    {
        // Do nothing. (Invalid index)
    }

    if((uiPhyInf == RMII_MODE))
    {
        (void)CLOCK_SetPeriRate(CLOCK_PERI_GMAC0 + (index * 2), RMII_PERICLK_RATE);   // GMAC controller
    }
    else if(uiPhyInf == MII_MODE)
    {
        (void)CLOCK_SetPeriRate(CLOCK_PERI_GMAC0 + (index * 2), MII_PERICLK_RATE);
    }
    else
    {
        (void)CLOCK_SetPeriRate(CLOCK_PERI_GMAC0 + (index * 2), RGMII_PERICLK_RATE);
    }

    (void)CLOCK_EnablePeri(CLOCK_PERI_GMAC0 + (index * 2));
}

/*
***************************************************************************************************
*                                          ETH_CoreInit
* Function to set MAC configuration.
*
* @param    [In] uiMode : Mode
* @return   None
* Notes
*
***************************************************************************************************
*/

static void ETH_CoreInit
(
    uint32                                          index,
    uint32                                          uiMode
)
{
    uint32                              base_addr = h_mac[index].BaseAddr;
    uint32                              addr;
    uint32                              uiValue;

    addr = base_addr + ETH_MAC_CONFIG;
    uiValue = ETH_DEFAULT_CORE_INIT;

    if(uiMode == PHY_OpMode_Loopback_MAC)
    {
        mcu_printf("Set MAC%d loopback Mode ! \n", index);
        uiValue |= ETH_MAC_CONFIG_LM;
    }

    (void)SAL_WriteReg(uiValue, addr);
    ETH_D("MAC%d_CONFIG set value: %08x\n", index, SAL_ReadReg(addr));


#ifdef ETH_MII_INTR_ENABLE
    // MII interrupt Enable
    addr = base_addr + ETH_MAC_INT_EN;
    uiValue = SAL_ReadReg(addr);
    uiValue |= (1<<18); // MDIO Interrupt enable bit
    SAL_WriteReg(uiValue, addr);
#endif
}

/*
***************************************************************************************************
*                                          ETH_SetPort
* Function to set HW Port config.
*
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/

static void ETH_SetPort
(
    uint32                                          index
)
{
    uint32                              uiPhyInf;
    uint32                              reg;
    uint32                              addr;
    uint32                              base_addr = h_mac[index].BaseAddr;

    reg = 0;
    addr = 0;
    uiPhyInf = PHY_INF_SEL;

    (void)GPIO_Config(h_mac[index].PortCfg.Mdc , GPIO_FUNC(1)|GPIO_OUTPUT|GPIO_DS(3));
    (void)GPIO_Config(h_mac[index].PortCfg.Mdio , GPIO_FUNC(1)|GPIO_INPUT|GPIO_INPUTBUF_EN|GPIO_DS(3));

    if(uiPhyInf == RMII_MODE)
    {
        (void)GPIO_Config(h_mac[index].PortCfg.Txclk , GPIO_FUNC(1)|GPIO_INPUT|GPIO_INPUTBUF_EN|GPIO_OUTPUT|GPIO_DS(3));
    }
    else
    {
        (void)GPIO_Config(h_mac[index].PortCfg.Txclk , GPIO_FUNC(1)|GPIO_OUTPUT|GPIO_DS(3));
    }

    (void)GPIO_Config(h_mac[index].PortCfg.Txd_0 , GPIO_FUNC(1)|GPIO_OUTPUT|GPIO_DS(3));
    (void)GPIO_Config(h_mac[index].PortCfg.Txd_1 , GPIO_FUNC(1)|GPIO_OUTPUT|GPIO_DS(3));

    if((uiPhyInf == RGMII_MODE) || (uiPhyInf == MII_MODE))
    {
        (void)GPIO_Config(h_mac[index].PortCfg.Txd_2 , GPIO_FUNC(1)|GPIO_OUTPUT|GPIO_DS(3));
        (void)GPIO_Config(h_mac[index].PortCfg.Txd_3 , GPIO_FUNC(1)|GPIO_OUTPUT|GPIO_DS(3));
    }

    (void)GPIO_Config(h_mac[index].PortCfg.Txen , GPIO_FUNC(1)|GPIO_OUTPUT|GPIO_DS(3));

    (void)GPIO_Config(h_mac[index].PortCfg.Rxclk , GPIO_FUNC(1)|GPIO_INPUT|GPIO_INPUTBUF_EN);
    (void)GPIO_Config(h_mac[index].PortCfg.Rxd_0 , GPIO_FUNC(1)|GPIO_INPUT|GPIO_INPUTBUF_EN);
    (void)GPIO_Config(h_mac[index].PortCfg.Rxd_1 , GPIO_FUNC(1)|GPIO_INPUT|GPIO_INPUTBUF_EN);

    if((uiPhyInf == RGMII_MODE) || (uiPhyInf == MII_MODE))
    {
        (void)GPIO_Config(h_mac[index].PortCfg.Rxd_2 , GPIO_FUNC(1)|GPIO_INPUT|GPIO_INPUTBUF_EN);
        (void)GPIO_Config(h_mac[index].PortCfg.Rxd_3 , GPIO_FUNC(1)|GPIO_INPUT|GPIO_INPUTBUF_EN);
    }

    (void)GPIO_Config(h_mac[index].PortCfg.Rxdv , GPIO_FUNC(1)|GPIO_INPUT|GPIO_INPUTBUF_EN);

    addr = base_addr + ETH_CFG_REG_OFFSET + ETH_CFG0_OFFSET;
    reg = 0;
    SAL_WriteReg(reg, addr);

    // CFG1 : Clock enable / PHY interface select / Tx clock enable
    addr = base_addr + ETH_CFG_REG_OFFSET + ETH_CFG1_OFFSET;
    reg = 0;
    reg |= ETH_CFG1_TCO;
    reg |= (uiPhyInf & ETH_CFG1_PHY_INFSEL_MASK) << ETH_CFG1_PHY_INFSEL_SHIFT;
    reg |= ETH_CFG1_CE;
    SAL_WriteReg(reg, addr);

    //(void)ETH_PhyReset();
}

/*
***************************************************************************************************
*                                          ETH_SetSignalDelay
* Function to modify RGMII/RMII/MII signal delay.
*
* @param    None
* @return   None
* Notes
*           delay [value] ns
*
***************************************************************************************************
*/

static void ETH_SetSignalDelay
(
    uint32                                          index
)
{
    uint32 base_addr = h_mac[index].BaseAddr;
    uint32 addr = 0;
    uint32 reg = 0;

    // Set Delay : TXC , TXEN
    reg = 0;
    reg |= (h_mac[index].DelayInfo.Txc << ETH_DLY_TXC_O_SHIFT);
    reg |= (h_mac[index].DelayInfo.TxcInv << ETH_DLY_TXC_O_INV_SHIFT);
    reg |= (h_mac[index].DelayInfo.Txen << ETH_DLY_TXEN_SHIFT);

    addr = base_addr + ETH_DLY_REG_OFFSET + ETH_DLY0_OFFSET;
    (void)SAL_WriteReg(reg, addr);

    // Set Delay : TXD[0:3]
    reg = 0;
    reg |= (h_mac[index].DelayInfo.Txd0 << ETH_DLY_TXD0_SHIFT);
    reg |= (h_mac[index].DelayInfo.Txd1 << ETH_DLY_TXD1_SHIFT);
    reg |= (h_mac[index].DelayInfo.Txd2 << ETH_DLY_TXD2_SHIFT);
    reg |= (h_mac[index].DelayInfo.Txd3 << ETH_DLY_TXD3_SHIFT);

    addr = base_addr + ETH_DLY_REG_OFFSET + ETH_DLY1_OFFSET;
    (void)SAL_WriteReg(reg, addr);

    // Set Delay : RXC, RXDV
    reg = 0;
    reg |= (h_mac[index].DelayInfo.Rxc << ETH_DLY_RXC_I_SHIFT);
    reg |= (h_mac[index].DelayInfo.RxcInv << ETH_DLY_RXC_I_INV_SHIFT);
    reg |= (h_mac[index].DelayInfo.Rxdv << ETH_DLY_RXDV_SHIFT);

    addr = base_addr + ETH_DLY_REG_OFFSET + ETH_DLY3_OFFSET;
    (void)SAL_WriteReg(reg, addr);

    // Set Delay : RXD[0:3]
    reg = 0;
    reg |= (h_mac[index].DelayInfo.Rxd0 << ETH_DLY_RXD0_SHIFT);
    reg |= (h_mac[index].DelayInfo.Rxd1 << ETH_DLY_RXD1_SHIFT);
    reg |= (h_mac[index].DelayInfo.Rxd2 << ETH_DLY_RXD2_SHIFT);
    reg |= (h_mac[index].DelayInfo.Rxd3 << ETH_DLY_RXD3_SHIFT);

    addr = base_addr + ETH_DLY_REG_OFFSET + ETH_DLY1_OFFSET;
    (void)SAL_WriteReg(reg, addr);
}

/*
***************************************************************************************************
*                                          ETH_SetOpmode
* Function to set operation mode for HW Queue & DMA channel.
*
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/

static void ETH_SetOpmode
(
    uint32                                          index
)
{
    uint32                              base_addr = h_mac[index].BaseAddr;
    uint32                              addr = 0;
    uint32                              uiValue;

    // MTL RxQ0 operation mode.
    // Threshold mode. full packet will be transferred
    addr = base_addr + + ETH_MAC_RXQ0_OP_MODE;
    //uiValue = 0x1F00000;
    uiValue = 0x1F00020; // +SF mode

    (void)SAL_WriteReg(uiValue, addr);

    // MTL TxQ0 operation mode
    // Threshold mode. Full packet will be transferred
    addr = base_addr + ETH_MAC_TXQ0_OP_MODE;
    //uiValue = 0xF0078; // TX Threshold : max 512 byte
    uiValue = 0xF000a; // +SF mode
    (void)SAL_WriteReg(uiValue, addr);

    // DMA Channel operation mode
    // Set PBL
    addr = base_addr + DMA_CHAN_CONTROL(0);
    (void)SAL_WriteReg((1 << DMA_BUS_MODE_PBL_SHIFT), addr);
    addr = base_addr + DMA_CHAN_TX_CONTROL(0);
    (void)SAL_WriteReg((DEFAULT_DMA_PBL << DMA_BUS_MODE_PBL_SHIFT), addr);
    addr = base_addr + DMA_CHAN_RX_CONTROL(0);
    (void)SAL_WriteReg((DEFAULT_DMA_PBL << DMA_BUS_MODE_RPBL_SHIFT), addr);

    // RXQ0-2EN ( EN_AV )
    addr = base_addr + ETH_MAC_RXQ_CTRL0;
    (void)SAL_WriteReg(0x2, addr);

}

/*
***************************************************************************************************
*                                          ETH_DescInit
* Function to initialize TX/RX descriptors.
*
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/

static void ETH_DescInit
(
    uint32                                          index
)
{
    uint32                              base_addr = h_mac[index].BaseAddr;
    uint32                              addr = 0;
    uint32                              reg = 0;

    for(uint32 desc_idx = 0; desc_idx < ETH_TDES_NUM; desc_idx++)
    {
        SAL_MemSet(&h_mac[index].Desc.Tdesc_base[desc_idx], 0, sizeof(ETH_TxDesc_t));
        SAL_MemSet(&h_mac[index].Desc.Rdesc_base[desc_idx], 0, sizeof(ETH_RxDesc_t));
    }

    // Set TX/RX Descriptor Base Address
    // RDES
    addr = base_addr + DMA_CHAN_RX_BASE_ADDR(0);
    reg = (uint32) h_mac[index].Desc.Rdesc_base;
    (void)SAL_WriteReg(reg, addr);
    // TDES
    addr = base_addr + DMA_CHAN_TX_BASE_ADDR(0);
    reg = (uint32) h_mac[index].Desc.Tdesc_base;
    (void)SAL_WriteReg(reg, addr);

    // Set Tx/Rx Ring Length
    addr = base_addr + DMA_CHAN_RX_RING_LEN(0);
    (void)SAL_WriteReg((ETH_RDES_NUM - 1), addr);
    addr = base_addr + DMA_CHAN_TX_RING_LEN(0);
    (void)SAL_WriteReg((ETH_TDES_NUM - 1), addr);

    // Set Tail Address
    addr = base_addr + DMA_CHAN_RX_END_ADDR(0);
    reg = (uint32)(&h_mac[index].Desc.Rdesc_base[ETH_RDES_NUM] + (ETH_DESC_SIZE * ETH_RDES_NUM));
    (void)SAL_WriteReg(reg , addr);
    ETH_D("RDES Tail Address: %x\n", SAL_ReadReg(addr));
}

/*
***************************************************************************************************
*                                          ETH_TxRxEnable
* Function to set TX/RX enable bit in MAC configuration register.
*
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/

static void ETH_TxRxEnable
(
    uint32                                          index
)
{
    uint32                              base_addr = h_mac[index].BaseAddr;
    uint32                              addr = 0;
    uint32                              uiReg;

    addr = base_addr + ETH_MAC_CONFIG;
    uiReg = SAL_ReadReg(addr);
    uiReg |= (ETH_MAC_CONFIG_RE) | (ETH_MAC_CONFIG_TE);

    (void)SAL_WriteReg(uiReg, addr);
}

/*
***************************************************************************************************
*                                          ETH_TxRxDisable
* Function to clear TX/RX enable bit in MAC configuration register.
*
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/

static void ETH_TxRxDisable
(
    uint32                                          index
)
{
    uint32                              base_addr = h_mac[index].BaseAddr;
    uint32                              addr = 0;
    uint32                              uiReg;

    addr = base_addr + ETH_MAC_CONFIG;
    uiReg = SAL_ReadReg(addr);
    uiReg &= ~((ETH_MAC_CONFIG_RE) | (ETH_MAC_CONFIG_TE));

    (void)SAL_WriteReg(uiReg, addr);
}

/*
***************************************************************************************************
*                                          ETH_CheckRxOwn
* Function to check Rx descriptor OWN bit.
*
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/

static uint32 ETH_CheckRxOwn
(
    uint32                                          index
)
{
    uint32                              Cur_Rx = h_mac[index].Desc.CurRx;
    ETH_RxDesc_t *                      pRdes_ptr;
    uint32                              uiRet;

    uiRet = 0;
    pRdes_ptr = (ETH_RxDesc_t *)(&h_mac[index].Desc.Rdesc_base[Cur_Rx]);

    uiRet = (pRdes_ptr->Rdes3 & RDES3_OWN);

    if(uiRet == 0)
    {
        h_mac[index].RxFrameLen = pRdes_ptr->Rdes3 & RDES3_PACKET_SIZE_MASK;
        if((pRdes_ptr->Rdes3 & RDES3_OVERFLOW_ERROR) != 0)
        {
            h_mac[index].Overflow_err = 1;
        }
    }
    else
    {
        h_mac[index].RxFrameLen = 0;
    }

    return uiRet;
}

/*
***************************************************************************************************
*                                          ETH_PlatformInit
* Function to initailze platform data.
*
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/

static void ETH_PlatformInit
(
    uint32                                          index
)
{
    (void)ETH_SetClock(index);
    (void)ETH_SetPort(index);
    (void)ETH_SetSignalDelay(index);
    (void)ETH_GetIPVersion(index);

    // GMAC interrupt
    if(index == ETH_CON_0)
    {
	    NVIC_IntVectSet(GMAC0_SB_IRQn, (IrqHandler_t)&ETH_Isr_0);
	    NVIC_IntSrcEn(GMAC0_SB_IRQn);
    }
    else if(index == ETH_CON_1)
    {
        NVIC_IntVectSet(GMAC1_SB_IRQn, (IrqHandler_t)&ETH_Isr_1);
        NVIC_IntSrcEn(GMAC1_SB_IRQn);
    }
    else
    {
        // Do nothing. (Invalid index)
    }


}

/*
***************************************************************************************************
*                                          ETH_RecvTask
* Function to process received packet. (for test)
* To use the TCP/IP Layer, use the task implemented in NetworkInterface.c.
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/

static void ETH_RecvTask_0
(
    void *                                          pArg
)
{
    (void)pArg;

    ETHRxDescriptor_t *                 pxETHRxDescriptor;
#ifdef ETH_RAW_THP_TEST
    uint32                              diff_time   = 0;
    uint32                              old_rx_len  = 0;
    uint32                              diff_len    = 0;
    uint32                              first_tick  = 0;
    uint32                              cur_tick    = 0;
    uint32                              old_tick    = 0;
    uint32                              cnt_sec     = 0;
#endif

    mcu_printf("Link Down.. waiting for link up.. \n");

    while (1)
    {
        if(ETH_GetLinkStatus(ETH_CON_0) == 0)
        {
            (void) ETH_UpdateLink((ETH_CON_0));
            SAL_TaskSleep(1);
        }
        else
        {
            pxETHRxDescriptor = ETH_Recv((ETH_CON_0));

            if (pxETHRxDescriptor->DataLength > 0)
            {
#ifdef ETH_RAW_THP_TEST
                if(first_tick == 0)
                {
                    SAL_GetTickCount(&first_tick);
                    old_rx_len = 0;
                    old_tick = first_tick;
                }
                else
                {
                    SAL_GetTickCount(&cur_tick);
                }

                diff_time = cur_tick - old_tick;
                if((diff_time > 1000)) // 1 sec ( 1ms tick * 1000 )
                {
                    old_tick = cur_tick;
                    diff_len = h_mac[ETH_CON_0].RxTotalLen - old_rx_len;
                    old_rx_len = h_mac[ETH_CON_0].RxTotalLen;
                    cnt_sec++;

                    mcu_printf("Ethernet throughput (%d s) : %d bps. (overflow err : %d) \n",
                                cnt_sec, (diff_len * 8) , h_mac[ETH_CON_0].Overflow_cnt);
                }
#else
                ETH_PrintPkt(ETH_CON_0, (uint8 *)pxETHRxDescriptor->EthBufferPtr, pxETHRxDescriptor->DataLength, DIRECTION_RX);
#endif
                (void)ETH_Rx(ETH_CON_0);
            }
            else
            {
                if(pxETHRxDescriptor->Overflow == 1)
                {
                    (void)ETH_Rx(ETH_CON_0);
                }
            }
#ifndef ETH_RAW_THP_TEST
            SAL_TaskSleep(1);
#endif
        }
    }
}

static void ETH_RecvTask_1
(
    void *                                          pArg
)
{
    (void)pArg;

    ETHRxDescriptor_t *                 pxETHRxDescriptor;
#ifdef ETH_RAW_THP_TEST
    uint32                              diff_time   = 0;
    uint32                              old_rx_len  = 0;
    uint32                              diff_len    = 0;
    uint32                              first_tick  = 0;
    uint32                              cur_tick    = 0;
    uint32                              old_tick    = 0;
    uint32                              cnt_sec     = 0;
#endif

    mcu_printf("Link Down.. waiting for link up.. \n");

    while (1)
    {
        if(ETH_GetLinkStatus(ETH_CON_1) == 0)
        {
            (void) ETH_UpdateLink((ETH_CON_1));
            SAL_TaskSleep(1);
        }
        else
        {
            pxETHRxDescriptor = ETH_Recv((ETH_CON_1));

            if (pxETHRxDescriptor->DataLength > 0)
            {
#ifdef ETH_RAW_THP_TEST
                if(first_tick == 0)
                {
                    SAL_GetTickCount(&first_tick);
                    old_rx_len = 0;
                    old_tick = first_tick;
                }
                else
                {
                    SAL_GetTickCount(&cur_tick);
                }

                diff_time = cur_tick - old_tick;
                if((diff_time > 1000)) // 1 sec ( 1ms tick * 1000 )
                {
                    old_tick = cur_tick;
                    diff_len = h_mac[ETH_CON_1].RxTotalLen - old_rx_len;
                    old_rx_len = h_mac[ETH_CON_1].RxTotalLen;
                    cnt_sec++;

                    mcu_printf("Ethernet throughput (%d s) : %d bps. (overflow err : %d) \n",
                                cnt_sec, (diff_len * 8) , h_mac[ETH_CON_1].Overflow_cnt);
                }
#else
                ETH_PrintPkt(ETH_CON_1, (uint8 *)pxETHRxDescriptor->EthBufferPtr, pxETHRxDescriptor->DataLength, DIRECTION_RX);
#endif
                (void)ETH_Rx(ETH_CON_1);
            }
            else
            {
                if(pxETHRxDescriptor->Overflow == 1)
                {
                    (void)ETH_Rx(ETH_CON_1);
                }
            }
#ifndef ETH_RAW_THP_TEST
            SAL_TaskSleep(1);
#endif
        }
    }
}

/*
***************************************************************************************************
*                                          ETH_Send
* Function to transmit ethernet packet.
*
* @param    [In] pBuff : Tx data buffer ptr
* @param    [In] uiLen : Tx data length
* @return   None
* Notes
*
***************************************************************************************************
*/

void ETH_Send
(
    uint32                                          index,
    uint8 *                                         pBuff,
    uint32                                          uiLen
)
{
    if((pBuff != NULL_PTR) && (uiLen != 0))
    {
        ETH_Tx(index, pBuff, uiLen);
    }
}

/*
***************************************************************************************************
*                                          ETH_Recv
* Function to transmit ethernet packet.
*
* @param    None
* @return   ETHRxDescriptor_t * : Pointer of Descriptor
* Notes
*
***************************************************************************************************
*/

ETHRxDescriptor_t * ETH_Recv
(
    uint32                                          index
)
{
    SAL_MemSet(&RxDesc, 0, sizeof(ETHRxDescriptor_t));

    if(ETH_CheckRxOwn(index) == 0)
    {
        if(h_mac[index].RxFrameLen > 0)
        {
            h_mac[index].RxTotalLen += h_mac[index].RxFrameLen;

            RxDesc.DataLength = h_mac[index].RxFrameLen;
            RxDesc.EthBufferPtr = (uint8 *)h_mac[index].Backup_rxbuf_addr[h_mac[index].Desc.CurRx];
        }
        else
        {
            RxDesc.DataLength = 0;
            RxDesc.EthBufferPtr = NULL;

            if(h_mac[index].Overflow_err == 1)
            {
                h_mac[index].Overflow_cnt++;
                RxDesc.Overflow = 1;
                h_mac[index].Overflow_err = 0;
            }
        }

        //ETH_PrintPkt((uint8 *)RxDesc.pucEthernetBuffer, h_mac[index].dRxFrameLen, DIRECTION_RX);
    }
    else
    {
        RxDesc.DataLength = 0;
        RxDesc.EthBufferPtr = NULL;
    }

    return &RxDesc;
}

/*
***************************************************************************************************
*                                          ETH_SetRecvBuff
* Function to set ptr of recv buffer.
*
* @param    [In] pBuff : Rx data buffer ptr
* @param    [In] uiSize : Rx buffer size
* @return   None
* Notes
*
***************************************************************************************************
*/

void ETH_SetRecvBuff
(
    uint32                                          index,
    uint32                                          desc_idx,
    uint8 *                                         pBuff
)
{
    ETH_RxDesc_t *                      pRdes_ptr;
    uint32                              base_addr = h_mac[index].BaseAddr;
    uint32                              addr = 0;

    pRdes_ptr = (ETH_RxDesc_t *) &h_mac[index].Desc.Rdesc_base[desc_idx];

    pRdes_ptr->Rdes0 = (uint32)pBuff;
    h_mac[index].Backup_rxbuf_addr[desc_idx] = (uint32) pBuff;

    pRdes_ptr->Rdes1 = 0;
    pRdes_ptr->Rdes2 = 0;
    pRdes_ptr->Rdes3 = 0;
    pRdes_ptr->Rdes3 |= RDES3_INT_ON_COMPLETION_EN | RDES3_BUFFER1_VALID_ADDR;
    pRdes_ptr->Rdes3 |= RDES3_OWN;

    addr = base_addr + DMA_CHAN_RX_END_ADDR(0);
    (void)SAL_WriteReg((uint32)pRdes_ptr, addr);
}

/*
***************************************************************************************************
*                                          ETH_RegisterTask
* Function to store task info.
*
* @param    [In] xTask : task handle ptr
* @return   None
* Notes
*
***************************************************************************************************
*/

#if (CONFIG_FREERTOS_NETWORK == 1)
void ETH_RegisterTask
(
    uint32                                          index,
    TaskHandle_t                                    xTask
)
{
    h_mac[index].xTask = xTask;
}
#endif

/*
***************************************************************************************************
*                                          ETH_CreateRecvTask
* Function to create ethernet packet recv task.
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/
void ETH_CreateRecvTask_0
(
    uint32                                          uiMode
)
{
    uint8                               ucMacAddress[6] = {0, };
    uint32                              idx = 0;
    uint8 *                             pucbuf;

#ifdef ETH_RAW_THP_TEST
    uint32                              ret = 0;
#endif
    static uint32                       EthRxTaskId = 0;
    static uint32                       EthRxTaskStack[ETH_TASK_STACK_SIZE];

    ucMacAddress[0] = 0x00;
    ucMacAddress[1] = 0x11;
    ucMacAddress[2] = 0x22;
    ucMacAddress[3] = 0x33;
    ucMacAddress[4] = 0x44;
    ucMacAddress[5] = 0x99;

    ETH_Prepare(ETH_CON_0, uiMode);
    ETH_SetMacAddress(ETH_CON_0, (uint8 *) &ucMacAddress[0]);

    for(idx = 0; idx < ETH_RDES_NUM ; idx++)
    {
        // Using buffer allocated in nc_dma_eth section.
        pucbuf = (uint8*)(ETH_GetDmaPartition(ETH_DPN_ETH0_FIFO) + (BUF_SIZE_2KiB * idx));
        ETH_SetRecvBuff(ETH_CON_0, idx, pucbuf);
    }

#ifdef ETH_RAW_THP_TEST
    if (pdPASS != (ret = xTaskCreate(ETH_RecvTask, "GMACRecvTask_0", 1024, (void *) 1, (15), NULL)))
    {
        ETH_E("Create ETH Recv Task : FAIL.\n");
    }
#else
    if((SAL_TaskCreate(&EthRxTaskId,  (const uint8 *)"ETH Recv Task_0", \
                         (SALTaskFunc)&ETH_RecvTask_0, \
                         &(EthRxTaskStack[0]), \
                         (uint32)ETH_TASK_STACK_SIZE, \
                         SAL_PRIO_ETH_RECV, \
                         NULL)) != SAL_RET_SUCCESS)
    {
        ETH_E("Create ETH Recv Task : FAIL.\n");
    }
    else
    {
        mcu_printf("%s\n", __func__);
    }
#endif
}
void ETH_CreateRecvTask_1
(
    uint32                                          uiMode
)
{
    uint8                               ucMacAddress[6] = {0, };
    uint32                              idx = 0;
    uint8 *                             pucbuf;

#ifdef ETH_RAW_THP_TEST
    uint32                              ret = 0;
#endif
    static uint32                       EthRxTaskId = 0;
    static uint32                       EthRxTaskStack[ETH_TASK_STACK_SIZE];

    ucMacAddress[0] = 0x00;
    ucMacAddress[1] = 0x11;
    ucMacAddress[2] = 0x22;
    ucMacAddress[3] = 0x33;
    ucMacAddress[4] = 0x44;
    ucMacAddress[5] = 0x55;

    ETH_Prepare(ETH_CON_1, uiMode);
    ETH_SetMacAddress(ETH_CON_1, (uint8 *) &ucMacAddress[0]);

    for(idx = 0; idx < ETH_RDES_NUM ; idx++)
    {
        // Using buffer allocated in nc_dma_eth section.
        pucbuf = (uint8*)(ETH_GetDmaPartition(ETH_DPN_ETH1_FIFO) + (BUF_SIZE_2KiB * idx));
        ETH_SetRecvBuff(ETH_CON_1, idx, pucbuf);
    }

#ifdef ETH_RAW_THP_TEST
    if (pdPASS != (ret = xTaskCreate(ETH_RecvTask, "GMACRecvTask_1", 1024, (void *) 1, (15), NULL)))
    {
        ETH_E("Create ETH Recv Task : FAIL.\n");
    }
#else
    if((SAL_TaskCreate(&EthRxTaskId,  (const uint8 *)"ETH Recv Task_1", \
                         (SALTaskFunc)&ETH_RecvTask_1, \
                         &(EthRxTaskStack[0]), \
                         (uint32)ETH_TASK_STACK_SIZE, \
                         SAL_PRIO_ETH_RECV, \
                         NULL)) != SAL_RET_SUCCESS)
    {
        ETH_E("Create ETH Recv Task : FAIL.\n");
    }
    else
    {
        mcu_printf("%s\n", __func__);
    }
#endif
}

/*
***************************************************************************************************
*                                          ETH_SetRecvCallback
* Function to set callback function pointer.
* @param    [In] function : callback function pointer
* @return   None
* Notes
*
***************************************************************************************************
*/

void ETH_SetRecvCallback
(
    uint32                                          index,
    ETHRecvCallback                                 function
)
{
    h_mac[index].RecvCallback = function;
};

/*
***************************************************************************************************
*                                          ETH_Prepare
* Function to initailize ethernet.
* @param    [In] uiMode : mode
* @return   None
* Notes
*
***************************************************************************************************
*/

SALRetCode_t ETH_Prepare
(
    uint32                                          index,
    uint32                                          uiMode
)
{
    SALRetCode_t                        ret = SAL_RET_SUCCESS;
    //CLOCK_SetClkCtrlRate(CLOCK_MBUS_HSIO_SUBSYS, 300*1000*1000);
    SAL_WriteReg(0x400122, 0x4b100000 + 0x18);
    mcu_printf("Set HSIO Clock %d \n", CLOCK_GetClkCtrlRate(CLOCK_MBUS_HSIO_SUBSYS));

    if(index > ETH_CON_1)
    {
        ETH_E("Invalid ethernet controller index %d. (valid index : 0~1)\n", index);
        ret = SAL_RET_FAILED;
    }
    else if(h_mac[index].Initialized > 0)
    {
        ETH_E("Ethernet %d is already initialized.\n", index);
        ret = SAL_RET_FAILED;
    }
    else
    {
        (void)ETH_SetDefaultInfo();
        h_mac[index].Mode = uiMode;

        if(h_mac[index].Initialized == 0)
        {
            (void)ETH_PlatformInit(index);
            (void)ETH_SetMacAddress(index, NULL_PTR);
            (void)ETH_DmaReset(index);

            (void)ETH_DmaInit(index);
            (void)ETH_CoreInit(index, uiMode);
            (void)ETH_DescInit(index);

            (void)ETH_SetOpmode(index);
            (void)ETH_SetFilter(index);

            (void)ETH_TxRxEnable(index);

            (void)ETH_DmaStartTx(index, 0);
            (void)ETH_DmaStartRx(index, 0);

            (void)ETH_PhyReset(index);

            if(index == ETH_CON_0) // 88EA1512 PHY device
            {
                (void)PHY_88E1512_Init(&h_mac[0]);

                if(uiMode == PHY_OpMode_Loopback_PHY)
                {
                    h_mac[index].PhyOps.Config(PHY_MS_Mode_MAX, PHY_OpMode_Loopback_PHY, PHY_SpeedMode_1000);
                }
                else
                {
                    h_mac[index].PhyOps.Config(PHY_MS_Mode_MAX, PHY_OpMode_Normal, PHY_SpeedMode_1000);
                }
            }
            else if(index == ETH_CON_1) // 88Q2220 PHY device
            {
                (void)PHY_88Q2220_Init(&h_mac[0]);

                if(uiMode == PHY_OpMode_Loopback_PHY)
                {
                    h_mac[index].PhyOps.Config(PHY_MS_Mode_Slave, PHY_OpMode_Loopback_PHY, PHY_SpeedMode_1000);
                }
                else
                {
                    h_mac[index].PhyOps.Config(PHY_MS_Mode_Slave, PHY_OpMode_Normal, PHY_SpeedMode_1000);
                }
            }
            else
            {

            }

            h_mac[index].Initialized = 1;
        }
        else
        {
            mcu_printf("Controller already initialized ! Skip HW init.\n");
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          ETH_Init
* Function to initailize ethernet and start tasks.
*
* @param    None
* @return   None
* Notes
*
***************************************************************************************************
*/

void ETH_Init
(
    void
)
{
#if 0
    ETH_CreateRecvTask(ETH_MODE_NORMAL);
#endif
}


#endif  // ( SIC_BSP_SUPPORT_DRIVER_ETH == 1 )

