/*
***************************************************************************************************
*
*   FileName : lpa_std.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/


#ifndef LPA_STD_H
#define LPA_STD_H

/****************************************
 *				Include					*
 ****************************************/

/****************************************
 *				Defines					*
 ****************************************/

/****************************************
 *				Enumeration				*
 ****************************************/

/****************************************
 *				Typedefs				*
 ****************************************/

/****************************************
 *		  Constant Definitions			*
 ****************************************/

/****************************************
 *		  Variable Definitions			*
 ****************************************/

/****************************************
 *		  Function Definitions			*
 ****************************************/
extern uint8 (*lpa_u8add)(uint8 a, uint8 b);
extern uint16 (*lpa_u16add)(uint16 a, uint16 b);
extern uint32 (*lpa_u32add)(uint32 a, uint32 b);
extern uint8 (*lpa_u8sub)(uint8 a, uint8 b);
extern uint16 (*lpa_u16sub)(uint16 a, uint16 b);
extern uint16 (*lpa_u16mul)(uint16 a, uint16 b);
extern uint32 (*lpa_u32mul)(uint32 a, uint32 b);

#endif

