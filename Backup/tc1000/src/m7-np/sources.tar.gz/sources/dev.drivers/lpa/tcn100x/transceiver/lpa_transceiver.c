/*
***************************************************************************************************
*
*   FileName : lpa_transceiver.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include "gpio.h"
#include "lpa_transceiver.h"

static void can_trxIC_set_gpio(void)
{
#if (BOARD_TCN1000_EVB)
	// CAN port 0 ~ 3 <<TJA1043TK>>
	(void)GPIO_Config(GPIO_GPE(0UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// CAN_TX[0]
	(void)GPIO_Config(GPIO_GPE(1UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// CAN_RX[0]
	(void)GPIO_Config(GPIO_GPJ(0UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT)); 						// CAN_STB[0]
	(void)GPIO_Config(GPIO_GPJ(1UL), (GPIO_FUNC(0UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// CAN_ERR[0]
	(void)GPIO_Config(GPIO_GPJ(2UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT)); 						// CAN_EN[0]
	(void)GPIO_Config(GPIO_GPK(8UL), (GPIO_FUNC(0UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// CAN_INH[0]
//	(void)GPIO_Config(GPIO_GPL(1UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT)); 						// CAN_WAKE (Not controlled because TPA uses it)

	(void)GPIO_Config(GPIO_GPE(2UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// CAN_TX[1]
	(void)GPIO_Config(GPIO_GPE(3UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// CAN_RX[1]
	(void)GPIO_Config(GPIO_GPJ(3UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT)); 						// CAN_STB[1]
	(void)GPIO_Config(GPIO_GPJ(4UL), (GPIO_FUNC(0UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// CAN_ERR[1]
	(void)GPIO_Config(GPIO_GPJ(5UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT)); 						// CAN_EN[1]
	(void)GPIO_Config(GPIO_GPK(9UL), (GPIO_FUNC(0UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// CAN_INH[1]

	(void)GPIO_Config(GPIO_GPE(4UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// CAN_TX[2]
	(void)GPIO_Config(GPIO_GPE(5UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// CAN_RX[2]
	(void)GPIO_Config(GPIO_GPJ(6UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT)); 						// CAN_STB[2]
	(void)GPIO_Config(GPIO_GPJ(7UL), (GPIO_FUNC(0UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// CAN_ERR[2]
	(void)GPIO_Config(GPIO_GPJ(8UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT)); 						// CAN_EN[2]
	(void)GPIO_Config(GPIO_GPK(10UL), (GPIO_FUNC(0UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// CAN_INH[2]

	(void)GPIO_Config(GPIO_GPE(6UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// CAN_TX[3]
	(void)GPIO_Config(GPIO_GPE(7UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// CAN_RX[3]
	(void)GPIO_Config(GPIO_GPJ(9UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT)); 						// CAN_STB[3]
	(void)GPIO_Config(GPIO_GPJ(10UL), (GPIO_FUNC(0UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// CAN_ERR[3]
	(void)GPIO_Config(GPIO_GPJ(11UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT)); 						// CAN_EN[3]
	(void)GPIO_Config(GPIO_GPK(11UL), (GPIO_FUNC(0UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// CAN_INH[3]

	// CAN port 4 ~ 15 <<MCP2562FD>>
	(void)GPIO_Config(GPIO_GPE(8UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// CAN_TX[4]
	(void)GPIO_Config(GPIO_GPE(9UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// CAN_RX[4]
	(void)GPIO_Config(GPIO_GPJ(15UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT)); 						// CAN_STB
	(void)GPIO_Config(GPIO_GPE(10UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// CAN_TX[5]
	(void)GPIO_Config(GPIO_GPE(11UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// CAN_RX[5]
	(void)GPIO_Config(GPIO_GPE(12UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// CAN_TX[6]
	(void)GPIO_Config(GPIO_GPE(13UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// CAN_RX[6]
	(void)GPIO_Config(GPIO_GPE(14UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// CAN_TX[7]
	(void)GPIO_Config(GPIO_GPE(15UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// CAN_RX[7]
	(void)GPIO_Config(GPIO_GPF(0UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// CAN_TX[8]
	(void)GPIO_Config(GPIO_GPF(1UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// CAN_RX[8]
	(void)GPIO_Config(GPIO_GPF(2UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// CAN_TX[9]
	(void)GPIO_Config(GPIO_GPF(3UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// CAN_RX[9]
	(void)GPIO_Config(GPIO_GPF(4UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// CAN_TX[10]
	(void)GPIO_Config(GPIO_GPF(5UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// CAN_RX[10]
	(void)GPIO_Config(GPIO_GPF(6UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// CAN_TX[11]
	(void)GPIO_Config(GPIO_GPF(7UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// CAN_RX[11]
	(void)GPIO_Config(GPIO_GPF(8UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// CAN_TX[12]
	(void)GPIO_Config(GPIO_GPF(9UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// CAN_RX[12]
	(void)GPIO_Config(GPIO_GPF(10UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// CAN_TX[13]
	(void)GPIO_Config(GPIO_GPF(11UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// CAN_RX[13]
	(void)GPIO_Config(GPIO_GPF(12UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// CAN_TX[14]
	(void)GPIO_Config(GPIO_GPF(13UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// CAN_RX[14]
	(void)GPIO_Config(GPIO_GPF(14UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// CAN_TX[15]
	(void)GPIO_Config(GPIO_GPF(15UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// CAN_RX[15]
#elif (BOARD_TCN1000_GPIO_MUX_SLT)
	uint32 port;
	uint32 val;

#if (SIC_BSP_SUPPORT_DRIVER_PMIO == 1)
#error "For testing LPA on the GPIO_MUX_SLT board, you should disable PMIO driver in menuconfig."
#error "Please disable PMIO driver on all MUCs."
#endif

	port = (1UL<<0UL)|(1UL<<2UL)|(1UL<<3UL)|(1UL<<4UL)|(1UL<<5UL);

	/* change PMIO to GPIO_K */
    val = SAL_ReadReg(0x4B310808UL);
    val |= port;
	SAL_WriteReg(val, 0x4B310808UL);	//1: pin controlled by GPIO

    val = SAL_ReadReg(0x4B31080CUL);
    val |= port;
	SAL_WriteReg(val, 0x4B31080CUL);	//1: input enable

	(void)GPIO_Config(GPIO_GPK(0UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT));						// BS_EN1
	(void)GPIO_Config(GPIO_GPK(2UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT));						// BS_EN3
	(void)GPIO_Config(GPIO_GPK(3UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT));						// BS_EN4
	(void)GPIO_Config(GPIO_GPK(4UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT));						// BS_EN5
	(void)GPIO_Config(GPIO_GPK(5UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT));						// BS_EN2

	// CAN port 0 ~ 3 <<TJA1043TK>>
	(void)GPIO_Config(GPIO_GPE(0UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT));						// CAN_TX[0]
	(void)GPIO_Config(GPIO_GPE(1UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN)); 	// CAN_RX[0]
	(void)GPIO_Config(GPIO_GPI(0UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT));						// CAN_STB[0]
	(void)GPIO_Config(GPIO_GPI(8UL), (GPIO_FUNC(0UL) | GPIO_INPUT | GPIO_INPUTBUF_EN)); 	// CAN_ERR[0]
	(void)GPIO_Config(GPIO_GPI(1UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT));						// CAN_EN[0]
	(void)GPIO_Config(GPIO_GPL(1UL), (GPIO_FUNC(0UL) | GPIO_INPUT | GPIO_INPUTBUF_EN)); 	// CAN_INH[0]
	(void)GPIO_Config(GPIO_GPL(9UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT));						// CAN_WAKE (Not controlled because TPA uses it)

	(void)GPIO_Config(GPIO_GPE(2UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT));						// CAN_TX[1]
	(void)GPIO_Config(GPIO_GPE(3UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN)); 	// CAN_RX[1]
	(void)GPIO_Config(GPIO_GPI(9UL), (GPIO_FUNC(0UL) | GPIO_INPUT | GPIO_INPUTBUF_EN)); 	// CAN_ERR[1]

	(void)GPIO_Config(GPIO_GPE(4UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT));						// CAN_TX[2]
	(void)GPIO_Config(GPIO_GPE(5UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN)); 	// CAN_RX[2]
	(void)GPIO_Config(GPIO_GPI(10UL), (GPIO_FUNC(0UL) | GPIO_INPUT | GPIO_INPUTBUF_EN)); 	// CAN_ERR[2]

	(void)GPIO_Config(GPIO_GPE(6UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT));						// CAN_TX[3]
	(void)GPIO_Config(GPIO_GPE(7UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN)); 	// CAN_RX[3]
	(void)GPIO_Config(GPIO_GPI(11UL), (GPIO_FUNC(0UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// CAN_ERR[3]

	// CAN port 4 ~ 15 <<MCP2562FD>>
	(void)GPIO_Config(GPIO_GPE(8UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT));						// CAN_TX[4]
	(void)GPIO_Config(GPIO_GPE(9UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN)); 	// CAN_RX[4]
	(void)GPIO_Config(GPIO_GPJ(15UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT));						// CAN_STB
	(void)GPIO_Config(GPIO_GPE(10UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT));						// CAN_TX[5]
	(void)GPIO_Config(GPIO_GPE(11UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// CAN_RX[5]
	(void)GPIO_Config(GPIO_GPE(12UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT));						// CAN_TX[6]
	(void)GPIO_Config(GPIO_GPE(13UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// CAN_RX[6]
	(void)GPIO_Config(GPIO_GPE(14UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT));						// CAN_TX[7]
	(void)GPIO_Config(GPIO_GPE(15UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// CAN_RX[7]
	(void)GPIO_Config(GPIO_GPF(0UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT));						// CAN_TX[8]
	(void)GPIO_Config(GPIO_GPF(1UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN)); 	// CAN_RX[8]
	(void)GPIO_Config(GPIO_GPF(2UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT));						// CAN_TX[9]
	(void)GPIO_Config(GPIO_GPF(3UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN)); 	// CAN_RX[9]
	(void)GPIO_Config(GPIO_GPF(4UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT));						// CAN_TX[10]
	(void)GPIO_Config(GPIO_GPF(5UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN)); 	// CAN_RX[10]
	(void)GPIO_Config(GPIO_GPF(6UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT));						// CAN_TX[11]
	(void)GPIO_Config(GPIO_GPF(7UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN)); 	// CAN_RX[11]
	(void)GPIO_Config(GPIO_GPF(8UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT));						// CAN_TX[12]
	(void)GPIO_Config(GPIO_GPF(9UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN)); 	// CAN_RX[12]
	(void)GPIO_Config(GPIO_GPF(10UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT));						// CAN_TX[13]
	(void)GPIO_Config(GPIO_GPF(11UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// CAN_RX[13]
	(void)GPIO_Config(GPIO_GPF(12UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT));						// CAN_TX[14]
	(void)GPIO_Config(GPIO_GPF(13UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// CAN_RX[14]
	(void)GPIO_Config(GPIO_GPF(14UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT));						// CAN_TX[15]
	(void)GPIO_Config(GPIO_GPF(15UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// CAN_RX[15]
#endif
}

static void lin_trxIC_set_gpio(void)
{
	// LIN port 0 ~ 7 <<TJA1021T>>
	(void)GPIO_Config(GPIO_GPG(0UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// LIN_TX[0]
	(void)GPIO_Config(GPIO_GPG(1UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// LIN_RX[0]
	(void)GPIO_Config(GPIO_GPH(9UL), (GPIO_FUNC(0UL) | GPIO_OUTPUT)); 						// LIN_SLP
	(void)GPIO_Config(GPIO_GPG(2UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// LIN_TX[1]
	(void)GPIO_Config(GPIO_GPG(3UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// LIN_RX[1]
	(void)GPIO_Config(GPIO_GPG(4UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// LIN_TX[2]
	(void)GPIO_Config(GPIO_GPG(5UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// LIN_RX[2]
	(void)GPIO_Config(GPIO_GPG(6UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// LIN_TX[3]
	(void)GPIO_Config(GPIO_GPG(7UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// LIN_RX[3]
	(void)GPIO_Config(GPIO_GPG(8UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// LIN_TX[4]
	(void)GPIO_Config(GPIO_GPG(9UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));		// LIN_RX[4]
	(void)GPIO_Config(GPIO_GPG(10UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// LIN_TX[5]
	(void)GPIO_Config(GPIO_GPG(11UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// LIN_RX[5]
	(void)GPIO_Config(GPIO_GPG(12UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// LIN_TX[6]
	(void)GPIO_Config(GPIO_GPG(13UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// LIN_RX[6]
	(void)GPIO_Config(GPIO_GPG(14UL), (GPIO_FUNC(1UL) | GPIO_OUTPUT)); 						// LIN_TX[7]
	(void)GPIO_Config(GPIO_GPG(15UL), (GPIO_FUNC(1UL) | GPIO_INPUT | GPIO_INPUTBUF_EN));	// LIN_RX[7]
}

static void can_trxIC_set_mode(uint32 opMode)
{
#if (BOARD_TCN1000_EVB)
	if (opMode == 1U) {	/* normal mode */
		(void)GPIO_Set(GPIO_GPJ(0UL), 1UL);		// CAN_STB[0]
		(void)GPIO_Set(GPIO_GPJ(2UL), 1UL);		// CAN_EN[0]
		(void)GPIO_Set(GPIO_GPJ(3UL), 1UL);		// CAN_STB[1]
		(void)GPIO_Set(GPIO_GPJ(5UL), 1UL);		// CAN_EN[1]
		(void)GPIO_Set(GPIO_GPJ(6UL), 1UL);		// CAN_STB[2]
		(void)GPIO_Set(GPIO_GPJ(8UL), 1UL);		// CAN_EN[2]
		(void)GPIO_Set(GPIO_GPJ(9UL), 1UL);		// CAN_STB[3]
		(void)GPIO_Set(GPIO_GPJ(11UL), 1UL);	// CAN_EN[3]

		(void)GPIO_Set(GPIO_GPJ(15UL), 0UL);	// CAN_STBY
	}
	else {	/* stanby mode */
		(void)GPIO_Set(GPIO_GPJ(0UL), 0UL);		// CAN_STB[0]
		(void)GPIO_Set(GPIO_GPJ(2UL), 0UL);		// CAN_EN[0]
		(void)GPIO_Set(GPIO_GPJ(3UL), 0UL);		// CAN_STB[1]
		(void)GPIO_Set(GPIO_GPJ(5UL), 0UL);		// CAN_EN[1]
		(void)GPIO_Set(GPIO_GPJ(6UL), 0UL);		// CAN_STB[2]
		(void)GPIO_Set(GPIO_GPJ(8UL), 0UL);		// CAN_EN[2]
		(void)GPIO_Set(GPIO_GPJ(9UL), 0UL);		// CAN_STB[3]
		(void)GPIO_Set(GPIO_GPJ(11UL), 0UL);	// CAN_EN[3]

		(void)GPIO_Set(GPIO_GPJ(15UL), 1UL);	// CAN_STBY
	}
#elif (BOARD_TCN1000_GPIO_MUX_SLT)
	(void)GPIO_Set(GPIO_GPK(0UL), 0UL); 		// BS_EN1 (on)
	(void)GPIO_Set(GPIO_GPK(3UL), 1UL); 		// BS_EN4 (off)
	(void)GPIO_Set(GPIO_GPK(4UL), 1UL); 		// BS_EN5 (off)

	if (opMode == 1U) {	/* normal mode */
		(void)GPIO_Set(GPIO_GPI(0UL), 1UL);		// CAN_STB[0]
		(void)GPIO_Set(GPIO_GPI(1UL), 1UL);		// CAN_EN[0]
		(void)GPIO_Set(GPIO_GPL(9UL), 1UL);		// CAN_WAKE

		(void)GPIO_Set(GPIO_GPJ(15UL), 0UL);	// CAN_STBY
	}
	else {	/* stanby mode */
		(void)GPIO_Set(GPIO_GPI(0UL), 0UL);		// CAN_STB[0]
		(void)GPIO_Set(GPIO_GPI(1UL), 0UL);		// CAN_EN[0]
		(void)GPIO_Set(GPIO_GPL(9UL), 0UL);		// CAN_WAKE

		(void)GPIO_Set(GPIO_GPJ(15UL), 1UL);	// CAN_STBY
	}
#endif
}

static void lin_trxIC_set_mode(uint32 opMode)
{
	if (opMode == 1U) {	/* normal mode */
		(void)GPIO_Set(GPIO_GPH(9UL), 1UL);		// LIN_SLP
	}
	else {	/* stanby mode */
		(void)GPIO_Set(GPIO_GPH(9UL), 0UL);		// LIN_SLP
	}
}

void lpa_trxIC_init(void)
{
	can_trxIC_set_gpio();
	lin_trxIC_set_gpio();
}

void lpa_trxIC_set_mode(uint32 can_flag, uint32 lin_flag, uint32 can_mode, uint32 lin_mode)
{
	if (can_flag != 0UL)
	{
		can_trxIC_set_mode(can_mode);
	}
	if (lin_flag != 0UL)
	{
		lin_trxIC_set_mode(lin_mode);
	}
}


