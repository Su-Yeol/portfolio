/*
***************************************************************************************************
*
*   FileName : lpa_txrx.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/


/****************************************
 *				Include					*
 ****************************************/
#include "lpa_types.h"
#include "lpa_drv.h"
#include "lpa_txrx.h"
#include "lpa_dma.h"

/****************************************
 *		  Variable Definitions			*
 ****************************************/
static uint32 idt_access_value = 0;

/****************************************
 *		  Function Definitions			*
 ****************************************/
static void lpa_txrxErrLog(const stLPA_HBUF_t *buf)
{
	switch(buf->result){
        case (int8)eLPA_SUCCESS:
            LPA_D("lpa_txrxErrLog: result CETRAC_SUCCESS errnum : %x idt :%x\n",buf->result, buf->idt);
            break;
        case (int8)eLPA_UNKNOWN_ERROR:
            LPA_D("lpa_txrxErrLog: result CETRAC_UNKNOWN_ERROR errnum : %x idt :%x\n",buf->result, buf->idt);
            break;
        case (int8)eLPA_TIMEOUT:
            LPA_D("lpa_txrxErrLog: result CETRAC_TIMEOUT errnum : %x idt :%x\n",buf->result, buf->idt);
            break;
        case (int8)eLPA_FIFO_FULL:
            LPA_D("lpa_txrxErrLog: result CETRAC_UNKNOWN errnum : %x idt :%x\n",buf->result, buf->idt);
            break;
        case (int8)eLPA_UNKNOWN_ID:
            LPA_D("lpa_txrxErrLog: result CETRAC_UNKNOWN_CETRAC_ID errnum : %x idt :%x\n",buf->result, buf->idt);
            break;
        case (int8)eLPA_CRC_ERROR:
            LPA_D("lpa_txrxErrLog: result CETRAC_CRC_ERROR errnum : %x idt :%x\n",buf->result, buf->idt);
            break;
        case (int8)eLPA_NO_DATA:
            LPA_D("lpa_txrxErrLog: result CETRAC_NO_DATA errnum : %x idt :%x\n",buf->result, buf->idt);
            break;
        case (int8)eLPA_PROCESSING_DATA:
            LPA_D("lpa_txrxErrLog: result CETRAC_PROCESSING_DATA errnum : %x idt :%x\n",buf->result, buf->idt);
            break;
        default:
            LPA_D("lpa_txrxErrLog: unknown result errnum : %x idt :%x\n",buf->result, buf->idt);
            break;
    }
}

static void lpa_txrxLog(const stLPA_HBUF_t *buf)
{
#if defined(USE_LPA_DEBUG_LOG)
	uint16 i = 0;
	switch(buf->type) {
		case (int8)eLPA_AXI_UNKNOWN:
			LPA_D("[%s] Type: eLPA_AXI_UNKNOWN", __func__);
			break;
		case (int8)eLPA_AXI_WRITE_NO_ANSWER:
			LPA_D("[%s] Type: eLPA_AXI_WRITE_NO_ANSWER", __func__);
			break;
		case (int8)eLPA_AXI_WRITE_WITH_ANSWER:
			LPA_D("[%s] Type: eLPA_AXI_WRITE_WITH_ANSWER", __func__);
			break;
		case (int8)eLPA_AXI_READ:
			LPA_D("[%s] Type: eLPA_AXI_READ", __func__);
			break;
		default:
			LPA_D("[%s] Type: %d", __func__, buf->type);
			break;
	}
	LPA_D("[%s] result: %d", __func__, buf->result);
	LPA_D("[%s] size: %d", __func__, buf->size);
	LPA_D("[%s] idt: %xh", __func__, buf->idt);
	LPA_D("[%s] sn: %xh", __func__, buf->sn);
	LPA_D("[%s] idt_access: %xh", __func__, buf->idt_access);
	LPA_D("[%s] header_crc: %xh", __func__, buf->header_crc);
	LPA_D("[%s] buffer: ", __func__);
#endif
}

static void udelay(uint32 us)
{
    uint32  i = 0;
    uint32  cnt = 0;
    uint32 cycle_per_1us = (uint32)configCPU_CLOCK_HZ / 1000000U;

    cnt = us * cycle_per_1us;
    for (i = 0UL; i < cnt; i++)
    {
         BSP_NOP_DELAY();
    }
}

static uint32 lpa_u64tou32(uint64 in)
{
	uint32 out;
	if(in > UL_MAX)  {
		out = UL_MAX;
		LPA_E("Data loss due to type conversion from U64[%xl] to U32.\n", in);
	}
	else {
		out = (uint32)in;
	}
	return out;
}

static uint64 lpa_reflect(uint64 data, uint8 nBits)
{
	uint8 bit;
	uint64 reflection = 0ULL;

	for(bit = 0; bit < nBits; ++bit) {
		if((data & 0x01ULL) > 0ULL) {
			reflection |= ((uint64)1 << ((nBits-1U)-bit));
		}
		data = (data >> 1);
	}

	return reflection;
}

static uint32 lpa_crc32(const uint8 pSrc[], uint32 size)
{
#if 0
	uint64 comp;
	uint32 rem = UL_MAX;
	uint32 byte;
	uint32 retValue;
	uint8 bit;

	for(byte = 0; byte < size; ++byte) {
		comp = lpa_reflect((uint64)pSrc[byte], 8U);
		rem ^= lpa_u64tou32(comp) << 24;
		for(bit = 8U; bit > 0U; --bit) {
			if((rem & 0x80000000UL) > 0UL){
				rem = (rem << 1) ^ 0x04C11DB7UL;
			}
			else {
				rem = (rem << 1);
			}
		}
	}
	comp = lpa_reflect(rem, 32);
	retValue = lpa_u64tou32(comp) ^ UL_MAX;
#else
	/* approximately 5x speedup */
	uint32 retValue;
	SAL_UtilCrc32((uint8 *)&retValue, (uint8 *)pSrc, size);
#endif
	return retValue;
}

static uint16 lpa_converterReturnValue(int8 result)
{
	uint16 ret = (uint16)eLPA_RET_OK;

	switch(result) {
		case (int8)eLPA_SUCCESS:			ret = (uint16)eLPA_RET_OK;					break;
		case (int8)eLPA_UNKNOWN_ERROR: 		ret = (uint16)eLPA_RET_DEV_UNKNOWN_ERROR;	break;
		case (int8)eLPA_TIMEOUT:			ret = (uint16)eLPA_RET_DEV_TIMEOUT;			break;
		case (int8)eLPA_FIFO_FULL:			ret = (uint16)eLPA_RET_DEV_FIFO_FULL;		break;
		case (int8)eLPA_UNKNOWN_ID:			ret = (uint16)eLPA_RET_DEV_UNKNOWN_ID;		break;
		case (int8)eLPA_CRC_ERROR:			ret = (uint16)eLPA_RET_DEV_CRC_ERROR;		break;
		case (int8)eLPA_NO_DATA:			ret = (uint16)eLPA_RET_DEV_NO_DATA;			break;
		case (int8)eLPA_PROCESSING_DATA:	ret = (uint16)eLPA_RET_DEV_BUSY; 			break;
		default:							ret = (uint16)eLPA_RET_DEV_UNKNOWN_ERROR;	break;
	}

	return ret;
}

static uint16 lpa_getDataSize(const stLPA_HBUF_t *buf)
{
	uint16 ret = 0;
	if(buf->size > LPA_CRC_SIZE) {
		ret = buf->size - (uint16)LPA_CRC_SIZE;
	}
	return ret;
}

static int32 lpa_checkHeaderCRC(const stLPA_HBUF_t *buf)
{
	int32 ret = 0;
	uint32 crc;

	crc = lpa_crc32((const uint8*)buf, LPA_HEADER_SIZE_NO_CRC);
	if(crc != buf->header_crc) {
		LPA_D("Calcurated Header CRC: %08xh", crc);
		ret = (int32)eLPA_RET_DEV_CRC_ERROR;
	}

	return ret;
}

static int32 lpa_checkDataCRC(const stLPA_RBUF_t *buf)
{
	int32 ret = 0;
	uint32 crc1 = 0;
	uint32 crc2 = 0;
	uint32 size = (uint32)lpa_getDataSize(&buf->hdr);

	crc1 = lpa_crc32((const uint8*)buf->data, size);
	SAL_MemCopy(&crc2, &buf->data[size], LPA_CRC_SIZE);
	if(crc1 != crc2) {
		LPA_D("Calcurated Data CRC: %08xh", crc1);
		ret = (int32)eLPA_RET_DEV_CRC_ERROR;
	}

	return ret;
}

static void lpa_fillHeader(stLPA_HBUF_t *buf, uint16 idt, uint16 sn, eLPA_AXI_TYPE_t type)
{
	buf->type = (int8)type;
	buf->idt = idt;
	buf->sn = sn;
	buf->size = 0u;
	if(idt_access_value < UL_MAX) {
		idt_access_value++;
	}
	else {
		idt_access_value = 0;
	}
	buf->idt_access = idt_access_value;
	buf->header_crc = lpa_crc32((uint8*)buf, LPA_HEADER_SIZE_NO_CRC);
	LPA_D("header crc: %xh", buf->header_crc);
}

static int32 lpa_fillBuffer(stLPA_WBUF_t *buf, const stLPA_REQUEST_t *req, eLPA_AXI_TYPE_t type)
{
	int32 ret = (int32)eLPA_RET_OK;
	uint32 crcdata;

	lpa_fillHeader(&buf->hdr, req->idt, req->sn, type);

	if(req->size != 0U) {
		buf->hdr.size = lpa_u16add(req->size, (uint16)LPA_CRC_SIZE);
	}

	if(req->size > 0U) {
		if(req->buffer != NULL) {
			if(SAL_MemCopy(buf->data, req->buffer, req->size) == SAL_RET_SUCCESS) {
				if (req->data_crc != 0U)
				{
					crcdata = req->data_crc;
				}
				else
				{
					crcdata = lpa_crc32((uint8*)buf->data, req->size);
				}
				LPA_D("data crc: %xh", crcdata);
				SAL_MemCopy(&buf->data[req->size], &crcdata, sizeof(uint32));
			}
			else {
				ret = (int32)eLPA_RET_DRV_NG_MEM_FAULT;
			}
		}
		else {
			ret = (int32)eLPA_RET_DRV_NG_INVALID_PARAM;
		}
	}

	return ret;
}

static void lpa_cpyMemToReg(uint32 pdst, const void *psrc, uint32 len)
{
	uint32 i;
	uint8 *pR = NULL;
	if((psrc != NULL) && (pdst != 0U)) {
		volatile uint8 *reg = pNULL;
		(void)SAL_MemCopy(&pR, &psrc, sizeof(uint8 *));
		if(SAL_MemCopy(&reg, &pdst, sizeof(volatile uint8 *)) == SAL_RET_SUCCESS) {
			for(i = 0U; i < len; i++){
				*((volatile uint8 *)(&reg[i])) = pR[i];
			}
		}
		else {
			LPA_E("Failed to copy to memory address for write reuqest");
		}
	}
}

static void lpa_cpyRegtoMem(void *pdst, uint32 psrc, uint32 len)
{
	uint32 i;
	uint8 *pW = NULL;
	if((pdst != NULL) && (psrc != 0U)) {
		volatile uint8 *reg = pNULL;
		(void)SAL_MemCopy(&pW, &pdst, sizeof(uint8 *));
		if(SAL_MemCopy(&reg, &psrc, sizeof(volatile uint8 *)) == SAL_RET_SUCCESS) {
			for(i = 0U; i < len; i++){
				pW[i] = *((volatile uint8 *)(&reg[i]));
			}
		}
		else {
			LPA_E("Failed to copy to memory address for read request\n");
		}
	}
}

static void lpa_writeBufferForReadReq(const stLPA_CTRL_t *pctrl, const stLPA_HBUF_t *buf)
{
#if defined(USE_LPA_DMA)
	lpa_cpyMemToReg(pctrl->dmaBufAddr, buf, LPA_HEADER_SIZE);
	(void)lpa_dma_sendRequest(pctrl, LPA_HEADER_SIZE/4U);
#else
	lpa_cpyMemToReg(pctrl->axiCtrlAddr, buf, LPA_HEADER_SIZE);
#endif
	udelay(0);		// ASIC: 13us, FPGA: 75us
}

static void lpa_writeBuffer(const stLPA_CTRL_t *pctrl, const stLPA_WBUF_t *buf)
{
#if defined(USE_LPA_DMA)
	uint16 txsize = lpa_u16add(LPA_HEADER_SIZE, buf->hdr.size);

	lpa_cpyMemToReg(pctrl->dmaBufAddr, buf, txsize);
	if((txsize % 4U) != 0U) {
		txsize = (txsize/4U)+1U;
	}
	else {
		txsize = txsize/4U;
	}
	(void)lpa_dma_sendRequest(pctrl, txsize);
#else
	lpa_cpyMemToReg(pctrl->axiCtrlAddr, buf, LPA_HEADER_SIZE + buf->hdr.size);
#endif
	udelay(0);		// ASIC: 13us, FPGA: 75us
}

static int32 lpa_readHeader(const stLPA_CTRL_t *pctrl, stLPA_HBUF_t *buf)
{
	int32 ret = 0;

	lpa_cpyRegtoMem(buf, lpa_u32add(pctrl->axiCtrlAddr, LPA_READ_OFFSET), LPA_HEADER_SIZE);
	if(lpa_checkHeaderCRC(buf) != 0) {
		LPA_E("<!> CETRAC_CRC_ERROR at Header <!>\n");
		lpa_txrxLog(buf);
		ret = (int32)eLPA_RET_DEV_CRC_ERROR;
	}

	if(ret == 0) {
		lpa_txrxLog(buf);
	}
	return ret;
}

static int32 lpa_readData(const stLPA_CTRL_t *pctrl, stLPA_RBUF_t *buf)
{
	int32 ret = 0;

	lpa_cpyRegtoMem(buf, lpa_u32add(pctrl->axiCtrlAddr, LPA_READ_OFFSET), LPA_HEADER_SIZE);
	if(lpa_checkHeaderCRC(&buf->hdr) != 0) {
		LPA_E("<!> CETRAC_CRC_ERROR at Header <!>\n");
		lpa_txrxLog(&buf->hdr);
		ret = (int32)eLPA_RET_DEV_CRC_ERROR;
	}
	else {
		if((buf->hdr.result == (int8)eLPA_SUCCESS) && (buf->hdr.size > 0U) && (buf->hdr.size <= LPA_RD_FRAME_MAX_SIZE)) {
#if defined(USE_LPA_DMA)
			uint16 rxsize = (buf->hdr.size)/4U;
			if(((buf->hdr.size) % 4U) != 0U) {
				rxsize++;
			}
			(void)lpa_dma_receiveRequest(pctrl, rxsize);
			lpa_cpyRegtoMem(buf->data, pctrl->dmaBufAddr, buf->hdr.size);
#else
			lpa_cpyRegtoMem(buf->data, pctrl->axiCtrlAddr+LPA_READ_DATA_OFFSET, buf->hdr.size);
#endif
			if(lpa_checkDataCRC(buf) != 0) {
		        LPA_E("<!> CETRAC_CRC_ERROR at Data <!>\n");
				lpa_txrxLog(&buf->hdr);
				ret = (int32)eLPA_RET_DEV_CRC_ERROR;
			}
		}
	}

	if(ret == 0) {
		lpa_txrxLog(&buf->hdr);
	}
	return ret;
}

int32 lpa_writeRequest(const stLPA_CTRL_t *pctrl, const stLPA_REQUEST_t *req, stLPA_RESPONSE_t *res)
{
	int32 ret = 0;
	int32 loop = 0;
	stLPA_WBUF_t wbuf;
	stLPA_HBUF_t rbuf;

	if((req != NULL) && (res != NULL) && (req->size <= (LPA_WR_FRAME_MAX_SIZE - LPA_CRC_SIZE))) {
		SAL_MemSet(&wbuf, 0, sizeof(stLPA_WBUF_t));
		SAL_MemSet(&rbuf, 0, sizeof(stLPA_HBUF_t));
//		ret = lpa_fillBuffer(&wbuf, (int8*)req->buffer, req->size, req->idt, req->sn, eLPA_AXI_WRITE_WITH_ANSWER);
		ret = lpa_fillBuffer(&wbuf, req, eLPA_AXI_WRITE_WITH_ANSWER);
	}
	else {
		ret = (int32)eLPA_RET_DRV_NG_INVALID_PARAM;
	}

	if(ret == 0) {
		LPA_D("lpa_write request...");
		lpa_writeBuffer(pctrl, &wbuf);
		if(wbuf.hdr.size < 1028U) {	// except configuration data
			lpa_txrxLog(&wbuf.hdr);	// test log
		}
		do {
			LPA_D("lpa_readHeader... loop count[%d]", loop);
			ret = lpa_readHeader(pctrl, &rbuf);
			if((rbuf.result == (int8)eLPA_SUCCESS) && (rbuf.idt == wbuf.hdr.idt) &&
			   (rbuf.idt_access == wbuf.hdr.idt_access) && (ret == (int32)eLPA_RET_OK))
			{
				break;	// OK!
			}
			if(rbuf.result == (int8)eLPA_PROCESSING_DATA) {
				udelay(1);
			}
			else {
				lpa_txrxErrLog(&rbuf);
			}
			loop++;
		}while(((rbuf.result == (int8)eLPA_PROCESSING_DATA) || (ret != (int32)eLPA_RET_OK)) && (loop < LPA_RW_RETRY_COUNT));

		res->idt = rbuf.idt;
		res->sn = rbuf.sn;
		res->size = rbuf.size;
		res->ret = lpa_converterReturnValue(rbuf.result);
	}

	return ret;
}

int32 lpa_readRequest(const stLPA_CTRL_t *pctrl, const stLPA_REQUEST_t *req, stLPA_RESPONSE_t *res)
{
	int32 ret = 0;
	int32 loop = 0;
	stLPA_HBUF_t wbuf;
	stLPA_RBUF_t rbuf;

	/* for coverity */
	rbuf.hdr.header_crc = 0U;
	rbuf.hdr.size = 0U;
	rbuf.hdr.type = (int8)0;

	if((req != NULL) && (res != NULL)) {
		if(req->idt == 0xFFFEU) {       // for status frame request
			lpa_fillHeader(&wbuf, req->idt, 0, eLPA_AXI_READ);
		}
		else {
			lpa_fillHeader(&wbuf, 0, 0, eLPA_AXI_READ);
		}
	}
	else {
		ret = (int32)eLPA_RET_DRV_NG_INVALID_PARAM;
	}

	if(ret == 0) {
		LPA_D("lpa_read request...");
		lpa_writeBufferForReadReq(pctrl, &wbuf);
		lpa_txrxLog(&wbuf);
		do {
			LPA_D("lpa_readData... loop count[%d]", loop);
			ret = lpa_readData(pctrl, &rbuf);
			if((rbuf.hdr.result == (int8)eLPA_SUCCESS) && (rbuf.hdr.idt_access == wbuf.idt_access) &&
			   (ret == (int32)eLPA_RET_OK))
			{
				break;	// OK!
			}
			if(rbuf.hdr.result == (int8)eLPA_PROCESSING_DATA) {
				udelay(1);
			}
			else {
				lpa_txrxErrLog(&rbuf.hdr);
			}
			loop++;
		}while(((rbuf.hdr.result == (int8)eLPA_PROCESSING_DATA) || (ret != (int32)eLPA_RET_OK)) && (loop < LPA_RW_RETRY_COUNT));

		res->idt = rbuf.hdr.idt;
		res->sn = rbuf.hdr.sn;
		res->size = rbuf.hdr.size;

		if(rbuf.hdr.size > 0U) {
			if(res->buffer != pNULL) {
				if(SAL_MemCopy(res->buffer, rbuf.data, rbuf.hdr.size) != SAL_RET_SUCCESS) {
					ret = (int32)eLPA_RET_DRV_NG_MEM_FAULT;
					res->ret = (uint16)eLPA_RET_DRV_NG_MEM_FAULT;
				}
				else {
					res->ret = lpa_converterReturnValue(rbuf.hdr.result);
				}
			}
			else {
				ret = (int32)eLPA_RET_DRV_NG_NULL_POINTER_PARAM;
				res->ret = (uint16)eLPA_RET_DRV_NG_NULL_POINTER_PARAM;
			}
		}
		else {
			res->ret = lpa_converterReturnValue(rbuf.hdr.result);
		}
	}

	return ret;
}

