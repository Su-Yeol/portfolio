/*
***************************************************************************************************
*
*   FileName : lpa_types.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/


#ifndef LPA_TYPES_H
#define LPA_TYPES_H

/****************************************
 *				Include					*
 ****************************************/
#include <FreeRTOS.h>
#include <task.h>
#include <semphr.h>
#include <bsp.h>
#include <nvic.h>
#include <string.h>
#include <debug.h>

#include "lpa_drv.h"
#include "lpa_std.h"

/****************************************
 *				Defines					*
 ****************************************/
#ifndef pNULL
#define	pNULL				(void*)(0)
#endif

//#define ENABLE_LPA_DEBUG

#ifdef ENABLE_LPA_DEBUG
#define LPA_D(fmt, args...)         {LOGD(DBG_TAG_LPA, fmt, ## args)}
#else
#define LPA_D(fmt, args...)
#endif
#define LPA_E(fmt, args...)         {LOGE(DBG_TAG_LPA, fmt, ## args)}



/* Version of the Driver */
#define V_RELEASE   (0)
#define V_MAJOR     (1)
#define V_MINOR     (11)
#define DRIVER_VERION_NUMBER   ((V_RELEASE*1000)+(V_MAJOR*100)+ (V_MINOR))

#define USE_LPA_DMA
//#define USE_LPA_DEBUG_LOG

/* Deficition of the Driver Module Name */
#define LPA_DRV_NAME 				"lpa-drv"

#define LPA_LOG_BUF_OFFSET			(0x1000UL)

#define LPA_CTRL_SIZE				(0x4028UL)
#define LPA_DMA_CTRL_SIZE			(0x1000UL)
#define LPA_DMA_BUF_SIZE			(0x2000UL)		// 0x2000 = 8192Byte = 8KB

#define UNUSED(x) 					(void)(x)

// Debug Options
//#define LPA_DBG_DATA

#define S64_MAX	(9223372036854775807LL)
#define S64_MIN	(-S64_MAX-1LL)
#define S32_MAX	(2147483647)
#define S32_MIN	(-2147483648)
#define F32_MAX	(2147483647.0f)
#define F32_MIN	(-2147483648.0f)
#define S16_MAX	(32767)
#define S16_MIN	(-32768)
#define S08_MAX (127)
#define S08_MIN (-128)

#define U64_MAX (18446744073709551615ULL)
#define U32_MAX	(4294967295U)
#define U16_MAX	(65535U)
#define U08_MAX	(255U)

#ifdef LPA_64BIT_SYSTEM
#define L_MAX	(9223372036854775807L)
#define L_MIN	(-L_MAX-1L)
#define UL_MAX	(0xFFFFFFFFFFFFFFFFUL)
#else
#define L_MAX	(0x7FFFFFFFL)
#define L_MIN	(-L_MAX-1L)
#define UL_MAX	(0xFFFFFFFFUL)
#endif

/****************************************
 *				Enumeration				*
 ****************************************/
typedef enum {
	eLPA_PORT_NULL       = 0,
	eLPA_PORT_PROCESSOR  = 1,
	eLPA_PORT_LOGGING    = 2
}eLPA_PORT_t;

typedef enum {
 	eLPA_STATE_CLOSE     = 0,
	eLPA_STATE_OPEN      = 1
}eLPA_STATE_t;

typedef enum {
	eLPA_INT_PROC        = 0,
	eLPA_INT_ERROR       = 1,
	eLPA_INT_LOG         = 2,
	eLPA_INT_MAX         = 3
}eLPA_INT_t;

/****************************************
 *				Typedefs				*
 ****************************************/
typedef struct {
	eLPA_PORT_t devPort;

	// AXI BUS
	uint32 axiCtrlAddr;
	uint32 axiCtrlSize;

	// DMA Control
	uint32 dmaCtrlAddr;
	uint32 dmaCtrlSize;

	// DMA Buffer
	uint32 dmaBufAddr;
	uint32 dmaBufSize;

	// Mutexes
	uint32 semaId;

	// App Task Handler
	TaskHandle_t taskHandler;
}stLPA_CTRL_t;

typedef struct {
	eLPA_STATE_t state;
	uint32 usageCnt;

	stLPA_CTRL_t proc;
	stLPA_CTRL_t logging;

	// Interrupt
	uint32 irqs[eLPA_INT_MAX];
	uint32 irqProcCnt;
	uint32 irqErrorCnt;
	uint32 irqLogCnt;
}stLPA_DRV_t;

/***************************************
*         Variable definitions         *
****************************************/
extern uint32 lpa_dmastart__;		// DMA buffer start address for lpa and defined in tcn1000.ld

#endif

