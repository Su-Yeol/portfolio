/*
***************************************************************************************************
*
*   FileName : lpa_dma.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/


#ifndef LPA_DMA_H
#define LPA_DMA_H

/****************************************
 *				Include					*
 ****************************************/

/****************************************
 *				Defines					*
 ****************************************/
// 0 proc 1 Log
#define PROCESSOR_VALUE	(0U)
#define LOGGING_VALUE	(1U)

#define LPA_MEMORY2FPGA(x) ((0x19U << 11) + ((x) << 1) + ((x) << 6) + 1U)
#define LPA_FPGA2MEMORY(x) ((0x1AU << 11) + ((x) << 1) + ((x) << 6) + 1U)
#define LPA_MEMORY2MEMORY (0x0000C001U)

#define LPA_PROC_WADDR (0x46D00000)
#define LPA_PROC_RADDR (0x46D02028)
#define LPA_LOG_WADDR  (0x46D10000)
#define LPA_LOG_RADDR  (0x46D12028)

/****************************************
 *				Enumeration				*
 ****************************************/
typedef enum {
	eLPA_DMA_CH0    = 0,
	eLPA_DMA_CH1    = 1
}eLPA_DMA_CH_t;

/****************************************
 *				Typedefs				*
 ****************************************/

/****************************************
 *		  Constant Definitions			*
 ****************************************/

/****************************************
 *		  Variable Definitions			*
 ****************************************/

/****************************************
 *		  Function Definitions			*
 ****************************************/
extern void lpa_dma_init(const stLPA_CTRL_t *pstCtrl);
extern void lpa_dma_deinit(const stLPA_CTRL_t *pstCtrl);
extern int32 lpa_dma_sendRequest(const stLPA_CTRL_t *pstCtrl, uint16 size);
extern int32 lpa_dma_receiveRequest(const stLPA_CTRL_t *pstCtrl, uint16 size);

extern void lpa_dma_test_setRequest(const stLPA_CTRL_t *pstCtrl, uint32 srcaddr, uint32 dstaddr, uint16 size);

#endif


