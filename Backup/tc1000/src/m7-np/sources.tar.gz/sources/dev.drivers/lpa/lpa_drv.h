/*
***************************************************************************************************
*
*   FileName : lpa_drv.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/


#ifndef LPA_DRV_H
#define LPA_DRV_H

/****************************************
 *				Include					*
 ****************************************/
#include <queue.h>

/****************************************
 *				Defines					*
 ****************************************/
#define CLKCFG_FOR_GTC				(0x4B100318U)	// GTC Peripheral Clock Generation Control Register
#define CLKCFG_FOR_LPA				(0x4B100394U)	// Clock for LPA Generation Control Register
#define CLKCFG_FOR_LPA_TS			(0x4B100398U)	// Clock for Timestamp Generation Control Register
#define LPA_PROC_BASE_ADDR			(0x46D00000U)	// LPA AXI Processor Port Base Address
#define LPA_LOG_BASE_ADDR			(0x46D10000U)	// LPA AXI Logging Port Base Address
#define LPA_DMA_BASE_ADDR			(0x46D20000U)  	// LPA DMA Control Base Address
#define CLK_MASK_CTRL				(0x46E00000U)	// Network Sub-system Clock Gating Control Register
#define SW_RST_CTRL					(0x46E00004U)	// Network Sub-system SW Reset Control Register
#define TS_CNT_SEL					(0x46E000A0U)	// Timestamp Counter Selection Register
#define TS_CNT_EN					(0x46E000A4U)	// Timestamp Counter Enable Register
#define LPP_OP_STS					(0x46E000B0U)	// LPP Operation Mode Status Register
#define LPP_CFG_STS					(0x46E000B4U)	// LPP Configuration Status Register
#define LPP_IRQ_EN					(0x46E000D0U)	// LPP Interrupt Enable Register
#define LPP_IRQ_STS					(0x46E000D4U)	// LPP Interrupt Status Register
#define LPP_IRQ_CLR					(0x46E000D8U)	// LPP Interrupt Clear Register

#define NP_SRAM_BASE_ADDR			(0x30400000UL)

#define LPA_80MHZ_PERI_CLK			(80UL)    // 80MHz
#define TS_50MHZ_PERI_CLK			(50UL)    // 50MHz


/****************************************
 *				Enumeration				*
 ****************************************/
// LPA Driver Return Value
typedef enum {
	eLPA_RET_OK,
	eLPA_RET_DEV_UNKNOWN_ERROR,
	eLPA_RET_DEV_TIMEOUT,
	eLPA_RET_DEV_FIFO_FULL,
	eLPA_RET_DEV_UNKNOWN_ID,
	eLPA_RET_DEV_CRC_ERROR,
	eLPA_RET_DEV_NO_DATA,
	eLPA_RET_DEV_BUSY,
	eLPA_RET_DEV_UNKNOWN_PORT,
	eLPA_RET_DRV_NG_OPEN,
	eLPA_RET_DRV_NG_ALREADY_OPEN,
	eLPA_RET_DRV_NG_NOT_OPEN,
	eLPA_RET_DRV_NG_CLOSE,
	eLPA_RET_DRV_NG_ALREADY_CLOSE,
	eLPA_RET_DRV_NG_INTERRUPT,
	eLPA_RET_DRV_NG_INVALID_PARAM,
	eLPA_RET_DRV_NG_MEM_FAULT,
	eLPA_RET_DRV_NG_NULL_POINTER_PARAM,
	eLPA_RET_DRV_NG_NOT_OPERATION_MODE
} eLPA_RET_t;

typedef enum {
	eLPA_MODE_INIT       = 0,
	eLPA_MODE_OPERATION  = 1,
	eLPA_MODE_PASSIVE    = 2,
	eLPA_MODE_UNKNOWN    = 3
}eLPA_MODE_t;

typedef enum {
	eLPA_NOTIFY_DATA    = 0x00000001,
	eLPA_NOTIFY_STATUS  = 0x00000002,
	eLPA_NOTIFY_LOGGING = 0x00000004
}eLPA_NOTIFY_t;

/****************************************
 *				Typedefs				*
 ****************************************/
typedef struct {
	uint16 idt;
	uint16 sn;			// serial number (for time-stamp)
	uint16 size;		// size of frame data buffer
	uint32 data_crc;
	uint8 *buffer;		// frame data buffer
}stLPA_REQUEST_t;

typedef struct {
	uint16 idt;			//
	uint16 sn;			// serial number (for time-stamp)
	uint16 size;		// size of frame data buffer
	uint8 *buffer;		// frame data buffer
	uint16 ret;			// processing return value of the request (Refer to eLPA_RET_t)
}stLPA_RESPONSE_t;

typedef void*(*pfnLpaQueueSend1B_t)(uint8 txval);

/***************************************************
*			Function declaration				*
****************************************************/
// LPA Processor
extern int32 lpa_open(void);
extern int32 lpa_close(void);
extern int32 lpa_startProc(TaskHandle_t taskHandler);	// on processor task
extern int32 lpa_stopProc(void);
extern int32 lpa_reset(void);
extern int32 lpa_write(const stLPA_REQUEST_t *pstRequest, stLPA_RESPONSE_t *pstResponse);
extern int32 lpa_read(const stLPA_REQUEST_t *pstRequest, stLPA_RESPONSE_t *pstResponse);
extern int32 lpa_getMode(eLPA_MODE_t *eMode);

// LPA Logging
extern int32 lpa_startLog(TaskHandle_t taskHandler);	// on logging task
extern int32 lpa_stopLog(void);
extern int32 lpa_readLog(const stLPA_REQUEST_t *pstRequest, stLPA_RESPONSE_t *pstResponse);
extern int32 lpa_getDrvState(void);
#endif	// #ifndef __LPA_DRV_H__

