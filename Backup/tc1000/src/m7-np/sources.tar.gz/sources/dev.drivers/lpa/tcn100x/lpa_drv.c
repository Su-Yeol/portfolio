/*
***************************************************************************************************
*
*   FileName : lpa_drv.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/


/****************************************
 *				Include					*
 ****************************************/
#include "lpa_types.h"
#include "lpa_drv.h"
#include "lpa_dma.h"
#include "lpa_txrx.h"
#include "clock.h"
#include "clock_dev.h"
#include "clock_reg.h"


/****************************************
 *		  Variable Definitions			*
 ****************************************/
static stLPA_DRV_t pstLpaDrv;

/***************************************************
*          Local function prototypes               *
****************************************************/
static void iowrite(uint32 data, uint32 addr);
static uint32 ioread(uint32 addr);
static void procMutexLock(void);
static void procMutexUnlock(void);
static void logMutexLock(void);
static void logMutexUnlock(void);

static void (*lpa_iowrite)(uint32 data, uint32 addr) = iowrite;
static uint32 (*lpa_ioread)(uint32 addr) = ioread;
static void (*lpa_procMutexLock)(void) = procMutexLock;
static void (*lpa_procMutexUnlock)(void) = procMutexUnlock;
static void (*lpa_logMutexLock)(void) = logMutexLock;
static void (*lpa_logMutexUnlock)(void) = logMutexUnlock;

/***************************************************
*			function definition				       *
****************************************************/
static void iowrite(uint32 data, uint32 addr)
{
	volatile uint32 *reg = pNULL;

	if(SAL_MemCopy(&reg, &addr, sizeof(volatile uint32 *)) == SAL_RET_SUCCESS) {
		SAL_WriteReg(data, reg);
	}
	else {
		LPA_E("Failed to copy to memory address for iowrite\n");
	}
}

static uint32 ioread(uint32 addr)
{
	volatile uint32 *reg = pNULL;
	uint32 ret = 0;

	if(SAL_MemCopy(&reg, &addr, sizeof(volatile uint32 *)) == SAL_RET_SUCCESS) {
		ret = SAL_ReadReg(reg);
	}
	else {
		LPA_E("Failed to copy to memory address for ioread\n");
	}
	return ret;
}

static void lpa_test_iowrite(uint32 data, uint32 addr)
{
	volatile uint32 *reg = pNULL;

	if(SAL_MemCopy(&reg, &addr, sizeof(volatile uint32 *)) == SAL_RET_SUCCESS) {
		SAL_WriteReg(data, reg);
		LPA_D("Write to: 0x%08x val = %08x\n", addr, data);
	}
	else {
		LPA_E("Failed to copy to memory address for lpa_test_iowrite()\n");
	}
}

static uint32 lpa_test_ioread(uint32 addr)
{
	volatile uint32 *reg = pNULL;
	uint32 ret = 0;

	if(SAL_MemCopy(&reg, &addr, sizeof(volatile uint32 *)) == SAL_RET_SUCCESS) {
		ret = SAL_ReadReg(reg);
		LPA_D("Read from: 0x%08x val = %08x\n", addr, ret);
	}
	else {
		LPA_E("Failed to copy to memory address for lpa_test_ioread()\n");
	}
	return ret;
}

static void mdelay(uint32 ms)
{
    uint32 i = 0;
    uint32 cnt = 0;
    uint32 cycle_per_1us = (uint32)configCPU_CLOCK_HZ / 1000000U;

    cnt = lpa_u32mul(ms, cycle_per_1us);
    for (i = 0UL; i < cnt; i++)
    {
         BSP_NOP_DELAY();
    }
}

static void lpa_createMutex(void)
{
	(void) SAL_SemaphoreCreate(&(pstLpaDrv.proc.semaId), (const uint8*)"LPA PROC Mutex", 1UL, SAL_OPT_BLOCKING);
	(void) SAL_SemaphoreCreate(&(pstLpaDrv.logging.semaId), (const uint8*)"LPA LOG Mutex", 1UL, SAL_OPT_BLOCKING);
	LPA_D("Porc Sema ID is %d, Logging Sema ID is %d\n", pstLpaDrv.proc.semaId, pstLpaDrv.logging.semaId);
}

static void lpa_deleteMutex(void)
{
    (void) SAL_SemaphoreDelete(pstLpaDrv.proc.semaId);
    (void) SAL_SemaphoreDelete(pstLpaDrv.logging.semaId);
}

static void procMutexLock(void)
{
    /*Acquire Mutex*/
    (void) SAL_SemaphoreWait(pstLpaDrv.proc.semaId, 0, SAL_OPT_BLOCKING);
}

static void procMutexUnlock(void)
{
    /*Release Mutex*/
    (void) SAL_SemaphoreRelease(pstLpaDrv.proc.semaId);
}

static void logMutexLock(void)
{
    /*Acquire Mutex*/
    (void) SAL_SemaphoreWait(pstLpaDrv.logging.semaId, 0, SAL_OPT_BLOCKING);
}

static void logMutexUnlock(void)
{
    /*Release Mutex*/
    (void) SAL_SemaphoreRelease(pstLpaDrv.logging.semaId);
}

static void lpa_setGtcPeriClock(void)
{
	uint32 val;
	uint32 uiDivdedPLL;
	uint32 clk_div;

	uiDivdedPLL = CLOCK_GetPllRate((sint32)CLOCK_MPLL_DIV_2);

	uiDivdedPLL /=1000000UL;
	clk_div = uiDivdedPLL / TS_50MHZ_PERI_CLK;
	if (clk_div > 1UL) {
		clk_div -= 1UL;
	}
	else {
		LPA_E("Invalid PLL2 clock for TS peri. clock\n");
	}
	LPA_D("clk_div:%d, divided PLL2 : %d MHz\n", clk_div, uiDivdedPLL);

	/*
		Timestamp Generation Peri. clock
	*/
	// step1: disable clock output
	val = lpa_ioread(CLKCFG_FOR_GTC);
	val &= 0xBFFFFFFFUL;
	lpa_iowrite(val, CLKCFG_FOR_GTC);

	// step2: wait until peripheral clock divider output is disabled
	while (TRUE) {
		val = lpa_ioread(CLKCFG_FOR_GTC);
		if ((val & 0x80000000UL) == 0x00000000UL) {
			break;
		}
	}

	// step3: disable clock dividing
	val = lpa_ioread(CLKCFG_FOR_GTC);
	val &= 0xDFFFFFFFUL;
	lpa_iowrite(val, CLKCFG_FOR_GTC);

	// step4: select the source to PLL2_FOUT
	val = lpa_ioread(CLKCFG_FOR_GTC);
	val &= 0xE0FFFFFFUL;
	val |= ((uint32)CLOCK_PCLKCTRL_SEL_PLL2DIV << 24UL);
	lpa_iowrite(val, CLKCFG_FOR_GTC);

	// step5: set divisor value of divider to 19 (= CLK_DIV + 1)
	val = lpa_ioread(CLKCFG_FOR_GTC);
	val |= (clk_div);
	lpa_iowrite(val, CLKCFG_FOR_GTC);

	// step6: enable clock dividing
	val = lpa_ioread(CLKCFG_FOR_GTC);
	val |= 0x20000000UL;
	lpa_iowrite(val, CLKCFG_FOR_GTC);

	// step7: enable clock output
	val = lpa_ioread(CLKCFG_FOR_GTC);
	val |= 0x40000000UL;
	lpa_iowrite(val, CLKCFG_FOR_GTC);

	// step8: wait until peripheral clock divider output is disabled
	while (TRUE) {
		val = lpa_ioread(CLKCFG_FOR_GTC);
		if ((val & 0x80000000UL) == 0x80000000UL) {
			break;
		}
	}

	LPA_D("GTC peri. register: 0x%X\n", lpa_ioread(CLKCFG_FOR_GTC));

	val = lpa_ioread(0x4B420000UL);
	val |= (1UL<<24U);	//BTG_EN (79-bit binary rollover timestamp)
	val |= (1UL<<20U);	//ENC_EN (79-bit binary rollover timestamp)
	val |= (1UL<<17U);	//GTB_EN
	val |= (1UL<<16U);	//DEC_EN
	val |= (1UL<<5U);	//GTM_OVW
	val |= (1UL<<3U);	//GTC_EN
	lpa_iowrite(val, 0x4B420000UL);

	LPA_D("GTC_CONFIG register: 0x%08X\n", lpa_ioread(0x4B420000UL));
}


static void lpa_setLppPeriClock(void)
{
	uint32 val;
	uint32 uiDivdedPLL;
	uint32 clk_div;

	uiDivdedPLL = CLOCK_GetPllRate((sint32)CLOCK_MPLL_DIV_0);

	uiDivdedPLL /=1000000UL;
	clk_div = uiDivdedPLL / LPA_80MHZ_PERI_CLK;
	if (clk_div > 1UL) {
		clk_div -= 1UL;
	}
	else {
		LPA_E("Invalid PLL0 clock for LPA peri. clock\n");
	}
	LPA_D("clk_div:%d, divided PLL0 : %d MHz\n", clk_div, uiDivdedPLL);

	/*
		LPP Peri. clock
	*/
	// step1: disable clock output
	val = lpa_ioread(CLKCFG_FOR_LPA);
	val &= 0xBFFFFFFFUL;
	lpa_iowrite(val, CLKCFG_FOR_LPA);

	// step2: wait until peripheral clock divider output is disabled
	while (TRUE) {
		val = lpa_ioread(CLKCFG_FOR_LPA);
		if ((val & 0x80000000UL) == 0x00000000UL) {
			break;
		}
	}

	// step3: disable clock dividing
	val = lpa_ioread(CLKCFG_FOR_LPA);
	val &= 0xDFFFFFFFUL;
	lpa_iowrite(val, CLKCFG_FOR_LPA);

	// step4: select the source to PLL0_FOUT
	val = lpa_ioread(CLKCFG_FOR_LPA);
	val &= 0xE0FFFFFFUL;
	val |= ((uint32)CLOCK_PCLKCTRL_SEL_PLL0DIV << 24UL);
	lpa_iowrite(val, CLKCFG_FOR_LPA);

	// step5: set divisor value of divider to 19 (= CLK_DIV + 1)
	val = lpa_ioread(CLKCFG_FOR_LPA);
	val |= (clk_div);
	lpa_iowrite(val, CLKCFG_FOR_LPA);

	// step6: enable clock dividing
	val = lpa_ioread(CLKCFG_FOR_LPA);
	val |= 0x20000000UL;
	lpa_iowrite(val, CLKCFG_FOR_LPA);

	// step7: enable clock output
	val = lpa_ioread(CLKCFG_FOR_LPA);
	val |= 0x40000000UL;
	lpa_iowrite(val, CLKCFG_FOR_LPA);

	// step8: wait until peripheral clock divider output is disabled
	while (TRUE) {
		val = lpa_ioread(CLKCFG_FOR_LPA);
		if ((val & 0x80000000UL) == 0x80000000UL) {
			break;
		}
	}

	LPA_D("LPA peri. register: 0x%X\n", lpa_ioread(CLKCFG_FOR_LPA));
}

static void lpa_setTsPeriClock(void)
{
	uint32 val;
	uint32 uiDivdedPLL;
	uint32 clk_div;

	uiDivdedPLL = CLOCK_GetPllRate((sint32)CLOCK_MPLL_DIV_2);

	uiDivdedPLL /=1000000UL;
	clk_div = uiDivdedPLL / TS_50MHZ_PERI_CLK;
	if (clk_div > 1UL) {
		clk_div -= 1UL;
	}
	else {
		LPA_E("Invalid PLL2 clock for TS peri. clock\n");
	}
	LPA_D("clk_div:%d, divided PLL2 : %d MHz\n", clk_div, uiDivdedPLL);

	/*
		Timestamp Generation Peri. clock
	*/
	// step1: disable clock output
	val = lpa_ioread(CLKCFG_FOR_LPA_TS);
	val &= 0xBFFFFFFFUL;
	lpa_iowrite(val, CLKCFG_FOR_LPA_TS);

	// step2: wait until peripheral clock divider output is disabled
	while (TRUE) {
		val = lpa_ioread(CLKCFG_FOR_LPA_TS);
		if ((val & 0x80000000UL) == 0x00000000UL) {
			break;
		}
	}

	// step3: disable clock dividing
	val = lpa_ioread(CLKCFG_FOR_LPA_TS);
	val &= 0xDFFFFFFFUL;
	lpa_iowrite(val, CLKCFG_FOR_LPA_TS);

	// step4: select the source to PLL2_FOUT
	val = lpa_ioread(CLKCFG_FOR_LPA_TS);
	val &= 0xE0FFFFFFUL;
	val |= ((uint32)CLOCK_PCLKCTRL_SEL_PLL2DIV << 24UL);
	lpa_iowrite(val, CLKCFG_FOR_LPA_TS);

	// step5: set divisor value of divider to 19 (= CLK_DIV + 1)
	val = lpa_ioread(CLKCFG_FOR_LPA_TS);
	val |= (clk_div);
	lpa_iowrite(val, CLKCFG_FOR_LPA_TS);

	// step6: enable clock dividing
	val = lpa_ioread(CLKCFG_FOR_LPA_TS);
	val |= 0x20000000UL;
	lpa_iowrite(val, CLKCFG_FOR_LPA_TS);

	// step7: enable clock output
	val = lpa_ioread(CLKCFG_FOR_LPA_TS);
	val |= 0x40000000UL;
	lpa_iowrite(val, CLKCFG_FOR_LPA_TS);

	// step8: wait until peripheral clock divider output is disabled
	while (TRUE) {
		val = lpa_ioread(CLKCFG_FOR_LPA_TS);
		if ((val & 0x80000000UL) == 0x80000000UL) {
			break;
		}
	}

	LPA_D("TS peri. register: 0x%X\n", lpa_ioread(CLKCFG_FOR_LPA_TS));
}

static void lpa_setClock(void)
{
	lpa_setGtcPeriClock();
	lpa_setLppPeriClock();
	lpa_setTsPeriClock();
}

static void lpa_resetDriver(stLPA_DRV_t *pdrv)
{
	uint32 usageCnt = pdrv->usageCnt;
	uint32 proccnt = pdrv->irqProcCnt;
	uint32 errcnt = pdrv->irqErrorCnt;
	uint32 logcnt = pdrv->irqLogCnt;
	SAL_MemSet(pdrv, 0, sizeof(stLPA_DRV_t));
	pdrv->usageCnt = usageCnt;
	pdrv->irqProcCnt = proccnt;
	pdrv->irqErrorCnt = errcnt;
	pdrv->irqLogCnt = logcnt;
}

static void lpa_resetDevice(void)
{
	uint32 val;
	/*
		enable LPP DMA bus clock & LPP bus clock
	*/
	val = lpa_ioread(CLK_MASK_CTRL);	// CLK_MASK_CTRL
	val |= (0x70UL);
	lpa_iowrite(val, CLK_MASK_CTRL);

	/*
		reset LPP DMA bus & LPP bus
	*/
	val = lpa_ioread(SW_RST_CTRL);	// SW_RST_CTRL
	val &= (0x38FUL);
	lpa_iowrite(val, SW_RST_CTRL);
	val |= (0x070UL);
	lpa_iowrite(val, SW_RST_CTRL);
}

static void lpa_initDriver(stLPA_DRV_t *pdrv)
{
	pdrv->state = eLPA_STATE_CLOSE;
	pdrv->usageCnt = lpa_u32add(pdrv->usageCnt, 1UL);

	pdrv->proc.devPort     = eLPA_PORT_PROCESSOR;
	pdrv->proc.axiCtrlAddr = LPA_PROC_BASE_ADDR;
	pdrv->proc.axiCtrlSize = LPA_CTRL_SIZE;
	pdrv->proc.dmaCtrlAddr = LPA_DMA_BASE_ADDR;
	pdrv->proc.dmaCtrlSize = LPA_DMA_CTRL_SIZE;
#if (CORTEX_M7_NP == 1)
    pdrv->proc.dmaBufAddr  = (uint32)(&lpa_dmastart__);
#endif
	pdrv->proc.dmaBufSize  = LPA_CTRL_SIZE;

	pdrv->logging.devPort     = eLPA_PORT_LOGGING;
	pdrv->logging.axiCtrlAddr = LPA_LOG_BASE_ADDR;
	pdrv->logging.axiCtrlSize = LPA_CTRL_SIZE;
	pdrv->logging.dmaCtrlAddr = LPA_DMA_BASE_ADDR;
	pdrv->logging.dmaCtrlSize = LPA_DMA_CTRL_SIZE;
	pdrv->logging.dmaBufAddr  = pdrv->proc.dmaBufAddr + LPA_LOG_BUF_OFFSET;
	pdrv->logging.dmaBufSize  = LPA_CTRL_SIZE;

	pdrv->irqs[eLPA_INT_PROC] = (uint32)LPA_HOST_AXI_IRQn;
	pdrv->irqs[eLPA_INT_ERROR] = (uint32)LPA_ERROR_AXI_IRQn;
	pdrv->irqs[eLPA_INT_LOG] = (uint32)LPA_LOG_AXI_IRQn;

	pdrv->proc.taskHandler = pNULL;
	pdrv->logging.taskHandler = pNULL;

	lpa_createMutex();
}

static void lpa_procIrqHandler(void)
{
	uint32 irq_status = 0U;
	BaseType_t xHigherPriorityTaskWoken = (BaseType_t)pdFALSE;
	BaseType_t ret = (BaseType_t)pdFALSE;
	uint8 fnotify = 0U;

	pstLpaDrv.irqProcCnt =lpa_u32add(pstLpaDrv.irqProcCnt, 1UL);

	LPA_D("  [INT] Processor Interrupt[0x01], IRQ Count[%d]", pstLpaDrv.irqProcCnt);
	irq_status = lpa_ioread(LPP_IRQ_STS); // LPP_IRQ_STS
	LPA_D("  [INT] IRQ Status=0x%08x", irq_status);

	lpa_iowrite(irq_status & 0x01UL, LPP_IRQ_CLR);     // LPP_IRQ_CLR

	if(pstLpaDrv.proc.taskHandler != NULL) {
		ret = xTaskNotifyFromISR(pstLpaDrv.proc.taskHandler, (uint32)eLPA_NOTIFY_DATA, eSetBits, &xHigherPriorityTaskWoken);
		if(ret != (BaseType_t)pdTRUE) {
			LPA_E("  [INT] Failed to notify data interrupt signal to processor task");
		}
		fnotify = 1U;
	}

	if(fnotify == 0U) {
		LPA_D("  [INT] A processor interrupt was triggered, but the notification failed due to an unknown task and queue setting");
	}
//	else {
//		portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
//	}
}

static void lpa_errorIrqHandler(void)
{
	uint32 irq_status = 0U;
	BaseType_t xHigherPriorityTaskWoken = (BaseType_t)pdFALSE;
	BaseType_t ret = (BaseType_t)pdFALSE;
	uint8 fnotify = 0U;

	pstLpaDrv.irqErrorCnt =lpa_u32add(pstLpaDrv.irqErrorCnt, 1UL);

	LPA_D("  [INT] Error Status Interrupt[0x04], IRQ Count[%d]", pstLpaDrv.irqErrorCnt);
	irq_status = lpa_ioread(LPP_IRQ_STS); // LPP_IRQ_STS
	LPA_D("  [INT] IRQ Status=0x%08x", irq_status);

	lpa_iowrite(irq_status & 0x04UL, LPP_IRQ_CLR);     // LPP_IRQ_CLR

	if(pstLpaDrv.proc.taskHandler != NULL) {
		NVIC_IntSrcDis(LPA_ERROR_AXI_IRQn);
		ret = xTaskNotifyFromISR(pstLpaDrv.proc.taskHandler, (uint32)eLPA_NOTIFY_STATUS, eSetBits, &xHigherPriorityTaskWoken);
		if(ret != (BaseType_t)pdTRUE) {
			LPA_E("  [INT] Failed to notify error status interrupt signal to processor task");
		}
		fnotify = 1U;
	}

	if(fnotify == 0U) {
		LPA_D("  [INT] A error status interrupt was triggered, but the notification failed due to an unknown task and queue setting");
	}
//	else {
//		portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
//	}
}

static void lpa_logIrqHandler(void)
{
	uint32 irq_status = 0U;
	BaseType_t xHigherPriorityTaskWoken = (BaseType_t)pdFALSE;
	BaseType_t ret = (BaseType_t)pdFALSE;
	uint8 fnotify = 0U;

	pstLpaDrv.irqLogCnt =lpa_u32add(pstLpaDrv.irqLogCnt, 1UL);

	LPA_D("  [INT] Logging Interrupt[0x02], IRQ Count[%d]", pstLpaDrv.irqLogCnt);
	irq_status = lpa_ioread(LPP_IRQ_STS); // LPP_IRQ_STS
	LPA_D("  [INT] IRQ Status=0x%08x", irq_status);

	lpa_iowrite(irq_status & 0x02UL, LPP_IRQ_CLR);     // LPP_IRQ_CLR

	if(pstLpaDrv.logging.taskHandler != NULL) {
		ret = xTaskNotifyFromISR(pstLpaDrv.logging.taskHandler, (uint32)eLPA_NOTIFY_LOGGING, eSetBits, &xHigherPriorityTaskWoken);
		if(ret != (BaseType_t)pdTRUE) {
			LPA_E("  [INT] Failed to notify logging interrupt signal to logging task");
		}
		fnotify = 1U;
	}

	if(fnotify == 0U) {
		LPA_D("  [INT] A logging interrupt was triggered, but the notification failed due to an unknown task and queue setting");
	}
//	else {
//		portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
//	}
}

static int32 lpa_request_irq(const stLPA_DRV_t *pstDrv)
{
	int32 ret = (int32)eLPA_RET_OK;
	SALRetCode_t rc;

	rc = NVIC_IntVectSet(LPA_HOST_AXI_IRQn, (IrqHandler_t)&lpa_procIrqHandler);
	if(rc != SAL_RET_SUCCESS) {
		LPA_E("Failed to set processor IRQ[%d] handler\n", pstDrv->irqs[eLPA_INT_PROC]);
		ret = (int32)eLPA_RET_DRV_NG_INTERRUPT;
	}
	else {
		LPA_D("Successfully set processor IRQ[%d] handler\n", pstDrv->irqs[eLPA_INT_PROC]);
		rc = NVIC_IntSrcEn(LPA_HOST_AXI_IRQn);
		if(rc != SAL_RET_SUCCESS) {
			LPA_E("Failed to enable processor IRQ\n");
			ret = (int32)eLPA_RET_DRV_NG_INTERRUPT;
		}
		else {
			LPA_D("Enable processor IRQ\n");
		}
	}

	rc = NVIC_IntVectSet(LPA_ERROR_AXI_IRQn, (IrqHandler_t)&lpa_errorIrqHandler);
	if(rc != SAL_RET_SUCCESS) {
		LPA_E("Failed to set error status IRQ[%d] handler\n", pstDrv->irqs[eLPA_INT_ERROR]);
		ret = (int32)eLPA_RET_DRV_NG_INTERRUPT;
	}
	else {
		LPA_D("Successfully set error status IRQ[%d] handler\n", pstDrv->irqs[eLPA_INT_ERROR]);
		rc = NVIC_IntSrcEn(LPA_ERROR_AXI_IRQn);
		if(rc != SAL_RET_SUCCESS) {
			LPA_E("Failed to enable error status IRQ\n");
			ret = (int32)eLPA_RET_DRV_NG_INTERRUPT;
		}
		else {
			LPA_D("Enable error status IRQ\n");
		}
	}

	rc = NVIC_IntVectSet(LPA_LOG_AXI_IRQn, (IrqHandler_t)&lpa_logIrqHandler);
	if(rc != SAL_RET_SUCCESS) {
		LPA_E("Failed to set logging IRQ[%d] handler\n", pstDrv->irqs[eLPA_INT_LOG]);
		ret = (int32)eLPA_RET_DRV_NG_INTERRUPT;
	}
	else {
		LPA_D("Successfully set logging IRQ[%d] handler\n", pstDrv->irqs[eLPA_INT_LOG]);
		rc = NVIC_IntSrcEn(LPA_LOG_AXI_IRQn);
		if(rc != SAL_RET_SUCCESS) {
			LPA_E("Failed to enable logging IRQ\n");
			ret = (int32)eLPA_RET_DRV_NG_INTERRUPT;
		}
		else {
			LPA_D("Enable logging IRQ\n");
		}
	}

	return ret;
}

static int32 lpa_probe(stLPA_DRV_t *pdrv)
{
	int32 ret = (int32)eLPA_RET_OK;

	if(pdrv != NULL) {
		LPA_D("LPA Probe In\n");
		lpa_initDriver(pdrv);
		lpa_dma_init(&pdrv->proc);
		ret = lpa_request_irq(pdrv);
		if(ret != 0) {
			lpa_deleteMutex();
			lpa_dma_deinit(&pdrv->proc);
			lpa_resetDriver(pdrv);
			LPA_E("Failed to initialize LPA\n");
		}
		else {
			LPA_D("LPA driver initialization succeeded\n");
		}
	}
	else {
		ret = (int32)eLPA_RET_DRV_NG_NULL_POINTER_PARAM;
	}

	return ret;
}

/*
***************************************************************************************************
*                                         INTERFACE FUNCTIONS
***************************************************************************************************
*/
int32 lpa_open(void)
{
	int32 ret = (int32)eLPA_RET_OK;

	if(pstLpaDrv.state != eLPA_STATE_OPEN) {
		mcu_printf("[LPA   ] LPA Driver Version: %d.%d.%d\n", V_RELEASE, V_MAJOR, V_MINOR);
		LPA_D("Starting the LPA driver open operation...\n");

		lpa_setClock();

		lpa_resetDevice();

		ret = lpa_probe(&pstLpaDrv);

		if(ret == (int32)eLPA_RET_OK) {
			uint32 val;
			// Enable LPA IRQs
			lpa_iowrite(0x00000007UL, LPP_IRQ_EN);
//			lpa_iowrite(0x00000005UL, LPP_IRQ_EN);

			// Timestamp Counter Enable Register
			val = lpa_ioread(TS_CNT_EN);
			val |= 0x100UL;
			lpa_iowrite(val, TS_CNT_EN);

			// LPP timestamp input selectin
//			val = lpa_ioread(TS_CNT_SEL);
//			val |= 0x100UL;
//			lpa_iowrite(val, TS_CNT_SEL);

			pstLpaDrv.state = eLPA_STATE_OPEN;
			LPA_D("LPA driver successfully opened\n");
		}
		else {
			ret = (int32)eLPA_RET_DRV_NG_OPEN;
			(void)SAL_DbgReportError(SAL_DRVID_LPA, 0UL, (uint32)SAL_ERR_FAIL_START, __FUNCTION__);
			LPA_E("Failed to open LPA driver\n");
		}
	}
	else {
		ret = (int32)eLPA_RET_DRV_NG_ALREADY_OPEN;
	}

    return ret;
}

int32 lpa_startProc(TaskHandle_t taskHandler)
{
	int32 ret = (int32)eLPA_RET_OK;

	if(pstLpaDrv.state == eLPA_STATE_OPEN) {
		lpa_procMutexLock();
		pstLpaDrv.proc.taskHandler = taskHandler;
		lpa_procMutexUnlock();
	}
	else {
		ret = (int32)eLPA_RET_DRV_NG_NOT_OPEN;
		(void)SAL_DbgReportError(SAL_DRVID_LPA, 6UL, (uint32)SAL_ERR_NOT_USEFUL, __FUNCTION__);
		LPA_E("Driver not opened. Please ensure the driver is opened before usage\n");
	}

	return ret;
}

int32 lpa_stopProc(void)
{
	int32 ret = (int32)eLPA_RET_OK;

	if(pstLpaDrv.state == eLPA_STATE_OPEN) {
		lpa_procMutexLock();
		pstLpaDrv.proc.taskHandler = NULL;
		lpa_procMutexUnlock();
	}
	else {
		ret = (int32)eLPA_RET_DRV_NG_NOT_OPEN;
		(void)SAL_DbgReportError(SAL_DRVID_LPA, 7UL, (uint32)SAL_ERR_NOT_USEFUL, __FUNCTION__);
		LPA_E("Driver not opened. Please ensure the driver is opened before usage\n");
	}

	return ret;
}

int32 lpa_close(void)
{
    int32 ret = (int32)eLPA_RET_OK;

	if(pstLpaDrv.state != eLPA_STATE_CLOSE) {
		pstLpaDrv.proc.taskHandler = pNULL;
		pstLpaDrv.logging.taskHandler = pNULL;
		LPA_D("Starting the LPA driver close operation...\n");
		lpa_resetDevice();
		lpa_procMutexUnlock();
		lpa_logMutexUnlock();
		lpa_deleteMutex();
		lpa_resetDriver(&pstLpaDrv);
		pstLpaDrv.state = eLPA_STATE_CLOSE;
		LPA_D("LPA driver successfully closed\n");
	}
	else {
		ret = (int32)eLPA_RET_DRV_NG_ALREADY_CLOSE;
	}
    return ret;
}

int32 lpa_reset(void)
{
	int32 ret = (int32)eLPA_RET_OK;

	if(pstLpaDrv.state == eLPA_STATE_OPEN) {
		lpa_procMutexLock();
		lpa_resetDevice();
		LPA_D("LPA device has been reset\n");
		lpa_procMutexUnlock();
	}
	else {
		ret = (int32)eLPA_RET_DRV_NG_NOT_OPEN;
		(void)SAL_DbgReportError(SAL_DRVID_LPA, 2UL, (uint32)SAL_ERR_INVALID_HANDLE, __FUNCTION__);
		LPA_E("Driver not opened. Please ensure the driver is opened before usage\n");
	}

	return ret;
}

int32 lpa_write(const stLPA_REQUEST_t *pstRequest, stLPA_RESPONSE_t *pstResponse)
{
	int32 ret = (int32)eLPA_RET_OK;

	if(pstLpaDrv.state == eLPA_STATE_OPEN) {
		if((pstRequest != NULL) && (pstResponse != NULL)) {

			lpa_procMutexLock();

			if(pstRequest->buffer != NULL) {
				ret = lpa_writeRequest(&pstLpaDrv.proc, pstRequest, pstResponse);
			}
			else {
				ret = (int32)eLPA_RET_DRV_NG_NULL_POINTER_PARAM;
				(void)SAL_DbgReportError(SAL_DRVID_LPA, 3UL, (uint32)SAL_ERR_INVALID_PARAMETER, __FUNCTION__);
				LPA_E("Function received NULL as input value\n");
				if(pstRequest->buffer == NULL) {
					LPA_D("Request buffer is NULL pointer\n");
				}
				if(pstResponse->buffer == NULL) {
					LPA_D("Response buffer is NULL pointer\n");
				}
			}
			lpa_procMutexUnlock();
		}
		else {
			ret = (int32)eLPA_RET_DRV_NG_NULL_POINTER_PARAM;
			(void)SAL_DbgReportError(SAL_DRVID_LPA, 3UL, (uint32)SAL_ERR_INVALID_PARAMETER, __FUNCTION__);
			LPA_E("Function received NULL as input value\n");
		}
	}
	else {
		ret = (int32)eLPA_RET_DRV_NG_NOT_OPEN;
		(void)SAL_DbgReportError(SAL_DRVID_LPA, 3UL, (uint32)SAL_ERR_INVALID_HANDLE, __FUNCTION__);
		LPA_E("Driver not opened. Please ensure the driver is opened before usage\n");
	}

	return ret;
}

int32 lpa_read(const stLPA_REQUEST_t *pstRequest, stLPA_RESPONSE_t *pstResponse)
{
	int32 ret = (int32)eLPA_RET_OK;

	if(pstLpaDrv.state == eLPA_STATE_OPEN) {
		if((pstRequest != NULL) && (pstResponse != NULL)) {

			lpa_procMutexLock();

			if((pstRequest->buffer != NULL) && (pstResponse->buffer != NULL)) {
				ret = lpa_readRequest(&pstLpaDrv.proc, pstRequest, pstResponse);
			}
			else {
				ret = (int32)eLPA_RET_DRV_NG_NULL_POINTER_PARAM;
				(void)SAL_DbgReportError(SAL_DRVID_LPA, 4UL, (uint32)SAL_ERR_INVALID_PARAMETER, __FUNCTION__);
				LPA_E("Function received NULL as input value\n");
				if(pstRequest->buffer == NULL) {
					LPA_D("Request buffer is NULL pointer\n");
				}
				if(pstResponse->buffer == NULL) {
					LPA_D("Response buffer is NULL pointer\n");
				}
			}
			lpa_procMutexUnlock();
		}
		else {
			ret = (int32)eLPA_RET_DRV_NG_NULL_POINTER_PARAM;
			(void)SAL_DbgReportError(SAL_DRVID_LPA, 4UL, (uint32)SAL_ERR_INVALID_PARAMETER, __FUNCTION__);
			LPA_E("Function received NULL as input value\n");
		}
	}
	else {
		ret = (int32)eLPA_RET_DRV_NG_NOT_OPEN;
		(void)SAL_DbgReportError(SAL_DRVID_LPA, 4UL, (uint32)SAL_ERR_INVALID_HANDLE, __FUNCTION__);
		LPA_E("Driver not opened. Please ensure the driver is opened before usage\n");
	}

	return ret;
}

int32 lpa_getMode(eLPA_MODE_t *eMode)
{
	int32 ret = (int32)eLPA_RET_OK;

	if(pstLpaDrv.state == eLPA_STATE_OPEN) {
		if(eMode != NULL) {
			uint32 val;
			lpa_procMutexLock();
			val = lpa_ioread(LPP_CFG_STS);	// LPP_CFG_STS
			mcu_printf("LPA Initialized Register: %08x\n", val);
			val = lpa_ioread(LPP_OP_STS);	// LPP_OP_STS
			mcu_printf("LPA Mode Register: %08x\n", val);
			if(val <= (uint32)eLPA_MODE_PASSIVE) {
				*eMode = (eLPA_MODE_t)val;
			}
			else {
				ret = (int32)eLPA_RET_DEV_UNKNOWN_ERROR;
				(void)SAL_DbgReportError(SAL_DRVID_LPA, 5UL, (uint32)SAL_ERR_NOT_USEFUL, __FUNCTION__);
			}
			lpa_procMutexUnlock();
		}
		else {
			ret = (int32)eLPA_RET_DRV_NG_INVALID_PARAM;
			(void)SAL_DbgReportError(SAL_DRVID_LPA, 5UL, (uint32)SAL_ERR_INVALID_PARAMETER, __FUNCTION__);
			LPA_E("Function received NULL as input value\n");
		}
	}
	else {
		ret = (int32)eLPA_RET_DRV_NG_NOT_OPEN;
		(void)SAL_DbgReportError(SAL_DRVID_LPA, 5UL, (uint32)SAL_ERR_INVALID_HANDLE, __FUNCTION__);
		LPA_E("Driver not opened. Please ensure the driver is opened before usage\n");
	}

	return ret;
}

int32 lpa_startLog(TaskHandle_t taskHandler)
{
	int32 ret = (int32)eLPA_RET_OK;

	if(pstLpaDrv.state == eLPA_STATE_OPEN) {
		lpa_logMutexLock();
		pstLpaDrv.logging.taskHandler = taskHandler;
		lpa_logMutexUnlock();
	}
	else {
		ret = (int32)eLPA_RET_DRV_NG_NOT_OPEN;
		(void)SAL_DbgReportError(SAL_DRVID_LPA, 6UL, (uint32)SAL_ERR_NOT_USEFUL, __FUNCTION__);
		LPA_E("Driver not opened. Please ensure the driver is opened before usage\n");
	}

	return ret;
}

int32 lpa_stopLog(void)
{
	int32 ret = (int32)eLPA_RET_OK;

	if(pstLpaDrv.state == eLPA_STATE_OPEN) {
		lpa_logMutexLock();
		pstLpaDrv.logging.taskHandler = NULL;
		lpa_logMutexUnlock();
	}
	else {
		ret = (int32)eLPA_RET_DRV_NG_NOT_OPEN;
		(void)SAL_DbgReportError(SAL_DRVID_LPA, 7UL, (uint32)SAL_ERR_NOT_USEFUL, __FUNCTION__);
		LPA_E("Driver not opened. Please ensure the driver is opened before usage\n");
	}

	return ret;
}

int32 lpa_readLog(const stLPA_REQUEST_t *pstRequest, stLPA_RESPONSE_t *pstResponse)
{
	int32 ret = (int32)eLPA_RET_OK;

	if(pstLpaDrv.state == eLPA_STATE_OPEN) {
		if((pstRequest != NULL) && (pstResponse != NULL)) {

			lpa_logMutexLock();

			if((pstRequest->buffer != NULL) && (pstResponse->buffer != NULL)) {
#if defined(LPA_DBG_DATA)
				uint32 i;
				uint8 *buf = (uint8*)pstRequest->buffer;
				uint8 *rbuf = (uint8*)pstResponse->buffer;
				LPA_D("LPA CLI Logging read request: idt[%d] sn[%d] size[%d] axiAddr[%px]\n", pstRequest->idt, pstRequest->sn, pstRequest->size, pstLpaDrv.proc.axiCtrlAddr);
				LPA_D("data: \n");
				for(i=0; i < (pstRequest->size/16); i++) {
					LPA_D("%08x: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x: %016lx %016lx\n",
							i*16, *(buf+(i*16)), *(buf+(i*16+1)), *(buf+(i*16+2)), *(buf+(i*16+3)), *(buf+(i*16+4)), *(buf+(i*16+5)), *(buf+(i*16+6)), *(buf+(i*16+7)),
							*(buf+(i*16+8)), *(buf+(i*16+9)), *(buf+(i*16+10)), *(buf+(i*16+11)), *(buf+(i*16+12)), *(buf+(i*16+13)), *(buf+(i*16+14)), *(buf+(i*16+15)),
							*((uint64*)(buf+(i*16))), *((uint64*)(buf+(i*16)+8)));
				}
				LPA_D("Reading LPA Logging Port...\n");
#endif
				ret = lpa_readRequest(&pstLpaDrv.logging, pstRequest, pstResponse);
#if defined(LPA_DBG_DATA)
				LPA_D("LPA IP Logging response: idt[%d] sn[%d] size[%d] ret[%d]\n", pstResponse->idt, pstResponse->sn, pstResponse->size, pstResponse->ret);
				LPA_D("data: \n");
				for(i=0; i < (pstResponse->size/16); i++) {
					LPA_D("%08x: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x: %016lx %016lx\n",
							i*16, *(rbuf+(i*16)), *(rbuf+(i*16+1)), *(rbuf+(i*16+2)), *(rbuf+(i*16+3)), *(rbuf+(i*16+4)), *(rbuf+(i*16+5)), *(rbuf+(i*16+6)), *(rbuf+(i*16+7)),
							*(rbuf+(i*16+8)), *(rbuf+(i*16+9)), *(rbuf+(i*16+10)), *(rbuf+(i*16+11)), *(rbuf+(i*16+12)), *(rbuf+(i*16+13)), *(rbuf+(i*16+14)), *(rbuf+(i*16+15)),
							*((uint64*)(buf+(i*16))), *((uint64*)(buf+(i*16)+8)));
				}
#endif
			}
			else {
				ret = (int32)eLPA_RET_DRV_NG_NULL_POINTER_PARAM;
				(void)SAL_DbgReportError(SAL_DRVID_LPA, 8UL, (uint32)SAL_ERR_INVALID_PARAMETER, __FUNCTION__);
				LPA_E("Function received NULL as input value\n");
				if(pstRequest->buffer == NULL) {
					LPA_D("Request buffer is NULL pointer\n");
				}
				if(pstResponse->buffer == NULL) {
					LPA_D("Response buffer is NULL pointer\n");
				}
			}
			lpa_logMutexUnlock();
		}
		else {
			ret = (int32)eLPA_RET_DRV_NG_NULL_POINTER_PARAM;
			(void)SAL_DbgReportError(SAL_DRVID_LPA, 8UL, (uint32)SAL_ERR_INVALID_PARAMETER, __FUNCTION__);
			LPA_E("Function received NULL as input value\n");
		}
	}
	else {
		ret = (int32)eLPA_RET_DRV_NG_NOT_OPEN;
		(void)SAL_DbgReportError(SAL_DRVID_LPA, 8UL, (uint32)SAL_ERR_INVALID_HANDLE, __FUNCTION__);
		LPA_E("Driver not opened. Please ensure the driver is opened before usage\n");
	}

	return ret;
}

int32 lpa_getDrvState(void)
{
	int32 ret = -1;
	if(pstLpaDrv.state == eLPA_STATE_OPEN) {
		ret = 0;
	}
	return ret;
}

