/*
***************************************************************************************************
*
*   FileName : lpa_dma.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/


/****************************************
 *				Include					*
 ****************************************/
#include "lpa_types.h"
#include "lpa_dma.h"

/****************************************
 *		  Variable Definitions			*
 ****************************************/

/****************************************
 *		  Function Definitions			*
 ****************************************/
static void lpa_dma_clearInterrupt(const stLPA_CTRL_t *pstCtrl)
{
	volatile uint32 *pDmacIntTCClear = pNULL;
	volatile uint32 *pDmacIntErrClr = pNULL;
	uint32 ulDmacIntTCClear = lpa_u32add(pstCtrl->dmaCtrlAddr, 0x008UL);
	uint32 ulDmacIntErrClr = lpa_u32add(pstCtrl->dmaCtrlAddr, 0x010UL);

	if(SAL_MemCopy(&pDmacIntTCClear, &ulDmacIntTCClear, sizeof(volatile uint32 *)) == SAL_RET_SUCCESS) {
		SAL_WriteReg(1UL, pDmacIntTCClear);
	}
	if(SAL_MemCopy(&pDmacIntErrClr, &ulDmacIntErrClr, sizeof(volatile uint32 *)) == SAL_RET_SUCCESS) {
		SAL_WriteReg(1UL, pDmacIntErrClr);
	}
}

static void lpa_dma_setSrcAddr(const stLPA_CTRL_t *pstCtrl, eLPA_DMA_CH_t ch, uint32 src)
{
	volatile uint32 *pDmacCxSrcAddr = pNULL;
	uint32 ulDmacCxSrcAddr;

	if(ch == eLPA_DMA_CH0) {
		// DMA Channel 0: DMACC0SrcAddr
		ulDmacCxSrcAddr = lpa_u32add(pstCtrl->dmaCtrlAddr, 0x100UL);
	}
	else {
		// DMA Channel 1: DMACC1SrcAddr
		ulDmacCxSrcAddr = lpa_u32add(pstCtrl->dmaCtrlAddr, 0x120UL);
	}

	if(SAL_MemCopy(&pDmacCxSrcAddr, &ulDmacCxSrcAddr, sizeof(volatile uint32 *)) == SAL_RET_SUCCESS) {
		SAL_WriteReg(src, pDmacCxSrcAddr);
	}
}

static void lpa_dma_setDstAddr(const stLPA_CTRL_t *pstCtrl, eLPA_DMA_CH_t ch, uint32 dst)
{
	volatile uint32 *pDmacCxDestAddr = pNULL;
	volatile uint32 *pDmacCxLLI = pNULL;
	uint32 ulDmacCxDestAddr;
	uint32 ulDmacCxLLI;

	if(ch == eLPA_DMA_CH0) {
		// DMA Channel 0: DMACC0DestAddr, DMACC0LLI
		ulDmacCxDestAddr = lpa_u32add(pstCtrl->dmaCtrlAddr, 0x104UL);
		ulDmacCxLLI = lpa_u32add(pstCtrl->dmaCtrlAddr, 0x108UL);
	}
	else {
		// DMA Channel 1: DMACC1DestAddr, DMACC1LLI
		ulDmacCxDestAddr = lpa_u32add(pstCtrl->dmaCtrlAddr, 0x124UL);
		ulDmacCxLLI = lpa_u32add(pstCtrl->dmaCtrlAddr, 0x128UL);
	}

	if(SAL_MemCopy(&pDmacCxDestAddr, &ulDmacCxDestAddr, sizeof(volatile uint32 *)) == SAL_RET_SUCCESS) {
		SAL_WriteReg(dst, pDmacCxDestAddr);
	}
	if(SAL_MemCopy(&pDmacCxLLI, &ulDmacCxLLI, sizeof(volatile uint32 *)) == SAL_RET_SUCCESS) {
		SAL_WriteReg(0UL, pDmacCxLLI);	// Linked List Item
	}
}

static void lpa_dma_ctrlInfo(const stLPA_CTRL_t *pstCtrl, eLPA_DMA_CH_t ch, uint16 size)
{
	volatile uint32 *pDmacCxControl = pNULL;
	uint32 ulDmacCxControl = lpa_u32add(pstCtrl->dmaCtrlAddr, 0x10CUL);
	uint32 val = lpa_u32add(0xC4BFUL<<12, size&0x0FFFUL);

	if(ch == eLPA_DMA_CH0) {
		// DMA Channel 0: DMACC0Control
		ulDmacCxControl = lpa_u32add(pstCtrl->dmaCtrlAddr, 0x10CUL);
	}
	else {
		// DMA Channel 1: DMACC1Control
		ulDmacCxControl = lpa_u32add(pstCtrl->dmaCtrlAddr, 0x12CUL);
	}

	if(SAL_MemCopy(&pDmacCxControl, &ulDmacCxControl, sizeof(volatile uint32 *)) == SAL_RET_SUCCESS) {
		SAL_WriteReg(val, pDmacCxControl);
	}
}

static void lpa_dma_confChannel(const stLPA_CTRL_t *pstCtrl, eLPA_DMA_CH_t ch, uint32 cmd)
{
	volatile uint32 *pDmacCxConfiguration = pNULL;
	uint32 ulDmacCxConfiguration;

	if(ch == eLPA_DMA_CH0) {
		// DMA Channel 0: DMACC0Configuration
		ulDmacCxConfiguration = lpa_u32add(pstCtrl->dmaCtrlAddr, 0x110UL);
	}
	else {
		// DMA Channel 1: DMACC11Configuration
		ulDmacCxConfiguration = lpa_u32add(pstCtrl->dmaCtrlAddr, 0x130UL);
	}

	if(SAL_MemCopy(&pDmacCxConfiguration, &ulDmacCxConfiguration, sizeof(volatile uint32 *)) == SAL_RET_SUCCESS) {
		SAL_WriteReg(cmd, pDmacCxConfiguration);
	}
}

void lpa_dma_init(const stLPA_CTRL_t *pstCtrl)
{
	volatile uint32 *pDmacConfiguration = pNULL;
	uint32 ulDmacConfiguration = lpa_u32add(pstCtrl->dmaCtrlAddr, 0x30UL);

	if(SAL_MemCopy(&pDmacConfiguration, &ulDmacConfiguration, sizeof(volatile uint32 *)) == SAL_RET_SUCCESS) {
		SAL_WriteReg(1UL, pDmacConfiguration);
	}
}

void lpa_dma_deinit(const stLPA_CTRL_t *pstCtrl)
{
	volatile uint32 *pDmacConfiguration = pNULL;
	uint32 ulDmacConfiguration = lpa_u32add(pstCtrl->dmaCtrlAddr, 0x30UL);

	if(SAL_MemCopy(&pDmacConfiguration, &ulDmacConfiguration, sizeof(volatile uint32 *)) == SAL_RET_SUCCESS) {
		SAL_WriteReg(0UL, pDmacConfiguration);
	}
}

static void lpa_dma_checkEnabledChannel(const stLPA_CTRL_t *pstCtrl)
{
	volatile uint32 *pDmacEnbldChns = pNULL;
	uint32 value;
	uint32 loop = 0UL;
	uint32 ulDmacEnbldChns = lpa_u32add(pstCtrl->dmaCtrlAddr, 0x01CUL);

	if(SAL_MemCopy(&pDmacEnbldChns, &ulDmacEnbldChns, sizeof(volatile uint32 *)) == SAL_RET_SUCCESS) {
		do{
			value = SAL_ReadReg(pDmacEnbldChns);
			if ((value & 0x01UL) == 0UL)
			{
				break;
			}
			loop++;
		}while(loop < 1000UL);
	}

	LPA_D("Checking DMA Enabled Channel... loop:%d", loop);
}

int32 lpa_dma_sendRequest(const stLPA_CTRL_t *pstCtrl, uint16 size)
{
	int32 ret = (int32)eLPA_RET_OK;
	uint32 lpa_dma_addr = pstCtrl->dmaBufAddr;
	eLPA_DMA_CH_t lpa_dma_ch = eLPA_DMA_CH0;

	lpa_dma_init(pstCtrl);
	lpa_dma_clearInterrupt(pstCtrl);
	if(pstCtrl->devPort == eLPA_PORT_PROCESSOR) {
		lpa_dma_setSrcAddr(pstCtrl, lpa_dma_ch, lpa_dma_addr);
		lpa_dma_setDstAddr(pstCtrl, lpa_dma_ch, LPA_PROC_WADDR);
	}
	else if(pstCtrl->devPort == eLPA_PORT_LOGGING) {
		lpa_dma_ch = eLPA_DMA_CH1;
		lpa_dma_setSrcAddr(pstCtrl, lpa_dma_ch, lpa_dma_addr);
		lpa_dma_setDstAddr(pstCtrl, lpa_dma_ch, LPA_LOG_WADDR);
	}
	else {
		ret = (int32)eLPA_RET_DEV_UNKNOWN_PORT;
	}
	if(ret == (int32)eLPA_RET_OK) {
		lpa_dma_ctrlInfo(pstCtrl, lpa_dma_ch, size);
		lpa_dma_confChannel(pstCtrl, lpa_dma_ch, LPA_MEMORY2MEMORY);
		lpa_dma_checkEnabledChannel(pstCtrl);
		LPA_D("DMA Channel Configuration Register: 0x%08x, Tx Word Size: 0x%04x", LPA_MEMORY2MEMORY, size);
	}
	return ret;
}

int32 lpa_dma_receiveRequest(const stLPA_CTRL_t *pstCtrl, uint16 size)
{
	int32 ret = (int32)eLPA_RET_OK;
	uint32 lpa_dma_addr = pstCtrl->dmaBufAddr;
	eLPA_DMA_CH_t lpa_dma_ch = eLPA_DMA_CH0;

	lpa_dma_init(pstCtrl);
	lpa_dma_clearInterrupt(pstCtrl);
	if(pstCtrl->devPort == eLPA_PORT_PROCESSOR) {
		lpa_dma_setSrcAddr(pstCtrl, lpa_dma_ch, LPA_PROC_RADDR);
		lpa_dma_setDstAddr(pstCtrl, lpa_dma_ch, lpa_dma_addr);
	}
	else if(pstCtrl->devPort == eLPA_PORT_LOGGING) {
		lpa_dma_ch = eLPA_DMA_CH1;
		lpa_dma_setSrcAddr(pstCtrl, lpa_dma_ch, LPA_LOG_RADDR);
		lpa_dma_setDstAddr(pstCtrl, lpa_dma_ch, lpa_dma_addr);
	}
	else {
		ret = (int32)eLPA_RET_DEV_UNKNOWN_PORT;
	}
	if(ret == (int32)eLPA_RET_OK) {
		lpa_dma_ctrlInfo(pstCtrl, lpa_dma_ch, size);
		lpa_dma_confChannel(pstCtrl, lpa_dma_ch, LPA_MEMORY2MEMORY);
		lpa_dma_checkEnabledChannel(pstCtrl);
		LPA_D("DMA Channel Configuration Register: 0x%08x, Rx Word Size: 0x%04x\n", LPA_MEMORY2MEMORY, size);
		//lpa_dma_confChannel(pstCtrl, lpa_dma_ch, 0x0000D001);	// for test
	}
	return ret;
}

void lpa_dma_test_setRequest(const stLPA_CTRL_t *pstCtrl, uint32 srcaddr, uint32 dstaddr, uint16 size)
{
	lpa_dma_init(pstCtrl);
	lpa_dma_clearInterrupt(pstCtrl);
	lpa_dma_setSrcAddr(pstCtrl, eLPA_DMA_CH0, srcaddr);
	lpa_dma_setDstAddr(pstCtrl, eLPA_DMA_CH0, dstaddr);
	lpa_dma_ctrlInfo(pstCtrl, eLPA_DMA_CH0, size);
	lpa_dma_confChannel(pstCtrl, eLPA_DMA_CH0, LPA_MEMORY2MEMORY);
	LPA_D("DMA Channel Configuration Register: 0x%08x, Tx Word Size: 0x%04x\n", LPA_MEMORY2MEMORY, size);
}
