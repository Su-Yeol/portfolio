/*
***************************************************************************************************
*
*   FileName : lpa_std.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/


/****************************************
 *				Include					*
 ****************************************/
#include "lpa_types.h"

/****************************************
 *		  Variable Definitions			*
 ****************************************/

/****************************************
 *		  Function Definitions			*
 ****************************************/
 static uint8 u8add(uint8 a, uint8 b)
{
	uint8 out;
	if (b < ((uint8)U08_MAX - a)) {
		out = a + b;
	}
	else {
		out = (uint8)U08_MAX;
	}
	return out;
}

static uint16 u16add(uint16 a, uint16 b)
{
	uint16 out;
	if (b < ((uint16)U16_MAX - a)) {
		out = a + b;
	}
	else {
		out = (uint16)U16_MAX;
	}
	return out;
}

static uint32 u32add(uint32 a, uint32 b)
{
	uint32 out;
	if (b < ((uint32)UL_MAX - a)) {
		out = a + b;
	}
	else {
		out = (uint32)UL_MAX;
	}
	return out;
}

static uint8 u8sub(uint8 a, uint8 b)
{
	uint8 out = 0;
	if (a >= b)	{
		out = a - b;
	}
	return out;
}

static uint16 u16sub(uint16 a, uint16 b)
{
	uint16 out = 0;
	if (a >= b)	{
		out = a - b;
	}
	return out;
}

static uint16 u16mul(uint16 a, uint16 b)
{
	uint32 tmp;
	uint16 out = 0;

	tmp = (uint32)a * (uint32)b;
	if (tmp <= U16_MAX) {
		out = (uint16)tmp;
	}
	else {
		out = U16_MAX;
	}
	return out;
}

static uint32 u32mul(uint32 a, uint32 b)
{
	uint64 tmp;
	uint32 out = 0;

	tmp = (uint64)a * (uint64)b;
	if (tmp <= UL_MAX) {
		out = (uint32)tmp;
	}
	else {
		out = UL_MAX;
	}
	return out;
}

uint8 (*lpa_u8add)(uint8 a, uint8 b) = u8add;
uint16 (*lpa_u16add)(uint16 a, uint16 b) = u16add;
uint32 (*lpa_u32add)(uint32 a, uint32 b) = u32add;
uint8 (*lpa_u8sub)(uint8 a, uint8 b) = u8sub;
uint16 (*lpa_u16sub)(uint16 a, uint16 b) = u16sub;
uint16 (*lpa_u16mul)(uint16 a, uint16 b) = u16mul;
uint32 (*lpa_u32mul)(uint32 a, uint32 b) = u32mul;

