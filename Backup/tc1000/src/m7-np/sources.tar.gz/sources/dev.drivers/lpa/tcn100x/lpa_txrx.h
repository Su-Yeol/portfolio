/*
***************************************************************************************************
*
*   FileName : lpa_txrx.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/


#ifndef LPA_TXRX_H
#define LPA_TXRX_H

/****************************************
 *				Include					*
 ****************************************/

/****************************************
 *				Defines					*
 ****************************************/
#define LPA_WR_FRAME_MAX_SIZE	(1024U + 4U)	// data + crc
#define LPA_RD_FRAME_MAX_SIZE	(132U + 4U)		// data + crc
#define LPA_READ_OFFSET			(0x2018U)
#define LPA_READ_DATA_OFFSET	(0x2028U)

#define LPA_CRC_SIZE			(sizeof(uint32))	// 4byte
#define LPA_HEADER_SIZE_NO_CRC	(sizeof(int8) + sizeof(int8) + sizeof(uint16) + sizeof(uint16) +sizeof(uint16) + sizeof(uint32)) // 12byte
#define LPA_HEADER_SIZE			(LPA_HEADER_SIZE_NO_CRC + LPA_CRC_SIZE) // 16byte

#define LPA_RW_RETRY_COUNT		(30)	//(300)

/****************************************
 *				Enumeration				*
 ****************************************/
typedef enum {
	eLPA_AXI_UNKNOWN,
	eLPA_AXI_WRITE_NO_ANSWER,
	eLPA_AXI_WRITE_WITH_ANSWER,
	eLPA_AXI_READ
} eLPA_AXI_TYPE_t;

// Result for LPA IP
typedef enum {
	eLPA_SUCCESS,
	eLPA_UNKNOWN_ERROR,
	eLPA_TIMEOUT,
	eLPA_FIFO_FULL,
	eLPA_UNKNOWN_ID,
	eLPA_CRC_ERROR,
	eLPA_NO_DATA,
	eLPA_PROCESSING_DATA,
} eLPA_RESULT_t;

/****************************************
 *				Typedefs				*
 ****************************************/
 typedef struct stLPA_HBUF_t {
	int8 type;
	int8 result;
	uint16 size;
	uint16 idt;
	uint16 sn;
	uint32 idt_access;
	uint32 header_crc;
}stLPA_HBUF_t;

typedef struct stLPA_WBUF_t {
	stLPA_HBUF_t hdr;
	int8 data[LPA_WR_FRAME_MAX_SIZE]; 	// data + crc
}stLPA_WBUF_t;

typedef struct stLPA_RBUF_t {
	stLPA_HBUF_t hdr;
	int8 data[LPA_RD_FRAME_MAX_SIZE]; 	// data + crc
}stLPA_RBUF_t;

/****************************************
 *		  Constant Definitions			*
 ****************************************/

/****************************************
 *		  Variable Definitions			*
 ****************************************/

/****************************************
 *		  Function Definitions			*
 ****************************************/
extern int32 lpa_writeRequest(const stLPA_CTRL_t *pctrl, const stLPA_REQUEST_t *req, stLPA_RESPONSE_t *res);
extern int32 lpa_readRequest(const stLPA_CTRL_t *pctrl, const stLPA_REQUEST_t *req, stLPA_RESPONSE_t *res);

#endif

