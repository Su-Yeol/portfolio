/*
***************************************************************************************************
*
*   FileName : gpio.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_GPIO_HEADER
#define SIC_BSP_GPIO_HEADER

#include <sal_internal.h>

/*
***************************************************************************************************
*                                            GLOBAL DEFINITIONS
***************************************************************************************************
*/

#if (DEBUG_ENABLE)
    #include "debug.h"

    #define GPIO_D(fmt,args...)         {LOGD(DBG_TAG_GPIO, fmt, ## args)}
    #define GPIO_E(fmt,args...)         {LOGE(DBG_TAG_GPIO, fmt, ## args)}
#else
    #define GPIO_D(fmt,args...)
    #define GPIO_E(fmt,args...)
#endif

#ifndef ENABLE
#   define GPIO_ENABLE                  (1)
#endif

#ifndef DISABLE
#   define GPIO_DISABLE                 (0)
#endif

#define GPIO_PIN_MASK                   (0x1FUL)
#define GPIO_PIN_NUM_MASK               (0x1FUL) // original 1FUL , avoid code sonar warning

#define GPIO_PORT_SHIFT                 (5)
#define GPIO_PORT_MASK                  ((uint32)0x1F << (uint32)GPIO_PORT_SHIFT)

// GPIO group bit width
// A - D : 21
// E - J : 16
// K : 14
// L : 18

/*
 * gpio port & pin structures
 *   [31:10]: reserved
 *   [9:5] : port (A,B,C,...)
 *   [4:0] : pin number (0~31)
 */
// GPIO group offset : 0x54
#define GPIO_PORT_A                     ((uint32)0 << (uint32)GPIO_PORT_SHIFT)  // +0x00
#define GPIO_PORT_B                     ((uint32)1 << (uint32)GPIO_PORT_SHIFT)  // +0x54
#define GPIO_PORT_C                     ((uint32)2 << (uint32)GPIO_PORT_SHIFT)  // +0xA8
#define GPIO_PORT_D                     ((uint32)3 << (uint32)GPIO_PORT_SHIFT)  // +0xFC
#define GPIO_PORT_E                     ((uint32)4 << (uint32)GPIO_PORT_SHIFT)  // +0x150
#define GPIO_PORT_F                     ((uint32)5 << (uint32)GPIO_PORT_SHIFT)  // +0x1A4
#define GPIO_PORT_G                     ((uint32)6 << (uint32)GPIO_PORT_SHIFT)  // +0x1F8
#define GPIO_PORT_H                     ((uint32)7 << (uint32)GPIO_PORT_SHIFT)  // +0x24C
#define GPIO_PORT_I                     ((uint32)8 << (uint32)GPIO_PORT_SHIFT)  // +0x2A0
#define GPIO_PORT_J                     ((uint32)9 << (uint32)GPIO_PORT_SHIFT)  // +0x2F4
#define GPIO_PORT_K                     ((uint32)10 << (uint32)GPIO_PORT_SHIFT) // +0x348
#define GPIO_PORT_L                     ((uint32)11 << (uint32)GPIO_PORT_SHIFT) // +0x39C
#define GPIO_PORT_SF_0                  ((uint32)12 << (uint32)GPIO_PORT_SHIFT) // +0x3F0
#define GPIO_PORT_SF_1                  ((uint32)13 << (uint32)GPIO_PORT_SHIFT) // +0x444
#define GPIO_PORT_SD                    ((uint32)14 << (uint32)GPIO_PORT_SHIFT) // +0x498

// GPIO group index + gpio index
#define GPIO_GPA(x)                     (GPIO_PORT_A | ((x) & (uint32)0x1F))
#define GPIO_GPB(x)                     (GPIO_PORT_B | ((x) & (uint32)0x1F))
#define GPIO_GPC(x)                     (GPIO_PORT_C | ((x) & (uint32)0x1F))
#define GPIO_GPD(x)                     (GPIO_PORT_D | ((x) & (uint32)0x1F))
#define GPIO_GPE(x)                     (GPIO_PORT_E | ((x) & (uint32)0x1F))
#define GPIO_GPF(x)                     (GPIO_PORT_F | ((x) & (uint32)0x1F))
#define GPIO_GPG(x)                     (GPIO_PORT_G | ((x) & (uint32)0x1F))
#define GPIO_GPH(x)                     (GPIO_PORT_H | ((x) & (uint32)0x1F))
#define GPIO_GPI(x)                     (GPIO_PORT_I | ((x) & (uint32)0x1F))
#define GPIO_GPJ(x)                     (GPIO_PORT_J | ((x) & (uint32)0x1F))
#define GPIO_GPK(x)                     (GPIO_PORT_K | ((x) & (uint32)0x1F))
#define GPIO_GPL(x)                     (GPIO_PORT_L | ((x) & (uint32)0x1F))
#define GPIO_GPSD(x)                    (GPIO_PORT_SD | ((x) & (uint32)0x1F))
#define GPIO_GPSF_0(x)                  (GPIO_PORT_SF_0 | ((x) & (uint32)0x1F))
#define GPIO_GPSF_1(x)                  (GPIO_PORT_SF_1 | ((x) & (uint32)0x1F))

#define GPIO_GP_MAX                     GPIO_GPSD((uint32)0x1f)

#define GPIO_REG_BASE(x)                (SIC_BSP_GPIO_BASE + ((((x) & GPIO_PORT_MASK) >> (uint32)GPIO_PORT_SHIFT) * 0x54UL))

#define GPIO_REG_DATA(x)                (GPIO_REG_BASE(x) + 0x00UL)
#define GPIO_REG_DATA_OR(x)             (GPIO_REG_BASE(x) + 0x04UL)
#define GPIO_REG_DATA_BIC(x)            (GPIO_REG_BASE(x) + 0x08UL)
#define GPIO_REG_OUTEN(x)               (GPIO_REG_BASE(x) + 0x10UL)
#define GPIO_REG_PULLEN(x)              (GPIO_REG_BASE(x) + 0x14UL)
#define GPIO_REG_PULLSEL(x)             (GPIO_REG_BASE(x) + 0x18UL)
#define GPIO_REG_IEN(x)                 (GPIO_REG_BASE(x) + 0x1CUL)
#define GPIO_REG_IS(x)                  (GPIO_REG_BASE(x) + 0x20UL)
#define GPIO_REG_DS(x,pin)              ((GPIO_REG_BASE(x) + 0x24UL) + (0x4UL * ((pin) / (uint32)8)))   // driver strength
#define GPIO_REG_FN(x,pin)              ((GPIO_REG_BASE(x) + 0x34UL) + (0x4UL * ((pin) / (uint32)8)))   // fnc
#define GPIO_REG_SLEW(x,pin)            ((GPIO_REG_BASE(x) + 0x44UL) + (0x4UL * ((pin) / (uint32)8)))   // slew rate

#define GPIO_REG_CFG_PW                 (SIC_BSP_GPIO_BASE + 0x700UL)
#define GPIO_REG_CFG_WR_LOCK            (SIC_BSP_GPIO_BASE + 0x704UL)

#define GPIO_PASSWORD                   (0x5afeace5UL)  //0x5AFEACE5UL


/*
 * gpio cfg structures
 *   [31:14]: reserved
 *   [13]   : slew rate
 *   [12]   : input type
 *   [11:10]: input buffer
 *   [9]    : direction
 *   [8:6]  : driver strength (0~3)
 *   [5:4]  : pull up/down
 *   [3:0]  : function selection (0~15)
 */
#define GPIO_SLEW_SHIFT                 (13)
#define GPIO_FAST_SLEW_RATE             (0UL << (uint32)GPIO_SLEW_SHIFT)
#define GPIO_SLOW_SLEW_RATE             (1UL << (uint32)GPIO_SLEW_SHIFT)

#define GPIO_INPUT_TYPE_SHIFT           (12)
#define GPIO_INPUT_SCHMITT              (1UL << (uint32)GPIO_INPUT_TYPE_SHIFT)
#define GPIO_INPUT_CMOS                 (0UL << (uint32)GPIO_INPUT_TYPE_SHIFT)

#define GPIO_INPUTBUF_SHIFT             (10)
#define GPIO_INPUTBUF_MASK              (0x3UL)
#define GPIO_INPUTBUF_EN                ((2UL | 1UL) << (uint32)GPIO_INPUTBUF_SHIFT)
#define GPIO_INPUTBUF_DIS               ((2UL | 0UL) << (uint32)GPIO_INPUTBUF_SHIFT)

#define GPIO_OUTPUT_SHIFT               (9)
#define GPIO_OUTPUT                     (1UL << (uint32)GPIO_OUTPUT_SHIFT)
#define GPIO_INPUT                      (0UL << (uint32)GPIO_OUTPUT_SHIFT)

#define GPIO_DS_SHIFT                   (6)
#define GPIO_DS_MASK                    (0x3UL)
#define GPIO_DS(x)                      ((((x) & (uint32)GPIO_DS_MASK) | 0x4UL) << (uint32)GPIO_DS_SHIFT)

#define GPIO_PULL_SHIFT                 (4)
#define GPIO_PULL_MASK                  (0x3UL)
#define GPIO_NOPULL                     (0UL << (uint32)GPIO_PULL_SHIFT)
#define GPIO_PULLUP                     (1UL << (uint32)GPIO_PULL_SHIFT)
#define GPIO_PULLDN                     (2UL << (uint32)GPIO_PULL_SHIFT)

#define GPIO_FUNC_MASK                  (0xFUL)
#define GPIO_FUNC(x)                    ((x) & (uint32)GPIO_FUNC_MASK)


// Multi CPU Access control register -> Skip

// GPMUX configuration register
// GPSB 0-5 / I2C 0-4 / UART 0-3 / PDM 0-3/
enum gpio_gpmux_cfg_idx
{
    GPIO_GPMUX_GPSB_0   =   0,
    GPIO_GPMUX_GPSB_1,
    GPIO_GPMUX_GPSB_2,
    GPIO_GPMUX_GPSB_3,
    GPIO_GPMUX_GPSB_4,
    GPIO_GPMUX_GPSB_5,
    GPIO_GPMUX_I2C_0,
    GPIO_GPMUX_I2C_1,
    GPIO_GPMUX_I2C_2,
    GPIO_GPMUX_I2C_3,
    GPIO_GPMUX_I2C_4,
    GPIO_GPMUX_UART_0,
    GPIO_GPMUX_UART_1,
    GPIO_GPMUX_UART_2,
    GPIO_GPMUX_UART_3,
    GPIO_GPMUX_PDM_0,
    GPIO_GPMUX_PDM_1,
    GPIO_GPMUX_PDM_2,
    GPIO_GPMUX_PDM_3,
    GPIO_GPMUX_MAX
};

#define GPIO_REG_GPMUX(x)               (SIC_BSP_GPIO_BASE + 0x800UL + (x * 0x4UL))


/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/

/*
***************************************************************************************************
*                                          GPIO_Config
*
* GPIO port configuration user interface APIs.
*
* @param    [In] uiPort     :   Gpio port number
* @param    [In] uiConfig   :   Gpio port configuration
* @return
*
* Notes
*
***************************************************************************************************
*/
SALRetCode_t GPIO_Config
(
    uint32                              uiPort,
    uint32                              uiConfig
);

/*
***************************************************************************************************
*                                          GPIO_Get
*
* Gets the value of the GPIO port corresponding to the input parameter.
*
* @param    [In] uiPort     :   Gpio port number
* @return   Gpio data value (0:Low or 1:High)
*
* Notes
*
***************************************************************************************************
*/
uint8 GPIO_Get
(
    uint32                              uiPort
);

/*
***************************************************************************************************
*                                          GPIO_Set
*
* Sets the 2nd input parameter value to the GPIO port corresponding to the 1st input parameter.
*
* @param    [In] uiPort     :   Gpio port number
* @param    [In] uiData     :   Gpio data value, (0 or 1)
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
*
* Notes
*
***************************************************************************************************
*/
SALRetCode_t GPIO_Set
(
    uint32                              uiPort,
    uint32                              uiData
);

/*
***************************************************************************************************
*                                          GPIO_ToNum
*
* Returns the GPIO port pin number.
*
* @param    [In] uiPort     :   Gpio port number
* @return   Index of gpio port
*
* Notes
*
***************************************************************************************************
*/
uint32 GPIO_ToNum
(
    uint32                              uiPort
);


void GPIO_PortSel(uint32 peri_id, uint32 port);

#endif /* __BSP_GPIO__H__ */

