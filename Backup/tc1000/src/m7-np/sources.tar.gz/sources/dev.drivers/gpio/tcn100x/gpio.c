/*
***************************************************************************************************
*
*   FileName : gpio.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include <gpio.h>
#include <reg_phys.h>
#include <bsp.h>
#include "debug.h"

/*
***************************************************************************************************
*                                             LOCAL DEFINES
***************************************************************************************************
*/

/*
***************************************************************************************************
*                                             VARIABLES
***************************************************************************************************
*/

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/
#if 0
static void GPIO_Select
(
    uint32                              uiPort,
    uint32                              uiFlag
);
#endif
static void GPIO_SetRegister(uint32 addr, uint32 bit, uint32 enable)
{
    uint32 base_val;
    uint32 set_val;

    base_val    = SAL_ReadReg(addr);
    set_val     = 0UL;

    if(enable == 1UL)
    {
        set_val     = (base_val | bit);
    }
    else if(enable == 0UL)
    {
        set_val     = (base_val & ~bit);
    }
    else
    {
        // Do nothing.
    }

    SAL_WriteReg(set_val, addr);
}

/*
***************************************************************************************************
*                                          GPIO_Select
*
* @param    uiPort [in]
* @param    uiFlag [in]
*
*
* Notes
*
***************************************************************************************************
*/
#if 0
static void GPIO_Select(uint32 uiPort, uint32 uiFlag)
{
    uint32 pin;
    uint32 port;
    uint32 port_addr;
    uint32 reg;

    pin     = uiPort & (uint32)GPIO_PIN_MASK;
    port    = uiPort & (uint32)GPIO_PORT_MASK;
    reg     = 0UL;
    port_addr = 0UL;

    switch (port)
    {
        case GPIO_PORT_A:
        {
            port_addr = SIC_BSP_PMU_BASE + GPIO_GPIOA_SEL_OFFSET;
            break;
        }

        case GPIO_PORT_B:
        {
            port_addr = SIC_BSP_PMU_BASE + GPIO_GPIOB_SEL_OFFSET;
            break;
        }

        case GPIO_PORT_C:
        {
            port_addr = SIC_BSP_PMU_BASE + GPIO_GPIOC_SEL_OFFSET;
            break;
        }

        case GPIO_PORT_E:
        {
            port_addr = SIC_BSP_PMU_BASE + GPIO_GPIOE_SEL_OFFSET;
            break;
        }

        case GPIO_PORT_G:
        {
            port_addr = SIC_BSP_PMU_BASE + GPIO_GPIOG_SEL_OFFSET;
            break;
        }

        case GPIO_PORT_H:
        {
            port_addr = SIC_BSP_PMU_BASE + GPIO_GPIOH_SEL_OFFSET;
            break;
        }

        default:
        {
            GPIO_E("\n Can't find GPIO Port select\n");
            break;
        }
    }

    if(uiFlag == (uint32)GPIO_SEL_AP)
    {
        reg = SAL_ReadReg(port_addr) | ((uint32)0x1 << pin);

    }
    else
    {
        reg = SAL_ReadReg(port_addr) & ~((uint32)0x1UL << pin);
    }

    SAL_WriteReg(reg, port_addr);

}
#endif
/*
***************************************************************************************************
*                                          GPIO_Config
*
* GPIO port configuration user interface APIs.
*
* @param    [In] uiPort     :   Gpio port number
* @param    [In] uiConfig   :   Gpio port configuration
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
*
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPIO_Config
(
    uint32                              uiPort,
    uint32                              uiConfig
)
{
    uint32 pin;
    uint32 bit;
    uint32 func;
    uint32 pull;
    uint32 ds;
    uint32 ien;
    uint32 sr;
    uint32 base_val;
    //uint32 comp_val;
    uint32 set_val;
    uint32 reg_fn;
    uint32 pullen_addr;
    uint32 pullsel_addr;
    uint32 ds_addr;
    uint32 outen_addr;
    uint32 ien_addr;
    uint32 is_addr;
    SALRetCode_t ret;

    ret     = SAL_RET_SUCCESS;
    pin     = uiPort & (uint32)GPIO_PIN_MASK;
    bit     = (uint32)1 << pin;
    func    = uiConfig & (uint32)GPIO_FUNC_MASK;
    pull    = uiConfig & ((uint32)GPIO_PULL_MASK << (uint32)GPIO_PULL_SHIFT);
    ds      = uiConfig & ((uint32)GPIO_DS_MASK << (uint32)GPIO_DS_SHIFT);
    ien     = uiConfig & ((uint32)GPIO_INPUTBUF_MASK << (uint32)GPIO_INPUTBUF_SHIFT);
    sr     = uiConfig & ((uint32)GPIO_INPUTBUF_MASK << (uint32)GPIO_INPUTBUF_SHIFT);

    // tcn100x not support ?
    //GPIO_Select(uiPort, GPIO_SEL_MCU); // gpio select change to micom

    /* function */
    reg_fn      = GPIO_REG_FN(uiPort,pin);
    base_val    = SAL_ReadReg(reg_fn) & (~((uint32)0xF<<((pin%(uint32)8)*(uint32)4)));
    set_val     = base_val | (func<<((pin%(uint32)8)*(uint32)4));
    SAL_WriteReg(set_val, reg_fn);


    /* pull-up/down */
    if (pull == GPIO_PULLUP)
    {
        pullen_addr = GPIO_REG_PULLEN(uiPort);
        pullsel_addr = GPIO_REG_PULLSEL(uiPort);

        GPIO_SetRegister(pullen_addr, bit, (uint32)TRUE);
        GPIO_SetRegister(pullsel_addr, bit, (uint32)TRUE);
    }
    else if (pull == GPIO_PULLDN)
    {
        pullen_addr = GPIO_REG_PULLEN(uiPort);
        pullsel_addr = GPIO_REG_PULLSEL(uiPort);

        GPIO_SetRegister(pullen_addr, bit, (uint32)TRUE);
        GPIO_SetRegister(pullsel_addr, bit, (uint32)FALSE);
    }
    else
    {
        pullen_addr = GPIO_REG_PULLEN(uiPort);
        GPIO_SetRegister(pullen_addr, bit, (uint32)FALSE);
    }

    /* drive strength */
    if (ds != 0UL)
    {
        ds_addr = GPIO_REG_DS(uiPort, pin);

        ds          = ds >> (uint32)GPIO_DS_SHIFT;
        base_val    = SAL_ReadReg(ds_addr) & ~((uint32)0xf << ((pin % (uint32)8) * (uint32)4));
        set_val     = base_val | ((ds & (uint32)0xf) << ((pin % (uint32)8) * (uint32)4));
        SAL_WriteReg(set_val, ds_addr);
    }

    /* direction */
    if ((uiConfig&GPIO_OUTPUT) != 0UL)
    {
        outen_addr  = GPIO_REG_OUTEN(uiPort);
        GPIO_SetRegister(outen_addr, bit, (uint32)TRUE);
    }
    else
    {
        outen_addr  = GPIO_REG_OUTEN(uiPort);
        GPIO_SetRegister(outen_addr, bit, (uint32)FALSE);
    }

    /* input buffer enable */
    if (ien == GPIO_INPUTBUF_EN)
    {
        ien_addr = GPIO_REG_IEN(uiPort);
        GPIO_SetRegister(ien_addr, bit, (uint32)TRUE);
    }
    else if (ien == GPIO_INPUTBUF_DIS)
    {
        ien_addr = GPIO_REG_IEN(uiPort);
        GPIO_SetRegister(ien_addr, bit, (uint32)FALSE);
    }
    else //QAC
    {
        ; // no statement
    }

    /* input type */
    if ((uiConfig & GPIO_INPUT_SCHMITT) != 0UL)
    {
        is_addr = GPIO_REG_IS(uiPort);
        GPIO_SetRegister(is_addr, bit, (uint32)TRUE);
    }
    else
    {
        is_addr = GPIO_REG_IS(uiPort);
        GPIO_SetRegister(is_addr, bit, (uint32)FALSE);
    }

    /* slew rate */
    if ((uiConfig & GPIO_SLOW_SLEW_RATE) != 0UL)
    {
        is_addr = GPIO_REG_SLEW(uiPort, pin);
        GPIO_SetRegister(is_addr, bit, (uint32)TRUE);
    }
    else
    {
        is_addr = GPIO_REG_SLEW(uiPort, pin);
        GPIO_SetRegister(is_addr, bit, (uint32)FALSE);
    }


    return ret;
}

/*
***************************************************************************************************
*                                          GPIO_Get
*
* Gets the value of the GPIO port corresponding to the input parameter.
*
* @param    [In] uiPort     :   Gpio port number
* @return   Gpio data value (0:Low or 1:High)
*
* Notes
*
***************************************************************************************************
*/

uint8 GPIO_Get
(
    uint32                              uiPort
)
{
    uint32 reg_data;
    uint32 value;
    uint8  ret;

    reg_data    = GPIO_REG_DATA(uiPort);
    value       = (SAL_ReadReg(reg_data) & ((uint32)1 << (uiPort & GPIO_PIN_MASK)));

    if (value != 0UL)
    {
        ret = (uint8)1;
    }
    else
    {
        ret = (uint8)0;
    }

    return ret;
}


/*
***************************************************************************************************
*                                          GPIO_Set
*
* Sets the 2nd input parameter value to the GPIO port corresponding to the 1st input parameter.
*
* @param    [In] uiPort     :   Gpio port number
* @param    [In] uiData     :   Gpio data value, (0 or 1)
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
*
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPIO_Set
(
    uint32                              uiPort,
    uint32                              uiData
)
{
    uint32 bit;
    uint32 data_or;
    uint32 data_bic;
    SALRetCode_t ret;

    ret = SAL_RET_SUCCESS;

    bit = (uint32)1 << (uiPort & GPIO_PIN_MASK);
    //GPIO_Select(uiPort, GPIO_SEL_MCU);

    if (uiData > 1UL)
    {
        ret = SAL_RET_FAILED;
    }
    else
    {
        /* set data */
        if (uiData!=0UL)
        {
            data_or = GPIO_REG_DATA_OR(uiPort);
            SAL_WriteReg(bit, data_or);
        }
        else
        {
            data_bic = GPIO_REG_DATA_BIC(uiPort);
            SAL_WriteReg(bit, data_bic);
        }
    }

    return ret;
}


/*
***************************************************************************************************
*                                          GPIO_ToNum
*
* Returns the GPIO port pin number.
*
* @param    [In] uiPort     :   Gpio port number
* @return   Index of gpio port
*
* Notes
*
***************************************************************************************************
*/
uint32 GPIO_ToNum
(
    uint32                              uiPort
)
{
    uint32 pin;
    uint32 ret;
    uint32 port;

    pin = uiPort & GPIO_PIN_NUM_MASK;
    ret = 0UL;
    port = uiPort & GPIO_PORT_MASK;

    switch (port)
    {
        case GPIO_PORT_A:   // 21
        {
            ret = pin;
            break;
        }

        case GPIO_PORT_B:   // 21
        {
            ret = (21 + pin);
            break;
        }
        case GPIO_PORT_C:   // 21
        {
            ret = (42 + pin);
            break;
        }
        case GPIO_PORT_D:   // 21
        {
            ret = (63 + pin);
            break;
        }
        case GPIO_PORT_E:   // 16
        {
            ret = (84 + pin);
            break;
        }
        case GPIO_PORT_F:   // 16
        {
            ret = (100 + pin);
            break;
        }
        case GPIO_PORT_G:   // 16
        {
            ret = (116 + pin);
            break;
        }
        case GPIO_PORT_H:   // 16
        {
            ret = (132 + pin);
            break;
        }
        case GPIO_PORT_I:   // 16
        {
            ret = (148 + pin);
            break;
        }
        case GPIO_PORT_J:   // 16
        {
            ret = (164 + pin);
            break;
        }
        case GPIO_PORT_K:   // 14
        {
            ret = (180 + pin);
            break;
        }
        case GPIO_PORT_L:   // 18
        {
            ret = (204 + pin);
            break;
        }
        default:
        {
            GPIO_E("\n Can't find GPIO Port \n");
            ret = 0UL;
            break;
        }
    }

    return ret;
}

// draft
void GPIO_PortSel(uint32 peri_id, uint32 port)
{
    uint32 addr = GPIO_REG_GPMUX(peri_id);

    if(peri_id < GPIO_GPMUX_I2C_0)
    {
        // valid port value : 0 - 18 for GPSB
        if(port <= 0x1F)
        {
            SAL_WriteReg(port, addr);
        }
        else
        {
            GPIO_E("Invalid port value.\n");
        }
    }
    else if(peri_id < GPIO_GPMUX_UART_0)
    {
        // valid port value : 0 - 44 for I2C
        if(port <= 0x3F)
        {
            SAL_WriteReg(port, addr);
        }
        else
        {
            GPIO_E("Invalid port value.\n");
        }
    }
    else if(peri_id < GPIO_GPMUX_PDM_0)
    {
        // valid port value : 0 - 25 for UART
        if(port <= 0x1F)
        {
            SAL_WriteReg(port, addr);
        }
        else
        {
            GPIO_E("Invalid port value.\n");
        }
    }
    else
    {
        // valid port value : 0 - 69 for PDM
        if(port <= 0x7F)
        {
            SAL_WriteReg(port, addr);
        }
        else
        {
            GPIO_E("Invalid port value.\n");
        }
    }
}
