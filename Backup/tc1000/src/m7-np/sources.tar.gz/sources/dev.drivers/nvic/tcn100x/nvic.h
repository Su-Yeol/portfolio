/*
***************************************************************************************************
*
*   FileName : nvic.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef __IRQ_H__
#define __IRQ_H__
#include <sal_internal.h>

#include "TCN100x.h"

typedef void (*IrqHandler_t)(void);

SALRetCode_t NVIC_SetPIC(void);
uint32 NVIC_GetLocalIrqNum(IRQn_Type xIrqNum);


SALRetCode_t NVIC_Init(void);

SALRetCode_t NVIC_IntVectSet(IRQn_Type xIrqNum, IrqHandler_t pfnIrqHandler);
SALRetCode_t NVIC_IntSrcEn(IRQn_Type xIrqNum);
SALRetCode_t NVIC_IntSrcDis(IRQn_Type xIrqNum);

#endif /* __IRQ_H__ */
