/*
***************************************************************************************************
*
*   FileName : nvic.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include "nvic.h"
#include "debug.h"

#define irqNVIC_EIRQ_OFFSET		(16u)

#define PIC_BASE_ADDR                   (0x4B500000UL)




#if ( CORTEX_M7_0 == 1 )
#define PIC_ISC_OFFSET                  (PIC_BASE_ADDR + 0x03CUL)
#define PIC_EN_BIT                      (1)
#elif ( CORTEX_M7_1 == 1)
#define PIC_ISC_OFFSET                  (PIC_BASE_ADDR + 0x078UL)
#define PIC_EN_BIT                      (2)
#elif ( CORTEX_M7_2 == 1)
#define PIC_ISC_OFFSET                  (PIC_BASE_ADDR + 0x0B4UL)
#define PIC_EN_BIT                      (4)
#elif ( CORTEX_M7_NP == 1)
#define PIC_ISC_OFFSET                  (PIC_BASE_ADDR + 0x0F0UL)
#define PIC_EN_BIT                      (8)
#endif
#define PIC_SET_EN                      (PIC_BASE_ADDR + 0x12CUL)
#define PIC_DONE_STS                    (PIC_BASE_ADDR + 0x130UL)

#define PIC_IDX_MAX                     (480ul)

static uint32 guiIrqRemap[PIC_IDX_MAX] = {0};




uint32 NVIC_GetLocalIrqNum(IRQn_Type xIrqNum)
{
    uint32 uiRet = 0xFFFFFFFFu;

    if((uint32)xIrqNum < PIC_IDX_MAX)
    {
        uiRet = guiIrqRemap[xIrqNum];
    }

    return uiRet;

}

/*
NOTE >!!
This function is a test function for verification,
so it should not be used for purposes other than verification.
Other side effects may occur if the PIC's IRQ is assigned at the FW level.
Please use for verification purposes only.

! Enter the irqs to be registered in uiLocalTable,
but assign them in order, starting from the smallest idx.
*/

SALRetCode_t NVIC_SetPIC(void)
{
    static uint32 uiLocalTable[] = {
        TMR0_16_0_IRQn,     TMR0_16_1_IRQn,     TMR0_16_2_IRQn,     TMR0_16_3_IRQn,
        TMR0_20_0_IRQn,     TMR0_20_1_IRQn,     TMR0_WDT_IRQn,      TMR0_32_IRQn,
        TMR1_16_0_IRQn,     TMR1_16_1_IRQn,     TMR1_16_2_IRQn,     TMR1_16_3_IRQn,
        TMR1_20_0_IRQn,     TMR1_20_1_IRQn,     TMR1_WDT_IRQn,      TMR1_32_IRQn,

        I2C_M_CH0_IRQn,     I2C_M_CH1_IRQn,     I2C_M_CH2_IRQn,     I2C_M_CH3_IRQn,
        I2C_M_CH4_IRQn,

        UART_C0_IRQn,       UART_C1_IRQn,       UART_C2_IRQn,       UART_C3_IRQn,
        UART_DMA_C0_IRQn,   UART_DMA_C1_IRQn,   UART_DMA_C2_IRQn,   UART_DMA_C3_IRQn,

        GPSB_C0_IRQn,       GPSB_DMA_C0_IRQn,   GPSB_C1_IRQn,       GPSB_DMA_C1_IRQn,
        GPSB_C2_IRQn,       GPSB_DMA_C2_IRQn,   GPSB_C3_IRQn,       GPSB_DMA_C3_IRQn,
        GPSB_C4_IRQn,       GPSB_DMA_C4_IRQn,   GPSB_C5_IRQn,       GPSB_DMA_C5_IRQn,
        GMAC0_SB_IRQn,      GMAC1_SB_IRQn,

        CAN_C0_0_IRQn,      CAN_C1_0_IRQn,      CAN_C2_0_IRQn,      CAN_C3_0_IRQn,

        IC_TC0_IRQn,        IC_TC1_IRQn,        IC_TC2_IRQn,

        MBOX_HSM_M0_MST_TX_IRQn, MBOX_HSM_M0_MST_RX_IRQn,
        MBOX_HSM_M1_MST_TX_IRQn, MBOX_HSM_M1_MST_RX_IRQn,
        MBOX_HSM_M2_MST_TX_IRQn, MBOX_HSM_M2_MST_RX_IRQn,

        M7_0_WDT_IRQn,      M7_1_WDT_IRQn,      M7_2_WDT_IRQn,      MX_WDT_IRQn,
        FMU_IRQ_IRQn,       FMU_FIQ_IRQn,       RESETVED5_IRQn,     RTC_IRQn,

#if ( CORTEX_M7_0 == 1)
		MBOX_A65_M0_NS_MST_TX_IRQn,
		MBOX_M0_M1_SLV_TX_IRQn,
		MBOX_M0_M2_SLV_TX_IRQn,
		MBOX_M0_MX_SLV_TX_IRQn,
#elif ( CORTEX_M7_1 == 1)
		MBOX_A65_M1_NS_MST_TX_IRQn,
		MBOX_M0_M1_MST_TX_IRQn,
		MBOX_M1_M2_SLV_TX_IRQn,
		MBOX_M1_MX_SLV_TX_IRQn,
#elif ( CORTEX_M7_2 == 1)
		MBOX_A65_M2_NS_MST_TX_IRQn,
		MBOX_M0_M2_MST_TX_IRQn,
		MBOX_M1_M2_MST_TX_IRQn,
		MBOX_M2_MX_SLV_TX_IRQn,
#elif ( CORTEX_M7_NP == 1)
		LPA_HOST_AXI_IRQn,  LPA_LOG_AXI_IRQn,   LPA_ERROR_AXI_IRQn, LPA_DMA_ERROR_IRQn,
		LPA_DMA_COUNT_IRQn, LPA_DMA_COMBINE_IRQn, TPA_EPP_INT1_IRQn,

		MBOX_A65_MX_NS_MST_TX_IRQn,
		MBOX_M0_MX_MST_TX_IRQn,
		MBOX_M1_MX_MST_TX_IRQn,
		MBOX_M2_MX_MST_TX_IRQn,
#endif

                                   };
    uint32 uiArrayCnt      = 0u;
    SALRetCode_t ret       = SAL_RET_FAILED;
    uint32 uiReg           = 0u;
    uint32 uiRegOffset     = PIC_ISC_OFFSET;
    uint32 uiValue         = 0u;
    uint32 uiDone          = 0u;
    uint32 uiEn            = 0u;
    uint32 uiMaskingBit    = 1u;

    uint32 uiI;

    uiArrayCnt = sizeof(uiLocalTable) / sizeof(uint32);
    uiEn = SAL_ReadReg(PIC_SET_EN);

    uiValue = (uiEn & (~PIC_EN_BIT));

    SAL_WriteReg(uiValue, PIC_SET_EN);


    for(uiI = 0u ; uiI < uiArrayCnt; uiI ++)
    {
       uiReg = uiRegOffset + (uiLocalTable[uiI] / 32u) * 4u;
       uiMaskingBit = 1u << (uiLocalTable[uiI] % 32u);

       uiValue = SAL_ReadReg(uiReg);
       uiValue = (uiValue | uiMaskingBit);
       SAL_WriteReg(uiValue, uiReg);
    }

    uiEn = SAL_ReadReg(PIC_SET_EN);

    uiValue = (uiEn | PIC_EN_BIT);

    SAL_WriteReg(uiValue, PIC_SET_EN);

    do
    {
        uiDone = SAL_ReadReg(PIC_DONE_STS);
    }while((uiDone & PIC_EN_BIT) != PIC_EN_BIT);


    return ret;
}


SALRetCode_t NVIC_Init()
{

    SALRetCode_t ret       = SAL_RET_FAILED;
    uint32 uiReg           = PIC_ISC_OFFSET;
    uint32 uiValue         = 0u;
    uint32 uiDone          = 0u;
    uint32 uiMaskingBit    = 1u;
    uint32 uiLocalIrgNum   = 0u;

    uint32 uiI;

    SAL_MemSet(guiIrqRemap, 0xFF, (PIC_IDX_MAX * 4u));
    uiDone = SAL_ReadReg(PIC_DONE_STS);

    if((uiDone & PIC_EN_BIT) == PIC_EN_BIT)
    {
        for(uiI = 0u; uiI < PIC_IDX_MAX; uiI ++)
        {

            if((uiI % 32) == 0)
            {
                uiValue = SAL_ReadReg(uiReg);
                uiMaskingBit = 1u;
                uiReg = uiReg + 4u;
            }

            if((uiValue & uiMaskingBit) == uiMaskingBit)
            {
                guiIrqRemap[uiI] = uiLocalIrgNum;
                uiLocalIrgNum ++;
            }
            uiMaskingBit = (uiMaskingBit << 1);
        }
    }
    else
    {
        mcu_printf("There is no interrupt source assigned to the corresponding mcu.\n");
    }

    NVIC_SetPriorityGrouping(2);//A value greater than 2 causes a hard fault when calling svc.

    for(uiI = 0u; uiI < 240; uiI ++)
    {
        NVIC_SetPriority((IRQn_Type)uiI, 0x10u);
    }

    return ret;
}

SALRetCode_t NVIC_IntVectSet(IRQn_Type xIrqNum, IrqHandler_t pfnIrqHandler)
{
    uint32 *xNvicTbl;
    SALRetCode_t ret = SAL_RET_FAILED;
    uint32 uiLocalIrqIdx = 0u;

    uiLocalIrqIdx = NVIC_GetLocalIrqNum(xIrqNum);
    //if ((uint32)(xIrqNum) >= 0)
    if(uiLocalIrqIdx != 0xFFFFFFFFu)
    {
        xNvicTbl = (uint32 *)(SAL_ReadReg(0xE000ED08u));
        xNvicTbl[uiLocalIrqIdx + irqNVIC_EIRQ_OFFSET] = (uint32)(pfnIrqHandler);

        SCB_CleanInvalidateDCache_by_Addr(&xNvicTbl[uiLocalIrqIdx + irqNVIC_EIRQ_OFFSET], 32);

        ret = SAL_RET_SUCCESS;
    }
    return ret;
}


SALRetCode_t NVIC_IntSrcEn(IRQn_Type xIrqNum)
{
    SALRetCode_t ret = SAL_RET_FAILED;
    uint32 uiLocalIrqIdx = 0u;

    uiLocalIrqIdx = NVIC_GetLocalIrqNum(xIrqNum);

    //if ((uint32)(xIrqNum) >= 0)
    if(uiLocalIrqIdx != 0xFFFFFFFFu)
    {
        NVIC_DisableIRQ(uiLocalIrqIdx);
        NVIC_ClearPendingIRQ(uiLocalIrqIdx);
        NVIC_EnableIRQ(uiLocalIrqIdx);
        ret = SAL_RET_SUCCESS;
    }
    return ret;
}

SALRetCode_t NVIC_IntSrcDis(IRQn_Type xIrqNum)
{
    SALRetCode_t ret = SAL_RET_FAILED;
    uint32 uiLocalIrqIdx = 0u;

    uiLocalIrqIdx = NVIC_GetLocalIrqNum(xIrqNum);

    //if ((uint32)(xIrqNum) >= 0)
    if(uiLocalIrqIdx != 0xFFFFFFFFu)
    {
        NVIC_DisableIRQ(uiLocalIrqIdx);
        NVIC_ClearPendingIRQ(uiLocalIrqIdx);
        ret = SAL_RET_SUCCESS;
    }

    return ret;

}

