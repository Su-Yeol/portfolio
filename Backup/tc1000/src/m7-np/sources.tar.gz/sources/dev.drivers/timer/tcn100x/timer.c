/*
***************************************************************************************************
*
*   FileName : timer.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include "timer.h"

#include <reg_phys.h>
#include <bsp.h>
//#include <gic.h>
#include <nvic.h>
#include <gpio.h>
#include <debug.h>

#include <clock.h>
#include <clock_dev.h>

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/
#if (DEBUG_ENABLE)
// Deviation Record - MISRA C-2012 Rule 20.10, Preprocessing Directives
#   include <debug.h>
#   define TMR_D(fmt, args...)          {LOGD(DBG_TAG_TIMER, fmt, ## args)}
#   define TMR_E(fmt, args...)          {LOGE(DBG_TAG_TIMER, fmt, ## args)}
#else
#   define TMR_D(fmt, args...)
#   define TMR_E(fmt, args...)
#endif


#define TIMER_BASE_ADDR(CHIDX)              ((0x4B400000) + (((CHIDX>>4) * 0x10000u)) )

#define TIMER_REG_TCFG(CHIDX)               ( (TIMER_BASE_ADDR(CHIDX))+(((CHIDX & 0x7) % 0x6)* 0x10u )+(0x0000u))
#define TIMER_REG_TCNT(CHIDX)               ( (TIMER_BASE_ADDR(CHIDX))+(((CHIDX & 0x7) % 0x6)* 0x10u )+(0x0004u))
#define TIMER_REG_TREF(CHIDX)               ( (TIMER_BASE_ADDR(CHIDX))+(((CHIDX & 0x7) % 0x6)* 0x10u )+(0x0008u))
#define TIMER_REG_TMREF(CHIDX)              ( (TIMER_BASE_ADDR(CHIDX))+(((CHIDX & 0x7) % 0x6)* 0x10u )+(0x000cu))
#define TIMER_REG_TIREQ(CHIDX)              ( (TIMER_BASE_ADDR(CHIDX))+ (0x0060u))

#define TIMER_REG_TC32EN(CHIDX)             ( (TIMER_BASE_ADDR(CHIDX))+ (0x0080u))
#define TIMER_REG_TC32LVD(CHIDX)            ( (TIMER_BASE_ADDR(CHIDX))+ (0x0084u))
#define TIMER_REG_TC32CMP0(CHIDX)           ( (TIMER_BASE_ADDR(CHIDX))+ (0x0088u))
#define TIMER_REG_TC32CMP1(CHIDX)           ( (TIMER_BASE_ADDR(CHIDX))+ (0x008Cu))
#define TIMER_REG_TC32PCNT(CHIDX)           ( (TIMER_BASE_ADDR(CHIDX))+ (0x0090u))
#define TIMER_REG_TC32MCNT(CHIDX)           ( (TIMER_BASE_ADDR(CHIDX))+ (0x0094u))
#define TIMER_REG_TC32IRQ(CHIDX)            ( (TIMER_BASE_ADDR(CHIDX))+ (0x0098u))



/* TCFGn Configuration Value */
#define TMR_OP_CFG_STOP                 (1UL << 9UL)
#define TMR_OP_CFG_CC                   (1UL << 8UL)
#define TMR_OP_CFG_FALLING              (1UL << 7UL)
#define TMR_OP_CFG_TCKSEL(k)            (((k) & 0x7) << 4UL)
#define TMR_OP_CFG_IEN                  (1UL << 3UL)
#define TMR_OP_CFG_PDM                  (1UL << 2UL)
#define TMR_OP_CFG_CON                  (1UL << 1UL)
#define TMR_OP_CFG_EN                   (1UL << 0UL)

/* TIREQ Configuration Value */
#define TMR_IREQ_TF5                   (1UL << 13UL)
#define TMR_IREQ_TF4                   (1UL << 12UL)
#define TMR_IREQ_TF3                   (1UL << 11UL)
#define TMR_IREQ_TF2                   (1UL << 10UL)
#define TMR_IREQ_TF1                   (1UL << 9UL)
#define TMR_IREQ_TF0                   (1UL << 8UL)

#define TMR_IREQ_TI5                   (1UL << 5UL)
#define TMR_IREQ_TI4                   (1UL << 4UL)
#define TMR_IREQ_TI3                   (1UL << 3UL)
#define TMR_IREQ_TI2                   (1UL << 2UL)
#define TMR_IREQ_TI1                   (1UL << 1UL)
#define TMR_IREQ_TI0                   (1UL << 0UL)


/* TC32EN Configuration Value */

#define TMR_OP32_CFG_LDM1               (1UL << 29UL)
#define TMR_OP32_CFG_LDM0               (1UL << 28UL)
#define TMR_OP32_CFG_STOP               (1UL << 26UL)
#define TMR_OP32_CFG_LDZERO             (1UL << 25UL)
#define TMR_OP32_CFG_EN                 (1UL << 24UL)

/* IRQ_CTRL Configuration Value */
#define TMR_IRQ_CLR_WHEN_WRITING        (1UL << 31UL)

#define TMR_IRQ_CTRL_CMP0               (0x1UL << 16UL)
#define TMR_IRQ_CTRL_CMP1               (0x2UL << 16UL)
#define TMR_IRQ_CTRL_MAINCNT            (0x4UL << 16UL)
#define TMR_IRQ_CTRL_PRESCALECNT        (0x8UL << 16UL)
#define TMR_IRQ_CTRL_BITSEL             (0x10UL << 16UL)
#define TMR_IRQ_CTRL_MASK               (0x1FUL << 16UL)

#define TMR_IRQ_BITSEL(k)               (((k) & 0x3fU) << 24UL)


static inline uint32 TIMER_READREG(uint32 uiAddr)
{
    uint32 uiRet = 0u;
    uiRet = SAL_ReadReg(uiAddr);
    return uiRet;
}

static inline void TIMER_WRITEREG(uint32 uiValue, uint32 uiAddr)
{
    SAL_WriteReg(uiValue, uiAddr);
    return;
}

/* PDM port selection */
/*
uiTick->ctGPIO

(void)GPIO_Config(GPIO_GPA(15u), GPIO_FUNC(5U) | GPIO_NOPULL | GPIO_INPUTBUF_EN);              //dqs


 GPIO_A[15]..TCO_0[0]..Func 5
 GPIO_A[17]..TCO_0[1]..Func 5
 GPIO_A[19]..TCO_0[2]..Func 5
 GPIO_B[15]..TCO_0[3]..Func 5
 GPIO_B[17]..TCO_0[4]..Func 5
 GPIO_B[19]..TCO_0[5]..Func 5

 GPIO_C[15]..TCO_1[0]..Func 5
 GPIO_C[17]..TCO_1[1]..Func 5
 GPIO_C[19]..TCO_1[2]..Func 5
 GPIO_D[15]..TCO_1[3]..Func 5
 GPIO_D[17]..TCO_1[4]..Func 5
 GPIO_D[19]..TCO_1[5]..Func 5

 GPIO_E[00]..TCO_0[0]..Func 5
 GPIO_E[02]..TCO_0[1]..Func 5
 GPIO_E[04]..TCO_0[2]..Func 5
 GPIO_E[06]..TCO_0[3]..Func 5
 GPIO_E[08]..TCO_0[4]..Func 5
 GPIO_E[10]..TCO_0[5]..Func 5

 GPIO_E[12]..TCO_1[0]..Func 5
 GPIO_E[14]..TCO_1[1]..Func 5
 GPIO_F[00]..TCO_1[2]..Func 5
 GPIO_F[02]..TCO_1[3]..Func 5
 GPIO_F[04]..TCO_1[4]..Func 5
 GPIO_F[06]..TCO_1[5]..Func 5

 GPIO_F[08]..TCO_0[0]..Func 5
 GPIO_F[10]..TCO_0[1]..Func 5
 GPIO_F[12]..TCO_0[2]..Func 5
 GPIO_F[14]..TCO_0[3]..Func 5
 GPIO_G[00]..TCO_0[4]..Func 5
 GPIO_G[02]..TCO_0[5]..Func 5

 GPIO_G[04]..TCO_1[0]..Func 5
 GPIO_G[06]..TCO_1[1]..Func 5
 GPIO_G[08]..TCO_1[2]..Func 5
 GPIO_G[10]..TCO_1[3]..Func 5
 GPIO_G[12]..TCO_1[4]..Func 5
 GPIO_G[14]..TCO_1[5]..Func 5

 GPIO_H[00]..TCO_0[0]..Func 5
 GPIO_H[02]..TCO_0[1]..Func 5
 GPIO_H[04]..TCO_0[2]..Func 5
 GPIO_H[06]..TCO_0[3]..Func 5
 GPIO_H[08]..TCO_0[4]..Func 5
 GPIO_H[10]..TCO_0[5]..Func 5

 GPIO_H[12]..TCO_1[0]..Func 5
 GPIO_H[14]..TCO_1[1]..Func 5
 GPIO_I[00]..TCO_1[2]..Func 5
 GPIO_I[02]..TCO_1[3]..Func 5
 GPIO_I[04]..TCO_1[4]..Func 5
 GPIO_I[06]..TCO_1[5]..Func 5

 GPIO_I[08]..TCO_0[0]..Func 5
 GPIO_I[10]..TCO_0[1]..Func 5
 GPIO_I[12]..TCO_0[2]..Func 5
 GPIO_I[14]..TCO_0[3]..Func 5
 GPIO_J[00]..TCO_0[4]..Func 5
 GPIO_J[02]..TCO_0[5]..Func 5

 GPIO_J[04]..TCO_1[0]..Func 5
 GPIO_J[06]..TCO_1[1]..Func 5
 GPIO_J[08]..TCO_1[2]..Func 5
 GPIO_J[10]..TCO_1[3]..Func 5
 GPIO_J[12]..TCO_1[4]..Func 5
 GPIO_J[14]..TCO_1[5]..Func 5

 GPIO_L[00]..TCO_0[0]..Func 5
 GPIO_L[02]..TCO_0[1]..Func 5
 GPIO_L[04]..TCO_0[2]..Func 5
 GPIO_L[06]..TCO_0[3]..Func 5
 GPIO_L[08]..TCO_0[4]..Func 5
 GPIO_L[10]..TCO_0[5]..Func 5

 GPIO_L[12]..TCO_1[0]..Func 5
 GPIO_L[14]..TCO_1[1]..Func 5
 GPIO_L[16]..TCO_1[2]..Func 5

*/

static uint32 TIMER_TCO_portset(uint32 uiCh, uint32 uiPort)
{
    uint32 uiRet = 1u;

    if((uiCh == TMRCH16_0) && \
        ((uiPort == GPIO_GPA(15u)) || (uiPort == GPIO_GPE(0u)) || (uiPort == GPIO_GPF(8u)) ||\
        (uiPort == GPIO_GPH(0u))  || (uiPort == GPIO_GPI(8u)) || (uiPort == GPIO_GPL(0u))) )
    {
        uiRet = 0u;
    }
    else if((uiCh == TMRCH16_1) && \
        ((uiPort == GPIO_GPA(17u)) || (uiPort == GPIO_GPE(2u)) || (uiPort == GPIO_GPF(10u)) ||\
        (uiPort == GPIO_GPH(2u))  || (uiPort == GPIO_GPI(10u)) || (uiPort == GPIO_GPL(2u))) )
    {
        uiRet = 0u;
    }
    else if((uiCh == TMRCH16_2) && \
        ((uiPort == GPIO_GPA(19u)) || (uiPort == GPIO_GPE(4u)) || (uiPort == GPIO_GPF(12u)) ||\
        (uiPort == GPIO_GPH(4u))  || (uiPort == GPIO_GPI(12u)) || (uiPort == GPIO_GPL(4u))) )
    {
        uiRet = 0u;
    }
    else if((uiCh == TMRCH16_3) && \
        ((uiPort == GPIO_GPB(15u)) || (uiPort == GPIO_GPE(6u)) || (uiPort == GPIO_GPF(14u)) ||\
        (uiPort == GPIO_GPH(6u))  || (uiPort == GPIO_GPI(14u)) || (uiPort == GPIO_GPL(6u))) )
    {
        uiRet = 0u;
    }
    else if((uiCh == TMRCH20_0) && \
        ((uiPort == GPIO_GPB(17u)) || (uiPort == GPIO_GPE(8u)) || (uiPort == GPIO_GPG(0u)) ||\
        (uiPort == GPIO_GPH(8u))  || (uiPort == GPIO_GPJ(0u)) || (uiPort == GPIO_GPL(8u))) )
    {
        uiRet = 0u;
    }
    else if((uiCh == TMRCH20_1) && \
        ((uiPort == GPIO_GPB(19u)) || (uiPort == GPIO_GPE(10u)) || (uiPort == GPIO_GPG(2u)) ||\
        (uiPort == GPIO_GPH(10u))  || (uiPort == GPIO_GPJ(2u)) || (uiPort == GPIO_GPL(10u))) )
    {
        uiRet = 0u;
    }
    else if((uiCh == TMRCH16_4) && \
        ((uiPort == GPIO_GPC(15u)) || (uiPort == GPIO_GPE(12u)) || (uiPort == GPIO_GPG(4u)) ||\
        (uiPort == GPIO_GPH(12u))  || (uiPort == GPIO_GPJ(4u)) || (uiPort == GPIO_GPL(12u))) )
    {
        uiRet = 0u;
    }
    else if((uiCh == TMRCH16_5) && \
        ((uiPort == GPIO_GPC(17u)) || (uiPort == GPIO_GPE(14u)) || (uiPort == GPIO_GPG(6u)) ||\
        (uiPort == GPIO_GPH(14u))  || (uiPort == GPIO_GPJ(6u)) || (uiPort == GPIO_GPL(14u))) )
    {
        uiRet = 0u;
    }
    else if((uiCh == TMRCH16_6) && \
        ((uiPort == GPIO_GPC(19u)) || (uiPort == GPIO_GPF(0u)) || (uiPort == GPIO_GPG(8u)) ||\
        (uiPort == GPIO_GPI(0u))  || (uiPort == GPIO_GPJ(8u)) || (uiPort == GPIO_GPL(16u))) )
    {
        uiRet = 0u;
    }
    else if((uiCh == TMRCH16_7) && \
        ((uiPort == GPIO_GPD(15u)) || (uiPort == GPIO_GPF(2u)) || (uiPort == GPIO_GPG(10u)) ||\
        (uiPort == GPIO_GPI(2u))  || (uiPort == GPIO_GPJ(10u))) )
    {
        uiRet = 0u;
    }
    else if((uiCh == TMRCH20_2) && \
        ((uiPort == GPIO_GPD(17u)) || (uiPort == GPIO_GPF(4u)) || (uiPort == GPIO_GPG(12u)) ||\
        (uiPort == GPIO_GPI(4u))  || (uiPort == GPIO_GPJ(12u))) )
    {
        uiRet = 0u;
    }
    else if((uiCh == TMRCH20_3) && \
        ((uiPort == GPIO_GPD(19u)) || (uiPort == GPIO_GPF(6u)) || (uiPort == GPIO_GPG(14u)) ||\
        (uiPort == GPIO_GPI(6u))  || (uiPort == GPIO_GPJ(14u))) )
    {
        uiRet = 0u;
    }
    else
    {
        ;
    }

    if(uiRet == 0u)
    {
        (void)GPIO_Config(uiPort, GPIO_FUNC(5U) | GPIO_NOPULL | GPIO_INPUTBUF_EN);
    }

    return uiRet;
}

//clk 4b10 0300  XCLK   TMR0   default xin 24M
//clk 4b10 0304  TCLK   16,20
//clk 4b10 0308  ZCLK   32
//clk 4b10 030c  XCLK   TMR1
//clk 4b10 0310  TCLK
//clk 4b10 0314  ZCLK

void TIMER_InterruptClear(uint32 uiCh)
{

    uint32 uiIntClrReg  = 0u;
    uint32 uiIntClrPos  = 0u;
    uint32 uiIntBitMask = 0u;

    if((uiCh == TMRCH32_0) || (uiCh == TMRCH32_1))
    {
        uiIntClrReg = TIMER_READREG(TIMER_REG_TC32IRQ(uiCh));
        TIMER_WRITEREG(uiIntClrReg, TIMER_REG_TC32IRQ(uiCh));
    }
    else if(uiCh < TMRCH_MAX)
    {
        uiIntClrPos = (uiCh & 0x7u);
        uiIntBitMask = (1UL << uiIntClrPos);
        uiIntClrReg = TIMER_READREG(TIMER_REG_TIREQ(uiCh));

        if((uiIntClrReg & uiIntBitMask) == uiIntBitMask)
        {
            uiIntClrReg = uiIntBitMask;
            uiIntClrReg = (uiIntClrReg | (1UL << (8UL + uiIntClrPos)));
            TIMER_WRITEREG(uiIntClrReg, TIMER_REG_TIREQ(uiCh));
        }

    }

    return;
}


uint32 TIMER_Enable(uint32 uiCh, TIMERTick_t* uiTick, TIMER16_20_DIV_t uiDIV, void * pFunc)
{

    uint32 uiRet       = 0u;

    uint32 uiCfgAddr   = 0u;

    uint32 uiCfgValue  = 0u;
    uint32 uiIrqValue  = 0u;

    uint32 uiPicIrqIdx = 0u;
    uint32 uiMaxTickValue = 0xFFFFu;
    SALRetCode_t ret;

    if(uiCh < TMRCH_MAX)
    {
        if((uiCh & TMR_32BIT_BIT_MASK)== TMR_32BIT_BIT_MASK)
        {
            /* 32bit tmr */
            uiCfgAddr = TIMER_REG_TC32EN(uiCh);

            if(uiTick->ctMainTick == 0u)
            {
                uiRet = 1u;
            }
            else
            {
                if((uiCh & TMR_TIMER1_BIT_MASK) == TMR_TIMER1_BIT_MASK)
                {
                    uiPicIrqIdx = (TMR1_32_IRQn );
                }
                else
                {
                    uiPicIrqIdx = (TMR0_32_IRQn );
                }

                TIMER_WRITEREG(0u, uiCfgAddr);
                TIMER_WRITEREG(0u, TIMER_REG_TC32IRQ(uiCh));

                if(uiTick->ctPrescaleTick != 0u)
                {
                    uiCfgValue = (uiTick->ctPrescaleTick & 0xFFFFFFu);
                }

                uiCfgValue |= TMR_OP32_CFG_LDZERO;
                uiIrqValue = TMR_IRQ_CLR_WHEN_WRITING;

                if((uiTick->ctCmp0Tick == 0u) && (uiTick->ctCmp1Tick == 0u))
                {
                    uiIrqValue |= TMR_IRQ_CTRL_MAINCNT;
                }
                else
                {
                    if(uiTick->ctCmp0Tick != 0u)
                    {
                        uiCfgValue |= TMR_OP32_CFG_LDM0;
                        uiIrqValue |= TMR_IRQ_CTRL_CMP0;
                        TIMER_WRITEREG(uiTick->ctCmp0Tick, TIMER_REG_TC32CMP0(uiCh));
                    }

                    if(uiTick->ctCmp1Tick != 0u)
                    {
                        uiCfgValue |= TMR_OP32_CFG_LDM1;
                        uiIrqValue |= TMR_IRQ_CTRL_CMP1;
                        TIMER_WRITEREG(uiTick->ctCmp1Tick, TIMER_REG_TC32CMP1(uiCh));
                    }
                }

                if(uiTick->ctReserved == 1u)
                {
                    uiCfgValue |= TMR_OP32_CFG_STOP;
                }
                else if((uiTick->ctReserved & 0x100) == 0x100)
                {
                    uiIrqValue = (TMR_IRQ_CTRL_BITSEL|TMR_IRQ_CLR_WHEN_WRITING);
                    uiIrqValue |= TMR_IRQ_BITSEL(uiTick->ctReserved );
                }

                uiCfgValue |= TMR_OP32_CFG_EN;

                TIMER_WRITEREG(uiTick->ctMainTick, TIMER_REG_TC32LVD(uiCh));

                if(pFunc != NULL_PTR)
                {
                    TIMER_WRITEREG(uiIrqValue, TIMER_REG_TC32IRQ(uiCh));
                }

                TIMER_WRITEREG(uiCfgValue, uiCfgAddr);

            }
        }
        else
        {
            uiCfgAddr = TIMER_REG_TCFG(uiCh);

            if((uiCh & TMR_20BIT_BIT_MASK)== TMR_20BIT_BIT_MASK)
            {
                uiMaxTickValue = 0xFFFFFFu;
            }

            if((uiTick->ctRefTick > uiMaxTickValue ) || (uiTick->ctMRefTick > uiMaxTickValue))
            {
                uiRet = 1u;
            }
            else
            {

                /* 16, 20bit tmr */

                TIMER_WRITEREG(0u, uiCfgAddr);

                if((uiCh & TMR_TIMER1_BIT_MASK) == TMR_TIMER1_BIT_MASK)
                {
                    uiPicIrqIdx = (TMR1_16_0_IRQn + (uiCh & 0x7) );
                }
                else
                {
                    uiPicIrqIdx = (TMR0_16_0_IRQn + (uiCh & 0x7) );
                }


                if(uiTick->ctRefTick != 0u)
                {

                    TIMER_WRITEREG(uiTick->ctRefTick ,TIMER_REG_TREF(uiCh));
                }
                else
                {
                    /* continuous mode */
                    uiCfgValue |= TMR_OP_CFG_CON;
                }

                if(uiTick->ctReserved == 1u)
                {
                    uiCfgValue |= TMR_OP_CFG_STOP;
                }

                if(pFunc != NULL_PTR)
                {
                    uiCfgValue |= TMR_OP_CFG_IEN;
                }
                uiCfgValue |= TMR_OP_CFG_TCKSEL(uiDIV);
                uiCfgValue |= ( TMR_OP_CFG_EN | TMR_OP_CFG_CC);

                if(uiTick->ctMRefTick != 0u)
                {
                    /* PDM mode */
                    TIMER_WRITEREG(uiTick->ctMRefTick ,TIMER_REG_TMREF(uiCh));
                    uiCfgValue |= TMR_OP_CFG_PDM;
                    uiRet = TIMER_TCO_portset(uiCh, uiTick->ctGPIO);
                }

                if(uiRet == 0u)
                {
                    TIMER_WRITEREG(uiCfgValue, uiCfgAddr);
                }

            }

        }


        if(pFunc != NULL_PTR)
        {
            ret = NVIC_IntVectSet(uiPicIrqIdx, (IrqHandler_t)pFunc);
            if(ret == SAL_RET_FAILED)
            {
                TIMER_WRITEREG(0u, uiCfgAddr);
                uiRet = 1u;
            }
            else
            {
                (void)NVIC_IntSrcEn(uiPicIrqIdx);
            }
        }

    }
    else
    {
        uiRet = 1u;
    }

    return uiRet;
}



uint32 TIMER_Disable(uint32 uiCh)
{

    uint32 uiRet       = 0u;

    uint32 uiCfgValue  = 0u;

    uint32 uiPicIrqIdx = 0u;
    uint32 uiIrqEn = 0u;

    if(uiCh < TMRCH_MAX)
    {
        if((uiCh & TMR_32BIT_BIT_MASK)== TMR_32BIT_BIT_MASK)
        {
            /* 32bit tmr */
            TIMER_WRITEREG(0u, TIMER_REG_TC32EN(uiCh));
            uiCfgValue = TIMER_READREG(TIMER_REG_TC32IRQ(uiCh));
            if((uiCfgValue & TMR_IRQ_CTRL_MASK ) != 0u)
            {
                uiIrqEn = 1u;
            }
            TIMER_WRITEREG(0u, TIMER_REG_TC32IRQ(uiCh));

            if((uiCh & TMR_TIMER1_BIT_MASK) == TMR_TIMER1_BIT_MASK)
            {
                uiPicIrqIdx = (TMR0_32_IRQn );
            }
            else
            {
                uiPicIrqIdx = (TMR1_32_IRQn );
            }

        }
        else
        {


            /* 16, 20bit tmr */
            uiCfgValue = TIMER_READREG(TIMER_REG_TCFG(uiCh));
            if((uiCfgValue & TMR_OP_CFG_IEN ) == TMR_OP_CFG_IEN)
            {
                uiIrqEn = 1u;
            }

            TIMER_WRITEREG(0u, TIMER_REG_TCFG(uiCh));

            if((uiCh & TMR_TIMER1_BIT_MASK) == TMR_TIMER1_BIT_MASK)
            {
                uiPicIrqIdx = (TMR1_16_0_IRQn + (uiCh & 0x7) );
            }
            else
            {
                uiPicIrqIdx = (TMR0_16_0_IRQn + (uiCh & 0x7) );
            }

        }

        if(uiIrqEn == 1u)
        {
            (void)NVIC_IntSrcDis(uiPicIrqIdx);
        }

    }
    else
    {
        uiRet = 1u;
    }

    return uiRet;

}

#ifdef NEVER





/* Register Map */
#define TMR_OP_EN_CFG                   (0x000UL)
#define TMR_MAIN_CNT_LVD                (0x004UL)
#define TMR_CMP_VALUE0                  (0x008UL)
#define TMR_CMP_VALUE1                  (0x00CUL)
#define TMR_PSCL_CNT                    (0x010UL)
#define TMR_MAIN_CNT                    (0x014UL)
#define TMR_IRQ_CTRL                    (0x018UL)

/* Configuration Value */
#define TMR_OP_EN_CFG_LDM0_ON           (1UL << 28UL)
#define TMR_OP_EN_CFG_LDM1_ON           (1UL << 29UL)
#define TMR_OP_EN_CFG_OPMODE_FREE_RUN   (0UL << 26UL)
#define TMR_OP_EN_CFG_OPMODE_ONE_SHOT   (1UL << 26UL)
#define TMR_OP_EN_CFG_LDZERO_OFFSET     (25UL)
#define TMR_OP_EN_CFG_CNT_EN            (1UL << 24UL)

/* 0: Reading this register to be cleared, 1: Writing a non-zero value to MASKED_IRQ_STATUS to be cleared */
#define TMR_IRQ_CLR_CTRL_WRITE          (1UL << 31UL)
#define TMR_IRQ_CLR_CTRL_READ           (0UL << 31UL)
#define TMR_IRQ_MASK_ALL                (0x1FUL)
#define TMR_IRQ_CTRL_IRQ_EN0            (1UL << 16UL)
#define TMR_IRQ_CTRL_IRQ_EN1            (2UL << 16UL)
#define TMR_IRQ_CTRL_IRQ_EN2            (4UL << 16UL)
#define TMR_IRQ_CTRL_IRQ_EN3            (8UL << 16UL)
#define TMR_IRQ_CTRL_IRQ_EN4            (16UL << 16UL)
#define TMR_IRQ_CTRL_IRQ_ALLEN          ((TMR_IRQ_CTRL_IRQ_EN0)         \
                                        | (TMR_IRQ_CTRL_IRQ_EN1)        \
                                        | (TMR_IRQ_CTRL_IRQ_EN2)        \
                                        | (TMR_IRQ_CTRL_IRQ_EN3)        \
                                        | (TMR_IRQ_CTRL_IRQ_EN4))

#define TMR_PRESCALE                    (11UL)
#define TMR_CLK_RATE                    ((12UL) * (1000UL) * (1000UL))

typedef struct TIMERResourceTable
{
    TIMERChannel_t                      rtChannel;
    boolean                             rtUsed;
    TIMERHandler                        rtHandler;
    void *                              rtArgs;

} TIMERResource_t;

/*
***************************************************************************************************
*                                             VARIABLES
***************************************************************************************************
*/
static boolean                          gTimerInitialized = FALSE;

static TIMERResource_t                  gTimerRes[TIMER_CH_MAX];

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/
static void TIMER_Handler0(    void);
static void TIMER_Handler1(    void);
static void TIMER_Handler2(    void);
static void TIMER_Handler3(    void);
static void TIMER_Handler4(    void);
static void TIMER_Handler5(    void);



static uint32 TIMER_GetRate
(
    const TIMERConfig_t *               pCfg
);

static SALRetCode_t TIMER_EnableMode
(
    const TIMERConfig_t *               pCfg,
    const uint32                        uiRateFactor
);

static SALRetCode_t TIMER_SetEnableCoreReg
(
    const TIMERConfig_t *               pCfg,
    const uint32                        uiRateFactor,
    const uint32                        uiCmpVal0,
    const uint32                        uiCmpVal1,
    uint32                              uiCfgVal,
    const uint32                        uiIrqVal
);

static SALRetCode_t TIMER_EnableComp0
(
    const TIMERConfig_t *               pCfg,
    const uint32                        uiRateFactor
);

static SALRetCode_t TIMER_EnableComp1
(
    const TIMERConfig_t *               pCfg,
    const uint32                        uiRateFactor
);

static SALRetCode_t TIMER_EnableSmallComp
(
    const TIMERConfig_t *               pCfg,
    const uint32                        uiRateFactor
);

/*
***************************************************************************************************
*                                         FUNCTIONS
***************************************************************************************************
*/

static void TIMER_Handler0
(
    void
)
{
    uint32              reg;

    reg = SIC_BSP_TIMER_BASE + TMR_IRQ_CTRL;

    if ((SAL_ReadReg(reg) & TMR_IRQ_CTRL_IRQ_ALLEN) != 0UL)
    {
        (void)TIMER_InterruptClear(TIMER_CH_0);
         if (gTimerRes[TIMER_CH_0].rtHandler != NULL_PTR)
        {
            (void)gTimerRes[TIMER_CH_0].rtHandler(TIMER_CH_0, gTimerRes[TIMER_CH_0].rtArgs);
        }
    }
}

static void TIMER_Handler1
(
    void
)
{
    uint32              reg;

    reg = SIC_BSP_TIMER_BASE + 0x100UL + TMR_IRQ_CTRL;

    if ((SAL_ReadReg(reg) & TMR_IRQ_CTRL_IRQ_ALLEN) != 0UL)
    {
        (void)TIMER_InterruptClear(TIMER_CH_1);
         if (gTimerRes[TIMER_CH_1].rtHandler != NULL_PTR)
        {
            (void)gTimerRes[TIMER_CH_1].rtHandler(TIMER_CH_1, gTimerRes[TIMER_CH_1].rtArgs);
        }
    }
}

static void TIMER_Handler2
(
    void
)
{
    uint32              reg;

    reg = SIC_BSP_TIMER_BASE + 0x200UL + TMR_IRQ_CTRL;

    if ((SAL_ReadReg(reg) & TMR_IRQ_CTRL_IRQ_ALLEN) != 0UL)
    {
        (void)TIMER_InterruptClear(TIMER_CH_2);
         if (gTimerRes[TIMER_CH_2].rtHandler != NULL_PTR)
        {
            (void)gTimerRes[TIMER_CH_2].rtHandler(TIMER_CH_2, gTimerRes[TIMER_CH_2].rtArgs);
        }
    }
}

static void TIMER_Handler3
(
    void
)
{
    uint32              reg;

    reg = SIC_BSP_TIMER_BASE + 0x300UL + TMR_IRQ_CTRL;

    if ((SAL_ReadReg(reg) & TMR_IRQ_CTRL_IRQ_ALLEN) != 0UL)
    {
        (void)TIMER_InterruptClear(TIMER_CH_1);
         if (gTimerRes[TIMER_CH_3].rtHandler != NULL_PTR)
        {
            (void)gTimerRes[TIMER_CH_3].rtHandler(TIMER_CH_3, gTimerRes[TIMER_CH_3].rtArgs);
        }
    }
}

static void TIMER_Handler4
(
    void
)
{
    uint32              reg;

    reg = SIC_BSP_TIMER_BASE + 0x400UL + TMR_IRQ_CTRL;

    if ((SAL_ReadReg(reg) & TMR_IRQ_CTRL_IRQ_ALLEN) != 0UL)
    {
        (void)TIMER_InterruptClear(TIMER_CH_4);
         if (gTimerRes[TIMER_CH_4].rtHandler != NULL_PTR)
        {
            (void)gTimerRes[TIMER_CH_4].rtHandler(TIMER_CH_4, gTimerRes[TIMER_CH_4].rtArgs);
        }
    }
}

static void TIMER_Handler5
(
    void
)
{
    uint32              reg;

    reg = SIC_BSP_TIMER_BASE + 0x500UL + TMR_IRQ_CTRL;

    if ((SAL_ReadReg(reg) & TMR_IRQ_CTRL_IRQ_ALLEN) != 0UL)
    {
        (void)TIMER_InterruptClear(TIMER_CH_5);
         if (gTimerRes[TIMER_CH_5].rtHandler != NULL_PTR)
        {
            (void)gTimerRes[TIMER_CH_5].rtHandler(TIMER_CH_5, gTimerRes[TIMER_CH_5].rtArgs);
        }
    }
}

static uint32 TIMER_GetRate
(
    const TIMERConfig_t *               pCfg
)
{
    uint32 retRate;

    retRate = 0;

    switch (pCfg->ctCounterMode)
    {
        case TIMER_COUNTER_MAIN :
        {
            retRate = (pCfg->ctMainValueUsec < 1000UL) ? (TMR_CLK_RATE * 2UL) : TMR_CLK_RATE;
            break;
        }

        case TIMER_COUNTER_COMP0 :
        {
            retRate = (pCfg->ctCmp0ValueUsec< 1000UL) ? (TMR_CLK_RATE * 2UL) : TMR_CLK_RATE;
            break;
        }

        case TIMER_COUNTER_COMP1 :
        {
            retRate = (pCfg->ctCmp1ValueUsec < 1000UL) ? (TMR_CLK_RATE * 2UL) : TMR_CLK_RATE;
            break;
        }

        case TIMER_COUNTER_SMALL_COMP :
        {
            // It need the smaller one.
            if (pCfg->ctCmp0ValueUsec > pCfg->ctCmp1ValueUsec)
            {
                retRate = (pCfg->ctCmp1ValueUsec < 1000UL) ? (TMR_CLK_RATE * 2UL) : TMR_CLK_RATE;
            }
            else
            {
                retRate = (pCfg->ctCmp0ValueUsec < 1000UL) ? (TMR_CLK_RATE * 2UL) : TMR_CLK_RATE;
            }

            break;
        }

        default :
        {
            TMR_E("unexpected code flow\n");
            break;
        }

    }

    return retRate;
}

/*
***************************************************************************************************
*                                          TIMER_InterruptClear
*
* This function clears the interrupt signal that is occurred when meeting the conditions.
*
* @param    uiChannel [in] The specific channel for TIMER module
* @return
*
* Notes
*   It is called automatically with dealing with TIMER handler.
*   Therefore, user don't have chance to call this function.
*
***************************************************************************************************
*/
SALRetCode_t TIMER_InterruptClear
(
    TIMERChannel_t                      uiChannel
)
{
    uint32  reg;
    uint32  clr_ctl;

    reg     = SIC_BSP_TIMER_BASE + ((uint32)uiChannel * 0x100U) + TMR_IRQ_CTRL;
    // Deviation Record - CERT INT36-C, CERT-C Integers
    clr_ctl = SAL_ReadReg(reg);

    if ((clr_ctl & TMR_IRQ_CLR_CTRL_WRITE) != 0U)
    {
        // Deviation Record - CERT INT36-C, CERT-C Integers
        SAL_WriteReg(clr_ctl | TMR_IRQ_MASK_ALL, reg);
    }
    else    // TMR_IRQ_CLR_CTRL_READ
    {
        // Deviation Record - CERT INT36-C, CERT-C Integers
        SAL_ReadReg(reg);
    }

    return SAL_RET_SUCCESS;
}

/*
***************************************************************************************************
*                                          TIMER_Enable
*
* This function enables the specific TIMER module with TIMER_OP_FREERUN, TIMER_START_ZERO,
* TIMER_COUNTER_COMP0
*
* @param    uiChannel [in] The specific channel for TIMER module
* @param    uiUSec [in] The micro-second that user want to set for interrupt signal
* @param    fnHandler [in] The external handler which user needs to register
* @param    pArgs [in] The pointer of configuration structure table
* @return
*
* Notes
*
***************************************************************************************************
*/
// Deviation Record - HIS metric violation (HIS_CALLING)
SALRetCode_t TIMER_Enable
(
    TIMERChannel_t                      uiChannel,
    uint32                              uiUSec,
    TIMERHandler                        fnHandler,
    void *                              pArgs
)
{
    return TIMER_EnableWithMode(uiChannel, uiUSec, TIMER_OP_FREERUN, fnHandler, pArgs);
}

/*
***************************************************************************************************
*                                          TIMER_EnableWithMode
*
* This function enables the specific TIMER module with TIMER_START_ZERO, TIMER_COUNTER_COMP0.
*
* @param    uiChannel [in] The specific channel for TIMER module
* @param    uiUSec [in] The micro-second that user want to set for interrupt signal
* @param    uiOpMode [in] Operation mode, Free running or One-time running
* @param    fnHandler [in] The external handler which user needs to register
* @param    pArgs [in] The pointer of configuration structure table
* @return
*
* Notes
*
***************************************************************************************************
*/
// Deviation Record - HIS metric violation (HIS_CALLING)
SALRetCode_t TIMER_EnableWithMode
(
    TIMERChannel_t                      uiChannel,
    uint32                              uiUSec,
    TIMEROpMode_t                       uiOpMode,
    TIMERHandler                        fnHandler,
    void *                              pArgs
)
{
    TIMERConfig_t cfg;

    cfg.ctChannel       = uiChannel;
    cfg.ctStartMode     = TIMER_START_ZERO;
    cfg.ctOpMode        = uiOpMode;
    cfg.ctCounterMode   = TIMER_COUNTER_COMP0;
    cfg.ctMainValueUsec = 0;
    cfg.ctCmp0ValueUsec = uiUSec;
    cfg.ctCmp1ValueUsec = 0;
    cfg.fnHandler       = fnHandler;
    cfg.pArgs           = pArgs;

    return TIMER_EnableWithCfg(&cfg);
}

/*
***************************************************************************************************
*                                          TIMER_EnableWithCfg
*
* This function enables the specific TIMER module with configuration structure
*
* @param    pCfg [in] Configuration structure with TIMER module information
* @return
*
* Notes
*
***************************************************************************************************
*/
SALRetCode_t TIMER_EnableWithCfg
(
    const TIMERConfig_t *               pCfg
)
{
    uint32              clk_id = 0x0UL;
    uint32              rate = 0x0UL;
    uint32              rate_factor = 0x0UL;
    SALRetCode_t        ret = SAL_RET_SUCCESS;

    // MISRA 14.7 : A function shall have a single point of exit at the end of the function
    if (gTimerInitialized == FALSE)
    {
        ret = SAL_DbgReportError
        (
            SAL_DRVID_TMR,
            TIMER_API_ENABLE_CFG,
            TIMER_ERR_NOT_INITIALIZED,
            __FUNCTION__
        );
    }
    else if (pCfg == NULL_PTR)
    {
        ret = SAL_DbgReportError
        (
            SAL_DRVID_TMR,
            TIMER_API_ENABLE_CFG,
            TIMER_ERR_INVALID_PARAM,
            __FUNCTION__
        );
    }
    else if (TIMER_CH_MAX <= pCfg->ctChannel)
    {
        ret = SAL_DbgReportError
        (
            SAL_DRVID_TMR,
            TIMER_API_ENABLE_CFG,
            TIMER_ERR_OUTOF_RANGE_CHANNEL,
            __FUNCTION__
        );
    }
    else
    {
        rate = TIMER_GetRate(pCfg);

        if (rate == 0UL)
        {
            ret = SAL_DbgReportError
            (
                SAL_DRVID_TMR,
                TIMER_API_ENABLE_CFG,
                TIMER_ERR_NOT_SUPPORT_MODE,
                __FUNCTION__
            );
        }
        else
        {
            clk_id = (uint32)CLOCK_PERI_TIMER0 + (uint32)pCfg->ctChannel;

            (void)CLOCK_SetPeriRate((sint32)clk_id, rate);
            (void)CLOCK_EnablePeri((sint32)clk_id);

            if (CLOCK_GetPeriRate((sint32)clk_id) != rate)
            {
                ret = SAL_DbgReportError
                (
                    SAL_DRVID_TMR,
                    TIMER_API_ENABLE_CFG,
                    TIMER_ERR_SET_CLOCK,
                    __FUNCTION__
                );
            }
            else
            {
                rate_factor = (rate / 1000UL) / ((TMR_PRESCALE + 1UL) * 1000UL); //The rate is 12 or 24M, Therefore, when it divided by 12, 1 or 2

                ret = TIMER_EnableMode(pCfg, rate_factor);

                if (ret == SAL_RET_SUCCESS)
                {
                    gTimerRes[pCfg->ctChannel].rtUsed       = TRUE;
                    gTimerRes[pCfg->ctChannel].rtHandler    = pCfg->fnHandler;
                    gTimerRes[pCfg->ctChannel].rtArgs       = pCfg->pArgs;

                    NVIC_IntSrcEn(TIMER0_IRQn+(uint32)pCfg->ctChannel);

                    TMR_D("Channel (%d) is enabled\n", (uint32)pCfg->ctChannel);
                }       // (ret == SAL_RET_SUCCESS)
            }       // (tcc_get_peri(clk_id) != rate)
        }
    }

    return ret;
}

static SALRetCode_t TIMER_EnableMode
(
    const TIMERConfig_t *               pCfg,
    const uint32                        uiRateFactor
)
{
    SALRetCode_t    ret = SAL_RET_SUCCESS;

    switch (pCfg->ctCounterMode)
    {
        case TIMER_COUNTER_COMP0 :
        {
            ret = TIMER_EnableComp0(pCfg, uiRateFactor);

            break;
        }

        case TIMER_COUNTER_COMP1 :
        {
            ret = TIMER_EnableComp1(pCfg, uiRateFactor);

            break;
        }

        case TIMER_COUNTER_SMALL_COMP :
        {
            ret = TIMER_EnableSmallComp(pCfg, uiRateFactor);

            break;
        }

        default : //TIMER_COUNTER_MAIN
        {
            ret = TIMER_SetEnableCoreReg(pCfg, uiRateFactor, 0x0UL, 0x0UL, 0x0UL, TMR_IRQ_CTRL_IRQ_EN2);

            break;
        }
    }

    return ret;
}

static SALRetCode_t TIMER_SetEnableCoreReg
(
    const TIMERConfig_t *               pCfg,
    const uint32                        uiRateFactor,
    const uint32                        uiCmpVal0,
    const uint32                        uiCmpVal1,
    uint32                              uiCfgVal,
    const uint32                        uiIrqVal
)
{
    uint32          mainval = 0x0UL;
    uint32          tmpval = 0x0UL;
    SALRetCode_t    ret = SAL_RET_SUCCESS;
    uint32          reg = SIC_BSP_TIMER_BASE + ((uint32)pCfg->ctChannel * 0x100UL);

    if (uiRateFactor == 0UL)
    {
        ret = SAL_DbgReportError
        (
            SAL_DRVID_TMR,
            TIMER_API_ENABLE_CFG,
            TIMER_ERR_INVALID_PARAM,
            __FUNCTION__
        );
    }
    else
    {
        mainval = (pCfg->ctMainValueUsec == 0UL) ? 0xFFFFFFFFUL : ((pCfg->ctMainValueUsec * uiRateFactor) - 1UL);

        //reset main cnt load value
        // Deviation Record - CERT INT36-C, CERT-C Integers
        SAL_WriteReg(mainval, (uint32)(reg + TMR_MAIN_CNT_LVD));
        SAL_WriteReg(uiCmpVal0, (uint32)(reg + TMR_CMP_VALUE0));
        SAL_WriteReg(uiCmpVal1, (uint32)(reg + TMR_CMP_VALUE1));

        uiCfgVal |= (TMR_PRESCALE
                    | TMR_OP_EN_CFG_CNT_EN
                    | ((uint32)pCfg->ctStartMode << TMR_OP_EN_CFG_LDZERO_OFFSET));

        if (pCfg->ctOpMode == TIMER_OP_ONESHOT)
        {
            uiCfgVal |= TMR_OP_EN_CFG_OPMODE_ONE_SHOT;
        }

        // Deviation Record - CERT INT36-C, CERT-C Integers
        tmpval = SAL_ReadReg((uint32)(reg + TMR_IRQ_CTRL));

        // Deviation Record - CERT INT36-C, CERT-C Integers
        SAL_WriteReg(uiCfgVal, (uint32)(reg + TMR_OP_EN_CFG));
        SAL_WriteReg((tmpval | uiIrqVal), (uint32)(reg + TMR_IRQ_CTRL));
    }

    return ret;
}

static SALRetCode_t TIMER_EnableComp0
(
    const TIMERConfig_t *               pCfg,
    const uint32                        uiRateFactor
)
{
    uint32          tmpval = 0x0UL;
    uint32          mainval = 0x0UL;
    uint32          cmpval0 = 0x0UL;
    uint32          cmpval1 = 0x0UL;
    uint32          reg_cfgval = 0x0UL;
    uint32          reg_irqval = TMR_IRQ_CTRL_IRQ_EN2;
    SALRetCode_t    ret = SAL_RET_SUCCESS;

    // CERT-C Integers (CERT INT30-C) : Ensure that unsigned integer operations do not wrap
    if ((uiRateFactor == 0UL) || ((SAL_MAX_INT_VAL / uiRateFactor) < pCfg->ctCmp0ValueUsec))
    {
        ret = SAL_DbgReportError
        (
            SAL_DRVID_TMR,
            TIMER_API_ENABLE_CFG,
            TIMER_ERR_OUTOF_COMPARATOR_0,
            __FUNCTION__
        );
    }
    else
    {
        mainval = (pCfg->ctMainValueUsec == 0UL) ? 0xFFFFFFFFUL : ((pCfg->ctMainValueUsec * uiRateFactor) - 1UL);
        tmpval = (pCfg->ctCmp0ValueUsec * uiRateFactor) - 1UL;

        if ((pCfg->ctStartMode == TIMER_START_MAINCNT)
            && (((0xFFFFFFFFUL - tmpval) == 0xFFFFFFFFUL) || (mainval > (0xFFFFFFFFUL - tmpval))))
        {
            ret = SAL_DbgReportError
            (
                SAL_DRVID_TMR,
                TIMER_API_ENABLE_CFG,
                TIMER_ERR_OUTOF_COMPARATOR_0,
                __FUNCTION__
            );
        }
        else
        {
            cmpval0     = (pCfg->ctStartMode == TIMER_START_ZERO) ? tmpval : (mainval + tmpval);
            reg_cfgval  = TMR_OP_EN_CFG_LDM0_ON;
            reg_irqval  |= TMR_IRQ_CTRL_IRQ_EN0;

            ret = TIMER_SetEnableCoreReg(pCfg, uiRateFactor, cmpval0, cmpval1, reg_cfgval, reg_irqval);
        }
    }

    return ret;
}

static SALRetCode_t TIMER_EnableComp1
(
    const TIMERConfig_t *               pCfg,
    const uint32                        uiRateFactor
)
{
    uint32          tmpval = 0x0UL;
    uint32          mainval = 0x0UL;
    uint32          cmpval0 = 0x0UL;
    uint32          cmpval1 = 0x0UL;
    uint32          reg_cfgval = 0x0UL;
    uint32          reg_irqval = TMR_IRQ_CTRL_IRQ_EN2;
    SALRetCode_t    ret = SAL_RET_SUCCESS;

    // CERT-C Integers (CERT INT30-C) : Ensure that unsigned integer operations do not wrap
    if ((uiRateFactor == 0UL) || ((SAL_MAX_INT_VAL / uiRateFactor) < pCfg->ctCmp1ValueUsec))
    {
        ret = SAL_DbgReportError
        (
            SAL_DRVID_TMR,
            TIMER_API_ENABLE_CFG,
            TIMER_ERR_OUTOF_COMPARATOR_1,
            __FUNCTION__
        );
    }
    else
    {
        mainval = (pCfg->ctMainValueUsec == 0UL) ? 0xFFFFFFFFUL : ((pCfg->ctMainValueUsec * uiRateFactor) - 1UL);
        tmpval = (pCfg->ctCmp1ValueUsec * uiRateFactor) - 1UL;

        if ((pCfg->ctStartMode == TIMER_START_MAINCNT)
            && (((0xFFFFFFFFUL - tmpval) == 0xFFFFFFFFUL) || (mainval > (0xFFFFFFFFUL - tmpval))))
        {
            ret = SAL_DbgReportError
            (
                SAL_DRVID_TMR,
                TIMER_API_ENABLE_CFG,
                TIMER_ERR_OUTOF_COMPARATOR_1,
                __FUNCTION__
            );
        }
        else
        {
            cmpval1     = (pCfg->ctStartMode == TIMER_START_ZERO) ? tmpval : (mainval + tmpval);
            reg_cfgval  = TMR_OP_EN_CFG_LDM1_ON;
            reg_irqval  |= TMR_IRQ_CTRL_IRQ_EN1;

            ret = TIMER_SetEnableCoreReg(pCfg, uiRateFactor, cmpval0, cmpval1, reg_cfgval, reg_irqval);
        }
    }

    return ret;
}

static SALRetCode_t TIMER_EnableSmallComp
(
    const TIMERConfig_t *               pCfg,
    const uint32                        uiRateFactor
)
{
    uint32          tmpval0 = 0x0UL;
    uint32          tmpval1 = 0x0UL;
    uint32          mainval = 0x0UL;
    uint32          cmpval0 = 0x0UL;
    uint32          cmpval1 = 0x0UL;
    uint32          reg_cfgval = 0x0UL;
    uint32          reg_irqval = TMR_IRQ_CTRL_IRQ_EN2;
    SALRetCode_t    ret = SAL_RET_SUCCESS;

    if (uiRateFactor == 0UL)
    {
        ret = SAL_DbgReportError
        (
            SAL_DRVID_TMR,
            TIMER_API_ENABLE_CFG,
            TIMER_ERR_INVALID_PARAM,
            __FUNCTION__
        );
    }
    else
    {
        mainval = (pCfg->ctMainValueUsec == 0UL) ? 0xFFFFFFFFUL : ((pCfg->ctMainValueUsec * uiRateFactor) - 1UL);
        tmpval0 = (pCfg->ctCmp0ValueUsec * uiRateFactor) - 1UL;
        tmpval1 = (pCfg->ctCmp1ValueUsec * uiRateFactor) - 1UL;

        if (pCfg->ctStartMode == TIMER_START_MAINCNT)
        {
            // Less value is selected
            if (tmpval0 <= tmpval1)
            {
                // CERT-C Integers (CERT INT30-C) : Ensure that unsigned integer operations do not wrap
                if ((SAL_MAX_INT_VAL - mainval) <= tmpval0)
                {
                    ret = SAL_DbgReportError
                    (
                        SAL_DRVID_TMR,
                        TIMER_API_ENABLE_CFG,
                        TIMER_ERR_OUTOF_COMPARATOR_0,
                        __FUNCTION__
                    );
                }
                else
                {
                    cmpval0 = mainval + tmpval0;
                    cmpval1 = SAL_MAX_INT_VAL;
                }
            }
            else
            {
                if ((SAL_MAX_INT_VAL - mainval) <= tmpval1)
                {
                    ret = SAL_DbgReportError
                    (
                        SAL_DRVID_TMR,
                        TIMER_API_ENABLE_CFG,
                        TIMER_ERR_OUTOF_COMPARATOR_1,
                        __FUNCTION__
                    );
                }
                else
                {
                    cmpval0 = SAL_MAX_INT_VAL;
                    cmpval1 = mainval + tmpval1;
                }
            }
        }
        else
        {
            cmpval0 = tmpval0;
            cmpval1 = tmpval1;
        }

        if (ret == SAL_RET_SUCCESS)
        {
            reg_cfgval  = (TMR_OP_EN_CFG_LDM0_ON | TMR_OP_EN_CFG_LDM1_ON);
            reg_irqval  |= (TMR_IRQ_CTRL_IRQ_EN0 | TMR_IRQ_CTRL_IRQ_EN1);

            ret = TIMER_SetEnableCoreReg(pCfg, uiRateFactor, cmpval0, cmpval1, reg_cfgval, reg_irqval);
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          TIMER_Disable
*
* This function disables the specific TIMER module.
*
* @param    uiChannel [in] The specific channel for TIMER module
* @return
*
* Notes
*
***************************************************************************************************
*/
// Deviation Record - HIS metric violation (HIS_CALLING)
SALRetCode_t TIMER_Disable
(
    TIMERChannel_t                      uiChannel
)
{
    SALRetCode_t    ret;
    uint32          reg;
    uint32          tmpval;

    ret = SAL_RET_SUCCESS;
    reg = SIC_BSP_TIMER_BASE + ((uint32)uiChannel * 0x100UL);
    tmpval = 0x0UL;

    // MISRA 14.7 : A function shall have a single point of exit at the end of the function
    if (gTimerInitialized == FALSE)
    {
        ret = SAL_DbgReportError
        (
            SAL_DRVID_TMR,
            TIMER_API_DISABLE,
            TIMER_ERR_NOT_INITIALIZED,
            __FUNCTION__
        );
    }
    else
    {
        // Deviation Record - CERT INT36-C, CERT-C Integers
        tmpval = SAL_ReadReg((uint32)(reg + TMR_OP_EN_CFG));

        // Deviation Record - CERT INT36-C, CERT-C Integers
        SAL_WriteReg((tmpval & (~TMR_OP_EN_CFG_CNT_EN)), (uint32)(reg + TMR_OP_EN_CFG));
        SAL_WriteReg(0U, (uint32)(reg + TMR_IRQ_CTRL));

        gTimerRes[uiChannel].rtUsed     = FALSE;
        gTimerRes[uiChannel].rtHandler  = NULL;
        gTimerRes[uiChannel].rtArgs     = NULL_PTR;

        TMR_D("Channel (%d) is disabled\n", (uint32)uiChannel);
    }

    return ret;
}

/*
***************************************************************************************************
*                                          TIMER_Init
*
* This function initializes clock and registers for all channels
*
* @return
*
* Notes
*
***************************************************************************************************
*/
SALRetCode_t TIMER_Init
(
    void
)
{
    uint32          reg;
    uint32          clk_rate;
    uint32          resIndex;
    uint32          reg_val;
    SALRetCode_t    ret;

    ret = SAL_RET_SUCCESS;
    (void)CLOCK_SetPeriRate((sint32)CLOCK_PERI_TIMER0, TMR_CLK_RATE);
    (void)CLOCK_EnablePeri((sint32)CLOCK_PERI_TIMER0);
    clk_rate    = CLOCK_GetPeriRate((sint32)CLOCK_PERI_TIMER0);

    // MISRA 14.7 : A function shall have a single point of exit at the end of the function
    if (clk_rate != TMR_CLK_RATE)
    {
        gTimerInitialized = FALSE;
        ret = SAL_DbgReportError
        (
            SAL_DRVID_TMR,
            TIMER_API_INIT,
            TIMER_ERR_SET_CLOCK,
            __FUNCTION__
        );

        // Uart is not ready to print sth so TMR_PASS/TMR_FAIL can't be showed off
    }
    else
    {
        for (resIndex = 0 ; resIndex < (uint32)TIMER_CH_MAX ; resIndex++)
        {
            reg = SIC_BSP_TIMER_BASE + (resIndex * 0x100UL);

            gTimerRes[resIndex].rtChannel  = (TIMERChannel_t)resIndex;
            gTimerRes[resIndex].rtUsed     = FALSE;
            gTimerRes[resIndex].rtHandler  = NULL_PTR;
            gTimerRes[resIndex].rtArgs     = NULL_PTR;

            // Deviation Record - CERT INT36-C, CERT-C Integers
            SAL_WriteReg(0x7FFFU, (uint32)(reg + TMR_OP_EN_CFG));
            SAL_WriteReg(0x0U,    (uint32)(reg + TMR_MAIN_CNT_LVD));
            SAL_WriteReg(0x0U,    (uint32)(reg + TMR_CMP_VALUE0));
            SAL_WriteReg(0x0U,    (uint32)(reg + TMR_CMP_VALUE1));

            reg_val = TMR_IRQ_CLR_CTRL_READ | TMR_IRQ_MASK_ALL; //  TMR_IRQ_CLR_CTRL_WRITE | TMR_IRQ_MASK_ALL;

            SAL_WriteReg(reg_val, (uint32)(reg + TMR_IRQ_CTRL));
        }

        NVIC_IntVectSet(TIMER0_IRQn, (IrqHandler_t)&TIMER_Handler0);
        NVIC_IntVectSet(TIMER1_IRQn, (IrqHandler_t)&TIMER_Handler1);
        NVIC_IntVectSet(TIMER2_IRQn, (IrqHandler_t)&TIMER_Handler2);
        NVIC_IntVectSet(TIMER3_IRQn, (IrqHandler_t)&TIMER_Handler3);
        NVIC_IntVectSet(TIMER4_IRQn, (IrqHandler_t)&TIMER_Handler4);
        NVIC_IntVectSet(TIMER5_IRQn, (IrqHandler_t)&TIMER_Handler5);

        gTimerInitialized = TRUE;

        // Uart is not ready to print sth so TMR_PASS/TMR_FAIL can't be showed off
    }

    return ret;
}
#endif /* NEVER */

