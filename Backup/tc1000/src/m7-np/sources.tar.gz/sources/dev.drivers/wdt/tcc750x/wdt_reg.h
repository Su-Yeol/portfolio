/*
***************************************************************************************************
*
*   FileName : wdt_reg.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_WDT_REG_HEADER
#define SIC_BSP_WDT_REG_HEADER

#if ( SIC_BSP_SUPPORT_DRIVER_WDT == 1 )
#include "sal_com.h"
/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/


#define WDT_CH_MAX                                  (1UL)



/**************************** Register ***************************/
/* Configuration Value */
#define WDT_REG_ADDR_BASE_0                         (0x1B934000UL) /* 0x41100000 */

#define WDT_MAX_IRQ_CNT                             (0xFFFFFFFFUL)
#define WDT_MAX_RST_CNT                             (0xFFFFFFFFUL)

#define WDT_PASSWORD                                (0x5AFEACE5UL)


typedef struct {
	volatile uint32 EN;             // 0x00,
	volatile uint32 CLR;            // 0x04,
	volatile uint32 IRQ_CNT;        // 0x08,
	volatile uint32 RST_CNT;        // 0x0C,
	volatile uint32 SM_MODE;        // 0x10,
	volatile uint32 WR_PW;          // 0x14, 0x5AFEACE5
}WDTReg_t;

WDTReg_t *WDT_REG[WDT_CH_MAX] =                     {
                                                        (WDTReg_t *)(WDT_REG_ADDR_BASE_0)
                                                    };

/****************************          ***************************/


#define WDT_KICK0_IRQ_NUM                           WWDG_IRQn
#define WDT_KICK1_IRQ_NUM                           WWDG_IRQn
#define WDT_KICK2_IRQ_NUM                           WWDG_IRQn


#define WDT_REG_PMU_RST_EN                          (*(volatile uint32*)(0x1B9360BCUL))
#define WDT_REG_PMU_RST_MASK(ch)                    (0x1UL << (7UL + (uint32)ch))

#endif  // ( SIC_BSP_SUPPORT_DRIVER_WDT == 1 )

#endif  // SIC_BSP_WDT_REG_HEADER

