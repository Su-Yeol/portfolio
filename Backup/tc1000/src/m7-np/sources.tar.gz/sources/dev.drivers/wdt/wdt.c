/*
***************************************************************************************************
*
*   FileName : wdt.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#if ( SIC_BSP_SUPPORT_DRIVER_WDT == 1 )

#include "wdt.h"
#include "wdt_reg.h"
#include <nvic.h>
//#include <debug.h>

/*
***************************************************************************************************
*                                             LOCAL DEFINES
***************************************************************************************************
*/

/*
 *  tcc750x: wdt 0 is available
 *  tcc807x: wdt 0 is available
 *  tcn100x: wdt 0/1/2/3 is available
 *
 *  4 kick handler is for tcn100x(is included NP),
 *  DO NOT change kick max
 */

#define WDT_KICK3_CH                                (WDT_CH_MAX-1UL)
#define WDT_KICK2_CH                                ((WDT_KICK3_CH == 0UL)?(0UL):(WDT_KICK3_CH-1UL))
#define WDT_KICK1_CH                                ((WDT_KICK2_CH == 0UL)?(0UL):(WDT_KICK2_CH-1UL))
#define WDT_KICK0_CH                                ((WDT_KICK1_CH == 0UL)?(0UL):(WDT_KICK1_CH-1UL))

#define WDT_KICK_MAX                                (4UL)




static void WDT_Kick0
(
    void
);

static void WDT_Kick1
(
    void
);

static void WDT_Kick2
(
    void
);
static void WDT_Kick3
(
    void
);


/*
***************************************************************************************************
*                                             VARIABLES
***************************************************************************************************
*/
uint32 gWdtKickIrqList[WDT_KICK_MAX] =             {
                                                        WDT_KICK0_IRQ_NUM,
                                                        WDT_KICK1_IRQ_NUM,
                                                        WDT_KICK2_IRQ_NUM,
                                                        WDT_KICK3_IRQ_NUM
                                                    };

void (*gWdtKickList[WDT_KICK_MAX])(void) =          {
                                                        &WDT_Kick0,
                                                        &WDT_Kick1,
                                                        &WDT_Kick2,
                                                        &WDT_Kick3
                                                    };
/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/
static void WDT_Kick0
(
    void
)
{
    WDT_REG[WDT_KICK0_CH]->WR_PW    = WDT_PASSWORD;
    WDT_REG[WDT_KICK0_CH]->CLR      = 0x1UL;
}

static void WDT_Kick1
(
    void
)
{
    WDT_REG[WDT_KICK1_CH]->WR_PW    = WDT_PASSWORD;
    WDT_REG[WDT_KICK1_CH]->CLR      = 0x1UL;
}

static void WDT_Kick2
(
    void
)
{
    WDT_REG[WDT_KICK2_CH]->WR_PW    = WDT_PASSWORD;
    WDT_REG[WDT_KICK2_CH]->CLR      = 0x1UL;
}

static void WDT_Kick3
(
    void
)
{
    WDT_REG[WDT_KICK3_CH]->WR_PW    = WDT_PASSWORD;
    WDT_REG[WDT_KICK3_CH]->CLR      = 0x1UL;
}


/*
***************************************************************************************************
*                                          WDT_Enable
*
* This function initializes configuration registers, registers interrupt handler for kick action,
* and starts WDT counter.
*
* @return
*
* Notes
*
***************************************************************************************************
*/
SALRetCode_t WDT_Enable
(
    uint32 uiCh,
    uint32 uiIrqCnt,
    uint32 uiRstCnt
)
{
    SALRetCode_t tRet;

    tRet = SAL_RET_SUCCESS;

    if(uiCh >= WDT_CH_MAX)
    {
        tRet = SAL_RET_FAILED;
    }
    else if (uiIrqCnt > WDT_MAX_IRQ_CNT)
    {
        tRet = SAL_RET_FAILED;
    }
    else if (uiRstCnt > WDT_MAX_RST_CNT)
    {
        tRet = SAL_RET_FAILED;
    }
    else if (WDT_REG[uiCh]->EN == 0x1UL)
    {
        tRet = SAL_RET_FAILED;
    }
    else
    {
        (void)NVIC_IntVectSet(gWdtKickIrqList[uiCh], (IrqHandler_t)gWdtKickList[uiCh]);
        (void)NVIC_IntSrcEn(gWdtKickIrqList[uiCh]);

        if((WDT_REG[uiCh]->SM_MODE & WDT_SM_SIG_FMU_NO_HANDSHAKE) == 0UL)
        {
            WDT_REG_PMU_RST_EN |= WDT_REG_PMU_RST_MASK(uiCh);
        }
        else
        {
            WDT_REG_PMU_RST_EN &= ~WDT_REG_PMU_RST_MASK(uiCh);
        }

        WDT_REG[uiCh]->WR_PW     = WDT_PASSWORD;
        WDT_REG[uiCh]->IRQ_CNT   = uiIrqCnt;

        WDT_REG[uiCh]->WR_PW     = WDT_PASSWORD;
        WDT_REG[uiCh]->RST_CNT   = uiRstCnt;

        WDT_REG[uiCh]->WR_PW     = WDT_PASSWORD;
        WDT_REG[uiCh]->EN        = 0x1UL;
    }


    return tRet;
}

/*
***************************************************************************************************
*                                          WDT_Disable
*
* This function stops WDT counter and unregister interrupt handler.
*
* Notes
*
***************************************************************************************************
*/
SALRetCode_t WDT_Disable
(
    uint32 uiCh
)
{
    SALRetCode_t tRet;

    tRet = SAL_RET_SUCCESS;

    if(uiCh >= WDT_CH_MAX)
    {
        tRet = SAL_RET_FAILED;
    }
    else
    {
        WDT_REG[uiCh]->WR_PW     = WDT_PASSWORD;
        WDT_REG[uiCh]->EN        = 0x0UL;

        WDT_REG_PMU_RST_EN &= (~WDT_REG_PMU_RST_MASK(uiCh));
        (void)NVIC_IntSrcDis(gWdtKickIrqList[uiCh]);
    }

    return tRet;
}

/*
***************************************************************************************************
*                                          WDT_SmMode
*
* This function configurate wdt sm mode
*
* @return
*
* Notes
*
***************************************************************************************************
*/
SALRetCode_t WDT_SmMode
(
    uint32          uiCh,
    WDTSmVote_t     tWdtSmVote,
    WDTSmSig_t      tWdtSmSig
)
{
    SALRetCode_t tRet;

    tRet = SAL_RET_SUCCESS;

    if(uiCh >= WDT_CH_MAX)
    {
        tRet = SAL_RET_FAILED;
    }
    else
    {
        WDT_REG[uiCh]->WR_PW     = WDT_PASSWORD;
        WDT_REG[uiCh]->SM_MODE   = (uint32)((uint32)tWdtSmVote|(uint32)tWdtSmSig);
    }

    return tRet;
}
#endif  // ( MCU_BSP_SUPPORT_DRIVER_WDT == 1 )

