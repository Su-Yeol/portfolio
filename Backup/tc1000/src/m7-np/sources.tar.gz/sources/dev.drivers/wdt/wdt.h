/*
***************************************************************************************************
*
*   FileName : wdt.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_WDT_HEADER
#define SIC_BSP_WDT_HEADER

#if ( SIC_BSP_SUPPORT_DRIVER_WDT == 1 )

#include <sal_internal.h>

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/
#define WDT_SEC(s)                      ((uint32)(s) * (uint32)(24UL * 1000UL * 1000UL))

/************ WDT SM_MODE info *************/
typedef enum {
    WDT_SM_VOTE_2oo3                    = 0UL, //reset signal out with 2oo3 vote. (standard mode)
    WDT_SM_VOTE_0                       = 1UL, //reset signal out with irq_cnt_0 and rst_cnt_0
    WDT_SM_VOTE_1                       = 2UL, //reset signal out with irq_cnt_1 and rst_cnt_1
    WDT_SM_VOTE_2                       = 3UL, //reset signal out with irq_cnt_2 and rst_cnt_2
}WDTSmVote_t;


typedef enum {
    WDT_SM_SIG_PMU_RST                  =  (0UL<<2UL), //pmu   reset signal out
    WDT_SM_SIG_FMU_HANDSHAKE            = ((0UL<<3UL)|(1UL<<2UL)), //fmu   signal out with fmu_ack handshake
    WDT_SM_SIG_FMU_NO_HANDSHAKE         = ((1UL<<3UL)|(1UL<<2UL)), //fmu   signal out without fmu_ack handshake
}WDTSmSig_t;
/******************************************/



/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/

/*
***************************************************************************************************
*                                          WDT_Enable
*
* This function initializes configuration registers, registers interrupt handler for kick action,
* and starts WDT counter.
*
* @return
*
* Notes
*
***************************************************************************************************
*/
SALRetCode_t WDT_Enable
(
    uint32          uiCh,
    uint32          uiIrqCnt,
    uint32          uiRstCnt
);

/*
***************************************************************************************************
*                                          WDT_Disable
*
* This function stops WDT counter and unregister interrupt handler.
*
* Notes
*
***************************************************************************************************
*/
SALRetCode_t WDT_Disable
(
    uint32          uiCh
);

/*
***************************************************************************************************
*                                          WDT_SmMode
*
* This function configurate wdt sm mode
*
* @return
*
* Notes
*
***************************************************************************************************
*/
SALRetCode_t WDT_SmMode
(
    uint32          uiCh,
    WDTSmVote_t     tWdtSmVote,
    WDTSmSig_t      tWdtSmSig
);

#endif  // ( SIC_BSP_SUPPORT_DRIVER_WDT == 1 )

#endif  // SIC_BSP_WDT_HEADER

