/*
***************************************************************************************************
*
*   FileName : reg_phys.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef REG_PHYS_HEADER
#define REG_PHYS_HEADER

/* Part 0. */
#define SIC_BSP_SNOR_BASE               (0x08000000UL)
#define SIC_BSP_BASE                    (0x1B000000UL)

/* Part 2. SMU & PMU */
#define SIC_BSP_SMU_BUS_BASE            (0x14000000UL)
#define SIC_BSP_SMU_VIC_BASE            (0x14100000UL)
#define SIC_BSP_SMU_GPIO_BASE           (0x14200000UL)
#define SIC_BSP_SMU_PMU_BASE            (0x14400000UL)
#define SIC_BSP_SMU_CFG_BASE            (0x14600000UL)
//#define SIC_BSP_PMU_BASE                (0x1B936000UL)

/* Part 3. Graphic */
#define SIC_BSP_GPU3D_BASE              (0x10000000UL)
#define SIC_BSP_GPU2D_BASE              (0x1A000000UL)

/* Part 4. Memory */
#define SIC_BSP_MBUS_CFG_BASE           (0x13500000UL)

/* Part 5. IO */
#define SIC_BSP_IOBUS_CFG_BASE          (0x16051000UL)
#define SIC_BSP_IOBUS_CFG1_BASE         (0x16494400UL)

/* Part 6. High Speed H/O */
#define SIC_BSP_HSIOBUS_CFG_BASE        (0x11DA0000UL)

/* Part 7. Display */
#define SIC_BSP_DBUS_VIOC_BASE          (0x12000000UL)

/* Part 8. Video */
#define SIC_BSP_VBUS_CFG_BASE           (0x15100000UL)

/* Part 9. CM */
#define SIC_BSP_CMBUS_CFG_BASE          (0x19100000UL)

/* Part 10. CPU */
#define SIC_BSP_CBUS_CFG_BASE           (0x17000000UL)
#define SIC_BSP_CBUS_GIC_BASE           (0x17300000UL)

/* Part 3. MCU SUB-SYSTEM */
#if ( CORTEX_M7_0==1 )
#define SIC_BSP_MBOX_BASE               (0x41000000UL)
#define SIC_BSP_WDT_BASE                (0x41100000UL)
#define SIC_BSP_CSR_BASE                (0x41E00000UL)
#define SIC_BSP_NOC_BASE                (0x41F00000UL)
#elif ( CORTEX_M7_1==1 )
#define SIC_BSP_MBOX_BASE               (0x42000000UL)
#define SIC_BSP_WDT_BASE                (0x42100000UL)
#define SIC_BSP_CSR_BASE                (0x42E00000UL)
#define SIC_BSP_NOC_BASE                (0x42F00000UL)
#elif ( CORTEX_M7_2==1 )
#define SIC_BSP_MBOX_BASE               (0x43000000UL)
#define SIC_BSP_WDT_BASE                (0x43100000UL)
#define SIC_BSP_CSR_BASE                (0x43E00000UL)
#define SIC_BSP_NOC_BASE                (0x43F00000UL)
#elif ( CORTEX_M7_NP==1 )
/* Part 6. NETWORK SUB-SYSTEM */
#define SIC_BSP_MBOX_BASE               (0x47000000UL)
#define SIC_BSP_WDT_BASE                (0x47100000UL)
#define SIC_BSP_CSR_BASE                (0x47E00000UL)
#define SIC_BSP_NOC_BASE                (0x47F00000UL)
#endif

/* Part 9. IO SUB-SYSTEM */
#define SIC_BSP_GPSB_BASE               (0x4A000000UL)
#define SIC_BSP_UART_BASE               (0x4A100000UL)
#define SIC_BSP_UDMA_BASE               (0x4A140000UL)
#define SIC_BSP_CAN_FD_BASE             (0x4A200000UL)
#define SIC_BSP_I2C_BASE                (0x4A300000UL)
#define SIC_BSP_ADC_BASE                (0x4A400000UL)
#define SIC_BSP_PWM_BASE                (0x4A500000UL)
#define SIC_BSP_ICTC_BASE               (0x4A600000UL)
#define SIC_BSP_IO_SUBSYS_BASE          (0x4AE00000UL)


/* Part 10. SMU SUB-SYSTEM */

#define SIC_BSP_CCU_BASE                (0x4B100000UL)
#define SIC_BSP_CMU_BASE                (0x4B110000UL)
#define SIC_BSP_PMU_BASE                (0x4B200000UL)
#define SIC_BSP_FMU_BASE                (0x4B210000UL)
#define SIC_BSP_GPIO_BASE               (0x4B300000UL)
#define SIC_BSP_PMIO_BASE               (0x4B310000UL)
#define SIC_BSP_RTC_CFG_BASE            (0x4B320000UL)
#define SIC_BSP_TIMER_BASE              (0x4B400000UL)
#define SIC_BSP_PIC_BASE                (0x4B500000UL)
#define SIC_BSP_TSC_BASE                (0x4B600000UL)
#define SIC_BSP_TRNG_BASE               (0x4B700000UL)
#define SIC_BSP_SMU_CSR_BASE            (0x4BE00000UL)
#define SIC_BSP_SMU_NOC_BASE            (0x4BF00000UL)


#define SIC_BSP_GIC_BASE                (0x1B900000UL)
#define SIC_BSP_SFMC_BASE               (0x1B910000UL)
#define SIC_BSP_SM_CTRL_BASE            (0x1B921000UL)
#define SIC_BSP_SUBSYS_BASE             (0x1B930000UL)
#define SIC_BSP_CKC_BASE                (0x1B931000UL)
#define SIC_BSP_DSE_BASE                (0x1B938000UL)
#define SIC_BSP_MID_CFG_BASE            (0x1B939000UL)
#define SIC_BSP_SFMC_MID_BASE           (0x1B93A000UL)
#define SIC_BSP_MID_BASE                (0x1B93B000UL)
#define SIC_BSP_MIPI_BASE               (0x1BC00000UL)
#define SIC_BSP_DP_BASE                 (0x1BD00000UL)

#define SIC_BSP_CHIP_VERSION            (0x1b9361CCUL)

//#define SRAM_DEVICE_SHARE_CONFIG_BASE 0xF0009FD0UL
//#define SRAM_BOOT_SEQ_CHECK_BASE  0xF0009FF8UL
#define SRAM_EXCEPTION_SAVE_BASE        (0xF000B1F0UL)  /* 0xF000_B200 (16bytes) */

#endif /* REG_PHYS_HEADER */

