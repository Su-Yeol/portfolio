/*
***************************************************************************************************
*
*   FileName : debug.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#if (SIC_BSP_SUPPORT_DRIVER_UART)
#include <uart.h>
#endif
#include <string.h>
#include <debug.h>
#include <stdarg.h>
#include <stdint.h>
//#include <tcc_type.h> //include for "false""
uint32                                  gDebugOption = 0xC0000001UL;

DbgTag_t                                dbgTags[DBG_MAX_TAGS] =
{
    {"SAL\0\0\0"},
    {"MPU\0\0\0"},
    {"GIC\0\0\0"},
    {"SSM\0\0\0"},
    {"MIDF\0\0"},
    {"CAN\0\0\0"},
    {"GPSB\0\0"},
    {"UART\0\0"},
    {"I2C\0\0\0"},
    {"PDM\0\0\0"},
    {"ICTC\0\0"},
    {"GDMA\0\0"},
    {"ADC\0\0\0"},
    {"MBOX\0\0"},
    {"TIMER\0"},
    {"WDT\0\0\0"},
    {"CKC\0\0\0"},
    {"GPIO\0\0"},
    {"PMIO\0\0"},
    {"DSE\0\0\0"},
    {"SDM\0\0\0"},
    {"FMU\0\0\0"},
    {"FWUG\0\0"},
    {"LIN\0\0\0"},
    {"TRVC\0\0"},
    {"SFMC\0\0"},
    {"GMAC\0\0"},
    {"TPA\0\0\0"},
    {"LPA\0\0\0"}
};


// 'ntoa' conversion buffer size, this must be big enough to hold one converted
// numeric number including padded zeros (dynamically created on stack)
// default: 32 byte
#ifndef PRINTF_NTOA_BUFFER_SIZE
#define PRINTF_NTOA_BUFFER_SIZE    32U
#endif

// 'ftoa' conversion buffer size, this must be big enough to hold one converted
// float number including padded zeros (dynamically created on stack)
// default: 32 byte
#ifndef PRINTF_FTOA_BUFFER_SIZE
#define PRINTF_FTOA_BUFFER_SIZE    32U
#endif

// support for the floating point type (%f)
// default: activated
#define PRINTF_DISABLE_SUPPORT_FLOAT
#ifndef PRINTF_DISABLE_SUPPORT_FLOAT
#define PRINTF_SUPPORT_FLOAT
#endif

// support for exponential floating point notation (%e/%g)
// default: activated
#define PRINTF_DISABLE_SUPPORT_EXPONENTIAL
#ifndef PRINTF_DISABLE_SUPPORT_EXPONENTIAL
#define PRINTF_SUPPORT_EXPONENTIAL
#endif

// define the default floating point precision
// default: 6 digits
#ifndef PRINTF_DEFAULT_FLOAT_PRECISION
#define PRINTF_DEFAULT_FLOAT_PRECISION  6U
#endif

// define the largest float suitable to print with %f
// default: 1e9
#ifndef PRINTF_MAX_FLOAT
#define PRINTF_MAX_FLOAT  1e9
#endif

// support for the long long types (%llu or %p)
// default: activated
#define PRINTF_DISABLE_SUPPORT_LONG_LONG
#ifndef PRINTF_DISABLE_SUPPORT_LONG_LONG
#define PRINTF_SUPPORT_LONG_LONG
#endif

// support for the ptrdiff_t type (%t)
// ptrdiff_t is normally defined in <stddef.h> as long or long long type
// default: activated
#define PRINTF_DISABLE_SUPPORT_PTRDIFF_T
#ifndef PRINTF_DISABLE_SUPPORT_PTRDIFF_T
#define PRINTF_SUPPORT_PTRDIFF_T
#endif


// internal flag definitions
#define FLAGS_ZEROPAD   (1U <<  0U)
#define FLAGS_LEFT      (1U <<  1U)
#define FLAGS_PLUS      (1U <<  2U)
#define FLAGS_SPACE     (1U <<  3U)
#define FLAGS_HASH      (1U <<  4U)
#define FLAGS_UPPERCASE (1U <<  5U)
#define FLAGS_CHAR      (1U <<  6U)
#define FLAGS_SHORT     (1U <<  7U)
#define FLAGS_LONG      (1U <<  8U)
#define FLAGS_LONG_LONG (1U <<  9U)
#define FLAGS_PRECISION (1U << 10U)
#define FLAGS_ADAPT_EXP (1U << 11U)

// Static

static sint32 _putchar
(
    sint8                               putChar
);

// output function type
typedef void (*out_fct_type)(sint8 character, void* buffer, sint32 idx, sint32 maxlen);

// internal test if char is a digit (0-9)
// \return true if char is a digit
static inline sint32 _is_digit(sint8 ch)
{
  return (ch >= '0') && (ch <= '9');
}

// internal secure strlen
// \return The length of the string (excluding the terminating 0) limited by 'maxsize'
static inline uint32 _strnlen_s(const sint8* str, sint32 maxsize)
{
  const sint8* s;
  for (s = str; *s && maxsize--; ++s);
  return (uint32)(s - str);
}


// internal ASCII string to uint32 conversion
static uint32 _atoi(const sint8** str)
{
  uint32 i = 0U;
  while (_is_digit(**str)) {
    i = i * 10U + (uint32)(*((*str)++) - '0');
  }
  return i;
}

// output the specified string in reverse, taking care of any zero-padding
static sint32 _out_rev(out_fct_type out, sint8* buffer, sint32 idx, sint32 maxlen, const sint8* buf, sint32 len, sint32 width, uint32 flags)
{
  const sint32 start_idx = idx;
  sint32 i;

  // pad spaces up to given width
  if (!(flags & FLAGS_LEFT) && !(flags & FLAGS_ZEROPAD)) {
    for (i = len; i < width; i++) {
      out(' ', buffer, idx++, maxlen);
    }
  }

  // reverse string
  while (len) {
    out(buf[--len], buffer, idx++, maxlen);
  }

  // append pad spaces up to given width
  if (flags & FLAGS_LEFT) {
    while (idx - start_idx < width) {
      out(' ', buffer, idx++, maxlen);
    }
  }

  return idx;
}


// internal itoa format
static sint32 _ntoa_format(out_fct_type out, sint8* buffer, uint32 idx, uint32 maxlen, sint8* buf, uint32 len, sint32 negative, uint32 base, uint32 prec, uint32 width, uint32 flags)
{
  // pad leading zeros
  if (!(flags & FLAGS_LEFT)) {
    if (width && (flags & FLAGS_ZEROPAD) && (negative || (flags & (FLAGS_PLUS | FLAGS_SPACE)))) {
      width--;
    }
    while ((len < prec) && (len < PRINTF_NTOA_BUFFER_SIZE)) {
      buf[len++] = '0';
    }
    while ((flags & FLAGS_ZEROPAD) && (len < width) && (len < PRINTF_NTOA_BUFFER_SIZE)) {
      buf[len++] = '0';
    }
  }

  // handle hash
  if (flags & FLAGS_HASH) {
    if (!(flags & FLAGS_PRECISION) && len && ((len == prec) || (len == width))) {
      len--;
      if (len && (base == 16U)) {
        len--;
      }
    }
    if ((base == 16U) && !(flags & FLAGS_UPPERCASE) && (len < PRINTF_NTOA_BUFFER_SIZE)) {
      buf[len++] = 'x';
    }
    else if ((base == 16U) && (flags & FLAGS_UPPERCASE) && (len < PRINTF_NTOA_BUFFER_SIZE)) {
      buf[len++] = 'X';
    }
    else if ((base == 2U) && (len < PRINTF_NTOA_BUFFER_SIZE)) {
      buf[len++] = 'b';
    }
    if (len < PRINTF_NTOA_BUFFER_SIZE) {
      buf[len++] = '0';
    }
  }

  if (len < PRINTF_NTOA_BUFFER_SIZE) {
    if (negative) {
      buf[len++] = '-';
    }
    else if (flags & FLAGS_PLUS) {
      buf[len++] = '+';  // ignore the space if the '+' exists
    }
    else if (flags & FLAGS_SPACE) {
      buf[len++] = ' ';
    }
  }

  return _out_rev(out, buffer, idx, maxlen, buf, len, width, flags);
}


// internal itoa for 'long' type
static sint32 _ntoa_long(out_fct_type out, sint8* buffer, uint32 idx, uint32 maxlen, uint32 value, sint32 negative, unsigned long base, uint32 prec, uint32 width, uint32 flags)
{
  sint8 buf[PRINTF_NTOA_BUFFER_SIZE];
  uint32 len = 0U;

  // no hash for 0 values
  if (!value) {
    flags &= ~FLAGS_HASH;
  }

  // write if precision != 0 and value is != 0
  if (!(flags & FLAGS_PRECISION) || value) {
    do {
      const sint8 digit = (sint8)(value % base);
      buf[len++] = digit < 10 ? '0' + digit : (flags & FLAGS_UPPERCASE ? 'A' : 'a') + digit - 10;
      value /= base;
    } while (value && (len < PRINTF_NTOA_BUFFER_SIZE));
  }

  return _ntoa_format(out, buffer, idx, maxlen, buf, len, negative, (uint32)base, prec, width, flags);
}


// internal null output
static inline void _out_null(sint8 character, void* buffer, sint32 idx, sint32 maxlen)
{
  (void)character; (void)buffer; (void)idx; (void)maxlen;
}

// internal vsnprintf
static int _vsnprintf(out_fct_type out, sint8* buffer, const uint32 maxlen, const int8* format, va_list va)
{
  uint32 flags, width, precision, n;
  uint32 idx = 0U;

  if (!buffer) {
    // use null output function
    out = _out_null;
  }

  while (*format)
  {
    // format specifier?  %[flags][width][.precision][length]
    if (*format != '%') {
      // no
      out(*format, buffer, idx++, maxlen);
      format++;
      continue;
    }
    else {
      // yes, evaluate it
      format++;
    }

    // evaluate flags
    flags = 0U;
    do {
      switch (*format) {
        case '0': flags |= FLAGS_ZEROPAD; format++; n = 1U; break;
        case '-': flags |= FLAGS_LEFT;    format++; n = 1U; break;
        case '+': flags |= FLAGS_PLUS;    format++; n = 1U; break;
        case ' ': flags |= FLAGS_SPACE;   format++; n = 1U; break;
        case '#': flags |= FLAGS_HASH;    format++; n = 1U; break;
        default :                                   n = 0U; break;
      }
    } while (n);

    // evaluate width field
    width = 0U;
    if (_is_digit(*format)) {
      width = _atoi((const sint8**)&format);
    }
    else if (*format == '*') {
      const int w = va_arg(va, int);
      if (w < 0) {
        flags |= FLAGS_LEFT;    // reverse padding
        width = (uint32)-w;
      }
      else {
        width = (uint32)w;
      }
      format++;
    }

    // evaluate precision field
    precision = 0U;
    if (*format == '.') {
      flags |= FLAGS_PRECISION;
      format++;
      if (_is_digit(*format)) {
        precision = _atoi((const sint8**)&format);
      }
      else if (*format == '*') {
        const int prec = (int)va_arg(va, int);
        precision = prec > 0 ? (uint32)prec : 0U;
        format++;
      }
    }

    // evaluate length field
    switch (*format) {
      case 'l' :
        flags |= FLAGS_LONG;
        format++;
        if (*format == 'l') {
          flags |= FLAGS_LONG_LONG;
          format++;
        }
        break;
      case 'h' :
        flags |= FLAGS_SHORT;
        format++;
        if (*format == 'h') {
          flags |= FLAGS_CHAR;
          format++;
        }
        break;
#if defined(PRINTF_SUPPORT_PTRDIFF_T)
      case 't' :
        flags |= (sizeof(ptrdiff_t) == sizeof(long) ? FLAGS_LONG : FLAGS_LONG_LONG);
        format++;
        break;
#endif
      //case 'j' :
      //  flags |= (sizeof(intmax_t) == sizeof(long) ? FLAGS_LONG : FLAGS_LONG_LONG);
      //  format++;
      //  break;
      case 'z' :
        flags |= (sizeof(sint32) == sizeof(long) ? FLAGS_LONG : FLAGS_LONG_LONG);
        format++;
        break;
      default :
        break;
    }

    // evaluate specifier
    switch (*format) {
      case 'd' :
      case 'i' :
      case 'u' :
      case 'x' :
      case 'X' :
      case 'o' :
      case 'b' : {
        // set the base
        uint32 base;
        if (*format == 'x' || *format == 'X') {
          base = 16U;
        }
        else if (*format == 'o') {
          base =  8U;
        }
        else if (*format == 'b') {
          base =  2U;
        }
        else {
          base = 10U;
          flags &= ~FLAGS_HASH;   // no hash for dec format
        }
        // uppercase
        if (*format == 'X') {
          flags |= FLAGS_UPPERCASE;
        }

        // no plus or space flag for u, x, X, o, b
        if ((*format != 'i') && (*format != 'd')) {
          flags &= ~(FLAGS_PLUS | FLAGS_SPACE);
        }

        // ignore '0' flag when precision is given
        if (flags & FLAGS_PRECISION) {
          flags &= ~FLAGS_ZEROPAD;
        }

        // convert the integer
        if ((*format == 'i') || (*format == 'd')) {
          // signed
          if (flags & FLAGS_LONG_LONG) {
#if defined(PRINTF_SUPPORT_LONG_LONG)
            const long long value = va_arg(va, long long);
            idx = _ntoa_long_long(out, buffer, idx, maxlen, (unsigned long long)(value > 0 ? value : 0 - value), value < 0, base, precision, width, flags);
#endif
          }
          else if (flags & FLAGS_LONG) {
            const long value = va_arg(va, long);
            idx = _ntoa_long(out, buffer, idx, maxlen, (unsigned long)(value > 0 ? value : 0 - value), value < 0, base, precision, width, flags);
          }
          else {
            const int value = (flags & FLAGS_CHAR) ? (sint8)va_arg(va, int) : (flags & FLAGS_SHORT) ? (short int)va_arg(va, int) : va_arg(va, int);
            idx = _ntoa_long(out, buffer, idx, maxlen, (uint32)(value > 0 ? value : 0 - value), value < 0, base, precision, width, flags);
          }
        }
        else {
          // unsigned
          if (flags & FLAGS_LONG_LONG) {
#if defined(PRINTF_SUPPORT_LONG_LONG)
            idx = _ntoa_long_long(out, buffer, idx, maxlen, va_arg(va, unsigned long long), false, base, precision, width, flags);
#endif
          }
          else if (flags & FLAGS_LONG) {
            idx = _ntoa_long(out, buffer, idx, maxlen, va_arg(va, uint32), /*(false)*/0, base, precision, width, flags);
          }
          else {
            const uint32 value = (flags & FLAGS_CHAR) ? (uint8)va_arg(va, uint32) : (flags & FLAGS_SHORT) ? (uint16)va_arg(va, uint32) : va_arg(va, uint32);
            idx = _ntoa_long(out, buffer, idx, maxlen, value, /*(false)*/0, base, precision, width, flags);
          }
        }
        format++;
        break;
      }
#if defined(PRINTF_SUPPORT_FLOAT)
      case 'f' :
      case 'F' :
        if (*format == 'F') flags |= FLAGS_UPPERCASE;
        idx = _ftoa(out, buffer, idx, maxlen, va_arg(va, double), precision, width, flags);
        format++;
        break;
#if defined(PRINTF_SUPPORT_EXPONENTIAL)
      case 'e':
      case 'E':
      case 'g':
      case 'G':
        if ((*format == 'g')||(*format == 'G')) flags |= FLAGS_ADAPT_EXP;
        if ((*format == 'E')||(*format == 'G')) flags |= FLAGS_UPPERCASE;
        idx = _etoa(out, buffer, idx, maxlen, va_arg(va, double), precision, width, flags);
        format++;
        break;
#endif  // PRINTF_SUPPORT_EXPONENTIAL
#endif  // PRINTF_SUPPORT_FLOAT
      case 'c' : {
        uint32 l = 1U;
        // pre padding
        if (!(flags & FLAGS_LEFT)) {
          while (l++ < width) {
            out(' ', buffer, idx++, maxlen);
          }
        }
        // char output
        out((sint8)va_arg(va, int), buffer, idx++, maxlen);
        // post padding
        if (flags & FLAGS_LEFT) {
          while (l++ < width) {
            out(' ', buffer, idx++, maxlen);
          }
        }
        format++;
        break;
      }

      case 's' : {
        const sint8* p = va_arg(va, sint8*);
        uint32 l = _strnlen_s(p, precision ? precision : 0xFFFFFFFFUL/*(size_t)-1*/);
        // pre padding
        if (flags & FLAGS_PRECISION) {
          l = (l < precision ? l : precision);
        }
        if (!(flags & FLAGS_LEFT)) {
          while (l++ < width) {
            out(' ', buffer, idx++, maxlen);
          }
        }
        // string output
        while ((*p != 0) && (!(flags & FLAGS_PRECISION) || precision--)) {
          out(*(p++), buffer, idx++, maxlen);
        }
        // post padding
        if (flags & FLAGS_LEFT) {
          while (l++ < width) {
            out(' ', buffer, idx++, maxlen);
          }
        }
        format++;
        break;
      }

      case 'p' : {
        width = sizeof(void*) * 2U;
        flags |= FLAGS_ZEROPAD | FLAGS_UPPERCASE;
#if defined(PRINTF_SUPPORT_LONG_LONG)
        const sint32 is_ll = sizeof(uintptr_t) == sizeof(long long);
        if (is_ll) {
          idx = _ntoa_long_long(out, buffer, idx, maxlen, (uintptr_t)va_arg(va, void*), false, 16U, precision, width, flags);
        }
        else {
#endif
          idx = _ntoa_long(out, buffer, idx, maxlen, (unsigned long)((uintptr_t)va_arg(va, void*)), /*(false)*/0, 16U, precision, width, flags);
#if defined(PRINTF_SUPPORT_LONG_LONG)
        }
#endif
        format++;
        break;
      }

      case '%' :
        out('%', buffer, idx++, maxlen);
        format++;
        break;

      default :
        out(*format, buffer, idx++, maxlen);
        format++;
        break;
    }
  }

  // termination
  out((sint8)0, buffer, idx < maxlen ? idx : maxlen - 1U, maxlen);

  // return written chars without terminating \0
  return (int)idx;
}

/*------- external -----------*/
static sint32 _putchar
(
    sint8                               putChar
) /* QAC - MISRA-C:2004 Rule 8.8 - This function is used in ASM */
{
//#ifndef TEMP_UART
#if (SIC_BSP_SUPPORT_DRIVER_UART)
    if (putChar == (sint8)'\n')
    {
        (void)UART_PutChar((uint8)UART_DEBUG_CH, (uint8)'\r');
    }

    (void)UART_PutChar((uint8)UART_DEBUG_CH, (uint8)putChar);
#endif
    return 0;
}

// internal _putchar wrapper
static inline void _out_char(sint8 character, void* buffer, uint32 idx, uint32 maxlen)
{
  (void)buffer; (void)idx; (void)maxlen;
  if (character) {
    _putchar(character);
  }
}


void DBG_SerialPrintf(const int8* format, ...)
{
	sint8 buffer[1];
	va_list va;
	va_start(va, format);
	(void)_vsnprintf((out_fct_type)&_out_char, buffer, 0xFFFFFFFFUL/*(size_t)-1*/, format, va);
	va_end(va);
}



#if 0 // old
#if DEBUG_ENABLE
#define is_digit(c)                     (((c) >= (sint8)'0') && ((c) <= (sint8)'9'))
#define to_upper(c)                     ((c) & ~0x20)

typedef void                            (fPUTC)(sint8 c);

static sint32 DBG_Print8
(
    uint32                              num,
    sint8 *                             str
);

static sint32 DBG_Print10
(
    uint32                              num,
    sint8 *                             str
);

static sint32 DBG_Print16L
(
    uint32                              num,
    sint8 *                             str
); //Lowercase

static sint32 DBG_Print16U
(
    uint32                              num,
    sint8 *                             str
); //Uppercase

sint32 DBG_Putc
(
    sint8                               putChar
);

sint32 DBG_Printfi
(
    fPUTC *                             fPutC,
    const sint8 *                       fmt_in,
    const sint32 *                      args_in
);

/*------- external -----------*/
sint32 DBG_Putc
(
    sint8                               putChar
) /* QAC - MISRA-C:2004 Rule 8.8 - This function is used in ASM */
{
    if (putChar == (sint8)'\n')
    {
        (void)UART_PutChar((uint8)UART_DEBUG_CH, (uint8)'\r');
    }

    (void)UART_PutChar((uint8)UART_DEBUG_CH, (uint8)putChar);

    return 0;
}

/*
 * print character
 */
static sint32 DBG_Print8
(
    uint32                              num,
    sint8 *                             str
)
{
    sint32  len;
    sint8   temp[20];
    sint8   *p  = temp;
    sint8   *destStr;
    uint32  numChar;
    uint32  calcTemp;

    numChar = num;
    *p      = 0;
    len     = 0;

    if(str != NULL_PTR)
    {
        destStr = str;

        do
        {
            ++p;
            calcTemp    = numChar%8UL; //orig numChar & 0x7
            *p          = ((sint8)((sint8)calcTemp) + (sint8)'0');
            numChar     = numChar/8UL;//orig numChar     = numChar >> 3U;
            len++;
        } while (numChar!=0UL);

        while(TRUE)
        {
            *destStr    = *p;
            destStr++;

            if((*p) == 0)
            {
                break;
            }

            p--;
         }
    }

    return  len;
}

/*
 * print decimal
 */
static sint32 DBG_Print10
(
    uint32                              num,
    sint8 *                             str
)
{
    sint32  len;
    sint8   temp[20];
    sint8   *p  = temp;
    sint8   *destStr;
    uint32 numChar;
    uint32 calcTemp;

    numChar = num;
    *p      = 0;
    len     = 0;

    if(str != NULL_PTR)
    {
        destStr = str;

        do
        {
            ++p;
            calcTemp    = numChar % 10UL;
            *p          = (sint8)((sint8)calcTemp + (sint8)'0');
            numChar     = numChar / 10UL;
            len++;
        } while (numChar != 0UL);

        while(TRUE)
        {
            *destStr    = *p;
            destStr++;

            if((*p) == 0)
            {
                break;
            }

            p--;
        }
    }

    return  len;
}

/*
 * print hexa-decimal, lower case
 */
static sint32 DBG_Print16L
(
    uint32                              num,
    sint8 *                             str
)
{
    sint32  len;
    sint8   temp[20];
    sint8   *p  = temp;
    sint8   *destStr;
    uint32  numChar;
    uint32  calcTemp;

    numChar = num;
    *p      = 0;
    len     = 0;

    if(str != NULL_PTR)
    {
        destStr = str;

        do
        {
            ++p;
            calcTemp    = numChar % 16UL; //numChar & 0x0f
            *p          = (sint8)"0123456789abcdef"[calcTemp];
            numChar     = numChar / 16UL;
            len++;
        } while (numChar != 0UL);

        while(TRUE)
        {
            *destStr    = *p;
            destStr++;

            if((*p) == 0)
            {
                break;
            }

            p--;
        }
    }

    return  len;
}

/*
 * print hexa-decimal, upper case
 */
static sint32 DBG_Print16U
(
    uint32                              num,
    sint8 *                             str
)
{
    sint32  len;
    sint8   temp[20];
    sint8   *p  = temp;
    sint8   *destStr;
    uint32  numChar;
    uint32  calcTemp;

    numChar = num;
    *p      = 0;
    len     = 0;

    if(str != NULL_PTR)
    {
        destStr = str;

        do
        {
            ++p;
            calcTemp    = numChar % 16UL; //numChar & 0x0f
            *p          = (sint8)"0123456789ABCDEF"[calcTemp];
            numChar     = numChar / 16UL;
            len++;
        } while (numChar != 0UL);

        while(TRUE)
        {
            *destStr    = *p;
            destStr++;

            if((*p) == 0)
            {
                break;
            }

            p--;
        }
    }

    return  len;
}

static sint32 DBG_CheckFormat
(
    const sint8 **                      fmt,
    const sint32 **                     args,
    fPUTC *                             fPutC,
    DBGFormatInfo_t *                   fi
)
{
    sint32 ret;

    ret = DBG_SUCCESS;

    /* Echo " ... %%..." as '%'  */
    if (*(*fmt) == (sint8)'%')
    {
        (*fPutC)(*(*fmt));
        (*fmt)++;

        ret = DBG_AGAIN;
    }
    else
    {
        /* Check for "%-...",== Left-justified output */
        if (*(*fmt) == (sint8)'-')//if ((*fmt == (sint8)'-') != 0)
        {
            fi->leftjust = 1;
            (*fmt)++;
        }
        else
        {
            fi->leftjust = 0;
        }

        /* Allow for zero-filled numeric outputs ("%0...") */
        if (*(*fmt) ==(sint8)'0')
        {
            fi->fill = *(*fmt);
            (*fmt)++;
        }
        else
        {
            fi->fill = (sint8)' ';
        }

        /* Allow for minimum field width specifier for %d %u x,c,o,s */
        /* Also  allow %* for variable width (%0* as well)   */
        fi->fminString = 0L;

        if (*(*fmt) == (sint8)'*')
        {
            fi->fminString = *(*args);
            (*args)++;
            ++(*fmt);
        }
        else
        {
            while ((sint8)is_digit(*(*fmt)) != 0)
            {
                if (fi->fminString >= DBG_MAX_DIGIT)
                {
                    break;
                }
                else
                {
                    fi->fminString = (((fi->fminString * 10L) + (*(*fmt))) - (sint8)'0') ;
                    (*fmt)++;
                }
            }
        }

        /* Allow for maximum string width for %s */
        fi->fmaxString = 0;

        if (*(*fmt) == (sint8)'.')
        {
            ++(*fmt);

            if (*(*fmt) == (sint8)'*' )
            {
                fi->fmaxString = *(*args);
                (*args)++;
                ++(*fmt);
            }
            else
            {
                while ((sint8)is_digit(*(*fmt)) != 0) {
                    if (fi->fmaxString >= DBG_MAX_DIGIT)
                    {
                        break;
                    }
                    else
                    {
                        fi->fmaxString = (((fi->fmaxString * 10) + (*(*fmt))) - (sint8)'0');
                        (*fmt)++;
                    }
                }
            }
        }
    }

    return ret;
}

static void DBG_SetFormatInfo
(
    sint32                              f,
    const sint32 * const *              args,
    sint8 **                            str,
    sint8 *                             strArray,
    DBGFormatInfo_t *                   fi
)
{
    sint32       i;
    const sint8* tmp;

    fi->sign = 0;

    switch (f)
    {
        case 0x63/*'c'*/ :
        {
            tmp = (const sint8 *) *args;
            strArray[0] = tmp[3];;
            strArray[1] = (sint8) '\0';
            *str        = strArray;
            fi->length      = 1;
            fi->fmaxString  = 0;
            fi->fill        = (sint8)' ';
            break;
        }

        case 0x73/*'s'*/ :
        {
            (void) memcpy(str, *args, sizeof(sint8 *));

            for (fi->length = 0; fi->length < 2147483647; fi->length ++)//change of for(;;)
            {
                if(*(*str) == 0)
                {
                    break;
                }

                (*str)++;
            }
            (*str)++;
            (void) memcpy(str, *args, sizeof(sint8 *));
            fi->fill    = (sint8)' ';
            break;
        }

        case 0x64 /*'d'*/ :
        {
            *str = strArray;
            i    = *(const sint32 *) *args;

            if (i < 0)
            {
                fi->sign    = (sint8)'-';
                i       = -i;
            }

            fi->length      = DBG_Print10((uint32)i, *str);
            fi->fmaxString  = 0;
            break;
        }

        case 0x6f /*'o'*/ :
        {
            *str            = strArray;
            fi->length      = DBG_Print8((uint32) (*(*args)), *str);
            fi->fmaxString  = 0;
            break;
        }

        case 0x78 /*'x'*/ :
        {
            *str            = strArray;
            fi->length      = DBG_Print16L((uint32) (*(*args)), *str);
            fi->fmaxString  = 0;
            break;
        }

        case 0x58 /*'X'*/ :
        {
            *str            = strArray;
            fi->length      = DBG_Print16U((uint32) (*(*args)), *str);
            fi->fmaxString  = 0;
            break;
        }

        default:
        {
            /* format is not supported */
            (void) memcpy(str, *args, sizeof(void *));
            fi->length  = 1;
            break;
        }
    }

    fi->leading = 0;
}

static void DBG_WriteFormat
(
    sint8 **                            str,
    const sint32 **                     args,
    fPUTC *                             fPutC,
    DBGFormatInfo_t *                   fi
)
{
    sint32         i;

    if ((fi->fmaxString != 0) || (fi->fminString!=0))
    {
        if (fi->fmaxString != 0)
        {
            if (fi->length > fi->fmaxString)
            {
                fi->length  = fi->fmaxString;
            }
        }

        if (fi->fminString!=0)
        {
            fi->leading     = fi->fminString - fi->length;
        }

        if (fi->sign == (sint8)'-')
        {
            fi->leading = (fi->leading == DBG_MIN_INT) ? fi->leading : (fi->leading - 1);
        }
    }

    if ((fi->sign == (sint8)'-') && (fi->fill == (sint8)'0'))
    {
        (*fPutC)(fi->sign);
    }

    if (fi->leftjust==0)//if (!fi->leftjust)
    {
        for (i = 0; i < fi->leading; i ++)
        {
            (*fPutC)(fi->fill);
        }
    }

    if ((fi->sign == (sint8)'-') && (fi->fill == (sint8)' '))
    {
        (*fPutC)(fi->sign);
    }

    for (i = 0; i < fi->length; i ++)
    {
        (*fPutC)(*(*str));
        (*str)++;
    }

    if (fi->leftjust != 0)
    {
        for (i = 0; i < fi->leading; i ++)
        {
            (*fPutC)(fi->fill);
        }
    }

    (*args)++;
}

/*
 *
 */
sint32 DBG_Printfi
(
    fPUTC *                             fPutC,
    const sint8 *                       fmt_in,
    const sint32 *                      args_in
) /* QAC - MISRA-C:2004 Rule 8.8 - This function is used in ASM */
{
    sint32         f    = 0L;
    sint8          c    = -1;
    sint8 *        str  = NULL;
    sint8          strArray[64];
    const sint8 *  fmt  = NULL;
    const sint32 * args = NULL;

    DBGFormatInfo_t formatInfo;

    formatInfo.length      = 0;
    formatInfo.leftjust    = 0;

    if ((fPutC != NULL_PTR) && (fmt_in != NULL_PTR) && (args_in != NULL_PTR))
    {
        fmt     = fmt_in;
        args    = args_in;

        for(;;)
        {
            /* Echo character until '%' or end of fmt string */
            while ((*fmt) != (sint8)'%')
            {
                c = *fmt;
                fmt++;

                if (c == (sint8)0)//if (!c)
                {
                    break;
                }

                (*fPutC)(c);
            }

            if (c != (sint8)0)
            {
                fmt++;

                if (DBG_AGAIN == DBG_CheckFormat(&fmt, &args, fPutC, &formatInfo))
                {
                    continue;
                }

                if ((*fmt) == 0)
                {
                    f = *fmt;
                    fmt++;
                    (*fPutC)((sint8)'%');
                }
                else
                {
                    f = *fmt;
                    fmt++;
                    DBG_SetFormatInfo(f, &args, &str, strArray, &formatInfo);
                    DBG_WriteFormat(&str, &args, fPutC, &formatInfo);
                }
            }
            else
            {
                break;
            }
        }
    }

    return (-1);
}

__attribute__ ((naked)) void DBG_SerialPrintf
(
    const int8 *                        format,
    ...
) /* QAC - MISRA-C:2004 Rule 16.1 - Printf() needs variable parameters */
{
    /*The compiler only supports basic __asm statements in __attribute__((naked)) functions.
      Using extended assembly, parameter references or mixing C code with __asm statements might not work reliably.*/
    //(void)format;
#if defined(__GNUC__)
#if 1
    __asm volatile (
            "stmdb  sp!, {r1-r3}    \n"
            "mov    r1, r0          \n"     /* r1 = format string */
            "mov    r2, sp          \n"     /* r2 = arguments */
            "ldr    r0, =DBG_Putc     \n"     /* r0 = function pointer which will put character */
            "str    lr, [sp, #-4]!  \n"     /* save r14 */
            "bl     DBG_Printfi       \n"
            "ldr    lr, [sp], #4    \n"     /* restore r14 */
            "add    sp, sp, #12     \n"     /* restore stack */
            "mov    pc, lr          \n"
            :::"r0", "r1", "r2", "r3" \
    );
#endif
#else //Green Hills case
    #pragma asm
    mov r1, r0
    mov r2, sp
    add r2, r2, #8
    ldr r0, =DBG_Putc
    str lr, [sp, #-4]!
    bl  DBG_Printfi
    ldr lr, [sp], #4
    add sp, sp, #20
    mov pc, lr
    #pragma endasm
#endif
}
#else
__attribute__ ((naked)) void DBG_SerialPrintf
(
    const int8 *                        format,
    ...
) /* QAC - MISRA-C:2004 Rule 16.1 - Printf() needs variable parameters */
{

}
#endif
#endif
