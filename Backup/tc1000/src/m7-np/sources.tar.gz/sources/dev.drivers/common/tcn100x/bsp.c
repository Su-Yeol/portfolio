/*
***************************************************************************************************
*
*   FileName : bsp.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include "bsp.h"

#include <reg_phys.h>
#include <debug.h>
#include <clock.h>
#include <mpu.h>
#include <nvic.h>

#if(SIC_BSP_SUPPORT_DRIVER_WDT)
#include <wdt.h>
#endif

#if (SIC_BSP_SUPPORT_DRIVER_GPSB)
#include <gpsb.h>
#endif

#if (SIC_BSP_SUPPORT_DRIVER_I2C)
#include <i2c.h>
#endif

#if (SIC_BSP_SUPPORT_DRIVER_UART)
#include <uart.h>
#endif

#if (SIC_BSP_SUPPORT_DRIVER_TIMER==1)
#include <timer.h>
#endif

#if(SIC_BSP_SUPPORT_DRIVER_SWDT)
#include <swdt.h>
#endif

#if(SIC_BSP_SUPPORT_DRIVER_MBOX)
#include <mbox.h>
#include <ipi.h>

#endif

#if (SIC_BSP_SUPPORT_DRIVER_FMU)
#include <fmu.h>
#endif

#if (SIC_BSP_SUPPORT_DRIVER_PMIO)
#include <pmio.h>
#endif

#if (SIC_BSP_SUPPORT_DRIVER_ADC)
#include <adc.h>
#endif

/*
***************************************************************************************************
                                         STATIC VARIABLES
***************************************************************************************************
*/
//static uint32 *                         puiChipVersion = (uint32 *) SIC_BSP_CHIP_VERSION;

/*
***************************************************************************************************
                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/
static void BSP_PreGpioSel
(
    void
);

static void BSP_SystemMpuSetup
(
    void
);

/*
***************************************************************************************************
*                                         FUNCTIONS
***************************************************************************************************
*/

void BSP_PreInit
(
    void
)
{
#if (SIC_BSP_SUPPORT_DRIVER_PMIO)
    PMIO_Init();
#endif

    CLOCK_Init();

    NVIC_SetPIC();
    NVIC_Init();
}

static void BSP_InitPhase00
(
    void
)
{

#if (SIC_BSP_SUPPORT_DRIVER_TIMER==1)
    //(void)TIMER_Init();
#endif
#if (SIC_BSP_SUPPORT_DRIVER_UART)
    (void)UART_Init(); //to be ported
#endif

#if(SIC_BSP_SUPPORT_DRIVER_WDT)
    #if ( CORTEX_M7_0 == 1 )
        (void)WDT_Enable(0, WDT_SEC(10), WDT_SEC(24));
    #elif ( CORTEX_M7_1 == 1)
        (void)WDT_Enable(1, WDT_SEC(10), WDT_SEC(24));
    #elif ( CORTEX_M7_2 == 1)
        (void)WDT_Enable(2, WDT_SEC(10), WDT_SEC(24));
    #else
        (void)WDT_Enable(3, WDT_SEC(10), WDT_SEC(24));
    #endif
#endif

    //uart_init();
#if (SIC_BSP_SUPPORT_DRIVER_GPSB == 1)
    GPSB_Init(); //to be ported
#endif
#if (SIC_BSP_SUPPORT_DRIVER_I2C == 1)
    I2C_Init();
#endif
#if (SIC_BSP_SUPPORT_DRIVER_ADC == 1)
    ADC_Init(0);
#endif

    //SystemHalt();
}

static void BSP_InitPhase01
(
    void
)
{
#if (SIC_BSP_SUPPORT_DRIVER_FMU)
    (void)FMU_Init();
#endif

#if (SIC_BSP_SUPPORT_DRIVER_MBOX)
    (void)MBOX_Init();
	(void)ipi_mailbox_init();

#endif

#if (SIC_BSP_SUPPORT_DRIVER_PMIO)
    PMIO_SetPortType((PMIO_GPK(0)|PMIO_GPK(1)), PMIO_PORT_PM_IN);
    PMIO_SetPortIntr((PMIO_GPK(0)|PMIO_GPK(1)), PMIO_INTR_FALLING_EDGE, &PMIO_PowerDown);
    PMIO_SetPortWkup((PMIO_GPK(0)|PMIO_GPK(1)), PMIO_WKUP_RISING_EDGE);
#endif
}

void BSP_Init
(
    void
)
{
    BSP_InitPhase00();
    BSP_InitPhase01(); //blocking for mal-function of MBOX_Init()

    mcu_printf("\nInitialize System done : ");
#if ( CORTEX_M7_0 == 1 )
    mcu_printf("Start TCN100x [CM7-0]\n");
#elif ( CORTEX_M7_1 == 1)
    mcu_printf("Start TCN100x [CM7-1]\n");
#elif ( CORTEX_M7_2 == 1)
    mcu_printf("Start TCN100x [CM7-2]\n");
#elif ( CORTEX_M7_NP == 1)
    mcu_printf("Start TCN100x [Network Processor]\n");
#endif

    mcu_printf("Welcome to Telechips Safety Core(SC) BSP\n");
}

/* R0 : ARM Exception ID, R1 : Dummy , R2 : Link Register(Return PC)*/
void BSP_UndefAbortExceptionHook
(
    uint32                              uiExceptId,
    uint32                              uiDummy,
    uint32                              uiLinkReg
)
{
    (void)uiExceptId;
    (void)uiDummy;
    (void)uiLinkReg;
/* Unused function by TCC805X
    SAL_WriteReg(uiExceptId, SRAM_EXCEPTION_SAVE_BASE);
    SAL_WriteReg(uiLinkReg, (SRAM_EXCEPTION_SAVE_BASE+4));
*/
}

/*
Warning !!!  After calliing this function. it will never return from exception except H/W reseting.
This function is designed for very restricted use case such as firmware upgrading.
*/
void BSP_SystemHalt
(
    void
)
{
    (void)SAL_CoreCriticalEnter();  // Interrupt disable(I/F)
    //ARM_Reserved();                 // move ARM p.c on the sram.
}

static void BSP_SystemMpuSetup(void)
{
    MPU_Init();
    MPU_Enable();
}

void BSP_SystemInit(void)
{
    // I/D Cache Disable for system re-configuration
#if ( CORTEX_M7_0 == 1 )
    SCB_DisableDCache();
    SCB_DisableICache();

    /* enable certain faults */
    SCB->SHCSR &= ~(SCB_SHCSR_USGFAULTENA_Msk | SCB_SHCSR_BUSFAULTENA_Msk | SCB_SHCSR_MEMFAULTENA_Msk);

    NVIC_SetPriority(SVC_IRQn, 0x0);
    NVIC_SetPriority(PendSV_IRQn, 0x0);
    NVIC_SetPriority(SysTick_IRQn, 0x0);
    NVIC_SetPriority(DebugMon_IRQn, 0x0);
#endif

#if ( SIC_BSP_SUPPORT_TEST_APP_CPU == 1 )
/* To avoid affected from OS resources */

    // for mcu_print
    SAL_Init_dhrystone();
    CLOCK_Init();
    UART_Init();

    // for dhrystone
    main_dhrystone_1();
#endif

	BSP_SystemMpuSetup();

    // I/D Cache Enable
    SCB_EnableICache();
    SCB_EnableDCache();
    SCB_InvalidateICache();
    SCB_CleanInvalidateDCache();
}

