/*
***************************************************************************************************
*
*   FileName : adc_reg.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#if ( SIC_BSP_SUPPORT_DRIVER_ADC == 1 )

/*
***************************************************************************************************
*                                            GLOBAL DEFINITIONS
***************************************************************************************************
*/
#define ADC_BIT(x)                      (1UL << x)

#define ADC_MODULE_0                    (0U)
#define ADC_CONV_TIMEOUT                (2UL)
#define ADC_ERR_INVALID_MODULE          (-1)

#define ADC_PERI_CLOCK                  (120000000UL)
#define ADC_CLOCK_DIV                   (2UL)
#define ADC_CONV_CYCLE                  (30UL)

#define ADC_DEFAULT_SAMPLE              ADC_BIT(0)
#define ADC_TIMEOUT                     10000

#define ADC_BASE_ADDR                   (SIC_BSP_ADC_BASE)
// Register Offset
#define ADC_SMP_CMD_STS_REG             (0x00U)  //0x00
    #define ADC_00_BIT_DONE             ADC_BIT(31)
    #define ADC_00_MASK_SMP_CMD         (0xFFFUL)
#define ADC_IRQ_DREQ_STS_REG            (0x04U)  //0x04
    #define ADC_BIT_IRQ                 ADC_BIT(0)
    #define ADC_BIT_IRQ_CLR             ADC_BIT(0)
    #define ADC_BIT_IRQ_DMA             ADC_BIT(1)
    #define ADC_BIT_IRQ_DMA_ACK         ADC_BIT(2)
#define ADC_CTRL_CFG_REG                (0x08U)  //0x08
    #define ADC_IRQ_EN                  ADC_BIT(8)
    #define ADC_DMA_IRQ_EN              ADC_BIT(9)
    #define ADC_MASK_ADC_CLK_DIV        (0xFFUL)
#define ADC_TIMEOUT_CFG_REG             (0x0CU)  //0x0C
#define ADC_ICTRL_REG                   (0x10U)  //0x10
#define ADC_TIMING_REG                  (0x40U)  //0x40
#define ADC_SDOUT_REG(x)                (0x80U + (x * 0x4UL))
#define ADC_SDOUT0_REG                  (0x80U)  //0x80
#define ADC_SDOUT1_REG                  (0x84U)  //0x84
#define ADC_SDOUT2_REG                  (0x88U)  //0x88
#define ADC_SDOUT3_REG                  (0x8CU)  //0x8C
#define ADC_SDOUT4_REG                  (0x90U)  //0x90
#define ADC_SDOUT5_REG                  (0x94U)  //0x94
#define ADC_SDOUT6_REG                  (0x98U)  //0x98
#define ADC_SDOUT7_REG                  (0x9CU)  //0x9C
#define ADC_SDOUT8_REG                  (0xA0U)  //0xA0
#define ADC_SDOUT9_REG                  (0xA4U)  //0xA4
#define ADC_SDOUT10_REG                 (0xA8U)  //0xA8
#define ADC_SDOUT11_REG                 (0xACU)  //0xAC

// Bit Control in register
#define ADC_IRQ_EN                      ADC_BIT(8)  // CTRL_CFG, +0x08
#define ADC_DMA_EN                      ADC_BIT(9)  // CTRL_CFG

#define ADC_SDOUT_INIT                  (0xFFFFUL)
#define ADC_STDBIT                      (0x01UL)
#define ADC_CHNNEL_MASK                 (0x1FFUL)

typedef enum ADCChannel
{
    ADC_CHANNEL_0                       = 0,
    ADC_CHANNEL_1                       = 1,
    ADC_CHANNEL_2                       = 2,
    ADC_CHANNEL_3                       = 3,
    ADC_CHANNEL_4                       = 4,
    ADC_CHANNEL_5                       = 5,
    ADC_CHANNEL_6                       = 6,
    ADC_CHANNEL_7                       = 7,
    ADC_CHANNEL_8                       = 8,
    ADC_CHANNEL_9                       = 9,
    ADC_CHANNEL_10                      = 10,
    ADC_CHANNEL_11                      = 11,
    ADC_CHANNEL_MAX                     = 12
} ADCChannel_t;

typedef enum ADCMode
{
    ADC_MODE_NORMAL                     = 0,
    ADC_MODE_IRQ                        = 1,
    ADC_MODE_DMA                        = 2
} ADCMode_t;

void Init_NVIC_Vector_ADC
(
    void
);

void DeInit_NVIC_Vector_ADC
(
    void
);
#endif  // SIC_BSP_ADC_HEADER

