/*
***************************************************************************************************
*
*   FileName : adc.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#if ( SIC_BSP_SUPPORT_DRIVER_ADC == 1 )

/*
***************************************************************************************************
*                                             INCLUDE FILES
***************************************************************************************************
*/

#include <bsp.h>
#include "reg_phys.h"
#include "clock.h"
#include "clock_dev.h"
#include "adc.h"
#include "nvic.h"

/*
***************************************************************************************************
*                                             LOCAL DEFINES
***************************************************************************************************
*/

static uint32 g_cur_sample_mask = 0;

/* Flags */
//#define ADC_DBG_ENABLED
//#define ADC_DMA_ENABLED
//#define ADC_TEST_ENABLED
#define ADC_AUTO_SCAN_ENABLED

/* Defines */

#ifdef ADC_TEST_ENABLED

/* Key definition*/
#define ADC_KEY_NULL                    (0x00)
#define ADC_KEY_1                       (0x01)
#define ADC_KEY_2                       (0x02)
#define ADC_KEY_3                       (0x03)
#define ADC_KEY_4                       (0x04)
#define ADC_KEY_5                       (0x05)
#define ADC_KEY_6                       (0x06)

#define ADC_KEY_ENTER                   (0x11)
#define ADC_KEY_SCAN                    (0x12)
#define ADC_KEY_SETUP                   (0x13)
#define ADC_KEY_MENU                    (0x14)
#define ADC_KEY_DISP                    (0x15)
#define ADC_KEY_TRACKDOWN               (0x16)
#define ADC_KEY_TRACKUP                 (0x17)
#define ADC_KEY_FOLDERDOWN              (0x18)
#define ADC_KEY_FOLDERUP                (0x19)
#define ADC_KEY_POWER                   (0x1a)
#define ADC_KEY_RADIO                   (0x1b)
#define ADC_KEY_MEDIA                   (0x1c)
#define ADC_KEY_PHONE                   (0x1d) //KEY_HANDSFREE
#define ADC_KEY_VOLUMEUP                (0x1e)
#define ADC_KEY_VOLUMEDOWN              (0x1f)

typedef struct ADCButton
{
    uint32                              btLower;
    uint32                              btUpper;
    uint16                              btVkcode;
    uint8                               btName[15];
} ADCButton_t;

typedef struct ADCButtonMap
{
    sint32                              bmSize;
    ADCButton_t *                       bmButton;
} ADCButtonMap_t;

/* Variables */
//uint32 ADCCompltedFlag = 0;   // removed for codesonar warning
#ifdef ADC_DMA_ENABLED
    uint32                              uiDMAData[100];
#endif

static struct ADCButton_t adc_btn_map_00[5] =
{
    /* ADC_CHANNEL_0 */
    {
        0x00,
        0x83,
        ADC_KEY_ENTER,
        "ENTER      "
    },
    {
        0x266,
        0x2EE,
        ADC_KEY_SCAN,
        "SCAN       "
    },
    {
        0x732,
        0x8CC,
        ADC_KEY_SETUP,
        "SETUP      "
    },
    {
        0x9E5,
        0xC18,
        ADC_KEY_MENU,
        "MENU       "
    },
    {
        0xD4A,
        0xFA0,
        ADC_KEY_DISP,
        "DISP       "
    },
};

static struct ADCButton_t adc_btn_map_01[4] =
{
    /* ADC_CHANNEL_1 */
    {
        0x6B,
        0x83,
        ADC_KEY_TRACKDOWN,
        "TRACK DOWN "
    },
    {
        0x732,
        0x8CC,
        ADC_KEY_TRACKUP,
        "TRACK UP   "
    },
    {
        0x9E5,
        0xC18,
        ADC_KEY_FOLDERDOWN,
        "FOLDER DOWN"
    },
    {
        0xD4A,
        0xFA0,
        ADC_KEY_FOLDERUP,
        "FOLDER UP  "
    },
};

static struct ADCButton_t adc_btn_map_02[4] =
{
    /* ADC_CHANNEL_2 */
    {
        0x00,
        0x83,
        ADC_KEY_POWER,
        "POWER      "
    },
    {
        0x732,
        0x8CC,
        ADC_KEY_RADIO,
        "RADIO      "
    },
    {
        0x9E5,
        0xC18,
        ADC_KEY_MEDIA,
        "MEDIA      "
    },
    {
        0xD4A,
        0xFA0,
        ADC_KEY_PHONE,
        "PHONE      "
    },
};

static struct ADCButton_t adc_btn_map_10[5] =
{
    /* ADC_CHANNEL_10 */
    {
        0x6B,
        0x83,
        ADC_KEY_1,
        "KEY1       "
    },
    {
        0x266,
        0x2EE,
        ADC_KEY_2,
        "KEY2       "
    },
    {
        0x52B,
        0x651,
        ADC_KEY_3,
        "KEY3       "
    },
    {
        0x732,
        0x8CC,
        ADC_KEY_4,
        "KEY4       "
    },
    {
        0x9E5,
        0xC18,
        ADC_KEY_5,
        "KEY5       "
    },
    {
        0xD4A,
        0xFA0,
        ADC_KEY_6,
        "KEY6       "
    },
};


struct ADCButtonMap_t adc_btn_map_ptr[12] =
{
    {
        SAL_ArraySize(adc_btn_map_00),
        adc_btn_map_00
    },
    {
        SAL_ArraySize(adc_btn_map_01),
        adc_btn_map_01
    },
    {
        SAL_ArraySize(adc_btn_map_02),
        adc_btn_map_02
    },
    {
        0,
        NULL
    },  // 03
    {
        0,
        NULL
    },  // 04
    {
        0,
        NULL
    },  // 05
    {
        0,
        NULL
    },  // 06
    {
        0,
        NULL
    },  // 07
    {
        0,
        NULL
    },  // 08
    {
        0,
        NULL
    },  // 09
    {
        SAL_ArraySize(adc_btn_map_10),
        adc_btn_map_10
    },
    {
        0,
        NULL
    }   // 11
};
#endif /* ADC_TEST_ENABLED */

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/

#ifdef ADC_DMA_ENABLED
static void ADC_SetDma
(
    void
);
/*
***************************************************************************************************
*                                          ADC_SetDma
*
* @return
*
* Notes
*
***************************************************************************************************
*/

void ADC_SetDma
(
    void
)
{
#if 0
    SAL_WriteReg((SAL_ReadReg(DMA_CONFIG_REG) |= (1 << 0)), DMA_CONFIG_REG);  //DMA Enable
    //  DMA_SREQ_REG |= (1 << 12);
    //  DMA_SYNC_REG |= (1 << 12);
    SAL_WriteReg(0xFFFFFFFF, DMA_HIDDEN_REG);

    //DMA 0 channel
    SAL_WriteReg(0x1B700080, DMA0_SRC_ADDR_REG);    //ADC OUTPUT(0 Channl)
    SAL_WriteReg((uint32)&uiDMAData[0], DMA0_DEST_ADDR_REG);
    SAL_WriteReg((uint32)&uiDMAData[0], DMA0_LLI_REG );
    SAL_WriteReg(((2 << 21) | (2 << 18) | (0 << 15) | (0 << 12) | (100 << 0)), DMA0_CONTROL_REG);           //
    SAL_WriteReg((SAL_ReadReg(DMA0_CONFIG_REG) |= (2 << 11) | (12 << 1) | (1 << 0)), DMA0_CONFIG_REG);      //0 channel of DMA Enable
#endif
}
#endif



/*
***************************************************************************************************
*                                          ADC_Delay
*
* @param    iDelay [in]
*
* Notes
*
***************************************************************************************************
*/

static void ADC_Delay
(
    sint32                              iDelay
)
{
    sint32 i;
    sint32 modi_delay;

    /* wait 1 cycle */
    modi_delay = iDelay * 50;   // 600/12 (CPU_CLOCK/ADC_PERI_CLOCK)

    for (i = 0 ; i < modi_delay ; i++)
    {
        BSP_NOP_DELAY();
    }
}

/*
***************************************************************************************************
*                                          ADC_0_Isr
*
* @param    pArg [in]
*
* Notes
*
***************************************************************************************************
*/

void ADC_0_Isr
(
    void *                              pArg
)
{
    uint32 status;
    uint32 addr = ADC_BASE_ADDR + ADC_IRQ_DREQ_STS_REG;
    (void) pArg;

    // Read IRQ status
    status = SAL_ReadReg(addr);

    if((status & ADC_BIT_IRQ) > 0)
    {
        ADC_D("ADC interrupt\n");
    }
    else if((status & ADC_BIT_IRQ_DMA) > 0)
    {
        ADC_D("ADC DMA interrupt\n");
    }
    else if((status & ADC_BIT_IRQ_DMA_ACK) > 0)
    {
        ADC_D("ADC DMA ACK interrupt\n");
    }
    else
    {
    }

    // Clear interrupt status
    SAL_WriteReg(ADC_BIT_IRQ_CLR, addr);
}

/*
***************************************************************************************************
*                                          ADC_GetAllData
*
*
* @param
*
* @return
*
* Notes
*
***************************************************************************************************
*/

uint32 * ADC_GetAllData
(
    void
)
{
#ifdef ADC_AUTO_SCAN_ENABLED
    uint32 ch;
    uint32 read_data;
    static uint32 adc_scan_val[ADC_CHANNEL_MAX];

    read_data   = 0;

    for (ch = 0 ; ch < (uint32)ADC_CHANNEL_MAX ; ch++)
    {
        read_data           = ADC_GetData(ch);
        adc_scan_val[ch]    = read_data;
        ADC_D("ADC Data[%d] : 0x%x\n", (SAL_ReadReg(ADC_BASE_ADDR + ADC_SDOUT_REG(0)) >> 16) & 0xF ,adc_scan_val[ch]);
    }
    return adc_scan_val;
#else
    ADC_E("Not supported ADC auto scan\n");
    return NULL;
#endif
}




/*
***************************************************************************************************
*                                          ADC_CheckDone
*
*
*
* Notes
*
***************************************************************************************************
*/



// Complete covert?
static boolean ADC_CheckDone
(
    void
)
{
    boolean ret = FALSE;
    uint32 reg = 0;
    uint32 addr = ADC_BASE_ADDR + ADC_SMP_CMD_STS_REG;

    reg = SAL_ReadReg(addr);

    if((reg & ADC_00_BIT_DONE) != 0)
    {
        ret = TRUE;
    }
    else
    {
        ret = FALSE;
    }

    return ret;
}

void ADC_SetSamplingChannel
(
    uint32 sample_mask
)
{
    g_cur_sample_mask = ADC_STDBIT << ((uint32) sample_mask & ADC_00_MASK_SMP_CMD);

}

uint32 ADC_GetData
(
    uint32  ch_idx
)
{
    uint32 reg = 0;
    uint32 ret_data = 0;
    boolean ret = FALSE;
    uint32 timeout_cnt = 0;
    uint32 addr = ADC_BASE_ADDR + ADC_SMP_CMD_STS_REG;

    // Set Sampling channels and Start coverting.
    reg = SAL_ReadReg(addr);
    reg &= ~ADC_00_MASK_SMP_CMD;    // Clear mask

    ADC_SetSamplingChannel(ch_idx);

    if(g_cur_sample_mask == 0)
    {
        reg |= ADC_DEFAULT_SAMPLE;
    }
    else
    {
        reg |= (g_cur_sample_mask & ADC_00_MASK_SMP_CMD); // Set mask
    }

    SAL_WriteReg(reg, addr);

    // Wait covering complete
    reg = 0;

    while(1)
    {
        ret = ADC_CheckDone();
        if(ret == TRUE)
        {
            break;
        }
        else
        {
            timeout_cnt++;
            if(timeout_cnt >= ADC_TIMEOUT)
            {
                ADC_E("ADC data read timeout.\n");
                break;
            }
        }
    }

    if(ret == TRUE)
    {
        reg = 0;
        addr = ADC_BASE_ADDR + ADC_SDOUT_REG(0);

        reg = SAL_ReadReg(addr);
        ret_data = reg & 0xFFFFUL;
    }
    else
    {
        ret_data = 0xFFFFFFFFUL;
        ADC_E("Fail read ADC coverted data.\n");
    }

    return ret_data;
}

void ADC_SetInterruptMode
(
    ADCMode_t   mode
)
{
    uint32 reg = 0;
    uint32 addr = ADC_BASE_ADDR + ADC_CTRL_CFG_REG;

    reg = SAL_ReadReg(addr);

    if(mode == ADC_MODE_IRQ)
    {
        reg |= ADC_IRQ_EN;
    }
    else if (mode == ADC_MODE_DMA)
    {
        reg |= ADC_DMA_IRQ_EN;
    }
    else if (mode == ADC_MODE_NORMAL)
    {
        reg &= ~(ADC_IRQ_EN | ADC_DMA_IRQ_EN);
    }

    SAL_WriteReg(reg, addr);
}

/*
***************************************************************************************************
*                                          ADC_Enable
*
*
*
* @return   SALRetCode_t
*
* Notes
*       ADC Enable = ADC Clock Enable
*
***************************************************************************************************
*/

SALRetCode_t ADC_Enable
(
    void
)
{
    SALRetCode_t ret = SAL_RET_FAILED;
    uint32 clock_div = ADC_CLOCK_DIV;
    uint32 reg = 0;
    uint32 addr = ADC_BASE_ADDR + ADC_CTRL_CFG_REG;
    // Note:
    // ADC Clock rate = ADC Peri_Clock / (2*(clock_div+1))
    // Target rate : 120000000 / (2*(2+1)) = 120000000/6 = 20MHz
    // ADC Sample rate : ADC Clock Rate / 20 = 1MHz

    reg = SAL_ReadReg(addr);
    reg &= ~ADC_MASK_ADC_CLK_DIV;
    reg |= (clock_div & ADC_MASK_ADC_CLK_DIV);
    SAL_WriteReg(reg, addr);

    if (0 == CLOCK_SetPeriRate((sint32)CLOCK_PERI_ADC, ADC_PERI_CLOCK))
    {
        (void)CLOCK_EnablePeri((sint32)CLOCK_PERI_ADC);
        ret = SAL_RET_SUCCESS;
    }
    else
    {
        ADC_E("%s failed to enable adc clock\n", __func__);
        ret = SAL_RET_FAILED;
    }

    return ret;
}

/*
***************************************************************************************************
*                                          ADC_Disable
*
*
*
* @return
*
* Notes
*       ADC Disable = ADC Clock Disable
*
***************************************************************************************************
*/

void ADC_Disable
(
    void
)
{
    (void)CLOCK_DisablePeri((sint32)CLOCK_PERI_ADC);

    return;
}
/*
***************************************************************************************************
*                                          ADC_Init
*
*
* @param    Type [in]
*
* Notes
*
***************************************************************************************************
*/

void ADC_Init
(
    uint8                               Type
)
{
    (void)Init_NVIC_Vector_ADC();
}

/*
***************************************************************************************************
*                                          ADC_DeInit
*
*
* @return
*
* Notes
*
***************************************************************************************************
*/
void ADC_DeInit
(
    void
)
{
    (void)DeInit_NVIC_Vector_ADC();
}

#endif  // ( SIC_BSP_SUPPORT_DRIVER_ADC == 1 )

