/*
***************************************************************************************************
*
*   FileName : adc.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_ADC_HEADER
#define SIC_BSP_ADC_HEADER

#if ( SIC_BSP_SUPPORT_DRIVER_ADC == 1 )

#include <sal_internal.h>
#include <adc_reg.h>

#if (DEBUG_ENABLE)
    #include "debug.h"

    #define ADC_D(fmt,args...)          {LOGD(DBG_TAG_ADC, fmt, ## args)}
    #define ADC_E(fmt,args...)          {LOGE(DBG_TAG_ADC, fmt, ## args)}
#else
    #define ADC_D(fmt,args...)          {}
    #define ADC_E(fmt,args...)          {}
#endif

/*
***************************************************************************************************
*                                            GLOBAL DEFINITIONS
***************************************************************************************************
*/

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/

static void ADC_Delay
(
    sint32                              iDelay
);

void ADC_0_Isr
(
    void *                              pArg
);

/*
***************************************************************************************************
*                                          ADC_GetAllData
*
*
* @param
*
* @return
*
* Notes
*
***************************************************************************************************
*/

uint32 * ADC_GetAllData
(
    void
);

/*
***************************************************************************************************
*                                          ADC_CheckDone
*
*
*
* Notes
*
***************************************************************************************************
*/

static boolean ADC_CheckDone
(
    void
);

/*
***************************************************************************************************
*                                          ADC_SetSamplingChannel
*
* param     sample_mask [in] : ADC Analog channel bit mask
*
* Notes
*
***************************************************************************************************
*/

void ADC_SetSamplingChannel
(
    uint32 sample_mask
);

/*
***************************************************************************************************
*                                          ADC_GetData
*
* param     ch_idx [in] : ADC Analog channel index
*
* Notes
*
***************************************************************************************************
*/

uint32 ADC_GetData
(
    uint32  ch_idx
);

/*
***************************************************************************************************
*                                          ADC_SetInterruptMode
*
* param     mode [in] : ADC interrupt mode
*
* Notes
*
***************************************************************************************************
*/
void ADC_SetInterruptMode
(
    ADCMode_t   mode
);

/*
***************************************************************************************************
*                                          ADC_Enable
*
*
*
* @return   SALRetCode_t
*
* Notes
*       ADC Enable = ADC Clock Enable
*
***************************************************************************************************
*/

SALRetCode_t ADC_Enable
(
    void
);

/*
***************************************************************************************************
*                                          ADC_Disable
*
*
*
* @return
*
* Notes
*       ADC Disable = ADC Clock Disable
*
***************************************************************************************************
*/

void ADC_Disable
(
    void
);

/*
***************************************************************************************************
*                                          ADC_Init
*
*
* @param    Type [in]
*
* Notes
*
***************************************************************************************************
*/

void ADC_Init
(
    uint8                               Type
);

/*
***************************************************************************************************
*                                          ADC_DeInit
*
*
* @return
*
* Notes
*
***************************************************************************************************
*/
void ADC_DeInit
(
    void
);

#endif  // ( SIC_BSP_SUPPORT_DRIVER_ADC == 1 )

#endif  // SIC_BSP_ADC_HEADER
