/****************************************************************************
 *   FileName    : sramecc.c
 *   Description : SRAM ECC en/decoder with SECDED
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips Inc.
 *   All rights reserved

This source code contains confidential information of Telechips.
Any unauthorized use without a written permission of Telechips including not limited to re-
distribution in source or binary form is strictly prohibited.
This source code is provided "AS IS" and nothing contained in this source code shall
constitute any express or implied warranty of any kind, including without limitation, any warranty
of merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
or other third party intellectual property right. No warranty is made, express or implied,
regarding the information's accuracy, completeness, or performance.
In no event shall Telechips be liable for any claim, damages or other liability arising from, out of
or in connection with this source code or the use in the source code.
This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
between Telechips and Company.
*
****************************************************************************/
#if ( SIC_BSP_SUPPORT_DRIVER_FMU )

/*
*********************************************************************************************************
*                                             INCLUDE FILES
*********************************************************************************************************
*/
#include <imc.h>

#include <reg_phys.h>
#include <fmu.h>
#include "sal_com.h"



/*
*********************************************************************************************************
*                                             LOCAL DEFINES
*********************************************************************************************************
*/

#define MC_ECC_CFG_PW               0x8030ACE5U
#define MC_ECC_CFG_WR_PW            0x1B921070U

#define MC_SRAM0_ECC_ERR_REQ_EN     0x1B921000U
#define MC_SRAM0_ECC_ERR_STS        0x1B921004U


#if 0 //not supported SRAM1 on TCC807x
#define MC_SRAM1_ECC_ERR_REQ_EN     0x1B92100CU
#define MC_SRAM1_ECC_ERR_STS        0x1B921010U
#endif



#define MC_IMC_MAX_HANDLERS     10

struct MC_IMC_Handler_Item
{
    IMC_FAULT_HANDLER handler;
    uint8 registered;
};
typedef struct MC_IMC_Handler_Item McIMCHandlerItem_t;

/*
*********************************************************************************************************
*                                            LOCAL VARIABLES
*********************************************************************************************************
*/

static McIMCHandlerItem_t MC_IMC_HandlerTable[MC_IMC_MAX_HANDLERS];

static uint8 gImcHandlerCount = 0;
static boolean gImcEnabled = FALSE;

/*
*********************************************************************************************************
*                                         FUNCTION PROTOTYPES
*********************************************************************************************************
*/
static void mc_imc_sram0_fmu_handler(void * arg);
#if 0 //not supported SRAM1 on TCC807x
static void mc_imc_sram1_fmu_handler(void * arg);
#endif
static int16 mc_imc_get_newID(void);

/*
*********************************************************************************************************
*                                          mc_imc_fmu_handler
*
*
* @param        arg : void *
* @return       None
*
* Notes
*
*********************************************************************************************************
*/
static void mc_imc_sram0_fmu_handler(void * arg)
{
    if (gImcHandlerCount > 0)
    {
        uint16 index = 0;

        for (; index < MC_IMC_MAX_HANDLERS; index++)
        {
            if (MC_IMC_HandlerTable[index].registered == TRUE)
            {
                (*MC_IMC_HandlerTable[index].handler)((uint32)IMC_SRAM0, mc_imc_get_status(index + 1));
            }
        }
    }
#if defined(TCN100x)
    FMU_IsrClr(FMU_ID_IMC0);
#else
    FMU_IsrClr(FMU_ID_IMC_SRAM0_ECC);
#endif
}

#if 0 //not supported SRAM1 on TCC807x
/*
*********************************************************************************************************
*                                          mc_imc_fmu_handler
*
*
* @param        arg : void *
* @return       None
*
* Notes
*
*********************************************************************************************************
*/
static void mc_imc_sram1_fmu_handler(void * arg)
{
    if (gImcHandlerCount > 0)
    {
        uint16 index = 0;

        for (; index < MC_IMC_MAX_HANDLERS; index++)
        {
            if (MC_IMC_HandlerTable[index].registered == TRUE)
            {
                (*MC_IMC_HandlerTable[index].handler)((uint32)IMC_SRAM1, mc_imc_get_status(index + 1));
            }
        }
    }

    tcc_fmu_isr_clr(FMU_ID_SRAM1_ECC);
}
#endif

/*
*********************************************************************************************************
*                                          mc_imc_passwd_config
*
* This interface is first called before  SRAM ECC's configuration is set.
* It will be available to change the status of configuration by writing a predefined password.
*
* @param        None
* @return       0 : Success, -1 : Already enabled, -2 : Fail to set
*
* Notes
*
*********************************************************************************************************
*/
int16 mc_imc_passwd_config(void)
{
    int16 retVal = -1;

    if (SAL_ReadReg(MC_ECC_CFG_WR_PW) != 0x1)
    {
        SAL_WriteReg(MC_ECC_CFG_PW, MC_ECC_CFG_WR_PW);

        /* Unnecessary code(0) in Controller Tester Tool ( Wired )*/
        retVal = (int16)((SAL_ReadReg(MC_ECC_CFG_WR_PW) == 0x1) ? 0 : (-2));
    }

    return retVal;
}

/*
*********************************************************************************************************
*                                          mc_imc_enable_sramecc
*
* Enable ECC encoder / decoder with SECDED to detect the fault of the SRAM memory itself
* when writing or reading data to the SRAM
*
* @param        None
* @return       0 : Success, -1 : Already enabled, -2 : Fail to set
*
* Notes
*
*********************************************************************************************************
*/
int16 mc_imc_enable_sramecc(void)
{
    int16 retVal = -1;

     if(gImcEnabled == FALSE)
    {
        retVal = -2;

#if defined(TCN100x)
        if ((FMU_IsrHandler(FMU_ID_IMC0, FMU_SVL_LOW, mc_imc_sram0_fmu_handler, 0) == SAL_RET_SUCCESS)
            //&& (tcc_fmu_isr_handler(FMU_ID_SRAM1_ECC, FMU_SVL_LOW, mc_imc_sram1_fmu_handler, 0) == SAL_RET_SUCCESS)
            && (FMU_Set(FMU_ID_IMC0) == SAL_RET_SUCCESS))
            //&& (tcc_fmu_set(FMU_ID_SRAM1_ECC) == SAL_RET_SUCCESS))
#else
        if ((FMU_IsrHandler(FMU_ID_IMC_SRAM0_ECC, FMU_SVL_LOW, mc_imc_sram0_fmu_handler, 0) == SAL_RET_SUCCESS)
            //&& (tcc_fmu_isr_handler(FMU_ID_SRAM1_ECC, FMU_SVL_LOW, mc_imc_sram1_fmu_handler, 0) == SAL_RET_SUCCESS)
            && (FMU_Set(FMU_ID_IMC_SRAM0_ECC) == SAL_RET_SUCCESS))
            //&& (tcc_fmu_set(FMU_ID_SRAM1_ECC) == SAL_RET_SUCCESS))
#endif            
        {
            retVal = 0;
        }

        if (retVal != -2)
        {
            if (mc_imc_passwd_config() != -2)
            {
                SAL_WriteReg(0xFFFFFFFFU, MC_SRAM0_ECC_ERR_REQ_EN);
            }
            else
            {
                retVal = -2;
            }
        }


        if (retVal != -2)
        {
            gImcEnabled = TRUE;
        }
    }

    return retVal;
}

/*
*********************************************************************************************************
*                                          mc_imc_disable_sramecc
*
* Disable ECC encoder /  encoder with SECDED
*
* @param        None
* @return       0 : Success, -1 : Already disabled, -2 : Fail to set
*
* Notes
*
*********************************************************************************************************
*/
int16 mc_imc_disable_sramecc(void)
{
    int16 retVal = -1;

    if(gImcEnabled == TRUE)
    {
        retVal = -2;

        if (mc_imc_passwd_config() != -2)
        {
            SAL_WriteReg(0x0, MC_SRAM0_ECC_ERR_REQ_EN);

            retVal = 0;
        }

#if 0 //not supported SRAM1 on TCC807x
        if (retVal != -2)
        {
            if (mc_imc_passwd_config() != -2)
            {
                SAL_WriteReg(0x0, MC_SRAM1_ECC_ERR_REQ_EN);
            }
            else
            {
                retVal = -2;
            }
        }
#endif

        if (retVal != -2)
        {
#if defined(TCN100x)            
            if (FMU_IsrClr(FMU_ID_IMC0) != SAL_RET_SUCCESS)
#else
            if (FMU_IsrClr(FMU_ID_IMC_SRAM0_ECC) != SAL_RET_SUCCESS)
#endif
            {
                retVal = -2;
            }
#if 0 //not supported SRAM1 on TCC807x
            if (tcc_fmu_isr_clr(FMU_ID_SRAM1_ECC) != SAL_RET_SUCCESS)
            {
                retVal = -2;
            }
#endif
        }

        if (retVal != -2)
        {
             gImcEnabled = FALSE;
         }
    }

    return retVal;


}

/*
*********************************************************************************************************
*                                          mc_imc_get_newID
*
* This function is to issue new ID to register a fault handler.
*
* @param        None
* @return       -1 : Fail to issue new ID, 1~10 : Issued ID
*
* Notes
*
*********************************************************************************************************
*/
static int16 mc_imc_get_newID(void)
{
    int16 retId = -1;

    if (gImcHandlerCount < MC_IMC_MAX_HANDLERS)
    {
        int16 index = 0;

        for (; index < MC_IMC_MAX_HANDLERS; index++)
        {
            if (MC_IMC_HandlerTable[index].registered == FALSE)
            {
                retId = index + 1;
                break;
            }
        }
    }

    return retId;
}

/*
*********************************************************************************************************
*                                          mc_imc_register_fault_handler
*
* This interface is to register the handler to inform external controller of error interrupt.
*
* @param        handlerId : 0 when registering the handler for the first time or the previously issued ID(1~10) to update the handler function.
*               faultHandler : handler function pointer
* @return       0 : Success, -1 : Full of register slot
*
* Notes
*
*********************************************************************************************************
*/
int16 mc_imc_register_fault_handler(uint16 handlerId, IMC_FAULT_HANDLER faultHandler)
{
    int16 retId = -1;

    if (gImcHandlerCount < MC_IMC_MAX_HANDLERS)
    {
        if (handlerId == 0)
        {
            retId = mc_imc_get_newID();

            if (retId > 0)
            {
                MC_IMC_HandlerTable[retId - 1].handler = faultHandler;
                MC_IMC_HandlerTable[retId - 1].registered = TRUE;

                gImcHandlerCount++;
            }
        }
        else if (handlerId <= MC_IMC_MAX_HANDLERS)
        {
            MC_IMC_HandlerTable[handlerId- 1].handler = faultHandler;

            if (MC_IMC_HandlerTable[handlerId- 1].registered == FALSE)
            {
                MC_IMC_HandlerTable[handlerId- 1].registered = TRUE;

                gImcHandlerCount++;
            }

            retId = (int16)handlerId;
        }
        else
        {
            retId = -2;
        }
    }

    return retId;

    /* Deprecated because of MISRA 14.7

    int16 retId = -1;

    if (gImcHandlerCount >= MC_IMC_MAX_HANDLERS)
    {
        return retId;
    }

    if (handlerId == 0)
    {
        retId = mc_imc_get_newID();

        if (retId == -1)
        {
            return retId;
        }

        MC_IMC_HandlerTable[retId - 1].handler= faultHandler;
        MC_IMC_HandlerTable[retId - 1].registered = TRUE;

        gImcHandlerCount++;
    }
    else if (handlerId <= MC_IMC_MAX_HANDLERS)
    {
        MC_IMC_HandlerTable[handlerId- 1].handler = faultHandler;

        if (MC_IMC_HandlerTable[handlerId- 1].registered == FALSE)
        {
            MC_IMC_HandlerTable[handlerId- 1].registered = TRUE;

            gImcHandlerCount++;
        }

        retId = (int16)handlerId;
    }
    else
    {
        retId = -2;
    }

    return retId;
    */
}

/*
*********************************************************************************************************
*                                          mc_imc_unregister_fault_handler
*
* This interface is to unregister the handler to inform external controller of error interrupt.
*
* @param        handlerId : the previously issued ID(1~10) to unregister the handler function.
* @return       0 : Success, -1 : Fail to unregister handler
*
* Notes
*
*********************************************************************************************************
*/
int16 mc_imc_unregister_fault_handler(uint16 handlerId)
{
    int16 retVal = -1;

     if ((1 <= handlerId) && (handlerId <= MC_IMC_MAX_HANDLERS))
    {
        MC_IMC_HandlerTable[handlerId- 1].handler = NULL;
        MC_IMC_HandlerTable[handlerId- 1].registered = FALSE;

        gImcHandlerCount--;

        retVal = 0;
    }

    return retVal;
}

/*
*********************************************************************************************************
*                                          mc_mic_get_status
*
* This interface is to return the current status of SRAM ECC
*
* @param        handlerId : Issued ID of fault handler or 0 if the ID hasn't been issued
* @return       Bit [0] : Status of callback function
*                   0 : not registered, 1: registered
*               Bit [1-3] : Reserved
*               Bit [4] : SRAM ECC error request
*                   0 : disabled, 1 : enabled
*               Bit [5-7] : Reserved
*               Bit [8] : status of detection for SRAM0 ECC byte lane 0 error
*                   0 : not detected, 1 : detected
*               Bit [9] : status of detection for SRAM0 ECC byte lane 1 error
*                   0 : not detected, 1 : detected
*               Bit [10] : status of detection for SRAM0 ECC byte lane 2 error
*                   0 : not detected, 1 : detected
*               Bit [11] : status of detection for SRAM0 ECC byte lane 3 error
*                   0 : not detected, 1 : detected
*               Bit [12] : status of detection for SRAM0 ECC byte lane 4 error
*                   0 : not detected, 1 : detected
*               Bit [13] : status of detection for SRAM0 ECC byte lane 5 error
*                   0 : not detected, 1 : detected
*               Bit [14] : status of detection for SRAM0 ECC byte lane 6 error
*                   0 : not detected, 1 : detected
*               Bit [15] : status of detection for SRAM0 ECC byte lane 7 error
*                   0 : not detected, 1 : detected
*               Bit [16] : status of detection for SRAM1 ECC byte lane 0 error
*                   0 : not detected, 1 : detected
*               Bit [17] : status of detection for SRAM1 ECC byte lane 1 error
*                   0 : not detected, 1 : detected
*               Bit [18] : status of detection for SRAM1 ECC byte lane 2 error
*                   0 : not detected, 1 : detected
*               Bit [19] : status of detection for SRAM1 ECC byte lane 3 error
*                   0 : not detected, 1 : detected
*               Bit [20] : status of detection for SRAM1 ECC byte lane 4 error
*                   0 : not detected, 1 : detected
*               Bit [21] : status of detection for SRAM1 ECC byte lane 5 error
*                   0 : not detected, 1 : detected
*               Bit [22] : status of detection for SRAM1 ECC byte lane 6 error
*                   0 : not detected, 1 : detected
*               Bit [23] : status of detection for SRAM1 ECC byte lane 7 error
*                   0 : not detected, 1 : detected
*
* Notes
*
*********************************************************************************************************
*/
uint32 mc_imc_get_status(uint16 handlerId)
{
    uint32 ret = 0;
    uint16 index = 0; 		// for C2143 on VC9.0

    if ((gImcHandlerCount > 0)
        && ((1 <= handlerId) && (handlerId <= MC_IMC_MAX_HANDLERS))
        && (MC_IMC_HandlerTable[handlerId -1].registered == TRUE))
    {
        ret |= SRAM_CB_REGISTERED;
    }

    //uint16 index = 0;		// for C2143 on VC9.0

    for (index = 0; index < 8; index++)
    {
        if (((SAL_ReadReg(MC_SRAM0_ECC_ERR_STS) >> (index << 2)) & 0xF) > 0)
        {
            ret |= SRAM_ECC_ERR_REQ_ENABLED;
            ret |= ((uint32)SRAM_0_LANE0_FAULT << index);
        }
    }

#if 0 //not supported SRAM1 on TCC807x
    for (index = 0; index < 8; index++)
    {
        if (((SAL_ReadReg(MC_SRAM1_ECC_ERR_STS) >> (index << 2)) & 0xF) > 0)
        {
            ret |= SRAM_ECC_ERR_REQ_ENABLED;
            ret |= ((uint32)SRAM_1_LANE0_FAULT << index);
        }
    }
#endif

    return ret;
}

#endif  /* End of SIC_BSP_SUPPORT_DRIVER_FMU */
