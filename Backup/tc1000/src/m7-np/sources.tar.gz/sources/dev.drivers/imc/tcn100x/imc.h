/****************************************************************************
 *   FileName    : sramecc.h
 *   Description : SRAM ECC en/decoder with SECDED
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips Inc.
 *   All rights reserved

This source code contains confidential information of Telechips.
Any unauthorized use without a written permission of Telechips including not limited to re-
distribution in source or binary form is strictly prohibited.
This source code is provided "AS IS" and nothing contained in this source code shall
constitute any express or implied warranty of any kind, including without limitation, any warranty
of merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
or other third party intellectual property right. No warranty is made, express or implied,
regarding the information's accuracy, completeness, or performance.
In no event shall Telechips be liable for any claim, damages or other liability arising from, out of
or in connection with this source code or the use in the source code.
This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
between Telechips and Company.
*
****************************************************************************/

/*
*********************************************************************************************************
*                                                 MODULE
*
* Note(s) : (1) This header file is protected from multiple pre-processor inclusion through use of the
*               GLOBALS present pre-processor macro definition.
*********************************************************************************************************
*/

#ifndef  _SRAMECC_H_
#define  _SRAMECC_H_

#if ( SIC_BSP_SUPPORT_DRIVER_FMU )

#include <sal_internal.h>
#include <bsp.h>


/*
*********************************************************************************************************
*                                            GLOBAL DEFINITIONS
*********************************************************************************************************
*/

typedef  void (*IMC_FAULT_HANDLER)(uint32, uint32);

typedef enum
{
    IMC_SRAM0 = 0,
    IMC_SRAM1 = 1,
    IMC_TYPE_SIZE = 2
} IMC_Type_ID;

typedef enum
{
    SRAM_CB_REGISTERED          = 0x000001U,
//  Reserved [1-3]
    SRAM_ECC_ERR_REQ_ENABLED    = 0x000010U,
//  Reserved [5-7]
    SRAM_0_LANE0_FAULT          = 0x000100U,
    SRAM_0_LANE1_FAULT          = 0x000200U,
    SRAM_0_LANE2_FAULT          = 0x000400U,
    SRAM_0_LANE3_FAULT          = 0x000800U,
    SRAM_0_LANE4_FAULT          = 0x001000U,
    SRAM_0_LANE5_FAULT          = 0x002000U,
    SRAM_0_LANE6_FAULT          = 0x004000U,
    SRAM_0_LANE7_FAULT          = 0x008000U,
    SRAM_1_LANE0_FAULT          = 0x010000U,
    SRAM_1_LANE1_FAULT          = 0x020000U,
    SRAM_1_LANE2_FAULT          = 0x040000U,
    SRAM_1_LANE3_FAULT          = 0x080000U,
    SRAM_1_LANE4_FAULT          = 0x100000U,
    SRAM_1_LANE5_FAULT          = 0x200000U,
    SRAM_1_LANE6_FAULT          = 0x400000U,
    SRAM_1_LANE7_FAULT          = 0x800000U
} SRAM_Status_Type;

/*
*********************************************************************************************************
*                                         MODULE INTERFACES
*********************************************************************************************************
*/

int16 mc_imc_passwd_config(void);

int16 mc_imc_enable_sramecc(void);
int16 mc_imc_disable_sramecc(void);

int16 mc_imc_register_fault_handler(uint16 handlerId, IMC_FAULT_HANDLER faultHandler);
int16 mc_imc_unregister_fault_handler(uint16 handlerId);

uint32 mc_imc_get_status(uint16 handlerId);

#endif  /* End of SIC_BSP_SUPPORT_DRIVER_FMU */

#endif //_SRAMECC_H_
