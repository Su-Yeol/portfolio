/*
***************************************************************************************************
*
*   FileName : pmu_rst.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_PMU_RST_HEADER
#define SIC_BSP_PMU_RST_HEADER

#include <sal_internal.h>
#include "reg_phys.h"

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/
#define PMU_REG_SSS_DP_RSTN_MSK             (SIC_BSP_PMU_BASE + 0x8UL)
#define PMU_REG_PMU_USSTATUS                (SIC_BSP_PMU_BASE + 0x1CUL)
#define PMU_REG_WDTRST_EN                   (SIC_BSP_PMU_BASE + 0xBCUL)
#define PMU_REG_WDTRST_MASK_TOP             (SIC_BSP_PMU_BASE + 0x130UL)
#define PMU_REG_PMU_CRST                    (SIC_BSP_PMU_BASE + 0x17CUL)
#define PMU_REG_PMU_AP_WRST                 (SIC_BSP_PMU_BASE + 0x180UL)
#define PMU_REG_PMU_WRST                    (SIC_BSP_PMU_BASE + 0x184UL)
#define PMU_REG_CAM_SDM_TRVC_RSTN_MSK       (SIC_BSP_PMU_BASE + 0x1F8UL)
#define PMU_REG_PMU_SWRSTN                  (SIC_BSP_PMU_BASE + 0x1FCUL)
#define PMU_REG_CPU_READY                   (SIC_BSP_PMU_BASE + 0x200UL)
    #define PMU_CPU_READY_FLD_SIC_READY     (0xFFFFUL << 16UL)
    #define PMU_CPU_READY_FLD_SC_READY      (0x1UL << 1UL)
    #define PMU_CPU_READY_FLD_SSS_READY     (0x1UL << 0UL)


typedef enum
{
    PMU_RST_ASSERT                        = (0x0UL),
    PMU_RST_RELEASE                       = (0x1UL),
    PMU_RST_ASSERT_AND_RELEASE            = (0x2UL)
}PmuRstAssert_t;

typedef enum
{
    PMU_RST_ALLOW                       = (0x0UL),
    PMU_RST_IGNORE                      = (0x1UL)
}PmuRstAllow_t;

typedef enum
{
    PMU_NOT_READY                       = (0x0UL),
    PMU_READY                           = (0x1UL)
}PmuReady_t;

typedef enum
{
    PMU_SSSRST_BY_SRC_ANY_WDT               = (1UL << 2UL) ,
    PMU_SSSRST_BY_SRC_WARM                  = (1UL << 3UL) ,
    PMU_SSSRST_BY_SRC_AP_WARM               = (1UL << 4UL) ,
    PMU_SSSRST_BY_SRC_PVT                   = (1UL << 5UL) ,
    PMU_SSSRST_BY_SRC_HSM_WDT0              = (1UL << 6UL) ,
    PMU_SSSRST_BY_SRC_HSM_WDT1              = (1UL << 7UL) ,
    PMU_SSSRST_BY_SRC_HSM                   = (1UL << 8UL) ,
    PMU_SSSRST_BY_SRC_SSS_SW                = (1UL << 9UL) ,
    PMU_SSSRST_BY_SRC_COLD                  = (1UL << 10UL),

    PMU_SSSRST_BY_SRC_ALL                   = ((1UL << 2UL) |
                                              (1UL << 3UL) |
                                              (1UL << 4UL) |
                                              (1UL << 5UL) |
                                              (1UL << 6UL) |
                                              (1UL << 7UL) |
                                              (1UL << 8UL) |
                                              (1UL << 9UL) |
                                              (1UL << 10UL)),

    PMU_DPRST_BY_SRC_ANY_WDT                = (1UL << 13UL),
    PMU_DPRST_BY_SRC_WARM                   = (1UL << 14UL),
    PMU_DPRST_BY_SRC_AP_WARM                = (1UL << 15UL),
    PMU_DPRST_BY_SRC_PVT                    = (1UL << 16UL),
    PMU_DPRST_BY_SRC_DP_SW                  = (1UL << 17UL),
    PMU_DPRST_BY_SRC_COLD                   = (1UL << 18UL),

    PMU_DPRST_BY_SRC_ALL                    = ((1UL << 13UL)|
                                              (1UL << 14UL)|
                                              (1UL << 15UL)|
                                              (1UL << 16UL)|
                                              (1UL << 17UL)|
                                              (1UL << 18UL))
}PmuSssDpRst_t;


typedef enum
{
    PMU_WDTRST_BY_SRC_SICSSWDT              = (0x1UL << 7UL),
    PMU_WDTRST_BY_SRC_HSMWDT0               = (0x1UL << 12UL),
    PMU_WDTRST_BY_SRC_HSMWDT1               = (0x1UL << 13UL),
    PMU_WDTRST_BY_SRC_SWDT                  = (0x1UL << 14UL),
    PMU_WDTRST_BY_SRC_HSM                   = (0x1UL << 15UL),

    PMU_WDTRST_BY_SRC_ALL                   = (
                                                (0x1UL << 7UL)|
                                                (0x1UL << 12UL)|
                                                (0x1UL << 13UL)|
                                                (0x1UL << 14UL)|
                                                (0x1UL << 15UL)
                                              )
}PmuWdtRst_t;


typedef enum
{
    PMU_TOPRST_BY_SRC_CPUSSWDT0             = (0x1UL << 0UL),
    PMU_TOPRST_BY_SRC_CPUSSWDT1             = (0x1UL << 1UL),
    PMU_TOPRST_BY_SRC_CPUSSWDT2             = (0x1UL << 2UL),
    PMU_TOPRST_BY_SRC_CPUSSWDT3             = (0x1UL << 3UL),
    PMU_TOPRST_BY_SRC_CPUSSWDT4             = (0x1UL << 4UL),

    PMU_TOPRST_BY_SRC_PMUWDT                = (0x1UL << 6UL),
    PMU_TOPRST_BY_SRC_SICSSWDT              = (0x1UL << 7UL),
    PMU_TOPRST_BY_SRC_CPUSSWDT5             = (0x1UL << 8UL),
    PMU_TOPRST_BY_SRC_CPUSSWDT6             = (0x1UL << 9UL),
    PMU_TOPRST_BY_SRC_CPUSSWDT7             = (0x1UL << 10UL),
    PMU_TOPRST_BY_SRC_SCSSWDT               = (0x1UL << 11UL),
    PMU_TOPRST_BY_SRC_HSMWDT0               = (0x1UL << 12UL),
    PMU_TOPRST_BY_SRC_HSMWDT1               = (0x1UL << 13UL),
    PMU_TOPRST_BY_SRC_SFWDT                 = (0x1UL << 14UL),

    PMU_TOPRST_BY_SRC_ALL                   = ((0x1UL << 0UL)|
                                               (0x1UL << 1UL)|
                                               (0x1UL << 2UL)|
                                               (0x1UL << 3UL)|
                                               (0x1UL << 4UL)|
                                               (0x1UL << 6UL)|
                                               (0x1UL << 7UL)|
                                               (0x1UL << 8UL)|
                                               (0x1UL << 9UL)|
                                               (0x1UL << 10UL)|
                                               (0x1UL << 11UL)|
                                               (0x1UL << 12UL)|
                                               (0x1UL << 13UL)|
                                               (0x1UL << 14UL))
}PmuTopRst_t;

typedef enum
{
    PMU_TRVCRST_BY_SRC_ANY_WDT              = (1UL << 26UL),
    PMU_TRVCRST_BY_SRC_WARM                 = (1UL << 27UL),
    PMU_TRVCRST_BY_SRC_AP_WARM              = (1UL << 28UL),
    PMU_TRVCRST_BY_SRC_PVT                  = (1UL << 29UL),
    PMU_TRVCRST_BY_SRC_SSS                  = (1UL << 30UL),
    PMU_TRVCRST_BY_SRC_COLD                 = (1UL << 31UL),

    PMU_TRVCRST_BY_SRC_ALL                  = (
                                               (1UL << 26UL)|
                                               (1UL << 27UL)|
                                               (1UL << 28UL)|
                                               (1UL << 29UL)|
                                               (1UL << 30UL)|
                                               (1UL << 31UL)
                                             ),

    PMU_SDMRST_BY_SRC_ANY_WDT               = (1UL << 18UL),
    PMU_SDMRST_BY_SRC_WARM                  = (1UL << 19UL),
    PMU_SDMRST_BY_SRC_AP_WARM               = (1UL << 20UL),
    PMU_SDMRST_BY_SRC_PVT                   = (1UL << 21UL),
    PMU_SDMRST_BY_SRC_SSS                   = (1UL << 22UL),
    PMU_SDMRST_BY_SRC_COLD                  = (1UL << 23UL),

    PMU_SDMRST_BY_SRC_ALL                   = (
                                               (1UL << 18UL)|
                                               (1UL << 19UL)|
                                               (1UL << 20UL)|
                                               (1UL << 21UL)|
                                               (1UL << 22UL)|
                                               (1UL << 23UL)
                                             ),

    PMU_CAMRST_BY_SRC_ANY_WDT               = (1UL << 10UL),
    PMU_CAMRST_BY_SRC_WARM                  = (1UL << 11UL),
    PMU_CAMRST_BY_SRC_AP_WARM               = (1UL << 12UL),
    PMU_CAMRST_BY_SRC_PVT                   = (1UL << 13UL),
    PMU_CAMRST_BY_SRC_SSS                   = (1UL << 14UL),
    PMU_CAMRST_BY_SRC_COLD                  = (1UL << 15UL),

    PMU_CAMRST_BY_SRC_ALL                   = (
                                               (1UL << 10UL)|
                                               (1UL << 11UL)|
                                               (1UL << 12UL)|
                                               (1UL << 13UL)|
                                               (1UL << 14UL)|
                                               (1UL << 15UL)
                                             )
}PmuCamSdmTrvcRst_t;

typedef enum
{
    PMU_SWRST_CAM                           = (1UL << 1UL),
    PMU_SWRST_TRVC                          = (1UL << 2UL),
    PMU_SWRST_DP                            = (1UL << 3UL),
    PMU_SWRST_SSS                           = (1UL << 4UL),
    PMU_SWRST_SDM                           = (1UL << 16UL)
}PmuSwRst_t;

typedef enum
{
    PMU_RET_RST_NONE                        = 0UL,

    //RST_STS0
    PMU_RET_RST_CPUSSWDT0                   = ( (0x164UL<<16UL) | 0UL  ),
    PMU_RET_RST_CPUSSWDT1                   = ( (0x164UL<<16UL) | 8UL  ),
    PMU_RET_RST_CPUSSWDT2                   = ( (0x164UL<<16UL) | 16UL ),
    PMU_RET_RST_CPUSSWDT3                   = ( (0x164UL<<16UL) | 24UL ),

    //RST_STS1
    PMU_RET_RST_CPUSSWDT4                   = ( (0x168UL<<16UL) | 0UL  ),
    PMU_RET_RST_SICWDT                      = ( (0x168UL<<16UL) | 16UL ),
    PMU_RET_RST_PMUWDT                      = ( (0x168UL<<16UL) | 24UL ),

    //RST_STS2
    PMU_RET_RST_PMU                         = ( (0x16CUL<<16UL) | 0UL  ),
    PMU_RET_RST_WARM                        = ( (0x16CUL<<16UL) | 8UL  ),
    PMU_RET_RST_COLD                        = ( (0x16CUL<<16UL) | 16UL ),
    PMU_RET_RST_GLOBAL                      = ( (0x16CUL<<16UL) | 24UL ),

    //RST_STS3
    PMU_RET_RST_XINPVT                      = ( (0x170UL<<16UL) | 0UL  ),
    PMU_RET_RST_OTPPVT                      = ( (0x170UL<<16UL) | 8UL  ),
    PMU_RET_RST_COREPVT                     = ( (0x170UL<<16UL) | 16UL ),
    PMU_RET_RST_SICWARM                     = ( (0x170UL<<16UL) | 24UL ),

    //RST_STS4
    PMU_RET_RST_CPUSSWDT6                   = ( (0x240UL<<16UL) | 0UL  ),
    PMU_RET_RST_CPUSSWDT7                   = ( (0x240UL<<16UL) | 8UL  ),
    PMU_RET_RST_SUBCLUSTERWDT               = ( (0x240UL<<16UL) | 16UL ),
    PMU_RET_RST_MAINCLUSTERWDT              = ( (0x240UL<<16UL) | 24UL ),

    //RST_STS5
    PMU_RET_RST_TOP                         = ( (0x244UL<<16UL) | 0UL  ),

    //RST_STS6
    PMU_RET_RST_SCSSWDT                     = ( (0x248UL<<16UL) | 0UL  ),
    PMU_RET_RST_HSMREQ                      = ( (0x248UL<<16UL) | 8UL  ),
    PMU_RET_RST_HSMWDT0                     = ( (0x248UL<<16UL) | 16UL ),
    PMU_RET_RST_HSMWDT1                     = ( (0x248UL<<16UL) | 24UL ),

    //RST_STS7
    PMU_RET_RST_SFWDT                       = ( (0x28CUL<<16UL) | 0UL  )
}PmuRetRst_t;

#define PMU_RET_RST_NUM                     25UL

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/
PmuRetRst_t PMU_GetRstReason
(
    void
);

uint32  PMU_GetUsrStatus
(
    void
);

PmuReady_t PMU_IsSicReady
(
    void
);

PmuReady_t PMU_IsScReady
(
    void
);

PmuReady_t PMU_IsSssReady
(
    void
);


void PMU_SssDpRstMask
(
    PmuRstAllow_t       tAllow,
    PmuSssDpRst_t       tSrcRst
);

void PMU_WdtRstMask
(
    PmuRstAllow_t       tAllow,
    PmuWdtRst_t         tSrcRst
);

void PMU_TopRstMask
(
    PmuRstAllow_t       tAllow,
    PmuTopRst_t         tSrcRst
);

void PMU_CamSdmTrvcRstMask
(
    PmuRstAllow_t       tAllow,
    PmuCamSdmTrvcRst_t  tSrcRst
);

void PMU_ColdReset
(
    void
);

void PMU_WarmReset
(
    void
);

void PMU_ApWarmReset
(
    void
);

void PMU_SwReset
(
    PmuRstAssert_t tAssRel,
    PmuSwRst_t  tSrcRst
);
#endif /* __SIC_BSP_PMU_RST_HEADER__ */

