/*
***************************************************************************************************
*
*   FileName : pmu.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include "pmu_io.h"
#include "pmu_acc.h"

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/

/***************************************************************************************************
*                                             LOCAL VARIABLES
***************************************************************************************************/
/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/

///////////////// GPIO Control
void PMU_IOCtrl
(
    PmuGpioSel_t        tPortSel,
    uint32              uiPortNum,
    PmuGpioCtrl_t       tPortCtrl
)
{
    uint32 uiVa;
    uint32 uiPortGrp;

    uiPortGrp = (uint32)tPortSel;

    uiVa = SAL_ReadReg(SIC_BSP_PMU_BASE + uiPortGrp);

    if(tPortCtrl == PMU_GPIO_CTRL_SIC)
    {
        uiVa &= ~(0x1UL<<uiPortNum);
    }
    else
    {
        uiVa |= (0x1UL<<uiPortNum);
    }

    PMU_WriteOpen();

    SAL_WriteReg(uiVa, (SIC_BSP_PMU_BASE + uiPortGrp));

    PMU_WriteClose();
}

void PMU_IORetMode
(
    uint32              uiSet
)
{
    PMU_WriteOpen();

    if(uiSet == 0UL)
    {
        SAL_WriteReg(0x1UL, PMU_REG_TOP_PWRCTRL);
    }
    else
    {
        SAL_WriteReg(0x0UL, PMU_REG_TOP_PWRCTRL);
    }

    PMU_WriteClose();
}

//////////////////////////////
