/*
***************************************************************************************************
*
*   FileName : pmu_io.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_PMU_IO_HEADER
#define SIC_BSP_PMU_IO_HEADER

#include <sal_internal.h>
#include "reg_phys.h"

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/
#define PMU_REG_TOP_PWRCTRL                 (SIC_BSP_PMU_BASE + 0x60UL)

#if defined (TCC807x)
typedef enum
{
    PMU_GPIO_SEL_MA                         = (0x160UL),
    PMU_GPIO_SEL_MB                         = (0xA8UL),
    PMU_GPIO_SEL_MC                         = (0xACUL),
    PMU_GPIO_SEL_MD                         = (0xB0UL),
    PMU_GPIO_SEL_H                          = (0x15CUL),
    PMU_GPIO_SEL_K                          = (0x280UL)
}PmuGpioSel_t;

#elif defined (TCC750x)
typedef enum
{
    PMU_GPIO_SEL_MA                         = (0x160UL),
    PMU_GPIO_SEL_MB                         = (0xA8UL),
    PMU_GPIO_SEL_MC                         = (0xACUL),
    PMU_GPIO_SEL_MD                         = (0xB0UL),
    PMU_GPIO_SEL_A                          = (0x148UL),
    PMU_GPIO_SEL_B                          = (0x14CUL),
    PMU_GPIO_SEL_C                          = (0x150UL),
    PMU_GPIO_SEL_D                          = (0x154UL),
    PMU_GPIO_SEL_G                          = (0x158UL),
    PMU_GPIO_SEL_H                          = (0x15CUL),
    PMU_GPIO_SEL_K                          = (0x280UL)
}PmuGpioSel_t;
#endif


typedef enum
{
    PMU_GPIO_CTRL_SIC                       = (0UL),
    PMU_GPIO_CTRL_AP                        = (1UL)
}PmuGpioCtrl_t;

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/
void PMU_IOCtrl
(
    PmuGpioSel_t        tPortSel,
    uint32              uiPortNum,
    PmuGpioCtrl_t       tPortCtrl
);

void PMU_IORetMode
(
    uint32              uiSet
);
#endif /* __SIC_BSP_PMU_IO_HEADER__ */

