/*
***************************************************************************************************
*
*   FileName : pmu_rst.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include "pmu_rst.h"
#include "pmu_acc.h"

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/


/***************************************************************************************************
*                                             LOCAL VARIABLES
***************************************************************************************************/
/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/


PmuRetRst_t PMU_GetRstReason
(
    void
)
{
    PmuRetRst_t tRstStsList[PMU_RET_RST_NUM] =
    {
        //RST_STS0
        PMU_RET_RST_CPUSSWDT0     ,
        PMU_RET_RST_CPUSSWDT1     ,
        PMU_RET_RST_CPUSSWDT2     ,
        PMU_RET_RST_CPUSSWDT3     ,

        //RST_STS1
        PMU_RET_RST_CPUSSWDT4     ,
        PMU_RET_RST_SICWDT        ,
        PMU_RET_RST_PMUWDT        ,

        //RST_STS2
        PMU_RET_RST_PMU           ,
        PMU_RET_RST_WARM          ,
        PMU_RET_RST_COLD          ,
        PMU_RET_RST_GLOBAL        ,

        //RST_STS3
        PMU_RET_RST_XINPVT        ,
        PMU_RET_RST_OTPPVT        ,
        PMU_RET_RST_COREPVT       ,
        PMU_RET_RST_SICWARM       ,

        //RST_STS4
        PMU_RET_RST_CPUSSWDT6     ,
        PMU_RET_RST_CPUSSWDT7     ,
        PMU_RET_RST_SUBCLUSTERWDT ,
        PMU_RET_RST_MAINCLUSTERWDT,

        //RST_STS5
        PMU_RET_RST_TOP           ,

        //RST_STS6
        PMU_RET_RST_SCSSWDT       ,
        PMU_RET_RST_HSMREQ        ,
        PMU_RET_RST_HSMWDT0       ,
        PMU_RET_RST_HSMWDT1       ,

        //RST_STS7
        PMU_RET_RST_SFWDT
    };

    PmuRetRst_t tRet;
    uint8 ucIsRstOccure = 0U;
    uint32 uiIdx;
    uint32 uiVa;
    uint32 uiOffset;
    uint32 uiFld;

    for(uiIdx = 0UL ; uiIdx < PMU_RET_RST_NUM ; uiIdx++)
    {
        uiVa        = (uint32)(tRstStsList[uiIdx]);
        uiOffset    = ((uiVa) >> 16UL) & 0xFFFFUL;
        uiFld       = uiVa & 0xFFUL;

        uiVa = (uint32)(SAL_ReadReg(SIC_BSP_PMU_BASE + uiOffset));

        /*Check 0x00 unsupport field. */
        if((uiVa & (0xFFUL << uiFld)) != 0UL)
        {
            /*Check 0xF0 reset field. */
            if((uiVa & (0xF0UL<<uiFld)) == 0UL)
            {
                tRet = tRstStsList[uiIdx];
            }
            /*Check 0xFF reset occurs state*/
            else
            {
                ucIsRstOccure = 1U;
            }
        }
    }

    /*Check no reset*/
    if(ucIsRstOccure == 0U)
    {
        tRet = PMU_RET_RST_NONE;
    }

    return tRet;
}

uint32 PMU_GetUsrStatus
(
    void
)
{
    return SAL_ReadReg(PMU_REG_PMU_USSTATUS);
}

PmuReady_t PMU_IsSicReady
(
    void
)
{
    PmuReady_t tReady;

    tReady = PMU_NOT_READY;

    if((SAL_ReadReg(PMU_REG_CPU_READY) & PMU_CPU_READY_FLD_SIC_READY) > 0UL)
    {
        tReady = PMU_READY;
    }
    return tReady;
}

PmuReady_t PMU_IsScReady
(
    void
)
{
    PmuReady_t tReady;

    tReady = PMU_NOT_READY;

    if((SAL_ReadReg(PMU_REG_CPU_READY) & PMU_CPU_READY_FLD_SC_READY) > 0UL)
    {
        tReady = PMU_READY;
    }
    return tReady;
}

PmuReady_t PMU_IsSssReady
(
    void
)
{
    PmuReady_t tReady;

    tReady = PMU_NOT_READY;

    if((SAL_ReadReg(PMU_REG_CPU_READY) & PMU_CPU_READY_FLD_SSS_READY) > 0UL)
    {
        tReady = PMU_READY;
    }
    return tReady;
}

/////////////////// Reset Control
void PMU_SssDpRstMask
(
    PmuRstAllow_t       tAllow,
    PmuSssDpRst_t       tSrcRst
)
{
    uint32 uiVa;
    uint32 uiSrcRst;

    uiSrcRst = (uint32)tSrcRst;

    uiVa = SAL_ReadReg(PMU_REG_SSS_DP_RSTN_MSK);

    if(tAllow == PMU_RST_ALLOW)
    {
        uiVa &= (~uiSrcRst);
    }
    else
    {
        uiVa |= (uiSrcRst);
    }

    PMU_WriteOpen();
    PMU_WexSicAccess(PMU_WEX_ACC_ALL);

    SAL_WriteReg(uiVa, PMU_REG_SSS_DP_RSTN_MSK);

    //PMU_WriteClose();
}

void PMU_WdtRstMask
(
    PmuRstAllow_t       tAllow,
    PmuWdtRst_t         tSrcRst
)
{
    uint32 uiVa;
    uint32 uiSrcRst;

    uiSrcRst = (uint32)tSrcRst;

    uiVa = SAL_ReadReg(PMU_REG_WDTRST_EN);

    if(tAllow == PMU_RST_ALLOW)
    {
        uiVa |= (uiSrcRst);
    }
    else
    {
        uiVa &= (~uiSrcRst);
    }

    PMU_WriteOpen();

    SAL_WriteReg(uiVa, PMU_REG_WDTRST_EN);

    //PMU_WriteClose();
}

void PMU_TopRstMask
(
    PmuRstAllow_t       tAllow,
    PmuTopRst_t         tSrcRst
)
{
    uint32 uiVa;
    uint32 uiSrcRst;

    uiSrcRst = (uint32)tSrcRst;

    uiVa = SAL_ReadReg(PMU_REG_WDTRST_MASK_TOP);

    if(tAllow == PMU_RST_ALLOW)
    {
        uiVa &= (~uiSrcRst);
    }
    else
    {
        uiVa |= (uiSrcRst);
    }

    PMU_WriteOpen();
    PMU_WexSicAccess(PMU_WEX_ACC_ALL);

    SAL_WriteReg(uiVa, PMU_REG_WDTRST_MASK_TOP);

    //PMU_WriteClose();
}

void PMU_CamSdmTrvcRstMask
(
    PmuRstAllow_t       tAllow,
    PmuCamSdmTrvcRst_t  tSrcRst
)
{
    uint32 uiVa;
    uint32 uiSrcRst;

    uiSrcRst = (uint32)tSrcRst;

    uiVa = SAL_ReadReg(PMU_REG_CAM_SDM_TRVC_RSTN_MSK);

    if(tAllow == PMU_RST_ALLOW)
    {
        uiVa &= (~uiSrcRst);
    }
    else
    {
        uiVa |= (uiSrcRst);
    }

    PMU_WriteOpen();
    PMU_WexSicAccess(PMU_WEX_ACC_ALL);

    SAL_WriteReg(uiVa, PMU_REG_CAM_SDM_TRVC_RSTN_MSK);

    //PMU_WriteClose();
}

void PMU_ColdReset
(
    void
)
{
    PMU_WriteOpen();
    PMU_WexSicAccess(PMU_WEX_ACC_ALL);

    SAL_WriteReg(0x1UL, PMU_REG_PMU_CRST);

    //PMU_WriteClose();
}

void PMU_WarmReset
(
    void
)
{
    PMU_WriteOpen();
    PMU_WexSicAccess(PMU_WEX_ACC_ALL);

    SAL_WriteReg(0x1UL, PMU_REG_PMU_WRST);

    //PMU_WriteClose();
}

void PMU_ApWarmReset
(
    void
)
{
    PMU_WriteOpen();
    PMU_WexSicAccess(PMU_WEX_ACC_ALL);

    SAL_WriteReg(0x1UL, PMU_REG_PMU_AP_WRST);

    //PMU_WriteClose();
}

void PMU_SwReset
(
    PmuRstAssert_t tAssRel,
    PmuSwRst_t  tSrcRst
)
{
    uint32 uiVa;
    uint32 uiSrcRst;

    uiSrcRst = (uint32)tSrcRst;

    uiVa = SAL_ReadReg(PMU_REG_PMU_SWRSTN);

    if((tAssRel == PMU_RST_ASSERT) || (tAssRel == PMU_RST_ASSERT_AND_RELEASE))
    {
        uiVa &= (~uiSrcRst);

        PMU_WriteOpen();
        PMU_WexSicAccess(PMU_WEX_ACC_ALL);

        SAL_WriteReg(uiVa, PMU_REG_PMU_SWRSTN);

        //PMU_WriteClose();
    }

    if((tAssRel == PMU_RST_RELEASE) || (tAssRel == PMU_RST_ASSERT_AND_RELEASE))
    {
        uiVa |= (uiSrcRst);

        PMU_WriteOpen();
        PMU_WexSicAccess(PMU_WEX_ACC_ALL);

        SAL_WriteReg(uiVa, PMU_REG_PMU_SWRSTN);

        //PMU_WriteClose();
    }
}
/////////////////////////////////////////////////////////////////
