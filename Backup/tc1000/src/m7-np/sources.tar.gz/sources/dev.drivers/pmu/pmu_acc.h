/*
***************************************************************************************************
*
*   FileName : pmu_acc.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_PMU_ACC_HEADER
#define SIC_BSP_PMU_ACC_HEADER

#include <sal_internal.h>
#include "reg_phys.h"

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/
#define PMU_REG_SIC_DIRWR_CODE               (SIC_BSP_PMU_BASE + 0x1ACUL)
#define PMU_REG_SIC_DIRWR_EN                 (SIC_BSP_PMU_BASE + 0x1B0UL)
#define PMU_REG_PMU_ACCESS_CTRL              (SIC_BSP_PMU_BASE + 0x254UL)


#define PMU_DIRWR_CODE                      (0x5AFEACE5UL)

typedef enum
{
    PMU_WEX_ACC_NONE                        = (0x0UL),

    PMU_WEX_ACC_WDTRST                      = (0x1UL << 8UL),
    PMU_WEX_ACC_SDM                         = (0x1UL << 6UL),
    PMU_WEX_ACC_TRVC                        = (0x1UL << 5UL),
    PMU_WEX_ACC_CAM                         = (0x1UL << 3UL),
    PMU_WEX_ACC_SSS                         = (0x1UL << 2UL),
    PMU_WEX_ACC_DP                          = (0x1UL << 1UL),
    PMU_WEX_ACC_REMAP                       = (0x1UL << 0UL),

    PMU_WEX_ACC_ALL                         = (
                                               (0x1UL << 8UL)|
                                               (0x1UL << 6UL)|
                                               (0x1UL << 5UL)|
                                               (0x1UL << 3UL)|
                                               (0x1UL << 2UL)|
                                               (0x1UL << 1UL)|
                                               (0x1UL << 0UL)
                                              )
}PMUWexAcc_t;

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/
void PMU_WriteOpen
(
    void
);

void PMU_WriteClose
(
    void
);

void PMU_WexSicAccess
(
    PMUWexAcc_t tAcc
);

#endif /* __SIC_BSP_PMU_ACC_HEADER__ */

