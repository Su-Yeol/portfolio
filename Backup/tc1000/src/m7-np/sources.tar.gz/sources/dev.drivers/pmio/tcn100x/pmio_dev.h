/*
***************************************************************************************************
*
*   FileName : pmio_dev.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef  MCU_BSP_PMIO_DEV_HEADER
#define  MCU_BSP_PMIO_DEV_HEADER
/*
***************************************************************************************************
*                                             INCLUDE FILES
***************************************************************************************************
*/
#include "reg_phys.h"

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/
#define PMIO_VA_BASE_ADDR               (SIC_BSP_PMIO_BASE)        // R/W, Backup RAM Register
#define PMIO_VA_BACKUP_RAM_ADDR         (PMIO_VA_BASE_ADDR + 0x000UL)             // R/W, Backup RAM Register

#define PMIO_VA_GPK_ALL                 (0x3FFFUL)
#define PMIO_VA_GPK_MAX                 (14UL)
#define PMIO_VA_BACKUP_RAM_SIZE         (1024UL) // 1 Kbyte Backup RAM
#define PMIO_VA_INTR_NUM                (328UL)
#define PMIO_VA_UNIT_WORD               (4UL)


/*PMIO VALUES*/
/*PMIO va: Bit flags*/
#define PMIO_VA_BITALL                  (0xFFFFFFFFUL)
#define PMIO_VA_BITCLEAR                (0x00000000UL)
#define PMIO_VA_BIT31                   (0x80000000UL)
#define PMIO_VA_BIT30                   (0x40000000UL)
#define PMIO_VA_BIT29                   (0x20000000UL)
#define PMIO_VA_BIT28                   (0x10000000UL)
#define PMIO_VA_BIT27                   (0x08000000UL)
#define PMIO_VA_BIT26                   (0x04000000UL)
#define PMIO_VA_BIT25                   (0x02000000UL)
#define PMIO_VA_BIT24                   (0x01000000UL)
#define PMIO_VA_BIT23                   (0x00800000UL)
#define PMIO_VA_BIT22                   (0x00400000UL)
#define PMIO_VA_BIT21                   (0x00200000UL)
#define PMIO_VA_BIT20                   (0x00100000UL)
#define PMIO_VA_BIT19                   (0x00080000UL)
#define PMIO_VA_BIT18                   (0x00040000UL)
#define PMIO_VA_BIT17                   (0x00020000UL)
#define PMIO_VA_BIT16                   (0x00010000UL)
#define PMIO_VA_BIT15                   (0x00008000UL)
#define PMIO_VA_BIT14                   (0x00004000UL)
#define PMIO_VA_BIT13                   (0x00002000UL)
#define PMIO_VA_BIT12                   (0x00001000UL)
#define PMIO_VA_BIT11                   (0x00000800UL)
#define PMIO_VA_BIT10                   (0x00000400UL)
#define PMIO_VA_BIT9                    (0x00000200UL)
#define PMIO_VA_BIT8                    (0x00000100UL)
#define PMIO_VA_BIT7                    (0x00000080UL)
#define PMIO_VA_BIT6                    (0x00000040UL)
#define PMIO_VA_BIT5                    (0x00000020UL)
#define PMIO_VA_BIT4                    (0x00000010UL)
#define PMIO_VA_BIT3                    (0x00000008UL)
#define PMIO_VA_BIT2                    (0x00000004UL)
#define PMIO_VA_BIT1                    (0x00000002UL)
#define PMIO_VA_BIT0                    (0x00000001UL)

/*PMIO REGISTERS*/
/*PMIO reg: GPK by PMIO*/
#define PMIO_REG_GPK_FDAT               (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0xA00UL)) //GPK Filtered Data Port
#define PMIO_REG_GPK_IRQST              (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0xA10UL)) //GPK Interrupt Status Register
#define PMIO_REG_GPK_IRQEN              (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0xA14UL)) //GPK Interrupt Enable Register
#define PMIO_REG_GPK_IRQPOL             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0xA18UL)) //GPK Interrupt Polarity Register
#define PMIO_REG_GPK_IRQTM0             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0xA1CUL)) //GPK Interrupt Trigger Mode 0 Reg
#define PMIO_REG_GPK_IRQTM1             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0xA20UL)) //GPK Interrupt Trigger Mode 1 Reg
#define PMIO_REG_GPK_FCK                (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0xA24UL)) //GPK Filter Clock Conf Reg
#define PMIO_REG_GPK_FBP                (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0xA28UL)) //GPK Filter Bypass Register
#define PMIO_REG_GPK_CTL                (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0xA2CUL)) //GPK Miscellaneous Control Reg

/*PMIO reg: Backup Ram*/
#define PMIO_REG_BACKUP_RAM             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x000UL)) // R/W, Backup RAM Register

/*PMIO reg: PMGPIO*/
#define PMIO_REG_PMGPIO_DAT             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x800UL)) //PMGPIO Data Reg
#define PMIO_REG_PMGPIO_EN              (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x804UL)) //PMGPIO Direction Control Reg
#define PMIO_REG_PMGPIO_FS              (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x808UL)) //PMGPIO Function Select Reg
#define PMIO_REG_PMGPIO_IEN             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x80CUL)) //PMGPIO Input Enable Reg
#define PMIO_REG_PMGPIO_PE              (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x810UL)) //PMGPIO PULL Down/Up Enable Reg
#define PMIO_REG_PMGPIO_PS              (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x814UL)) //PMGPIO PULL Down/Up Select Reg
#define PMIO_REG_PMGPIO_CD0             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x818UL)) //PMGPIO Driver Strength 1 Reg
#define PMIO_REG_PMGPIO_CD1             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x81CUL)) //PMGPIO Driver Strength 1 Reg
#define PMIO_REG_PMGPIO_EE0             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x820UL)) //PMGPIO Event Enable 0 Reg
#define PMIO_REG_PMGPIO_EE1             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x824UL)) //PMGPIO Event Enable 1 Reg
#define PMIO_REG_PMGPIO_CTL             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x828UL)) //PMGPIO Control Reg
#define PMIO_REG_PMGPIO_DI              (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x82CUL)) //PMGPIO Input Raw Status Reg
#define PMIO_REG_PMGPIO_STR             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x830UL)) //PMGPIO Rising Event Status Reg
#define PMIO_REG_PMGPIO_STF             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x834UL)) //PMGPIO Falling Event Status Reg
#define PMIO_REG_PMGPIO_POL             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x838UL)) //PMGPIO Event Polarity Reg
#define PMIO_REG_PMGPIO_PROT            (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x83CUL)) //PMGPIO Protect Reg
#define PMIO_REG_PMGPIO_APB             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x900UL)) //PMGPIO & PMRAM APB Timing Reg

/*PMIO reg: PCTLIO*/
#define PMIO_REG_PCTLIO_DAT             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x840UL)) //PCTLIO Data Reg
#define PMIO_REG_PCTLIO_EN              (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x844UL)) //PCTLIO Direction Control Reg
#define PMIO_REG_PCTLIO_FS              (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x848UL)) //PCTLIO Function Select Reg
#define PMIO_REG_PCTLIO_IEN             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x84CUL)) //PCTLIO Input Enable Reg
#define PMIO_REG_PCTLIO_PE              (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x850UL)) //PCTLIO PULL Down/Up Enable Reg
#define PMIO_REG_PCTLIO_PS              (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x854UL)) //PCTLIO PULL Down/Up Reg
#define PMIO_REG_PCTLIO_CD0             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x858UL)) //PCTLIO Driver Strength 0 Reg
#define PMIO_REG_PCTLIO_CD1             (*(SALReg32 *)(PMIO_VA_BASE_ADDR + 0x85CUL)) //PCTLIO Driver Strength 1 Reg

/*
***************************************************************************************************
*                                             LOCAL VARIABLES
***************************************************************************************************
*/

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/
#endif

