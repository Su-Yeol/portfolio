/*
***************************************************************************************************
*
*   FileName : pmio.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************/

#include <pmio.h>
#include <pmio_dev.h>
#include <nvic.h>

/*************************************************************************************************
 *                                             DEFINITIONS
 *************************************************************************************************/
#if (DEBUG_ENABLE==1)
    #include <debug.h>
#endif

/***************************************************************************************************
*                                             LOCAL VARIABLES
***************************************************************************************************/
static PMIOIntr_f gHandler[PMIO_VA_GPK_MAX];

static boolean gIsIrqInit = FALSE;
static uint32 gSTR = 0UL;
static uint32 gSTF = 0UL;

/**************************************************************************************************/
/*                                         FUNCTION PROTOTYPES                                    */
/**************************************************************************************************/
static void PMIO_IntrHandler
(
    void
);


/*************************************************************************************************/
/*                                             Implementation                                    */
/* ***********************************************************************************************/

static void PMIO_IntrHandler
(
    void
)
{
    uint32 uiIdx;

    for(uiIdx = 0UL ; uiIdx < PMIO_VA_GPK_MAX ; uiIdx++)
    {
        if( (PMIO_REG_GPK_IRQEN & (0x1UL<<uiIdx)) > 0UL )
        {
            if( (PMIO_REG_GPK_IRQST & (0x1UL<<uiIdx)) > 0UL )
            {
                PMIO_REG_GPK_IRQST = (0x1UL<<uiIdx);
#if (DEBUG_ENABLE==1)
                mcu_printf("pmio gpio_k %02d irq generated.\n", uiIdx);
#endif
                break;
            }
        }
    }

    if(uiIdx < PMIO_VA_GPK_MAX)
    {
        gHandler[uiIdx]();
    }
}

void PMIO_Init
(
    void
)
{
    boolean bIsReset;

    //Check reset of PCTL for First Power On
    ((PMIO_REG_PCTLIO_DAT == 0UL)?(bIsReset = TRUE):(bIsReset = FALSE));

    PMIO_REG_PMGPIO_PROT = 0UL;

    PMIO_REG_PCTLIO_FS  = 0UL;
    PMIO_REG_PCTLIO_EN  = 0x3UL;
    PMIO_REG_PCTLIO_DAT = ( (1UL<<1UL) | (0UL<<0UL) ); //1-0 Active

    PMIO_REG_PMGPIO_CTL &= (~(PMIO_VA_BIT1|PMIO_VA_BIT0));  //enable Latch/LVS
    PMIO_REG_PMGPIO_CTL |= (PMIO_VA_BIT5); //OFFCTL[1:0], keep low until PRST# active

    //PMIO_REG_PMGPIO_IEN |=  (PMIO_VA_BITALL);  //1: input enable

    if(bIsReset == TRUE)
    {
        //Clear backup ram
        (void)PMIO_SetBackupRam(0x0UL, PMIO_VA_BACKUP_RAM_SIZE, 0x0UL);
    }
    else
    {
        //Get Event
        gSTR = PMIO_REG_PMGPIO_STR;
        gSTF = PMIO_REG_PMGPIO_STF;
    }

    //Clear Event
    PMIO_REG_PMGPIO_STR = PMIO_VA_BITALL;
    PMIO_REG_PMGPIO_STF = PMIO_VA_BITALL;
}

void PMIO_PowerDown
(
    void
)
{
    (void)NVIC_IntSrcDis(PMIO_VA_INTR_NUM);
    gIsIrqInit = FALSE;

#if (DEBUG_ENABLE==1)
    mcu_printf("pmio power down.\n");
#endif

    PMIO_REG_PMGPIO_CTL |=  (PMIO_VA_BIT2); //1: BackupRam write protected

    /*This bit must be set to “1” before core power (VDDI) is turned off.*/
    PMIO_REG_PMGPIO_CTL |=  (PMIO_VA_BIT1|PMIO_VA_BIT0); //disable Latch/LVS

    PMIO_REG_PMGPIO_STR = PMIO_VA_BITALL;
    PMIO_REG_PMGPIO_STF = PMIO_VA_BITALL;

    PMIO_REG_PCTLIO_DAT = ( (0UL<<1UL) | (1UL<<0UL) ); //0-1: powerdown
}

//Port Control
void PMIO_SetPortType
(
    uint32                              uiPort32,
    PMIOPort_t                          tTypeSel
)
{
    uint32 uiIdx;

    switch(tTypeSel)
    {
        case PMIO_PORT_DISABLE:
            {
                //GPK port default is controled by PMGPIO
                PMIO_REG_GPK_IRQEN  &= ~(uiPort32); // interrupt disable
                PMIO_REG_GPK_IRQST  |=  (uiPort32);  // clear interrupt

                PMIO_REG_PMGPIO_POL &= ~(uiPort32); //0:STR 1:STF
                PMIO_REG_PMGPIO_STR  =  (uiPort32); // Clear evnet status
                PMIO_REG_PMGPIO_STF  =  (uiPort32); // Clear evnet status
                PMIO_REG_PMGPIO_EE0 &= ~(uiPort32); //0:Disable 1: En

                PMIO_REG_PMGPIO_IEN &= ~(uiPort32);  //0: input disable
                PMIO_REG_PMGPIO_FS  &= ~(uiPort32);  //0: pin controlled by PMGPIO
                PMIO_REG_PMGPIO_EN  &= ~(uiPort32);  //0: input

                for(uiIdx = 0UL ; uiIdx < PMIO_VA_GPK_MAX ; uiIdx++)
                {
                    if( (uiPort32 & (0x1UL << uiIdx)) > 0UL )
                    {
                        gHandler[uiIdx] = NULL_PTR;
                    }
                }
                break;
            }
        case PMIO_PORT_GPIO:
            {
                PMIO_REG_PMGPIO_FS  |=  (uiPort32); //1: pin controlled by GPIO
                PMIO_REG_PMGPIO_IEN |=  (uiPort32);  //1: input enable
                break;
            }
        case PMIO_PORT_PM_IN:
            {
                PMIO_REG_PMGPIO_FS  &= ~(uiPort32);  //0: pin controlled by PMGPIO
                PMIO_REG_PMGPIO_EN  &= ~(uiPort32);  //0: input
                PMIO_REG_PMGPIO_IEN |=  (uiPort32);  //1: input enable
                break;
            }
        case PMIO_PORT_PM_OUT_L:
            {
                PMIO_REG_PMGPIO_FS  &= ~(uiPort32); //0: pin controlled by PMGPIO_DAT/EN
                PMIO_REG_PMGPIO_EN  |=  (uiPort32); //1: output
                PMIO_REG_PMGPIO_IEN |=  (uiPort32);  //1: input enable
                PMIO_REG_PMGPIO_DAT &= ~(uiPort32); //0: Low
                break;
            }
        case PMIO_PORT_PM_OUT_H:
            {
                PMIO_REG_PMGPIO_FS  &= ~(uiPort32); //0: pin controlled by PMGPIO_DAT/EN
                PMIO_REG_PMGPIO_EN  |=  (uiPort32); //1: output
                PMIO_REG_PMGPIO_IEN |=  (uiPort32);  //1: input enable
                PMIO_REG_PMGPIO_DAT |=  (uiPort32); //1: High
                break;
            }
        case PMIO_PORT_PU:
            {
                PMIO_REG_PMGPIO_PS  |=  (uiPort32);  //1: Set to pull-up
                PMIO_REG_PMGPIO_PE  |=  (uiPort32); //pull up/down En
                break;
            }
        case PMIO_PORT_PD:
            {
                PMIO_REG_PMGPIO_PS  &= ~(uiPort32); //0: Set to pull-down
                PMIO_REG_PMGPIO_PE  |=  (uiPort32); //pull up/down En
                break;
            }
        default:
            {
                break;
            }
    }
}

void PMIO_SetPortIntr
(
    uint32                              uiPort32,
    PMIOIntr_t                          tIntrType,
    PMIOIntr_f                          fIrqFunc
)
{
    uint32 uiIdx;

    PMIO_REG_GPK_IRQEN  &= ~(uiPort32); // interrupt disable
    PMIO_REG_GPK_IRQST  |=  (uiPort32);  // clear interrupt

    PMIO_REG_PMGPIO_FS  &= ~(uiPort32);  //0: pin controlled by PMGPIO
    PMIO_REG_PMGPIO_EN  &= ~(uiPort32);  //0: input
    PMIO_REG_PMGPIO_IEN |=  (uiPort32);  //1: input enable

    switch(tIntrType)
    {
        case PMIO_INTR_RISING_EDGE:
            {
                PMIO_REG_GPK_IRQTM0 &= ~(uiPort32);  //0:edge 1:level
                PMIO_REG_GPK_IRQTM1 &= ~(uiPort32); //0:sigle edge 1:both edge
                PMIO_REG_GPK_IRQPOL &= ~(uiPort32);  //not inverted (when changed low->high)
                break;
            }
        case PMIO_INTR_FALLING_EDGE :
            {
                PMIO_REG_GPK_IRQTM0 &= ~(uiPort32);  //0:edge 1:level
                PMIO_REG_GPK_IRQTM1 &= ~(uiPort32); //0:sigle edge 1:both edge
                PMIO_REG_GPK_IRQPOL |=  (uiPort32);  //inverted (when changed high->low)
                break;
            }
        case PMIO_INTR_BOTH_EDGE    :
            {
                PMIO_REG_GPK_IRQTM0 &= ~(uiPort32);  //0:edge 1:level
                PMIO_REG_GPK_IRQTM1 |= (uiPort32); //0:sigle edge 1:both edge
                break;
            }
        case PMIO_INTR_RISING_LEVEL :
            {
                PMIO_REG_GPK_IRQTM0 |=  (uiPort32);  //0:edge 1:level
                PMIO_REG_GPK_IRQTM1 &= ~(uiPort32); //0:sigle edge 1:both edge
                PMIO_REG_GPK_IRQPOL &= ~(uiPort32);  //not inverted (when changed low->high)
                break;
            }
        case PMIO_INTR_FALLING_LEVEL:
            {
                PMIO_REG_GPK_IRQTM0 |=  (uiPort32);  //0:edge 1:level
                PMIO_REG_GPK_IRQTM1 &= ~(uiPort32); //0:sigle edge 1:both edge
                PMIO_REG_GPK_IRQPOL |=  (uiPort32);  //inverted (when changed high->low)
                break;
            }
        default:
            {
                break;
            }
    }

    for(uiIdx = 0UL ; uiIdx < PMIO_VA_GPK_MAX ; uiIdx++)
    {
        if( (uiPort32 & (0x1UL << uiIdx)) > 0UL )
        {
            if(fIrqFunc != NULL)
            {
                gHandler[uiIdx] = fIrqFunc;
#if (DEBUG_ENABLE==1)
                //mcu_printf("pmio gpio_k %02d irq registerd\n", uiIdx );
#endif
            }
        }
    }

    PMIO_REG_GPK_IRQST  |=  (uiPort32);  // clear interrupt

    if(gIsIrqInit == FALSE)
    {
        gIsIrqInit = TRUE;
        (void)NVIC_IntVectSet(PMIO_VA_INTR_NUM, (IrqHandler_t)&PMIO_IntrHandler);
        (void)NVIC_IntSrcEn(PMIO_VA_INTR_NUM);
    }

    PMIO_REG_GPK_IRQEN  |=  (uiPort32); // interrupt enable
}

void PMIO_SetPortWkup
(
    uint32                              uiPort32,
    PMIOWkup_t                           tWkupType
)
{
    PMIO_REG_PMGPIO_EE0 &= ~(uiPort32); //0:Disable 1: En

    PMIO_REG_PMGPIO_STR  =  (uiPort32); // Clear evnet status
    PMIO_REG_PMGPIO_STF  =  (uiPort32); // Clear evnet status

    PMIO_REG_PMGPIO_FS  &= ~(uiPort32);  //0: pin controlled by PMGPIO
    PMIO_REG_PMGPIO_EN  &= ~(uiPort32);  //0: input
    PMIO_REG_PMGPIO_IEN |=  (uiPort32);  //1: input enable

    switch(tWkupType)
    {
        case PMIO_WKUP_RISING_EDGE  :
            {
                PMIO_REG_PMGPIO_POL &= ~(uiPort32); //0:STR 1:STF
                break;
            }
        case PMIO_WKUP_FALLING_EDGE :
            {
                PMIO_REG_PMGPIO_POL |=  (uiPort32); //0:STR 1:STF
                break;
            }
        default:
            {
                break;
            }
    }

    PMIO_REG_PMGPIO_STR  =  (uiPort32); // Clear evnet status
    PMIO_REG_PMGPIO_STF  =  (uiPort32); // Clear evnet status
    PMIO_REG_PMGPIO_EE0  =  (uiPort32); //0:Disable 1: En
}

uint32 PMIO_GetPortWkup
(
    uint32                              uiPort32
)
{
    uint32 uiRet;
    uint32 uiPortPol;

    uiRet = 0UL;
    uiPort32 &= PMIO_REG_PMGPIO_EE0;

    if( uiPort32 > 0UL )
    {
        //STF
        uiPortPol = PMIO_REG_PMGPIO_POL & uiPort32;
        uiRet |= (uiPortPol & gSTF);
        gSTF &= ~(uiPortPol);

        //STR
        uiPortPol = ((~PMIO_REG_PMGPIO_POL) & uiPort32);
        uiRet |= (uiPortPol & gSTR);
        gSTR &= ~(uiPortPol);
    }

    return uiRet;
}

uint32 PMIO_SetBackupRam
(
    uint32                              uiAddrOffset,
    uint32                              uiSize,
    uint32                              uiVa
)
{
    uint32 uiCurrentOffset;

    if((uiAddrOffset + uiSize) > PMIO_VA_BACKUP_RAM_SIZE)
    {
        uiCurrentOffset = 0UL;
    }
    else if(uiSize == 0UL) //check word unit
    {
        uiCurrentOffset = 0UL;
    }
    else if((uiSize % PMIO_VA_UNIT_WORD) != 0UL) //check word unit
    {
        uiCurrentOffset = 0UL;
    }
    else
    {
        PMIO_REG_PMGPIO_CTL &= ~(PMIO_VA_BIT2); //0: BackupRam write enable

        for
        (
             uiCurrentOffset  = uiAddrOffset    ;
             uiCurrentOffset  < uiSize          ;
             uiCurrentOffset += PMIO_VA_UNIT_WORD
        )
        {
            SAL_WriteReg(uiVa, (PMIO_VA_BACKUP_RAM_ADDR + uiCurrentOffset));
        }

        PMIO_REG_PMGPIO_CTL |= (PMIO_VA_BIT2); //1: BackupRam write protected
    }

    return uiCurrentOffset;
}

uint32 PMIO_GetBackupRam
(
    uint32                              uiAddrOffset
)
{
    uint32 uiReadVa;

    if((uiAddrOffset + PMIO_VA_UNIT_WORD) > PMIO_VA_BACKUP_RAM_SIZE)
    {
        uiReadVa        = 0UL;
    }
    else
    {
        PMIO_REG_PMGPIO_CTL &= ~(PMIO_VA_BIT2); //0: BackupRam write enable

        uiReadVa = SAL_ReadReg(PMIO_VA_BACKUP_RAM_ADDR + uiAddrOffset);

        PMIO_REG_PMGPIO_CTL |= (PMIO_VA_BIT2); //1: BackupRam write protected
    }

    return uiReadVa;
}

