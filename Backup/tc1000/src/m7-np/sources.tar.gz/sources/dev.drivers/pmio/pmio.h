/*
***************************************************************************************************
*
*   FileName : pmio.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_PMIO_HEADER
#define SIC_BSP_PMIO_HEADER

#if ( SIC_BSP_SUPPORT_DRIVER_PMIO == 1 )

#include <sal_com.h>

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/

typedef void                            (* PMIOIntr_f)(void);

#define PMIO_GPK(n)                     (1UL<<(uint32)n)

/*PMIO port types*/
typedef enum
{
    PMIO_PORT_DISABLE    = (0UL),
    PMIO_PORT_GPIO       = (1UL), //Switch to normal GPIO_K
    PMIO_PORT_PM_IN      = (2UL), //Controled by PMGPIO to Input
    PMIO_PORT_PM_OUT_L   = (3UL), //Controled by PMGPIO to Output Low
    PMIO_PORT_PM_OUT_H   = (4UL), //Controled by PMGPIO to Output High
    PMIO_PORT_PD         = (5UL), //Regardless of FS, the port makes Pull down
    PMIO_PORT_PU         = (6UL), //Regardless of FS, the port makes Pull up
}PMIOPort_t;

typedef enum
{
    PMIO_INTR_RISING_EDGE   = (0UL),
    PMIO_INTR_FALLING_EDGE  = (1UL),
    PMIO_INTR_BOTH_EDGE     = (2UL),
    PMIO_INTR_RISING_LEVEL  = (3UL),
    PMIO_INTR_FALLING_LEVEL = (4UL)
}PMIOIntr_t;

typedef enum
{
    PMIO_WKUP_RISING_EDGE   = (0UL),
    PMIO_WKUP_FALLING_EDGE  = (1UL)
}PMIOWkup_t;
/*
***************************************************************************************************
*                                             LOCAL VARIABLES
***************************************************************************************************
*/

/**************************************************************************************************/
/*                                         FUNCTION PROTOTYPES                                    */
/**************************************************************************************************/


/************************************************
*   Power Control
*************************************************/
void PMIO_Init
(
    void
);

void PMIO_PowerDown
(
    void
);
/************************************************/



/************************************************
*   Port Control
*************************************************/
void PMIO_SetPortType
(
    uint32                              uiPort32,
    PMIOPort_t                          tTypeSel
);

void PMIO_SetPortIntr
(
    uint32                              uiPort32,
    PMIOIntr_t                          tIntrType,
    PMIOIntr_f                          fIrqFunc
);

void PMIO_SetPortWkup
(
    uint32                              uiPort32,
    PMIOWkup_t                          tWkupType
);

uint32 PMIO_GetPortWkup
(
    uint32                              uiPort32
);
/************************************************/



/************************************************
*   BackupRam Control
*************************************************/
uint32 PMIO_SetBackupRam
(
    uint32                              uiAddrOffset,
    uint32                              uiSize,
    uint32                              uiVa
);

uint32 PMIO_GetBackupRam
(
    uint32                              uiAddrOffset
);
/************************************************/

#endif

#endif

