/*
***************************************************************************************************
*
*   FileName : uart.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include "bsp.h"
#include "gpio.h"
#include "mpu.h" //mem_get_dma_base
#include "udma.h"
#include "uart.h"
#include "uart_drv.h"

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/

static UartParam_t UART_Param;
static UartStatus_t uart[UART_CH_MAX];

static uint8 uart_buff0[2][UART_BUFF_SIZE];
static uint8 uart_buff1[2][UART_BUFF_SIZE];
static uint8 uart_buff2[2][UART_BUFF_SIZE];
static uint8 uart_buff3[2][UART_BUFF_SIZE];

static uint8 *uart_buff[UART_CH_MAX][2] =
{
    { uart_buff0[0], uart_buff0[1] },
    { uart_buff1[0], uart_buff1[1] },
    { uart_buff2[0], uart_buff2[1] },
    { uart_buff3[0], uart_buff3[1] }
};

/*
***************************************************************************************************
                                     STATIC FUNCTIONS
***************************************************************************************************
*/

static uint32 UART_RegRead
(
    uint8                               ucCh,
    uint32                              uiAddr
);

static void UART_RegWrite
(
    uint8                               ucCh,
    uint32                              uiAddr,
    uint32                              uiSetValue
);

static SALRetCode_t UART_Reset
(
    uint8                               ucCh
);

static sint32 UART_SetGpio
(
    uint8                               ucCh,
    const UartBoardPort_t *             psInfo
);

static sint32 UART_SetPortConfig
(
    uint8                               ucCh,
    uint32                              uiPort
);

static SALRetCode_t UART_ClearGpio
(
    uint8                               ucCh
);

static sint32 UART_SetChannelConfig
(
    UartParam_t                         * pUartCfg
);

static sint32 UART_SetBaudRate
(
    uint8                               ucCh,
    uint32                              uiBaud
);

static void UART_StatusInit
(
    uint8                               ucCh
);

static sint32 UART_Probe
(
    UartParam_t                         * pUartCfg
);

static sint32 UART_Rx
(
    uint8                               ucCh
);

static sint32 UART_TxChar
(
    uint8                               ucCh,
    uint8                               cChar
);

static sint32 UART_Tx
(
    uint8                               ucCh
);

static void UART_DmaRxIrq
(
    uint8                               ucCh
);

static void UART_EnableInterrupt
(
    uint8                               ucCh,
    uint8                               ucFIFO,
    IrqHandler_t                          fnCallback
);

static void UART_DisableInterrupt
(
    uint8                               ucCh
);

static void UART_InterruptTxProbe
(
    uint8                               ucCh
);

static void UART_InterruptRxProbe
(
    uint8                               ucCh
);

static void UART_InterruptProbe
(
    uint8                               ucCh
);

static sint32 UART_InterruptWrite
(
    uint8                               ucCh,
    const uint8 *                       pucBuf,
    uint32                              uiSize
);

static sint32 UART_InterruptRead
(
    uint8                               ucCh,
    uint8 *                             pucBuf,
    uint32                              uiSize
);

static uint32 UART_GetDmaRxAddr
(
    uint8                               ucCh,
    uint8                               uiTxRx
);

static void UART_DmaTxProbe
(
    uint8                               ucCh,
    uint32 *                            puiAddr
);

static void UART_DmaRxProbe
(
    uint8                               ucCh,
    uint32 *                            puiAddr
);

static void UART_DmaProbe
(
    uint8                               ucCh
);

static sint32 UART_DmaTxEnable
(
    uint8                               ucCh,
    uint32                              uiSize,
    const UDMAInformation_t *           psDmacon
);

static sint32 UART_DmaRxEnable
(
    uint8                               ucCh,
    uint32                              uiSize,
    const UDMAInformation_t *           psDmacon
);

static sint32 UART_DmaWrite
(
    uint8                               ucCh,
    const uint8 *                       pucBuf,
    uint32                              uiSize
);

static sint32 UART_DmaRead
(
    uint8                               ucCh,
    uint8 *                             pucBuf,
    uint32                              uiSize
);

static sint32 UART_DmaRxTriggerDma
(
    uint8                               ucCh
);

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/

static uint32 UART_RegRead
(
    uint8                               ucCh,
    uint32                              uiAddr
)
{
    uint32 uiBaseAddr;
    uint32 uiRegAddr;
    uint32 uiRet;

    uiRet       = 0;
    uiBaseAddr  = uart[ucCh].sBase & 0x4FFFFFFFU;
    uiAddr      &= 0xFFFFU;
    uiRegAddr   = uiBaseAddr + uiAddr;
    uiRet       = SAL_ReadReg(uiRegAddr);

    return uiRet;
}

static void UART_RegWrite
(
    uint8                               ucCh,
    uint32                              uiAddr,
    uint32                              uiSetValue
)
{
    uint32 uiBaseAddr;
    uint32 uiRegAddr;

    uiBaseAddr  = uart[ucCh].sBase & 0x4FFFFFFFU;
    uiAddr      &= 0xFFFFU;
    uiRegAddr   = uiBaseAddr + uiAddr;
    SAL_WriteReg(uiSetValue, uiRegAddr);

    return;
}

/*
***************************************************************************************************
*                                          UART_Reset
*
* Function to reset UART Channel.
*
* @param    ucCh [in]       : Value of channel to control
* @return   SAL_RET_SUCCESS or SAL_ERR
* Notes
*
***************************************************************************************************
*/

static SALRetCode_t UART_Reset
(
    uint8                               ucCh
)
{
    SALRetCode_t tRet;
    sint32 iRet;
    sint32 iClkBusId;

    tRet = SAL_RET_SUCCESS;
    iClkBusId   = (sint32)CLOCK_IOBUS_UART0 + (sint32)ucCh;

    /* SW reset */
    iRet = CLOCK_SetSwReset(iClkBusId, TRUE);

    if(iRet != (sint32)NULL)
    {
        tRet = SAL_RET_FAILED;
    }
    else
    {
        /* Bit Clear */
        iRet = CLOCK_SetSwReset(iClkBusId, FALSE);

        if(iRet != (sint32)NULL)
        {
            tRet = SAL_RET_FAILED;
        }
    }

    return tRet;
}

static sint32 UART_SetGpio
(
    uint8                               ucCh,
    const UartBoardPort_t *             psInfo
)
{
    uint32          portcfg;
    uint32          portcfg_val;
    sint32          iRet;
    SALRetCode_t    tRet;

    /* AXON_TEMP */
    SAL_WriteReg(GPIO_PASSWORD, GPIO_REG_CFG_PW);
    SAL_WriteReg(0x0UL, GPIO_REG_CFG_WR_LOCK);

    portcfg = GPIO_CFG_UARTx_SEL(ucCh);
    iRet    = -2;

    if(psInfo != NULL_PTR)
    {
        /* set portcfg */
        portcfg_val = (psInfo->bPortCfg & 0x1F);    // 0 =< psInfo->bPortCfg < 25
        SAL_WriteReg(portcfg_val, portcfg);

        /* set debug port */
        tRet = GPIO_Config(psInfo->bPortTx, (psInfo->bPortFs)); // TX
        tRet &= GPIO_Config(psInfo->bPortRx, (psInfo->bPortFs | GPIO_INPUT | GPIO_INPUTBUF_EN)); // RX

        uart[ucCh].sPort.bPortCfg = psInfo->bPortCfg;
        uart[ucCh].sPort.bPortTx = psInfo->bPortTx;
        uart[ucCh].sPort.bPortRx = psInfo->bPortRx;
        uart[ucCh].sPort.bPortFs = psInfo->bPortFs;

        if(uart[ucCh].sCtsRts != 0UL)
        {
            tRet &= GPIO_Config(psInfo->bPortRts, psInfo->bPortFs); // RTS
            tRet &= GPIO_Config(psInfo->bPortCts, psInfo->bPortFs); // CTS

            if(tRet != SAL_RET_SUCCESS)
            {
                iRet = -1;
            }
            else
            {
                uart[ucCh].sPort.bPortCts = psInfo->bPortCts;
                uart[ucCh].sPort.bPortRts = psInfo->bPortRts;
            }
        }
        else if(tRet != SAL_RET_SUCCESS)
        {
            iRet = -1;
        }
        else
        {
            iRet = 0;
        }
    }
    else
    {
        iRet = -1;
    }

    return iRet;
}

static sint32 UART_SetPortConfig
(
    uint8                               ucCh,
    uint32                              uiPort
)
{
    uint32  idx;
    sint32  ret = 0;

    static const UartBoardPort_t board_serial[UART_PORT_TBL_SIZE] =
    {

        { 0U,  GPIO_GPA(15U),  GPIO_GPA(16U),  GPIO_GPA(17U),    GPIO_GPA(18U),    GPIO_FUNC(3U) },
        { 1U,  GPIO_GPB(15U),  GPIO_GPB(16U),  GPIO_GPB(17U),    GPIO_GPB(18U),    GPIO_FUNC(3U) },
        { 2U,  GPIO_GPC(15U),  GPIO_GPC(16U),  GPIO_GPC(17U),    GPIO_GPC(18U),    GPIO_FUNC(3U) },
        { 3U,  GPIO_GPD(15U),  GPIO_GPD(16U),  GPIO_GPD(17U),    GPIO_GPD(18U),    GPIO_FUNC(3U) },
        { 4U,  GPIO_GPE(0U),   GPIO_GPE(1U),   GPIO_GPE(2U),     GPIO_GPE(3U),     GPIO_FUNC(3U) },
        { 5U,  GPIO_GPE(6U),   GPIO_GPE(7U),   GPIO_GPE(8U),     GPIO_GPE(9U),     GPIO_FUNC(3U) },
        { 6U,  GPIO_GPE(12U),  GPIO_GPE(13U),  GPIO_GPE(14U),    GPIO_GPE(15U),    GPIO_FUNC(3U) },
        { 7U,  GPIO_GPF(0U),   GPIO_GPF(1U),   GPIO_GPF(2U),     GPIO_GPF(3U),     GPIO_FUNC(3U) },
        { 8U,  GPIO_GPF(6U),   GPIO_GPF(7U),   GPIO_GPF(8U),     GPIO_GPF(9U),     GPIO_FUNC(3U) },
        { 9U,  GPIO_GPF(12U),  GPIO_GPF(13U),  GPIO_GPF(14U),    GPIO_GPF(15U),    GPIO_FUNC(3U) },
        { 10U, GPIO_GPG(0U),   GPIO_GPG(1U),   GPIO_GPG(2U),     GPIO_GPG(3U),     GPIO_FUNC(3U) },
        { 11U, GPIO_GPG(6U),   GPIO_GPG(7U),   GPIO_GPG(8U),     GPIO_GPG(9U),     GPIO_FUNC(3U) },
        { 12U, GPIO_GPG(12U),  GPIO_GPG(13U),  GPIO_GPG(14U),    GPIO_GPG(15U),    GPIO_FUNC(3U) },
        { 13U, GPIO_GPH(0U),   GPIO_GPH(1U),   GPIO_GPH(2U),     GPIO_GPH(3U),     GPIO_FUNC(3U) },
        { 14U, GPIO_GPH(6U),   GPIO_GPH(7U),   GPIO_GPH(8U),     GPIO_GPH(9U),     GPIO_FUNC(3U) },
        { 15U, GPIO_GPH(12U),  GPIO_GPH(13U),  GPIO_GPH(14U),    GPIO_GPH(15U),    GPIO_FUNC(3U) },
        { 16U, GPIO_GPI(0U),   GPIO_GPI(1U),   GPIO_GPI(2U),     GPIO_GPI(3U),     GPIO_FUNC(3U) },
        { 17U, GPIO_GPI(6U),   GPIO_GPI(7U),   GPIO_GPI(8U),     GPIO_GPI(9U),     GPIO_FUNC(3U) },
        { 18U, GPIO_GPI(12U),  GPIO_GPI(13U),  GPIO_GPI(14U),    GPIO_GPI(15U),    GPIO_FUNC(3U) },
        { 19U, GPIO_GPJ(0U),   GPIO_GPJ(1U),   GPIO_GPJ(2U),     GPIO_GPJ(3U),     GPIO_FUNC(3U) },
        { 20U, GPIO_GPJ(6U),   GPIO_GPJ(7U),   GPIO_GPJ(8U),     GPIO_GPJ(9U),     GPIO_FUNC(3U) },
        { 21U, GPIO_GPJ(12U),  GPIO_GPJ(13U),  GPIO_GPJ(14U),    GPIO_GPJ(15U),    GPIO_FUNC(3U) },
        { 22U, GPIO_GPL(0U),   GPIO_GPL(1U),   GPIO_GPL(2U),     GPIO_GPL(3U),     GPIO_FUNC(3U) },
        { 23U, GPIO_GPL(6U),   GPIO_GPL(7U),   GPIO_GPL(8U),     GPIO_GPL(9U),     GPIO_FUNC(3U) },
        { 24U, GPIO_GPL(12U),  GPIO_GPL(13U),  GPIO_GPL(14U),    GPIO_GPL(15U),    GPIO_FUNC(3U) }
    };

    if((uiPort < UART_PORT_CFG_MAX) && (ucCh < UART_CH_MAX))
    {
        for(idx = 0U; idx < UART_PORT_CFG_MAX; idx++)
        {
            if(board_serial[idx].bPortCfg == uiPort)
            {
                ret = UART_SetGpio(ucCh, &board_serial[idx]);
                break;
            }
        }
    }
    else
    {
        ret = -1;
    }

    return ret;
}

static SALRetCode_t UART_ClearGpio
(
    uint8                               ucCh
)
{
    uint32          portcfg;
    uint32          gpio_Tx = 0;
    uint32          gpio_Rx = 0;
    uint32          gpio_Cts = 0;
    uint32          gpio_Rts = 0;
    SALRetCode_t    ret = SAL_RET_SUCCESS;

    if(ucCh >= UART_CH_MAX)
    {
        ret = SAL_RET_FAILED;
    }
    else
    {
        gpio_Tx = uart[ucCh].sPort.bPortTx;
        gpio_Rx = uart[ucCh].sPort.bPortRx;

        /* Reset gpio */
        ret = GPIO_Config(gpio_Tx, GPIO_FUNC(0UL));
        ret &= GPIO_Config(gpio_Rx, GPIO_FUNC(0UL));

        if(uart[ucCh].sCtsRts == ON)
        {
            gpio_Cts = uart[ucCh].sPort.bPortCts;
            gpio_Rts = uart[ucCh].sPort.bPortRts;

            ret &= GPIO_Config(gpio_Cts, GPIO_FUNC(0UL));
            ret &= GPIO_Config(gpio_Rts, GPIO_FUNC(0UL));
        }

        if(ret != SAL_RET_FAILED)
        {
            /* Reset uart pcfg */
            portcfg = GPIO_CFG_UARTx_SEL(ucCh);
            SAL_WriteReg(0x1FUL, portcfg);
        }
    }

    return ret;
}

static sint32 UART_SetChannelConfig
(    UartParam_t                         * pUartCfg
)
{
    uint8   ucCh;
    sint32  ret;
    sint32  iClkBusId;
    sint32  iClkPeriId;
    uint32  cr_data = 0;
    uint32  lcr_data = 0;

    ucCh = pUartCfg->sCh;

    /* Enable the UART controller peri clock */
    iClkBusId   = (sint32)CLOCK_IOBUS_UART0 + (sint32)ucCh;
    (void)CLOCK_SetIobusPwdn(iClkBusId, SALDisabled);
    iClkPeriId  = (sint32)CLOCK_PERI_UART0 + (sint32)ucCh;
    ret         = CLOCK_SetPeriRate(iClkPeriId, UART_DEBUG_CLK);
    (void)CLOCK_EnablePeri(iClkPeriId);

    if(ret == 0)
    {
        (void)UART_SetBaudRate(ucCh, pUartCfg->sBaudrate);

        // line control setting
        // Word Length
        pUartCfg->sWordLength &= 0x3U;
        lcr_data |= UART_LCRH_WLEN((uint32)pUartCfg->sWordLength);

        // Enables FIFOs
        if(pUartCfg->sFIFO == ENABLE_FIFO)
        {
            lcr_data |= UART_LCRH_FEN;
        }

        // Two Stop Bits
        if(pUartCfg->s2StopBit == ON)
        {
            lcr_data |= UART_LCRH_STP2;
        }

        // Parity Enable
        switch(pUartCfg->sParity)
        {
            case PARITY_NONE:
                lcr_data &= ~(UART_LCRH_PEN);
                break;
            case PARITY_EVEN:
                lcr_data |= ((UART_LCRH_PEN | UART_LCRH_EPS) & ~(UART_LCRH_SPS));
                break;
            case PARITY_ODD:
                lcr_data |= ((UART_LCRH_PEN & ~(UART_LCRH_EPS)) & ~(UART_LCRH_SPS));
                break;
            case PARITY_MARK:
                lcr_data |= ((UART_LCRH_PEN & ~(UART_LCRH_EPS)) | UART_LCRH_SPS);
                break;
            case PARITY_SPACE:
                lcr_data |= (UART_LCRH_PEN | UART_LCRH_EPS | UART_LCRH_SPS);
                break;
            default:
                break;
        }

        UART_RegWrite(ucCh, UART_REG_LCRH, lcr_data);

        // control register setting
        cr_data = UART_CR_EN;
        cr_data |= UART_CR_TXE;
        cr_data |= UART_CR_RXE;

        if(uart[ucCh].sCtsRts != 0UL)
        {
            cr_data |= (UART_CR_RTSEN | UART_CR_CTSEN);
        }

        UART_RegWrite(ucCh, UART_REG_CR, cr_data);
    }

    return ret;
}

static sint32 UART_SetBaudRate
(
    uint8                               ucCh,
    uint32                              uiBaud
)
{
    uint32  u32_div;
    uint32  mod;
    uint32  brd_i;
    uint32  brd_f;
    uint32  pclk;
    sint32  ret;

    if(ucCh >= UART_CH_MAX)
    {
        ret = -1;
    }
    else
    {
        // Read the peri clock
        pclk = CLOCK_GetPeriRate((sint32)CLOCK_PERI_UART0 + (sint32)ucCh);

        if(pclk != 0UL)
        {
            // calculate integer baud rate divisor
            u32_div = 16UL * uiBaud;
            brd_i   = pclk / u32_div;
            UART_RegWrite(ucCh, UART_REG_IBRD, brd_i);

            // calculate faction baud rate divisor
            // NOTICE : fraction maybe need sampling
            uiBaud &= 0xFFFFFFU;
            mod     = (pclk % (16U * uiBaud)) & 0xFFFFFFU;
            u32_div = ((128U * mod) / (16U * uiBaud));    //u32_div = ((((1UL << 3UL) * 16UL) * mod) / (16UL * uiBaud));
            brd_f   = u32_div / 2UL;
            UART_RegWrite(ucCh, UART_REG_FBRD, brd_f);

            ret = (sint32)SAL_RET_SUCCESS;
        }
    }
    return ret;
}

static void UART_StatusInit
(
    uint8                               ucCh
)
{
    uart[ucCh].sIsProbed                = 0;
    uart[ucCh].sBase                    = UART_GET_BASE(ucCh);
    uart[ucCh].sCh                      = ucCh;
    uart[ucCh].sOpMode                  = UART_POLLING_MODE;
    uart[ucCh].sCtsRts                  = 0;

    /* Interupt mode init */
    uart[ucCh].sTxIntr.iXmitBuf         = NULL;
    uart[ucCh].sTxIntr.iHead            = -1;
    uart[ucCh].sTxIntr.iTail            = -1;
    uart[ucCh].sTxIntr.iSize            = 0;
    uart[ucCh].sRxIntr.iXmitBuf         = NULL;
    uart[ucCh].sRxIntr.iHead            = -1;
    uart[ucCh].sRxIntr.iTail            = -1;
    uart[ucCh].sRxIntr.iSize            = 0;

    /* DMA mode init */
    uart[ucCh].sTxDma.iCon              = 0xFF;
    uart[ucCh].sTxDma.iCh               = 0xFF;
    uart[ucCh].sTxDma.iSrcAddr          = NULL;
    uart[ucCh].sTxDma.iDestAddr         = NULL;
    uart[ucCh].sTxDma.iBufSize          = UDMA_BUFF_SIZE;
    uart[ucCh].sTxDma.iTransSize        = 0;
    uart[ucCh].sTxDma.iIsRun            = 0;
    uart[ucCh].sRxDma.iCon              = 0xFF;
    uart[ucCh].sRxDma.iCh               = 0xFF;
    uart[ucCh].sRxDma.iSrcAddr          = NULL;
    uart[ucCh].sRxDma.iDestAddr         = NULL;
    uart[ucCh].sRxDma.iBufSize          = UDMA_BUFF_SIZE;
    uart[ucCh].sRxDma.iTransSize        = 0;
    uart[ucCh].sRxDma.iIsRun            = 0;
}

static sint32 UART_Probe
(
    UartParam_t                         * pUartCfg
)
{
    uint8   ucCh;
    sint32  ret = -1;

    ucCh = pUartCfg->sCh;

    if((ucCh < UART_CH_MAX) && (uart[ucCh].sIsProbed == OFF))
    {
        uart[ucCh].sOpMode      = pUartCfg->sMode;
        uart[ucCh].sCtsRts      = pUartCfg->sCtsRts;

        // Set port config
        ret = UART_SetPortConfig(ucCh, pUartCfg->sPortCfg);

        if(ret != -1)
        {
            ret = UART_SetChannelConfig(pUartCfg);

            if(ret != -1)
            {
                // Configure for interrupt mode
                if(uart[ucCh].sOpMode == UART_INTR_MODE)
                {
                    UART_InterruptProbe(ucCh);
                    UART_EnableInterrupt(ucCh, pUartCfg->sFIFO, pUartCfg->sFnCallback);
                }
                else if(uart[ucCh].sOpMode == UART_DMA_MODE)
                {
                    UART_DmaProbe(ucCh);
                    UART_EnableInterrupt(ucCh, pUartCfg->sFIFO, pUartCfg->sFnCallback);
                }
                else
                {
	                // UART_POLLING_MODE
                }

                uart[ucCh].sIsProbed = ON;
            }
        }
    }

    return ret;
}

static sint32 UART_Rx
(
    uint8                               ucCh
)
{
    uint32  status;
    sint32  max_count;
    uint32  data;
    uint8 * buf;
    sint32  ret = -1;

    max_count   = UART_BUFF_SIZE;
    buf         = NULL;

    if(ucCh < UART_CH_MAX)
    {
        buf = uart[ucCh].sRxIntr.iXmitBuf;

        while(max_count > 0)
        {
            status = UART_RegRead(ucCh, UART_REG_FR);

            if((status & UART_FR_RXFE) != 0U)
            {
                break;
            }

            data = UART_RegRead(ucCh, UART_REG_DR);

            buf[uart[ucCh].sRxIntr.iHead] = (uint8)(data & 0xFFUL);

            if(uart[ucCh].sRxIntr.iHead < 0xFFFF)
            {
                uart[ucCh].sRxIntr.iHead++;
            }

            if(uart[ucCh].sRxIntr.iHead >= uart[ucCh].sRxIntr.iSize)
            {
                uart[ucCh].sRxIntr.iHead = 0;
            }

            max_count--;
        }

        ret = (sint32)SAL_RET_SUCCESS;
    }

    return ret;
}

static sint32 UART_TxChar
(
    uint8                               ucCh,
    uint8                               cChar
)
{
    sint32  ret = -1;

    if(ucCh < UART_CH_MAX)
    {
        if((UART_RegRead(ucCh, UART_REG_FR) & UART_FR_TXFF) == 0UL)
        {
            UART_RegWrite(ucCh, UART_REG_DR, cChar);
            ret = (sint32)SAL_RET_SUCCESS;
        }
    }

    return ret;
}

static sint32 UART_Tx
(
    uint8                               ucCh
)
{
    const uint8 * buf;
    sint32  ret = -1;

    if(ucCh < UART_CH_MAX)
    {
        buf = uart[ucCh].sTxIntr.iXmitBuf;

        // xmit buffer is empty
        if(uart[ucCh].sTxIntr.iHead == uart[ucCh].sTxIntr.iTail)
        {
            UART_RegWrite(ucCh, UART_REG_ICR, UART_INT_TXIS);
        }
        else
        {
            do
            {
                if(UART_TxChar(ucCh, buf[(uint32)uart[ucCh].sTxIntr.iTail]) != 0)
                {
                    break;
                }

                uart[ucCh].sTxIntr.iTail++;

                if(uart[ucCh].sTxIntr.iTail >= uart[ucCh].sTxIntr.iSize)
                {
                    uart[ucCh].sTxIntr.iTail = 0;
                }
            } while(uart[ucCh].sTxIntr.iHead != uart[ucCh].sTxIntr.iTail);
        }

        ret = (sint32)SAL_RET_SUCCESS;
    }

    return ret;
}

static void UART_DmaRxIrq
(
    uint8                               ucCh
)
{
    uint32  dmacr;

    if(ucCh < UART_CH_MAX)
    {
        dmacr   = UART_RegRead(ucCh, UART_REG_DMACR);
        dmacr   &= ~UART_DMACR_RXDMAE;
        UART_RegWrite(ucCh, UART_REG_DMACR, dmacr);

        uart[ucCh].sRxDma.iIsRun = 0;

        UART_RegWrite(ucCh, UART_REG_ICR, UART_INT_OEIS | UART_INT_BEIS | UART_INT_PEIS | UART_INT_FEIS);

        (void)UART_DmaRxTriggerDma(ucCh);

        uart[ucCh].sRxDma.iIsRun = 0;
    }
}

static void UART_EnableInterrupt
(
    uint8                               ucCh,
    uint8                               ucFIFO,
    IrqHandler_t                        fnCallback
)
{
    uint32  i;
    uint32  im = 0UL;

    if(ucCh < UART_CH_MAX)
    {
        (void)NVIC_IntVectSet(UART_C0_IRQn + ucCh, (IrqHandler_t)fnCallback);
        (void)NVIC_IntSrcEn(UART_C0_IRQn + ucCh);

        UART_RegWrite(ucCh, UART_REG_ICR, UART_INT_RXIS | UART_INT_TXIS | UART_INT_RTIS);

        for(i = 0UL ; i < (UART_RX_FIFO_SIZE * 2UL) ; ++i)
        {
            if((UART_RegRead(ucCh, UART_REG_FR) & UART_FR_RXFF) != 0UL)
            {
                break;
            }

            (void)UART_RegRead(ucCh, UART_REG_DR);
        }

        if(ucFIFO == ENABLE_FIFO)
        {
            im = UART_INT_RTIS;
        }

        if(uart[ucCh].sRxDma.iIsRun == 0UL)
        {
            im |= UART_INT_RXIS;
        }

        UART_RegWrite(ucCh, UART_REG_IMSC, im);
    }
}

static void UART_DisableInterrupt
(
    uint8                               ucCh
)
{
    if(ucCh < UART_CH_MAX)
    {
        (void)NVIC_IntSrcDis(UART_C0_IRQn + ucCh);
        UART_RegWrite(ucCh, UART_REG_ICR, 0x7FF);
    }
}

static void UART_InterruptTxProbe
(
    uint8                               ucCh
)
{
    if(ucCh < UART_CH_MAX)
    {
        uart[ucCh].sTxIntr.iXmitBuf = uart_buff[ucCh][UART_MODE_TX];
        uart[ucCh].sTxIntr.iSize    = (sint32)UART_BUFF_SIZE;
        uart[ucCh].sTxIntr.iHead    = 0;
        uart[ucCh].sTxIntr.iTail    = 0;
    }
}

static void UART_InterruptRxProbe
(
    uint8                               ucCh
)
{
    if(ucCh < UART_CH_MAX)
    {
        uart[ucCh].sRxIntr.iXmitBuf = uart_buff[ucCh][UART_MODE_RX];
        uart[ucCh].sRxIntr.iSize    = (sint32)UART_BUFF_SIZE;
        uart[ucCh].sRxIntr.iHead    = 0;
        uart[ucCh].sRxIntr.iTail    = 0;
    }
}

static void UART_InterruptProbe
(
    uint8                               ucCh
)
{
    UART_InterruptTxProbe(ucCh);
    UART_InterruptRxProbe(ucCh);
}


static sint32 UART_InterruptWrite
(
    uint8                               ucCh,
    const uint8 *                       pucBuf,
    uint32                              uiSize
)
{
    uint32  i;
    uint32  imsc;
    sint32  ret = -1;

    if(pucBuf != NULL_PTR)
    {
        // copy user buffer to tx buffer
        for(i = 0 ; i < uiSize ; i++)
        {
            uart[ucCh].sTxIntr.iXmitBuf[uart[ucCh].sTxIntr.iHead] = pucBuf[i];
            if(uart[ucCh].sTxIntr.iHead < (sint32)UART_BUFF_SIZE)
            {
                uart[ucCh].sTxIntr.iHead++;
            }

            if(uart[ucCh].sTxIntr.iHead >= uart[ucCh].sTxIntr.iSize)
            {
                uart[ucCh].sTxIntr.iHead = 0;
            }
        }

        ret = UART_Tx(ucCh);

        if(ret == (sint32)SAL_RET_SUCCESS)
        {
            imsc = UART_RegRead(ucCh, UART_REG_IMSC);
            imsc |= UART_INT_TXIS;
            UART_RegWrite(ucCh, UART_REG_IMSC, imsc);
        }
    }

    return ret;
}

static sint32 UART_InterruptRead
(
    uint8                               ucCh,
    uint8 *                             pucBuf,
    uint32                              uiSize
)
{
    sint32  cnt;
    sint32  i;
    sint32  ret = -1;

    if(ucCh < UART_CH_MAX)
    {
        if(uart[ucCh].sRxIntr.iHead > uart[ucCh].sRxIntr.iTail)
        {
            cnt = uart[ucCh].sRxIntr.iHead - uart[ucCh].sRxIntr.iTail;
        }
        else if(uart[ucCh].sRxIntr.iHead < uart[ucCh].sRxIntr.iTail)
        {
            cnt = uart[ucCh].sRxIntr.iSize - uart[ucCh].sRxIntr.iTail;
        }
        else
        {
            cnt = 0;
        }

        uiSize &= 0xFFFFU;
        if (cnt > (sint32)uiSize)
        {
            cnt = (sint32)uiSize;
        }

        // copy rx buffer to user buffer
        for(i = 0 ; i < cnt ; i++)
        {
            pucBuf[i] = uart[ucCh].sRxIntr.iXmitBuf[uart[ucCh].sRxIntr.iTail];
            uart[ucCh].sRxIntr.iTail++;

            if(uart[ucCh].sRxIntr.iTail >= uart[ucCh].sRxIntr.iSize)
            {
                uart[ucCh].sRxIntr.iTail = 0;
            }
        }

        ret = cnt;
    }

    return ret;
}

static uint32 UART_GetDmaRxAddr
(
    uint8                               ucCh,
    uint8                               uiTxRx
)
{
    uint32          uiDmaBaseAddr = 0;
    uint32          uiDmaBufOffset = 0;
    uint32          uiDmaBufAddr = 0;

    /* SRAM remap */
#if ( CORTEX_M7_0==1 )
    uiDmaBaseAddr = MPU_GetDMABaseAddress();
#elif ( CORTEX_M7_1==1 )
    uiDmaBaseAddr = MPU_GetDMABaseAddress() + 0x30200000UL;
#elif ( CORTEX_M7_2==1 )
    uiDmaBaseAddr = MPU_GetDMABaseAddress() + 0x30300000UL;
#elif ( CORTEX_M7_NP==1 )
    uiDmaBaseAddr = MPU_GetDMABaseAddress() + 0x30400000UL;
#endif

    uiDmaBaseAddr &= 0x3FFFFFFFU;
    ucCh &= 0xFU;
    uiDmaBufOffset = (UDMA_ADDRESS_UNIT << 1) * ucCh;

    switch(uiTxRx)
    {
        case UDMA_PERI_RX:
            uiDmaBufAddr = uiDmaBaseAddr + uiDmaBufOffset;
            break;
        case UDMA_PERI_TX:
            uiDmaBufAddr = uiDmaBaseAddr + (uiDmaBufOffset + UDMA_ADDRESS_UNIT);
            break;
        default:
            uiDmaBufAddr = uiDmaBaseAddr;
            break;
    }

    return uiDmaBufAddr;
}

static void UART_DmaTxProbe
(
    uint8                               ucCh,
    uint32 *                            puiAddr
)
{
    uint32 regData;

    if(ucCh < UART_CH_MAX)
    {
        uart[ucCh].sTxDma.iCon          = ucCh;
        uart[ucCh].sTxDma.iCh           = (uint32)UDMA_PERI_TX;
        uart[ucCh].sTxDma.iBufSize      = UDMA_BUFF_SIZE;
        uart[ucCh].sTxDma.iTransSize    = 0U;
        (void)SAL_MemCopy(&uart[ucCh].sTxDma.iSrcAddr, &puiAddr, sizeof(uint8 *));
        (void)SAL_MemCopy(&uart[ucCh].sTxDma.iDestAddr, &uart[ucCh].sBase, sizeof(uint8 *));

        (void)UDMA_Init(&uart[ucCh].sTxDma);

        // Enable Transmit DMA
        regData = (UART_RegRead(ucCh, UART_REG_DMACR) | UART_DMACR_DMAONERR | UART_DMACR_TXDMAE);
        UART_RegWrite(ucCh, UART_REG_DMACR, regData);

        // Set flow ctrl, burst size
        UDMA_SetParam(&uart[ucCh].sTxDma, UDMA_PERI_TX);

        UDMA_SetPeri(&uart[ucCh].sTxDma, (uint8)UDMA_PERI_TX, 0U);

        (void)UART_DmaTxEnable(ucCh, uart[ucCh].sTxDma.iBufSize, (const UDMAInformation_t *)&uart[ucCh].sTxDma);
    }
}

static void UART_DmaRxProbe
(
    uint8                               ucCh,
    uint32 *                            puiAddr
)
{
    uint32 regData;

    uart[ucCh].sRxDma.iCon          = ucCh;
    uart[ucCh].sRxDma.iCh           = (uint32)UDMA_PERI_RX;
    uart[ucCh].sRxDma.iBufSize      = UDMA_BUFF_SIZE;
    uart[ucCh].sRxDma.iTransSize    = 0U;
    (void)SAL_MemCopy(&uart[ucCh].sRxDma.iSrcAddr, &uart[ucCh].sBase, sizeof(uint8 *));
    (void)SAL_MemCopy(&uart[ucCh].sRxDma.iDestAddr, &puiAddr, sizeof(uint8 *));

    (void)UDMA_Init(&uart[ucCh].sRxDma);

    // Enable Receive DMA
    regData = (UART_RegRead(ucCh, UART_REG_DMACR) | UART_DMACR_DMAONERR | UART_DMACR_RXDMAE);
    UART_RegWrite(ucCh, UART_REG_DMACR, regData);
    // Set flow ctrl, burst size
    UDMA_SetParam(&uart[ucCh].sRxDma, UDMA_PERI_RX);

    UDMA_SetPeri(&uart[ucCh].sRxDma, 0U, (uint8)UDMA_PERI_RX);

    (void)UART_DmaRxEnable(ucCh, uart[ucCh].sRxDma.iBufSize, (const UDMAInformation_t *)&uart[ucCh].sRxDma);
}

static void UART_DmaProbe
(
    uint8                               ucCh
)
{
    uint32          uiDmaRxAddr;
    uint32          uiDmaTxAddr;
    static uint32 * dma_tx_buf;
    static uint32 * dma_rx_buf;

    uiDmaRxAddr = UART_GetDmaRxAddr(ucCh, UDMA_PERI_RX);
    uiDmaTxAddr = UART_GetDmaRxAddr(ucCh, UDMA_PERI_TX);
    (void)SAL_MemCopy(&dma_rx_buf, &uiDmaRxAddr, sizeof(uint32 *));
    (void)SAL_MemCopy(&dma_tx_buf, &uiDmaTxAddr, sizeof(uint32 *));

    if((dma_tx_buf != NULL_PTR) && (dma_rx_buf != NULL_PTR))
    {
        (void)SAL_MemSet((void *)dma_rx_buf, 0, UDMA_BUFF_SIZE);
        (void)SAL_MemSet((void *)dma_tx_buf, 0, UDMA_BUFF_SIZE);
        UART_DmaTxProbe(ucCh, dma_tx_buf);
        UART_DmaRxProbe(ucCh, dma_rx_buf);
    }
}

static sint32 UART_DmaTxEnable
(
    uint8                               ucCh,
    uint32                              uiSize,
    const UDMAInformation_t *           psDmacon
)
{
    sint32  ret = -1;

    if(ucCh < UART_CH_MAX)
    {
        uart[ucCh].sTxDma.iSrcAddr  = (uint8 *)(psDmacon->iSrcAddr);
        uart[ucCh].sTxDma.iDestAddr = (uint8 *)(psDmacon->iDestAddr);
        UDMA_SetSrcAddr(&uart[ucCh].sTxDma, (uint32)(uart[ucCh].sTxDma.iSrcAddr));
        UDMA_SetDestAddr(&uart[ucCh].sTxDma, (uint32)(uart[ucCh].sTxDma.iDestAddr));
        UDMA_InterruptEnable(&uart[ucCh].sTxDma);
        UDMA_SetTransferWidth(&uart[ucCh].sTxDma, UDMA_TRANSFER_SIZE_BYTE, UDMA_TRANSFER_SIZE_BYTE);
        UDMA_SetTransferSize(&uart[ucCh].sTxDma, uiSize);
        ret = (sint32)SAL_RET_SUCCESS;
    }

    return ret;
}

static sint32 UART_DmaRxEnable
(
    uint8                               ucCh,
    uint32                              uiSize,
    const UDMAInformation_t *           psDmacon
)
{
    sint32  ret = -1;

    if(ucCh < UART_CH_MAX)
    {
        uart[ucCh].sRxDma.iSrcAddr  = (uint8 *)(psDmacon->iSrcAddr);
        uart[ucCh].sRxDma.iDestAddr = (uint8 *)(psDmacon->iDestAddr);
        UDMA_SetSrcAddr(&uart[ucCh].sRxDma, (uint32)(uart[ucCh].sRxDma.iSrcAddr));
        UDMA_SetDestAddr(&uart[ucCh].sRxDma, (uint32)(uart[ucCh].sRxDma.iDestAddr));
        UDMA_InterruptEnable(&uart[ucCh].sRxDma);
        UDMA_SetTransferWidth(&uart[ucCh].sRxDma, UDMA_TRANSFER_SIZE_BYTE, UDMA_TRANSFER_SIZE_BYTE);
        UDMA_SetTransferSize(&uart[ucCh].sRxDma, uiSize);

        // Run DMA
        UDMA_ChannelEnable(&uart[ucCh].sRxDma);
        ret = (sint32)SAL_RET_SUCCESS;
    }

    return ret;
}

static sint32 UART_DmaWrite
(
    uint8                               ucCh,
    const uint8 *                       pucBuf,
    uint32                              uiSize
)
{
    uint32  i;
    sint32  ret = -1;

    if(ucCh < UART_CH_MAX)
    {
        if(uiSize <= UDMA_BUFF_SIZE)
        {
            for(i = 0; i < uiSize; i++)
            {
                uart[ucCh].sTxDma.iSrcAddr[i] = pucBuf[i];
            }

            UDMA_SetSrcAddr(&uart[ucCh].sTxDma, (uint32)(uart[ucCh].sTxDma.iSrcAddr));
            UDMA_SetDestAddr(&uart[ucCh].sTxDma, (uint32)(uart[ucCh].sTxDma.iDestAddr));
            UDMA_InterruptEnable(&uart[ucCh].sTxDma);
            UDMA_SetTransferWidth(&uart[ucCh].sTxDma, UDMA_TRANSFER_SIZE_BYTE, UDMA_TRANSFER_SIZE_BYTE);
            UDMA_SetTransferSize(&uart[ucCh].sTxDma, uiSize);

            // Run DMA
            UDMA_ChannelEnable(&uart[ucCh].sTxDma);
            ret = (sint32)SAL_RET_SUCCESS;
        }
    }

    return ret;
}

static sint32 UART_DmaRead
(
    uint8                               ucCh,
    uint8 *                             pucBuf,
    uint32                              uiSize
)
{
    uint32  cnt;
    uint32  post_cnt;
    uint32  i;
    uint32  num_brige;
    uint32  prev_buf;
    uint32  c_size;
    uint32  u_size;
    sint32  ret;

    cnt         = 0;
    post_cnt    = 0;
    num_brige   = 0;
    prev_buf    = 0;
    c_size      = 0;
    u_size      = uiSize;

    if(ucCh < UART_CH_MAX)
    {
        c_size = UDMA_GetTransferSize(&uart[ucCh].sRxDma);

        if(uart[ucCh].sRxDma.iIsRun != 0UL)
        {
            ret = -1;
        }
        else if(uart[ucCh].sRxDma.iTransSize != c_size)
        {
            if(uart[ucCh].sRxDma.iTransSize > c_size)
            {
                cnt         = (uart[ucCh].sRxDma.iTransSize - c_size) & 0xFFFFU;
                prev_buf    = (uart[ucCh].sRxDma.iBufSize - uart[ucCh].sRxDma.iTransSize) & 0xFFFFU;

                if(u_size >= cnt)
                {
                    for (i = 0 ; i < cnt ; i++)
                    {
                        pucBuf[i] = (uint8)(uart[ucCh].sRxDma.iDestAddr[prev_buf+i]);
                    }

                    uart[ucCh].sRxDma.iTransSize = c_size;
                }
                else //else if(u_size < cnt)
                {
                    for (i = 0 ; i < u_size ; i++)
                    {
                        pucBuf[i] = (uint8)(uart[ucCh].sRxDma.iDestAddr[prev_buf+i]);
                    }

                    uart[ucCh].sRxDma.iTransSize -=  u_size;
                    cnt = u_size;
                }
                ret = (sint32)cnt;
            }
            else if(c_size > uart[ucCh].sRxDma.iTransSize)
            {
                prev_buf    = (uart[ucCh].sRxDma.iBufSize - uart[ucCh].sRxDma.iTransSize) & 0xFFFFU;
                cnt         = (uart[ucCh].sRxDma.iBufSize - c_size) & 0xFFFFU;
                post_cnt    = (uart[ucCh].sRxDma.iTransSize) & 0xFFFFU;

                if(u_size > post_cnt)
                {
                    u_size  = u_size - post_cnt;

                    for(i= 0UL ; i < post_cnt ; i++)
                    {
                        pucBuf[i] = (uint8)(uart[ucCh].sRxDma.iDestAddr[prev_buf + i]);
                        num_brige=i+1U;
                    }

                    if(u_size >= cnt)
                    {
                        for(i = 0UL ; i < cnt ; i++)
                        {
                            num_brige &= 0xFFFFU;
                            pucBuf[num_brige+i] = (uint8)(uart[ucCh].sRxDma.iDestAddr[i]);
                        }

                        uart[ucCh].sRxDma.iTransSize = c_size;
                        cnt += post_cnt;
                    }
                    else //else if(u_size < cnt)
                    {
                        for(i = 0UL ; i < u_size ; i++)
                        {
                            num_brige &= 0xFFFFU;
                            pucBuf[num_brige+i] = (uint8)(uart[ucCh].sRxDma.iDestAddr[i]);
                        }

                        uart[ucCh].sRxDma.iTransSize =  uart[ucCh].sRxDma.iBufSize - u_size;
                        cnt = u_size + post_cnt;
                    }
                }
                else
                {
                    for(i= 0UL ; i < u_size ; i++)
                    {
                        pucBuf[i]   = (uint8)(uart[ucCh].sRxDma.iDestAddr[prev_buf + i]);
                    }

                    uart[ucCh].sRxDma.iTransSize -= u_size;
                    cnt = u_size;
                }

                ret = (sint32)cnt;
            }
            else
            {
                ret = 0; // empty statement
            }
        }
        else
        {
            ret = 0; // empty statement
        }
    }
    else
    {
        ret = -1;
    }

    return ret;
}

static sint32 UART_DmaRxTriggerDma
(
    uint8                               ucCh
)
{
    uint32  dmacr;
    uint32  im;
    sint32  ret = -1;

    if(ucCh < UART_CH_MAX)
    {
        dmacr = UART_RegRead(ucCh, UART_REG_DMACR);
        dmacr |= UART_DMACR_RXDMAE;
        UART_RegWrite(ucCh, UART_REG_DMACR, dmacr);

        uart[ucCh].sRxDma.iIsRun = 1;

        im = UART_RegRead(ucCh, UART_REG_IMSC);
        im |= ~UART_INT_RXIS;
        UART_RegWrite(ucCh, UART_REG_IMSC, im);

        ret = (sint32)SAL_RET_SUCCESS;
    }

    return ret;
}

/*
***************************************************************************************************
*                                         INTERFACE FUNCTIONS
***************************************************************************************************
*/

sint32 UART_Open
(
    UartParam_t                         * pUartCfg
)
{
    uint8   ucCh;
    sint32  ret = -1;

    ucCh = pUartCfg->sCh;
    UART_StatusInit(ucCh);

    if(pUartCfg->sPortCfg <= UART_PORT_CFG_MAX)
    {
        ret = UART_Probe(pUartCfg);
    }

    return ret;
}

void UART_Close
(
    uint8                               ucCh
)
{
    sint32          iClkBusId;

    if(ucCh < UART_CH_MAX)
    {
        /* Disable the UART Interrupt */
        UART_DisableInterrupt(ucCh);

        /* Disable the UART controller Bus clock */
        iClkBusId   = (sint32)CLOCK_IOBUS_UART0 + (sint32)ucCh;
        (void)CLOCK_SetIobusPwdn(iClkBusId, TRUE);

        if(uart[ucCh].sOpMode == UART_DMA_MODE)
        {
            /* Disable the UDMA controller Bus clock */
            iClkBusId   = (sint32)CLOCK_IOBUS_UART0_DMA + (sint32)ucCh;
            (void)CLOCK_SetIobusPwdn(iClkBusId, TRUE);
        }

        (void)UART_ClearGpio(ucCh);

        /* Initialize UART Structure */
        SAL_MemSet(&uart[ucCh], 0, sizeof(UartStatus_t));

        /* UART SW Reset */
        (void)UART_Reset(ucCh);

        if(uart[ucCh].sOpMode == UART_DMA_MODE)
        {
            (void)UDMA_Reset(ucCh);
        }
    }
}


sint32 UART_Read
(
    uint8                               ucCh,
    uint8 *                             pucBuf,
    uint32                              uiSize
)
{
    uint32  i;
    sint8   getc_err;
    sint32  ret = -1;

    if((pucBuf != NULL_PTR) && (ucCh < UART_CH_MAX))
    {
        if(OFF != uart[ucCh].sIsProbed)
        {
            if(uart[ucCh].sOpMode == UART_DMA_MODE)
            {
                ret = UART_DmaRead(ucCh, pucBuf, uiSize);
            }
            else if(uart[ucCh].sOpMode == UART_INTR_MODE)
            {
                ret = UART_InterruptRead(ucCh, pucBuf, uiSize);
            }
            else
            {
                for(i = 0 ; i < uiSize ; i++)
                {
                    ret = UART_GetChar(ucCh, 0, &getc_err);

                    if(ret >= 0)
                    {
                        pucBuf[i] = (uint8)((uint32)ret & 0xFFUL);
                    }
                    else
                    {
                        break;
                    }
                }

                ret = (sint32)i;
            }
        }
    }

    return ret;
}

sint32 UART_Write
(
    uint8                               ucCh,
    const uint8 *                       pucBuf,
    uint32                              uiSize
)
{
    uint32  i;
    sint32  ret = -1;

    if(pucBuf != NULL_PTR)
    {
        if(OFF != uart[ucCh].sIsProbed)
        {
            if(ucCh < UART_CH_MAX)
            {
                if(uart[ucCh].sOpMode == UART_DMA_MODE)
                {
                    ret = UART_DmaWrite(ucCh, pucBuf, uiSize);
                }
                else if(uart[ucCh].sOpMode == UART_INTR_MODE)
                {
                    ret = UART_InterruptWrite(ucCh, pucBuf, uiSize);
                }
                else
                {
                    for(i = 0; i < uiSize; i++)
                    {
                        ret = UART_PutChar(ucCh, pucBuf[i]);
                    }
                }
            }
        }
    }

    return ret;
}

sint32 UART_GetChar
(
    uint8                               ucCh,
    uint8                               iWait,
    sint8 *                             pcErr
)
{
    uint32  data = 0;
    sint32  ret = -1;

    if(pcErr != NULL_PTR)
    {
        if((ucCh >= UART_CH_MAX) || (OFF == uart[ucCh].sIsProbed))
        {
            *pcErr = -1;
        }
        else
        {
            if(iWait == 1U)
            {
                while((UART_RegRead(ucCh, UART_REG_FR) & UART_FR_RXFE) != 0UL)
                {
                    if((UART_RegRead(ucCh, UART_REG_FR) & UART_FR_RXFE) == 0UL)
                    {
                        break;
                    }
                }
                data = UART_RegRead(ucCh, UART_REG_DR);
                data &= 0x7FFFFFFFU;
                ret = (sint32)data;
            }
            else
            {
                if((UART_RegRead(ucCh, UART_REG_FR) & UART_FR_RXFE) != 0UL)
                {
                    *pcErr = -1;
                }
                else
                {
                    data = UART_RegRead(ucCh, UART_REG_DR);
                    data &= 0x7FFFFFFFU;
                    ret = (sint32)data;
                }
            }
        }
    }

    return ret;
}

sint32 UART_PutChar
(
    uint8                               ucCh,
    uint8                               ucChar
)
{
    sint32  ret;

    if((ucCh >= UART_CH_MAX) || (OFF == uart[ucCh].sIsProbed))
    {
    	// this makes recursive call of UART_PutChar(). UART_PutChar() called in SAL_DbgReportError again.
        //(void)SAL_DbgReportError(SAL_DRVID_UART, 0UL, (uint32)SAL_ERR_INVALID_PARAMETER, __FUNCTION__);
        ret = -1;
    }
    else
    {
        while((UART_RegRead(ucCh, UART_REG_FR) & UART_FR_TXFF) != 0UL)
        {
            if((UART_RegRead(ucCh, UART_REG_FR) & UART_FR_TXFF) == 0UL)
            {
                break;
            }
        }

        UART_RegWrite(ucCh, UART_REG_DR, ucChar);
        ret = (sint32)SAL_RET_SUCCESS;
    }

    return ret;
}

void UART_Init
(
    void
)
{
    UART_Param.sCh          = UART_DEBUG_CH;
    UART_Param.sBaudrate    = 115200U;
    UART_Param.sMode        = UART_POLLING_MODE;
    UART_Param.sCtsRts      = UART_CTSRTS_OFF;
    UART_Param.sPortCfg     = UART_DEBUG_CFG;
    UART_Param.sWordLength  = WORD_LEN_8;
    UART_Param.sFIFO        = DISABLE_FIFO;
    UART_Param.s2StopBit    = TWO_STOP_BIT_OFF;
    UART_Param.sParity      = PARITY_NONE;
    UART_Param.sFnCallback  = NULL_PTR;

#if( CORTEX_M7_0==1 )
    // Reset status and close UART_CH_1, since it used in fwdn
    (void)UART_StatusInit(UART_DEBUG_CH);
    (void)UART_Close(UART_DEBUG_CH);
#endif

    // For LOG output
    (void)UART_Open(&UART_Param);
}

static void UART_ISR
(
    uint8                               ucCh
)
{
    uint32                  status;
    uint32                  imsc;
    sint32                  max_count;

    max_count   = (sint32)UART_BUFF_SIZE;
    imsc        = UART_RegRead(ucCh, UART_REG_IMSC);
    status      = UART_RegRead(ucCh, UART_REG_MIS) & imsc;

    if(status != 0UL)
    {
        do
        {
            UART_RegWrite(ucCh, UART_REG_ICR, status & ~(UART_INT_RXIS | UART_INT_RTIS | UART_INT_TXIS));

            if((status & (UART_INT_RTIS | UART_INT_RXIS)) != 0UL)
            {
                if(uart[ucCh].sOpMode == UART_DMA_MODE)
                {
                    UART_DmaRxIrq(ucCh);
                }
                else
                {
                    (void)UART_Rx(ucCh);
                }

                UART_RegWrite(ucCh, UART_REG_ICR, UART_INT_RXIS | UART_INT_RTIS);
            }

            if((status & UART_INT_TXIS) != 0UL)
            {
                //(void)UART_Tx(ucCh);
                UART_RegWrite(ucCh, UART_REG_ICR, UART_INT_TXIS);
            }

            status = UART_RegRead(ucCh, UART_REG_MIS) & imsc;

            if(max_count > (sint32)0)
            {
                max_count--;
            }
            else
            {
                break;
            }
        } while(status != 0UL);
    }
}

void UART_0_ISR
(
    void
)
{
    UART_ISR(UART_CH0);
}

void UART_1_ISR
(
    void
)
{
    UART_ISR(UART_CH1);
}

void UART_2_ISR
(
    void
)
{
    UART_ISR(UART_CH2);
}

void UART_3_ISR
(
    void
)
{
    UART_ISR(UART_CH3);
}

