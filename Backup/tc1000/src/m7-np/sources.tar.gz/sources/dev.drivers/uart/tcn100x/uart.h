/*
***************************************************************************************************
*
*   FileName : uart.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef UART_HEADER
#define UART_HEADER

#include "nvic.h"
#include "clock.h"
#include "clock_dev.h"
#include "reg_phys.h"
#include "sal_internal.h"

#ifndef ON
#define ON                              (TRUE)
#define OFF                             (FALSE)
#endif

// UART Channel

#define UART_CH0                        (0U)
#define UART_CH1                        (1U)
#define UART_CH2                        (2U)
#define UART_CH3                        (3U)
#define UART_CH_MAX                     (4U)

#define UART_POLLING_MODE               (0U)
#define UART_INTR_MODE                  (1U)
#define UART_DMA_MODE                   (2U)

#define UART_CTSRTS_ON                  (1U)
#define UART_CTSRTS_OFF                 (0U)

/*
***************************************************************************************************
*                                         UART DEFAULT SETTING
***************************************************************************************************
*/

// Set for using UART debug channel
#if ( CORTEX_M7_0 == 1 )
#define UART_DEBUG_CH                   (UART_CH1)
#define UART_DEBUG_CFG                  (1U)        // GPIO_B15, GPIO_B16
#elif ( CORTEX_M7_NP == 1 )
#define UART_DEBUG_CH                   (UART_CH2)
#define UART_DEBUG_CFG                  (2U)        // GPIO_C15, GPIO_C16
#else
#define UART_DEBUG_CH                   (UART_CH3)
#define UART_DEBUG_CFG                  (3U)        // GPIO_D15, GPIO_D16
#endif

// Uart peri clock 200MHz max
#define UART_DEBUG_CLK                  (24000000U)    // 24MHz

/*
***************************************************************************************************
*                                         REGISTERS
***************************************************************************************************
*/

// UART Register (BASE Address + Offset)
#define UART_REG_DR                     (0x00U)    // Data register
#define UART_REG_RSR                    (0x04U)    // Receive Status register
#define UART_REG_ECR                    (0x04U)    // Error Clear register
#define UART_REG_FR                     (0x18U)    // Flag register
#define UART_REG_ILPR                   (0x20U)    // IrDA Low-Power Counter Register
#define UART_REG_IBRD                   (0x24U)    // Integer Baud rate register
#define UART_REG_FBRD                   (0x28U)    // Fractional Baud rate register
#define UART_REG_LCRH                   (0x2CU)    // Line Control register
#define UART_REG_CR                     (0x30U)    // Control register
#define UART_REG_IFLS                   (0x34U)    // Interrupt FIFO Level status register
#define UART_REG_IMSC                   (0x38U)    // Interrupt Mask Set/Clear register
#define UART_REG_RIS                    (0x3cU)    // Raw Interrupt Status register
#define UART_REG_MIS                    (0x40U)    // Masked Interrupt Status register
#define UART_REG_ICR                    (0x44U)    // Interrupt Clear register
#define UART_REG_DMACR                  (0x48U)    // DMA Control register

// UART Flag Register(FR) Fields
#define UART_FR_TXFE                    (1UL << 7U)    // Transmit FIFO empty
#define UART_FR_RXFF                    (1UL << 6U)    // Receive FIFO full
#define UART_FR_TXFF                    (1UL << 5U)    // Transmit FIFO full
#define UART_FR_RXFE                    (1UL << 4U)    // Receive FIFO empty
#define UART_FR_BUSY                    (1UL << 3U)    // UART busy
#define UART_FR_CTS                     (1UL << 0U)    // Clear to send

// UART Line Control Register (LCR_H) Fields
#define UART_LCRH_SPS                   (1UL << 7U)    // Stick parity select
#define UART_LCRH_WLEN(x)               ((x) << 5U)    // Word length
#define UART_LCRH_FEN                   (1UL << 4U)    // Enable FIFOs
#define UART_LCRH_STP2                  (1UL << 3U)    // Two stop bits select
#define UART_LCRH_EPS                   (1UL << 2U)    // Even parity select
#define UART_LCRH_PEN                   (1UL << 1U)    // Parity enable
#define UART_LCRH_BRK                   (1UL << 0U)    // Send break

// UART Control Register (CR) Fields
#define UART_CR_CTSEN                   (1UL << 15U)   // CTS hardware flow control enable
#define UART_CR_RTSEN                   (1UL << 14U)   // RTS hardware flow control enable
#define UART_CR_RTS                     (1UL << 11U)   // Request to send
#define UART_CR_RXE                     (1UL << 9U)    // Receive enable
#define UART_CR_TXE                     (1UL << 8U)    // Transmit enable
#define UART_CR_LBE                     (1UL << 7U)    // Loopback enable
#define UART_CR_EN                      (1UL << 0U)    // UART enable

#define ENABLE_FIFO                     (1U)
#define DISABLE_FIFO                    (0U)

#define TWO_STOP_BIT_ON                 (1U)
#define TWO_STOP_BIT_OFF                (0U)

enum
{
    WORD_LEN_5 = 0,
    WORD_LEN_6,
    WORD_LEN_7,
    WORD_LEN_8
};

enum
{
    PARITY_NONE = 0,
    PARITY_SPACE,
    PARITY_EVEN,
    PARITY_ODD,
    PARITY_MARK
};

typedef struct UART_PARAM
{
    uint8                               sCh;
    uint32                              sBaudrate;     // Baudrate
    uint8                               sMode;         // polling or interrupt or udma
    uint8                               sCtsRts;       // on/off
    uint8                               sPortCfg;      // port selection
    uint8                               sWordLength;   // 5~6 bits
    uint8                               sFIFO;         // on/off
    uint8                               s2StopBit;     // on/off
    uint8                               sParity;       // space, even, odd, mark
    IrqHandler_t                        sFnCallback;   // callback function
} UartParam_t;

/*
***************************************************************************************************
*                                         EXTERN FUNCTIONS
***************************************************************************************************
*/

sint32 UART_Open
(
    UartParam_t                         * pUartCfg
);

void UART_Close
(
    uint8                               ucCh
);

sint32 UART_Read
(
    uint8                               ucCh,
    uint8                               *pucBuf,
    uint32                              uiSize
);

sint32 UART_Write
(
    uint8                               ucCh,
    const uint8                         *pucBuf,
    uint32                              uiSize
);

sint32 UART_GetChar
(
    uint8                               ucCh,
    uint8                               iWait,
    sint8                               *pcErr
);

sint32 UART_PutChar
(
    uint8                               ucCh,
    uint8                               ucChar
);

void UART_Init
(
    void
);

void UART_0_ISR
(
    void
);

void UART_1_ISR
(
    void
);

void UART_2_ISR
(
    void
);

void UART_3_ISR
(
    void
);

#endif /* _PLATFORM_TCC_UART_H_ */

