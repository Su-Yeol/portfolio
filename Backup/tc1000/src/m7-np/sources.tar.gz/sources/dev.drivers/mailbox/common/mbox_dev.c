/*
***************************************************************************************************
*
*   FileName : mbox_dev.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/
#if(SIC_BSP_SUPPORT_DRIVER_MBOX)
#include <sal_com.h>
#include <string.h>
//#include "gic.h"
#include <nvic.h>

#include "mbox.h"
#include "mbox_phy.h"
#include "mbox_dev.h"

static void MBOX_DevMakeCtlPacket
(
    uint32 *                            puiCtl,
    const uint32 *                      puiCmd,
    const uint8 *                       pucName
);

int32 MBOX_DevDeploySwbuf
(
    MBOXCh_t                            siCh,
    int32                               siCmdLen,
    int32                               siDatLen
);

static void MBOX_DevWordCpy
(
    uint32 *                            puiTarget,
    const uint32 *                      puiSource,
    int32                               siLen
);

static void MBOX_DevByteCpy
(
    uint8 *                             puiTarget,
    const uint8 *                       puiSource,
    int32                               siLen
);

static int32 MBOX_DevQput
(
    MBOXCh_t                            siCh,
    int32                               siDevId,
    MBOXQueue_t *                       pQueue,
    int32                               siLen
);

static int32 MBOX_DevQget
(
    MBOXCh_t                            siCh,
    int32                               siDevId,
    MBOXQueue_t *                       pQueue,
    uint32 *                            puiCmd,
    uint32 *                            puiData
);

static int32 MBOX_DevFind
(
    MBOXCh_t                            siCh,
    const MBOXMsage_t *                 pMsg
);

static int32 MBOX_DevNew
(
    MBOXCh_t                            siCh,
    const int8 *                        pcDevName
);

static int32 MBOX_DevMapGet
(
    MBOXCh_t                            siCh,
    const int8 *                        pcDevName
);

static int32 MBOX_DevMapPut
(
    MBOXCh_t                            siCh,
    const int8 *                        pcDevName,
    int32                               siIdx
);

static uint32 MBOX_DevCrc32
(
    const int8 *                        puc,
    int32                               siLen
);

static int32 MBOX_DevSendSafe
(
    const MBOXDvice_t *                 pDev,
    const uint32 *                      puiCmd,
    const uint32 *                      puiData,
    int32                               siLen
);

static MBOXDvice_t * MBOX_DevOpenSafe
(
    MBOXCh_t                            siCh,
    const int8 *                        pcDevName,
    uint8                               ucFlag
);

static int32 MBOX_DevRecvSafe
(
    const MBOXDvice_t *                 pDev,
    uint32 *                            puiCmd,
    uint32 *                            puiData
);

static int32 MBOX_DevDeploySwbufSafe
(
    MBOXCh_t                            siCh,
    int32                               siDevId,
    int32                               siDatLen
);

MBOXSpecialDev_t                        spMboxDev[MBOX_CH_MAX + 1];

static MBOXHashMap_t devIdMap[MBOX_CH_MAX][MBOX_MAX_MULTI_OPEN];

 /* ====================================================================== *
  *  COPYRIGHT (C) 1986 Gary S. Brown.  You may use this program, or       *
  *  code or tables extracted from it, as desired without restriction.     *
  *                                                                        *
  *  First, the polynomial itself and its table of feedback terms.  The    *
  *  polynomial is                                                         *
  *  X^32+X^26+X^23+X^22+X^16+X^12+X^11+X^10+X^8+X^7+X^5+X^4+X^2+X^1+X^0   *
  *                                                                        *
  *  Note that we take it "backwards" and put the highest-order term in    *
  *  the lowest-order bit.  The X^32 term is "implied"; the LSB is the     *
  *  X^31 term, etc.  The X^0 term (usually shown as "+1") results in      *
  *  the MSB being 1.                                                      *
  *                                                                        *
  *  Note that the usual hardware shift register implementation, which     *
  *  is what we're using (we're merely optimizing it by doing eight-bit    *
  *  chunks at a time) shifts bits into the lowest-order term.  In our     *
  *  implementation, that means shifting towards the right.  Why do we     *
  *  do it this way?  Because the calculated CRC must be transmitted in    *
  *  order from highest-order term to lowest-order term.  UARTs transmit   *
  *  characters in order from LSB to MSB.  By storing the CRC this way,    *
  *  we hand it to the UART in the order low-byte to high-byte; the UART   *
  *  sends each low-bit to hight-bit; and the result is transmission bit   *
  *  by bit from highest- to lowest-order term without requiring any bit   *
  *  shuffling on our part.  Reception works similarly.                    *
  *                                                                        *
  *  The feedback terms table consists of 256, 32-bit entries.  Notes:     *
  *                                                                        *
  *      The table can be generated at runtime if desired; code to do so   *
  *      is shown later.  It might not be obvious, but the feedback        *
  *      terms simply represent the results of eight shift/xor opera-      *
  *      tions for all combinations of data and CRC register values.       *
  *                                                                        *
  *      The values must be right-shifted by eight bits by the "updcrc"    *
  *      logic; the shift must be unsigned (bring in zeroes).  On some     *
  *      hardware you could probably optimize the shift in assembler by    *
  *      using byte-swap instructions.                                     *
  *      polynomial $edb88320                                              *
  *                                                                        *
  * ====================================================================== */
static uint32 MBOXCrc32Tab[] =
{
      0x00000000UL, 0x77073096UL, 0xee0e612cUL, 0x990951baUL, 0x076dc419UL,
      0x706af48fUL, 0xe963a535UL, 0x9e6495a3UL, 0x0edb8832UL, 0x79dcb8a4UL,
      0xe0d5e91eUL, 0x97d2d988UL, 0x09b64c2bUL, 0x7eb17cbdUL, 0xe7b82d07UL,
      0x90bf1d91UL, 0x1db71064UL, 0x6ab020f2UL, 0xf3b97148UL, 0x84be41deUL,
      0x1adad47dUL, 0x6ddde4ebUL, 0xf4d4b551UL, 0x83d385c7UL, 0x136c9856UL,
      0x646ba8c0UL, 0xfd62f97aUL, 0x8a65c9ecUL, 0x14015c4fUL, 0x63066cd9UL,
      0xfa0f3d63UL, 0x8d080df5UL, 0x3b6e20c8UL, 0x4c69105eUL, 0xd56041e4UL,
      0xa2677172UL, 0x3c03e4d1UL, 0x4b04d447UL, 0xd20d85fdUL, 0xa50ab56bUL,
      0x35b5a8faUL, 0x42b2986cUL, 0xdbbbc9d6UL, 0xacbcf940UL, 0x32d86ce3UL,
      0x45df5c75UL, 0xdcd60dcfUL, 0xabd13d59UL, 0x26d930acUL, 0x51de003aUL,
      0xc8d75180UL, 0xbfd06116UL, 0x21b4f4b5UL, 0x56b3c423UL, 0xcfba9599UL,
      0xb8bda50fUL, 0x2802b89eUL, 0x5f058808UL, 0xc60cd9b2UL, 0xb10be924UL,
      0x2f6f7c87UL, 0x58684c11UL, 0xc1611dabUL, 0xb6662d3dUL, 0x76dc4190UL,
      0x01db7106UL, 0x98d220bcUL, 0xefd5102aUL, 0x71b18589UL, 0x06b6b51fUL,
      0x9fbfe4a5UL, 0xe8b8d433UL, 0x7807c9a2UL, 0x0f00f934UL, 0x9609a88eUL,
      0xe10e9818UL, 0x7f6a0dbbUL, 0x086d3d2dUL, 0x91646c97UL, 0xe6635c01UL,
      0x6b6b51f4UL, 0x1c6c6162UL, 0x856530d8UL, 0xf262004eUL, 0x6c0695edUL,
      0x1b01a57bUL, 0x8208f4c1UL, 0xf50fc457UL, 0x65b0d9c6UL, 0x12b7e950UL,
      0x8bbeb8eaUL, 0xfcb9887cUL, 0x62dd1ddfUL, 0x15da2d49UL, 0x8cd37cf3UL,
      0xfbd44c65UL, 0x4db26158UL, 0x3ab551ceUL, 0xa3bc0074UL, 0xd4bb30e2UL,
      0x4adfa541UL, 0x3dd895d7UL, 0xa4d1c46dUL, 0xd3d6f4fbUL, 0x4369e96aUL,
      0x346ed9fcUL, 0xad678846UL, 0xda60b8d0UL, 0x44042d73UL, 0x33031de5UL,
      0xaa0a4c5fUL, 0xdd0d7cc9UL, 0x5005713cUL, 0x270241aaUL, 0xbe0b1010UL,
      0xc90c2086UL, 0x5768b525UL, 0x206f85b3UL, 0xb966d409UL, 0xce61e49fUL,
      0x5edef90eUL, 0x29d9c998UL, 0xb0d09822UL, 0xc7d7a8b4UL, 0x59b33d17UL,
      0x2eb40d81UL, 0xb7bd5c3bUL, 0xc0ba6cadUL, 0xedb88320UL, 0x9abfb3b6UL,
      0x03b6e20cUL, 0x74b1d29aUL, 0xead54739UL, 0x9dd277afUL, 0x04db2615UL,
      0x73dc1683UL, 0xe3630b12UL, 0x94643b84UL, 0x0d6d6a3eUL, 0x7a6a5aa8UL,
      0xe40ecf0bUL, 0x9309ff9dUL, 0x0a00ae27UL, 0x7d079eb1UL, 0xf00f9344UL,
      0x8708a3d2UL, 0x1e01f268UL, 0x6906c2feUL, 0xf762575dUL, 0x806567cbUL,
      0x196c3671UL, 0x6e6b06e7UL, 0xfed41b76UL, 0x89d32be0UL, 0x10da7a5aUL,
      0x67dd4accUL, 0xf9b9df6fUL, 0x8ebeeff9UL, 0x17b7be43UL, 0x60b08ed5UL,
      0xd6d6a3e8UL, 0xa1d1937eUL, 0x38d8c2c4UL, 0x4fdff252UL, 0xd1bb67f1UL,
      0xa6bc5767UL, 0x3fb506ddUL, 0x48b2364bUL, 0xd80d2bdaUL, 0xaf0a1b4cUL,
      0x36034af6UL, 0x41047a60UL, 0xdf60efc3UL, 0xa867df55UL, 0x316e8eefUL,
      0x4669be79UL, 0xcb61b38cUL, 0xbc66831aUL, 0x256fd2a0UL, 0x5268e236UL,
      0xcc0c7795UL, 0xbb0b4703UL, 0x220216b9UL, 0x5505262fUL, 0xc5ba3bbeUL,
      0xb2bd0b28UL, 0x2bb45a92UL, 0x5cb36a04UL, 0xc2d7ffa7UL, 0xb5d0cf31UL,
      0x2cd99e8bUL, 0x5bdeae1dUL, 0x9b64c2b0UL, 0xec63f226UL, 0x756aa39cUL,
      0x026d930aUL, 0x9c0906a9UL, 0xeb0e363fUL, 0x72076785UL, 0x05005713UL,
      0x95bf4a82UL, 0xe2b87a14UL, 0x7bb12baeUL, 0x0cb61b38UL, 0x92d28e9bUL,
      0xe5d5be0dUL, 0x7cdcefb7UL, 0x0bdbdf21UL, 0x86d3d2d4UL, 0xf1d4e242UL,
      0x68ddb3f8UL, 0x1fda836eUL, 0x81be16cdUL, 0xf6b9265bUL, 0x6fb077e1UL,
      0x18b74777UL, 0x88085ae6UL, 0xff0f6a70UL, 0x66063bcaUL, 0x11010b5cUL,
      0x8f659effUL, 0xf862ae69UL, 0x616bffd3UL, 0x166ccf45UL, 0xa00ae278UL,
      0xd70dd2eeUL, 0x4e048354UL, 0x3903b3c2UL, 0xa7672661UL, 0xd06016f7UL,
      0x4969474dUL, 0x3e6e77dbUL, 0xaed16a4aUL, 0xd9d65adcUL, 0x40df0b66UL,
      0x37d83bf0UL, 0xa9bcae53UL, 0xdebb9ec5UL, 0x47b2cf7fUL, 0x30b5ffe9UL,
      0xbdbdf21cUL, 0xcabac28aUL, 0x53b39330UL, 0x24b4a3a6UL, 0xbad03605UL,
      0xcdd70693UL, 0x54de5729UL, 0x23d967bfUL, 0xb3667a2eUL, 0xc4614ab8UL,
      0x5d681b02UL, 0x2a6f2b94UL, 0xb40bbe37UL, 0xc30c8ea1UL, 0x5a05df1bUL,
      0x2d02ef8dUL
};

/*
***************************************************************************************************
*                                      <MBOX_DevInit>
*
* This function initializes Mailbox hardware.
*
* @param    siCh  [in] A Mailbox channel to be initialized.
* @param    uiIlv [in] An interrupt Level for received command fifo.
* @param    ucOpn [in] The number of virtual devices per Mailbox channel.
* @param    pFunc [in] A pointer of callbacker functions.
* @return   < 0 on error, otherwise MBOX_SUCCESS.
*
* Notes
*
***************************************************************************************************
*/

int32 MBOX_DevInit
(
    MBOXCh_t                            siCh,
    uint32                              uiIlv,
    uint32                              ucOpn,
    const MBOXCallback_t *              pFunc
)
{
    int32 ret;
    uint32 ctrl;

    ret = MBOX_SUCCESS;
    ctrl = 0UL;
    ret = MBOX_PhyReady(siCh, ucOpn);

    if (ret == MBOX_SUCCESS)
    {
        ctrl = MBOX_CMD_FLUSH_BIT|MBOX_DAT_FLUSH_BIT|MBOX_RD_IEN_BIT|uiIlv;

        if(pFunc != (void*) 0)
        {
            mboxInfo[siCh].mbOsfn.osInit = pFunc->osInit;
            mboxInfo[siCh].mbOsfn.wrLock = pFunc->wrLock;
            mboxInfo[siCh].mbOsfn.wrUnlk = pFunc->wrUnlk;
            mboxInfo[siCh].mbOsfn.rsInit = pFunc->rsInit;
            mboxInfo[siCh].mbOsfn.rdWake = pFunc->rdWake;
            mboxInfo[siCh].mbOsfn.rdWait = pFunc->rdWait;
            mboxInfo[siCh].mbOsfn.wsInit = pFunc->wsInit;
            mboxInfo[siCh].mbOsfn.wrWake = pFunc->wrWake;
            mboxInfo[siCh].mbOsfn.wrWclr = pFunc->wrWclr;
            mboxInfo[siCh].mbOsfn.wrWait = pFunc->wrWait;
            mboxInfo[siCh].mbIntlv = uiIlv;

            MBOX_DevPtrCallVoid(mboxInfo[siCh].mbOsfn.osInit, (uint32 *) &mboxInfo[siCh].mbLock)

            if (mboxInfo[siCh].mbOsfn.wsInit != (void*)0)
            {
                MBOX_DevPtrCallVoid(mboxInfo[siCh].mbOsfn.wsInit, (uint32 *) &mboxInfo[siCh].mbSiid);
                ctrl = ctrl | MBOX_WR_IEN_BIT;
            }
            else
            {
                MBOX_D("not-block write mode\n");
            }
        }
        else
        {
            MBOX_D("callback is null\n");
        }

        MBOX_BITCLR(mboxInfo[siCh].mbBase->mboxCtlCmd.nREG, ctrl);
        MBOX_BITSET(mboxInfo[siCh].mbBase->mboxCtlCmd.nREG, ctrl);

        if(mboxInfo[siCh].mbBase != (void *)0)
        {
            mboxInfo[siCh].mbBase->mboxCtlSts.nREG = (mboxInfo[siCh].mbBase->mboxCtlSts.nREG & ~MBOX_BIT(0U)) | (MBOX_ENABLE & MBOX_BIT(0U));
        }
        else
        {
            ret = MBOX_ERR_NOT_INITIALIZE;
        }
    }
    else
    {
        MBOX_E("mbox_phy_ready fail [%d]\n", ret);
    }

    return ret;
}

/*
***************************************************************************************************
*                                      <MBOX_DevOpen>
*
* This function creates virtual device for specific mailbox channel.
*
* @param    siCh      [in] A Mailbox channel to be opened.
* @param    pcDevName [in] A virtual device name for specific Mailbox channel.
* @param    ucFlag    [in] An option flags (reserved).
* @return   < 0 on error, otherwise MBOX_SUCCESS.
*
* Notes
*
***************************************************************************************************
*/

MBOXDvice_t * MBOX_DevOpen
(
    MBOXCh_t                            siCh,
    const int8 *                        pcDevName,
    uint8                               ucFlag
)
{
    MBOXDvice_t *   mboxDev;

    mboxDev = NULL;

    if ((siCh < MBOX_CH_MAX) && (pcDevName != (void *) 0))
    {
        mboxDev = MBOX_DevOpenSafe(siCh, pcDevName, ucFlag);
    }
    else
    {
        MBOX_E("open fail siCh[%d] pcDevName[%s]\n", siCh, pcDevName);
    }

    return mboxDev;
}

/*
***************************************************************************************************
*                                      <MBOX_DevSend>
*
* This function sends 8 word command and 128 word data to Application Processor.
*
* @param    pDev    [in] A virtual device opened, which data must be sent.
* @param    puiCmd  [in] A pointer of 8 word command (fixed length).
* @param    puiData [in] A pointer of 128 word data.
* @param    siLen   [in] A data length of puiData within 128 word.
* @return   < 0 on error, otherwise MBOX_SUCCESS.
*
* Notes 1word = 4byte.
*
***************************************************************************************************
*/

int32 MBOX_DevSend
(
    const MBOXDvice_t *                 pDev,
    const uint32 *                      puiCmd,
    const uint32 *                      puiData,
    int32                               siLen
)
{
    int32   ret;

    ret = MBOX_SUCCESS;

    if ((pDev != (void *)0) && (puiData != (void *)0) && ((siLen <= MBOX_DATA_FIFO_SIZE) && (siLen > 0)))
    {
        if ((pDev->dvIden >= 0) && (pDev->dvChnl < MBOX_CH_MAX))
        {
            ret = MBOX_DevSendSafe(pDev, puiCmd, puiData, siLen);
        }
        else
        {
            ret = MBOX_ERR_DEV_NOT_OPENED;
            MBOX_E("devId %d, ch %d \n", pDev->dvIden, pDev->dvChnl);
        }
    }
    else
    {
        ret = MBOX_ERR_ARGUMENT;
        MBOX_E("send fail pDev[0x%08X] puiData[0x%08X] siLen[%d] invalid param\n", pDev, puiData, siLen);
    }

    return ret;
}

/*
***************************************************************************************************
*                                      <MBOX_DevSendCmd>
*
* This function sends 8 word command to Application Processor.
*
* @param    pDev    [in] A virtual device opened, which data must be sent.
* @param    puiCmd  [in] A pointer of 8 word command (fixed length).
* @return   < 0 on error, otherwise MBOX_SUCCESS.
*
* Notes 1word = 4byte.
*
***************************************************************************************************
*/

int32 MBOX_DevSendCmd
(
    const MBOXDvice_t *                 pDev,
    const uint32 *                      puiCmd
)
{
    int32   ret;

    ret  = MBOX_SUCCESS;

    if ((pDev != (void *)0) && (puiCmd != (void *)0))
    {
        if ((pDev->dvIden >= 0) && (pDev->dvChnl < MBOX_CH_MAX))
        {
            ret = MBOX_DevSendSafe(pDev, puiCmd, NULL, 0);
        }
        else
        {
            ret = MBOX_ERR_DEV_NOT_OPENED;
            MBOX_E("devId %d, ch %d \n", pDev->dvIden, pDev->dvChnl);
        }
    }
    else
    {
        ret = MBOX_ERR_ARGUMENT;
        MBOX_E("send fail dev[0x%08X] puiCmd[0x%08X] invalid param\n", pDev, puiCmd);
    }

    return ret;
}

/*
***************************************************************************************************
*                                      <MBOX_DevSendData>
*
* This function sends 8 word command and 128 word data to Application Processor.
*
* @param    pDev    [in] A virtual device opened, which data must be sent.
* @param    puiData [in] A pointer of 128 word data.
* @param    siLen   [in] A data length of puiData within 128 word.
* @return   < 0 on error, otherwise MBOX_SUCCESS.
*
* Notes 1word = 4byte.
*
***************************************************************************************************
*/

int32 MBOX_DevSendData
(
    const MBOXDvice_t *                 pDev,
    const uint32 *                      puiData,
    int32                               siLen
)
{
    int32   ret;

    ret = MBOX_SUCCESS;

    if ((pDev != (void *)0) && (puiData != (void *)0) && ((siLen <= MBOX_DATA_FIFO_SIZE) && (siLen > 0)))
    {
        if ((pDev->dvIden >= 0) && (pDev->dvChnl < MBOX_CH_MAX))
        {
            ret = MBOX_DevSendSafe(pDev, NULL, puiData, siLen);
        }
        else
        {
            ret = MBOX_ERR_DEV_NOT_OPENED;
            MBOX_E("devId %d, ch %d \n", pDev->dvIden, pDev->dvChnl);
        }
    }
    else
    {
        ret = MBOX_ERR_ARGUMENT;
        MBOX_E("send fail dev[0x%08X] puiData[0x%08X] siLen[%d] invalid param\n", pDev, puiData, siLen);
    }

    return ret;
}

/*
***************************************************************************************************
*                                      <MBOX_DevRecv>
*
* This function receives 8 word command and 128 word data from Application Processor.
*
* @param    pDev    [in] A virtual device opened, which data must be sent.
* @param    puiCmd  [in] A pointer of 128 word data.
* @param    puiData [in] A data length of puiData within 128 word.
* @return   < 0 on error, == 0 if only 8 word command, > 0 data length within 128 word.
*
* Notes 1word = 4byte.
*
***************************************************************************************************
*/

int32 MBOX_DevRecv
(
    const MBOXDvice_t *                 pDev,
    uint32 *                            puiCmd,
    uint32 *                            puiData
)
{
    int32 ret;

    ret = MBOX_DEV_GET_AGAIN;

    if ((pDev != (void *)0) && ((puiCmd != (void *)0) || (puiData !=(void *)0)))
    {
        if ((pDev->dvIden >= 0) && (pDev->dvChnl < MBOX_CH_MAX))
        {
            ret = MBOX_DevRecvSafe(pDev, puiCmd, puiData);
        }
        else
        {
            ret = MBOX_ERR_DEV_NOT_OPENED;
        }
    }
    else
    {
        ret = MBOX_ERR_ARGUMENT;
    }

    return ret;
}

/*
***************************************************************************************************
*                                      <MBOX_DevRecvCmd>
*
* This function receives 8 word command and 128 word data from Application Processor.
*
* @param    pDev    [in] A virtual device opened, which data must be sent.
* @param    puiCmd  [in] A pointer of 128 word data.
* @return   < 0 on error, == 0 if only 8 word command.
*
* Notes 1word = 4byte.
*
***************************************************************************************************
*/

int32 MBOX_DevRecvCmd
(
    const MBOXDvice_t *                 pDev,
    uint32 *                            puiCmd
)
{
    return MBOX_DevRecv(pDev, puiCmd, NULL);
}

/*
***************************************************************************************************
*                                      <MBOX_DevRecvData>
*
* This function receives 8 word command and 128 word data from Application Processor.
*
* @param    pDev    [in] A virtual device opened, which data must be sent.
* @param    puiData [in] A data length of puiData within 128 word.
* @return   < 0 on error, > 0 data length within 128 word.
*
* Notes 1word = 4byte.
*
***************************************************************************************************
*/

int32 MBOX_DevRecvData
(
    const MBOXDvice_t *                 pDev,
    uint32 *                            puiData
)
{
    return MBOX_DevRecv(pDev, NULL, puiData);
}


/*
***************************************************************************************************
*                                      <MBOX_DevMakeCtlPacket>
*
* This function constructs control command to use virtaul device.
*
* @param    puiCtl    [in] A pointer of 8 word target command to be sent.
* @param    puiCmd    [in] A pointer of 8 word source commend to be copied.
* @param    pucName   [in] A pointer of virtual device name.
* @return
*
* Notes
*
***************************************************************************************************
*/

static void MBOX_DevMakeCtlPacket
(
    uint32 *                            puiCtl,
    const uint32 *                      puiCmd,
    const uint8 *                       pucName
)
{
    uint8 * scmd;

    scmd    = (uint8 *) puiCtl;
    MBOX_DevByteCpy(&scmd[2],  &pucName[4], 1);
    MBOX_DevByteCpy(&scmd[3],  &pucName[5], 1);
    MBOX_DevByteCpy(&scmd[28], &pucName[0], 1);
    MBOX_DevByteCpy(&scmd[29], &pucName[1], 1);
    MBOX_DevByteCpy(&scmd[30], &pucName[2], 1);
    MBOX_DevByteCpy(&scmd[31], &pucName[3], 1);

    if ((puiCmd !=(void *)0))
    {
        MBOX_DevWordCpy(&puiCtl[1],  puiCmd, 6);
    }
}


/*
***************************************************************************************************
*                                      <MBOX_DevDeploySwbuf>
*
* This function puts received data into software buffer.
*
* @param    siCh     [in] A Mailbox channel that data has been transmitted.
* @param    siLen    [in] A length of received data.
* @return   < 0 on error, otherwise MBOX_SUCCESS.
*
* Notes
*
***************************************************************************************************
*/

int32 MBOX_DevDeploySwbuf
(
    MBOXCh_t                            siCh,
    int32                               siCmdLen,
    int32                               siDatLen
)
{
    int32 ret;
    int32 devId;

    ret     = MBOX_SUCCESS;
    devId   = -1;

    if ((mboxInfo[siCh].mbDlst != (void *)0) && ((siCmdLen <= MBOX_CMD_FIFO_SIZE) && (siCmdLen > 0)))
    {
        devId = MBOX_DevFind(siCh, &mboxInfo[siCh].mbMesg);
        ret = MBOX_DevDeploySwbufSafe(siCh, devId, siDatLen);
    }
    else
    {
        ret = MBOX_ERR_NOT_INITIALIZE;
        MBOX_E("dev no initialized siCmdLen[%d]\n", siCmdLen);
    }

    return ret;
}

/*
***************************************************************************************************
*                                      <MBOX_DevQput>
*
* This function puts received data into software queue.
*
* @param    siCh     [in] A Mailbox channel that data has been transmitted.
* @param    siDevId  [in] A virtual device identifier to be opened.
* @param    pQueue   [in] A pointer of queue for data to be stored.
* @param    siLen    [in] A length of data received.
* @return   < 0 on error, otherwise MBOX_SUCCESS.
*
* Notes
*
***************************************************************************************************
*/
static int32 MBOX_DevQput
(
    MBOXCh_t                            siCh,
    int32                               siDevId,
    MBOXQueue_t *                       pQueue,
    int32                               siLen
)
{
    int32 ret;

    ret = MBOX_SUCCESS;

    if ((siDevId >= 0) && (pQueue != (void*)0))
    {
        if (((pQueue->qiRear + 1) % MBOX_MAX_QUEUE_SIZE) == pQueue->qiFrnt)
        {
            ret = MBOX_ERR_QUEUE_FULL;
            MBOX_E("full for ch[%d] siDevId[%d]\n", (int32) siCh, siDevId);
        }
        else
        {
            pQueue->qiRear = ((pQueue->qiRear + 1) % MBOX_MAX_QUEUE_SIZE);
            pQueue->qiData[pQueue->qiRear].mmDlen = 0;
            MBOX_DevWordCpy(pQueue->qiData[pQueue->qiRear].mmCmnd, mboxInfo[siCh].mbMesg.mmCmnd, MBOX_CMD_FIFO_SIZE);

            if ((siLen <= MBOX_DATA_FIFO_SIZE) && (siLen > 0))
            {
                pQueue->qiData[pQueue->qiRear].mmDlen = siLen;
                MBOX_DevWordCpy(pQueue->qiData[pQueue->qiRear].mmData, mboxInfo[siCh].mbMesg.mmData, siLen);
            }
        }
    }
    else
    {
        ret = MBOX_ERR_NO_SUCH_DEV;
        MBOX_E("no such device siDev[%d]\n", (sint32) siDevId);
    }

    return ret;
}

/*
***************************************************************************************************
*                                      <MBOX_DevQget>
*
* This function gets received data form software queue.
*
* @param    siCh     [in] A Mailbox channel that data has been transmitted.
* @param    siDevId  [in] A virtual device identifier to be opened.
* @param    puiCmd   [in] A pointer of 8 word command to store received command.
* @param    puiData  [in] A pointer of 128 word data to store received data.
* @return   < 0 on error, otherwise MBOX_SUCCESS.
*
* Notes 1word = 4byte.
*
***************************************************************************************************
*/

static int32 MBOX_DevQget
(
    MBOXCh_t                            siCh,
    int32                               siDevId,
    MBOXQueue_t *                       pQueue,
    uint32 *                            puiCmd,
    uint32 *                            puiData
)
{
    int32 ret;

    (void) siCh;
    (void) siDevId;

    ret = MBOX_DEV_GET_AGAIN;

    if ((pQueue !=(void *)0) && ((puiCmd !=(void *)0) || (puiData !=(void *)0)))
    {
        if (pQueue->qiFrnt == pQueue->qiRear)
        {
            MBOX_D("empty for ch[%d] siDevId[%d]\n", (sint32) siCh, siDevId);
        }
        else
        {
            pQueue->qiFrnt = ((pQueue->qiFrnt + 1) % MBOX_MAX_QUEUE_SIZE);
            MBOX_DevWordCpy(puiCmd, &pQueue->qiData[pQueue->qiFrnt].mmCmnd[1], (MBOX_CMD_FIFO_SIZE - 2L));

            if ((pQueue->qiData[pQueue->qiFrnt].mmDlen <= MBOX_DATA_FIFO_SIZE) && (pQueue->qiData[pQueue->qiFrnt].mmDlen > 0))
            {
                MBOX_DevWordCpy(puiData, pQueue->qiData[pQueue->qiFrnt].mmData, pQueue->qiData[pQueue->qiFrnt].mmDlen);
            }

            ret = pQueue->qiData[pQueue->qiFrnt].mmDlen;
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                      <MBOX_DevRegisterIrq>
*
* This function enables IRQ and registers callback function to be called by IRQ.
*
* @param    siCh     [in] A Mailbox channel that data has been transmitted.
* @param    uiNo     [in] A interrupt number to call interrupt service routine.
* @param    fnIsr    [in] A pointer of interrupt service routine.
* @return
*
* Notes
*
***************************************************************************************************
*/

void MBOX_DevRegisterIrq
(
    void
)
{
    NVIC_IntVectSet(MBOX_TX_IRQn, (IrqHandler_t)MBOX_DevIsrWriteconfirm);
	NVIC_IntSrcEn(MBOX_TX_IRQn);

    NVIC_IntVectSet(MBOX_RX_IRQn, (IrqHandler_t)MBOX_DevIsrReceived);
	NVIC_IntSrcEn(MBOX_RX_IRQn);

    SAL_WriteReg(0x3FFF, MBOX_INT_SRC_MASK_REG);
}

/*
***************************************************************************************************
*                                      <MBOX_DevWordCpy>
*
* This function copies words from source to target.
*
* @param    puiTarget   [in] A pointer of target.
* @param    puiSource   [in] A pointer of source.
* @param    siLen       [in] A length of words to be copied.
* @return
*
* Notes
*
***************************************************************************************************
*/

static void MBOX_DevWordCpy
(
    uint32 *                            puiTarget,
    const uint32 *                      puiSource,
    int32                               siLen
)
{
    int32 idx;

    if ((puiTarget != (void *)0) && (puiSource !=(void *)0))
    {
        for (idx = 0 ; idx < siLen ; idx++)
        {
            puiTarget[idx]  = puiSource[idx];
        }
    }
    else
    {
        MBOX_E("invalid param target[0x%08X] source[0x%08X]\n", puiTarget, puiSource);
    }
}

/*
***************************************************************************************************
*                                      <MBOX_DevByteCpy>
*
* This function copies bytes from source to target.
*
* @param    puiTarget   [in] A pointer of target.
* @param    puiSource   [in] A pointer of source.
* @param    siLen       [in] A length of bytes to be copied.
* @return
*
* Notes
*
***************************************************************************************************
*/

static void MBOX_DevByteCpy
(
    uint8 *                             puiTarget,
    const uint8 *                       puiSource,
    int32                               siLen
)
{
    int32 idx;

    if ((puiTarget != (void *)0) && (puiSource != (void *)0))
    {
        for (idx = 0 ; idx < siLen ; idx++)
        {
            puiTarget[idx] = puiSource[idx];
        }
    }
    else
    {
        MBOX_E("invalid param target[0x%08X] source[0x%08X]\n", puiTarget, puiSource);
    }

}

/*
***************************************************************************************************
*                                      <MBOX_DevFind>
*
* This function writes/reads Mailbox registers.
*
* @param    siCh        [in] A Mailbox channel, which data is arrived.
* @param    pMsg        [in] A pointer of received data.
* @return
*
* Notes
*
***************************************************************************************************
*/

static int32 MBOX_DevFind
(
    MBOXCh_t                            siCh,
    const MBOXMsage_t *                 pMsg
)
{
    uint8 hkey[MBOX_MAX_KEY_SIZE + 1];

    hkey[0]  = (uint8) ((pMsg->mmCmnd[7] & 0x000000FFUL) >> 0UL);
    hkey[1]  = (uint8) ((pMsg->mmCmnd[7] & 0x0000FF00UL) >> 8UL);
    hkey[2]  = (uint8) ((pMsg->mmCmnd[7] & 0x00FF0000UL) >> 16UL);
    hkey[3]  = (uint8) ((pMsg->mmCmnd[7] & 0xFF000000UL) >> 24UL);
    hkey[4]  = (uint8) ((pMsg->mmCmnd[0] & 0x00FF0000UL) >> 16UL);
    hkey[5]  = (uint8) ((pMsg->mmCmnd[0] & 0xFF000000UL) >> 24UL);

    return MBOX_DevMapGet(siCh, (int8 *) hkey);
}

/*
***************************************************************************************************
*                                      <MBOX_DevNew>
*
* This function allocates memory for virtual device.
*
* @param    siCh        [in] A Mailbox channel to be used.
* @param    pcDevName   [in] A pointer of device name.
* @return
*
* Notes
*
***************************************************************************************************
*/

static int32 MBOX_DevNew
(
    MBOXCh_t                            siCh,
    const int8 *                        pcDevName
)
{
    uint32  idx;
    int32   ret;

    ret = MBOX_DEV_ERR_FULL;
    ret = MBOX_DevMapGet(siCh, pcDevName);

    if (ret < 0)
    {
        for (idx = 0 ; idx < MBOX_MAX_MULTI_OPEN ; idx++)
        {
            if (mboxInfo[siCh].mbDlst[idx].dvIden < 0)
            {
                ret = MBOX_DevMapPut(siCh, pcDevName, (int32) idx);
                break;
            }
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                      <MBOX_DevMapGet>
*
* This function finds device opened from hash map.
*
* @param    siCh        [in] A Mailbox channel to be used.
* @param    pcDevName   [in] A pointer of device name.
* @return
*
* Notes: Open source
* There are no restriction to use this logic according to http:\\github.com\petewarden\c_hashmap
*
***************************************************************************************************
*/

static int32 MBOX_DevMapGet
(
    MBOXCh_t                            siCh,
    const int8 *                        pcDevName
)
{
    int32   ret;
    uint32  hkey;
    uint32  idx;

    ret = -1;
    hkey = 0UL;

    if ((siCh < MBOX_CH_MAX))
    {
        if ((pcDevName != (void *)0))
        {
            hkey = MBOX_DevCrc32(pcDevName, MBOX_MAX_KEY_SIZE);
            /* Robert Jenkins' 32 bit Mix Function */
            hkey += (hkey << 12UL);
            hkey ^= (hkey >> 22UL);
            hkey += (hkey << 4UL);
            hkey ^= (hkey >> 9UL);
            hkey += (hkey << 10UL);
            hkey ^= (hkey >> 2UL);
            hkey += (hkey << 7UL);
            hkey ^= (hkey >> 12UL);
            /* Knuth's Multiplicative Method */
            hkey = (hkey >> 3UL) * 2654435761UL;
            hkey = hkey % MBOX_MAX_MULTI_OPEN;

            for (idx = 0 ; idx < MBOX_MAX_MULTI_OPEN ; idx++)
            {
                if ((devIdMap[siCh][hkey].hmInuse == 1) &&
                    (pcDevName[0] == devIdMap[siCh][hkey].hmSrkey[0]) &&
                    (pcDevName[1] == devIdMap[siCh][hkey].hmSrkey[1]) &&
                    (pcDevName[2] == devIdMap[siCh][hkey].hmSrkey[2]) &&
                    (pcDevName[3] == devIdMap[siCh][hkey].hmSrkey[3]) &&
                    (pcDevName[4] == devIdMap[siCh][hkey].hmSrkey[4]) &&
                    (pcDevName[5] == devIdMap[siCh][hkey].hmSrkey[5]))
                {
                    ret = devIdMap[siCh][hkey].hmValue;
                    break;
                }
                else
                {
                    hkey = (hkey + 1UL) % MBOX_MAX_MULTI_OPEN;
                    ret = MBOX_DEV_ERR_KEY_NOTINUSED;
                }
            }
        }
        else
        {
            ret = MBOX_DEV_ERR_INVALID_NAME;
        }
    }
    else
    {
        ret = MBOX_DEV_ERR_INVALID_CH;
    }

    return ret;
}

/*
***************************************************************************************************
*                                      <MBOX_DevMapPut>
*
* This function stores device opened into hash map.
*
* @param    siCh        [in] A Mailbox channel to be used.
* @param    pcDevName   [in] A pointer of device name.
* @param    siIdx         [in] A device number to be opened.
* @return
*
* Notes: Open source
* There are no restriction to use this logic according to http:\\github.com\petewarden\c_hashmap
*
***************************************************************************************************
*/

static int32 MBOX_DevMapPut
(
    MBOXCh_t                            siCh,
    const int8 *                        pcDevName,
    int32                               siIdx
)
{
    int32   ret;
    uint32  hkey;
    uint32  idx;

    ret = -1;
    hkey = 0L;

    if ((siCh < MBOX_CH_MAX))
    {
        if ((pcDevName != (void *)0))
        {
            hkey = MBOX_DevCrc32(pcDevName, MBOX_MAX_KEY_SIZE);
            /* Robert Jenkins' 32 bit Mix Function */
            hkey += (hkey << 12uL);
            hkey ^= (hkey >> 22UL);
            hkey += (hkey << 4UL);
            hkey ^= (hkey >> 9UL);
            hkey += (hkey << 10UL);
            hkey ^= (hkey >> 2UL);
            hkey += (hkey << 7UL);
            hkey ^= (hkey >> 12UL);
            /* Knuth's Multiplicative Method */
            hkey = (hkey >> 3UL) * 2654435761UL;
            hkey = hkey % MBOX_MAX_MULTI_OPEN;

            for (idx = 0 ; idx < MBOX_MAX_MULTI_OPEN ; idx++)
            {
                if (devIdMap[siCh][hkey].hmInuse == 0)
                {
                    devIdMap[siCh][hkey].hmInuse     = 1;
                    devIdMap[siCh][hkey].hmValue     = siIdx;
                    devIdMap[siCh][hkey].hmSrkey[0]  = pcDevName[0];
                    devIdMap[siCh][hkey].hmSrkey[1]  = pcDevName[1];
                    devIdMap[siCh][hkey].hmSrkey[2]  = pcDevName[2];
                    devIdMap[siCh][hkey].hmSrkey[3]  = pcDevName[3];
                    devIdMap[siCh][hkey].hmSrkey[4]  = pcDevName[4];
                    devIdMap[siCh][hkey].hmSrkey[5]  = pcDevName[5];
                    ret = devIdMap[siCh][hkey].hmValue;
                    break;
                }
                else
                {
                    hkey = (hkey + 1LU) % MBOX_MAX_MULTI_OPEN;
                    ret = MBOX_DEV_ERR_HASH_MAP_FULL;
                }
            }
        }
        else
        {
            ret = MBOX_DEV_ERR_INVALID_NAME;
        }
    }
    else
    {
        ret = MBOX_DEV_ERR_INVALID_CH;
    }

    return ret;
}

/*
***************************************************************************************************
*                                      <MBOX_DevCrc32>
*
* This function creates crc32 code for hash map.
*
* @param    puc         [in] A pointer of device name to be hashed.
* @param    siLen       [in] A length of device name.
* @return
*
* Notes: Open source
* There are no restriction to use this logic according to http:\\github.com\petewarden\c_hashmap
*
***************************************************************************************************
*/

static uint32 MBOX_DevCrc32
(
    const int8 *                        puc,
    int32                               siLen
)
{
    int32   i;
    uint32  crc32val;

    crc32val = 0;

    for (i = 0 ;  i < siLen ;  i ++)
    {
        crc32val = MBOXCrc32Tab[(crc32val ^ (const uint8) puc[i]) & 0xffUL] ^ (crc32val >> 8UL);
    }

    return crc32val;
}

/*
***************************************************************************************************
*                                      <MBOX_DevOpenSafe>
*
* This function creates virtual device for specific mailbox channel.
*
* @param    siCh      [in] A Mailbox channel to be opened.
* @param    pcDevName [in] A virtual device name for specific Mailbox channel.
* @param    ucFlag    [in] An option flags (reserved).
* @return   < 0 on error, otherwise MBOX_SUCCESS.
*
* Notes
*
***************************************************************************************************
*/

static MBOXDvice_t * MBOX_DevOpenSafe
(
    MBOXCh_t                            siCh,
    const int8 *                        pcDevName,
    uint8                               ucFlag
)
{
    int32           devId;
    MBOXDvice_t *   mboxDev;

    devId   = -1;
    mboxDev = NULL;

    MBOX_DevPtrCallVoid(mboxInfo[siCh].mbOsfn.wrLock, mboxInfo[siCh].mbLock)
    devId = MBOX_DevNew(siCh, pcDevName);

    if ((devId >= 0) && (mboxInfo[siCh].mbDlst != (void*)0) && (mboxInfo[siCh].mbDlst[devId].dvQueu != (void*)0))
    {
        mboxInfo[siCh].mbDlst[devId].dvChnl         = siCh;
        mboxInfo[siCh].mbDlst[devId].dvIden         = devId;
        mboxInfo[siCh].mbDlst[devId].dvFlag         = ucFlag;
        mboxInfo[siCh].mbDlst[devId].dvQueu->qiFrnt = -1;
        mboxInfo[siCh].mbDlst[devId].dvQueu->qiRear = -1;
        mboxInfo[siCh].mbDlst[devId].dvName[0]      = (uint8) pcDevName[0];
        mboxInfo[siCh].mbDlst[devId].dvName[1]      = (uint8) pcDevName[1];
        mboxInfo[siCh].mbDlst[devId].dvName[2]      = (uint8) pcDevName[2];
        mboxInfo[siCh].mbDlst[devId].dvName[3]      = (uint8) pcDevName[3];
        mboxInfo[siCh].mbDlst[devId].dvName[4]      = (uint8) pcDevName[4];
        mboxInfo[siCh].mbDlst[devId].dvName[5]      = (uint8) pcDevName[5];
        mboxInfo[siCh].mbDlst[devId].dvName[6]      = (uint8) '\0';
        mboxDev = &mboxInfo[siCh].mbDlst[devId];
        MBOX_DevPtrCallVoid(mboxInfo[siCh].mbOsfn.rsInit, (uint32 *) &mboxInfo[siCh].mbDlst[devId].dvSiid)
    }
    else
    {
        MBOX_E("open fail siCh[%d] dev[%d] not initialized\n", siCh, devId);
    }

    MBOX_DevPtrCallVoid(mboxInfo[siCh].mbOsfn.wrUnlk, mboxInfo[siCh].mbLock)

    return mboxDev;
}

/*
***************************************************************************************************
*                                      <MBOX_DevSendSafe>
*
* This function sends 8 word command and 128 word data to Application Processor.
*
* @param    pDev    [in] A virtual device opened, which data must be sent.
* @param    puiCmd  [in] A pointer of 8 word command (fixed length).
* @param    puiData [in] A pointer of 128 word data.
* @param    siLen   [in] A data length of puiData within 128 word.
* @return   < 0 on error, otherwise MBOX_SUCCESS.
*
* Notes 1word = 4byte.
*
***************************************************************************************************
*/

static int32 MBOX_DevSendSafe
(
    const MBOXDvice_t *                 pDev,
    const uint32 *                      puiCmd,
    const uint32 *                      puiData,
    int32                               siLen
)
{
    int32   ret;
    uint32  scmd[8] = {0, };

    ret = MBOX_SUCCESS;

    MBOX_DevPtrCall(ret, mboxInfo[pDev->dvChnl].mbOsfn.wrLock, mboxInfo[pDev->dvChnl].mbLock)
    if ((MBOX_PhyEmptyMdata(pDev->dvChnl) & MBOX_PhyEmptyMcmd(pDev->dvChnl)) == (uint8) 0x01)
    {
        if ((puiData != (void *) 0) && ((siLen <= MBOX_DATA_FIFO_SIZE) && (siLen > 0)))
        {
            ret = MBOX_PhyWriteData(pDev->dvChnl, puiData, siLen);
        }

        if (ret == MBOX_SUCCESS)
        {
            MBOX_DevMakeCtlPacket(scmd, puiCmd, pDev->dvName);
            MBOX_DevPtrCall(ret, mboxInfo[pDev->dvChnl].mbOsfn.wrWclr, mboxInfo[pDev->dvChnl].mbSiid)
            MBOX_BITCLR(mboxInfo[pDev->dvChnl].mbBase->mboxCtlCmd.nREG, MBOX_OEN_BIT);
            ret = MBOX_PhyWriteCmd(pDev->dvChnl, scmd);

            MBOX_BITCLR(mboxInfo[pDev->dvChnl].mbBase->mboxCtlCmd.nREG, MBOX_OEN_BIT);
            MBOX_BITSET(mboxInfo[pDev->dvChnl].mbBase->mboxCtlCmd.nREG, MBOX_OEN_BIT);
            MBOX_DevPtrCall(ret, mboxInfo[pDev->dvChnl].mbOsfn.wrWait, mboxInfo[pDev->dvChnl].mbSiid)
        }
        else
        {
            ret = MBOX_ERR_WRITE;
        }
    }
    else
    {
        ret =  MBOX_ERR_FIFO_FULL;
    }
    MBOX_DevPtrCall(ret, mboxInfo[pDev->dvChnl].mbOsfn.wrUnlk, mboxInfo[pDev->dvChnl].mbLock)

    return ret;
}

/*
***************************************************************************************************
*                                      <MBOX_DevRecvSafe>
*
* This function receives 8 word command and 128 word data from Application Processor.
*
* @param    pDev    [in] A virtual device opened, which data must be sent.
* @param    puiCmd  [in] A pointer of 128 word data.
* @param    puiData [in] A data length of puiData within 128 word.
* @return   < 0 on error, == 0 if only 8 word command, > 0 data length within 128 word.
*
* Notes 1word = 4byte.
*
***************************************************************************************************
*/

static int32 MBOX_DevRecvSafe
(
    const MBOXDvice_t *                 pDev,
    uint32 *                            puiCmd,
    uint32 *                            puiData
)
{
    int32 ret;

    ret = MBOX_DEV_GET_AGAIN;

    while (ret == MBOX_DEV_GET_AGAIN)
    {
        ret = MBOX_DevQget(pDev->dvChnl, pDev->dvIden, pDev->dvQueu, puiCmd, puiData);
        if(ret != MBOX_DEV_GET_AGAIN)
        {
            continue;
        }
        else
        {
            MBOX_DevCallBreakOnNonBlock(ret, mboxInfo[pDev->dvChnl].mbOsfn.rdWait, pDev->dvSiid, MBOX_SUCCESS)
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                      <MBOX_DevDeploySwbufSafe>
*
* This function puts received data into software buffer.
*
* @param    siCh     [in] A Mailbox channel that data has been transmitted.
* @param    siLen    [in] A length of received data.
* @return   < 0 on error, otherwise MBOX_SUCCESS.
*
* Notes
*
***************************************************************************************************
*/

static int32 MBOX_DevDeploySwbufSafe
(
    MBOXCh_t                            siCh,
    int32                               siDevId,
    int32                               siDatLen
)
{
    int32 ret;

    ret     = MBOX_SUCCESS;

    if ((siDevId >= 0))
    {
        ret = MBOX_DevQput(siCh, siDevId, mboxInfo[siCh].mbDlst[siDevId].dvQueu, siDatLen);
        MBOX_DevPtrCallVoid(mboxInfo[siCh].mbOsfn.rdWake, mboxInfo[siCh].mbDlst[siDevId].dvSiid)
    }
    else
    {
        ret = MBOX_ERR_DEV_NOT_FOUND;
        MBOX_E("no such device dev[%d]\n", (sint32) siDevId);
    }

    return ret;
}
#endif

