/*
***************************************************************************************************
*
*   FileName : mbox.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_MAILBOX_DRIVER_HEADER
#define SIC_BSP_MAILBOX_DRIVER_HEADER

#if ( SIC_BSP_SUPPORT_DRIVER_MBOX )

/**************************************************************************************************
*                                           INCLUDE HEADER
***************************************************************************************************/
#include <sal_internal.h>
#include <bsp.h>
#include "debug.h"
#include "nvic.h"

/**************************************************************************************************
*                                           DEFINITION (Address)
***************************************************************************************************/
#define MBOX_CFG_ATTEMPT_CNT            (10UL)

#define MBOX_CFG_CMD_FIFO_SIZE          (8UL)
#define MBOX_CFG_DATA_FIFO_SIZE         (128UL)

/* Cortex-M7 Wrapper-0 Mailbox Address Map */
#define MBOX_M0_A65_S_HP_BASE           (0x41000000UL)
#define MBOX_M0_A65_NS_HP_BASE          (0x41010000UL)
#define MBOX_M0_M1_HP_BASE              (0x41020000UL)
#define MBOX_M0_M2_HP_BASE              (0x41030000UL)
#define MBOX_M0_HSM_HP_BASE             (0x41040000UL)
#define MBOX_M0_NP_HP_BASE              (0x41050000UL)
#define MBOX_M0_HP_ECSR                 (0x41060000UL)
#define MBOX_A65_M0_S_GP_BASE           (0x41070000UL)
#define MBOX_A65_M0_NS_GP_BASE          (0x41080000UL)
#define MBOX_M1_M0_GP_BASE              (0x41090000UL)
#define MBOX_M2_M0_GP_BASE              (0x410A0000UL)
#define MBOX_HSM_M0_GP_BASE             (0x410B0000UL)
#define MBOX_NP_M0_GP_BASE              (0x410C0000UL)
#define MBOX_M0_GP_ECSR                 (0x410D0000UL)

/* Cortex-M7 Wrapper-1 Mailbox Address Map */
#define MBOX_M1_A65_S_HP_BASE           (0x42000000UL)
#define MBOX_M1_A65_NS_HP_BASE          (0x42010000UL)
#define MBOX_M1_M0_HP_BASE              (0x42020000UL)
#define MBOX_M1_M2_HP_BASE              (0x42030000UL)
#define MBOX_M1_HSM_HP_BASE             (0x42040000UL)
#define MBOX_M1_NP_HP_BASE              (0x42050000UL)
#define MBOX_M1_HP_ECSR                 (0x42060000UL)
#define MBOX_A65_M1_S_GP_BASE           (0x42070000UL)
#define MBOX_A65_M1_NS_GP_BASE          (0x42080000UL)
#define MBOX_M0_M1_GP_BASE              (0x42090000UL)
#define MBOX_M2_M1_GP_BASE              (0x420A0000UL)
#define MBOX_HSM_M1_GP_BASE             (0x420B0000UL)
#define MBOX_NP_M1_GP_BASE              (0x420C0000UL)
#define MBOX_M1_GP_GP_ECSR              (0x420D0000UL)

/* Cortex-M7 Wrapper-2 Mailbox Address Map */
#define MBOX_M2_A65_S_HP_BASE           (0x43000000UL)
#define MBOX_M2_A65_NS_HP_BASE          (0x43010000UL)
#define MBOX_M2_M0_HP_BASE              (0x43020000UL)
#define MBOX_M2_M1_HP_BASE              (0x43030000UL)
#define MBOX_M2_HSM_HP_BASE             (0x43040000UL)
#define MBOX_M2_NP_HP_BASE              (0x43050000UL)
#define MBOX_M2_HP_ECSR                 (0x43060000UL)
#define MBOX_A65_M2_S_GP_BASE           (0x43070000UL)
#define MBOX_A65_M2_NS_GP_BASE          (0x43080000UL)
#define MBOX_M0_M2_GP_BASE              (0x43090000UL)
#define MBOX_M1_M2_GP_BASE              (0x430A0000UL)
#define MBOX_HSM_M2_GP_BASE             (0x430B0000UL)
#define MBOX_NP_M2_GP_BASE              (0x430C0000UL)
#define MBOX_M2_GP_ECSR                 (0x430D0000UL)

/* Networking Processor Wrapper Mailbox Address Map */
#define MBOX_NP_A65_S_HP_BASE           (0x47000000UL)
#define MBOX_NP_A65_NS_HP_BASE          (0x47010000UL)
#define MBOX_NP_M0_HP_BASE              (0x47020000UL)
#define MBOX_NP_M1_HP_BASE              (0x47030000UL)
#define MBOX_NP_M2_HP_BASE              (0x47040000UL)
#define MBOX_NP_HSM_HP_BASE             (0x47050000UL)
#define MBOX_NP_HP_ECSR                 (0x47060000UL)
#define MBOX_A65_NP_S_GP_BASE           (0x47070000UL)
#define MBOX_A65_NP_NS_GP_BASE          (0x47080000UL)
#define MBOX_M0_NP_GP_BASE              (0x47090000UL)
#define MBOX_M1_NP_GP_BASE              (0x470A0000UL)
#define MBOX_M2_NP_GP_BASE              (0x470B0000UL)
#define MBOX_HSM_NP_GP_BASE             (0x470C0000UL)
#define MBOX_NP_GP_ECSR                 (0x470D0000UL)

/* Base Address of Cortex-A65 Mailbox */
#define MBOX_A65_M0_S_HP_BASE           (0x40400000UL)
#define MBOX_A65_M1_S_HP_BASE           (0x40410000UL)
#define MBOX_A65_M2_S_HP_BASE           (0x40420000UL)
#define MBOX_A65_HSM_S_HP_BASE          (0x40430000UL)
#define MBOX_A65_NP_S_HP_BASE           (0x40440000UL)
#define MBOX_A65_S_HP_ECSR              (0x40450000UL)

#define MBOX_M0_A65_S_GP_BASE           (0x40460000UL)
#define MBOX_M1_A65_S_GP_BASE           (0x40470000UL)
#define MBOX_M2_A65_S_GP_BASE           (0x40480000UL)
#define MBOX_HSM_A65_S_GP_BASE          (0x40490000UL)
#define MBOX_NP_A65_S_GP_BASE           (0x404A0000UL)
#define MBOX_A65_S_GP_ECSR              (0x404B0000UL)

#define MBOX_A65_M0_NS_HP_BASE          (0x40500000UL)
#define MBOX_A65_M1_NS_HP_BASE          (0x40510000UL)
#define MBOX_A65_M2_NS_HP_BASE          (0x40520000UL)
#define MBOX_A65_HSM_NS_HP_BASE         (0x40530000UL)
#define MBOX_A65_NP_NS_HP_BASE          (0x40540000UL)
#define MBOX_A65_NS_HP_ECSR             (0x40550000UL)

#define MBOX_M0_A65_NS_GP_BASE          (0x40560000UL)
#define MBOX_M1_A65_NS_GP_BASE          (0x40570000UL)
#define MBOX_M2_A65_NS_GP_BASE          (0x40580000UL)
#define MBOX_HSM_A65_NS_GP_BASE         (0x40590000UL)
#define MBOX_NP_A65_NS_GP_BASE          (0x405A0000UL)
#define MBOX_A65_NS_GP_ECSR             (0x405B0000UL)

/* Mailbox Register Map (Base Address Symbol: HSM_MBOX_GPn) */
#define MBOX_A65_HSM_S_GP_BASE          (0x44170000UL)
#define MBOX_A65_HSM_NS_GP_BASE         (0x44180000UL)
#define MBOX_M0_HSM_GP_BASE             (0x44190000UL)
#define MBOX_M1_HSM_GP_BASE             (0x441A0000UL)
#define MBOX_M2_HSM_GP_BASE             (0x441B0000UL)
#define MBOX_NP_HSM_GP_BASE             (0x441C0000UL)
#define MBOX_HSM_GP_ECSR                (0x441D0000UL)


#define MBOX_SHIFT_CMD_MCOUNT           ( 4UL)
#define MBOX_SHIFT_CMD_SCOUNT           (20UL)
#define MBOX_SHIFT_OPP_TMN_STS          (16UL)
#define MBOX_SHIFT_CMD_TX_MEMP          ( 0UL)
#define MBOX_SHIFT_DAT_TX_MEMP          (31UL)

#define MBOX_MASK_CMD_MCOUNT            (0x000000F0UL)
#define MBOX_MASK_CMD_SCOUNT            (0x00F00000UL)
#define MBOX_MASK_DAT_MCOUNT            (0x0000FFFFUL)
#define MBOX_MASK_DAT_SCOUNT            (0x0000FFFFUL)

#define MBOX_CFG_CMD_MEMP               (1UL <<  0UL)
#define MBOX_CFG_CMD_SEMP               (1UL << 16UL)
#define MBOX_CFG_DATA_MEMP              (1UL << 31UL)
#define MBOX_CFG_DATA_MFUL              (1UL << 30UL)
#define MBOX_CFG_DATA_SEMP              (1UL << 31UL)
#define MBOX_CFG_DATA_SFUL              (1UL << 30UL)
#define MBOX_CFG_IEN_READ               (1UL <<  4UL)
#define MBOX_CFG_OEN                    (1UL <<  5UL)
#define MBOX_CFG_CF_FLUSH               (1UL <<  6UL)
#define MBOX_CFG_DF_FLUSH               (1UL <<  7UL)
#define MBOX_CFG_IEN_WRITE              (1UL << 20UL)
#define MBOX_CFG_ICLR_WRITE             (1UL << 21UL)
#define MBOX_CFG_OWN_TMN_STS            (1UL <<  0UL)
#define MBOX_CFG_OPP_TMN_STS            (1UL << 16UL)

/**************************************************************************************************
*                                           DEFINITION (Struct)
***************************************************************************************************/
typedef struct
{
    volatile uint32                     rCMD_FIFO_TXD[MBOX_CFG_CMD_FIFO_SIZE];  /* 0x0000 ~ 0x001C */
    volatile uint32                     rCMD_FIFO_RXD[MBOX_CFG_CMD_FIFO_SIZE];  /* 0x0020 ~ 0x003C */
    volatile uint32                     rMBOX_CTRL;                             /* 0x0040 */
    volatile uint32                     rCMD_FIFO_STS;                          /* 0x0044 */
    volatile uint32                     rRESERVED0[2UL];                        /* 0x0048 ~ 0x004C */
    volatile uint32                     rDAT_FIFO_TX_STS;                       /* 0x0050 */
    volatile uint32                     rDAT_FIFO_RX_STS;                       /* 0x0054 */
    volatile uint32                     rRESERVED1[2UL];                        /* 0x0058 ~ 0x005C */
    volatile uint32                     rDAT_FIFO_TXD;                          /* 0x0060 */
    volatile uint32                     rRESERVED2[3UL];                        /* 0x0064 ~ 0x006C */
    volatile uint32                     rDAT_FIFO_RXD;                          /* 0x0070 */
    volatile uint32                     rMBOX_CTRL_SET;                         /* 0x0074 */
    volatile uint32                     rMBOX_CTRL_CLR;                         /* 0x0078 */
    volatile uint32                     rTMN_STS;                               /* 0x007C */
}MailboxReg_t;

typedef struct
{
    uint32                              CmdLen;   /* UNIT: WORD */
    uint32                              DataLen;  /* UNIT: WORD */
    uint32                              Cmd[MBOX_CFG_CMD_FIFO_SIZE];
    uint32                              Data[MBOX_CFG_DATA_FIFO_SIZE];
}MboxMessage_t;

typedef enum
{
    MBOX_CH_A65_SECURE_HP   = 0x00UL,   /* -> CA65 Secure       */
    MBOX_CH_A65_SECURE_GP,
    MBOX_CH_A65_NON_SECURE_HP,          /* -> CA65 Non-Secure   */
    MBOX_CH_A65_NON_SECURE_GP,
    MBOX_CH_M0_HP,                      /* -> M0                */
    MBOX_CH_M0_GP,
    MBOX_CH_M1_HP,                      /* -> M1                */
    MBOX_CH_M1_GP,
    MBOX_CH_M2_HP,                      /* -> M2                */
    MBOX_CH_M2_GP,
    MBOX_CH_HSM_HP,                     /* -> HSM               */
    MBOX_CH_HSM_GP,
    MBOX_CH_NP_HP,                      /* -> Network           */
    MBOX_CH_NP_GP,
    MBOX_CH_MAX_VALUE
} MboxChIds_t;

typedef enum
{
    MBOX_CFG_ILEVEL_0       = 0x00UL,
    MBOX_CFG_ILEVEL_1,
    MBOX_CFG_ILEVEL_2,
    MBOX_CFG_ILEVEL_3
} MboxIntLevel_t;


/**************************************************************************************************
*                                          EXTERNAL FUNCTION
***************************************************************************************************/
/**************************************************************************************************
*                                          MBOX_CheckMessage
*
* [External] Check the validation of message
*
* @param        uiChannel
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_CheckMessage
(
    const MboxMessage_t *               sMboxMessage
);

/**************************************************************************************************
*                                          MBOX_CheckTxDone
*
* [External] Check the complete of sending a message
*
* @param        uiChannel
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_CheckTxDone
(
    MboxChIds_t                         uiChannel
);

/**************************************************************************************************
*                                          MBOX_ClearTxInterrupt
*
* [External] Clear the command-transmit-done interrupt
*
* @param        uiChannel
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_ClearTxInterrupt
(
    MboxChIds_t                         uiChannel
);

/**************************************************************************************************
*                                          MBOX_DisableInterrupt
*
* [External] Disable the command-transmit-done/receive-command interrupt
*
* @param        uiChannel
*               uiField (MBOX_CFG_IEN_WRITE, MBOX_CFG_IEN_READ)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_DisableInterrupt
(
    MboxChIds_t                         uiChannel,
    uint32                              uiField
);

/**************************************************************************************************
*                                          MBOX_EnableInterrupt
*
* [External] Enable the command-transmit-done/receive-command interrupt
*
* @param        uiChannel
*               uiField (MBOX_CFG_IEN_WRITE, MBOX_CFG_IEN_READ)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_EnableInterrupt
(
    MboxChIds_t                         uiChannel,
    uint32                              uiField
);

/**************************************************************************************************
*                                          MBOX_SetInterruptLevel
*
* [External] Set the receive-command FIFO level to generate interrupt
*
* @param        uiChannel
*               uiIntLevel (MBOX_CFG_ILEVEL_0 ~ 3)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_SetInterruptLevel
(
    MboxChIds_t                         uiChannel,
    MboxIntLevel_t                      uiIntLevel
);


/**************************************************************************************************
*                                          MBOX_GetIrqIndex
*
* [External] Get the interrupt request index value corresponding to the channel and interrupt mode.
*
* @param        uiChannel
*               uiField (MBOX_CFG_IEN_WRITE, MBOX_CFG_IEN_READ)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
uint32 MBOX_GetIrqIndex
(
    MboxChIds_t                         uiChannel,
    uint32                              uiField
);

/**************************************************************************************************
*                                          MBOX_SetTerminalStatus
*
* [External] Set the terminal status of R5 Mailbox
*
* @param        uiChannel
*               uiStatus (TRUE or FALSE)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_SetOwnTerminalStatus
(
    MboxChIds_t                         uiChannel,
    uint32                              uiStatus
);

/**************************************************************************************************
*                                          MBOX_GetOwnTerminalStatus
*
* [External] Get the own terminal status
*
* @param        uiChannel
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
uint32 MBOX_GetOwnTerminalStatus
(
    MboxChIds_t                         uiChannel
);

/**************************************************************************************************
*                                          MBOX_GetOppTerminalStatus
*
* [External] Get the opposite terminal status
*
* @param        uiChannel
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
uint32 MBOX_GetOppTerminalStatus
(
    MboxChIds_t                         uiChannel
);


/**************************************************************************************************
*                                          MBOX_FlushFIFO
*
* [External] Flush Command and Data FIFO
*
* @param        uiChannel
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_FlushFIFO
(
    MboxChIds_t                         uiChannel
);

/**************************************************************************************************
*                                          MBOX_SendMessage
*
* [External] Send the message (command + data)
*
* @param        uiChannel
*               sMboxMessage (struct type)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_SendMessage
(
    MboxChIds_t                         uiChannel,
    const MboxMessage_t *               sMboxMessage
);

/**************************************************************************************************
*                                          MBOX_SendCommand
*
* [External] Send the message (Only command)
*
* @param        uiChannel
*               sMboxMessage (struct type)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_SendCommand
(
    MboxChIds_t                         uiChannel,
    const MboxMessage_t *               sMboxMessage
);

/**************************************************************************************************
*                                          MBOX_ReadMessage
*
* [External] Read the message (command + data)
*
* @param        uiChannel
*               sMboxMessage (struct type)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_ReadMessage
(
    MboxChIds_t                         uiChannel,
    MboxMessage_t *                     sMboxMessage
);

/**************************************************************************************************
*                                          MBOX_ReadCommand
*
* [External] Read the message (Only command)
*
* @param        uiChannel
*               sMboxMessage (struct type)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_ReadCommand
(
    MboxChIds_t                         uiChannel,
    MboxMessage_t *                     sMboxMessage
);

/**************************************************************************************************
*                                          MBOX_Close
*
* [External] Close the mbox driver of the channel.
*
* @param        uiChannel
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_Close
(
    MboxChIds_t                         uiChannel
);

/**************************************************************************************************
*                                          MBOX_Open
*
* [External] Ready the mbox driver of the channel.
*
* @param        uiChannel
*               pTxIrqHandler   ( Tx Interrupt Handler )
*               pRxIrqHandler   ( Rx Interrupt Handler )
*               uiIntLevel      ( MBOX_CFG_ILEVEL_0 ~ 3 )
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_Open
(
    MboxChIds_t                         uiChannel,
    IrqHandler_t                        pTxIrqHandler,
    IrqHandler_t                        pRxIrqHandler,
    MboxIntLevel_t                      uiIntLevel
);

/**************************************************************************************************
*                                          MBOX_Init
*
* [External] Initialize the Mailbox (Set ILEVEL, Flush FIFO)
*
* @param
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
void MBOX_Init
(
    void
);

#endif  /* End of SIC_BSP_SUPPORT_DRIVER_MBOX */

#endif  /* End of SIC_BSP_MAILBOX_DRIVER_HEADER */

