/*
***************************************************************************************************
*
*   FileName : mbox_dev.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/
#ifndef MBOX_DEV_H
#define MBOX_DEV_H
#if(SIC_BSP_SUPPORT_DRIVER_MBOX)
/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/
#define MBOX_CTRL_IEN                   (0x00000010)
#define MBOX_CTRL_OEN                   (0x00000020)
#define MBOX_CTRL_CMD_FLUSH             (0x00000040)
#define MBOX_CTRL_DAT_FLUSH             (0x00000080)

#define MBOX_RD_BLOCK                   (0x0001)
#define MBOX_WR_BLOCK                   (0x0002)

#define MBOX_DevPtrCallVoid(F, P)       \
{                                       \
    if ((F) != (void *) 0)              \
    {                                   \
        (void) (F)(P);                  \
    }                                   \
}

#define MBOX_DevPtrCall(R, F, P)        \
{                                       \
    if ((F) != (void *) 0)              \
    {                                   \
        (R) = (F)(P);                   \
    }                                   \
}

#define MBOX_DevCallBreakOnErr(R, F, E) \
{                                       \
    (R) = (F);                          \
    if ((R) != (E))                     \
    {                                   \
        break;                          \
    }                                   \
}

#define MBOX_DevCallBreakOnNonBlock(R, F, P, E)         \
{                                                       \
    if ((F) != (void *)0)                          \
    {                                                   \
        MBOX_DevCallBreakOnErr((R), (F)(P), (E))        \
        (R) = MBOX_DEV_GET_AGAIN;                       \
    }                                                   \
    else                                                \
    {                                                   \
        (R) = (E);                                      \
    }                                                   \
}

typedef void (*MBOXIsrCallBack)
(
    const void *                        arg
);

typedef struct MBOXIsrFunc
{
    MBOXIsrCallBack                     cbRecev;
    MBOXIsrCallBack                     cbWrite;
} MBOXIsrFunc_t;

typedef struct MBOXHashMap
{
    int8                                hmSrkey[MBOX_MAX_KEY_SIZE];
    int32                               hmValue;
    int32                               hmInuse;
} MBOXHashMap_t;

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/

void MBOX_DevIsrReceived
(
    void
);

void MBOX_DevIsrWriteconfirm
(
    void
);


extern int32 MBOX_PhyReady
(
    MBOXCh_t                            siCh,
    uint32                              ucOpen
);

/* ================ Command FIFO Status Register ================ *
 * ============================================================== */

extern uint8 MBOX_PhyEmptyMcmd
(
    MBOXCh_t                            siCh
);

/* ============== Transmit Data FIFO Status Register ============ *
 * ============================================================== */
extern uint8 MBOX_PhyEmptyMdata
(
    MBOXCh_t                            siCh
);

/* =============== Receive Data FIFO Status Register ============ *
 * ============================================================== */

/* =============== Transmit Register for Command FIFO =========== *
 * ============================================================== */
extern int32 MBOX_PhyWriteCmd
(
    MBOXCh_t                            siCh,
    const uint32 *                      puiCmd
);

/* =============== Receive Register for Command FIFO ============ *
 * ============================================================== */
extern int32 MBOX_PhyReadCmd
(
    MBOXCh_t                            siCh
);

/* =============== Transmit Register for Data FIFO ============== *
 * ============================================================== */
extern int32 MBOX_PhyWriteData
(
    MBOXCh_t                            siCh,
    const uint32 *                      puiData,
    int32                               siLen
);

/* ================ Receive Register for Data FIFO ============== *
 * ============================================================== */
extern int32 MBOX_PhyReadData
(
    MBOXCh_t                            siCh
);

/* ==================== Terminal Status Register ================ *
 * ============================================================== */
extern void MBOX_DevRegisterIrq
(
    void
);

extern int32 MBOX_DevDeploySwbuf
(
    MBOXCh_t                            siCh,
    int32                               siCmdLen,
    int32                               siDatLen
);

#endif
#endif // MBOX_DEV_H

