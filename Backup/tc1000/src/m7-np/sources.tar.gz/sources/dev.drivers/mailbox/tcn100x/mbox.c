/*
***************************************************************************************************
*
*   FileName : mbox.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#if ( SIC_BSP_SUPPORT_DRIVER_MBOX )

/**************************************************************************************************
*                                           INCLUDE HEADER
***************************************************************************************************/
#include <mbox.h>

/**************************************************************************************************
*                                           LOCAL VARIABLES
**************************************************************************************************/

/**************************************************************************************************
*                                           INTERNAL FUNCTION
***************************************************************************************************/
/**************************************************************************************************
*                                          MBOX_GetBaseAddr
*
* [Internal] Return the base address for each channel of mailbox
*
* @param        uiChannel
* @return       (unsigned int32) Base address
*
* Notes
*
***************************************************************************************************/

static uint32 MBOX_GetBaseAddr
(
    MboxChIds_t                       uiChannel
)
{
    uint32      uiAddr;

    uiAddr      = NULL;

#if ( CORTEX_M7_0 == 1)
    switch(uiChannel)
    {
        case    MBOX_CH_A65_SECURE_HP:
        {
            uiAddr  = MBOX_M0_A65_S_HP_BASE;
            break;
        }

        case    MBOX_CH_A65_SECURE_GP:
        {
            uiAddr  = MBOX_M0_A65_S_GP_BASE;
            break;
        }

        case    MBOX_CH_A65_NON_SECURE_HP:
        {
            uiAddr  = MBOX_M0_A65_NS_HP_BASE;
            break;
        }

        case    MBOX_CH_A65_NON_SECURE_GP:
        {
            uiAddr  = MBOX_M0_A65_NS_GP_BASE;
            break;
        }

        case    MBOX_CH_M1_HP:
        {
            uiAddr  = MBOX_M0_M1_HP_BASE;
            break;
        }

        case    MBOX_CH_M1_GP:
        {
            uiAddr  = MBOX_M0_M1_GP_BASE;
            break;
        }

        case    MBOX_CH_M2_HP:
        {
            uiAddr  = MBOX_M0_M2_HP_BASE;
            break;
        }

        case    MBOX_CH_M2_GP:
        {
            uiAddr  = MBOX_M0_M2_GP_BASE;
            break;
        }

        case    MBOX_CH_HSM_HP:
        {
            uiAddr  = MBOX_M0_HSM_HP_BASE;
            break;
        }

        case    MBOX_CH_HSM_GP:
        {
            uiAddr  = MBOX_M0_HSM_GP_BASE;
            break;
        }

        case    MBOX_CH_NP_HP:
        {
            uiAddr  = MBOX_M0_NP_HP_BASE;
            break;
        }

        case    MBOX_CH_NP_GP:
        {
            uiAddr  = MBOX_M0_NP_GP_BASE;
            break;
        }

        default:
        {
            mcu_printf("[%s] Invalid Channel of Mailbox (Channel: %d)\n", __func__, uiChannel);

            break;
        }
    }

#elif ( CORTEX_M7_1 == 1)
    switch(uiChannel)
    {
        case    MBOX_CH_A65_SECURE_HP:
        {
            uiAddr  = MBOX_M1_A65_S_HP_BASE;
            break;
        }

        case    MBOX_CH_A65_SECURE_GP:
        {
            uiAddr  = MBOX_M1_A65_S_GP_BASE;
            break;
        }

        case    MBOX_CH_A65_NON_SECURE_HP:
        {
            uiAddr  = MBOX_M1_A65_NS_HP_BASE;
            break;
        }

        case    MBOX_CH_A65_NON_SECURE_GP:
        {
            uiAddr  = MBOX_M1_A65_NS_GP_BASE;
            break;
        }

        case    MBOX_CH_M0_HP:
        {
            uiAddr  = MBOX_M1_M0_HP_BASE;
            break;
        }

        case    MBOX_CH_M0_GP:
        {
            uiAddr  = MBOX_M1_M0_GP_BASE;
            break;
        }

        case    MBOX_CH_M2_HP:
        {
            uiAddr  = MBOX_M1_M2_HP_BASE;
            break;
        }

        case    MBOX_CH_M2_GP:
        {
            uiAddr  = MBOX_M1_M2_GP_BASE;
            break;
        }

        case    MBOX_CH_HSM_HP:
        {
            uiAddr  = MBOX_M1_HSM_HP_BASE;
            break;
        }

        case    MBOX_CH_HSM_GP:
        {
            uiAddr  = MBOX_M1_HSM_GP_BASE;
            break;
        }

        case    MBOX_CH_NP_HP:
        {
            uiAddr  = MBOX_M1_NP_HP_BASE;
            break;
        }

        case    MBOX_CH_NP_GP:
        {
            uiAddr  = MBOX_M1_NP_GP_BASE;
            break;
        }

        default:
        {
            mcu_printf("[%s] Invalid Channel of Mailbox (Channel: %d)\n", __func__, uiChannel);

            break;
        }
    }

#elif ( CORTEX_M7_2 == 1)
    switch(uiChannel)
    {
        case    MBOX_CH_A65_SECURE_HP:
        {
            uiAddr  = MBOX_M2_A65_S_HP_BASE;
            break;
        }

        case    MBOX_CH_A65_SECURE_GP:
        {
            uiAddr  = MBOX_M2_A65_S_GP_BASE;
            break;
        }

        case    MBOX_CH_A65_NON_SECURE_HP:
        {
            uiAddr  = MBOX_M2_A65_NS_HP_BASE;
            break;
        }

        case    MBOX_CH_A65_NON_SECURE_GP:
        {
            uiAddr  = MBOX_M2_A65_NS_GP_BASE;
            break;
        }

        case    MBOX_CH_M0_HP:
        {
            uiAddr  = MBOX_M2_M0_HP_BASE;
            break;
        }

        case    MBOX_CH_M0_GP:
        {
            uiAddr  = MBOX_M2_M0_GP_BASE;
            break;
        }

        case    MBOX_CH_M1_HP:
        {
            uiAddr  = MBOX_M2_M1_HP_BASE;
            break;
        }

        case    MBOX_CH_M1_GP:
        {
            uiAddr  = MBOX_M2_M1_GP_BASE;
            break;
        }

        case    MBOX_CH_HSM_HP:
        {
            uiAddr  = MBOX_M2_HSM_HP_BASE;
            break;
        }

        case    MBOX_CH_HSM_GP:
        {
            uiAddr  = MBOX_M2_HSM_GP_BASE;
            break;
        }

        case    MBOX_CH_NP_HP:
        {
            uiAddr  = MBOX_M2_NP_HP_BASE;
            break;
        }

        case    MBOX_CH_NP_GP:
        {
            uiAddr  = MBOX_M2_NP_GP_BASE;
            break;
        }

        default:
        {
            mcu_printf("[%s] Invalid Channel of Mailbox (Channel: %d)\n", __func__, uiChannel);

            break;
        }
    }

#elif ( CORTEX_M7_NP == 1)
        switch(uiChannel)
        {
            case    MBOX_CH_A65_SECURE_HP:
            {
                uiAddr  = MBOX_NP_A65_S_HP_BASE;
                break;
            }

            case    MBOX_CH_A65_SECURE_GP:
            {
                uiAddr  = MBOX_NP_A65_S_GP_BASE;
                break;
            }

            case    MBOX_CH_A65_NON_SECURE_HP:
            {
                uiAddr  = MBOX_NP_A65_NS_HP_BASE;
                break;
            }

            case    MBOX_CH_A65_NON_SECURE_GP:
            {
                uiAddr  = MBOX_NP_A65_NS_GP_BASE;
                break;
            }

            case    MBOX_CH_M0_HP:
            {
                uiAddr  = MBOX_NP_M0_HP_BASE;
                break;
            }

            case    MBOX_CH_M0_GP:
            {
                uiAddr  = MBOX_NP_M0_GP_BASE;
                break;
            }

            case    MBOX_CH_M1_HP:
            {
                uiAddr  = MBOX_NP_M1_HP_BASE;
                break;
            }

            case    MBOX_CH_M1_GP:
            {
                uiAddr  = MBOX_NP_M1_GP_BASE;
                break;
            }

            case    MBOX_CH_M2_HP:
            {
                uiAddr  = MBOX_NP_M2_HP_BASE;
                break;
            }

            case    MBOX_CH_M2_GP:
            {
                uiAddr  = MBOX_NP_M2_GP_BASE;
                break;
            }

            case    MBOX_CH_HSM_HP:
            {
                uiAddr  = MBOX_NP_HSM_HP_BASE;
                break;
            }

            case    MBOX_CH_HSM_GP:
            {
                uiAddr  = MBOX_NP_HSM_GP_BASE;
                break;
            }

            default:
            {
                mcu_printf("[%s] Invalid Channel of Mailbox (Channel: %d)\n", __func__, uiChannel);

                break;
            }
        }

#endif

    return  uiAddr;
}

/**************************************************************************************************
*                                          EXTERNAL FUNCTION
***************************************************************************************************/
/**************************************************************************************************
*                                          MBOX_CheckMessage
*
* [External] Check the validation of message
*
* @param        sMboxMessage (struct type)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_CheckMessage
(
    const MboxMessage_t *               sMboxMessage
)
{
    SALRetCode_t        ucRet;

    ucRet         = SAL_RET_FAILED;

    if(sMboxMessage == NULL)
    {
        ucRet = SAL_RET_FAILED;
    }
    else if(sMboxMessage->CmdLen == 0UL)
    {
        ucRet = SAL_RET_FAILED;
    }
    else if(MBOX_CFG_CMD_FIFO_SIZE < sMboxMessage->CmdLen)
    {
        ucRet = SAL_RET_FAILED;
    }
    else if(MBOX_CFG_DATA_FIFO_SIZE < sMboxMessage->DataLen)
    {
        ucRet = SAL_RET_FAILED;
    }
    else
    {
        ucRet = SAL_RET_SUCCESS;
    }

    return ucRet;
}

/**************************************************************************************************
*                                          MBOX_CheckTxDone
*
* [External] Check the complete of sending a message
*
* @param        uiChannel
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_CheckTxDone
(
    MboxChIds_t                         uiChannel
)
{
    MailboxReg_t *      sMboxRegister;
    SALRetCode_t        ucRet;
    uint32              uiValue;

    sMboxRegister   = NULL_PTR;
    ucRet           = SAL_RET_FAILED;

    if(MBOX_CH_MAX_VALUE <= uiChannel)
    {
        mcu_printf("[%s] Wrong Argument (Channel: %d)\n", __func__, uiChannel);
    }
    else
    {
        sMboxRegister   = ((MailboxReg_t *) MBOX_GetBaseAddr(uiChannel));

        if(NULL != sMboxRegister)
        {
            uiValue = (sMboxRegister->rCMD_FIFO_STS & MBOX_CFG_CMD_MEMP);

            if((uint32)TRUE == uiValue)
            {
                sMboxRegister->rMBOX_CTRL   &= ~(MBOX_CFG_OEN);
                sMboxRegister->rMBOX_CTRL   |= (MBOX_CFG_DF_FLUSH | MBOX_CFG_CF_FLUSH);

                ucRet = SAL_RET_SUCCESS;
            }
        }
    }

    return ucRet;
}

/**************************************************************************************************
*                                          MBOX_ClearTxInterrupt
*
* [External] Clear the command-transmit-done interrupt
*
* @param        uiChannel
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_ClearTxInterrupt
(
    MboxChIds_t                         uiChannel
)
{
    MailboxReg_t *      sMboxRegister;
    SALRetCode_t        ucRet;

    sMboxRegister   = NULL_PTR;
    ucRet           = SAL_RET_FAILED;

    if(MBOX_CH_MAX_VALUE <= uiChannel)
    {
        mcu_printf("[%s] Wrong Argument (Channel: %d)\n", __func__, uiChannel);
    }
    else
    {
        sMboxRegister   = ((MailboxReg_t *) MBOX_GetBaseAddr(uiChannel));

        if(NULL != sMboxRegister)
        {
            sMboxRegister->rMBOX_CTRL   |= (uint32)MBOX_CFG_ICLR_WRITE;

            ucRet   = SAL_RET_SUCCESS;
        }
    }

    return ucRet;
}

/**************************************************************************************************
*                                          MBOX_DisableInterrupt
*
* [External] Disable the command-transmit-done/receive-command interrupt
*
* @param        uiChannel
*               uiField (MBOX_CFG_IEN_WRITE, MBOX_CFG_IEN_READ)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_DisableInterrupt
(
    MboxChIds_t                         uiChannel,
    uint32                              uiField
)
{
    MailboxReg_t *      sMboxRegister;
    SALRetCode_t        ucRet;

    sMboxRegister   = NULL_PTR;
    ucRet           = SAL_RET_FAILED;

    if(MBOX_CH_MAX_VALUE <= uiChannel)
    {
        mcu_printf("[%s] Wrong Argument (Channel: %d)\n", __func__, uiChannel);
    }
    else if((MBOX_CFG_IEN_READ != uiField) && (MBOX_CFG_IEN_WRITE != uiField))
    {
        mcu_printf("[%s] Wrong Argument (uiField: 0x%08X)\n", __func__, uiField);
    }
    else
    {
        sMboxRegister   = ((MailboxReg_t *) MBOX_GetBaseAddr(uiChannel));

        if(NULL != sMboxRegister)
        {
            sMboxRegister->rMBOX_CTRL   &= ~(uiField);

            ucRet   = SAL_RET_SUCCESS;
        }
    }

    return ucRet;
}

/**************************************************************************************************
*                                          MBOX_EnableInterrupt
*
* [External] Enable the command-transmit-done/receive-command interrupt
*
* @param        uiChannel
*               uiField (MBOX_CFG_IEN_WRITE, MBOX_CFG_IEN_READ)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_EnableInterrupt
(
    MboxChIds_t                         uiChannel,
    uint32                              uiField
)
{
    MailboxReg_t *      sMboxRegister;
    SALRetCode_t        ucRet;

    sMboxRegister   = NULL_PTR;
    ucRet           = SAL_RET_FAILED;

    if(MBOX_CH_MAX_VALUE <= uiChannel)
    {
        mcu_printf("[%s] Wrong Argument (Channel: %d)\n", __func__, uiChannel);
    }
    else if((MBOX_CFG_IEN_READ != uiField) && (MBOX_CFG_IEN_WRITE != uiField))
    {
        mcu_printf("[%s] Wrong Argument (uiField: 0x%08X)\n", __func__, uiField);
    }
    else
    {
        sMboxRegister   = ((MailboxReg_t *) MBOX_GetBaseAddr(uiChannel));

        if(NULL != sMboxRegister)
        {
            sMboxRegister->rMBOX_CTRL   &= ~(uiField);
            sMboxRegister->rMBOX_CTRL   |= uiField;

            ucRet   = SAL_RET_SUCCESS;
        }
    }

    return ucRet;
}

/**************************************************************************************************
*                                          MBOX_SetInterruptLevel
*
* [External] Set the receive-command FIFO level to generate interrupt
*
* @param        uiChannel
*               uiIntLevel (MBOX_CFG_ILEVEL_0 ~ 3)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_SetInterruptLevel
(
    MboxChIds_t                         uiChannel,
    MboxIntLevel_t                      uiIntLevel
)
{
    MailboxReg_t *      sMboxRegister;
    SALRetCode_t        ucRet;

    sMboxRegister   = NULL_PTR;
    ucRet           = SAL_RET_FAILED;

    if(MBOX_CH_MAX_VALUE <= uiChannel)
    {
        mcu_printf("[%s] Wrong Argument (Channel: %d)\n", __func__, uiChannel);
    }
    else if(MBOX_CFG_ILEVEL_3 < uiIntLevel)
    {
        mcu_printf("[%s] Wrong Argument (IntLevel: %d)\n", __func__, uiIntLevel);
    }
    else
    {
        sMboxRegister   = ((MailboxReg_t *) MBOX_GetBaseAddr(uiChannel));

        if(NULL != sMboxRegister)
        {
            sMboxRegister->rMBOX_CTRL   &= ~((uint32)uiIntLevel);
            sMboxRegister->rMBOX_CTRL   |= (uint32)uiIntLevel;

            ucRet   = SAL_RET_SUCCESS;
        }
    }

    return ucRet;
}

/**************************************************************************************************
*                                          MBOX_GetIrqIndex
*
* [External] Get the interrupt request index value corresponding to the channel and interrupt mode.
*
* @param        uiChannel
*               uiField (MBOX_CFG_IEN_WRITE, MBOX_CFG_IEN_READ)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
uint32 MBOX_GetIrqIndex
(
    MboxChIds_t                         uiChannel,
    uint32                              uiField
)
{
    uint32 uiIrqIndex = NULL;

    if(MBOX_CH_MAX_VALUE <= uiChannel)
    {
        mcu_printf("[%s] Wrong Argument (Channel: %d)\n", __func__, uiChannel);
    }else{

        if(MBOX_CFG_IEN_READ == uiField)
        {

#if ( CORTEX_M7_0 == 1)
            switch(uiChannel)
            {
                case    MBOX_CH_A65_SECURE_HP:
                {
                    uiIrqIndex  = MBOX_M0_A65_S_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_A65_SECURE_GP:
                {
                    uiIrqIndex  = MBOX_A65_M0_S_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_A65_NON_SECURE_HP:
                {
                    uiIrqIndex  = MBOX_M0_A65_NS_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_A65_NON_SECURE_GP:
                {
                    uiIrqIndex  = MBOX_A65_M0_NS_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M1_HP:
                {
                    uiIrqIndex  = MBOX_M0_M1_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M1_GP:
                {
                    uiIrqIndex  = MBOX_M1_M0_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M2_HP:
                {
                    uiIrqIndex  = MBOX_M0_M2_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M2_GP:
                {
                    uiIrqIndex  = MBOX_M2_M0_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_HSM_HP:
                {
                    uiIrqIndex  = MBOX_M0_HSM_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_HSM_GP:
                {
                    uiIrqIndex  = MBOX_HSM_M0_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_NP_HP:
                {
                    uiIrqIndex  = MBOX_M0_MX_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_NP_GP:
                {
                    uiIrqIndex  = MBOX_MX_M0_MST_TX_IRQn;
                    break;
                }
                default:
                {
                    mcu_printf("[%s] Invalid Channel of Mailbox (Channel: %d)\n", __func__, uiChannel);
                    break;
                }
            }

#elif ( CORTEX_M7_1 == 1)

            switch(uiChannel)
            {
                case    MBOX_CH_A65_SECURE_HP:
                {
                    uiIrqIndex  = MBOX_M1_A65_S_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_A65_SECURE_GP:
                {
                    uiIrqIndex  = MBOX_A65_M1_S_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_A65_NON_SECURE_HP:
                {
                    uiIrqIndex  = MBOX_M1_A65_NS_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_A65_NON_SECURE_GP:
                {
                    uiIrqIndex  = MBOX_A65_M1_NS_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M0_HP:
                {
                    uiIrqIndex  = MBOX_M1_M0_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M0_GP:
                {
                    uiIrqIndex  = MBOX_M0_M1_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M2_HP:
                {
                    uiIrqIndex  = MBOX_M1_M2_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M2_GP:
                {
                    uiIrqIndex  = MBOX_M2_M1_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_HSM_HP:
                {
                    uiIrqIndex  = MBOX_M1_HSM_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_HSM_GP:
                {
                    uiIrqIndex  = MBOX_HSM_M1_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_NP_HP:
                {
                    uiIrqIndex  = MBOX_M1_MX_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_NP_GP:
                {
                    uiIrqIndex  = MBOX_MX_M1_MST_TX_IRQn;
                    break;
                }
                default:
                {
                    mcu_printf("[%s] Invalid Channel of Mailbox (Channel: %d)\n", __func__, uiChannel);
                    break;
                }
            }
#elif ( CORTEX_M7_2 == 1)
            switch(uiChannel)
            {
                case    MBOX_CH_A65_SECURE_HP:
                {
                    uiIrqIndex  = MBOX_M2_A65_S_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_A65_SECURE_GP:
                {
                    uiIrqIndex  = MBOX_A65_M2_S_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_A65_NON_SECURE_HP:
                {
                    uiIrqIndex  = MBOX_M2_A65_NS_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_A65_NON_SECURE_GP:
                {
                    uiIrqIndex  = MBOX_A65_M2_NS_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M0_HP:
                {
                    uiIrqIndex  = MBOX_M2_M0_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M0_GP:
                {
                    uiIrqIndex  = MBOX_M0_M2_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M1_HP:
                {
                    uiIrqIndex  = MBOX_M2_M1_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M1_GP:
                {
                    uiIrqIndex  = MBOX_M1_M2_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_HSM_HP:
                {
                    uiIrqIndex  = MBOX_M2_HSM_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_HSM_GP:
                {
                    uiIrqIndex  = MBOX_HSM_M2_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_NP_HP:
                {
                    uiIrqIndex  = MBOX_M2_MX_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_NP_GP:
                {
                    uiIrqIndex  = MBOX_MX_M2_MST_TX_IRQn;
                    break;
                }
                default:
                {
                    mcu_printf("[%s] Invalid Channel of Mailbox (Channel: %d)\n", __func__, uiChannel);
                    break;
                }
            }
#elif ( CORTEX_M7_NP == 1)
            switch(uiChannel)
            {
                case    MBOX_CH_A65_SECURE_HP:
                {
                    uiIrqIndex  = MBOX_MX_A65_S_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_A65_SECURE_GP:
                {
                    uiIrqIndex  = MBOX_A65_MX_S_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_A65_NON_SECURE_HP:
                {
                    uiIrqIndex  = MBOX_MX_A65_NS_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_A65_NON_SECURE_GP:
                {
                    uiIrqIndex  = MBOX_A65_MX_NS_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M0_HP:
                {
                    uiIrqIndex  = MBOX_MX_M0_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M0_GP:
                {
                    uiIrqIndex  = MBOX_M0_MX_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M1_HP:
                {
                    uiIrqIndex  = MBOX_MX_M1_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M1_GP:
                {
                    uiIrqIndex  = MBOX_M1_MX_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M2_HP:
                {
                    uiIrqIndex  = MBOX_MX_M2_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_M2_GP:
                {
                    uiIrqIndex  = MBOX_M2_MX_MST_TX_IRQn;
                    break;
                }
                case    MBOX_CH_HSM_HP:
                {
                    uiIrqIndex  = MBOX_MX_HSM_SLV_TX_IRQn;
                    break;
                }
                case    MBOX_CH_HSM_GP:
                {
                    uiIrqIndex  = MBOX_HSM_MX_MST_TX_IRQn;
                    break;
                }
                default:
                {
                    mcu_printf("[%s] Invalid Channel of Mailbox (Channel: %d)\n", __func__, uiChannel);
                    break;
                }
            }
#endif
        }
        else if(MBOX_CFG_IEN_WRITE == uiField)
        {
#if ( CORTEX_M7_0 == 1)
            switch(uiChannel)
            {
                case    MBOX_CH_A65_SECURE_HP:
                {
                    uiIrqIndex  = MBOX_M0_A65_S_SLV_RX_IRQn;
                    break;
                }
                case    MBOX_CH_A65_SECURE_GP:
                {
                    uiIrqIndex  = MBOX_A65_M0_S_MST_RX_IRQn;
                    break;
                }
                case    MBOX_CH_A65_NON_SECURE_HP:
                {
                    uiIrqIndex  = MBOX_M0_A65_NS_SLV_RX_IRQn;
                    break;
                }
                case    MBOX_CH_A65_NON_SECURE_GP:
                {
                    uiIrqIndex  = MBOX_A65_M0_NS_MST_RX_IRQn;
                    break;
                }
                case    MBOX_CH_M1_HP:
                {
                    uiIrqIndex  = MBOX_M0_M1_SLV_RX_IRQn;
                    break;
                }
                case    MBOX_CH_M1_GP:
                {
                    uiIrqIndex  = MBOX_M1_M0_MST_RX_IRQn;
                    break;
                }
                case    MBOX_CH_M2_HP:
                {
                    uiIrqIndex  = MBOX_M0_M2_SLV_RX_IRQn;
                    break;
                }
                case    MBOX_CH_M2_GP:
                {
                    uiIrqIndex  = MBOX_M2_M0_MST_RX_IRQn;
                    break;
                }
                case    MBOX_CH_HSM_HP:
                {
                    uiIrqIndex  = MBOX_M0_HSM_SLV_RX_IRQn;
                    break;
                }
                case    MBOX_CH_HSM_GP:
                {
                    uiIrqIndex  = MBOX_HSM_M0_MST_RX_IRQn;
                    break;
                }
                case    MBOX_CH_NP_HP:
                {
                    uiIrqIndex  = MBOX_M0_MX_SLV_RX_IRQn;
                    break;
                }
                case    MBOX_CH_NP_GP:
                {
                    uiIrqIndex  = MBOX_MX_M0_MST_RX_IRQn;
                    break;
                }
                default:
                {
                    mcu_printf("[%s] Invalid Channel of Mailbox (Channel: %d)\n", __func__, uiChannel);
                    break;
                }
            }
#elif ( CORTEX_M7_1 == 1)
        switch(uiChannel)
        {
            case    MBOX_CH_A65_SECURE_HP:
            {
                uiIrqIndex  = MBOX_M1_A65_S_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_A65_SECURE_GP:
            {
                uiIrqIndex  = MBOX_A65_M1_S_MST_RX_IRQn;
                break;
            }
            case    MBOX_CH_A65_NON_SECURE_HP:
            {
                uiIrqIndex  = MBOX_M1_A65_NS_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_A65_NON_SECURE_GP:
            {
                uiIrqIndex  = MBOX_A65_M1_NS_MST_RX_IRQn;
                break;
            }
            case    MBOX_CH_M0_HP:
            {
                uiIrqIndex  = MBOX_M1_M0_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_M0_GP:
            {
                uiIrqIndex  = MBOX_M0_M1_MST_RX_IRQn;
                break;
            }
            case    MBOX_CH_M2_HP:
            {
                uiIrqIndex  = MBOX_M1_M2_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_M2_GP:
            {
                uiIrqIndex  = MBOX_M2_M1_MST_RX_IRQn;
                break;
            }
            case    MBOX_CH_HSM_HP:
            {
                uiIrqIndex  = MBOX_M1_HSM_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_HSM_GP:
            {
                uiIrqIndex  = MBOX_HSM_M1_MST_RX_IRQn;
                break;
            }
            case    MBOX_CH_NP_HP:
            {
                uiIrqIndex  = MBOX_M1_MX_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_NP_GP:
            {
                uiIrqIndex  = MBOX_MX_M1_MST_RX_IRQn;
                break;
            }
            default:
            {
                mcu_printf("[%s] Invalid Channel of Mailbox (Channel: %d)\n", __func__, uiChannel);
                break;
            }
        }
#elif ( CORTEX_M7_2 == 1)
        switch(uiChannel)
        {
            case    MBOX_CH_A65_SECURE_HP:
            {
                uiIrqIndex  = MBOX_M2_A65_S_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_A65_SECURE_GP:
            {
                uiIrqIndex  = MBOX_A65_M2_S_MST_RX_IRQn;
                break;
            }
            case    MBOX_CH_A65_NON_SECURE_HP:
            {
                uiIrqIndex  = MBOX_M2_A65_NS_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_A65_NON_SECURE_GP:
            {
                uiIrqIndex  = MBOX_A65_M2_NS_MST_RX_IRQn;
                break;
            }
            case    MBOX_CH_M0_HP:
            {
                uiIrqIndex  = MBOX_M2_M0_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_M0_GP:
            {
                uiIrqIndex  = MBOX_M0_M2_MST_RX_IRQn;
                break;
            }
            case    MBOX_CH_M1_HP:
            {
                uiIrqIndex  = MBOX_M2_M1_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_M1_GP:
            {
                uiIrqIndex  = MBOX_M1_M2_MST_RX_IRQn;
                break;
            }
            case    MBOX_CH_HSM_HP:
            {
                uiIrqIndex  = MBOX_M2_HSM_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_HSM_GP:
            {
                uiIrqIndex  = MBOX_HSM_M2_MST_RX_IRQn;
                break;
            }
            case    MBOX_CH_NP_HP:
            {
                uiIrqIndex  = MBOX_M2_MX_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_NP_GP:
            {
                uiIrqIndex  = MBOX_MX_M2_MST_RX_IRQn;
                break;
            }
            default:
            {
                mcu_printf("[%s] Invalid Channel of Mailbox (Channel: %d)\n", __func__, uiChannel);
                break;
            }
        }
#elif ( CORTEX_M7_NP == 1)
        switch(uiChannel)
        {
            case    MBOX_CH_A65_SECURE_HP:
            {
                uiIrqIndex  = MBOX_MX_A65_S_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_A65_SECURE_GP:
            {
                uiIrqIndex  = MBOX_A65_MX_S_MST_RX_IRQn;
                break;
            }
            case    MBOX_CH_A65_NON_SECURE_HP:
            {
                uiIrqIndex  = MBOX_MX_A65_NS_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_A65_NON_SECURE_GP:
            {
                uiIrqIndex  = MBOX_A65_MX_NS_MST_RX_IRQn;
                break;
            }
            case    MBOX_CH_M0_HP:
            {
                uiIrqIndex  = MBOX_MX_M0_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_M0_GP:
            {
                uiIrqIndex  = MBOX_M0_MX_MST_RX_IRQn;
                break;
            }
            case    MBOX_CH_M1_HP:
            {
                uiIrqIndex  = MBOX_MX_M1_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_M1_GP:
            {
                uiIrqIndex  = MBOX_M1_MX_MST_RX_IRQn;
                break;
            }
            case    MBOX_CH_M2_HP:
            {
                uiIrqIndex  = MBOX_MX_M2_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_M2_GP:
            {
                uiIrqIndex  = MBOX_M2_MX_MST_RX_IRQn;
                break;
            }
            case    MBOX_CH_HSM_HP:
            {
                uiIrqIndex  = MBOX_MX_HSM_SLV_RX_IRQn;
                break;
            }
            case    MBOX_CH_HSM_GP:
            {
                uiIrqIndex  = MBOX_HSM_MX_MST_RX_IRQn;
                break;
            }
            default:
            {
                mcu_printf("[%s] Invalid Channel of Mailbox (Channel: %d)\n", __func__, uiChannel);
                break;
            }
        }
#endif
        }
        else
        {
            mcu_printf("[%s] Wrong Argument (uiField: 0x%08X)\n", __func__, uiField);
        }
    }

    return uiIrqIndex;
}

/**************************************************************************************************
*                                          MBOX_SetTerminalStatus
*
* [External] Set the terminal status of SIC Mailbox
*
* @param        uiChannel
*               uiStatus (TRUE or FALSE)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_SetOwnTerminalStatus
(
    MboxChIds_t                         uiChannel,
    uint32                              uiStatus
)
{
    MailboxReg_t *      sMboxRegister;
    SALRetCode_t        ucRet;

    sMboxRegister   = NULL_PTR;
    ucRet           = SAL_RET_FAILED;

    if(MBOX_CH_MAX_VALUE <= uiChannel)
    {
        mcu_printf("[%s] Wrong Argument (Channel: %d)\n", __func__, uiChannel);
    }
    else if((uint32)TRUE < uiStatus)
    {
        mcu_printf("[%s] Wrong Argument (Status: %d)\n", __func__, uiStatus);
    }
    else
    {
        sMboxRegister = ((MailboxReg_t *) MBOX_GetBaseAddr(uiChannel));

        if(NULL != sMboxRegister)
        {
            switch(uiStatus)
            {
                case    (uint32)TRUE:
                {
                    sMboxRegister->rTMN_STS |= uiStatus;

                    ucRet   = SAL_RET_SUCCESS;

                    break;
                }
                case    (uint32)FALSE:
                {
                    sMboxRegister->rTMN_STS &= uiStatus;

                    ucRet   = SAL_RET_SUCCESS;

                    break;
                }
                default:
                {
                    mcu_printf("[%s] Worng Argument (status : %d)\n", __func__, uiStatus);

                    break;
                }
            }
        }
    }

    return ucRet;
}

/**************************************************************************************************
*                                          MBOX_GetOwnTerminalStatus
*
* [External] Get the own terminal status
*
* @param        uiChannel
* @return       uiStatus (TRUE or FALSE)
*
* Notes
*
***************************************************************************************************/
uint32 MBOX_GetOwnTerminalStatus
(
    MboxChIds_t                         uiChannel
)
{
    const MailboxReg_t *    sMboxRegister;
    uint32                  uiStatus;

    sMboxRegister = NULL_PTR;
    uiStatus      = 0U;

    if(MBOX_CH_MAX_VALUE <= uiChannel)
    {
        mcu_printf("[%s] Wrong Argument (Channel: %d)\n", __func__, uiChannel);
    }
    else
    {
        sMboxRegister = ((MailboxReg_t *) MBOX_GetBaseAddr(uiChannel));

        if(NULL != sMboxRegister)
        {
            uiStatus = (sMboxRegister->rTMN_STS & MBOX_CFG_OWN_TMN_STS);
        }
    }

    return uiStatus;
}

/**************************************************************************************************
*                                          MBOX_GetOppTerminalStatus
*
* [External] Get the opposite terminal status
*
* @param        uiChannel
* @return       uiStatus (TRUE or FALSE)
*
* Notes
*
***************************************************************************************************/
uint32 MBOX_GetOppTerminalStatus
(
    MboxChIds_t                         uiChannel
)
{
    const MailboxReg_t *    sMboxRegister;
    uint32                  uiStatus;

    sMboxRegister = NULL_PTR;
    uiStatus      = 0U;

    if(MBOX_CH_MAX_VALUE <= uiChannel)
    {
        mcu_printf("[%s] Wrong Argument (Channel: %d)\n", __func__, uiChannel);
    }
    else
    {
        sMboxRegister = ((MailboxReg_t *) MBOX_GetBaseAddr(uiChannel));

        if(NULL != sMboxRegister)
        {
            uiStatus = (sMboxRegister->rTMN_STS >> MBOX_SHIFT_OPP_TMN_STS) & 0x01U;
        }
    }

    return uiStatus;
}

/**************************************************************************************************
*                                          MBOX_FlushFIFO
*
* [External] Flush Command and Data FIFO
*
* @param        uiChannel
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_FlushFIFO
(
    MboxChIds_t                         uiChannel
)
{
    MailboxReg_t *      sMboxRegister;
    SALRetCode_t        ucRet;

    sMboxRegister = NULL_PTR;
    ucRet         = SAL_RET_FAILED;

    if(MBOX_CH_MAX_VALUE <= uiChannel)
    {
        mcu_printf("[%s] Wrong Argument (Channel: %d)\n", __func__, uiChannel);
    }
    else
    {
        sMboxRegister = ((MailboxReg_t *) MBOX_GetBaseAddr(uiChannel));

        if(NULL != sMboxRegister)
        {
            sMboxRegister->rMBOX_CTRL   |= (MBOX_CFG_DF_FLUSH | MBOX_CFG_CF_FLUSH);

            ucRet   = SAL_RET_SUCCESS;
        }
    }

    return ucRet;
}

/**************************************************************************************************
*                                          MBOX_SendMessage
*
* [External] Send the message (command + data)
*
* @param        uiChannel
*               sMboxMessage (struct type)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_SendMessage
(
    MboxChIds_t                         uiChannel,
    const MboxMessage_t *               sMboxMessage
)
{
    MailboxReg_t *      sMboxRegister;
    SALRetCode_t        ucRet;
    uint32              uiIdx;
    uint32              uiAttemptCnt;
    uint32              uiStatus;

    sMboxRegister   = NULL_PTR;
    ucRet           = SAL_RET_FAILED;
    uiAttemptCnt    = MBOX_CFG_ATTEMPT_CNT;
    uiIdx           = 0U;

    if(MBOX_CH_MAX_VALUE <= uiChannel)
    {
        mcu_printf("[%s] Wrong Argument (Channel: %d)\n", __func__, uiChannel);
    }
    else if(sMboxMessage == NULL_PTR)
    {
        mcu_printf("[%s] Wrong Argument (Message: NULL)\n", __func__);
    }
    else
    {
        sMboxRegister = ((MailboxReg_t *) MBOX_GetBaseAddr(uiChannel));

        if(NULL != sMboxRegister)
        {
            /* Check the status of the opposite side */
            uiStatus = (sMboxRegister->rTMN_STS >> MBOX_SHIFT_OPP_TMN_STS) & 0x01U;
            if(uiStatus != 0)
            {
                while(0UL < uiAttemptCnt)
                {
                    if((sMboxRegister->rCMD_FIFO_STS & MBOX_CFG_CMD_MEMP) == MBOX_CFG_CMD_MEMP)
                    {
                        sMboxRegister->rMBOX_CTRL   &= ~(MBOX_CFG_OEN);

                        for(uiIdx = 0U; uiIdx < sMboxMessage->DataLen; uiIdx++)
                        {
                            sMboxRegister->rDAT_FIFO_TXD = sMboxMessage->Data[uiIdx];
                        }

                        for(uiIdx = 0U; uiIdx < sMboxMessage->CmdLen; uiIdx++)
                        {
                            sMboxRegister->rCMD_FIFO_TXD[uiIdx] = sMboxMessage->Cmd[uiIdx];
                        }

                        sMboxRegister->rMBOX_CTRL    |= MBOX_CFG_OEN;

                        ucRet   = SAL_RET_SUCCESS;

                        break;
                    }

                    uiAttemptCnt--;

                    BSP_NOP_DELAY();
                }
            }
        }
    }

    return  ucRet;
}

/**************************************************************************************************
*                                          MBOX_SendCommand
*
* [External] Send the message (Only command)
*
* @param        uiChannel
*               sMboxMessage (struct type)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_SendCommand
(
    MboxChIds_t                         uiChannel,
    const MboxMessage_t *               sMboxMessage
)
{
    MailboxReg_t *      sMboxRegister;
    SALRetCode_t        ucRet;
    uint32              uiIdx;
    uint32              uiAttemptCnt;
    uint32              uiStatus;

    sMboxRegister   = NULL_PTR;
    ucRet           = SAL_RET_FAILED;
    uiAttemptCnt    = MBOX_CFG_ATTEMPT_CNT;
    uiIdx           = 0UL;

    if(MBOX_CH_MAX_VALUE <= uiChannel)
    {
        mcu_printf("[%s] Wrong Argument (Channel: %d)\n", __func__, uiChannel);
    }
    else if(sMboxMessage == NULL_PTR)
    {
        mcu_printf("[%s] Wrong Argument (Message: NULL)\n", __func__);
    }
    else
    {
        sMboxRegister = ((MailboxReg_t *) MBOX_GetBaseAddr(uiChannel));

        if(NULL != sMboxRegister)
        {
            uiStatus = (sMboxRegister->rTMN_STS >> MBOX_SHIFT_OPP_TMN_STS) & 0x01U;
            if(uiStatus != 0)
            {
                while(0UL < uiAttemptCnt)
                {
                    if((sMboxRegister->rCMD_FIFO_STS & MBOX_CFG_CMD_MEMP) == MBOX_CFG_CMD_MEMP)
                    {
                        sMboxRegister->rMBOX_CTRL   &= ~(MBOX_CFG_OEN);

                        for(uiIdx = 0UL; uiIdx < sMboxMessage->CmdLen; uiIdx++)
                        {
                            sMboxRegister->rCMD_FIFO_TXD[uiIdx] = sMboxMessage->Cmd[uiIdx];
                        }

                        sMboxRegister->rMBOX_CTRL    |= MBOX_CFG_OEN;

                        ucRet = SAL_RET_SUCCESS;

                        break;
                    }

                    uiAttemptCnt--;

                    BSP_NOP_DELAY();
                }
            }
        }
    }

    return  ucRet;
}

/**************************************************************************************************
*                                          MBOX_ReadMessage
*
* [External] Read the message (command + data)
*
* @param        uiChannel
*               sMboxMessage (struct type)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_ReadMessage
(
    MboxChIds_t                         uiChannel,
    MboxMessage_t *                     sMboxMessage
)
{
    const MailboxReg_t *    sMboxRegister;
    SALRetCode_t            ucRet;
    uint32                  uiIdx;
    uint32                  uiStatus;

    sMboxRegister   = NULL_PTR;
    ucRet           = SAL_RET_FAILED;
    uiIdx           = 0UL;

    if(MBOX_CH_MAX_VALUE <= uiChannel)
    {
        mcu_printf("[%s] Wrong Argument (Channel: %d)\n", __func__, uiChannel);
    }
    else if(sMboxMessage == NULL_PTR)
    {
        mcu_printf("[%s] Wrong Argument (Message: NULL)\n", __func__);
    }
    else
    {
        sMboxRegister = ((MailboxReg_t *) MBOX_GetBaseAddr(uiChannel));

        if(NULL != sMboxRegister)
        {
            uiStatus = (sMboxRegister->rTMN_STS >> MBOX_SHIFT_OPP_TMN_STS) & 0x01U;
            if(uiStatus != 0)
            {
                if(0x00UL == (sMboxRegister->rDAT_FIFO_RX_STS & MBOX_CFG_DATA_SEMP))
                {
                    sMboxMessage->DataLen = (sMboxRegister->rDAT_FIFO_RX_STS & MBOX_MASK_DAT_SCOUNT);

                    for(uiIdx = 0UL; uiIdx < sMboxMessage->DataLen; uiIdx++)
                    {
                        sMboxMessage->Data[uiIdx] = sMboxRegister->rDAT_FIFO_RXD;
                    }
                }

                if(0x00UL == (sMboxRegister->rCMD_FIFO_STS & MBOX_CFG_CMD_SEMP))
                {
                    sMboxMessage->CmdLen = (sMboxRegister->rCMD_FIFO_STS & MBOX_MASK_CMD_SCOUNT) >> MBOX_SHIFT_CMD_SCOUNT;

                    for(uiIdx = 0UL; uiIdx < sMboxMessage->CmdLen; uiIdx++)
                    {
                        sMboxMessage->Cmd[uiIdx] = sMboxRegister->rCMD_FIFO_RXD[uiIdx];
                    }

                    ucRet   = SAL_RET_SUCCESS;
                }
            }
        }
    }

    return  ucRet;
}

/**************************************************************************************************
*                                          MBOX_ReadCommand
*
* [External] Read the message (Only command)
*
* @param        uiChannel
*               sMboxMessage (struct type)
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_ReadCommand
(
    MboxChIds_t                         uiChannel,
    MboxMessage_t *                     sMboxMessage
)
{
    const MailboxReg_t *    sMboxRegister;
    SALRetCode_t            ucRet;
    uint32                  uiIdx;
    uint32                  uiStatus;

    sMboxRegister   = NULL_PTR;
    ucRet           = SAL_RET_FAILED;
    uiIdx           = 0UL;

    if(MBOX_CH_MAX_VALUE <= uiChannel)
    {
        mcu_printf("[%s] Wrong Argument (Channel: %d)\n", __func__, uiChannel);
    }
    else if (sMboxMessage == NULL_PTR)
    {
        mcu_printf("[%s] Wrong Argument (Message: NULL)\n", __func__);
    }
    else
    {
        sMboxRegister = ((MailboxReg_t *) MBOX_GetBaseAddr(uiChannel));

        if(NULL != sMboxRegister)
        {
            uiStatus = (sMboxRegister->rTMN_STS >> MBOX_SHIFT_OPP_TMN_STS) & 0x01U;
            if(uiStatus != 0)
            {

                if(0x00UL == (sMboxRegister->rCMD_FIFO_STS & MBOX_CFG_CMD_SEMP))
                {
                    sMboxMessage->CmdLen = (sMboxRegister->rCMD_FIFO_STS & MBOX_MASK_CMD_SCOUNT) >> MBOX_SHIFT_CMD_SCOUNT;

                    for(uiIdx = 0UL; uiIdx < sMboxMessage->CmdLen; uiIdx++)
                    {
                        sMboxMessage->Cmd[uiIdx] = sMboxRegister->rCMD_FIFO_RXD[uiIdx];
                    }

                    ucRet   = SAL_RET_SUCCESS;
                }
            }
        }
    }

    return  ucRet;
}


/**************************************************************************************************
*                                          MBOX_Close
*
* [External] Close the mbox driver of the channel.
*
* @param        uiChannel
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
SALRetCode_t MBOX_Close
(
    MboxChIds_t                         uiChannel
)
{
    SALRetCode_t        ucRet;
    uint32              uiIRQn;
    MailboxReg_t *      sMboxRegister;

    ucRet           = SAL_RET_SUCCESS;
    uiIRQn          = NULL;

    if(MBOX_CH_MAX_VALUE <= uiChannel)
    {
        mcu_printf("[%s] Wrong Argument (Channel: %d)\n", __func__, uiChannel);
    }
    else
    {
        sMboxRegister = ((MailboxReg_t *) MBOX_GetBaseAddr((MboxChIds_t)uiChannel));

        if(NULL != sMboxRegister)
        {
            /* Clear Tx Interrup, Disable Tx, Rx Interrupt */
            sMboxRegister->rMBOX_CTRL = 0x00UL;

            uiIRQn = MBOX_GetIrqIndex(uiChannel, MBOX_CFG_IEN_WRITE);
            if(SAL_RET_SUCCESS != NVIC_IntSrcDis(uiIRQn))
            {
                ucRet = SAL_RET_FAILED;
            }

            uiIRQn = MBOX_GetIrqIndex(uiChannel, MBOX_CFG_IEN_READ);
            if(SAL_RET_SUCCESS != NVIC_IntSrcDis(uiIRQn))
            {
                ucRet = SAL_RET_FAILED;
            }

            (void)MBOX_SetOwnTerminalStatus(uiChannel, (uint32)FALSE);
            (void)MBOX_FlushFIFO(uiChannel);
        }
    }

    return ucRet;
}

/**************************************************************************************************
*                                          MBOX_Open
*
* [External] Ready the mbox driver of the channel.
*
* @param        uiChannel
*               pTxIrqHandler   ( Tx Interrupt Handler )
*               pRxIrqHandler   ( Rx Interrupt Handler )
*               uiIntLevel      ( MBOX_CFG_ILEVEL_0 ~ 3 )
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/

SALRetCode_t MBOX_Open
(
    MboxChIds_t                         uiChannel,
    IrqHandler_t                        pTxIrqHandler,
    IrqHandler_t                        pRxIrqHandler,
    MboxIntLevel_t                      uiIntLevel
)
{
    SALRetCode_t        ucRet;
    uint32              uiIRQn;

    ucRet           = SAL_RET_SUCCESS;
    uiIRQn          = NULL;

    if(pTxIrqHandler != NULL_PTR)
    {
        uiIRQn = MBOX_GetIrqIndex(uiChannel, MBOX_CFG_IEN_WRITE);
        if(SAL_RET_SUCCESS == NVIC_IntVectSet(uiIRQn, pTxIrqHandler))
        {
            if(SAL_RET_SUCCESS == NVIC_IntSrcEn(uiIRQn))
            {
                if(SAL_RET_SUCCESS != MBOX_EnableInterrupt(uiChannel, MBOX_CFG_IEN_WRITE))
                {
                    ucRet = SAL_RET_FAILED;
                }

            }
            else
            {
                ucRet = SAL_RET_FAILED;
            }
        }
        else
        {
            ucRet = SAL_RET_FAILED;
        }

    }

    if(pRxIrqHandler != NULL_PTR)
    {
        uiIRQn = MBOX_GetIrqIndex(uiChannel, MBOX_CFG_IEN_READ);
        if(SAL_RET_SUCCESS == NVIC_IntVectSet(uiIRQn, pRxIrqHandler))
        {
            if(SAL_RET_SUCCESS == NVIC_IntSrcEn(uiIRQn))
            {
                if(SAL_RET_SUCCESS != MBOX_SetInterruptLevel(uiChannel, uiIntLevel))
                {
                    ucRet = SAL_RET_FAILED;
                }

                if(SAL_RET_SUCCESS != MBOX_EnableInterrupt(uiChannel, MBOX_CFG_IEN_READ))
                {
                    ucRet = SAL_RET_FAILED;
                }
            }
            else
            {
                ucRet = SAL_RET_FAILED;
            }
        }
        else
        {
            ucRet = SAL_RET_FAILED;
        }
    }

    if(SAL_RET_SUCCESS != MBOX_FlushFIFO(uiChannel))
    {
        ucRet = SAL_RET_FAILED;
    }

    if(SAL_RET_SUCCESS != MBOX_SetOwnTerminalStatus(uiChannel, (uint32)TRUE))
    {
        ucRet = SAL_RET_FAILED;
    }

    return ucRet;
}

/**************************************************************************************************
*                                          MBOX_Init
*
* [External] Initialize the Mailbox ( Reset MBOX_CTRL register )
*
* @param
* @return       SALRetCode_t
*
* Notes
*
***************************************************************************************************/
void MBOX_Init
(
    void
)
{
    MailboxReg_t *      sMboxRegister;
    uint32              uiCh;

    sMboxRegister   = NULL_PTR;
    uiCh            = (uint32)MBOX_CH_A65_SECURE_HP;


    for(uiCh = (uint32)MBOX_CH_A65_SECURE_HP; uiCh < (uint32)MBOX_CH_MAX_VALUE; uiCh++)
    {

#if ( CORTEX_M7_0 == 1 )
        if(((uint32)MBOX_CH_M0_HP) == uiCh || ((uint32)MBOX_CH_M0_GP == uiCh))
        {
            continue;
        }
#elif ( CORTEX_M7_1 == 1 )
        if(((uint32)MBOX_CH_M1_HP == uiCh) || ((uint32)MBOX_CH_M1_GP == uiCh))
        {
            continue;
        }
#elif ( CORTEX_M7_2 == 1 )
        if(((uint32)MBOX_CH_M2_HP == uiCh) || ((uint32)MBOX_CH_M2_GP == uiCh))
        {
            continue;
        }
#elif ( CORTEX_M7_NP == 1 )
        if(((uint32)MBOX_CH_NP_HP == uiCh) || ((uint32)MBOX_CH_NP_GP == uiCh))
        {
            continue;
        }
#endif

        sMboxRegister = ((MailboxReg_t *) MBOX_GetBaseAddr((MboxChIds_t)uiCh));

        if(NULL != sMboxRegister)
        {
            sMboxRegister->rMBOX_CTRL = 0x00UL;
        }
    }
}

#endif  /* End of SIC_BSP_SUPPORT_DRIVER_MBOX */

