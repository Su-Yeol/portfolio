/*
***************************************************************************************************
*
*   FileName : dma_330.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include <sal_internal.h>

#include "dma_330.h"
#include <debug.h>
#if DMA_PERIPH_PROVISION_16550_SUPPORT
#include "16550_uart.h"
#include "socal/uart.h"
#endif

#if DMA_PERIPH_PROVISION_QSPI_SUPPORT
#include "socal/qspi.h"
#endif

/////
#define DMA330_MMIO

#define DMA330_SECURE_DEFAULT_NS

#ifndef MIN
#define MIN(a, b) ((a) > (b) ? (b) : (a))
#endif // MIN

#ifndef ARRAY_COUNT
#define ARRAY_COUNT(array) (sizeof(array) / sizeof(array[0]))
#endif

//
// SoCAL stand in for DMA Controller registers
//
// The base can be one of the following: 
//  - DMANONSECURE_ADDR
//  - DMASECURE_ADDR
//
// Macros which have a channel parameter does no validation.
//

// DMA Manager Status Register
#define DMA_DSR_OFST 0x0
#define DMA_DSR_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_DSR_OFST))
#define DMA_DSR_DMASTATUS_SET_MSK 0x0000000f
#define DMA_DSR_DMASTATUS_GET(value) ((value) & 0x0000000f)

// DMA Program Counter Register
#define DMA_DPC_OFST 0x4
#define DMA_DPC_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_DPC_OFST))

// Interrupt Enable Register
#define DMA_INTEN_OFST 0x20
#define DMA_INTEN_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_INTEN_OFST))

// Event-Interrupt Raw Status Register
#define DMA_INT_EVENT_RIS_OFST 0x24
#define DMA_INT_EVENT_RIS_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_INT_EVENT_RIS_OFST))

// Interrupt Status Register
#define DMA_INTMIS_OFST 0x28
#define DMA_INTMIS_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_INTMIS_OFST))

// Interrupt Clear Register
#define DMA_INTCLR_OFST 0x2c
#define DMA_INTCLR_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_INTCLR_OFST))

// Fault Status DMA Manager Register
#define DMA_FSRD_OFST 0x30
#define DMA_FSRD_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_FSRD_OFST))

// Fault Status DMA Channel Register
#define DMA_FSRC_OFST 0x34
#define DMA_FSRC_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_FSRC_OFST))

// Fault Type DMA Manager Register
#define DMA_FTRD_OFST 0x38
#define DMA_FTRD_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_FSRD_OFST))

// Fault Type DMA Channel Registers
#define DMA_FTRx_OFST(channel) (0x40 + 0x4 * (channel))
#define DMA_FTRx_ADDR(base, channel) CAST(void *, (CAST(char *, (base)) + DMA_FTRx_OFST(channel)))

// Channel Status Registers
#define DMA_CSRx_OFST(channel) (0x100 + 0x8 * (channel))
#define DMA_CSRx_ADDR(base, channel) CAST(void *, (CAST(char *, (base)) + DMA_CSRx_OFST(channel)))
#define DMA_CSRx_CHANNELSTATUS_SET_MSK 0x0000000f
#define DMA_CSRx_CHANNELSTATUS_GET(value) ((value) & 0x0000000f)

// Channel Program Counter Registers
#define DMA_CPCx_OFST(channel) (0x104 + 0x8 * (channel))
#define DMA_CPCx_ADDR(base, channel) CAST(void *, (CAST(char *, (base)) + DMA_CPCx_OFST(channel)))

// Source Address Registers
#define DMA_SARx_OFST(channel) (0x400 + 0x20 * (channel))
#define DMA_SARx_ADDR(base, channel) CAST(void *, (CAST(char *, (base)) + DMA_SARx_OFST(channel)))

// Destination Address Registers
#define DMA_DARx_OFST(channel) (0x404 + 0x20 * (channel))
#define DMA_DARx_ADDR(base, channel) CAST(void *, (CAST(char *, (base)) + DMA_DARx_OFST(channel)))

// Channel Control Registers
#define DMA_CCRx_OFST(channel) (0x408 + 0x20 * (channel))
#define DMA_CCRx_ADDR(base, channel) CAST(void *, (CAST(char *, (base)) + DMA_CCRx_OFST(channel)))

// Loop Counter 0 Registers
#define DMA_LC0_x_OFST(channel) (0x40c + 0x20 * (channel))
#define DMA_LC0_x_ADDR(base, channel) CAST(void *, (CAST(char *, (base)) + DMA_LC0_x_OFST(channel)))

// Loop Counter 1 Registers
#define DMA_LC1_x_OFST(channel) (0x410 + 0x20 * (channel))
#define DMA_LC1_x_ADDR(base, channel) CAST(void *, (CAST(char *, (base)) + DMA_LC1_x_OFST(channel)))

// Debug Status Register
#define DMA_DBGSTATUS_OFST 0xd00
#define DMA_DBGSTATUS_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_DBGSTATUS_OFST))

// Debug Command Register
#define DMA_DBGCMD_OFST 0xd04
#define DMA_DBGCMD_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_DBGCMD_OFST))

// Debug Instruction-0 Register
#define DMA_DBGINST0_OFST 0xd08
#define DMA_DBGINST0_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_DBGINST0_OFST))
#define DMA_DBGINST0_CHANNELNUMBER_SET(value) (((value) & 0x7) << 8)
#define DMA_DBGINST0_DEBUGTHREAD_SET(value) ((value) & 0x1)
#define DMA_DBGINST0_DEBUGTHREAD_E_MANAGER 0
#define DMA_DBGINST0_DEBUGTHREAD_E_CHANNEL 1
#define DMA_DBGINST0_INSTRUCTIONBYTE0_SET(value) (((value) & 0xff) << 16)
#define DMA_DBGINST0_INSTRUCTIONBYTE1_SET(value) (((value) & 0xff) << 24)

// Debug Instruction-1 Register
#define DMA_DBGINST1_OFST 0xd0c
#define DMA_DBGINST1_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_DBGINST1_OFST))

// Configuration Registers 0 - 4
#define DMA_CR0_OFST 0xe00
#define DMA_CR1_OFST 0xe04
#define DMA_CR2_OFST 0xe08
#define DMA_CR3_OFST 0xe0c
#define DMA_CR4_OFST 0xe10
#define DMA_CR0_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_CR0_OFST))
#define DMA_CR1_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_CR1_OFST))
#define DMA_CR2_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_CR2_OFST))
#define DMA_CR3_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_CR3_OFST))
#define DMA_CR4_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_CR4_OFST))

// DMA Configuration Register
#define DMA_CRD_OFST 0xe14
#define DMA_CRD_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_CRD_OFST))

// Watchdog Register
#define DMA_WD_OFST 0xe80
#define DMA_WD_ADDR(base) CAST(void *, (CAST(char *, (base)) + DMA_WD_OFST))

#ifdef DMA330_MMIO
/////
typedef volatile struct DMA330_MAP {
    /* 0x000 */
    struct {
        uint32 DSR;           /* RO */
        uint32 DPC;           /* RO */
        uint32 reserved0[6];
        uint32 INTEN;         /* RW */
        uint32 INT_EVENT_RIS; /* RO */
        uint32 INTMIS;        /* RO */
        uint32 INTCLR;        /* WO */
        uint32 FSDM;           /* RO */
        uint32 FSDC;           /* RO */
        uint32 FTDM;           /* RO */
        uint32 reserved1[1];
        uint32 FTDC[DMA_CHANNEL_CNT];        /* RO */
        uint32 reserved2[40];
    } CTRL;
    /* 0x100 */
    struct {
        uint32 CSR;           /* RO */
        uint32 CPC;           /* RO */
    } CHSTAT[DMA_CHANNEL_CNT];
    uint32 reserved0[176];
    /* 0x400 */
    struct dma330_axi_map {
        uint32 SAR;           /* RO */
        uint32 DAR;           /* RO */
        uint32 CCR;           /* RO */
        uint32 LC0;         /* RO */
        uint32 LC1;         /* RO */
        uint32 reserved[3];
    } AXI[DMA_CHANNEL_CNT];
    uint32 reserved1[512];
    /* 0xd00 */
    struct {
        uint32 DBGSTATUS;     /* RO */
        uint32 DBGCMD;        /* WO */
        uint32 DBGINST0;    /* WO */
        uint32 DBGINST1;    /* WO */
        uint32 reserved[60];
    } DEBUG;
    /* 0xe00 */
    struct {
        uint32 CR[5];         /* RO */
        uint32 CRD;           /* RO */
        uint32 reserved[58];
    } CONFIG;
    /* 0xf00 */
    uint32 reserved2[56];
    /* 0xfe0 */
    struct {
        uint32 PERIPH[4];     /* RO */
        uint32 PCELL[4];      /* RO */
    } ID;
} DMA330_MAP_T;



static DMA330_MAP_T * stDma330NSEReg = (DMA330_MAP_T *)(0x45200000UL);
//static DMA330_MAP_T * stDma330SEReg = (DMA330_MAP_T *)(0x45210000UL);

#endif
typedef volatile struct DAM330_WRAP
{
    uint32 DMA_BOOT_CFG;
    uint32 DMA_BOOT_ADDR;
    uint32 DMA_BOOT_IRQ_NS;
    uint32 DMA_BOOT_PERIPH_NS;
    uint32 DMA_REQ_CFG;
    uint32 DMA_ADDR_MSB_CH0;
    uint32 DMA_ADDR_MSB_CH1;
    uint32 DMA_ADDR_MSB_CH2;
    uint32 DMA_ADDR_MSB_CH3;
    uint32 DMA_ADDR_MSB_CH4;
    uint32 DMA_ADDR_MSB_CH5;
    uint32 DMA_ADDR_MSB_CH6;
    uint32 DMA_ADDR_MSB_CH7;
    uint32 DMA_ADDR_MSB_CH8;
    uint32 DMA_ADDR_MSB_CH9;
    uint32 DMA_ADDR_MSB_CH10;
    uint32 DMA_ADDR_MSB_CH11;
    uint32 DMA_ADDR_MSB_CH12;
    uint32 DMA_ADDR_MSB_CH13;
    uint32 DMA_ADDR_MSB_CH14;
    uint32 DMA_ADDR_MSB_CH15;

} DAM330_WRAP_T;
static DAM330_WRAP_T * stDma330Wrap = (DAM330_WRAP_T *)(0x45211000UL);

//
// Internal Data structures
//

// This flag marks the channel as being allocated.
#define DMA_CHANNEL_INFO_FLAG_ALLOCED (1 << 0)

typedef struct DMA_CHANNEL_INFO_s
{
    uint8 flag;
}
DMA_CHANNEL_INFO_t;

static DMA_CHANNEL_INFO_t channel_info_array[DMA_CHANNEL_CNT];
#define PASSWORD 0x5AFEACE5

/////
#define wr_data_32b(addr, data) (*(volatile uint32*)(addr)) = data
#define rd_data_32b(addr)       (*(volatile uint32*)(addr))

DMA_ERR dma_init(const DMA_CFG_t * dma_cfg)
{
    // Initialize the channel information array
    for (int i = 0; i < 8; ++i)
    {
        channel_info_array[i].flag = 0;
    }

    //stDma330Wrap->DMA_BOOT_CFG = 0x10001;

    //stDma330Wrap->DMA_BOOT_ADDR = 0x38000000;
    wr_data_32b(0x454007F8, PASSWORD); // IMC WR PW
    wr_data_32b(0x454007FC, 0x0);      // IMC WR LOCK release
    wr_data_32b(0x45400000, 0x0);      // SRAM ECC Disable

    // Update the System Manager DMA configuration items
    
#ifdef NEVER
    uint32 dmactrl = 0;
#endif /* NEVER */

    // Handle FPGA / CAN muxing
    for (int i = 0; i < 4; ++i)
    {
        // The default is FPGA.
        switch (dma_cfg->periph_mux[i])
        {
        case DMA_PERIPH_MUX_DEFAULT:
        case DMA_PERIPH_MUX_FPGA:
            break;
        case DMA_PERIPH_MUX_CAN:
#ifdef NEVER
            dmactrl |= (SYSMGR_DMA_CTL_CHANSEL_0_SET_MSK << i);
#endif /* NEVER */
            break;
        default:
            return E_ERROR;
        }
    }

    // Handle Manager security
    // Default is Secure state.
    switch (dma_cfg->manager_sec)
    {
    case DMA_SECURITY_DEFAULT:
    case DMA_SECURITY_SECURE:
        break;
    case DMA_SECURITY_NONSECURE:
#ifdef NEVER
        dmactrl |= SYSMGR_DMA_CTL_MGRNONSECURE_SET_MSK;
#endif /* NEVER */
        break;
    default:
        return E_ERROR;
    }

#ifdef NEVER
    // Handle IRQ security
    for (int i = 0; i < SYSMGR_DMA_CTL_IRQNONSECURE_WIDTH; ++i)
    {
        // Default is Secure state.
        switch (dma_cfg->irq_sec[i])
        {
        case DMA_SECURITY_DEFAULT:
        case DMA_SECURITY_SECURE:
            break;
        case DMA_SECURITY_NONSECURE:
            dmactrl |= (1 << (i + SYSMGR_DMA_CTL_IRQNONSECURE_LSB));
            break;
        default:
            return E_ERROR;
        }
    }
#endif /* NEVER */

#ifdef NEVER
    write_word(SYSMGR_DMA_CTL_ADDR, dmactrl);
#endif /* NEVER */

    // Update the System Manager DMA peripheral security items

    uint32 dmapersecurity = 0;

    for (int i = 0; i < 32; ++i)
    {
        // Default is Secure state.
        switch (dma_cfg->periph_sec[i])
        {
        case DMA_SECURITY_DEFAULT:
        case DMA_SECURITY_SECURE:
            break;
        case DMA_SECURITY_NONSECURE:
            dmapersecurity |= (1 << i);
            break;
        default:
            return E_ERROR;
        }
    }

#ifdef NEVER
    write_word(SYSMGR_DMA_PERSECURITY_ADDR, dmapersecurity);

    // Take DMA out of reset.

    clrbits_word(RSTMGR_PERMODRST_ADDR, RSTMGR_PERMODRST_DMA_SET_MSK);
#endif /* NEVER */

    return E_SUCCESS;
}


DMA_ERR dma_uninit(void)
{
    // DMAKILL all channel and free all allocated channels.
    for (int i = 0; i < 8; ++i)
    {
        if (channel_info_array[i].flag & DMA_CHANNEL_INFO_FLAG_ALLOCED)
        {
            dma_channel_kill((DMA_CHANNEL_t)i);
            dma_channel_free((DMA_CHANNEL_t)i);
        }
    }

    // Put DMA into reset.

#ifdef NEVER
    setbits_word(RSTMGR_PERMODRST_ADDR, RSTMGR_PERMODRST_DMA_SET_MSK);
#endif /* NEVER */

    return E_SUCCESS;
}

DMA_ERR dma_channel_alloc(DMA_CHANNEL_t channel)
{
    // Validate channel
    switch (channel)
    {
    case DMA_CHANNEL_0:
    case DMA_CHANNEL_1:
    case DMA_CHANNEL_2:
    case DMA_CHANNEL_3:
    case DMA_CHANNEL_4:
    case DMA_CHANNEL_5:
    case DMA_CHANNEL_6:
    case DMA_CHANNEL_7:
        break;
    default:
        return E_BAD_ARG;
    }

    // Verify channel is unallocated

    if (channel_info_array[channel].flag & DMA_CHANNEL_INFO_FLAG_ALLOCED)
    {
        return E_ERROR;
    }

    // Mark channel as allocated

    channel_info_array[channel].flag |= DMA_CHANNEL_INFO_FLAG_ALLOCED;

    return E_SUCCESS;
}

DMA_ERR dma_channel_alloc_any(DMA_CHANNEL_t * allocated)
{
    // Sweep channel array for unallocated channel

    for (int i = 0; i < 8; ++i)
    {
        if (!(channel_info_array[i].flag & DMA_CHANNEL_INFO_FLAG_ALLOCED))
        {
            // Allocate that free channel.

            DMA_ERR status = dma_channel_alloc((DMA_CHANNEL_t)i);
            if (status == E_SUCCESS)
            {
                *allocated = (DMA_CHANNEL_t)i;
            }
            return status;
        }
    }

    // No free channels found.

    return E_ERROR;
}

DMA_ERR dma_channel_free(DMA_CHANNEL_t channel)
{
    // Verify channel is stopped

    DMA_CHANNEL_STATE_t state;
    DMA_ERR status = dma_channel_state_get(channel, &state);

    // Validate channel
    switch (channel)
    {
    case DMA_CHANNEL_0:
    case DMA_CHANNEL_1:
    case DMA_CHANNEL_2:
    case DMA_CHANNEL_3:
    case DMA_CHANNEL_4:
    case DMA_CHANNEL_5:
    case DMA_CHANNEL_6:
    case DMA_CHANNEL_7:
        break;
    default:
        return E_BAD_ARG;
    }

    // Verify channel is allocated

    if (!(channel_info_array[channel].flag & DMA_CHANNEL_INFO_FLAG_ALLOCED))
    {
        return E_ERROR;
    }

    if (status != E_SUCCESS)
    {
        return status;
    }
    if (state != DMA_CHANNEL_STATE_STOPPED)
    {
        return E_ERROR;
    }

    // Mark channel as unallocated.

    channel_info_array[channel].flag &= ~DMA_CHANNEL_INFO_FLAG_ALLOCED;

    return E_SUCCESS;
}

DMA_ERR dma_channel_exec(DMA_CHANNEL_t channel, DMA_PROGRAM_t * pgm)
{
    DMA_CHANNEL_STATE_t state;
    DMA_ERR status;
    uint32 start;
    uint32 boot_cfg = 1;
    uint32 boot_manager_ns = 1;
    uint32 boot_irq_ns = 0xFFFFFFFF;
    uint32 boot_periph_ns = 0xFFFFFFFF;

    // Validate channel
    switch (channel)
    {
    case DMA_CHANNEL_0:
    case DMA_CHANNEL_1:
    case DMA_CHANNEL_2:
    case DMA_CHANNEL_3:
    case DMA_CHANNEL_4:
    case DMA_CHANNEL_5:
    case DMA_CHANNEL_6:
    case DMA_CHANNEL_7:
        break;
    default:
        return E_BAD_ARG;
    }

    // Verify channel is allocated

    if (!(channel_info_array[channel].flag & DMA_CHANNEL_INFO_FLAG_ALLOCED))
    {
        return E_ERROR;
    }

    // Verify channel is stopped

    status = dma_channel_state_get(channel, &state);
    if (status != E_SUCCESS)
    {
        return status;
    }
    if (state != DMA_CHANNEL_STATE_STOPPED)
    {
        return E_ERROR;
    }

    // Validate the program

    if (DMA330_Instr_validate(pgm) != E_SUCCESS)
    {
        return E_ERROR;
    }

    //
    // Execute the program
    //

    // Get the start address

    start = (uint32) &pgm->program[pgm->buffer_start];

    sic_printf("DMA[exec]: pgm->program = %x \n", pgm->program);
    sic_printf("DMA[exec]: start        = %x \n", (void *)start);

    // Configure DBGINST0 and DBGINST1 to execute DMAGO targetting the requested channel.

    // For information on APB Interface, see PL330, section 2.5.1.
    // For information on DBGINSTx, see PL330, section 3.3.20 - 3.3.21.
    // For information on DMAGO, see PL330, section 4.3.5.

    #ifdef DMA330_MMIO
    stDma330Wrap->DMA_BOOT_CFG = ((boot_manager_ns << 16) + (boot_cfg));
    stDma330Wrap->DMA_BOOT_ADDR = start;
    stDma330Wrap->DMA_BOOT_IRQ_NS = boot_irq_ns;
    stDma330Wrap->DMA_BOOT_PERIPH_NS = boot_periph_ns;

    #ifdef DMA330_SECURE_DEFAULT_NS
    stDma330NSEReg->DEBUG.DBGINST0 = (DMA_DBGINST0_INSTRUCTIONBYTE0_SET(0xa2) | 
                   DMA_DBGINST0_INSTRUCTIONBYTE1_SET(channel));
	#else
    stDma330NSEReg->DEBUG.DBGINST0 = (DMA_DBGINST0_INSTRUCTIONBYTE0_SET(0xa0) | 
                   DMA_DBGINST0_INSTRUCTIONBYTE1_SET(channel));
	#endif
    stDma330NSEReg->DEBUG.DBGINST1 = start;

    // Execute the instruction held in DBGINST{0,1}

    // For information on DBGCMD, see PL330, section 3.3.19.

    stDma330NSEReg->DEBUG.DBGCMD = 0;
                   
    #else
    write_word(DMA_DBGINST0_ADDR(DMASECURE_ADDR),
                   DMA_DBGINST0_INSTRUCTIONBYTE0_SET(0xa0) | 
                   DMA_DBGINST0_INSTRUCTIONBYTE1_SET(channel));

    write_word(DMA_DBGINST1_ADDR(DMASECURE_ADDR), start);

    // Execute the instruction held in DBGINST{0,1}

    // For information on DBGCMD, see PL330, section 3.3.19.

    write_word(DMA_DBGCMD_ADDR(DMASECURE_ADDR), 0);
                   
    #endif

    return E_SUCCESS;
}

DMA_ERR dma_channel_kill(DMA_CHANNEL_t channel)
{
    DMA_ERR status;
    DMA_CHANNEL_STATE_t current;
    uint32 i;

    // Validate channel
    switch (channel)
    {
    case DMA_CHANNEL_0:
    case DMA_CHANNEL_1:
    case DMA_CHANNEL_2:
    case DMA_CHANNEL_3:
    case DMA_CHANNEL_4:
    case DMA_CHANNEL_5:
    case DMA_CHANNEL_6:
    case DMA_CHANNEL_7:
        break;
    default:
        return E_BAD_ARG;
    }

    // Verify channel is allocated

    if (!(channel_info_array[channel].flag & DMA_CHANNEL_INFO_FLAG_ALLOCED))
    {
        return E_ERROR;
    }

    // NOTE: Don't worry about the current channel state. Just issue DMAKILL
    //   instruction. The channel state cannot move from from Stopped back to
    //   Killing.

    // Configure DBGINST0 to execute DMAKILL on the requested channel thread.
    // DMAKILL is short enough not to use DBGINST1 register.

    // For information on APB Interface, see PL330, section 2.5.1.
    // For information on DBGINSTx, see PL330, section 3.3.20 - 3.3.21.
    // For information on DMAKILL, see PL330, section 4.3.6.

#ifdef DMA330_MMIO
    stDma330NSEReg->DEBUG.DBGINST0 = (DMA_DBGINST0_INSTRUCTIONBYTE0_SET(0x1) |
                   DMA_DBGINST0_CHANNELNUMBER_SET(channel) |
                   DMA_DBGINST0_DEBUGTHREAD_SET(DMA_DBGINST0_DEBUGTHREAD_E_CHANNEL));

    // Execute the instruction held in DBGINST0

    // For information on DBGCMD, see PL330, section 3.3.19.

    stDma330NSEReg->DEBUG.DBGCMD = 0;
#else
    write_word(DMA_DBGINST0_ADDR(DMASECURE_ADDR),
                   DMA_DBGINST0_INSTRUCTIONBYTE0_SET(0x1) |
                   DMA_DBGINST0_CHANNELNUMBER_SET(channel) |
                   DMA_DBGINST0_DEBUGTHREAD_SET(DMA_DBGINST0_DEBUGTHREAD_E_CHANNEL));

    // Execute the instruction held in DBGINST0

    // For information on DBGCMD, see PL330, section 3.3.19.

    write_word(DMA_DBGCMD_ADDR(DMASECURE_ADDR), 0);
#endif
    // Wait for channel to move to KILLING or STOPPED state. Do not wait for
    // the STOPPED only. If the AXI transaction hangs permanently, it can be
    // waiting indefinately.

    status = E_SUCCESS;
    i = 20000;

    while (--i)
    {
        status = dma_channel_state_get(channel, &current);
        if (status != E_SUCCESS)
        {
            break;
        }
        if (   (current == DMA_CHANNEL_STATE_KILLING)
            || (current == DMA_CHANNEL_STATE_STOPPED))
        {
            break;
        }
    }

    if (i == 0)
    {
        status = E_TMO;
    }

    return status;
}

DMA_ERR dma_channel_reg_get(DMA_CHANNEL_t channel,
                                        DMA_PROGRAM_REG_t reg, uint32 * val)
{
    // Validate channel
    switch (channel)
    {
    case DMA_CHANNEL_0:
    case DMA_CHANNEL_1:
    case DMA_CHANNEL_2:
    case DMA_CHANNEL_3:
    case DMA_CHANNEL_4:
    case DMA_CHANNEL_5:
    case DMA_CHANNEL_6:
    case DMA_CHANNEL_7:
        break;
    default:
        return E_BAD_ARG;
    }

    // For information on SAR, see PL330, section 3.3.13.
    // For information on DAR, see PL330, section 3.3.14.
    // For information on CCR, see PL330, section 3.3.15.

    switch (reg)
    {
    case DMA_PROGRAM_REG_SAR:
#ifdef DMA330_MMIO      
        stDma330NSEReg->AXI[channel].SAR;
#else
        *val = read_word(DMA_SARx_ADDR(DMASECURE_ADDR, channel));
#endif
        break;
    case DMA_PROGRAM_REG_DAR:
#ifdef DMA330_MMIO      
        stDma330NSEReg->AXI[channel].DAR;
#else
        *val = read_word(DMA_DARx_ADDR(DMASECURE_ADDR, channel));
#endif
        break;
    case DMA_PROGRAM_REG_CCR:
#ifdef DMA330_MMIO      
        stDma330NSEReg->AXI[channel].CCR;
#else
        *val = read_word(DMA_CCRx_ADDR(DMASECURE_ADDR, channel));
#endif
        break;
    default:
        return E_BAD_ARG;
    }

    return E_SUCCESS;
}

DMA_ERR dma_send_event(DMA_EVENT_t evt_num)
{
    // Validate evt_num

    switch (evt_num)
    {
    case DMA_EVENT_0:
    case DMA_EVENT_1:
    case DMA_EVENT_2:
    case DMA_EVENT_3:
    case DMA_EVENT_4:
    case DMA_EVENT_5:
    case DMA_EVENT_6:
    case DMA_EVENT_7:
    case DMA_EVENT_ABORT:
        break;
    default:
        return E_BAD_ARG;
    }

    // Issue the DMASEV on the DMA manager thread.
    // DMASEV is short enough not to use DBGINST1 register.

    // For information on APB Interface, see PL330, section 2.5.1.
    // For information on DBGINSTx, see PL330, section 3.3.20 - 3.3.21.
    // For information on DMASEV, see PL330, section 4.3.15.
#ifdef DMA330_MMIO
    stDma330NSEReg->DEBUG.DBGINST0 = (DMA_DBGINST0_INSTRUCTIONBYTE0_SET(0x34) | // opcode for DMASEV
                   DMA_DBGINST0_INSTRUCTIONBYTE1_SET(evt_num << 3) |
                   DMA_DBGINST0_DEBUGTHREAD_SET(DMA_DBGINST0_DEBUGTHREAD_E_MANAGER)
        );

    stDma330NSEReg->DEBUG.DBGCMD = 0x0UL;
#else

    write_word(DMA_DBGINST0_ADDR(DMASECURE_ADDR),
                   DMA_DBGINST0_INSTRUCTIONBYTE0_SET(0x34) | // opcode for DMASEV
                   DMA_DBGINST0_INSTRUCTIONBYTE1_SET(evt_num << 3) |
                   DMA_DBGINST0_DEBUGTHREAD_SET(DMA_DBGINST0_DEBUGTHREAD_E_MANAGER)
        );

    // Execute the instruction held in DBGINST0

    // For information on DBGCMD, see PL330, section 3.3.19.

    write_word(DMA_DBGCMD_ADDR(DMASECURE_ADDR), 0);
#endif
    return E_SUCCESS;
}

DMA_ERR dma_manager_state_get(DMA_MANAGER_STATE_t * state)
{
    // For information on DSR, see PL330, section 3.3.1.
#ifdef DMA330_MMIO
    uint32 raw_state = stDma330NSEReg->CTRL.DSR;
#else
    uint32 raw_state = read_word(DMA_DSR_ADDR(DMASECURE_ADDR));
#endif
    *state = (DMA_MANAGER_STATE_t)DMA_DSR_DMASTATUS_GET(raw_state);

    return E_SUCCESS;
}

DMA_ERR dma_channel_state_get(DMA_CHANNEL_t channel,
                                          DMA_CHANNEL_STATE_t * state)
{
    uint32 raw_state = 0;

    // Validate channel
    switch (channel)
    {
    case DMA_CHANNEL_0:
    case DMA_CHANNEL_1:
    case DMA_CHANNEL_2:
    case DMA_CHANNEL_3:
    case DMA_CHANNEL_4:
    case DMA_CHANNEL_5:
    case DMA_CHANNEL_6:
    case DMA_CHANNEL_7:
        break;
    default:
        return E_BAD_ARG;
    }

    // For information on CSR, see PL330, section 3.3.11.
#ifdef DMA330_MMIO
    raw_state = stDma330NSEReg->CHSTAT[channel].CSR;    
#else    
    raw_state = read_word(DMA_CSRx_ADDR(DMASECURE_ADDR, channel));
#endif
    *state = (DMA_CHANNEL_STATE_t)DMA_CSRx_CHANNELSTATUS_GET(raw_state);

    return E_SUCCESS;
}

DMA_ERR dma_manager_fault_status_get(DMA_MANAGER_FAULT_t * fault)
{
    // For information on FTRD, see PL330, section 3.3.9.
    if ( fault != NULL_PTR)
    {
#ifdef DMA330_MMIO
        *fault = stDma330NSEReg->CTRL.FSDM;
#else
        *fault = (DMA_MANAGER_FAULT_t)read_word(DMA_FTRD_ADDR(DMASECURE_ADDR));
#endif
    }
    return E_SUCCESS;
}

DMA_ERR dma_channel_fault_status_get(DMA_CHANNEL_t channel,
                                                 DMA_CHANNEL_FAULT_t * fault)
{
    // Validate channel
    switch (channel)
    {
    case DMA_CHANNEL_0:
    case DMA_CHANNEL_1:
    case DMA_CHANNEL_2:
    case DMA_CHANNEL_3:
    case DMA_CHANNEL_4:
    case DMA_CHANNEL_5:
    case DMA_CHANNEL_6:
    case DMA_CHANNEL_7:
        break;
    default:
        return E_BAD_ARG;
    }

    // For information on FTR, see PL330, section 3.3.10.

#ifdef DMA330_MMIO
    *fault = stDma330NSEReg->CTRL.FSDC;
#else
    *fault = (DMA_CHANNEL_FAULT_t)read_word(DMA_FTRx_ADDR(DMASECURE_ADDR, channel));
#endif  
    return E_SUCCESS;
}

DMA_ERR dma_event_int_select(DMA_EVENT_t evt_num,
                                         DMA_EVENT_SELECT_t opt)
{
    // Validate evt_num
    switch (evt_num)
    {
    case DMA_EVENT_0:
    case DMA_EVENT_1:
    case DMA_EVENT_2:
    case DMA_EVENT_3:
    case DMA_EVENT_4:
    case DMA_EVENT_5:
    case DMA_EVENT_6:
    case DMA_EVENT_7:
    case DMA_EVENT_ABORT:
        break;
    default:
        return E_BAD_ARG;
    }

    // For information on INTEN, see PL330, section 3.3.3.

    switch (opt)
    {
    case DMA_EVENT_SELECT_SEND_EVT:
#ifdef DMA330_MMIO
        stDma330NSEReg->CTRL.INTEN &= ~(uint32)(0x1UL << evt_num);
#else
        clrbits_word(DMA_INTEN_ADDR(DMASECURE_ADDR), 1 << evt_num);
#endif
        break;
    case DMA_EVENT_SELECT_SIG_IRQ:
#ifdef DMA330_MMIO
        stDma330NSEReg->CTRL.INTEN |= (uint32)(0x1UL << evt_num);
#else
        setbits_word(DMA_INTEN_ADDR(DMASECURE_ADDR), 1 << evt_num);
#endif
        break;
    default:
        return E_BAD_ARG;
    }

    return E_SUCCESS;
}

DMA_ERR dma_event_int_status_get_raw(DMA_EVENT_t evt_num)
{
    uint32 status_raw;

    // Validate evt_num
    switch (evt_num)
    {
    case DMA_EVENT_0:
    case DMA_EVENT_1:
    case DMA_EVENT_2:
    case DMA_EVENT_3:
    case DMA_EVENT_4:
    case DMA_EVENT_5:
    case DMA_EVENT_6:
    case DMA_EVENT_7:
    case DMA_EVENT_ABORT:
        break;
    default:
        return E_BAD_ARG;
    }

    // For information on INT_EVENT_RIS, see PL330, section 3.3.4.
#ifdef DMA330_MMIO
    status_raw = stDma330NSEReg->CTRL.INT_EVENT_RIS;
#else
    status_raw = read_word(DMA_INT_EVENT_RIS_ADDR(DMASECURE_ADDR));
#endif
    if (status_raw & (1 << evt_num))
    {
        return E_TRUE;
    }
    else
    {
        return E_FALSE;
    }
}

DMA_ERR dma_int_status_get(DMA_EVENT_t irq_num)
{
    uint32 int_status;

    // Validate evt_num
    switch (irq_num)
    {
    case DMA_EVENT_0:
    case DMA_EVENT_1:
    case DMA_EVENT_2:
    case DMA_EVENT_3:
    case DMA_EVENT_4:
    case DMA_EVENT_5:
    case DMA_EVENT_6:
    case DMA_EVENT_7:
    case DMA_EVENT_ABORT:
        break;
    default:
        return E_BAD_ARG;
    }

    // For information on INTMIS, see PL330, section 3.3.5.
#ifdef DMA330_MMIO
    int_status = stDma330NSEReg->CTRL.INTMIS;
#else
    int_status = read_word(DMA_INTMIS_ADDR(DMASECURE_ADDR));
#endif
    if (int_status & (1 << irq_num))
    {
        return E_TRUE;
    }
    else
    {
        return E_FALSE;
    }
}

DMA_ERR dma_int_clear(DMA_EVENT_t irq_num)
{
    // Validate evt_num
    switch (irq_num)
    {
    case DMA_EVENT_0:
    case DMA_EVENT_1:
    case DMA_EVENT_2:
    case DMA_EVENT_3:
    case DMA_EVENT_4:
    case DMA_EVENT_5:
    case DMA_EVENT_6:
    case DMA_EVENT_7:
    case DMA_EVENT_ABORT:
        break;
    default:
        return E_BAD_ARG;
    }

    // For information on INTCLR, see PL330, section 3.3.6.
#ifdef DMA330_MMIO
    stDma330NSEReg->CTRL.INTCLR |= (uint32)(0x1ul << irq_num);
#else
    write_word(DMA_INTCLR_ADDR(DMASECURE_ADDR), 1 << irq_num);
#endif
    return E_SUCCESS;
}

/////

DMA_ERR dma_memory_to_memory(DMA_CHANNEL_t channel,
                                         DMA_PROGRAM_t * program,
                                         void * dst,
                                         const void * src,
                                         uint32 size,
                                         int8 send_evt,
                                         DMA_EVENT_t evt)
{
    DMA_ERR status = E_SUCCESS;

    // If the size is zero, and no event is requested, just return success.
    if ((size == 0) && (send_evt == FALSE))
    {
        return status;
    }

    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_init(program);
    }

    if (size != 0)
    {
        uint32 sizeleft = 0;
        uint32 burstcount = 0;
        int8 correction = 0;
    
        uint32  udst = (uint32)dst;
        uint32  usrc = (uint32)src;

        sic_printf("DMA[M->M]: dst  = %x \r\n", dst);
        sic_printf("DMA[M->M]: src  = %x \r\n", src);
        sic_printf("DMA[M->M]: size = 0x%x \r\n", size);
        
        // Detect if memory regions overshoots the address space.

        if (udst + size - 1 < udst)
        {
            return E_BAD_ARG;
        }
        if (usrc + size - 1 < usrc)
        {
            return E_BAD_ARG;
        }

        // Detect if memory regions overlaps.

        if (udst > usrc)
        {
            if (usrc + size - 1 > udst)
            {
                return E_BAD_ARG;
            }
        }
        else
        {
            if (udst + size - 1 > usrc)
            {
                return E_BAD_ARG;
            }
        }

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_SAR, (uint32)usrc);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_DAR, (uint32)udst);
        }

        sizeleft = size;

        //
        // The algorithm uses the strategy described in PL330 B.3.1.
        // It is extended for 2-byte and 1-byte unaligned cases.
        //

        // First see how many byte(s) we need to transfer to get src to be 8 byte aligned
        if ((uint32)usrc & 0x7UL)
        {
            uint32 aligncount = MIN(8 - ((uint32)usrc & 0x7UL), sizeleft);
            sizeleft -= aligncount;

            sic_printf("DMA[M->M]: Total pre-alignment 1-byte burst size tranfer(s): %d \n", aligncount);

            // Program in the following parameters:
            //  - SS8 (Source      burst size of 1-byte)
            //  - DS8 (Destination burst size of 1-byte)
            //  - SBx (Source      burst length of [aligncount] transfers)
            //  - DBx (Destination burst length of [aligncount] transfers)
            //  - All other options default.

            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                                (   ((aligncount - 1) << 4) // SB
                                                  | DMA_CCR_OPT_SS8
                                                  | DMA_CCR_OPT_SA_DEFAULT
                                                  | DMA_CCR_OPT_SP_DEFAULT
                                                  | DMA_CCR_OPT_SC_DEFAULT
                                                  | ((aligncount - 1) << 18) // DB
                                                  | DMA_CCR_OPT_DS8
                                                  | DMA_CCR_OPT_DA_DEFAULT
                                                  | DMA_CCR_OPT_DP_DEFAULT
                                                  | DMA_CCR_OPT_DC_DEFAULT
                                                  | DMA_CCR_OPT_ES_DEFAULT
                                                )
                    );
            }
            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_NONE);
            }
            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_NONE);
            }
        }

        // This is the number of 8-byte bursts
        burstcount = sizeleft >> 3;

        correction = (burstcount != 0);

        // Update the size left to transfer
        sizeleft &= 0x7;

        sic_printf("DMA[M->M]: Total Main 8-byte burst size transfer(s): %d \r\n", burstcount);
        sic_printf("DMA[M->M]: Total Main 1-byte burst size transfer(s): %d \r\n", sizeleft);

        // Determine how many 16 length bursts can be done

        if (burstcount >> 4)
        {
            uint32 length16burstcount = burstcount >> 4;
            burstcount &= 0xf;

            sic_printf("DMA[M->M]:   Number of 16 burst length 8-byte transfer(s): %d \r\n", length16burstcount);
            sic_printf("DMA[M->M]:   Number of remaining 8-byte transfer(s):       %d \r\n", burstcount);

            // Program in the following parameters:
            //  - SS64 (Source      burst size of 8-byte)
            //  - DS64 (Destination burst size of 8-byte)
            //  - SB16 (Source      burst length of 16 transfers)
            //  - DB16 (Destination burst length of 16 transfers)
            //  - All other options default.

            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                                (   DMA_CCR_OPT_SB16
                                                  | DMA_CCR_OPT_SS64
                                                  | DMA_CCR_OPT_SA_DEFAULT
                                                  | DMA_CCR_OPT_SP_DEFAULT
                                                  | DMA_CCR_OPT_SC_DEFAULT
                                                  | DMA_CCR_OPT_DB16
                                                  | DMA_CCR_OPT_DS64
                                                  | DMA_CCR_OPT_DA_DEFAULT
                                                  | DMA_CCR_OPT_DP_DEFAULT
                                                  | DMA_CCR_OPT_DC_DEFAULT
                                                  | DMA_CCR_OPT_ES_DEFAULT
                                                )
                    );
            }

            while (length16burstcount > 0)
            {
                if (status != E_SUCCESS)
                {
                    break;
                }

                uint32 loopcount = MIN(length16burstcount, 256);
                length16burstcount -= loopcount;

                sic_printf("DMA[M->M]:   Looping %d 16 burst length 8-byte transfer(s).\n", loopcount);

                if ((status == E_SUCCESS) && (loopcount > 1))
                {
                    status = DMA330_Instr_DMALP(program, loopcount);
                }
                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_NONE);
                }
                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_NONE);
                }
                if ((status == E_SUCCESS) && (loopcount > 1))
                {
                    status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_NONE);
                }
            }
        }

        // At this point, we should have [burstcount] 8-byte transfer(s)
        // remaining. [burstcount] should be less than 16.

        // Do one more burst with a SB / DB of length [burstcount].

        if (burstcount)
        {
            // Program in the following parameters:
            //  - SS64 (Source      burst size of 8-byte)
            //  - DS64 (Destination burst size of 8-byte)
            //  - SBx  (Source      burst length of [burstlength] transfers)
            //  - DBx  (Destination burst length of [burstlength] transfers)
            //  - All other options default.

            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                                (   ((burstcount - 1) << 4) // SB
                                                  | DMA_CCR_OPT_SS64
                                                  | DMA_CCR_OPT_SA_DEFAULT
                                                  | DMA_CCR_OPT_SP_DEFAULT
                                                  | DMA_CCR_OPT_SC_DEFAULT
                                                  | ((burstcount - 1) << 18) // DB
                                                  | DMA_CCR_OPT_DS64
                                                  | DMA_CCR_OPT_DA_DEFAULT
                                                  | DMA_CCR_OPT_DP_DEFAULT
                                                  | DMA_CCR_OPT_DC_DEFAULT
                                                  | DMA_CCR_OPT_ES_DEFAULT
                                                )
                    );
            }
            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_NONE);
            }
            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_NONE);
            }
        }

        // This is where the last DMAMOV CCR and DMAST is done if an
        // alignment correction required.

        if (   (correction == TRUE)
            && (((uint32)usrc & 0x7UL) != ((uint32)udst & 0x7UL)) // If src and dst are mod-8 congruent, no correction is needed.
           )
        {
            if (status == E_SUCCESS)
            {
                // Determine what type of correction.

                // Set the source parameters to match that of the destination
                // parameters. This way the SAR is increment in the same fashion as
                // DAR. This will allow the non 8-byte transfers to copy correctly.

                uint32 ccr;

                if (((uint32)usrc & 0x3UL) == ((uint32)udst & 0x3UL))
                {
                    sic_printf("DMA[M->M]: Single correction 4-byte burst size tranfer.\n");

                    // Program in the following parameters:
                    //  - SS32 (Source      burst size of 4-byte)
                    //  - DS32 (Destination burst size of 4-byte)
                    //  - SB1  (Source      burst length of 1 transfer)
                    //  - DB1  (Destination burst length of 1 transfer)
                    //  - All other options default.

                    ccr = (   DMA_CCR_OPT_SB1
                            | DMA_CCR_OPT_SS32
                            | DMA_CCR_OPT_SA_DEFAULT
                            | DMA_CCR_OPT_SP_DEFAULT
                            | DMA_CCR_OPT_SC_DEFAULT
                            | DMA_CCR_OPT_DB1
                            | DMA_CCR_OPT_DS32
                            | DMA_CCR_OPT_DA_DEFAULT
                            | DMA_CCR_OPT_DP_DEFAULT
                            | DMA_CCR_OPT_DC_DEFAULT
                            | DMA_CCR_OPT_ES_DEFAULT
                          );
                }
                else if (((uint32)usrc & 0x1UL) == ((uint32)udst & 0x1UL))
                {
                    sic_printf("DMA[M->M]: Single correction 2-byte burst size tranfer.\n");

                    // Program in the following parameters:
                    //  - SS16 (Source      burst size of 2-byte)
                    //  - DS16 (Destination burst size of 2-byte)
                    //  - SB1  (Source      burst length of 1 transfer)
                    //  - DB1  (Destination burst length of 1 transfer)
                    //  - All other options default.

                    ccr = (   DMA_CCR_OPT_SB1
                            | DMA_CCR_OPT_SS16
                            | DMA_CCR_OPT_SA_DEFAULT
                            | DMA_CCR_OPT_SP_DEFAULT
                            | DMA_CCR_OPT_SC_DEFAULT
                            | DMA_CCR_OPT_DB1
                            | DMA_CCR_OPT_DS16
                            | DMA_CCR_OPT_DA_DEFAULT
                            | DMA_CCR_OPT_DP_DEFAULT
                            | DMA_CCR_OPT_DC_DEFAULT
                            | DMA_CCR_OPT_ES_DEFAULT
                          );
                }
                else
                {
                    sic_printf("DMA[M->M]: Single correction 1-byte burst size tranfer.\n");

                    // Program in the following parameters:
                    //  - SS8 (Source      burst size of 1-byte)
                    //  - DS8 (Destination burst size of 1-byte)
                    //  - SB1 (Source      burst length of 1 transfer)
                    //  - DB1 (Destination burst length of 1 transfer)
                    //  - All other options default.

                    ccr = (   DMA_CCR_OPT_SB1
                            | DMA_CCR_OPT_SS8
                            | DMA_CCR_OPT_SA_DEFAULT
                            | DMA_CCR_OPT_SP_DEFAULT
                            | DMA_CCR_OPT_SC_DEFAULT
                            | DMA_CCR_OPT_DB1
                            | DMA_CCR_OPT_DS8
                            | DMA_CCR_OPT_DA_DEFAULT
                            | DMA_CCR_OPT_DP_DEFAULT
                            | DMA_CCR_OPT_DC_DEFAULT
                            | DMA_CCR_OPT_ES_DEFAULT
                          );
                }

                status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                                ccr);
            }
            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_NONE);
            }
        }

        // At this point, there should be 0 - 7 1-byte transfers remaining.

        if (sizeleft)
        {
            sic_printf("DMA[M->M]: Total post 1-byte burst size tranfer(s): %d \n", sizeleft);

            // Program in the following parameters:
            //  - SS8 (Source      burst size of 1-byte)
            //  - DS8 (Destination burst size of 1-byte)
            //  - SBx (Source      burst length of [sizeleft] transfers)
            //  - DBx (Destination burst length of [sizeleft] transfers)
            //  - All other options default.

            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                                (   ((sizeleft - 1) << 4) // SB
                                                  | DMA_CCR_OPT_SS8
                                                  | DMA_CCR_OPT_SA_DEFAULT
                                                  | DMA_CCR_OPT_SP_DEFAULT
                                                  | DMA_CCR_OPT_SC_DEFAULT
                                                  | ((sizeleft - 1) << 18) // DB
                                                  | DMA_CCR_OPT_DS8
                                                  | DMA_CCR_OPT_DA_DEFAULT
                                                  | DMA_CCR_OPT_DP_DEFAULT
                                                  | DMA_CCR_OPT_DC_DEFAULT
                                                  | DMA_CCR_OPT_ES_DEFAULT
                                                )
                    );
            }
            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_NONE);
            }
            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_NONE);
            }
        }
    } // if (size != 0)

    // Send event if requested.
    if (send_evt)
    {
        if (status == E_SUCCESS)
        {
            sic_printf("DMA[M->M]: Adding event ...\n");
			dma_event_int_select(evt, DMA_EVENT_SELECT_SIG_IRQ);
            status = DMA330_Instr_DMASEV(program, evt);
        }
    }

    // Now that everything is done, end the program.
    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_DMAEND(program);
    }

    // If there was a problem assembling the program, clean up the buffer and exit.
    if (status != E_SUCCESS)
    {
        // Do not report the status for the clear operation. A failure should be
        // reported regardless of if the clear is successful.
        DMA330_Instr_clear(program);
        return status;
    }

    // Execute the program on the given channel.
    return dma_channel_exec(channel, program);
}

DMA_ERR dma_zero_to_memory(DMA_CHANNEL_t channel,
                                       DMA_PROGRAM_t * program,
                                       void * buf,
                                       uint32 size,
                                       int8 send_evt,
                                       DMA_EVENT_t evt)
{
    DMA_ERR status = E_SUCCESS;

    // If the size is zero, and no event is requested, just return success.
    if ((size == 0) && (send_evt == FALSE))
    {
        return status;
    }

    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_init(program);
    }

    if (size != 0)
    {
        uint32 sizeleft = size;
        uint32 burstcount = 0;
        
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_DAR, (uint32)buf);
        }

        sic_printf("DMA[Z->M]: buf  = %d \n", buf);
        sic_printf("DMA[Z->M]: size = 0x%d \n", size);


        // First see how many byte(s) we need to transfer to get dst to be 8 byte aligned.
        if ((uint32)buf & 0x7)
        {
            uint32 aligncount = MIN(8 - ((uint32)buf & 0x7), sizeleft);
            sizeleft -= aligncount;

            sic_printf("DMA[Z->M]: Total pre-alignment 1-byte burst size tranfer(s): %d \n", aligncount);

            // Program in the following parameters:
            //  - DS8 (Destination burst size of 1-byte)
            //  - DBx (Destination burst length of [aligncount] transfers)
            //  - All other options default.

            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                                (   DMA_CCR_OPT_SB_DEFAULT
                                                  | DMA_CCR_OPT_SS_DEFAULT
                                                  | DMA_CCR_OPT_SA_DEFAULT
                                                  | DMA_CCR_OPT_SP_DEFAULT
                                                  | DMA_CCR_OPT_SC_DEFAULT
                                                  | ((aligncount - 1) << 18) // DB
                                                  | DMA_CCR_OPT_DS8
                                                  | DMA_CCR_OPT_DA_DEFAULT
                                                  | DMA_CCR_OPT_DP_DEFAULT
                                                  | DMA_CCR_OPT_DC_DEFAULT
                                                  | DMA_CCR_OPT_ES_DEFAULT
                                                )
                    );
            }
            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMASTZ(program);
            }
        }

        // This is the number of 8-byte bursts left
        burstcount = sizeleft >> 3;

        // Update the size left to transfer
        sizeleft &= 0x7;

        sic_printf("DMA[Z->M]: Total Main 8-byte burst size transfer(s): %d \n", burstcount);
        sic_printf("DMA[Z->M]: Total Main 1-byte burst size transfer(s): %d \n", sizeleft);

        // Determine how many 16 length bursts can be done
        if (burstcount >> 4)
        {
            uint32 length16burstcount = burstcount >> 4;
            burstcount &= 0xf;

            sic_printf("DMA[Z->M]:   Number of 16 burst length 8-byte transfer(s): %d \n", length16burstcount);
            sic_printf("DMA[Z->M]:   Number of remaining 8-byte transfer(s):       %d \n", burstcount);

            // Program in the following parameters:
            //  - DS64 (Destination burst size of 8-byte)
            //  - DB16 (Destination burst length of 16 transfers)
            //  - All other options default.

            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                                (   DMA_CCR_OPT_SB_DEFAULT
                                                  | DMA_CCR_OPT_SS_DEFAULT
                                                  | DMA_CCR_OPT_SA_DEFAULT
                                                  | DMA_CCR_OPT_SP_DEFAULT
                                                  | DMA_CCR_OPT_SC_DEFAULT
                                                  | DMA_CCR_OPT_DB16
                                                  | DMA_CCR_OPT_DS64
                                                  | DMA_CCR_OPT_DA_DEFAULT
                                                  | DMA_CCR_OPT_DP_DEFAULT
                                                  | DMA_CCR_OPT_DC_DEFAULT
                                                  | DMA_CCR_OPT_ES_DEFAULT
                                                )
                    );
            }

            while (length16burstcount > 0)
            {
            
                uint32 loopcount;
                if (status != E_SUCCESS)
                {
                    break;
                }

                loopcount = MIN(length16burstcount, 256);
                length16burstcount -= loopcount;

                sic_printf("DMA[Z->M]:   Looping %d 16 burst length 8-byte transfer(s).\n", loopcount);

                if ((status == E_SUCCESS) && (loopcount > 1))
                {
                    status = DMA330_Instr_DMALP(program, loopcount);
                }
                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMASTZ(program);
                }
                if ((status == E_SUCCESS) && (loopcount > 1))
                {
                    status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_NONE);
                }
            }
        }

        // At this point, we should have [burstcount] 8-byte transfer(s)
        // remaining. [burstcount] should be less than 16.

        // Do one more burst with a SB / DB of length [burstcount].

        if (burstcount)
        {
            // Program in the following parameters:
            //  - DS64 (Destination burst size of 8-byte)
            //  - DBx  (Destination burst length of [burstlength] transfers)
            //  - All other options default.

            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                                (   DMA_CCR_OPT_SB_DEFAULT
                                                  | DMA_CCR_OPT_SS_DEFAULT
                                                  | DMA_CCR_OPT_SA_DEFAULT
                                                  | DMA_CCR_OPT_SP_DEFAULT
                                                  | DMA_CCR_OPT_SC_DEFAULT
                                                  | ((burstcount - 1) << 18) // DB
                                                  | DMA_CCR_OPT_DS64
                                                  | DMA_CCR_OPT_DA_DEFAULT
                                                  | DMA_CCR_OPT_DP_DEFAULT
                                                  | DMA_CCR_OPT_DC_DEFAULT
                                                  | DMA_CCR_OPT_ES_DEFAULT
                                                )
                    );
            }
            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMASTZ(program);
            }
        }

        // At this point, there should be 0 - 7 1-byte transfers remaining.

        if (sizeleft)
        {
            sic_printf("DMA[Z->M]: Total post 1-byte burst size tranfer(s): %d \n", sizeleft);

            // Program in the following parameters:
            //  - DS8 (Destination burst size of 1-byte)
            //  - DBx (Destination burst length of [sizeleft] transfers)
            //  - All other options default.

            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                                (   DMA_CCR_OPT_SB_DEFAULT
                                                  | DMA_CCR_OPT_SS_DEFAULT
                                                  | DMA_CCR_OPT_SA_DEFAULT
                                                  | DMA_CCR_OPT_SP_DEFAULT
                                                  | DMA_CCR_OPT_SC_DEFAULT
                                                  | ((sizeleft - 1) << 18) // DB
                                                  | DMA_CCR_OPT_DS8
                                                  | DMA_CCR_OPT_DA_DEFAULT
                                                  | DMA_CCR_OPT_DP_DEFAULT
                                                  | DMA_CCR_OPT_DC_DEFAULT
                                                  | DMA_CCR_OPT_ES_DEFAULT
                                                )
                    );
            }
            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMASTZ(program);
            }
        }
    } // if (size != 0)

    // Send event if requested.
    if (send_evt)
    {
        if (status == E_SUCCESS)
        {
            sic_printf("DMA[Z->M]: Adding event ...\n");
            status = DMA330_Instr_DMASEV(program, evt);
        }
    }

    // Now that everything is done, end the program.
    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_DMAEND(program);
    }

    // If there was a problem assembling the program, clean up the buffer and exit.
    if (status != E_SUCCESS)
    {
        // Do not report the status for the clear operation. A failure should be
        // reported regardless of if the clear is successful.
        DMA330_Instr_clear(program);
        return status;
    }

    // Execute the program on the given channel.
    return dma_channel_exec(channel, program);
}

DMA_ERR dma_memory_to_register(DMA_CHANNEL_t channel,
                                           DMA_PROGRAM_t * program,
                                           void * dst_reg,
                                           const void * src_buf,
                                           uint32 count,
                                           uint32 register_width_bits,
                                           int8 send_evt,
                                           DMA_EVENT_t evt)
{
    DMA_ERR status = E_SUCCESS;

    // If the count is zero, and no event is requested, just return success.
    if ((count == 0) && (send_evt == FALSE))
    {
        return status;
    }

    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_init(program);
    }

    if (count != 0)
    {
        // Verify valid register_width_bits and construct the CCR SS and DS parameters.
        uint32 ccr_ss_ds_mask = 0;

        if (status == E_SUCCESS)
        {
            switch (register_width_bits)
            {
            case 8:
                // Program in the following parameters:
                //  - SS8 (Source      burst size of 8 bits)
                //  - DS8 (Destination burst size of 8 bits)
                ccr_ss_ds_mask = DMA_CCR_OPT_SS8 | DMA_CCR_OPT_DS8;
                break;
            case 16:
                // Program in the following parameters:
                //  - SS16 (Source      burst size of 16 bits)
                //  - DS16 (Destination burst size of 16 bits)
                ccr_ss_ds_mask = DMA_CCR_OPT_SS16 | DMA_CCR_OPT_DS16;
                break;
            case 32:
                // Program in the following parameters:
                //  - SS32 (Source      burst size of 32 bits)
                //  - DS32 (Destination burst size of 32 bits)
                ccr_ss_ds_mask = DMA_CCR_OPT_SS32 | DMA_CCR_OPT_DS32;
                break;
            case 64:
                // Program in the following parameters:
                //  - SS64 (Source      burst size of 64 bits)
                //  - DS64 (Destination burst size of 64 bits)
                ccr_ss_ds_mask = DMA_CCR_OPT_SS64 | DMA_CCR_OPT_DS64;
                break;
            default:
                status = E_BAD_ARG;
                break;
            }
        }

        // Verify that the dst_reg and src_buf are aligned to the register width
        if (status == E_SUCCESS)
        {
            //if      (((uint32 *)dst_reg & ((register_width_bits >> 3) - 1)) != 0)
            if      (((uint32)dst_reg & ((register_width_bits >> 3) - 1)) != 0)
            {
                status = E_BAD_ARG;
            }
           // else if (((uint32 *)src_buf & ((register_width_bits >> 3) - 1)) != 0)
           else if (((uint32)src_buf & ((register_width_bits >> 3) - 1)) != 0)
            {
                status = E_BAD_ARG;
            }
            else
            {
                sic_printf("DMA[M->R]: dst_reg = %p.\n",   dst_reg);
                sic_printf("DMA[M->R]: src_buf = %p.\n",   src_buf);
                sic_printf("DMA[M->R]: count   = 0x%x.\n", count);
            }
        }

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_SAR, (uint32)src_buf);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_DAR, (uint32)dst_reg);
        }

        // This is the remaining count left to process.
        uint32 countleft = count;

        // See how many 16-length bursts we can use
        if (countleft >> 4)
        {
            // Program in the following parameters:
            //  - SSx  (Source      burst size of [ccr_ss_ds_mask])
            //  - DSx  (Destination burst size of [ccr_ss_ds_mask])
            //  - DAF  (Destination address fixed)
            //  - SB16 (Source      burst length of 16 transfers)
            //  - DB16 (Destination burst length of 16 transfers)
            //  - All other options default.

            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                                (   ccr_ss_ds_mask
                                                  | DMA_CCR_OPT_SB16
                                                  | DMA_CCR_OPT_SA_DEFAULT
                                                  | DMA_CCR_OPT_SP_DEFAULT
                                                  | DMA_CCR_OPT_SC_DEFAULT
                                                  | DMA_CCR_OPT_DB16
                                                  | DMA_CCR_OPT_DAF
                                                  | DMA_CCR_OPT_DP_DEFAULT
                                                  | DMA_CCR_OPT_DC_DEFAULT
                                                  | DMA_CCR_OPT_ES_DEFAULT
                                                )
                    );
            }

            uint32 length16burst = countleft >> 4;
            countleft &= 0xf;

            sic_printf("DMA[M->R]:   Number of 16 burst length transfer(s): %lu.\n", length16burst);
            sic_printf("DMA[M->R]:   Number of remaining transfer(s):       %lu.\n", countleft);

            // See how many 256x 16-length bursts we can use
            if (length16burst >> 8)
            {
                uint32 loop256length16burst = length16burst >> 8;
                length16burst &= ((1 << 8) - 1);

                sic_printf("DMA[M->R]:     Number of 256-looped 16 burst length transfer(s): %lu.\n", loop256length16burst);
                sic_printf("DMA[M->R]:     Number of remaining 16 burst length transfer(s):  %lu.\n", length16burst);

                while (loop256length16burst > 0)
                {
                    if (status != E_SUCCESS)
                    {
                        break;
                    }

                    uint32 loopcount = MIN(loop256length16burst, 256);
                    loop256length16burst -= loopcount;

                    sic_printf("DMA[M->R]:     Looping %lux super loop transfer(s).\n", loopcount);

                    if ((status == E_SUCCESS) && (loopcount > 1))
                    {
                        status = DMA330_Instr_DMALP(program, loopcount);
                    }

                    if (status == E_SUCCESS)
                    {
                        status = DMA330_Instr_DMALP(program, 256);
                    }
                    if (status == E_SUCCESS)
                    {
                        status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_NONE);
                    }
                    if (status == E_SUCCESS)
                    {
                        status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_NONE);
                    }
                    if (status == E_SUCCESS)
                    {
                        status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_NONE);
                    }

                    if ((status == E_SUCCESS) && (loopcount > 1))
                    {
                        status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_NONE);
                    }
                }
            }

            // The super loop above ensures that the length16burst is below 256.
            if (length16burst > 0)
            {
                uint32 loopcount = length16burst;
                length16burst = 0;

                sic_printf("DMA[M->R]:   Looping %lux 16 burst length transfer(s).\n", loopcount);

                if ((status == E_SUCCESS) && (loopcount > 1))
                {
                    status = DMA330_Instr_DMALP(program, loopcount);
                }
                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_NONE);
                }
                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_NONE);
                }
                if ((status == E_SUCCESS) && (loopcount > 1))
                {
                    status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_NONE);
                }
            }
        }

        // At this point, we should have [countleft] transfer(s) remaining.
        // [countleft] should be less than 16.

        if (countleft)
        {
            // Program in the following parameters:
            //  - SSx (Source      burst size of [ccr_ss_ds_mask])
            //  - DSx (Destination burst size of [ccr_ss_ds_mask])
            //  - DAF (Destination address fixed)
            //  - SBx (Source      burst length of [countleft] transfer(s))
            //  - DBx (Destination burst length of [countleft] transfer(s))
            //  - All other options default.

            if (status == E_SUCCESS)
            {
                sic_printf("DMA[M->R]:   Tail end %lux transfer(s).\n", countleft);

                status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                                (   ccr_ss_ds_mask
                                                  | ((countleft - 1) << 4) // SB
                                                  | DMA_CCR_OPT_SA_DEFAULT
                                                  | DMA_CCR_OPT_SP_DEFAULT
                                                  | DMA_CCR_OPT_SC_DEFAULT
                                                  | ((countleft - 1) << 18) // DB
                                                  | DMA_CCR_OPT_DAF
                                                  | DMA_CCR_OPT_DP_DEFAULT
                                                  | DMA_CCR_OPT_DC_DEFAULT
                                                  | DMA_CCR_OPT_ES_DEFAULT
                                                )
                    );
            }
            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_NONE);
            }
            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_NONE);
            }
        }

    } // if (count != 0)

    // Send event if requested.
    if (send_evt)
    {
        if (status == E_SUCCESS)
        {
            sic_printf("DMA[M->R]: Adding event ...\n");
            status = DMA330_Instr_DMASEV(program, evt);
        }
    }

    // Now that everything is done, end the program.
    if (status == E_SUCCESS)
    {
        sic_printf("DMA[M->R]: DMAEND program.\n");
        status = DMA330_Instr_DMAEND(program);
    }

    // If there was a problem assembling the program, clean up the buffer and exit.
    if (status != E_SUCCESS)
    {
        // Do not report the status for the clear operation. A failure should be
        // reported regardless of if the clear is successful.
        DMA330_Instr_clear(program);
        return status;
    }

    // Execute the program on the given channel.
    return dma_channel_exec(channel, program);
}

DMA_ERR dma_register_to_memory(DMA_CHANNEL_t channel,
                                           DMA_PROGRAM_t * program,
                                           void * dst_buf,
                                           const void * src_reg,
                                           uint32 count,
                                           uint32 register_width_bits,
                                           int8 send_evt,
                                           DMA_EVENT_t evt)
{
    DMA_ERR status = E_SUCCESS;

    // If the count is zero, and no event is requested, just return success.
    if ((count == 0) && (send_evt == FALSE))
    {
        return status;
    }

    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_init(program);
    }

    if (count != 0)
    {
        // Verify valid register_width_bits and construct the CCR SS and DS parameters.
        uint32 ccr_ss_ds_mask = 0;

        if (status == E_SUCCESS)
        {
            switch (register_width_bits)
            {
            case 8:
                // Program in the following parameters:
                //  - SS8 (Source      burst size of 8 bits)
                //  - DS8 (Destination burst size of 8 bits)
                ccr_ss_ds_mask = DMA_CCR_OPT_SS8 | DMA_CCR_OPT_DS8;
                break;
            case 16:
                // Program in the following parameters:
                //  - SS16 (Source      burst size of 16 bits)
                //  - DS16 (Destination burst size of 16 bits)
                ccr_ss_ds_mask = DMA_CCR_OPT_SS16 | DMA_CCR_OPT_DS16;
                break;
            case 32:
                // Program in the following parameters:
                //  - SS32 (Source      burst size of 32 bits)
                //  - DS32 (Destination burst size of 32 bits)
                ccr_ss_ds_mask = DMA_CCR_OPT_SS32 | DMA_CCR_OPT_DS32;
                break;
            case 64:
                // Program in the following parameters:
                //  - SS64 (Source      burst size of 64 bits)
                //  - DS64 (Destination burst size of 64 bits)
                ccr_ss_ds_mask = DMA_CCR_OPT_SS64 | DMA_CCR_OPT_DS64;
                break;
            default:
                sic_printf("DMA[R->M]: Invalid register width.\n");
                status = E_BAD_ARG;
                break;
            }
        }

        // Verify that the dst_buf and src_reg are aligned to the register width
        if (status == E_SUCCESS)
        {
            //if      (((uint32 *)dst_buf & ((register_width_bits >> 3) - 1)) != 0)
            if      (((uint32)dst_buf & ((register_width_bits >> 3) - 1)) != 0)
            {
                status = E_BAD_ARG;
            }
            //else if (((uint32 *)src_reg & ((register_width_bits >> 3) - 1)) != 0)
            else if (((uint32)src_reg & ((register_width_bits >> 3) - 1)) != 0)
            {
                status = E_BAD_ARG;
            }
            else
            {
                sic_printf("DMA[R->M]: dst_reg = %p.\n",   dst_buf);
                sic_printf("DMA[R->M]: src_buf = %p.\n",   src_reg);
                sic_printf("DMA[R->M]: count   = 0x%x.\n", count);
            }
        }

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_SAR, (uint32)src_reg);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_DAR, (uint32)dst_buf);
        }

        // This is the remaining count left to process.
        uint32 countleft = count;

        // See how many 16-length bursts we can use
        if (countleft >> 4)
        {
            uint32 length16burst = countleft >> 4;
            countleft &= 0xf;

            sic_printf("DMA[R->M]:   Number of 16 burst length transfer(s): %lu.\n", length16burst);
            sic_printf("DMA[R->M]:   Number of remaining transfer(s):       %lu.\n", countleft);

            //
            // The algorithm uses the strategy described in PL330 B.2.3.
            // Not sure if registers will accept burst transfers so read the register in its own transfer.
            //

            // Program in the following parameters:
            //  - SAF  (Source      address fixed)
            //  - SSx  (Source      burst size of [ccr_ss_ds_mask])
            //  - DSx  (Destination burst size of [ccr_ss_ds_mask])
            //  - SB16 (Source      burst length of 16 transfers)
            //  - DB16 (Destination burst length of 16 transfers)
            //  - All other options default.

            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                                (   ccr_ss_ds_mask
                                                  | DMA_CCR_OPT_SB16
                                                  | DMA_CCR_OPT_SAF
                                                  | DMA_CCR_OPT_SP_DEFAULT
                                                  | DMA_CCR_OPT_SC_DEFAULT
                                                  | DMA_CCR_OPT_DB16
                                                  | DMA_CCR_OPT_DA_DEFAULT
                                                  | DMA_CCR_OPT_DP_DEFAULT
                                                  | DMA_CCR_OPT_DC_DEFAULT
                                                  | DMA_CCR_OPT_ES_DEFAULT
                                                )
                    );
            }

            // See how many 256x 16-length bursts we can do
            if (length16burst >> 8)
            {
                uint32 loop256length16burst = length16burst >> 8;
                length16burst &= ((1 << 8) - 1);

                sic_printf("DMA[R->M]:     Number of 256-looped 16 burst length transfer(s): %lu.\n", loop256length16burst);
                sic_printf("DMA[R->M]:     Number of remaining 16 burst length transfer(s):  %lu.\n", length16burst);

                while (loop256length16burst > 0)
                {
                    if (status != E_SUCCESS)
                    {
                        break;
                    }

                    uint32 loopcount = MIN(loop256length16burst, 256);
                    loop256length16burst -= loopcount;

                    sic_printf("DMA[R->M]:     Looping %lux super loop transfer(s).\n", loopcount);

                    if ((status == E_SUCCESS) && (loopcount > 1))
                    {
                        status = DMA330_Instr_DMALP(program, loopcount);
                    }

                    if (status == E_SUCCESS)
                    {
                        status = DMA330_Instr_DMALP(program, 256);
                    }
                    if (status == E_SUCCESS)
                    {
                        status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_NONE);
                    }
                    if (status == E_SUCCESS)
                    {
                        status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_NONE);
                    }
                    if (status == E_SUCCESS)
                    {
                        status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_NONE);
                    }

                    if ((status == E_SUCCESS) && (loopcount > 1))
                    {
                        status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_NONE);
                    }
                }
            }

            // The super loop above ensures that the length16burst is below 256.
            if (length16burst > 0)
            {
                uint32 loopcount = length16burst;
                length16burst = 0;

                sic_printf("DMA[R->M]:   Looping %lux 16 burst length transfer(s).\n", loopcount);

                if ((status == E_SUCCESS) && (loopcount > 1))
                {
                    status = DMA330_Instr_DMALP(program, loopcount);
                }
                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_NONE);
                }
                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_NONE);
                }
                if ((status == E_SUCCESS) && (loopcount > 1))
                {
                    status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_NONE);
                }
            }
        }

        // At this point, we should have [countleft] transfer(s) remaining.
        // [countleft] should be less than 16.

        if (countleft)
        {
            sic_printf("DMA[R->M]:   Tail end %lux transfer(s).\n", countleft);

            // Program in the following parameters:
            //  - SAF (Source      address fixed)
            //  - SSx (Source      burst size of [ccr_ss_ds_mask])
            //  - DSx (Destination burst size of [ccr_ss_ds_mask])
            //  - SBx (Source      burst length of [countleft] transfer(s))
            //  - DBx (Destination burst length of [countleft] transfer(s))
            //  - All other options default.

            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                                (   ccr_ss_ds_mask
                                                  | ((countleft - 1) << 4) // SB
                                                  | DMA_CCR_OPT_SAF
                                                  | DMA_CCR_OPT_SP_DEFAULT
                                                  | DMA_CCR_OPT_SC_DEFAULT
                                                  | ((countleft - 1) << 18) // DB
                                                  | DMA_CCR_OPT_DA_DEFAULT
                                                  | DMA_CCR_OPT_DP_DEFAULT
                                                  | DMA_CCR_OPT_DC_DEFAULT
                                                  | DMA_CCR_OPT_ES_DEFAULT
                                                )
                    );
            }

            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_NONE);
            }
            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_NONE);
            }
        }

    } // if (count != 0)

    // Send event if requested.
    if (send_evt)
    {
        if (status == E_SUCCESS)
        {
            sic_printf("DMA[R->M]: Adding event ...\n");
            status = DMA330_Instr_DMASEV(program, evt);
        }
    }

    // Now that everything is done, end the program.
    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_DMAEND(program);
    }

    // If there was a problem assembling the program, clean up the buffer and exit.
    if (status != E_SUCCESS)
    {
        // Do not report the status for the clear operation. A failure should be
        // reported regardless of if the clear is successful.
        DMA330_Instr_clear(program);
        return status;
    }

    // Execute the program on the given channel.
    return dma_channel_exec(channel, program);
}

#if DMA_PERIPH_PROVISION_QSPI_SUPPORT
static DMA_ERR dma_memory_to_qspi(DMA_PROGRAM_t * program,
                                              const char * src,
                                              uint32 size)
{
    if ((uint32 *)src & 0x3)
    {
        return E_ERROR;
    }

    if (size & 0x3)
    {
        return E_ERROR;
    }

    /////

    DMA_ERR status = E_SUCCESS;

    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_DAR,
                                        (uint32)QSPIDATA_ADDR);
    }
    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_SAR,
                                        (uint32)src);
    }

    /////

    uint32 dmaper = read_word(QSPI_DMAPER_ADDR);
    uint32 qspi_single_size_log2 = QSPI_DMAPER_NUMSGLREQBYTES_GET(dmaper);
    uint32 qspi_burst_size_log2  = QSPI_DMAPER_NUMBURSTREQBYTES_GET(dmaper);
    uint32 qspi_single_size      = 1 << qspi_single_size_log2;
    uint32 qspi_burst_size       = 1 << qspi_burst_size_log2;

    sic_printf("DMA[M->P][QSPI]: QSPI Single = %lu; Burst = %lu.\n", qspi_single_size, qspi_burst_size);

    // Because single transfers are equal or smaller than burst (and in the
    // smaller case, it is always a clean multiple), only the single size
    // check is needed for transfer composability.
    if (size & (qspi_single_size - 1))
    {
        sic_printf("DMA[M->P][QSPI]: QSPI DMA size configuration not suitable for transfer request.\n");
        return E_ERROR;
    }

    /////

    if ((uint32 *)src & 0x7)
    {
        // Source address is not 8-byte aligned. Do 1x 32-bit transfer to get it 8-byte aligned.

        sic_printf("DMA[M->P][QSPI]: Creating 1x 4-byte aligning transfer.\n");

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                            (   DMA_CCR_OPT_SAI
                                              | DMA_CCR_OPT_SS32
                                              | DMA_CCR_OPT_SB1
                                              | DMA_CCR_OPT_SP_DEFAULT
                                              | DMA_CCR_OPT_SC_DEFAULT
                                              | DMA_CCR_OPT_DAF
                                              | DMA_CCR_OPT_DS32
                                              | DMA_CCR_OPT_DB1
                                              | DMA_CCR_OPT_DP_DEFAULT
                                              | DMA_CCR_OPT_DC_DEFAULT
                                              | DMA_CCR_OPT_ES_DEFAULT
                                            )
                );
        }

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAFLUSHP(program, DMA_PERIPH_QSPI_FLASH_TX);
        }

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAWFP(program, DMA_PERIPH_QSPI_FLASH_TX, DMA_PROGRAM_INST_MOD_SINGLE);
        }

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_SINGLE);
        }

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_SINGLE);
        }

        size -= sizeof(uint32);
    }

    uint32 qspi_single_count = 0;
    uint32 qspi_burst_count  = size >> qspi_burst_size_log2;

    // Use QSPI burst transfers if:
    //  - QSPI bursts are larger than QSPI singles [AND]
    //  - Size is large enough that at least 1 burst will be used.

    if (   (qspi_burst_size_log2 > qspi_single_size_log2)
        && (qspi_burst_count != 0)
       )
    {
        // qspi_burst_count = size >> qspi_burst_size_log2;
        qspi_single_count   = (size & (qspi_burst_size - 1)) >> qspi_single_size_log2;

        sic_printf("DMA[M->P][QSPI][B]: Burst size = %lu bytes, count = %lu.\n", qspi_burst_size, qspi_burst_count);

        // 1 << 3 => 8 bytes => 64 bits, which is the width of the AXI bus.
        uint32 src_size_log2 = MIN(3, qspi_burst_size_log2);

        uint32 src_length   = 0;
        uint32 src_multiple = 0;

        if ((qspi_burst_size >> src_size_log2) <= 16)
        {
            src_length   = qspi_burst_size >> src_size_log2;
            src_multiple = 1;
        }
        else
        {
            src_length   = 16;
            src_multiple = (qspi_burst_size >> src_size_log2) >> 4; // divide by 16

            if (src_multiple == 0)
            {
                sic_printf("DEBUG[QSPI][B]: src_multiple is 0.\n");
                status = E_ERROR;
            }
        }

        // uint32 dst_length = 1; // dst_length is always 1 because the address is fixed.
        uint32 dst_multiple = qspi_burst_size >> 2; // divide by sizeof(uint32)

        sic_printf("DMA[M->P][QSPI][B]: dst_size = %u bits, dst_length = %u, dst_multiple = %lu.\n",
                32,                       1,          dst_multiple);
        sic_printf("DMA[M->P][QSPI][B]: src_size = %u bits, src_length = %lu, src_multiple = %lu.\n",
                (1 << src_size_log2) * 8, src_length, src_multiple);

        /////

        // Program in the following parameters:
        //  - SAI  (Source      address increment)
        //  - SSx  (Source      burst size of [1 << src_size_log2]-bytes)
        //  - SBx  (Source      burst length of [src_length] transfer(s))
        //  - DAF  (Destination address fixed)
        //  - DS32 (Destination burst size of 4-bytes)
        //  - DB1  (Destination burst length of 1 transfer)
        //  - All other parameters default

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                            (   DMA_CCR_OPT_SAI
                                              | (src_size_log2 << 1) // SS
                                              | ((src_length - 1) << 4) // SB
                                              | DMA_CCR_OPT_SP_DEFAULT
                                              | DMA_CCR_OPT_SC_DEFAULT
                                              | DMA_CCR_OPT_DAF
                                              | DMA_CCR_OPT_DS32
                                              | DMA_CCR_OPT_DB1
                                              | DMA_CCR_OPT_DP_DEFAULT
                                              | DMA_CCR_OPT_DC_DEFAULT
                                              | DMA_CCR_OPT_ES_DEFAULT
                                            )
                );
        }

        // NOTE: We do not do the 256x bursts for M->P case because we only
        //   write up to 256 B at a time.

        while (qspi_burst_count > 0)
        {
            if (status != E_SUCCESS)
            {
                break;
            }

            uint32 loopcount = MIN(qspi_burst_count, 256);
            qspi_burst_count -= loopcount;

            sic_printf("DMA[M->P][QSPI][B]: Creating %lu burst-type transfer(s).\n", loopcount);

            if ((status == E_SUCCESS) && (loopcount > 1))
            {
                status = DMA330_Instr_DMALP(program, loopcount);
            }

            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAFLUSHP(program, DMA_PERIPH_QSPI_FLASH_TX);
            }
            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAWFP(program, DMA_PERIPH_QSPI_FLASH_TX, DMA_PROGRAM_INST_MOD_BURST);
            }
            for (uint32 j = 0; j < src_multiple; ++j)
            {
                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_BURST);
                }
            }
            for (uint32 k = 0; k < dst_multiple; ++k)
            {
                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_BURST);
                }
            }

            if ((status == E_SUCCESS) && (loopcount > 1))
            {
                status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_NONE);
            }
        }
    }
    else
    {
        qspi_single_count = size >> qspi_single_size_log2;
    }

    // Assemble the single portion of the DMA program.
    if (qspi_single_count)
    {
        sic_printf("DMA[M->P][QSPI][S]: Single size = %lu bytes, count = %lu.\n", qspi_single_size, qspi_single_count);

        // 1 << 3 => 8 bytes => 64 bits, which is the width of the AXI bus.
        uint32 src_size_log2 = MIN(3, qspi_single_size_log2);

        uint32 src_length   = 0;
        uint32 src_multiple = 0;

        if ((qspi_single_size >> src_size_log2) <= 16)
        {
            src_length   = qspi_single_size >> src_size_log2;
            src_multiple = 1;
        }
        else
        {
            src_length   = 16;
            src_multiple = (qspi_single_size >> src_size_log2) >> 4; // divide by 16

            if (src_multiple == 0)
            {
                sic_printf("DEBUG[QSPI][S]: src_multiple is 0.\n");
                status = E_ERROR;
            }
        }

        // uint32 dst_length = 1; // dst_length is always 1 becaus the address is fixed.
        uint32 dst_multiple = qspi_single_size >> 2; // divide by sizeof(uint32)

        sic_printf("DMA[M->P][QSPI][S]: dst_size = %u bits, dst_length = %u, dst_multiple = %lu.\n",
                32,                      1,          dst_multiple);
        sic_printf("DMA[M->P][QSPI][S]: src_size = %u bits, src_length = %lu, src_multiple = %lu.\n",
                (1 <<src_size_log2) * 8, src_length, src_multiple);

        /////

        // Program in the following parameters:
        //  - SAI  (Source      address increment)
        //  - SSx  (Source      burst size of [1 << src_size_log2]-bytes)
        //  - SBx  (Source      burst length of [src_length] transfer(s))
        //  - DAF  (Destination address fixed)
        //  - DS32 (Destination burst size of 4-bytes)
        //  - DB1  (Destination burst length of 1 transfer)
        //  - All other parameters default

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                            (   DMA_CCR_OPT_SAI
                                              | (src_size_log2 << 1) // SS
                                              | ((src_length - 1) << 4) // SB
                                              | DMA_CCR_OPT_SP_DEFAULT
                                              | DMA_CCR_OPT_SC_DEFAULT
                                              | DMA_CCR_OPT_DAF
                                              | DMA_CCR_OPT_DS32
                                              | DMA_CCR_OPT_DB1
                                              | DMA_CCR_OPT_DP_DEFAULT
                                              | DMA_CCR_OPT_DC_DEFAULT
                                              | DMA_CCR_OPT_ES_DEFAULT
                                            )
                );
        }

        // NOTE: We do not do the 256x bursts for M->P case because we only
        //   write up to 256 B at a time.

        while (qspi_single_count > 0)
        {
            if (status != E_SUCCESS)
            {
                break;
            }

            uint32 loopcount = MIN(qspi_single_count, 256);
            qspi_single_count -= loopcount;

            sic_printf("DMA[M->P][QSPI][S]: Creating %lu single-type transfer(s).\n", loopcount);

            if ((status == E_SUCCESS) && (loopcount > 1))
            {
                status = DMA330_Instr_DMALP(program, loopcount);
            }

            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAFLUSHP(program, DMA_PERIPH_QSPI_FLASH_TX);
            }
            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAWFP(program, DMA_PERIPH_QSPI_FLASH_TX, DMA_PROGRAM_INST_MOD_SINGLE);
            }
            for (uint32 j = 0; j < src_multiple; ++j)
            {
                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_SINGLE);
                }
            }
            for (uint32 k = 0; k < dst_multiple; ++k)
            {
                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_SINGLE);
                }
            }

            if ((status == E_SUCCESS) && (loopcount > 1))
            {
                status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_NONE);
            }
        }

    } // if (qspi_single_count != 0)

    return status;
}

static DMA_ERR dma_qspi_to_memory(DMA_PROGRAM_t * program,
                                              char * dst,
                                              uint32 size)
{
    if ((uint32 *)dst & 0x3)
    {
        return E_ERROR;
    }

    if (size & 0x3)
    {
        return E_ERROR;
    }

    /////

    DMA_ERR status = E_SUCCESS;

    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_DAR,
                                        (uint32)dst);
    }
    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_SAR,
                                        (uint32)QSPIDATA_ADDR);
    }

    /////

    uint32 dmaper = read_word(QSPI_DMAPER_ADDR);
    uint32 qspi_single_size_log2 = QSPI_DMAPER_NUMSGLREQBYTES_GET(dmaper);
    uint32 qspi_burst_size_log2  = QSPI_DMAPER_NUMBURSTREQBYTES_GET(dmaper);
    uint32 qspi_single_size      = 1 << qspi_single_size_log2;
    uint32 qspi_burst_size       = 1 << qspi_burst_size_log2;

    sic_printf("DMA[P->M][QSPI]: QSPI Single = %lu; Burst = %lu.\n", qspi_single_size, qspi_burst_size);

    // Because single transfers are equal or smaller than burst (and in the
    // smaller case, it is always a clean multiple), only the single size
    // check is needed for transfer composability.
    if (size & (qspi_single_size - 1))
    {
        sic_printf("DMA[P->M][QSPI]: QSPI DMA size configuration not suitable for transfer request.\n");
        return E_ERROR;
    }

    /////

    if ((uint32 *)dst & 0x7)
    {
        // Destination address is not 8-byte aligned. Do 1x 32-bit transfer to get it 8-byte aligned.

        sic_printf("DMA[P->M][QSPI]: Creating 1x 4-byte aligning transfer.\n");

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                            (   DMA_CCR_OPT_SAF
                                              | DMA_CCR_OPT_SS32
                                              | DMA_CCR_OPT_SB1
                                              | DMA_CCR_OPT_SP_DEFAULT
                                              | DMA_CCR_OPT_SC_DEFAULT
                                              | DMA_CCR_OPT_DAI
                                              | DMA_CCR_OPT_DS32
                                              | DMA_CCR_OPT_DB1
                                              | DMA_CCR_OPT_DP_DEFAULT
                                              | DMA_CCR_OPT_DC_DEFAULT
                                              | DMA_CCR_OPT_ES_DEFAULT
                                            )
                );
        }

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAFLUSHP(program, DMA_PERIPH_QSPI_FLASH_RX);
        }

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAWFP(program, DMA_PERIPH_QSPI_FLASH_RX, DMA_PROGRAM_INST_MOD_SINGLE);
        }

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_SINGLE);
        }

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_SINGLE);
        }

        size -= sizeof(uint32);
    }

    uint32 qspi_single_count = 0;
    uint32 qspi_burst_count  = size >> qspi_burst_size_log2;

    // Use QSPI burst transfers if:
    //  - QSPI bursts are larger than QSPI singles [AND]
    //  - Size is large enough that at least 1 burst will be used.

    if (   (qspi_burst_size_log2 > qspi_single_size_log2)
        && (qspi_burst_count != 0)
       )
    {
        // qspi_burst_count = size >> qspi_burst_size_log2;
        qspi_single_count   = (size & (qspi_burst_size - 1)) >> qspi_single_size_log2;

        sic_printf("DMA[P->M][QSPI][B]: Burst size = %lu bytes, count = %lu.\n", qspi_burst_size, qspi_burst_count);

        // 1 << 3 => 8 bytes => 64 bits, which is the width of the AXI bus.
        uint32 dst_size_log2 = MIN(3, qspi_burst_size_log2);

        uint32 dst_length   = 0;
        uint32 dst_multiple = 0;

        if ((qspi_burst_size >> dst_size_log2) <= 16)
        {
            dst_length   = qspi_burst_size >> dst_size_log2;
            dst_multiple = 1;
        }
        else
        {
            dst_length   = 16;
            dst_multiple = (qspi_burst_size >> dst_size_log2) >> 4; // divide by 16

            if (dst_multiple == 0)
            {
                sic_printf("DEBUG[QSPI][B]: dst_multiple is 0.\n");
                status = E_ERROR;
            }
        }

        // uint32 src_length = 1; // src_length is always 1 because the address is fixed.
        uint32 src_multiple = qspi_burst_size >> 2; // divide by sizeof(uint32)

        sic_printf("DMA[P->M][QSPI][B]: dst_size = %u bits, dst_length = %lu, dst_multiple = %lu.\n", 
                (1 << dst_size_log2) * 8, dst_length, dst_multiple);
        sic_printf("DMA[P->M][QSPI][B]: src_size = %u bits, src_length = %u, src_multiple = %lu.\n",
                32,                       1,          src_multiple);

        /////

        // Program in the following parameters:
        //  - SAF  (Source      address fixed)
        //  - SS32 (Source      burst size of 4-bytes)
        //  - SB1  (Source      burst length of 1 transfer)
        //  - DAI  (Destination address increment)
        //  - DSx  (Destination burst size of [1 << dst_size_log2]-bytes])
        //  - DBx  (Destination burst length of [dst_length] transfer(s))
        //  - All other parameters default

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                            (   DMA_CCR_OPT_SAF
                                              | DMA_CCR_OPT_SS32
                                              | DMA_CCR_OPT_SB1
                                              | DMA_CCR_OPT_SP_DEFAULT
                                              | DMA_CCR_OPT_SC_DEFAULT
                                              | DMA_CCR_OPT_DAI
                                              | (dst_size_log2 << 15) // DS
                                              | ((dst_length - 1) << 18) // DB
                                              | DMA_CCR_OPT_DP_DEFAULT
                                              | DMA_CCR_OPT_DC_DEFAULT
                                              | DMA_CCR_OPT_ES_DEFAULT
                                            )
                );
        }

        // See how many 256x bursts we can construct. This will allow for extremely large requests.

        if (qspi_burst_count >> 8)
        {
            uint32 qspi_burst256_count = qspi_burst_count >> 8;
            qspi_burst_count &= (1 << 8) - 1;

            while (qspi_burst256_count > 0)
            {
                if (status != E_SUCCESS)
                {
                    break;
                }

                uint32 loopcount = MIN(qspi_burst256_count, 256);
                qspi_burst256_count -= loopcount;

                sic_printf("DMA[P->M][QSPI][B]: Creating %lu 256x burst-type transfer(s).\n", loopcount);

                // Outer loop {

                if ((status == E_SUCCESS) && (loopcount > 1))
                {
                    status = DMA330_Instr_DMALP(program, loopcount);
                }

                // Inner loop {

                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMALP(program, 256);
                }

                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMAFLUSHP(program, DMA_PERIPH_QSPI_FLASH_RX);
                }
                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMAWFP(program, DMA_PERIPH_QSPI_FLASH_RX, DMA_PROGRAM_INST_MOD_BURST);
                }
                for (uint32 j = 0; j < src_multiple; ++j)
                {
                    if (status == E_SUCCESS)
                    {
                        status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_BURST);
                    }
                }
                for (uint32 k = 0; k < dst_multiple; ++k)
                {
                    if (status == E_SUCCESS)
                    {
                        status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_BURST);
                    }
                }

                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_NONE);
                }

                // } Inner loop

                if ((status == E_SUCCESS) && (loopcount > 1))
                {
                    status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_NONE);
                }

                // } Outer loop
            }
        }

        while (qspi_burst_count > 0)
        {
            if (status != E_SUCCESS)
            {
                break;
            }

            uint32 loopcount = MIN(qspi_burst_count, 256);
            qspi_burst_count -= loopcount;

            sic_printf("DMA[P->M][QSPI][B]: Creating %lu burst-type transfer(s).\n", loopcount);

            if ((status == E_SUCCESS) && (loopcount > 1))
            {
                status = DMA330_Instr_DMALP(program, loopcount);
            }

            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAFLUSHP(program, DMA_PERIPH_QSPI_FLASH_RX);
            }
            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAWFP(program, DMA_PERIPH_QSPI_FLASH_RX, DMA_PROGRAM_INST_MOD_BURST);
            }
            for (uint32 j = 0; j < src_multiple; ++j)
            {
                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_BURST);
                }
            }
            for (uint32 k = 0; k < dst_multiple; ++k)
            {
                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_BURST);
                }
            }

            if ((status == E_SUCCESS) && (loopcount > 1))
            {
                status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_NONE);
            }
        }
    }
    else
    {
        qspi_single_count = size >> qspi_single_size_log2;
    }

    // Assemble the single portion of the DMA program.
    if (qspi_single_count)
    {
        sic_printf("DMA[P->M][QSPI][S]: Single size = %lu bytes, count = %lu.\n", qspi_single_size, qspi_single_count);

        // 1 << 3 => 8 bytes => 64 bits, which is the width of the AXI bus.
        uint32 dst_size_log2 = MIN(3, qspi_single_size_log2);

        uint32 dst_length   = 0;
        uint32 dst_multiple = 0;

        if ((qspi_single_size >> dst_size_log2) <= 16)
        {
            dst_length   = qspi_single_size >> dst_size_log2;
            dst_multiple = 1;
        }
        else
        {
            dst_length   = 16;
            dst_multiple = (qspi_single_size >> dst_size_log2) >> 4; // divide by 16

            if (dst_multiple == 0)
            {
                sic_printf("DEBUG[QSPI][S]: dst_multiple is 0.\n");
                status = E_ERROR;
            }
        }

        // uint32 src_length = 1; // src_length is always 1 because the address is fixed.
        uint32 src_multiple = qspi_single_size >> 2; // divide by sizeof(uint32)

        sic_printf("DMA[P->M][QSPI][S]: dst_size = %u bits, dst_length = %lu, dst_multiple = %lu.\n",
                (1 << dst_size_log2) * 8, dst_length, dst_multiple);
        sic_printf("DMA[P->M][QSPI][S]: src_size = %u bits, src_length = %u, src_multiple = %lu.\n",
                32,                       1,          src_multiple);

        /////

        // Program in the following parameters:
        //  - SAF  (Source      address fixed)
        //  - SS32 (Source      burst size of 4-bytes)
        //  - SB1  (Source      burst length of 1 transfer)
        //  - DAI  (Destination address increment)
        //  - DSx  (Destination burst size of [1 << dst_size_log2]-bytes])
        //  - DBx  (Destination burst length of [dst_length] transfer(s))
        //  - All other parameters default

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                            (   DMA_CCR_OPT_SAF
                                              | DMA_CCR_OPT_SS32
                                              | DMA_CCR_OPT_SB1
                                              | DMA_CCR_OPT_SP_DEFAULT
                                              | DMA_CCR_OPT_SC_DEFAULT
                                              | DMA_CCR_OPT_DAI
                                              | (dst_size_log2 << 15) // DS
                                              | ((dst_length - 1) << 18) // DB
                                              | DMA_CCR_OPT_DP_DEFAULT
                                              | DMA_CCR_OPT_DC_DEFAULT
                                              | DMA_CCR_OPT_ES_DEFAULT
                                            )
                );
        }

        // See how many 256x bursts we can construct. This will allow for extremely large requests.

        if (qspi_single_count >> 8)
        {
            uint32 qspi_single256_count = qspi_single_count >> 8;
            qspi_single_count &= (1 << 8) - 1;

            while (qspi_single256_count > 0)
            {
                if (status != E_SUCCESS)
                {
                    break;
                }

                uint32 loopcount = MIN(qspi_single256_count, 256);
                qspi_single256_count -= loopcount;

                sic_printf("DMA[P->M][QSPI][S]: Creating %lu 256x single-type transfer(s).\n", loopcount);

                // Outer loop {

                if ((status == E_SUCCESS) && (loopcount > 1))
                {
                    status = DMA330_Instr_DMALP(program, loopcount);
                }

                // Inner loop {

                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMALP(program, 256);
                }

                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMAFLUSHP(program, DMA_PERIPH_QSPI_FLASH_RX);
                }
                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMAWFP(program, DMA_PERIPH_QSPI_FLASH_RX, DMA_PROGRAM_INST_MOD_SINGLE);
                }
                for (uint32 j = 0; j < src_multiple; ++j)
                {
                    if (status == E_SUCCESS)
                    {
                        status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_SINGLE);
                    }
                }
                for (uint32 k = 0; k < dst_multiple; ++k)
                {
                    if (status == E_SUCCESS)
                    {
                        status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_SINGLE);
                    }
                }

                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_NONE);
                }

                // } Inner loop

                if ((status == E_SUCCESS) && (loopcount > 1))
                {
                    status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_NONE);
                }

                // } Outer loop
            }
        }

        while (qspi_single_count > 0)
        {
            if (status != E_SUCCESS)
            {
                break;
            }

            uint32 loopcount = MIN(qspi_single_count, 256);
            qspi_single_count -= loopcount;

            sic_printf("DMA[P->M][QSPI][S]: Creating %lu single-type transfer(s).\n", loopcount);

            if ((status == E_SUCCESS) && (loopcount > 1))
            {
                status = DMA330_Instr_DMALP(program, loopcount);
            }

            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAFLUSHP(program, DMA_PERIPH_QSPI_FLASH_RX);
            }
            if (status == E_SUCCESS)
            {
                status = DMA330_Instr_DMAWFP(program, DMA_PERIPH_QSPI_FLASH_RX, DMA_PROGRAM_INST_MOD_SINGLE);
            }
            for (uint32 j = 0; j < src_multiple; ++j)
            {
                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_SINGLE);
                }
            }
            for (uint32 k = 0; k < dst_multiple; ++k)
            {
                if (status == E_SUCCESS)
                {
                    status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_SINGLE);
                }
            }

            if ((status == E_SUCCESS) && (loopcount > 1))
            {
                status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_NONE);
            }
        }

    } // if (qspi_single_count != 0)

    return status;
}
#endif // DMA_PERIPH_PROVISION_QSPI_SUPPORT

#if DMA_PERIPH_PROVISION_16550_SUPPORT
static DMA_ERR dma_memory_to_16550_single(DMA_PROGRAM_t * program,
                                                      DMA_PERIPH_t periph,
                                                      uint32 size)
{
    DMA_ERR status = E_SUCCESS;

    // Program in the following parameters:
    //  - SS8 (Source      burst size of 1-byte)
    //  - DS8 (Destination burst size of 1-byte)
    //  - SB1 (Source      burst length of 1 transfer)
    //  - DB1 (Destination burst length of 1 transfer)
    //  - DAF (Destination address fixed)
    //  - All other options default.

    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                        (   DMA_CCR_OPT_SB1
                                          | DMA_CCR_OPT_SS8
                                          | DMA_CCR_OPT_SA_DEFAULT
                                          | DMA_CCR_OPT_SP_DEFAULT
                                          | DMA_CCR_OPT_SC_DEFAULT
                                          | DMA_CCR_OPT_DB1
                                          | DMA_CCR_OPT_DS8
                                          | DMA_CCR_OPT_DAF
                                          | DMA_CCR_OPT_DP_DEFAULT
                                          | DMA_CCR_OPT_DC_DEFAULT
                                          | DMA_CCR_OPT_ES_DEFAULT
                                        )
            );
    }

    uint32 sizeleft = size;

    while (sizeleft > 0)
    {
        if (status != E_SUCCESS)
        {
            break;
        }

        uint32 loopcount = MIN(sizeleft, 256);
        sizeleft -= loopcount;

        sic_printf("DMA[M->P][16550][S]: Creating %lu transfer(s).\n", loopcount);

        if ((status == E_SUCCESS) && (loopcount > 1))
        {
            status = DMA330_Instr_DMALP(program, loopcount);
        }

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAFLUSHP(program, periph);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAWFP(program, periph, DMA_PROGRAM_INST_MOD_SINGLE);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_SINGLE);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_SINGLE);
        }

        if ((status == E_SUCCESS) && (loopcount > 1))
        {
            status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_SINGLE);
        }
    }

    return status;
}

static DMA_ERR dma_memory_to_16550_burst(DMA_PROGRAM_t * program,
                                                     DMA_PERIPH_t periph,
                                                     uint32 burst_size,
                                                     uint32 burst_count)
{
    DMA_ERR status = E_SUCCESS;

    // Program in the following parameters:
    //  - SS8  (Source      burst size of 1-byte)
    //  - DS8  (Destination burst size of 1-byte)
    //  - SB16 (Source      burst length of 16 transfers)
    //  - DB16 (Destination burst length of 16 transfers)
    //  - DAF  (Source      address fixed)
    //  - All other options default.

    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                        (   DMA_CCR_OPT_SB16
                                          | DMA_CCR_OPT_SS8
                                          | DMA_CCR_OPT_SA_DEFAULT
                                          | DMA_CCR_OPT_SP_DEFAULT
                                          | DMA_CCR_OPT_SC_DEFAULT
                                          | DMA_CCR_OPT_DB16
                                          | DMA_CCR_OPT_DS8
                                          | DMA_CCR_OPT_DAF
                                          | DMA_CCR_OPT_DP_DEFAULT
                                          | DMA_CCR_OPT_DC_DEFAULT
                                          | DMA_CCR_OPT_ES_DEFAULT
                                        )
            );
    }

    while (burst_count > 0)
    {
        if (status != E_SUCCESS)
        {
            break;
        }

        uint32 loopcount = MIN(burst_count, 256);
        burst_count -= loopcount;

        sic_printf("DMA[M->P][16550][B]: Creating outer %lu inner loop(s).\n", loopcount);

        // Outer loop {

        if ((status == E_SUCCESS) && (loopcount > 1))
        {
            status = DMA330_Instr_DMALP(program, loopcount);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAFLUSHP(program, periph);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAWFP(program, periph, DMA_PROGRAM_INST_MOD_BURST);
        }

        // Inner loop {

        // Loop [burst_size / 16] times. The burst_size was trimmed to the
        // nearest multiple of 16 by the caller. Each burst does 16 transfers
        // hence the need for the divide.

        sic_printf("DMA[M->P][16550][B]: Creating inner %u transfer(s).\n", burst_size >> 4);

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMALP(program, burst_size >> 4); // divide by 16.
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_BURST);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_BURST);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_BURST);
        }

        // } Inner loop

        if ((status == E_SUCCESS) && (loopcount > 1))
        {
            status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_BURST);
        }

        // } Outer loop
    }

    return status;
}

static DMA_ERR dma_memory_to_16550(DMA_PROGRAM_t * program,
                                               DMA_PERIPH_t periph,
                                               16550_HANDLE_t * handle,
                                               const void * src,
                                               uint32 size)
{
    DMA_ERR status = E_SUCCESS;

    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_DAR,
                                        (uint32)UART_RBR_THR_DLL_ADDR(handle->location));
    }
    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_SAR,
                                        (uint32)src);
    }

    // Determine if FIFOs are enabled from the FCR cache

    if (UART_FCR_FIFOE_GET(handle->fcr) != 0)
    {
        sic_printf("DMA[M->P][16550]: FIFOs enabled.\n");

        //
        // FIFOs are enabled.
        //

        uint32 tx_size;
        uint32 burst_size;
        16550_FIFO_TRIGGER_TX_t trig_tx;

        // Get the TX FIFO Size
        // Use the register interface to avoid coupling the 16550 and DMA.
        tx_size = UART_CPR_FIFO_MOD_GET(read_word(UART_CPR_ADDR(handle->location))) << 4;

        // Get the TX FIFO Trigger Level from the FCR cache
        trig_tx = (16550_FIFO_TRIGGER_TX_t)UART_FCR_TET_GET(handle->fcr);

        switch (trig_tx)
        {
        case 16550_FIFO_TRIGGER_TX_EMPTY:
            burst_size = tx_size;
            break;
        case 16550_FIFO_TRIGGER_TX_ALMOST_EMPTY:
            burst_size = tx_size - 2;
            break;
        case 16550_FIFO_TRIGGER_TX_QUARTER_FULL:
            burst_size = 3 * (tx_size >> 2);
            break;
        case 16550_FIFO_TRIGGER_TX_HALF_FULL:
            burst_size = tx_size >> 1;
            break;
        default:
            // This case should never happen.
            return E_ERROR;
        }

        if (burst_size < 16)
        {
            // There's no point bursting 1 byte at a time per notify, so just do single transfers.
            if (status == E_SUCCESS)
            {
                status = dma_memory_to_16550_single(program,
                                                        periph,
                                                        size);
            }
        }
        else
        {
            uint32 sizeleft = size;

            // Now trip the burst size to a multiple of 16.
            // This will optimize the bursting in the fewest possible commands.
            sic_printf("DMA[M->P][16550]: Untrimmed burst size = %lu.\n", burst_size);
            burst_size &= ~0xf;
            sic_printf("DMA[M->P][16550]: Trimmed burst size   = %lu.\n", burst_size);

            // Determine how many burst transfers can be done
            uint32 burst_count = 0;

            burst_count = sizeleft / burst_size;
            sizeleft -= burst_count * burst_size;

            if (burst_count == 0)
            {
                // Do the transfer
                if (status == E_SUCCESS)
                {
                    status = dma_memory_to_16550_single(program,
                                                            periph,
                                                            sizeleft);
                }
            }
            else
            {
                // Do the burst transfers
                if (status == E_SUCCESS)
                {
                    status = dma_memory_to_16550_burst(program,
                                                           periph,
                                                           burst_size,
                                                           burst_count);
                }

                // Program the DMA engine to transfer the non-burstable items in single tranfers
                if (status == E_SUCCESS)
                {
                    status = dma_memory_to_16550_single(program,
                                                            periph,
                                                            sizeleft);
                }

            } // else if (burst_count == 0)
        }
    }
    else
    {
        sic_printf("DMA[M->P][16550]: FIFOs disabled.\n");

        //
        // FIFOs are disabled.
        //

        status = dma_memory_to_16550_single(program,
                                                periph,
                                                size);
    }

    return status;
}

static DMA_ERR dma_16550_to_memory_single(DMA_PROGRAM_t * program,
                                                      DMA_PERIPH_t periph,
                                                      uint32 size)
{
    DMA_ERR status = E_SUCCESS;

    // Program in the following parameters:
    //  - SS8 (Source      burst size of 1-byte)
    //  - DS8 (Destination burst size of 1-byte)
    //  - SB1 (Source      burst length of 1 transfer)
    //  - DB1 (Destination burst length of 1 transfer)
    //  - SAF (Source      address fixed)
    //  - All other options default.

    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                        (   DMA_CCR_OPT_SB1
                                          | DMA_CCR_OPT_SS8
                                          | DMA_CCR_OPT_SAF
                                          | DMA_CCR_OPT_SP_DEFAULT
                                          | DMA_CCR_OPT_SC_DEFAULT
                                          | DMA_CCR_OPT_DB1
                                          | DMA_CCR_OPT_DS8
                                          | DMA_CCR_OPT_DA_DEFAULT
                                          | DMA_CCR_OPT_DP_DEFAULT
                                          | DMA_CCR_OPT_DC_DEFAULT
                                          | DMA_CCR_OPT_ES_DEFAULT
                                        )
            );
    }

    uint32 sizeleft = size;

    while (sizeleft > 0)
    {
        if (status != E_SUCCESS)
        {
            break;
        }

        uint32 loopcount = MIN(sizeleft, 256);
        sizeleft -= loopcount;

        sic_printf("DMA[P->M][16550][S]: Creating %lu transfer(s).\n", loopcount);

        if ((status == E_SUCCESS) && (loopcount > 1))
        {
            status = DMA330_Instr_DMALP(program, loopcount);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAFLUSHP(program, periph);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAWFP(program, periph, DMA_PROGRAM_INST_MOD_SINGLE);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_SINGLE);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_SINGLE);
        }
        if ((status == E_SUCCESS) && (loopcount > 1))
        {
            status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_SINGLE);
        }
    }

    return status;
}                                              

static DMA_ERR dma_16550_to_memory_burst(DMA_PROGRAM_t * program,
                                                     DMA_PERIPH_t periph,
                                                     uint32 burst_size,
                                                     uint32 burst_count)
{
    DMA_ERR status = E_SUCCESS;

    // Program in the following parameters:
    //  - SS8  (Source      burst size of 1-byte)
    //  - DS8  (Destination burst size of 1-byte)
    //  - SB16 (Source      burst length of 16 transfers)
    //  - DB16 (Destination burst length of 16 transfers)
    //  - SAF  (Source      address fixed)
    //  - All other options default.

    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_CCR,
                                        (   DMA_CCR_OPT_SB16
                                          | DMA_CCR_OPT_SS8
                                          | DMA_CCR_OPT_SAF
                                          | DMA_CCR_OPT_SP_DEFAULT
                                          | DMA_CCR_OPT_SC_DEFAULT
                                          | DMA_CCR_OPT_DB16
                                          | DMA_CCR_OPT_DS8
                                          | DMA_CCR_OPT_DA_DEFAULT
                                          | DMA_CCR_OPT_DP_DEFAULT
                                          | DMA_CCR_OPT_DC_DEFAULT
                                          | DMA_CCR_OPT_ES_DEFAULT
                                        )
            );
    }

    while (burst_count > 0)
    {
        if (status != E_SUCCESS)
        {
            break;
        }

        uint32 loopcount = MIN(burst_count, 256);
        burst_count -= loopcount;

        sic_printf("DMA[P->M][16550][B]: Creating outer %lu inner loop(s).\n", loopcount);

        // Outer loop {

        if ((status == E_SUCCESS) && (loopcount > 1))
        {
            status = DMA330_Instr_DMALP(program, loopcount);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAFLUSHP(program, periph);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAWFP(program, periph, DMA_PROGRAM_INST_MOD_BURST);
        }

        // Inner loop {

        // Loop [burst_size / 16] times. The burst_size was trimmed to the
        // nearest multiple of 16 by the caller. Each burst does 16 transfers
        // hence the need for the divide.

        sic_printf("DMA[P->M][16550][B]: Creating inner %u transfer(s).\n", burst_size >> 4);

        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMALP(program, burst_size >> 4); // divide by 16.
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMALD(program, DMA_PROGRAM_INST_MOD_BURST);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMAST(program, DMA_PROGRAM_INST_MOD_BURST);
        }
        if (status == E_SUCCESS)
        {
            status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_BURST);
        }

        // } Inner loop

        if ((status == E_SUCCESS) && (loopcount > 1))
        {
            status = DMA330_Instr_DMALPEND(program, DMA_PROGRAM_INST_MOD_BURST);
        }

        // } Outer loop
    }

    return status;
}

static DMA_ERR dma_16550_to_memory(DMA_PROGRAM_t * program,
                                               DMA_PERIPH_t periph,
                                               16550_HANDLE_t * handle,
                                               void * dst,
                                               uint32 size)
{
    DMA_ERR status = E_SUCCESS;

    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_DAR, (uint32)dst);
    }
    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_DMAMOV(program, DMA_PROGRAM_REG_SAR, (uint32)UART_RBR_THR_DLL_ADDR(handle->location));
    }

    // Determine if FIFOs are enabled from the FCR cache

    if (UART_FCR_FIFOE_GET(handle->fcr) != 0)
    {
        sic_printf("DMA[P->M][16550]: FIFOs enabled.\n");

        //
        // FIFOs are enabled.
        //

        uint32 rx_size;
        uint32 burst_size;
        16550_FIFO_TRIGGER_RX_t trig_rx;

        // Get the RX FIFO Size
        // Use the register interface to avoid coupling the 16550 and DMA.
        rx_size = UART_CPR_FIFO_MOD_GET(read_word(UART_CPR_ADDR(handle->location))) << 4;

        // Get the RX FIFO Trigger Level from the FCR cache
        trig_rx = (16550_FIFO_TRIGGER_RX_t)UART_FCR_RT_GET(handle->fcr);

        switch (trig_rx)
        {
        case 16550_FIFO_TRIGGER_RX_ANY:
            burst_size = 1;
            break;
        case 16550_FIFO_TRIGGER_RX_QUARTER_FULL:
            burst_size = rx_size >> 2; // divide by 4
            break;
        case 16550_FIFO_TRIGGER_RX_HALF_FULL:
            burst_size = rx_size >> 1; // divide by 2
            break;
        case 16550_FIFO_TRIGGER_RX_ALMOST_FULL:
            burst_size = rx_size - 2;
            break;
        default:
            // This case should never happen.
            return E_ERROR;
        }

        if (burst_size < 16)
        {
            // There's no point bursting 1 byte at a time per notify, so just do single transfers.
            if (status == E_SUCCESS)
            {
                status = dma_16550_to_memory_single(program,
                                                        periph,
                                                        size);
            }
        }
        else
        {
            uint32 sizeleft = size;

            // Now trim the burst size to a multiple of 16.
            // This will optimize the bursting in the fewest possible commands.
            sic_printf("DMA[P->M][16550]: Untrimmed burst size = %lu.\n", burst_size);
            burst_size &= ~0xf;
            sic_printf("DMA[P->M][16550]: Trimmed burst size   = %lu.\n", burst_size);

            // Determine how many burst transfers can be done
            uint32 burst_count = 0;

            burst_count = sizeleft / burst_size;
            sizeleft -= burst_count * burst_size;

            if (burst_count == 0)
            {
                // Do the transfer.
                if (status == E_SUCCESS)
                {
                    status = dma_16550_to_memory_single(program,
                                                            periph,
                                                            sizeleft);
                }
            }
            else
            {
                // Do the burst transfers
                if (status == E_SUCCESS)
                {
                    status = dma_16550_to_memory_burst(program,
                                                           periph,
                                                           burst_size,
                                                           burst_count);
                }

                // Program the DMA engine to transfer the non-burstable items in single transfers.
                if (status == E_SUCCESS)
                {
                    status = dma_16550_to_memory_single(program,
                                                            periph,
                                                            sizeleft);
                }

            } // if (burst_count == 0)
        }
    }
    else
    {
        sic_printf("DMA[P->M][16550]: FIFOs disabled.\n");

        //
        // FIFOs are disabled.
        //

        status = dma_16550_to_memory_single(program,
                                                periph,
                                                size);
    }

    return status;
}
#endif // DMA_PERIPH_PROVISION_16550_SUPPORT

DMA_ERR dma_memory_to_periph(DMA_CHANNEL_t channel,
                                         DMA_PROGRAM_t * program,
                                         DMA_PERIPH_t dstp,
                                         const void * src,
                                         uint32 size,
                                         void * periph_info,
                                         int8 send_evt,
                                         DMA_EVENT_t evt)
{
    DMA_ERR status = E_SUCCESS;

    if ((size == 0) && (send_evt == FALSE))
    {
        return status;
    }

    if (status == E_SUCCESS)
    {
        sic_printf("DMA[M->P]: Init Program.\n");
        status = DMA330_Instr_init(program);
    }

    if ((status == E_SUCCESS) && (size != 0))
    {
        switch (dstp)
        {
#if DMA_PERIPH_PROVISION_QSPI_SUPPORT
        case DMA_PERIPH_QSPI_FLASH_TX:
            status = dma_memory_to_qspi(program, src, size);
            break;
#endif

#if DMA_PERIPH_PROVISION_16550_SUPPORT
        case DMA_PERIPH_UART0_TX:
        case DMA_PERIPH_UART1_TX:
            status = dma_memory_to_16550(program, dstp,
                                             (16550_HANDLE_t *)periph_info, src, size);
            break;
#endif

		case DMA_PERIPH_ADC  :	 
		case DMA_PERIPH_CAN0 :	 
		case DMA_PERIPH_CAN1 :	 
		case DMA_PERIPH_CAN2 :	 
		case DMA_PERIPH_CAN3 :	 
		case DMA_PERIPH_ICTC0:	 
		case DMA_PERIPH_ICTC1:	 
		case DMA_PERIPH_ICTC2:

        default:
            status = E_BAD_ARG;
            break;
        }
    }

    // Send event if requested.
    if (send_evt)
    {
        if (status == E_SUCCESS)
        {
            sic_printf("DMA[M->P]: Adding event.\n");
            status = DMA330_Instr_DMASEV(program, evt);
        }
    }

    // Now that everything is done, end the program.
    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_DMAEND(program);
    }

    // If there was a problem assembling the program, clean up the buffer and exit.
    if (status != E_SUCCESS)
    {
        // Do not report the status for the clear operation. A failure should be
        // reported regardless of if the clear is successful.
        DMA330_Instr_clear(program);
        return status;
    }

    // Execute the program on the given channel.

    return dma_channel_exec(channel, program);
}

DMA_ERR dma_periph_to_memory(DMA_CHANNEL_t channel,
                                         DMA_PROGRAM_t * program,
                                         void * dst,
                                         DMA_PERIPH_t srcp,
                                         uint32 size,
                                         void * periph_info,
                                         int8 send_evt,
                                         DMA_EVENT_t evt)
{
    DMA_ERR status = E_SUCCESS;

    if ((size == 0) && (send_evt == FALSE))
    {
        return E_SUCCESS;
    }

    if (status == E_SUCCESS)
    {
        sic_printf("DMA[P->M]: Init Program.\n");
        status = DMA330_Instr_init(program);
    }

    if ((status == E_SUCCESS) && (size != 0))
    {
        switch (srcp)
        {
#if DMA_PERIPH_PROVISION_QSPI_SUPPORT
        case DMA_PERIPH_QSPI_FLASH_RX:
            status = dma_qspi_to_memory(program, dst, size);
            break;
#endif

#if DMA_PERIPH_PROVISION_16550_SUPPORT
        case DMA_PERIPH_UART0_RX:
        case DMA_PERIPH_UART1_RX:
            status = dma_16550_to_memory(program, srcp,
                                             (16550_HANDLE_t *)periph_info, dst, size);
            break;
#endif

		case DMA_PERIPH_ADC  :	 
		case DMA_PERIPH_CAN0 :	 
		case DMA_PERIPH_CAN1 :	 
		case DMA_PERIPH_CAN2 :	 
		case DMA_PERIPH_CAN3 :	 
		case DMA_PERIPH_ICTC0:	 
		case DMA_PERIPH_ICTC1:	 
		case DMA_PERIPH_ICTC2:

        default:
            status = E_BAD_ARG;
            break;
        }
    }

    // Send event if requested.
    if (send_evt)
    {
        if (status == E_SUCCESS)
        {
            sic_printf("DMA[P->M]: Adding event.\n");
            status = DMA330_Instr_DMASEV(program, evt);
        }
    }

    // Now that everything is done, end the program.
    if (status == E_SUCCESS)
    {
        status = DMA330_Instr_DMAEND(program);
    }

    // If there was a problem assembling the program, clean up the buffer and exit.
    if (status != E_SUCCESS)
    {
        // Do not report the status for the clear operation. A failure should be
        // reported regardless of if the clear is successful.
        DMA330_Instr_clear(program);
        return status;
    }

    // Execute the program on the given channel.

    return dma_channel_exec(channel, program);
}

/////

static int8 dma_is_init(void)
{
#ifdef NEVER
    uint32 permodrst = read_word(RSTMGR_PERMODRST_ADDR);

    if (permodrst & RSTMGR_PERMODRST_DMA_SET_MSK)
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
#endif /* NEVER */
    return TRUE;

}

#ifdef NEVER
DMA_ERR dma_ecc_start(void * block, uint32 size)
{
    if (dma_is_init() == FALSE)
    {
        return E_ERROR;
    }

    //if ((uint32 *)block & (sizeof(uint64) - 1))
    if ((uint32)block & (sizeof(uint64) - 1))
    {
        return E_ERROR;
    }

    // Verify that all channels are either unallocated or allocated and idle.

    for (int i = 0; i < ARRAY_COUNT(channel_info_array); ++i)
    {
        if (channel_info_array[i].flag & DMA_CHANNEL_INFO_FLAG_ALLOCED)
        {
            DMA_CHANNEL_STATE_t state;
            dma_channel_state_get((DMA_CHANNEL_t)i, &state);

            if (state != DMA_CHANNEL_STATE_STOPPED)
            {
                sic_printf("DMA[ECC]: Error: Channel %d state is non-stopped (%d).\n", i, (int)state);
                return E_ERROR;
            }
        }
    }

    /////

#ifdef NEVER
    // Enable ECC for DMA RAM

    sic_printf("DEBUG[DMA][ECC]: Enable ECC in SysMgr.\n");
    write_word(SYSMGR_ECC_DMA_ADDR, SYSMGR_ECC_DMA_EN_SET_MSK);

    // Clear any pending spurious DMA ECC interrupts.

    sic_printf("DEBUG[DMA][ECC]: Clear any pending spurious ECC status in SysMgr.\n");
    write_word(SYSMGR_ECC_DMA_ADDR,
                     SYSMGR_ECC_DMA_EN_SET_MSK
                   | SYSMGR_ECC_DMA_SERR_SET_MSK
                   | SYSMGR_ECC_DMA_DERR_SET_MSK);
#endif /* NEVER */

    return E_SUCCESS;
}
#endif /* NEVER */
