/*
***************************************************************************************************
*
*   FileName : dma_program.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include <sal_internal.h>

#include "dma_program.h"
#include <debug.h>

//
// The following section describes how the bits are used in the "flag" field:
//

// [17:16] Which loop registers (LOOP0, LOOP1) are currently being used by a
//   partially assembled program. LOOP0 is always used before LOOP1. LOOP1 is
//   always ended before LOOP0.
#define DMA_PROGRAM_FLAG_LOOP0 (1UL << 16)
#define DMA_PROGRAM_FLAG_LOOP1 (1UL << 17)
#define DMA_PROGRAM_FLAG_LOOP_ALL (DMA_PROGRAM_FLAG_LOOP0 | DMA_PROGRAM_FLAG_LOOP1)

// [18] Flag that marks LOOP0 as a forever loop. Said another way, LOOP0 is
//   being used to execute the DMALPFE directive.
#define DMA_PROGRAM_FLAG_LOOP0_IS_FE (1UL << 18)
// [19] Flag that marks LOOP1 as a forever loop. Said another way, LOOP1 is
//   being used to execute the DMALPFE directive.
#define DMA_PROGRAM_FLAG_LOOP1_IS_FE (1UL << 19)

// [24] Flag that the first SAR has been programmed. The SAR field is valid and
//    is the offset from the start of the buffer where SAR is located.
#define DMA_PROGRAM_FLAG_SAR (1UL << 24)
// [25] Flag that the first DAR has been programmed. The DAR field is valid and
//    is the offset from the start of the buffer where DAR is located.
#define DMA_PROGRAM_FLAG_DAR (1UL << 25)

// [31] Flag that marks the last assembled instruction as DMAEND.
#define DMA_PROGRAM_FLAG_ENDED (1UL << 31)

/////

DMA_ERR DMA330_Instr_init(DMA_PROGRAM_t * pgm)
{
    // Clear the variables that matter.
    pgm->flag      = 0;
    pgm->code_size = 0;

    // Calculate the cache aligned start location of the buffer.
    uint32 buffer = (uint32)pgm->program;
    uint32 offset = ((buffer + DMA_PROGRAM_CACHE_LINE_SIZE - 1) & ~(DMA_PROGRAM_CACHE_LINE_SIZE - 1)) - buffer;

    // It is safe to cast to uint16 because the extra offset can only be up to
    // (DMA_PROGRAM_CACHE_LINE_SIZE - 1) or 31, which is within range of the
    // uint16.
    pgm->buffer_start = (uint16)offset;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_uninit(DMA_PROGRAM_t * pgm)
{
    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_clear(DMA_PROGRAM_t * pgm)
{
    // Clear the variables that matter
    pgm->flag      = 0;
    pgm->code_size = 0;

    return E_SUCCESS;
}

__attribute__((weak)) DMA_ERR cache_system_clean(void * address, uint32 length)
{
    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_validate(const DMA_PROGRAM_t * pgm)
{
    // Verify that at least one instruction is in the buffer
    if (pgm->code_size == 0)
    {
        return E_ERROR;
    }

    // Verify all loops are completed.
    if (pgm->flag & DMA_PROGRAM_FLAG_LOOP_ALL)
    {
        return E_ERROR;
    }

    // Verify last item is DMAEND
    if (!(pgm->flag & DMA_PROGRAM_FLAG_ENDED))
    {
        return E_ERROR;
    }

    // Sync the DMA program to RAM.
    //void * vaddr  = (void *)((uint32 *)(pgm->program + pgm->buffer_start) & ~(CACHE_LINE_SIZE - 1));
    void * vaddr  = (void *)((uint32)(pgm->program + pgm->buffer_start) & ~(CACHE_LINE_SIZE - 1));
    uint32 length = (pgm->code_size + CACHE_LINE_SIZE) & ~(CACHE_LINE_SIZE - 1);

    sic_printf("DEBUG[DMAP]: Program (real) @ %x, length = 0x%x\n", pgm->program + pgm->buffer_start, pgm->code_size);
    sic_printf("DEBUG[DMAP]: Clean: addr = %x, length = 0x%x\n", vaddr, length);

    return cache_system_clean(vaddr, length);
}

DMA_ERR DMA330_Instr_progress_reg(DMA_PROGRAM_t * pgm,
                                             DMA_PROGRAM_REG_t reg,
                                             uint32 current, uint32 * progress)
{
    // Pointer to where the register is initialized in the program buffer.
    uint8 * buffer = NULL;

    switch (reg)
    {
    case DMA_PROGRAM_REG_SAR:
        if (!(pgm->flag & DMA_PROGRAM_FLAG_SAR))
        {
            return E_BAD_ARG;
        }
        buffer = pgm->program + pgm->buffer_start + pgm->sar;
        break;

    case DMA_PROGRAM_REG_DAR:
        if (!(pgm->flag & DMA_PROGRAM_FLAG_DAR))
        {
            return E_BAD_ARG;
        }
        buffer = pgm->program + pgm->buffer_start + pgm->dar;
        break;

    default:
        return E_BAD_ARG;
    }

    uint32 initial =
        (buffer[3] << 24) |
        (buffer[2] << 16) |
        (buffer[1] <<  8) |
        (buffer[0] <<  0);

    *progress = current - initial;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_update_reg(DMA_PROGRAM_t * pgm,
                                           DMA_PROGRAM_REG_t reg, uint32 val)
{
    uint8 * buffer = NULL;

    switch (reg)
    {
    case DMA_PROGRAM_REG_SAR:
        if (!(pgm->flag & DMA_PROGRAM_FLAG_SAR))
        {
            return E_BAD_ARG;
        }
        buffer = pgm->program + pgm->buffer_start + pgm->sar;
        break;

    case DMA_PROGRAM_REG_DAR:
        if (!(pgm->flag & DMA_PROGRAM_FLAG_DAR))
        {
            return E_BAD_ARG;
        }
        buffer = pgm->program + pgm->buffer_start + pgm->dar;
        break;

    default:
        return E_BAD_ARG;
    }

    buffer[0] = (uint8)((val >>  0) & 0xff);
    buffer[1] = (uint8)((val >>  8) & 0xff);
    buffer[2] = (uint8)((val >> 16) & 0xff);
    buffer[3] = (uint8)((val >> 24) & 0xff);

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMAADDH(DMA_PROGRAM_t * pgm,
                                        DMA_PROGRAM_REG_t addr_reg, uint16 val)
{
    // For information on DMAADDH, see PL330, section 4.3.1.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 3) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Verify valid register; construct instruction modifier.
    uint8 ra_mask = 0;
    switch (addr_reg)
    {
    case DMA_PROGRAM_REG_SAR:
        ra_mask = 0x0;
        break;
    case DMA_PROGRAM_REG_DAR:
        ra_mask = 0x2;
        break;
    default:
        return E_BAD_ARG;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMAADDH
    buffer[0] = 0x54 | ra_mask;
    buffer[1] = (uint8)(val & 0xff);
    buffer[2] = (uint8)(val >> 8);

    // Update the code size.
    pgm->code_size += 3;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMAADNH(DMA_PROGRAM_t * pgm,
                                        DMA_PROGRAM_REG_t addr_reg, uint16 val)
{
    // For information on DMAADNH, see PL330, section 4.3.2.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 3) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Verify valid register; construct instruction modifier.
    uint8 ra_mask = 0;
    switch (addr_reg)
    {
    case DMA_PROGRAM_REG_SAR:
        ra_mask = 0x0;
        break;
    case DMA_PROGRAM_REG_DAR:
        ra_mask = 0x2;
        break;
    default:
        return E_BAD_ARG;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMAADNH
    buffer[0] = 0x5c | ra_mask;
    buffer[1] = (uint8)(val & 0xff);
    buffer[2] = (uint8)(val >> 8);

    // Update the code size.
    pgm->code_size += 3;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMAEND(DMA_PROGRAM_t * pgm)
{
    // For information on DMAEND, see PL330, section 4.3.3.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 1) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMAEND
    buffer[0] = 0x00;

    // Update the code size.
    pgm->code_size += 1;

    // Mark program as ended.
    pgm->flag |= DMA_PROGRAM_FLAG_ENDED;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMAFLUSHP(DMA_PROGRAM_t * pgm,
                                          DMA_PERIPH_t periph)
{
    // For information on DMAFLUSHP, see PL330, section 4.3.4.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 2) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Verify valid peripheral identifier.
    if (periph > ((1 << 5) - 1))
    {
        return E_BAD_ARG;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMAFLUSHP
    buffer[0] = 0x35;
    buffer[1] = (uint8)(periph) << 3;

    // Update the code size.
    pgm->code_size += 2;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMAGO(DMA_PROGRAM_t * pgm,
                                      DMA_CHANNEL_t channel, uint32 val,
                                      DMA_SECURITY_t sec)
{
    // For information on DMAGO, see PL330, section 4.3.5.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 6) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Verify channel
    switch (channel)
    {
    case DMA_CHANNEL_0:
    case DMA_CHANNEL_1:
    case DMA_CHANNEL_2:
    case DMA_CHANNEL_3:
    case DMA_CHANNEL_4:
    case DMA_CHANNEL_5:
    case DMA_CHANNEL_6:
    case DMA_CHANNEL_7:
        break;
    default:
        return E_BAD_ARG;
    }

    // Verify security; construct ns mask value
    uint8 ns_mask = 0;
    switch (sec)
    {
    case DMA_SECURITY_DEFAULT:
    case DMA_SECURITY_SECURE:
        ns_mask = 0x0;
        break;
    case DMA_SECURITY_NONSECURE:
        ns_mask = 0x2;
        break;
    default:
        return E_BAD_ARG;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMAGO
    buffer[0] = 0xa0 | ns_mask;
    buffer[1] = (uint8)channel;
    buffer[2] = (uint8)((val >>  0) & 0xff);
    buffer[3] = (uint8)((val >>  8) & 0xff);
    buffer[4] = (uint8)((val >> 16) & 0xff);
    buffer[5] = (uint8)((val >> 24) & 0xff);

    // Update the code size.
    pgm->code_size += 6;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMAKILL(DMA_PROGRAM_t * pgm)
{
    // For information on DMAKILL, see PL330, section 4.3.6.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 1) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMAKILL
    buffer[0] = 0x01;

    // Update the code size.
    pgm->code_size += 1;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMALD(DMA_PROGRAM_t * pgm,
                                      DMA_PROGRAM_INST_MOD_t mod)
{
    // For information on DMALD, see PL330, section 4.3.7.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 1) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Verify instruction modifier; construct bs, x mask value.
    uint8 bsx_mask = 0;
    switch (mod)
    {
    case DMA_PROGRAM_INST_MOD_NONE:
        bsx_mask = 0x0;
        break;
    case DMA_PROGRAM_INST_MOD_SINGLE:
        bsx_mask = 0x1;
        break;
    case DMA_PROGRAM_INST_MOD_BURST:
        bsx_mask = 0x3;
        break;
    default:
        return E_BAD_ARG;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMALD
    buffer[0] = 0x04 | bsx_mask;

    // Update the code size.
    pgm->code_size += 1;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMALDP(DMA_PROGRAM_t * pgm,
                                       DMA_PROGRAM_INST_MOD_t mod, DMA_PERIPH_t periph)
{
    // For information on DMALDP, see PL330, section 4.3.8.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 2) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Verify instruction modifier; construct bs mask value.
    uint8 bs_mask = 0;
    switch (mod)
    {
    case DMA_PROGRAM_INST_MOD_SINGLE:
        bs_mask = 0x0;
        break;
    case DMA_PROGRAM_INST_MOD_BURST:
        bs_mask = 0x2;
        break;
    default:
        return E_BAD_ARG;
    }

    // Verify valid peripheral identifier.
    if (periph > ((1 << 5) - 1))
    {
        return E_BAD_ARG;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMALDP
    buffer[0] = 0x25 | bs_mask;
    buffer[1] = (uint8)(periph) << 3;

    // Update the code size.
    pgm->code_size += 2;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMALP(DMA_PROGRAM_t * pgm,
                                      uint32 iterations)
{
    // For information on DMALP, see PL330, section 4.3.9.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 2) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Verify iterations in range
    if ((iterations == 0) || (iterations > 256))
    {
        return E_BAD_ARG;
    }

    // Find suitable LOOPx register to use; construct lc mask value.
    uint8 lc_mask = 0;
    switch (pgm->flag & DMA_PROGRAM_FLAG_LOOP_ALL)
    {
    case 0:                              // No LOOPx in use. Use LOOP0.
        pgm->flag |= DMA_PROGRAM_FLAG_LOOP0;
        pgm->loop0 = pgm->code_size + 2; // This is the first instruction after the DMALP
        lc_mask = 0x0;
        break;

    case DMA_PROGRAM_FLAG_LOOP0:     // LOOP0 in use. Use LOOP1.
        pgm->flag |= DMA_PROGRAM_FLAG_LOOP1;
        pgm->loop1 = pgm->code_size + 2; // This is the first instruction after the DMALP
        lc_mask = 0x2;
        break;

    case DMA_PROGRAM_FLAG_LOOP_ALL: // All LOOPx in use. Report error.
        return E_BAD_OPERATION;

    default:                            // Catastrophic error !!!
        return E_ERROR;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMALP
    buffer[0] = 0x20 | lc_mask;
    buffer[1] = (uint8)(iterations - 1);

    // Update the code size.
    pgm->code_size += 2;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMALPEND(DMA_PROGRAM_t * pgm,
                                         DMA_PROGRAM_INST_MOD_t mod)
{
    // For information on DMALPEND, see PL330, section 4.3.10.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 2) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Verify instruction modifier; construct bs, x mask value.
    uint8 bsx_mask = 0;
    switch (mod)
    {
    case DMA_PROGRAM_INST_MOD_NONE:
        bsx_mask = 0x0;
        break;
    case DMA_PROGRAM_INST_MOD_SINGLE:
        bsx_mask = 0x1;
        break;
    case DMA_PROGRAM_INST_MOD_BURST:
        bsx_mask = 0x3;
        break;
    default:
        return E_BAD_ARG;
    }

    // Determine the loop to end, if it is a forever loop; construct lc mask, nf mask, and backwards jump value.
    uint8 lc_mask = 0;
    uint8 nf_mask = 0;
    uint16 backwards_jump = 0;
    switch (pgm->flag & DMA_PROGRAM_FLAG_LOOP_ALL)
    {
    case DMA_PROGRAM_FLAG_LOOP0:    // LOOP0 in use. End LOOP0.

        backwards_jump = pgm->code_size - pgm->loop0;

        pgm->flag &= ~DMA_PROGRAM_FLAG_LOOP0;
        pgm->loop0 = 0;

        lc_mask = 0x0;

        if (pgm->flag & DMA_PROGRAM_FLAG_LOOP0_IS_FE)
        {
            pgm->flag &= ~DMA_PROGRAM_FLAG_LOOP0_IS_FE;
        }
        else
        {
            nf_mask = 0x10;
        }
        break;

    case DMA_PROGRAM_FLAG_LOOP_ALL: // All LOOPx in use. End LOOP1.

        backwards_jump = pgm->code_size - pgm->loop1;

        pgm->flag &= ~DMA_PROGRAM_FLAG_LOOP1;
        pgm->loop1 = 0;

        lc_mask = 0x4;

        if (pgm->flag & DMA_PROGRAM_FLAG_LOOP1_IS_FE)
        {
            pgm->flag &= ~DMA_PROGRAM_FLAG_LOOP1_IS_FE;
        }
        else
        {
            nf_mask = 0x10;
        }
        break;

    case 0:                             // No LOOPx in use. Report error!
        return E_BAD_OPERATION;

    default:                            // Catastrophic error !!!
        return E_ERROR;
    }

    // Verify that the jump size is suitable
    if (backwards_jump > 255)
    {
        return E_ARG_RANGE;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMALPEND
    buffer[0] = 0x28 | nf_mask | lc_mask | bsx_mask;
    buffer[1] = (uint8)(backwards_jump);

    // Update the code size.
    pgm->code_size += 2;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMALPFE(DMA_PROGRAM_t * pgm)
{
    // For information on DMALPFE, see PL330, section 4.3.11.

    // Find suitable LOOPx register to use;
    switch (pgm->flag & DMA_PROGRAM_FLAG_LOOP_ALL)
    {
    case 0:                             // No LOOPx in use. Use LOOP0.
        pgm->flag |= DMA_PROGRAM_FLAG_LOOP0;
        pgm->flag |= DMA_PROGRAM_FLAG_LOOP0_IS_FE;
        pgm->loop0 = pgm->code_size;
        break;

    case DMA_PROGRAM_FLAG_LOOP0:    // LOOP0 in use. Use LOOP1.
        pgm->flag |= DMA_PROGRAM_FLAG_LOOP1;
        pgm->flag |= DMA_PROGRAM_FLAG_LOOP1_IS_FE;
        pgm->loop1 = pgm->code_size;
        break;

    case DMA_PROGRAM_FLAG_LOOP_ALL: // All LOOPx in use. Report error.
        return E_BAD_OPERATION;

    default:                            // Catastrophic error !!!
        return E_ERROR;
    }

    // Nothing to assemble.

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMAMOV(DMA_PROGRAM_t * pgm,
                                       DMA_PROGRAM_REG_t chan_reg, uint32 val)
{
    // For information on DMAMOV, see PL330, section 4.3.12.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 6) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Verify channel register; construct rd mask value
    uint8 rd_mask = 0;
    switch (chan_reg)
    {
    case DMA_PROGRAM_REG_SAR:
        rd_mask = 0;
        // If SAR has not been set before, mark the location of where SAR is in the buffer.
        if (!(pgm->flag & DMA_PROGRAM_FLAG_SAR))
        {
            pgm->flag |= DMA_PROGRAM_FLAG_SAR;
            pgm->sar = pgm->code_size + 2;
        }
        break;

    case DMA_PROGRAM_REG_CCR:
        rd_mask = 1;
        break;

    case DMA_PROGRAM_REG_DAR:
        rd_mask = 2;
        // If DAR has not been set before, mark the location of where DAR is in the buffer.
        if (!(pgm->flag & DMA_PROGRAM_FLAG_DAR))
        {
            pgm->flag |= DMA_PROGRAM_FLAG_DAR;
            pgm->dar = pgm->code_size + 2;
        }
        break;

    default:
        return E_BAD_ARG;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMAMOV
    buffer[0] = 0xbc;;
    buffer[1] = rd_mask;
    buffer[2] = (uint8)((val >>  0) & 0xff);
    buffer[3] = (uint8)((val >>  8) & 0xff);
    buffer[4] = (uint8)((val >> 16) & 0xff);
    buffer[5] = (uint8)((val >> 24) & 0xff);

    // Update the code size.
    pgm->code_size += 6;

    return E_SUCCESS;

}

DMA_ERR DMA330_Instr_DMANOP(DMA_PROGRAM_t * pgm)
{
    // For information on DMANOP, see PL330, section 4.3.13.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 1) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMANOP
    buffer[0] = 0x18;

    // Update the code size.
    pgm->code_size += 1;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMARMB(DMA_PROGRAM_t * pgm)
{
    // For information on DMARMB, see PL330, section 4.3.14.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 1) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMARMB
    buffer[0] = 0x12;

    // Update the code size.
    pgm->code_size += 1;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMASEV(DMA_PROGRAM_t * pgm,
                                       DMA_EVENT_t evt)
{
    // For information on DMA, see PL330, section 4.3.15.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 2) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Validate evt selection
    switch (evt)
    {
    case DMA_EVENT_0:
    case DMA_EVENT_1:
    case DMA_EVENT_2:
    case DMA_EVENT_3:
    case DMA_EVENT_4:
    case DMA_EVENT_5:
    case DMA_EVENT_6:
    case DMA_EVENT_7:
    case DMA_EVENT_ABORT:
        break;
    default:
        return E_BAD_ARG;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMASEV
    buffer[0] = 0x34;
    buffer[1] = (uint8)(evt) << 3;

    // Update the code size.
    pgm->code_size += 2;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMAST(DMA_PROGRAM_t * pgm,
                                      DMA_PROGRAM_INST_MOD_t mod)
{
    // For information on DMAST, see PL330, section 4.3.16.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 1) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Verify instruction modifier; construct bs, x mask value.
    uint8 bsx_mask = 0;
    switch (mod)
    {
    case DMA_PROGRAM_INST_MOD_NONE:
        bsx_mask = 0x0;
        break;
    case DMA_PROGRAM_INST_MOD_SINGLE:
        bsx_mask = 0x1;
        break;
    case DMA_PROGRAM_INST_MOD_BURST:
        bsx_mask = 0x3;
        break;
    default:
        return E_BAD_ARG;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMAST
    buffer[0] = 0x08 | bsx_mask;

    // Update the code size.
    pgm->code_size += 1;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMASTP(DMA_PROGRAM_t * pgm,
                                       DMA_PROGRAM_INST_MOD_t mod, DMA_PERIPH_t periph)
{
    // For information on DMASTP, see PL330, section 4.3.17.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 2) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Verify instruction modifier; construct bs mask value.
    uint8 bs_mask = 0;
    switch (mod)
    {
    case DMA_PROGRAM_INST_MOD_SINGLE:
        bs_mask = 0x0;
        break;
    case DMA_PROGRAM_INST_MOD_BURST:
        bs_mask = 0x2;
        break;
    default:
        return E_BAD_ARG;
    }

    // Verify valid peripheral identifier.
    if (periph > ((1 << 5) - 1))
    {
        return E_BAD_ARG;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMASTP
    buffer[0] = 0x29 | bs_mask;
    buffer[1] = (uint8)(periph) << 3;

    // Update the code size.
    pgm->code_size += 2;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMASTZ(DMA_PROGRAM_t * pgm)
{
    // For information on DMASTZ, see PL330, section 4.3.18.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 1) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMASTZ
    buffer[0] = 0x0c;

    // Update the code size.
    pgm->code_size += 1;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMAWFE(DMA_PROGRAM_t * pgm,
                                       DMA_EVENT_t evt, int8 invalid)
{
    // For information on DMAWFE, see PL330, section 4.3.19.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 2) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Validate evt selection
    switch (evt)
    {
    case DMA_EVENT_0:
    case DMA_EVENT_1:
    case DMA_EVENT_2:
    case DMA_EVENT_3:
    case DMA_EVENT_4:
    case DMA_EVENT_5:
    case DMA_EVENT_6:
    case DMA_EVENT_7:
    case DMA_EVENT_ABORT:
        break;
    default:
        return E_BAD_ARG;
    }

    // Construct i mask value
    uint8 i_mask = 0;
    if (invalid)
    {
        i_mask = 0x2;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMAWFE
    buffer[0] = 0x36;
    buffer[1] = ((uint8)(evt) << 3) | i_mask;

    // Update the code size.
    pgm->code_size += 2;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMAWFP(DMA_PROGRAM_t * pgm,
                                       DMA_PERIPH_t periph, DMA_PROGRAM_INST_MOD_t mod)
{
    // For information on DMAWFP, see PL330, section 4.3.20.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 2) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Verify valid peripheral identifier.
    if (periph > ((1 << 5) - 1))
    {
        return E_BAD_ARG;
    }

    // Verify instruction modifier; construct bs, p mask value.
    uint8 bsp_mask = 0;
    switch (mod)
    {
    case DMA_PROGRAM_INST_MOD_SINGLE:
        bsp_mask = 0x0;
        break;
    case DMA_PROGRAM_INST_MOD_BURST:
        bsp_mask = 0x2;
        break;
    case DMA_PROGRAM_INST_MOD_PERIPH:
        bsp_mask = 0x1;
        break;
    default:
        return E_BAD_ARG;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMAWFP
    buffer[0] = 0x30 | bsp_mask;
    buffer[1] = (uint8)(periph) << 3;

    // Update the code size.
    pgm->code_size += 2;

    return E_SUCCESS;
}

DMA_ERR DMA330_Instr_DMAWMB(DMA_PROGRAM_t * pgm)
{
    // For information on DMAWMB, see PL330, section 4.3.21.

    // Check for sufficient space in buffer
    if ((pgm->code_size + 1) > DMA_PROGRAM_PROVISION_BUFFER_SIZE)
    {
        return E_BUF_OVF;
    }

    // Buffer of where to assemble the instruction.
    uint8 * buffer = pgm->program + pgm->buffer_start + pgm->code_size;

    // Assemble DMAWMB
    buffer[0] = 0x13;

    // Update the code size.
    pgm->code_size += 1;

    return E_SUCCESS;
}
