/*
***************************************************************************************************
*
*   FileName : gdma.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include "gdma.h"
#include "clock.h"
#include "clock_dev.h"
//#include <gic.h>
#include <nvic.h>

#include <debug.h>
#include "gdma_dev.h"
#include "dma_330.h"

#if (DEBUG_ENABLE)
    #define GDMA_LOGD(fmt, args...)     {LOGD(DBG_TAG_GDMA, fmt, ## args)}
    #define GDMA_LOGE(fmt, args...)     {LOGE(DBG_TAG_GDMA, fmt, ## args)}
#else
    #define GDMA_LOGD(fmt, args...)
    #define GDMA_LOGE(fmt, args...)
#endif
/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/

// GDMA Interrupt Flag Group
#define GDMA_EVT_FLAG_GRP_TIMEOUT       (1000UL)

#define GDMA_INC                        (1UL)
#define GDMA_NO_INC                     (0UL)

#define GDMA_TRANSFER_SIZE_BYTE         (0UL)
#define GDMA_TRANSFER_SIZE_HALF         (1UL)
#define GDMA_TRANSFER_SIZE_WORD         (2UL)

#define GDMA_MAX_LLI_NUM                (64UL)

#define GDMA_BURST_SIZE_1               (0UL)
#define GDMA_BURST_SIZE_4               (1UL)
#define GDMA_BURST_SIZE_8               (2UL)
#define GDMA_BURST_SIZE_16              (3UL)
#define GDMA_BURST_SIZE_32              (4UL)
#define GDMA_BURST_SIZE_64              (5UL)
#define GDMA_BURST_SIZE_128             (6UL)
#define GDMA_BURST_SIZE_256             (7UL)

#define GDMA_FLOW_TYPE_M2M              (0UL)
#define GDMA_FLOW_TYPE_M2P              (1UL)
#define GDMA_FLOW_TYPE_P2M              (2UL)
#define GDMA_FLOW_TYPE_P2P              (3UL)

/*
***************************************************************************************************
                                             LOCAL VARIABLES
***************************************************************************************************
*/
static uint32 uiGDMAEnabled = 0UL;

static DMA_CFG_t  stDmaCfg;
static DMA_PROGRAM_t stDmaProgram;
/*
***************************************************************************************************
                                         LOCAL FUNCTION PROTOTYPES
***************************************************************************************************
*/

static void GDMA_ISR
(
    void
);



static void GDMA_ISR
(
    void
)
{

}


 /*
***************************************************************************************************
*                                          GDMA_TransferFunctionForM2M
*
* Request DMA transfer from source address to destination address with given data length.
*
* @param    pGdmaControl [in] pointer of gdma control data.
* @param    uiSourceAddress [in] source address. This address is valid only for physical address.
* @param    uiDestinationAddress [in] destination address. This address is valid only for physical address.
* @param    uiLength [in] lengh fo data requested for transfer.
* @return   the result of transfer.
*
* Notes
*
***************************************************************************************************
*/

sint32 GDMA_TransferFunctionForM2M
(
    const GDMAControlData_t *           pGdmaControl,
    uint32                              uiSourceAddress,
    uint32                              uiDestinationAddress,
    uint32                              uiLength
)
{
    SALRetCode_t ret;
    

    if ( (uiGDMAEnabled == 1UL) && (pGdmaControl != NULL_PTR))
    {
        if ((uiSourceAddress != 0UL) && (uiDestinationAddress != 0UL) && ((uiSourceAddress % sizeof(sint32)) == 0UL) && ((uiDestinationAddress % sizeof(sint32)) == 0UL))
        {
            // memory to memory copy
            ret = dma_memory_to_memory(pGdmaControl->cdChannel, (void *)&stDmaProgram, (void *)uiDestinationAddress, (const void *)uiSourceAddress, uiLength, 1, DMA_EVENT_0);
        }
        else if(((uiDestinationAddress  % sizeof(sint32)) == 0UL) && (uiSourceAddress == 0UL))
        {
            // zero fill for destination address
            ret = dma_zero_to_memory(pGdmaControl->cdChannel, (void *)&stDmaProgram, (void *)uiDestinationAddress, uiLength, 0, 0);
        }
        else
        {
            /* mis align check */
            GDMA_LOGE("SAL_ERR_INVALID_PARAMETER uiSourceAddress %x, uiDestinationAddress %x", uiSourceAddress, uiDestinationAddress);
            ret = (sint32)SAL_ERR_INVALID_PARAMETER;
        }
    }
    else
    {
        ret = (sint32)SAL_ERR_UNDEF_STATE;
    }

    GDMA_LOGD("GDMA_TransferFunctionForM2M ret %d", ret);

    return ret;
}

 /*
***************************************************************************************************
*                                          GDMA_Initialize
*
* Initialize the gdma driver.
*
* @param    pGdmaControl [in] pointer of gdma control data.
* @param    uiInterruptPriority [in] priority of gdma interrupt.
* @return
*
* Notes
*
***************************************************************************************************
*/

sint32 GDMA_Initialize
(
    GDMAControlData_t *                 pGdmaControl,
    uint32                              uiInterruptPriority
)
{
    SALRetCode_t    err = SAL_RET_SUCCESS;
    DMA_ERR dmaErr;
    DMA_CHANNEL_t channel;
    
    dmaErr = dma_init(&stDmaCfg);
    
    if (dmaErr == E_SUCCESS)
    {
        dmaErr = dma_channel_alloc_any(&channel);

        if (dmaErr == E_SUCCESS)
        {
            NVIC_IntVectSet(GDMA_0_IRQn, (IrqHandler_t)&GDMA_ISR);
            NVIC_IntSrcEn(GDMA_0_IRQn);

            uiGDMAEnabled   = 1UL;
        }
    }
    GDMA_LOGD("GDMA_Initialize ret %d", err);

    return (sint32)err;
}

