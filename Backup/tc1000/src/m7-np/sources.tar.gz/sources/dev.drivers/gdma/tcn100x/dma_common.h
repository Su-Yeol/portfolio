/*
***************************************************************************************************
*
*   FileName : dma_common.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/


#ifndef __DMA_COMMON_H__
#define __DMA_COMMON_H__

#ifdef __cplusplus
extern "C"
{
#endif  /* __cplusplus */

#define CAST(type, ptr)  ((type) (ptr))

typedef int32             DMA_ERR;

/*! Definitions of status codes returned by the HWLIB. */

/*! The operation was successful. */
#define E_SUCCESS               0

/*! The operation failed. */
#define E_ERROR                 (-1)
/*! FPGA configuration error detected.*/
#define E_FPGA_CFG              (-2)
/*! FPGA CRC error detected. */
#define E_FPGA_CRC              (-3)
/*! An error occurred on the FPGA configuration bitstream input source. */
#define E_FPGA_CFG_STM          (-4)
/*! The FPGA is powered off. */
#define E_FPGA_PWR_OFF          (-5)
/*! The SoC does not currently control the FPGA. */
#define E_FPGA_NO_SOC_CTRL      (-6)
/*! The FPGA is not in USER mode. */
#define E_FPGA_NOT_USER_MODE    (-7)
/*! An argument violates a range constraint. */
#define E_ARG_RANGE             (-8)
/*! A bad argument value was passed. */
#define E_BAD_ARG               (-9)
/*! The operation is invalid or illegal. */
#define E_BAD_OPERATION         (-10)
/*! An invalid option was selected. */
#define E_INV_OPTION            (-11)
/*! An operation or response timeout period expired. */
#define E_TMO                   (-12)
/*! The argument value is reserved or unavailable. */
#define E_RESERVED              (-13)
/*! A clock is not enabled or violates an operational constraint. */
#define E_BAD_CLK               (-14)
/*! The version ID is invalid. */
#define E_BAD_VERSION           (-15)
/*! The buffer does not contain enough free space for the operation. */
#define E_BUF_OVF               (-20)

/*!
 * Indicates a FALSE condition.
 */
#define E_FALSE                 (0)
/*!
 * Indicates a TRUE condition.
 */
#define E_TRUE                  (1)

/*!
 * \addtogroup SOCAL_UTIL_RW_FUNC SoCAL Memory Read/Write Utilities
 *
 * This section implements read and write functionality for various
 * memory untis. The memory unit terms used for these functions are
 * consistent with those used in the ARM Architecture Reference Manual
 * ARMv7-A and ARMv7-R edition manual. The terms used for units of memory are:
 *
 *  Unit of Memory | Abbreviation | Size in Bits
 * :---------------|:-------------|:------------:
 *  Byte           | byte         |       8
 *  Half Word      | hword        |      16
 *  Word           | word         |      32
 *  Double Word    | dword        |      64
 *
 * @{
 */

/*! Write the 8 bit byte to the destination address in device memory.
 *  \param dest - Write destination pointer address
 *  \param src  - 8 bit data byte to write to memory
 */
#define write_byte(dest, src)       (*CAST(volatile uint8 *, (dest)) = (src))

/*! Read and return the 8 bit byte from the source address in device memory.
 *  \param src    Read source pointer address
 *  \returns      8 bit data byte value
 */
#define read_byte(src)              (*CAST(volatile uint8 *, (src)))

/*! Write the 16 bit half word to the destination address in device memory.
 *  \param dest - Write destination pointer address
 *  \param src  - 16 bit data half word to write to memory
 */
#define write_hword(dest, src)      (*CAST(volatile uint16 *, (dest)) = (src))

/*! Read and return the 16 bit half word from the source address in device memory.
 *  \param src    Read source pointer address
 *  \returns      16 bit data half word value
 */
#define read_hword(src)             (*CAST(volatile uint16 *, (src)))

/*! Write the 32 bit word to the destination address in device memory.
 *  \param dest - Write destination pointer address
 *  \param src  - 32 bit data word to write to memory
 */
#define write_word(dest, src)       (*CAST(volatile uint32 *, (dest)) = (src))

/*! Read and return the 32 bit word from the source address in device memory.
 *  \param src    Read source pointer address
 *  \returns      32 bit data word value
 */
#define read_word(src)              (*CAST(volatile uint32 *, (src)))

/*! Write the 64 bit double word to the destination address in device memory.
 *  \param dest - Write destination pointer address
 *  \param src  - 64 bit data double word to write to memory
 */
#define write_dword(dest, src)      (*CAST(volatile uint64 *, (dest)) = (src))

/*! Read and return the 64 bit double word from the source address in device memory.
 *  \param src    Read source pointer address
 *  \returns      64 bit data double word value
 */
#define read_dword(src)             (*CAST(volatile uint64 *, (src)))


/*! Set selected bits in the 8 bit byte at the destination address in device memory.
 *  \param dest - Destination pointer address
 *  \param bits - Bits to set in destination byte
 */
#define     setbits_byte(dest, bits)        (write_byte(dest, read_byte(dest) | (bits)))

/*! Clear selected bits in the 8 bit byte at the destination address in device memory.
 *  \param dest - Destination pointer address
 *  \param bits - Bits to clear in destination byte
 */
#define     clrbits_byte(dest, bits)        (write_byte(dest, read_byte(dest) & ~(bits)))

/*! Change or toggle selected bits in the 8 bit byte at the destination address in device memory.
 *  \param dest - Destination pointer address
 *  \param bits - Bits to change in destination byte
 */
#define     xorbits_byte(dest, bits)        (write_byte(dest, read_byte(dest) ^ (bits)))

/*! Replace selected bits in the 8 bit byte at the destination address in device memory.
 *  \param  dest - Destination pointer address
 *  \param  msk  - Bits to replace in destination byte
 *  \param  src  - Source bits to write to cleared bits in destination byte
 */
#define     replbits_byte(dest, msk, src)   (write_byte(dest,(read_byte(dest) & ~(msk)) | ((src) & (msk))))

/*! Set selected bits in the 16 bit halfword at the destination address in device memory.
 *  \param dest - Destination pointer address
 *  \param bits - Bits to set in destination halfword
 */
#define     setbits_hword(dest, bits)       (write_hword(dest, read_hword(dest) | (bits)))

/*! Clear selected bits in the 16 bit halfword at the destination address in device memory.
 *  \param dest - Destination pointer address
 *  \param bits - Bits to clear in destination halfword
 */
#define     clrbits_hword(dest, bits)       (write_hword(dest, read_hword(dest) & ~(bits)))

/*! Change or toggle selected bits in the 16 bit halfword at the destination address in device memory.
 *  \param dest - Destination pointer address
 *  \param bits - Bits to change in destination halfword
 */
#define     xorbits_hword(dest, bits)       (write_hword(dest, read_hword(dest) ^ (bits)))

/*! Replace selected bits in the 16 bit halfword at the destination address in device memory.
 *  \param  dest - Destination pointer address
 *  \param  msk  - Bits to replace in destination halfword
 *  \param  src  - Source bits to write to cleared bits in destination halfword
 */
#define     replbits_hword(dest, msk, src)   (write_hword(dest,(read_hword(dest) & ~(msk)) | ((src) & (msk))))

/*! Set selected bits in the 32 bit word at the destination address in device memory.
 *  \param dest - Destination pointer address
 *  \param bits - Bits to set in destination word
 */
#define     setbits_word(dest, bits)        (write_word(dest, read_word(dest) | (bits)))

/*! Clear selected bits in the 32 bit word at the destination address in device memory.
 *  \param dest - Destination pointer address
 *  \param bits - Bits to clear in destination word
 */
#define     clrbits_word(dest, bits)        (write_word(dest, read_word(dest) & ~(bits)))

/*! Change or toggle selected bits in the 32 bit word at the destination address in device memory.
 *  \param dest - Destination pointer address
 *  \param bits - Bits to change in destination word
 */
#define     xorbits_word(dest, bits)        (write_word(dest, read_word(dest) ^ (bits)))

/*! Replace selected bits in the 32 bit word at the destination address in device memory.
 *  \param  dest - Destination pointer address
 *  \param  msk  - Bits to replace in destination word
 *  \param  src  - Source bits to write to cleared bits in destination word
 */
#define     replbits_word(dest, msk, src)   (write_word(dest,(read_word(dest) & ~(msk)) | ((src) & (msk))))

/*! Set selected bits in the 64 bit doubleword at the destination address in device memory.
 *  \param dest - Destination pointer address
 *  \param bits - Bits to set in destination doubleword
 */
#define     setbits_dword(dest, bits)       (write_dword(dest, read_dword(dest) | (bits)))

/*! Clear selected bits in the 64 bit doubleword at the destination address in device memory.
 *  \param dest - Destination pointer address
 *  \param bits - Bits to clear in destination doubleword
 */
#define     clrbits_dword(dest, bits)       (write_dword(dest, read_dword(dest) & ~(bits)))

/*! Change or toggle selected bits in the 64 bit doubleword at the destination address in device memory.
 *  \param dest - Destination pointer address
 *  \param bits - Bits to change in destination doubleword
 */
#define     xorbits_dword(dest, bits)       (write_dword(dest, read_dword(dest) ^ (bits)))

/*! Replace selected bits in the 64 bit doubleword at the destination address in device memory.
 *  \param  dest - Destination pointer address
 *  \param  msk  - Bits to replace in destination doubleword
 *  \param  src  - Source bits to write to cleared bits in destination word
 */
#define     replbits_dword(dest, msk, src)   (write_dword(dest,(read_dword(dest) & ~(msk)) | ((src) & (msk))))

/*!
 * \addtogroup DMA_COMMON DMA Controller Common API Definitions
 *
 * This module contains the common definitions for the DMA controller related
 * APIs.
 *
 * @{
 */

/*!
 * This type definition enumerates the DMA controller channel threads.
 */
typedef enum DMA_CHANNEL_e
{
    DMA_CHANNEL_0 = 0, /*!< DMA Channel Thread 0 */
    DMA_CHANNEL_1 = 1, /*!< DMA Channel Thread 1 */
    DMA_CHANNEL_2 = 2, /*!< DMA Channel Thread 2 */
    DMA_CHANNEL_3 = 3, /*!< DMA Channel Thread 3 */
    DMA_CHANNEL_4 = 4, /*!< DMA Channel Thread 4 */
    DMA_CHANNEL_5 = 5, /*!< DMA Channel Thread 5 */
    DMA_CHANNEL_6 = 6, /*!< DMA Channel Thread 6 */
    DMA_CHANNEL_7 = 7  /*!< DMA Channel Thread 7 */
}
DMA_CHANNEL_t;

/*!
 * This type definition enumerates the SoC system peripherals implementing the
 * required request interface that enables direct DMA transfers to/from the
 * device.
 *
 */
typedef enum DMA_PERIPH_e
{
	DMA_PERIPH_ADC                = 0,
	DMA_PERIPH_CAN0               = 1,
	DMA_PERIPH_CAN1               = 2,
	DMA_PERIPH_CAN2               = 3,
	DMA_PERIPH_CAN3               = 4,
	DMA_PERIPH_ICTC0              = 5,
	DMA_PERIPH_ICTC1              = 6,
	DMA_PERIPH_ICTC2              = 7,	
}
DMA_PERIPH_t;

/*!
 * This type enumerates the DMA security state options available.
 */
typedef enum DMA_SECURITY_e
{
    DMA_SECURITY_DEFAULT   = 0, /*!< Use the default security value (e.g. reset default) */
    DMA_SECURITY_SECURE    = 1, /*!< Secure */
    DMA_SECURITY_NONSECURE = 2  /*!< Non-secure */
}
DMA_SECURITY_t;

/*!
 * This type definition enumerates the DMA event-interrupt resources.
 */
typedef enum DMA_EVENT_e
{
    DMA_EVENT_0     = 0, /*!< DMA Event 0 */
    DMA_EVENT_1     = 1, /*!< DMA Event 1 */
    DMA_EVENT_2     = 2, /*!< DMA Event 2 */
    DMA_EVENT_3     = 3, /*!< DMA Event 3 */
    DMA_EVENT_4     = 4, /*!< DMA Event 4 */
    DMA_EVENT_5     = 5, /*!< DMA Event 5 */
    DMA_EVENT_6     = 6, /*!< DMA Event 6 */
    DMA_EVENT_7     = 7, /*!< DMA Event 7 */
    DMA_EVENT_ABORT = 8  /*!< DMA Abort Event */
}
DMA_EVENT_t;

#define CACHE_LINE_SIZE         32

#define DMA330_SECURE_DEFAULT_NS

/*!
 * @}
 */

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __DMA_COMMON_H__ */
