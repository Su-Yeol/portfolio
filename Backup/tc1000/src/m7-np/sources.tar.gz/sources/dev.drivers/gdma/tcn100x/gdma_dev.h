/*
***************************************************************************************************
*
*   FileName : gdma_dev.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef GDMA_DEV_HEADER_H
#define GDMA_DEV_HEADER_H

#define GDMA_BASE_ADDRESS               (0x1B600000UL)

#define GDMA_INTSR                      (0x00UL)
#define GDMA_ITCSR                      (0x04UL)
#define GDMA_ITCCR                      (0x08UL)
#define GDMA_IESR                       (0x0CUL)
#define GDMA_IECR                       (0x10UL)
#define GDMA_RITCSR                     (0x14UL)
#define GDMA_REISR                      (0x18UL)
#define GDMA_ECR                        (0x1CUL)
#define GDMA_SBRR                       (0x20UL)
#define GDMA_SSRR                       (0x24UL)
#define GDMA_SLBRR                      (0x28UL)
#define GDMA_SLSRR                      (0x2CUL)
#define GDMA_CR                         (0x30UL)
#define GDMA_SR                         (0x34UL)

#define DMA_CH_SRC_ADDR(x)              ((0x100UL + ((x) * 0x20UL)))
#define DMA_CH_DST_ADDR(x)              ((0x104UL + ((x) * 0x20UL)))
#define DMA_CH_LLI(x)                   ((0x108UL + ((x) * 0x20UL)))
#define DMA_CH_CON(x)                   ((0x10CUL + ((x) * 0x20UL)))
#define DMA_CH_CONFIG(x)                ((0x110UL + ((x) * 0x20UL)))

#define DMA_MAX_XFER_SIZE               (0xFFFUL)


//============================================================================================================================
// Controller hardware access definitions
//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
// DMA Controller - Configuration Register
#define bwDMA_CTRLR_ENABLED         1   // DMA Ctrlr enabled flag
#define bwDMA_AHB1_ENDIAN           1   // AHB Bus 1 Endianness
#define bwDMA_AHB2_ENDIAN           1   // AHB Bus 2 Endianness

#define bsDMA_CTRLR_ENABLED         0
#define bsDMA_AHB1_ENDIAN           1
#define bsDMA_AHB2_ENDIAN           2

// DMA Controller - Protection Register
#define bwDMA_PROTECTED_USE         1   // Protected access bit

#define bsDMA_PROTECTED_USE         0

// DMA Controller - DMA Channel LLI Register
#define bwDMA_NEXT_LLI_BUS          1   // AHB Bus of next LLI
#define bwDMA_LLI_RESERVED          1   // Reserved (set to 0 on write)
#define bwDMA_NEXT_LLI              30  // Address of next LLI

#define bsDMA_NEXT_LLI_BUS          0
#define bsDMA_LLI_RESERVED          1
#define bsDMA_NEXT_LLI              2

// DMA Controller - DMA Channel Control Register
#define bwDMA_TRANSFER_SIZE         12  // Transfer size
#define bwDMA_SRC_BURST_SIZE        3   // Source Burst Size
#define bwDMA_DEST_BURST_SIZE       3   // Destination Burst Size
#define bwDMA_SRC_WIDTH             3   // Source Width
#define bwDMA_DEST_WIDTH            3   // Destination Width
#define bwDMA_SRC_BUS               1   // Source AHB Bus
#define bwDMA_DEST_BUS              1   // Destination AHB Bus
#define bwDMA_SRC_INCREMENT         1   // Source auto Increment
#define bwDMA_DEST_INCREMENT        1   // Destination auto Increment
#define bwDMA_PROTECTION            3   // Bus Protection Lines
#define bwDMA_TC_INTERRUPT_ENABLE   1   // TC Interrupt enable

#define bsDMA_TRANSFER_SIZE         0
#define bsDMA_SRC_BURST_SIZE        12
#define bsDMA_DEST_BURST_SIZE       15
#define bsDMA_SRC_WIDTH             18
#define bsDMA_DEST_WIDTH            21
#define bsDMA_SRC_BUS               24
#define bsDMA_DEST_BUS              25
#define bsDMA_SRC_INCREMENT         26
#define bsDMA_DEST_INCREMENT        27
#define bsDMA_PROTECTION            28
#define bsDMA_TC_INTERRUPT_ENABLE   31

// DMA Controller - DMA Channel Configuration Register
#define bwDMA_CHANNEL_ENABLED       1   // Channel Enable
#define bwDMA_SRC_PERIPHERAL        5   // Source peripheral Id (0-31)
#define bwDMA_DEST_PERIPHERAL       5   // Destination peripheral Id (0-31)
#define bwDMA_FLOW_CONTROL          3   // Flow Control
#define bwDMA_ERROR_INTERRUPT_MASK  1   // Error Interrupt Mask
#define bwDMA_TC_INTERRUPT_MASK     1   // Terminal Count Interrupt Mask
#define bwDMA_BUS_LOCK              1   // Bus Lock
#define bwDMA_ACTIVE                1   // FIFO Active
#define bwDMA_HALT                  1   // Halt
#define bwDMA_CONFIG_RESERVED       13  // Reserved

#define bsDMA_CHANNEL_ENABLED       0
#define bsDMA_SRC_PERIPHERAL        1
#define bsDMA_DEST_PERIPHERAL       6
#define bsDMA_FLOW_CONTROL          11
#define bsDMA_ERROR_INTERRUPT_MASK  14
#define bsDMA_TC_INTERRUPT_MASK     15
#define bsDMA_BUS_LOCK              16
#define bsDMA_ACTIVE                17
#define bsDMA_HALT                  18
#define bsDMA_CONFIG_RESERVED       19

#define DMA_MAX_CHANNELS            8
#define DMA_MAX_AHB_MASTERS         2


//============================================================================================================================
// Common type definitions
//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
// Channel index
typedef enum
{
    GDMA_CHANNEL_INDEX_0     = 0,    // Channel-0
    GDMA_CHANNEL_INDEX_1     = 1,    // Channel-1
    GDMA_CHANNEL_INDEX_2     = 2,    // Channel-2
    GDMA_CHANNEL_INDEX_3     = 3,    // Channel-3
    GDMA_CHANNEL_INDEX_4     = 4,    // Channel-4
    GDMA_CHANNEL_INDEX_5     = 5,    // Channel-5
    GDMA_CHANNEL_INDEX_6     = 6,    // Channel-6
    GDMA_CHANNEL_INDEX_7     = 7,    // Channel-7
    GDMA_CHANNEL_INDEX_ALL   = 8     // Channel-0~7
} GDMAChannelIndex;

// Request index
typedef enum 
{
    GDMA_REQUEST_INDEX_0     = 0,    // Channel-0 
    GDMA_REQUEST_INDEX_1     = 1,    // Channel-1 
    GDMA_REQUEST_INDEX_2     = 2,    // Channel-2 
    GDMA_REQUEST_INDEX_3     = 3,    // Channel-3 
    GDMA_REQUEST_INDEX_4     = 4,    // Channel-4 
    GDMA_REQUEST_INDEX_5     = 5,    // Channel-5 
    GDMA_REQUEST_INDEX_6     = 6,    // Channel-6 
    GDMA_REQUEST_INDEX_7     = 7,    // Channel-7 
    GDMA_REQUEST_INDEX_8     = 8,    // Channel-8 
    GDMA_REQUEST_INDEX_9     = 9,    // Channel-9 
    GDMA_REQUEST_INDEX_10    = 10,   // Channel-10
    GDMA_REQUEST_INDEX_11    = 11,   // Channel-11
    GDMA_REQUEST_INDEX_12    = 12,   // Channel-12
    GDMA_REQUEST_INDEX_13    = 13,   // Channel-13
    GDMA_REQUEST_INDEX_14    = 14,   // Channel-14
    GDMA_REQUEST_INDEX_15    = 15,   // Channel-15
    GDMA_REQUEST_INDEX_ALL   = 16    // Channel-0~15
} GDMARequestIndex;

// AHB endianness
typedef enum 
{
    GDMA_LITTLE_ENDIAN       = 0,    // Litle endian
    GDMA_BIG_ENDIAN          = 1     // Big   endian
} GDMAAhbEndian;


// Id used to refer to AHB bus
typedef enum 
{
    GDMA_AHB_BUS_1           = 0,    // AHB Bus 1
    GDMA_AHB_BUS_2           = 1     // AHB Bus 2
} GDMAAhbBus;

// Id used to refer to AHB bus
typedef enum 
{
    GDMA_DISABLE             = 0,    // Disable
    GDMA_ENABLE              = 1     // Eanble
} GDMAEn;

// Width of the AHB bus(es)
typedef enum 
{
    GDMA_AHB_WIDTH_8_BIT     = 0,    //   32 Bits
    GDMA_AHB_WIDTH_16_BIT    = 1,    //   32 Bits
    GDMA_AHB_WIDTH_32_BIT    = 2     //   32 Bits
} GDMAAhbWidth;

// Burst Transfer Size
typedef enum 
{
    GDMA_BURST_1             = 0,    //   1 transfer  per burst
    GDMA_BURST_4             = 1,    //   4 transfers per burst
    GDMA_BURST_8             = 2,    //   8 transfers per burst
    GDMA_BURST_16            = 3,    //  16 transfers per burst
    GDMA_BURST_32            = 4,    //  32 transfers per burst
    GDMA_BURST_64            = 5,    //  64 transfers per burst
    GDMA_BURST_128           = 6     // 128 transfers per burst
} GDMABurstSize;

// Transfer Width
// : Do not specify a greater width than actual width of the AHB bus(es)
typedef enum 
{
    GDMA_WIDTH_8_BIT         = 0,    //    8 Bits per transfer
    GDMA_WIDTH_16_BIT        = 1,    //   16 Bits per transfer
    GDMA_WIDTH_32_BIT        = 2,    //   32 Bits per transfer
    GDMA_WIDTH_64_BIT        = 3,    //   64 Bits per transfer
    GDMA_WIDTH_128_BIT       = 4,    //  128 Bits per transfer
    GDMA_WIDTH_256_BIT       = 5,    //  256 Bits per transfer
    GDMA_WIDTH_512_BIT       = 6,    //  512 Bits per transfer
    GDMA_WIDTH_1024_BIT      = 7     // 1024 Bits per transfer
} GDMAWidth;

typedef enum 
{
    GDMA_SYNC_ENABLE   = 0,
    GDMA_SYNC_DISABLE  = 1
} GDMASync;

// Settings for AHB Bus Protection Lines
// : The desired protection should be created by binary ORing one entry from each pair. 
// ex) dma_PROT_SUPER | dma_PROT_BUFFERABLE | dma_PROT_CACHEABLE
typedef enum 
{
    GDMA_PROT_USER           = 0x00, // User access
    GDMA_PROT_SUPER          = 0x01, // Supervisor access

    GDMA_PROT_NON_BUFFERABLE = 0x00, // Non bufferable data
    GDMA_PROT_BUFFERABLE     = 0x02, // Bufferable data

    GDMA_PROT_NON_CACHEABLE  = 0x00, // Non cacheable data
    GDMA_PROT_CACHEABLE      = 0x04, // Cacheable data

    GDMA_PROTECTION_VALID    = ( GDMA_PROT_CACHEABLE  |
                                GDMA_PROT_BUFFERABLE |
                                GDMA_PROT_SUPER )
} GDMAProtectionBits;

// Enum of possible DMA flow directions & flow controllers
typedef enum GDMA_xFLOW_CONTROL
{
    GDMA_MEM_TO_MEM_DMA_CTRL                            = 0,
    GDMA_MEM_TO_PERIPHERAL_DMA_CTRL                     = 1,
    GDMA_PERIPHERAL_TO_MEM_DMA_CTRL                     = 2,
    GDMA_PERIPHERAL_TO_PERIPHERAL_DMA_CTRL              = 3,
    GDMA_PERIPHERAL_TO_PERIPHERAL_DEST_PERIPHERAL_CTRL  = 4,
    GDMA_MEM_TO_PERIPHERAL_PERIPHERAL_CTRL              = 5,
    GDMA_PERIPHERAL_TO_MEM_PERIPHERAL_CTRL              = 6,
    GDMA_PERIPHERAL_TO_PERIPHERAL_SRC_PERIPHERAL_CTRL   = 7

} GDMAFlowControl;

// Interrupt status / clear, enabled channel register structure
typedef struct  {
    uint32    CH0         : 1;    // [00]
    uint32    CH1         : 1;    // [01]
    uint32    CH2         : 1;    // [02]
    uint32    CH3         : 1;    // [03]
    uint32    CH4         : 1;    // [04]
    uint32    CH5         : 1;    // [05]
    uint32    CH6         : 1;    // [06]
    uint32    CH7         : 1;    // [07]
    uint32    reserved0   : 24;   // [31:08]
} GDMAChannel_t;

typedef union {
    uint32        nReg;
    GDMAChannel_t     bReg;
} GDMAChannelUnion_t;

// Software burst/single/last burst/last/single request, synchronization register structure
typedef struct  {
    uint32    REQ0        : 1;    // [00]
    uint32    REQ1        : 1;    // [01]
    uint32    REQ2        : 1;    // [02]
    uint32    REQ3        : 1;    // [03]
    uint32    REQ4        : 1;    // [04]
    uint32    REQ5        : 1;    // [05]
    uint32    REQ6        : 1;    // [06]
    uint32    REQ7        : 1;    // [07]
    uint32    REQ8        : 1;    // [08]
    uint32    REQ9        : 1;    // [09]
    uint32    REQ10       : 1;    // [10]
    uint32    REQ11       : 1;    // [11]
    uint32    REQ12       : 1;    // [12]
    uint32    REQ13       : 1;    // [13]
    uint32    REQ14       : 1;    // [14]
    uint32    REQ15       : 1;    // [15]
    uint32    reserved0   : 16;   // [31:16]
} GDMAReq_t;

typedef union {
    uint32        nReg;
    GDMAReq_t    bReg;
} GDMAReqUnion_t;

// Configuration register structure
typedef struct  {
    uint32    CTRL_ENABLE     : bwDMA_CTRLR_ENABLED;
    uint32    AHB1_ENDIAN     : bwDMA_AHB1_ENDIAN;
    uint32    AHB2_ENDIAN     : bwDMA_AHB2_ENDIAN;
    uint32    reserved0       : (32-bwDMA_CTRLR_ENABLED -bwDMA_AHB1_ENDIAN -bwDMA_AHB2_ENDIAN);
} GDMACfg_t;

typedef union {
    uint32        nReg;
    GDMACfg_t    bReg;
} GDMACfgUnion_t;

// Channel linked list item register structure
typedef struct  {
    uint32    NEXT_LLI_BUS    : bwDMA_NEXT_LLI_BUS;
    uint32    reserved0       : bwDMA_LLI_RESERVED;
    uint32    NEXT_LLI        : bwDMA_NEXT_LLI;
} GDMAChLLI_t;

typedef union {
    uint32        nReg;
    GDMAChLLI_t bReg;
} GDMAChLLIUnion_t;

// Channel control register structure
typedef struct  {
    uint32    TRANSFER_SIZE       : bwDMA_TRANSFER_SIZE;
    uint32    SRC_BURST_SIZE      : bwDMA_SRC_BURST_SIZE;
    uint32    DEST_BURST_SIZE     : bwDMA_DEST_BURST_SIZE;
    uint32    SRC_WIDTH           : bwDMA_SRC_WIDTH;
    uint32    DEST_WIDTH          : bwDMA_DEST_WIDTH;
    uint32    SRC_BURST             : bwDMA_SRC_BUS;
    uint32    DEST_BURST            : bwDMA_DEST_BUS;
    uint32    SRC_INCREMENT       : bwDMA_SRC_INCREMENT;
    uint32    DEST_INCREMENT      : bwDMA_DEST_INCREMENT;
    uint32    PROTECTION          : bwDMA_PROTECTION;
    uint32    TC_INTERRUPT_ENABLE : bwDMA_TC_INTERRUPT_ENABLE;
} GDMAChCtrl_t;

typedef union {
    uint32            nReg;
    GDMAChCtrl_t    bReg;
} GDMAChCtrlUnion_t;

// Channel configuration register structure
typedef struct  {
    uint32    CHANNEL_ENABLED      : bwDMA_CHANNEL_ENABLED;
    uint32    SRC_PERIPHERAL       : bwDMA_SRC_PERIPHERAL;
    uint32    DEST_PERIPHERAL      : bwDMA_DEST_PERIPHERAL;
    uint32    FLOW_CONTROL         : bwDMA_FLOW_CONTROL;
    uint32    INTERRUPT_ERROR_MASK : bwDMA_ERROR_INTERRUPT_MASK;
    uint32    TC_INTERRUPT_MASK    : bwDMA_TC_INTERRUPT_MASK;
    uint32    BUS_LOCK             : bwDMA_BUS_LOCK;
    uint32    ACTIVE               : bwDMA_ACTIVE;
    uint32    HALT                 : bwDMA_HALT;
    uint32    reserved0            : bwDMA_CONFIG_RESERVED;
} GDMAChCfg_t;

typedef union {
    uint32            nReg;
    GDMAChCfg_t     bReg;
} GDMAChCfgUnion_t;

// DMA Controller - DMA Channel Registers - template structure
typedef volatile struct 
{
    uint32            SRC_ADDR;           //0x100
    uint32            DEST_ADDR;           //0x104
    GDMAChLLIUnion_t     LLI;           //0x108
    GDMAChCtrlUnion_t    dmaCTRL;           //0x10c
    GDMAChCfgUnion_t     dmaCFG;           //0x110
    uint32            Reserved0;           //0x114
    uint32            Reserved1;           //0x118
    uint32            Reserved2;           //0x11c
} GDMAChannelReg_t;

// Constants defining the size (in 32 bit words) of reserved spaces in the DMA controllers address space
#define DMA_NUM_RSRVD_WRDS_BEFORE_CHANNELS      ( (0x100 - 0x038) >> 2 )
#define DMA_NUM_RSRVD_WRDS_BEFORE_PERIPHERAL_ID ( (0xfe0 - 0x200) >> 2 )

// DMA Controller - Template structure of entire address space of a DMA controller
typedef volatile struct 
{
    GDMAChannelUnion_t         crIntStatus;                                             // 0x0000 
    GDMAChannelUnion_t         crIntTCStatus;                                         // 0x0004 
    GDMAChannelUnion_t         crIntTCClear;                                          // 0x0008 
    GDMAChannelUnion_t         crIntErrorStatus;                                         // 0x000c 
    GDMAChannelUnion_t         crIntErrorClear;                                          // 0x0010 
    GDMAChannelUnion_t         crRawIntTCStatus;                                     // 0x0014 
    GDMAChannelUnion_t         crRawIntErrorStatus;                                     // 0x0018 
    GDMAChannelUnion_t         crEnabledChannels;                                        // 0x001c 
    GDMAReqUnion_t        crSoftBReq;                                           // 0x0020 
    GDMAReqUnion_t        crSoftSReq;                                          // 0x0024 
    GDMAReqUnion_t        crSoftLBReq;                                      // 0x0028 
    GDMAReqUnion_t        crSoftLSReq;                                     // 0x002c 
    GDMACfgUnion_t        crConfiguration;                                                 // 0x0030 
    GDMAReqUnion_t        crSync;                                                  // 0x0034 

    uint32            Reserved0[DMA_NUM_RSRVD_WRDS_BEFORE_CHANNELS];          // 0x0038 ~ 0x00fc

    GDMAChannelReg_t    crDMAChannel[DMA_MAX_CHANNELS];                                         // 0x0100 ~ 0x01fc

    uint32            Reserved1[DMA_NUM_RSRVD_WRDS_BEFORE_PERIPHERAL_ID];     // 0x0200 ~ 0x0fdc

    uint32            crPeriID0;                                               // 0x0fe0
    uint32            crPeriID1;                                               // 0x0fe4
    uint32            crPeriID2;                                               // 0x0fe8
    uint32            crPeriID3;                                               // 0x0fec
    uint32            crPeriID4;                                               // 0x0ff0
    uint32            crPeriID5;                                               // 0x0ff4
    uint32            crPeriID6;                                               // 0x0ff8
    uint32            crPeriID7;                                               // 0x0ffc
} GDMAControllerRegister_t;

// DMA LLI format
typedef struct 
{
    uint32            lfSrcAddr;
    uint32            lfDestAddr;
    GDMAChLLIUnion_t     lfLLI;
    GDMAChCtrlUnion_t    lfCTRL;
} GDMALLIFormat;

#endif  /* GDMA_DEV_HEADER_H */

