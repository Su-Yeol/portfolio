/* SPDX-License-Identifier: (GPL-2.0 WITH Linux-syscall-note) AND MIT */

/*************************************************************************/ /*!
@File
@Title          fp_netd.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    data structures Host interfaces
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#include <linux/types.h>
#include <linux/netdevice.h>

#include "fp_macros.h"
#include "tables_config.h"

#ifndef  _FP_NETD_H_
#define  _FP_NETD_H_
/*nfp device private info structure */
typedef struct fp_dev_info_s {
	struct net_device	*priv;
	uint8		real_dev_addr[ETH_ALEN];
	uint8		phyPortNo;
	struct net_device_stats	dev_stats;
	struct proc_dir_entry	*dent;
}fp_dev_info_t;

/*nfp device private info structure */
typedef struct nfp_dev_info_s{
	struct net_device	*real_dev;
	uint8		real_dev_addr[ETH_ALEN];
	uint8		phyPortNo;
	uint8		ifnum;
	struct net_device_stats	dev_stats;
	struct proc_dir_entry	*dent;


}nfp_dev_info_t;
extern struct net_device *fp_phy_addr[FP_MAX_PORTS];

/*Devices for fp*/
extern fp_dev_info_t  *dev0,*dev1;
#define NFP_DEV_INFO(x) ((nfp_dev_info_t *)(x->ml_priv))

typedef struct nfp_global_config {
	uint32a fastpath; /* enable or disable fastpath */
	uint32a notifier; /* enable or disable notifier */
} nfp_global_config_t;

extern nfp_global_config_t fpathConfig;
extern fp_dev_info_t  *fp_logical_dev[FP_MAX_PORTS];
extern int32a nfp_skb_recv(struct sk_buff *skb,
			struct net_device *dev,
			struct packet_type* ptype,
			struct net_device *orig_dev);
extern uint8 *getPciBaseAddr(void *dev);
extern int32a dump_packet(struct sk_buff *skb);
extern int32a fp_netif_receive_skb(struct sk_buff *skb);

int32a nfp_dev_rebuild_header(struct sk_buff *skb);
int32a fp_config_ioctl(struct net_device *, struct ifreq *rq, int32a cmd);



#endif /*End of _FP_NETD_H_ File */
