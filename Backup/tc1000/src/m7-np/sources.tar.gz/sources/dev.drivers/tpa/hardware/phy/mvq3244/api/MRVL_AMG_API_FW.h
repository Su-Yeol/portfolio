/**
 * @file MRVL_AMG_API_FW.h
 * @brief Marvell Multi-gig Automotive Ethernet PHY FW API header file for loading FW images 
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */

#ifndef MRVL_AMG_FW_H
#define MRVL_AMG_FW_H

#include "MRVL_AMG_API_CMD.h"
#include "MRVL_AMG_HwInterface.h"


#define DWORD_SIZE 4
#define SPI_SHA_BUFFER_SIZE 0x40
#define PTP_ARRAY_SIZE 16
#define MRVL_AMG_FLASH_INVALID_OPCODE 0xffU        /* invalid op code*/

MRVL_APHY_STATUS MRVL_AMG_FLASH_softResetFlash(MRVL_DEV_PTR device);
MRVL_APHY_STATUS MRVL_AMG_FLASH_resetFWFlash(MRVL_DEV_PTR device);
MRVL_APHY_STATUS MRVL_AMG_FLASH_eraseFlash(MRVL_DEV_PTR device, const MRVL_AMG_FLASH* flashInfo);
MRVL_APHY_STATUS MRVL_AMG_FLASH_writeFlash(MRVL_DEV_PTR device, const MRVL_AMG_FLASH* flashInfo, MRVL_APHY_U8 image[], MRVL_APHY_U32 imageSize);
MRVL_APHY_STATUS MRVL_AMG_FLASH_readFlash(MRVL_DEV_PTR device, const MRVL_AMG_FLASH* flashInfo, MRVL_APHY_U8 image[], MRVL_APHY_U32 imageSize, MRVL_APHY_BOOL standAloneRead);
MRVL_APHY_STATUS MRVL_AMG_FLASH_getFlashInfo(MRVL_DEV_PTR device, MRVL_AMG_FLASH* flashInfo);

/******************************************************************************
 *      FW Image and Flash
 ******************************************************************************/
/** @defgroup PHY_FW PHY FW Info, Image and Flash */

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_GetFirmwareInfo(MRVL_DEV_PTR device, MRVL_AMG_FirmwareInfo* fwInfo);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_LoadFlash(MRVL_DEV_PTR device, MRVL_APHY_U8 image[], MRVL_APHY_U32 size, MRVL_APHY_BOOL performVerification);

#endif
