/**
 * @file MRVL_Q222X.c
 * @brief Q222X General PHY Ctrl API Source File.
 * DUT General Control and Status Access
 *
 * @par Copyright and Version
 * See MRVL_Q222X_Copyright_and_Version.h
 */


#include "MRVL_Q222X.h"

/* check reg access */
STATIC MRVL_APHY_STATUS checkRegAccess(MRVL_DEV_PTR device)
{
	MRVL_APHY_U16 i;
	MRVL_APHY_U16 mrvlId;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_ERROR_MDIO;
	/* check reg access by reading bacl MRVL ID*/
	for (i = MRVL_Q222X_ACCESS_ATTEMPT_LOWER_BOUND; i <= MRVL_Q222X_ACCESS_ATTEMPT_UPPER_BOUND; i++)
	{
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_ID_DEVICE, MRVL_ORGANIZATION_ID_REG, &mrvlId);
		if (mrvlId == MRVL_ORGANIZATION_ID)
		{
			status = MRVL_APHY_STATUS_OK;
			break;
		}
		mrvl_aphy_wait(device, 1);
	}
	return status;
}

/**
 * @brief Get link status for GE/speed 1000, including PCS (local/remote) and local PMA
 *
 * @param[in]	device PHY pointer
 * @return MRVL_APHY_BOOL
 */
STATIC MRVL_APHY_BOOL checkLinkGe(MRVL_DEV_PTR device)
{
	MRVL_APHY_U16 regVal1, regVal2, regVal3;
	MRVL_APHY_BOOL isLinkup;
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, 3, 0x0901, &regVal1);
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, 3, 0x0901, &regVal1);	/* Read twice: link latches low status */
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, 7, 0x8001, &regVal2);	/* local and remote receiver status */
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, 3, 0xFD9D, &regVal3);	/* local receiver status 2 */
	isLinkup = ((0x0004U == (regVal1 & 0x0004U))
					&& (0x3000U == (regVal2 & 0x3000U))
					&& (0x0010U == (regVal3 & 0x0010U))) ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
	return isLinkup;
}

/**
 * @brief Get link status for FE/speed 100, including PCS (local/remote) and local PMA
 *
 * @param[in]	device PHY pointer
 * @return MRVL_APHY_BOOL
 */
STATIC MRVL_APHY_BOOL checkLinkFe(MRVL_DEV_PTR device)
{
	MRVL_APHY_U16 regVal;
	MRVL_APHY_BOOL isLinkup;
	/* link, local and remote receiver status */
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, 3, 0x810A, &regVal);
	/* bit[2:0]:  real time link, remote rx, and local rx,*/
	isLinkup = (0x0007U == (regVal & 0x0007U)) ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
	return isLinkup;
}

/**
 * @brief apply SGMII init code
 *
 * @param[in]	device PHY pointer
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void applySGMIIInit(MRVL_DEV_PTR device)
{
	/* Front-End optimization for SGMII */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AB, 0x0001);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AD, 0x0000);

	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AC, 0x0085);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AE, 0x1250);

	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AC, 0x0086);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AE, 0x9958);

	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AC, 0x0089);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AE, 0x1444);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AC, 0x00CC);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AE, 0x35FC);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AC, 0x0044);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AE, 0xCFC6);

	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AC, 0x0041);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AE, 0x190F);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AC, 0x0042);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AE, 0x144A);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AC, 0x0043);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AE, 0x56AD);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AC, 0x0050);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AE, 0xF800);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AC, 0x0051);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x80AE, 0x0970);

	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x818B, 0x00C0);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x8000, 0x3900);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x8000, 0x3100);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x818B, 0x0000);
	/* Toggle Squelch override */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x8178, 0x7540);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4, 0x8178, 0x5540);
}

/**
 * @brief apply B1 general init code.
 *
 * @param[in]	device PHY pointer
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void applyB1Init(MRVL_DEV_PTR device)
{
	/* set power management state breakpoint (internal state) */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFFE4, 0x0007);
	/* disable ANEG */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 7, 0x0200, MRVL_Q222X_AN_DISABLE);
	/* prepare to write init code */
	/* enable TXDAC setting overwrite bit */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xffe3, 0x7000);
	/* set IEEE power down */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 1, 0x0, 0x0840);
	/* wait 3 ms to get to ON_TBGB State and send out WUP if needed */
	mrvl_aphy_wait(device, 3);
	/* mdi vcm */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE07, 0x125A);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE09, 0x1288);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE08, 0x2588);
	/* aux_boost */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE72, 0x042C);
	/* Force ON_TBGB state */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFFE4, 0x0071);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFFE4, 0x0001);
	/* exit standby state(internal state) */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE1B, 0x0048);
	/* exit IEEE power down */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 1, 0x0000, 0x0000);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0x0000, 0x0000);
	/* disable DCL calibratin during tear down */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFFDB, 0xFC10);
	/* disable RESET of DCL*/
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE1B, 0x58);
	/* configure TC10 loc_act_detect for rev B1 */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFCAD, 0x030C);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0x8032, 0x6001);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFDFF, 0x05A5);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFDEC, 0xDBAF);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFCAB, 0x1054);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFCAC, 0x1483);
	/* set DISABLE_WAIT_COMM to 0 for WUR */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0x8033, 0xC801);
	/* send_s detection threshold, slave and master */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 7, 0x8032, 0x2020);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 7, 0x8031, 0xA28);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 7, 0x8031, 0xC28);
	/* update Initial FFE Coefficients */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFBBA, 0x0CB2);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFBBB, 0x0C4A);
	/* aneg set pga gain and amp */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE5F, 0xE8);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE05, 0x755C);
	/* Disable R2 Timer */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFA20, 0x002A);
	/* TM4 */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE11, 0x1105);
}

/* prepare to write init code */
STATIC void applyB0PreInit(MRVL_DEV_PTR device)
{
	MRVL_APHY_U16 regVal;
	MRVL_APHY_U16 i;
	/* enable txdac */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0x8033, 0x6801);
	/* disable ANEG */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 7, 0x0200, MRVL_Q222X_AN_DISABLE);
	/* prepare to write init code */
	/* set IEEE power down */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 1, 0x0, 0x840);
	/* exit standby state(internal state) */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE1B, 0x48);
	/* set power management state breakpoint (internal state) */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFFE4, 0x6B6);
	/* exit IEEE power down */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 1, 0x0000, 0x0000);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0x0000, 0x0000);
	/* wait upto MRVL_Q222X_ACCESS_ATTEMPT_UPPER_BOUND to enter to power management state */
	/* if not meet the target value, is still ok to proceed */
	for (i = MRVL_Q222X_ACCESS_ATTEMPT_LOWER_BOUND; i < MRVL_Q222X_ACCESS_ATTEMPT_UPPER_BOUND; i++)
	{
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, 3, 0xFFE4, &regVal);
		if (regVal == 0x06BA)
		{
			break;
		}
		mrvl_aphy_wait(device, 1);
	}
	/* Turn CM Clamp OFF */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE79, 0x0000);
	/* mdi vcm */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE07, 0x125A);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE09, 0x1288);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE08, 0x2588);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE11, 0x1105);
	/* aux_boost */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE72, 0x042C);
}

/* apply Ge/speed 1000 init code */
STATIC void applyGeInit(MRVL_DEV_PTR device, MRVL_APHY_BOOL needPrepare)
{
	if (device->revNum != MRVL_Q222X_B1)
	{
		/* call rev B0's per mode init sequence */
		if(MRVL_APHY_TRUE == needPrepare)
		{
			/* prepare to write init code */
			applyB0PreInit(device);
		}
		/* send_s detection threshold, slave and master */
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 7, 0x8032, 0x2020);
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 7, 0x8031, 0xA28);
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 7, 0x8031, 0xC28);
		/* disable DCL calibratin during tear down */
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFFDB, 0xFC10);
		/* disable RESET of DCL*/
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE1B, 0x58);
		/* Turn CM Clamp ON */
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE79, 0x0004);
	}
	else
	{
		/* call rev B1's general init sequence */
		applyB1Init(device);
	}
}

/* apply Fe/speed 100 init code */
STATIC void applyFeInit(MRVL_DEV_PTR device, MRVL_APHY_BOOL needPrepare)
{

	if (device->revNum != MRVL_Q222X_B1)
	{
		/* call rev B0's per mode init sequence */
		if(MRVL_APHY_TRUE == needPrepare)
		{
			/* prepare to write init code */
			applyB0PreInit(device);
		}
		/* update Initial FFE Coefficients */
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFBBA, 0x0CB2);
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFBBB, 0x0C4A);
		/* Turn CM Clamp ON */
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE79, 0x0004);
	}
	else
	{
		/* call rev B1's general init sequence */
		applyB1Init(device);
	}
}

/* apply aneg init code: validate the aneg speeds and run init commands */
STATIC MRVL_APHY_STATUS applyAnegInit(MRVL_DEV_PTR device, MRVL_APHY_U16 flag)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 anAbility = (flag & (MRVL_Q222X_AN_GE_ABILITY | MRVL_Q222X_AN_FE_ABILITY));
	/* validate aneg ability */
	if (0x0 == anAbility)
	{
		/* disable AN if data rates are invalid */
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 7, 0x0203, MRVL_Q222X_AN_DISABLE);
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 7, 0x0200, MRVL_Q222X_AN_RESET);
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		if (device->revNum != MRVL_Q222X_B1)
		{
			/* call rev B0's per mode init sequence */
			/* prepare to write init code */
			applyB0PreInit(device);
			/* apply Fe/speed 100 init code */
			applyFeInit(device, MRVL_APHY_FALSE);
			/* apply Ge/speed 1000 init code */
			applyGeInit(device, MRVL_APHY_FALSE);
			/* aneg set pga gain and amp */
			mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE5F, 0xE8);
			mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE05, 0x755C);
		}
		else
		{
			/* call rev B1's general init sequence */
			applyB1Init(device);
		}
		/* set Ability registers */
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 7, 0x0203, anAbility);
	}
	return status;
}

/* GE/1000BT1 soft reset */
STATIC void softResetGe(MRVL_DEV_PTR device)
{
	/* enable RESET of DCL */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE1B, 0x48);
	/* soft reset */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0x0900, 0x8000);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFFE4, 0x000C);
	/* disable RESET of DCL */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFE1B, 0x58);
}

/* FE/100BT1 soft reset */
STATIC void softResetFe(MRVL_DEV_PTR device)
{
	if(device->revNum != MRVL_Q222X_B1)
	{
		/* soft reset */
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0x0900, 0x8000);
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 3, 0xFFE4, 0x000C);
	}
	else
	{
		/* rev B1 uses general reset sequence*/
		softResetGe(device);
	}

}

/******************************************************************************
 *      Device Detection
 ******************************************************************************/

/**
 * @brief Obtain Q222X information.
 * Initialize with this function to update device ptr with model id an rev number
 *
 * @param[in,out]	device PHY pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PHY_DEVICE
 */
MRVL_APHY_STATUS q222x_getDeviceInfo(MRVL_DEV_PTR device)
{
	MRVL_APHY_U16 modelNum;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	/* check reg access */
	status = checkRegAccess(device);

	if (MRVL_APHY_STATUS_OK == status)
	{
		/* readback org id */
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_ID_DEVICE, MRVL_APHY_ID_REG, &modelNum);
		device->revNum = (MRVL_APHY_U8) (modelNum & 0x000FU);
		modelNum = (modelNum & 0x03F0U) >> 4;
		if (MRVL_APHY_ID == modelNum)
		{
			/* readback phy id */
			mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_APHY_ID_EXT_DEVICE, MRVL_APHY_ID_EXT_REG, &modelNum);
			device->modelNum = (modelNum & 0xFFF0U) >> 4;
			device->packageNum = modelNum & 0xFU;
			if (device->modelNum != MRVL_Q222X_PRODUCT_ID)
			{
				status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
			}
		}
		else
		{
			status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
		}
	}

	return status;
}

/******************************************************************************
 *      General Status
 ******************************************************************************/

/**
 * @brief Check current master/slave operation mode
 *
 * @param[in]	device   PHY pointer
 * @param[out]	isMaster True: MASTER operation mode; False: SLAVE operation mode
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PHY_STATUS
 */
MRVL_APHY_STATUS q222x_checkIsMaster(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isMaster)
{
	MRVL_APHY_U16 regVal;
	MRVL_APHY_BOOL angEnable;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	status = q222x_getAnegEnabled( device, &angEnable);
	if (angEnable == MRVL_APHY_TRUE)
	{
		/* read 7.0x8001 in auto-neg mode */
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, 7, 0x8001, &regVal);
		/* check bit 14 */
		regVal = (regVal >> 14) & 0x0001U;
	}
	else
	{
		/* read 1.0x0834 in forced speed mode */
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, 1, 0x0834, &regVal);
		/* check bit 14 */
		regVal = (regVal >> 14) & 0x0001U;
	}

	if (regVal == 1U)
	{
		*isMaster = MRVL_APHY_TRUE;
	}
	else
	{
		*isMaster = MRVL_APHY_FALSE;
	}
	return status;
}

/**
 * @brief Check if support SGMII per package number
 *
 * @param[in]	device       PHY pointer
 * @param[out]	supportSGMII True: PHY uses SGMII interface; False: PHY use RGMII interface
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PHY_STATUS
 */
MRVL_APHY_STATUS q222x_checkSupportSGMII(MRVL_DEV_PTR device, MRVL_APHY_BOOL* supportSGMII)
{
	/* packageNum is used as the SGMII indicator */
	switch (device->packageNum)
	{
	case MRVL_Q222X_PACKAGE_ID_Q2220M:
	case MRVL_Q222X_PACKAGE_ID_Q1210M:
	case MRVL_Q222X_PACKAGE_ID_Q2220:
	case MRVL_Q222X_PACKAGE_ID_Q1210:
		/* above packageNums are RGMII */
		*supportSGMII = MRVL_APHY_FALSE;
		break;
	default:
		/* rest packageNums are SGMII */
		*supportSGMII = MRVL_APHY_TRUE;
		break;
	}
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get link status including PCS (local/remote) and local PMA
 *
 * @param[in]	device   PHY pointer
 * @param[out]	isLinkup True: Link is up; False: Link is down
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PHY_STATUS
 */
MRVL_APHY_STATUS q222x_checkLink(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isLinkup)
{
	MRVL_APHY_SPEED speed;
	MRVL_APHY_STATUS status;
	status = q222x_getSpeed(device, &speed);
	if (MRVL_APHY_SPEED_1000 == speed)
	{
		/* 1000 speed link detection */
		*isLinkup = checkLinkGe(device);
	}
	else
	{
		/* 100 speed link detection */
		*isLinkup = checkLinkFe(device);
	}

	return status;
}

/**
 * @brief Get real time PMA link status
 *
 * @param[in]	device   PHY pointer
 * @param[out]	isLinkup True: Link is up; False: Link is down
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PHY_STATUS
 */
MRVL_APHY_STATUS q222x_getRealTimeLinkStatus(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isLinkup)
{
	MRVL_APHY_U16 regVal1 = 0;
	MRVL_APHY_SPEED speed;
	MRVL_APHY_STATUS status;
	status = q222x_getSpeed(device, &speed);
	if (MRVL_APHY_SPEED_1000 == speed)
	{
		/* 1000 speed real time link is a latched link */
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, 3, 0x0901, &regVal1);
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, 3, 0x0901, &regVal1);    /* Read twice: register latches low */
	}
	else
	{
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, 3, 0x810A, &regVal1);
	}
	*isLinkup = (0x0 != (regVal1 & 0x0004U)) ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
	return status;
}

/**
 * @brief Get latched link status.
 * Can use this function to find out if link was down since last time checked
 *
 * @param[in]	device   PHY pointer
 * @param[out]	isLinkup True: No link-down occurred; False: latched link was down
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PHY_STATUS
 */
MRVL_APHY_STATUS q222x_getLatchedLinkStatus(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isLinkup)
{
	MRVL_APHY_U16 regVal;
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, 1, 0x0901, &regVal);
	*isLinkup = (0x0U != (regVal & 0x0001U)) ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Check if Auto-Negotiation is enabled
 *
 * @param[in]	device   PHY pointer
 * @param[out]	isEnable True: Auto-Negotiation is enabled; False: Auto-Negotiation is disabled
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PHY_STATUS
 */
MRVL_APHY_STATUS q222x_getAnegEnabled(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isEnable)
{
	MRVL_APHY_U16 regVal;
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, 7, 0x0200, &regVal);
	*isEnable = (0x0 != (regVal & MRVL_Q222X_AN_ENABLE)) ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Check if Auto-Negotiation completed successfully
 *
 * @param[in]	device PHY pointer
 * @param[out]	isDone True: Auto-Negotiation is completed; False: Auto-Negotiation is not completed.
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PHY_STATUS
 */
MRVL_APHY_STATUS q222x_getAnegDone(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isDone)
{
	MRVL_APHY_U16 regVal;
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, 7, 0x0201, &regVal);
	*isDone = (0x0 != (regVal & MRVL_Q222X_AN_COMPLETE)) ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get current data rate negotiated or set directly
 *
 * @param[in]	device PHY pointer
 * @param[out]	speed  MRVL_APHY_SPEED: MRVL_APHY_SPEED_1000 or MRVL_APHY_SPEED_100
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PHY_STATUS
 */
MRVL_APHY_STATUS q222x_getSpeed(MRVL_DEV_PTR device, MRVL_APHY_SPEED* speed)
{
	MRVL_APHY_U16 regVal = 0;
	MRVL_APHY_BOOL isEnable;
	MRVL_APHY_STATUS status;
	status = q222x_getAnegEnabled(device, &isEnable);
	if (isEnable == MRVL_APHY_TRUE)
	{
		/* read 7.0x801a in auto-neg mode */
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, 7, 0x801a, &regVal);
		regVal = (regVal & 0x4000U) >> 14;
	}
	else
	{
		/* read 1.0x0834 in forced speed mode */
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, 1, 0x0834, &regVal);
		regVal &= 0x0001U;
	}
	/* only two speeds available */
	if (0 == regVal)
	{
		*speed = MRVL_APHY_SPEED_100;
	}
	else
	{
		*speed = MRVL_APHY_SPEED_1000;
	}

	return status;
}

/******************************************************************************
 *      Mode and Speed Configuration
 ******************************************************************************/

/**
 * @brief Initialize for 100 BASE-T1
 *
 * @param[in]	device PHY pointer
 * @param[in]	opMode MRVL_APHY_OPERATION_MODE: MASTER or SLAVE Operation mode
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PHY_MODE
 */
MRVL_APHY_STATUS q222x_initQ222XFe(MRVL_DEV_PTR device, MRVL_APHY_OPERATION_MODE opMode)
{
	MRVL_APHY_U16 regVal;
	MRVL_APHY_BOOL supportSGMII = MRVL_APHY_TRUE;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;

	/* check if reg access is ok */
	status = checkRegAccess(device);
	/* if reg access is ok, start to initialize device */
	if (status == MRVL_APHY_STATUS_OK)
	{
		status = q222x_checkSupportSGMII(device, &supportSGMII);
		/* write t1 init code */
		applyFeInit(device, MRVL_APHY_TRUE);

		if (supportSGMII == MRVL_APHY_TRUE)
		{
			/* write SGMII code */
			applySGMIIInit(device);
		}
		/* set speed and mode */
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, 1, 0x0834, &regVal);
		regVal &= 0xFFF0U;
		if (MRVL_APHY_OP_MASTER == opMode)
		{
			regVal |= 0x4000U;
		}
		else
		{
			regVal &= 0xBFFFU;
		}
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 1, 0x0834, regVal);
		/* add software reset to finish */
		softResetFe(device);
	}

	return status;
}

/**
 * @brief Initialize for 1000 BASE-T1
 *
 * @param[in]	device PHY pointer
 * @param[in]	opMode MRVL_APHY_OPERATION_MODE: MASTER or SLAVE Operation mode
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PHY_MODE
 */
MRVL_APHY_STATUS q222x_initQ222XGe(MRVL_DEV_PTR device, MRVL_APHY_OPERATION_MODE opMode)
{
	MRVL_APHY_U16 regVal;
	MRVL_APHY_BOOL supportSGMII = MRVL_APHY_TRUE;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	/* check if reg access is ok */
	status = checkRegAccess(device);

	/* if reg access is ok, start to initialize device */
	if (status == MRVL_APHY_STATUS_OK)
	{
		status = q222x_checkSupportSGMII(device, &supportSGMII);
		/* write t1 init code */
		applyGeInit(device, MRVL_APHY_TRUE);

		if (supportSGMII == MRVL_APHY_TRUE)
		{
			/* write SGMII code */
			applySGMIIInit(device);
		}
		/* write speed and mode */
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, 1, 0x0834, &regVal);
		regVal = (regVal & 0xFFF0U) | 0x0001U;
		if (MRVL_APHY_OP_MASTER == opMode)
		{
			regVal |= 0x4000U;
		}
		else
		{
			regVal &= 0xBFFFU;
		}
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 1, 0x0834, regVal);
		/* add software reset to finish */
		softResetGe(device);
	}

	return status;
}

/**
 * @brief Enable Auto-Negotiation
 *
 * @param[in]	device PHY pointer
 * @param[in]	opMode MRVL_APHY_OPERATION_MODE: MASTER or SLAVE Operation mode
 * @param[in]	flags  Can be set to these 3 value: MRVL_Q222X_AN_FE_ABILITY, MRVL_Q222X_AN_GE_ABILITY or
 * MRVL_Q222X_AN_FE_ABILITY | MRVL_Q222X_AN_GE_ABILITY
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PHY_MODE
 */
MRVL_APHY_STATUS q222x_setAneg(MRVL_DEV_PTR device, MRVL_APHY_OPERATION_MODE opMode, MRVL_APHY_U16 flags)
{
	MRVL_APHY_U16 regVal = 0;
	MRVL_APHY_BOOL supportSGMII = MRVL_APHY_TRUE;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	/* check reg access is ok */
	status = checkRegAccess(device);

	if (status == MRVL_APHY_STATUS_OK)
	{
		/* validate speed selection and write init code */
		status = applyAnegInit(device, flags);
	}
	/* if reg access is ok and t1 init codes are applied, start to initialize SGMII and rest */
	if (status == MRVL_APHY_STATUS_OK)
	{
		status = q222x_checkSupportSGMII(device, &supportSGMII);
		if (supportSGMII == MRVL_APHY_TRUE)
		{
			/* write SGMII code */
			applySGMIIInit(device);
		}
		/* prefer master if needed */
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, 7, 0x0203, &regVal);
		if (MRVL_APHY_OP_MASTER == opMode)
		{
			regVal |= 0x10U;
		}
		else
		{
			regVal &= 0xFFEFU;
		}
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 7, 0x0203, regVal);
		/* enable auto-neg */
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 7, 0x0200, MRVL_Q222X_AN_ENABLE);
		/* add software reset to finish */
		softResetGe(device);
	}
	return status;
}

/**
 * @brief Software Reset
 *
 * @param[in]	device PHY pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PHY_MODE
 */
MRVL_APHY_STATUS q222x_softReset(MRVL_DEV_PTR device)
{
	MRVL_APHY_SPEED speed;
	MRVL_APHY_STATUS status;
	status = q222x_getSpeed(device, &speed);
	if (MRVL_APHY_SPEED_1000 == speed)
	{
		softResetGe(device);
	}
	else
	{
		softResetFe(device);
	}
	return status;
}

/******************************************************************************
 *      Advanced Feature
 ******************************************************************************/

/**
 * @brief Get Signal Quality Indicator (SQI) with 8 levels.
 * Level 0-7, 7 indicates best quality. 0 indicates linkdown.
 *
 * @param[in]	device PHY pointer
 * @param[out]	sqi    Signal Quality Indicator (range 0-7)
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PHY_ADV_FEAT
 */
MRVL_APHY_STATUS q222x_getSQIReading_8Level(MRVL_DEV_PTR device, MRVL_APHY_U16* sqi)
{
	MRVL_APHY_U16 regVal = 0;
	MRVL_APHY_SPEED speed;
	MRVL_APHY_STATUS status;
	status = q222x_getSpeed(device, &speed);
	if (MRVL_APHY_SPEED_100 == speed)
	{
		/* read 3.0x8230 in 100 speed */
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, 3, 0x8230, &regVal);
		*sqi = (regVal & 0xE000U) >> 13;
	}
	else
	{
		/* read 3.0xFCD8 in 1000 speed */
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, 3, 0xFCD8, &regVal);
		*sqi = regVal & 0x7U;
	}
	return status;
}

/**
 * @brief Get cable diagnostic with harness-status and distance-to-fault detection
 *
 * @param[in]	device          PHY pointer
 * @param[out]	harnessStatus   MRVL_APHY_HARNESS_STATUS to reflect harness status
 * @param[out]	distanceToFault distance to main fault in meters (range 0-31m)
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PHY_ADV_FEAT
 */
MRVL_APHY_STATUS q222x_getCableDiagnostic(MRVL_DEV_PTR device, MRVL_APHY_HARNESS_STATUS* harnessStatus, MRVL_APHY_U16* distanceToFault)
{
	MRVL_APHY_U16 regVal= 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	/* adjust TDR settings */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 0x3, 0xfede, 0x0058);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 0x3, 0xfeda, 0x00eb);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 0x3, 0xfed9, 0x010e);
	/* trigger TDR */
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 0x3, 0xfeca, 0x0d90);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 0x3, 0xfedd, 0x0002);
	/* wait */
	mrvl_aphy_wait(device, 500);
	/* check result */
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, 3, 0xfedd, &regVal);
	if((regVal & 0x3U) != 1)
	{
		/* cannot finish TDR, return error */
		status = MRVL_APHY_STATUS_ERROR_TIMEOUT;
		*harnessStatus = MRVL_APHY_HARNESS_UNKNOWN;
		*distanceToFault = 0;
	}
	else
	{
		/* TDR is completed, return error */
		*distanceToFault = (regVal & 0xff00U) >> 8;
		regVal = (regVal & 0x00f0U) >> 4;
		switch (regVal)
		{
		case 0xe:
			*harnessStatus = MRVL_APHY_HARNESS_OPEN;
			break;
		case 0x3:
			*harnessStatus = MRVL_APHY_HARNESS_SHORT;
			break;
		case 0x7:
			*harnessStatus = MRVL_APHY_HARNESS_OK;
			*distanceToFault = 0;
			break;
		case 0x5:
			*harnessStatus = MRVL_APHY_HARNESS_NOISE;
			*distanceToFault = 0;
			break;
		default:
			/* unknown result, return error */
			*harnessStatus = MRVL_APHY_HARNESS_UNKNOWN;
			*distanceToFault = 0;
			status = MRVL_APHY_STATUS_UNKNOW;
			break;
		}
	}
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 0x3, 0xfeca, 0x1d90);
	return status;

}
