/**
 * @file MRVL_Q222X_TC10.h
 * @brief Q222X TC10 API Header File
 * DUT TC10 configuration and status checking
  *
 * @par Copyright and Version
 * See MRVL_Q222X_Copyright_and_Version.h
 */

#ifndef MRVL_Q222X_TC10_H
#define MRVL_Q222X_TC10_H

#include "MRVL_Q222X_TC10Types.h"

/******************************************************************************
 *     TC10 Configuration
 ******************************************************************************/
/** @defgroup TC10_CNFG TC10 Configuration */

EXPORT_FUNC MRVL_APHY_STATUS q222x_configTC10(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEnable);

EXPORT_FUNC MRVL_APHY_STATUS q222x_configTC10PowerRemoval(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEnable);

EXPORT_FUNC MRVL_APHY_STATUS q222x_configTC10SleepRequestAbort(MRVL_DEV_PTR device, MRVL_APHY_BOOL isAbort);

EXPORT_FUNC MRVL_APHY_STATUS q222x_startTC10SleepFlow(MRVL_DEV_PTR device);

EXPORT_FUNC MRVL_APHY_STATUS q222x_assertTC10WakeRequest(MRVL_DEV_PTR device);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getTC10Status(MRVL_DEV_PTR device, MRVL_Q222X_TC10_STATUS* status);

#endif  /* MRVL_Q222X_TC10_H */
