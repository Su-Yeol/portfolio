// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_cb_api.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    Functions to configure CB entries
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#include "reg_hal.h"
#include "fp_library.h"		// brings in linux/string.h
#include <fp_macros.h>
#include <fp_port.h>
#include "fp_cb_api.h"
#include "global_address_map_fpga.h"

typedef struct
{
	uint32a curr_base_diff;
	uint32a latent_error_diff;
	uint32a latent_error_paths;
	uint32a latent_error_period;
	uint32a latent_reset_period;
	uint32a latent_error_reset_count;
	uint32a latent_error_reset_secs;
	uint32a latent_error_check_secs;
	uint32a latent_error_occured;
} fp_latent_error_t;

fp_latent_error_t latent_error_info[CB_TABLE_SIZE];

int32a __fp_cb_get_entry(uint8 mac[], uint32a vlan_id, uint8 id_type, fp_cb_entry_t *cb, uint32a table_num);

/* Initialize the CB table with 0 data */
static void __init_cb_table(uint32a table_num)
{
	int32a cmd = 0;
	int32a i = 0;

    TableWrite(CB_TABLE_HOST_MAC1_ADDR_REG, 0x0, table_num);
    TableWrite(CB_TABLE_HOST_MAC2_ADDR_REG, 0x0, table_num);
    TableWrite(CB_TABLE_HOST_MAC3_ADDR_REG, 0x0, table_num);
    TableWrite(CB_TABLE_HOST_MAC4_ADDR_REG, 0x0, table_num);
    TableWrite(CB_TABLE_HOST_MAC5_ADDR_REG, 0x0, table_num);
    TableWrite(CB_TABLE_HOST_ENTRY_REG, 0x0, table_num);
    TableWrite(CB_TABLE_HOST_DIRECT_REG, 0x0, table_num);
    TableWrite(CB_TABLE_HOST_ENTRY1_REG, 0x0, table_num);
    TableWrite(CB_TABLE_HOST_ENTRY2_REG, 0x0, table_num);
    TableWrite(CB_TABLE_HOST_ENTRY3_REG, 0x0, table_num);
    TableWrite(CB_TABLE_HOST_ENTRY4_REG, 0x0, table_num);
    TableWrite(CB_TABLE_HOST_ENTRY5_REG, 0x0, table_num);

    for(i = 0; i < CB_TABLE_SIZE; i++)
    {
        cmd  = (i << 16) + CMD_MEM_WRITE;
		IssueCommandTable_CS(CB_TABLE_HOST_CMD_REG,
					cmd,
					CB_TABLE_HOST_STATUS_REG,
					CB_ENTRY_STATUS_CMD_DONE,
					CLR_STATUS_REG,
					table_num);
    }
}

static void init_cb_table(uint32a table_num)
{
	__init_cb_table(table_num);
}
/* CB function to issue INIT command and chain the collision space */

static int32a __fp_cb_table_init(uint32a table_num)
{
	uint32a cmd = CMD_INIT;
	uint32a cmd_done = 0;
	uint32a index = 0;
	uint32a mac_table_addr = 0;
	uint32a col_ptr = 0;
	uint32a i = 0;

	/* Initialize all entries with 0 data */
	init_cb_table(table_num);
	cmd_done = IssueCommandTable_CS(CB_TABLE_HOST_CMD_REG,
					cmd,
					CB_TABLE_HOST_STATUS_REG,
					CB_ENTRY_STATUS_CMD_DONE,
					CB_ENTRY_STATUS_CLR,
					table_num);
/*
	printk("%s -- cmd_done = %x done = %s, init done = %s\n",
		__FUNCTION__, cmd_done,
		(cmd_done & CB_ENTRY_STATUS_CMD_DONE) ? "TRUE" : "FALSE",
		(cmd_done & STATUS_INIT_DONE)   ? "TRUE" : "FALSE");
*/
	if (cmd_done & CB_ENTRY_STATUS_CMD_DONE) {
		if(cmd_done & STATUS_INIT_DONE) {
			/* initialize mac addresses */
			TableWrite(CB_TABLE_HOST_MAC1_ADDR_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_MAC2_ADDR_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_MAC3_ADDR_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_MAC4_ADDR_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_MAC5_ADDR_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_ENTRY_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_DIRECT_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_ENTRY1_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_ENTRY2_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_ENTRY3_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_ENTRY4_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_ENTRY5_REG, 0x0, table_num);
			/* chain the collision space */
			for (i = 0; i < CB_TABLE_COLL_ENTRIES; i++) {
				/* 32bit: 3bit(not used) + 4validbits + 16colptr + 9 bits */
				col_ptr = (0x40041 + i) << 9;
				TableWrite(CB_TABLE_HOST_ENTRY1_REG, col_ptr, table_num);
				index = CB_TABLE_HASH_ENTRIES + i;
				mac_table_addr = (index << 16) + CMD_MEM_WRITE;
				IssueCommandTable_CS(CB_TABLE_HOST_CMD_REG,
							mac_table_addr,
							CB_TABLE_HOST_STATUS_REG,
							CB_ENTRY_STATUS_CMD_DONE,
							CLR_STATUS_REG,
							table_num);
			} /*End of for loop collision space*/
			/* Intialize Free List Head Ptr */
			TableWrite(CB_TABLE_FREELIST_PTR_HEAD, CB_TABLE_INIT_HEAD_PTR, table_num);
			/* Initialize Free List Ptr */
			TableWrite(CB_TABLE_FREELIST_PTR_TAIL, CB_TABLE_INIT_TAIL_PTR, table_num);
			/* Initialize No of entries */
			TableWrite(CB_TABLE_FREELIST_ENTRIES_ADDR, CB_TABLE_COLL_ENTRIES, table_num);
			/* Clear Status Reg */
			TableWrite(CB_TABLE_HOST_STATUS_REG, CLR_STATUS_REG, table_num);
			TPA_D("CB TABLE HASH INIT DONE\r\n");
			return 0;	/* init done */
		}
		else
		{
			TPA_E("CMD_INIT - failed to init\n");
			return -1;
		}
	}
	TPA_E("CMD_INIT command failed\n");
	return -2;
}

int32a fp_cb_table_init()
{
	if(__fp_cb_table_init(1) < 0)
		return -1;
	return __fp_cb_table_init(3);
}

/*!
 Add CB entry

 @param            cb  cb entry to be added
 @return status code   0=success, -1=failure
 **/
static int32a __fp_cb_add_entry(fp_cb_entry_t *cb, uint8 alloc_rec_ptr, uint32a table_num)
{
#if 0
	uint32a mac1;
	uint32a mac2;
	uint32a entry1;
	uint32a entry2;
	uint32a entry3;
	uint32a entry4;
	uint32a entry5;
	uint32a entry6;
	uint32a entry7;
	uint32a cmd_done;
	uint32a cmd;
	uint32a field_valids = BIT_SET_MAC_2F_MACTBL;
	uint16 seq_gen_recovery_ptr = cb->seq_gen_recovery_ptr;

	//reverse_mac(&cb->mac[0]);
	uint32a *entry = (uint32a *)cb->mac;
	mac1 = entry[0];
	mac2 = entry[1] & 0xFFFF;
	mac2 |= (cb->vlan << 16);

	if (!__fp_cb_get_entry(cb->mac, cb->vlan, cb->id_type, cb, table_num))
	{
		printk("CB entry already exists in the CB Table\n");
		return 0;
	}

	/* set mac addr */
	TableWrite(CB_TABLE_HOST_MAC1_ADDR_REG, htonl(mac1), table_num);

	/* set mac addr and vlan */
	TableWrite(CB_TABLE_HOST_MAC2_ADDR_REG, ((mac2 & 0xFFFF0000) | ntohs(mac2)), table_num);

	entry1 = cb->fwd_port_list;
	entry1 |= (cb->id_type << 20);
	entry1 |= (cb->enable_vtag_removal << 22);
	entry1 |= (cb->enable_rtag_removal << 23);
	entry1 |= (cb->enable_recovery << 24);
	entry1 |= (cb->enable_seq_gen << 25);
	entry1 |= (cb->enable_mapped_vlan << 26);
	entry1 |= (cb->enable_vlan_insertion << 27);
	entry1 |= ((cb->recovery_enable_bits & 0x3) << 30);
	/* set seq number and collision ptr */
	TableWrite(CB_TABLE_HOST_ENTRY_REG, entry1, table_num);

	entry2 = cb->recovery_enable_bits >> 2;
	entry2 |= (cb->vtag_removal_port_list << 18);
	/* set forward port list and field valids */
	TableWrite(CB_TABLE_HOST_DIRECT_REG, entry2, table_num);

	entry3 = (cb->vtag_removal_port_list >> 14);
	entry3 |= (cb->rtag_removal_port_list << 6);
	entry3 |= ((cb->port_drop_list & 0x3F) << 26);
	/* set recovery enable bits and instance config */
	TableWrite(CB_TABLE_HOST_ENTRY1_REG, entry3, table_num);

	entry4 = (cb->port_drop_list >> 6);
	entry4 |= (cb->mapped_vlan << 14);
	entry4 |= (cb->pcp << 26);
	/* set individual recovery address */
	TableWrite(CB_TABLE_HOST_ENTRY2_REG, entry4, table_num);
	if( alloc_rec_ptr ) {
		cb->seq_gen_recovery_ptr = fp_alloc_seq_recovery_entry();
		fp_fill_seq_recovery_entry(cb);
	} else {
		cb->seq_gen_recovery_ptr = seq_gen_recovery_ptr;
	}
	entry5 = cb->seq_gen_recovery_ptr;
	/* set sequence recovery address */
	TableWrite(CB_TABLE_HOST_ENTRY3_REG, entry5, table_num);
	TableWrite(CB_TABLE_HOST_ENTRY4_REG, entry6, table_num);
	TableWrite(CB_TABLE_HOST_ENTRY5_REG, entry7, table_num);
	/* Submit ADD command */
	cmd = (CMD_ADD | field_valids);
	cmd_done = IssueCommandTable_CS(CB_TABLE_HOST_CMD_REG,
					cmd,
					CB_TABLE_HOST_STATUS_REG,
					CB_ENTRY_STATUS_CMD_DONE,
					CB_ENTRY_STATUS_CLR,
					table_num);
/*
	printk("%s -- cmd_done = %x done = %s, added = %s\n",
		__FUNCTION__, cmd_done,
		(cmd_done & CB_ENTRY_STATUS_CMD_DONE) ? "TRUE" : "FALSE",
		(cmd_done & STATUS_ENTRY_ADDED)       ? "TRUE" : "FALSE");
*/
	if (cmd_done & CB_ENTRY_STATUS_CMD_DONE) {
		if(cmd_done & STATUS_ENTRY_ADDED) {
			return 0;	/* entry added */
		} else {
			pr_err("CMD_ADD - CB Entry not added\n");
			return -1;
		}
	} else {
		pr_err("CMD_ADD failed\n");
		return -2;
	}
#else
	return -1;
#endif
}

int32a fp_cb_add_entry(fp_cb_entry_t *cb)
{
	if(__fp_cb_add_entry(cb, 1, 1) < 0)
		return -1;
	return __fp_cb_add_entry(cb, 0, 3);
}
/*!
 Delete CB entry

 @param           mac  mac address of the entry
 @param       vlan_id  vlan id of the entry
 @param   id_type      identification type
 @return status code   0=success, -1=failure
 **/
static int32a __fp_cb_del_entry (	uint8 mac[],
			uint32a vlan_id,
			uint8 id_type,
			uint8 free_rec_entry,
			uint32a table_num)
{
#if 0
	uint32a cmd_done;
	uint32a cmd;
	uint32a mac1;
	uint32a mac2;
	uint32a field_valids = BIT_SET_MAC_2F_MACTBL;
	uint32a seq_gen_recovery_ptr;
	fp_cb_entry_t cb;
	int32a ret = 0;

	//reverse_mac(&cb->mac[0]);
	uint32a *entry = (uint32a *)mac;
	mac1 = entry[0];
	mac2 = entry[1] & 0xFFFF;
	mac2 |= (vlan_id << 16);

	ret = __fp_cb_get_entry(mac, vlan_id, id_type, &cb, table_num);
	if(!ret)
	{
		seq_gen_recovery_ptr = cb.seq_gen_recovery_ptr;
	} else {
		pr_info("CB entry is not there \n");
		return ret;
	}
	/* set mac addr */
	TableWrite(CB_TABLE_HOST_MAC1_ADDR_REG, htonl(mac1), table_num);
	/* set mac addr and vlan */
	TableWrite(CB_TABLE_HOST_MAC2_ADDR_REG, ((mac2 & 0xFFFF0000) | ntohs(mac2)), table_num);
	/* Submit DEL command */
	cmd =  (CMD_DEL | field_valids);
	cmd_done = IssueCommandTable_CS(CB_TABLE_HOST_CMD_REG,
					cmd,
					CB_TABLE_HOST_STATUS_REG,
					CB_ENTRY_STATUS_CMD_DONE,
					CB_ENTRY_STATUS_CLR,
					table_num);
/*
	printk("%s -- cmd_done = %x done = %s, not found = %s\n",
		__FUNCTION__, cmd_done,
		(cmd_done & CB_ENTRY_STATUS_CMD_DONE) ? "TRUE" : "FALSE",
		(cmd_done & STATUS_ENTRY_NOT_FOUND)   ? "TRUE" : "FALSE");
*/
	if (cmd_done & CB_ENTRY_STATUS_CMD_DONE) {
		/* if STATUS_ENTRY_NOT_FOUND = 1 CMD_DEL failed */
		if(cmd_done & STATUS_ENTRY_NOT_FOUND) {
			pr_err("Entry not deleted \n");
			return -1;
		} else {
			return 0;
		}
	} else {
		pr_err("CMD_DEL failed\n");
		return -2;
	}
	if(free_rec_entry) {
		fp_free_seq_recovery_entry(seq_gen_recovery_ptr);
	}
#endif
	return 0;
}

int32a fp_cb_del_entry ( 	uint8 mac[],
			uint32a vlan_id,
			uint8 id_type)
{
	if(__fp_cb_del_entry(mac, vlan_id, id_type, 0, 1) < 0)
		return -1;
	return __fp_cb_del_entry(mac, vlan_id, id_type, 1, 3);
}

/*!
 Get CB entry

 @param           mac     mac address of the entry
 @param       vlan_id     vlan id of the entry
 @param   id_type      identification type
 @param             cb    cb entry to be read
 @return  status code:    0=success, -1=failure
 */
int32a __fp_cb_get_entry(	uint8 mac[],
			uint32a vlan_id,
			uint8 id_type,
			fp_cb_entry_t *cb,
			uint32a table_num)
{
#if 0
	uint32a cmd;
	uint32a mac1;
	uint32a mac2;
	uint32a entry1 = 0;
	uint32a entry2 = 0;
	uint32a entry3 = 0;
	uint32a entry4 = 0;
	uint32a entry5 = 0;
	uint32a entry6 = 0;
	uint32a entry7 = 0;
	uint32a cmd_done;
	uint32a  field_valids = BIT_SET_MAC_2F_MACTBL;

	//reverse_mac(&cb->mac[0]);
	uint32a *entry = (uint32a *)mac;
	mac1 = entry[0];
	mac2 = entry[1] & 0xFFFF;
	mac2 |= (vlan_id << 16);
	/* set mac addr */
	TableWrite(CB_TABLE_HOST_MAC1_ADDR_REG, htonl(mac1), table_num);

	/* set mac addr and vlan */
	TableWrite(CB_TABLE_HOST_MAC2_ADDR_REG, ((mac2 & 0xFFFF0000) | ntohs(mac2)), table_num);
	/* Submit ADD command */
	//cmd = CB_ENTRY_CMD_ADD;
	//cmd = 0x302;
	cmd = (CMD_SEARCH | field_valids);
	cmd_done = IssueCommandTable_CS(CB_TABLE_HOST_CMD_REG,
					cmd,
					CB_TABLE_HOST_STATUS_REG,
					CB_ENTRY_STATUS_CMD_DONE,
					CB_ENTRY_STATUS_CLR,
					table_num);
/*
	printk("%s -- cmd_done = %x done = %s, found = %s, match = %s\n",
		__FUNCTION__, cmd_done,
		(cmd_done & CB_ENTRY_STATUS_CMD_DONE)    ? "TRUE" : "FALSE",
		(cmd_done & STATUS_ENTRY_NOT_FOUND) ? "NOT FOUND" : "FOUND",
		(cmd_done & STATUS_ENTRY_MATCH) ? "MATCH" : "NO MATCH");
*/
	if (cmd_done & CB_ENTRY_STATUS_CMD_DONE) {
		if(cmd_done & STATUS_ENTRY_NOT_FOUND) {
			pr_err("CMD_SEARCH - Entry not found\n");
			return -1;
/* According to the TRM the STATUS_ENTRY_MATCH flag should get set, but it never does
 * So the check is commented for the time being
 */
		} else if (cmd_done & STATUS_ENTRY_MATCH) {
			cb->valid = 1;
			entry1 = TableRead(CB_TABLE_HOST_ENTRY_REG,  table_num);
			entry2 = TableRead(CB_TABLE_HOST_DIRECT_REG, table_num);
			entry3 = TableRead(CB_TABLE_HOST_ENTRY1_REG, table_num);
			entry4 = TableRead(CB_TABLE_HOST_ENTRY2_REG, table_num);
			entry5 = TableRead(CB_TABLE_HOST_ENTRY3_REG, table_num);
			entry6 = TableRead(CB_TABLE_HOST_ENTRY4_REG, table_num);
			entry7 = TableRead(CB_TABLE_HOST_ENTRY5_REG, table_num);

			cb->fwd_port_list = entry1 & 0xFFFFF;
			cb->id_type = ((entry1 >> 20) & 0x3);
			cb->enable_vtag_removal = ((entry1 >> 22) & 0x1);
			cb->enable_rtag_removal = ((entry1 >> 23) & 0x1);
			cb->enable_recovery = ((entry1 >> 24) & 0x1);
			cb->enable_seq_gen = ((entry1 >> 25) & 0x1);
			cb->enable_mapped_vlan = ((entry1 >> 26) & 0x1);
			cb->enable_vlan_insertion = ((entry1 >> 27) & 0x1);
			cb->recovery_enable_bits = ((entry1 >> 30) & 0x3);
			cb->recovery_enable_bits |= ((entry2 << 2) & 0xFFFFF);
			cb->vtag_removal_port_list = ((entry2 >> 18) | ((entry3 << 14) & 0xFFFFF));
			cb->rtag_removal_port_list = ((entry3 >> 6) & 0xFFFFF);
			cb->port_drop_list = ((entry3 >> 26) | ((entry4 << 6) & 0xFFFFF));
			cb->mapped_vlan = ((entry4 >> 14) & 0xFFF);
			cb->pcp = ((entry4 >> 26) & 0xF);
			cb->seq_gen_recovery_ptr = entry5;
			fp_get_seq_recovery_entry(cb->seq_gen_recovery_ptr, &cb->recovery_data[0]);
			return 0;
		} else {
			pr_err("entry found but not a match\n");
			return -3;
		}
	} else {
		pr_err("CMD_SEARCH failed\n");
		return -2;
	}
#endif
	return -1;
}

int32a fp_cb_get_entry(	uint8 mac[],
			uint32a vlan_id,
			uint8 id_type,
			fp_cb_entry_t *cb)
{
	return __fp_cb_get_entry(mac, vlan_id, id_type, cb, 1);
}

/* Function to retrieve the cb table entries by index */
static int32a __fp_cb_get_entry_by_index(uint32a index, fp_cb_entry_t *cb, uint32a table_num)
{
#if 0
	uint32a cmd;
	uint32a mac1 = 0;
	uint32a mac2 = 0;
	uint32a mac3 = 0;
	uint32a mac4 = 0;
	uint32a mac5 = 0;
	uint32a entry1 = 0;
	uint32a entry2 = 0;
	uint32a entry3 = 0;
	uint32a entry4 = 0;
	uint32a entry5 = 0;
//	uint32a entry6 = 0;
//	uint32a entry7 = 0;
	uint32a hash_valid = 0;

	TableWrite(CB_TABLE_HOST_MAC1_ADDR_REG, 0, table_num);
	TableWrite(CB_TABLE_HOST_MAC2_ADDR_REG, 0, table_num);
	TableWrite(CB_TABLE_HOST_MAC3_ADDR_REG, 0, table_num);
	TableWrite(CB_TABLE_HOST_MAC4_ADDR_REG, 0, table_num);
	TableWrite(CB_TABLE_HOST_MAC5_ADDR_REG, 0, table_num);
	TableWrite(CB_TABLE_HOST_ENTRY_REG, 0, table_num);
	TableWrite(CB_TABLE_HOST_DIRECT_REG, 0, table_num);
	TableWrite(CB_TABLE_HOST_ENTRY1_REG, 0, table_num);
	TableWrite(CB_TABLE_HOST_ENTRY2_REG, 0, table_num);
	TableWrite(CB_TABLE_HOST_ENTRY3_REG, 0, table_num);
	TableWrite(CB_TABLE_HOST_ENTRY4_REG, 0, table_num);
	TableWrite(CB_TABLE_HOST_ENTRY5_REG, 0, table_num);

	cmd = CMD_MEM_READ | (index << 16);
	IssueCommandTable_CS(	CB_TABLE_HOST_CMD_REG,
				cmd,
				CB_TABLE_HOST_STATUS_REG,
				CB_ENTRY_STATUS_CMD_DONE,
				CB_ENTRY_STATUS_CLR,
				table_num);
	mac1   = TableRead(CB_TABLE_HOST_MAC1_ADDR_REG, table_num);
	mac2   = TableRead(CB_TABLE_HOST_MAC2_ADDR_REG, table_num);
	mac3   = TableRead(CB_TABLE_HOST_MAC3_ADDR_REG, table_num);
	mac4   = TableRead(CB_TABLE_HOST_MAC4_ADDR_REG, table_num);
	mac5   = TableRead(CB_TABLE_HOST_MAC5_ADDR_REG, table_num);
	entry1 = TableRead(CB_TABLE_HOST_ENTRY_REG, table_num);
	entry2 = TableRead(CB_TABLE_HOST_DIRECT_REG, table_num);
	entry3 = TableRead(CB_TABLE_HOST_ENTRY1_REG, table_num);
	entry4 = TableRead(CB_TABLE_HOST_ENTRY2_REG, table_num);
	entry5 = TableRead(CB_TABLE_HOST_ENTRY3_REG, table_num);


	hash_valid = ((entry3 & 0x1F) << 4) || ((entry2 >> 28) & 0xF);
	if (mac2 != 0) {
	cb->valid = 1;
	} else {
		cb->valid = 0;
		return 0;
	}
	mac1 = htonl(mac1);
	memcpy(&cb->mac[0], &mac1, 4);
	cb->mac[5] = mac2 & 0xff;
	cb->mac[4] = (mac2 >> 8) & 0xff;
	cb->vlan = (mac2 >> 16 & 0x3ff);
	cb->fwd_port_list = ((mac3 & 0x1FFFF) << 3) | ((mac2 >> 29) & 0x7);
	cb->id_type = ((mac3 >> 17) & 0x3);
	cb->enable_vtag_removal = ((mac3 >> 19) & 0x1);
	cb->enable_rtag_removal = ((mac3 >> 20) & 0x1);
	cb->enable_recovery = ((mac3 >> 21) & 0x1);
	cb->enable_seq_gen = ((mac3 >> 22) & 0x1);
	cb->enable_mapped_vlan = ((mac3 >> 23) & 0x1);
	cb->enable_vlan_insertion = ((mac3 >> 24) & 0x1);
	cb->recovery_enable_bits = ((mac3 >> 27) & 0x1F);
	cb->recovery_enable_bits |= ((mac4 & 0x7FFF) << 5);
	cb->vtag_removal_port_list = ((mac4 >> 15) & 0x1FFFF) | ((mac5 & 0x7) << 17);
	cb->rtag_removal_port_list = ((mac5 >> 3) & 0xFFFFF);
	cb->port_drop_list = ((mac5 >> 23)) | ((entry1 & 0x7FF) << 9);
	cb->mapped_vlan = ((entry1 >> 11) & 0xFFF);
	cb->pcp = ((entry1 >> 23) & 0xF);
	cb->seq_gen_recovery_ptr = (entry1 >> 29) | ((entry2 & 0x1FFF) << 3);
	fp_get_seq_recovery_entry(cb->seq_gen_recovery_ptr, &cb->recovery_data[0]);
#endif
	return 0;
}

int32a fp_cb_get_entry_by_index(uint32a index, fp_cb_entry_t *cb)
{
	return __fp_cb_get_entry_by_index(index, cb, 1);
}

/*!
 Sets Sequence Reset timeout value for all streams.
 Sets the value globally to be used by all streams

 @param       timeout  timeout value in msec
 @return status code   0=success, -1=failure
 **/
int32a fp_cb_set_seq_reset_timeout_val (uint32a timeout)
{
	//TableWrite(CB_SEQ_RESET_TIMEOUT_REG, timeout);
	return 0;
}

/*!
 Sets Sequence History Length for all streams.
 Sets the value globally to be used by all streams

 @param           len  Sequence History Length (default 1024)
 @return status code   0=success, -1=failure
 **/
int32a fp_set_seq_history_len(uint32a timeout)
{
	//TableWrite(CB_SEQ_HISTORY_LEN_REG, timeout);
    return 0;
}

/*****************************************************************
*
*  Recovery Entry allocation APIs
*
******************************************************************/

/*!
 Allocates Sequence Recovery Entry.
 Need to allocate this recovery entry before adding the CB entry, if required.

 @return status code   0=success, -1=failure
 **/
static uint32a __fp_alloc_seq_recovery_entry(uint32a table_num)
{
	uint32a cmd_done = 0;
	cmd_done = IssueCommandTable_CS(HOST_CBRECOVERY_ENTRY_CMD_CNTRL_REG_ADDR,
					1, /* cmd */
					HOST_CBRECOVERY_ENTRY_STATUS_REG_ADDR,
					CB_ENTRY_STATUS_CMD_DONE,
					CB_ENTRY_STATUS_CLR,
					table_num);
	return ((cmd_done >> 4) & 0xFFFF);
}

uint32a fp_alloc_seq_recovery_entry()
{
	return __fp_alloc_seq_recovery_entry(1);
}
/*!
 Free Sequence Recovery Entry
 This entry needs to be freed after deletion of CB entry.

 @param rec            seq recovery entry to be freed
 @return status code   0=success, -1=failure
 **/
static uint32a __fp_free_seq_recovery_entry(uint32a seq_gen_recovery_ptr, uint32a table_num)
{
	uint32a cmd;
	// CMD_DELETE
	cmd = (seq_gen_recovery_ptr << 4) | 0x3;
	IssueCommandTable_CS(HOST_CBRECOVERY_ENTRY_CMD_CNTRL_REG_ADDR,
				cmd,
				HOST_CBRECOVERY_ENTRY_STATUS_REG_ADDR,
				CB_ENTRY_STATUS_CMD_DONE,
				CB_ENTRY_STATUS_CLR,
				table_num);
    return 0;
}

static uint32a __fp_fill_seq_recovery_entry(fp_cb_entry_t *cb, 		uint32a table_num)
{
	uint32a seq_gen_recovery_ptr = cb->seq_gen_recovery_ptr;
	int32a i = 0;
	struct recovery_entry rec_entry;
	uint32a recovery_bits = cb->recovery_enable_bits;

	for(i = 0; i < NUM_RECOVERY_ENTRIES; i++)
	{
		uint32a cmd;
		SAL_MemSet(&rec_entry, 0, sizeof(rec_entry));
		if ((i == 0) && (cb->enable_seq_gen)) {
			rec_entry.valid = 0;
			rec_entry.sequence_history1 = cb->start_seq_num;
		}
		else if ((i > 0)
		     &&  cb->enable_recovery
		     &&  ((recovery_bits >> (i - 1)) & 0x1)) {
			rec_entry.valid = 1;
			//rec_entry.seq_history_len = cb->seq_history_len;
		}
#if 0
	else	if ((i == 1)
		&& (cb->enable_recovery
		&& !recovery_bits))
			rec_entry.valid = 1;
#endif
		if (rec_entry.valid) {
			rec_entry.seq_rec_reset_msec = cb->seq_rec_reset_msec;
				//rec_entry.seq_num = cb->start_seq_num;
			//rec_entry.sequence_history1 = cb->start_seq_num;
		}
		if( (i == 1) && rec_entry.valid) {
			uint32a index = seq_gen_recovery_ptr/16;
			fp_latent_error_t *lat_err_info = &latent_error_info[index];
			SAL_MemSet(lat_err_info, 0, sizeof(fp_latent_error_t));
			/* TODO : initialize latent error info from cli */
			lat_err_info->latent_error_diff = 10;
			lat_err_info->latent_error_paths = 2;
			lat_err_info->latent_error_period = 5;
			lat_err_info->latent_reset_period = 60;
		}
		if (i != 0)
			rec_entry.recovery_algo_type = (cb->recovery_algo_type & (1 <<  (i-1))) ? 1 : 0;
		TableWrite(HOST_CBRECOVERY_DATA_REG0_ADDR,  rec_entry.Reg0 , table_num);
		TableWrite(HOST_CBRECOVERY_DATA_REG1_ADDR,  rec_entry.Reg1 , table_num);
		TableWrite(HOST_CBRECOVERY_DATA_REG2_ADDR,  rec_entry.Reg2 , table_num);
		TableWrite(HOST_CBRECOVERY_DATA_REG3_ADDR,  rec_entry.Reg3 , table_num);
		TableWrite(HOST_CBRECOVERY_DATA_REG4_ADDR,  rec_entry.Reg4 , table_num);
		TableWrite(HOST_CBRECOVERY_DATA_REG5_ADDR,  rec_entry.Reg5 , table_num);
		TableWrite(HOST_CBRECOVERY_DATA_REG6_ADDR,  rec_entry.Reg6 , table_num);
		TableWrite(HOST_CBRECOVERY_DATA_REG7_ADDR,  rec_entry.Reg7 , table_num);
		TableWrite(HOST_CBRECOVERY_DATA_REG8_ADDR,  rec_entry.Reg8 , table_num);
		TableWrite(HOST_CBRECOVERY_DATA_REG9_ADDR,  rec_entry.Reg9 , table_num);
		TableWrite(HOST_CBRECOVERY_DATA_REG10_ADDR, rec_entry.Reg10, table_num);
		TableWrite(HOST_CBRECOVERY_DATA_REG11_ADDR, rec_entry.Reg11, table_num);
		// CMD_WRITE
		cmd = ((seq_gen_recovery_ptr + i) << 4) | 0x4;
		IssueCommandTable_CS(	HOST_CBRECOVERY_ENTRY_CMD_CNTRL_REG_ADDR,
					cmd,
					HOST_CBRECOVERY_ENTRY_STATUS_REG_ADDR,
					CB_ENTRY_STATUS_CMD_DONE,
					CB_ENTRY_STATUS_CLR,
					table_num);
	}
	return 0;
}

uint32a fp_free_seq_recovery_entry(uint32a seq_gen_recovery_ptr)
{
	return __fp_free_seq_recovery_entry(seq_gen_recovery_ptr, 1);
}

uint32a fp_fill_seq_recovery_entry(fp_cb_entry_t *cb)
{
	return __fp_fill_seq_recovery_entry(cb, 1);
}

static uint32a __fp_get_seq_recovery_entry(uint32a seq_gen_recovery_ptr,
					uint32a *data,
					uint32a table_num)
{
	int32a i = 0;
	for(i = 0; i < NUM_RECOVERY_ENTRIES; i++)
	{
		uint32a cmd;
		// CMD_GET
		cmd = ((seq_gen_recovery_ptr + i) << 4) | 0x2;
		IssueCommandTable_CS(	HOST_CBRECOVERY_ENTRY_CMD_CNTRL_REG_ADDR,
					cmd,
					HOST_CBRECOVERY_ENTRY_STATUS_REG_ADDR,
					CB_ENTRY_STATUS_CMD_DONE,
					CB_ENTRY_STATUS_CLR,
					table_num);
		*data = TableRead(HOST_CBRECOVERY_DATA_REG0_ADDR, table_num);
		data++;
		*data = TableRead(HOST_CBRECOVERY_DATA_REG1_ADDR, table_num);
		data++;
		*data = TableRead(HOST_CBRECOVERY_DATA_REG2_ADDR, table_num);
		data++;
		*data = TableRead(HOST_CBRECOVERY_DATA_REG3_ADDR, table_num);
		data++;
		*data = TableRead(HOST_CBRECOVERY_DATA_REG4_ADDR, table_num);
		data++;
		*data = TableRead(HOST_CBRECOVERY_DATA_REG5_ADDR, table_num);
		data++;
		*data = TableRead(HOST_CBRECOVERY_DATA_REG6_ADDR, table_num);
		data++;
		*data = TableRead(HOST_CBRECOVERY_DATA_REG7_ADDR, table_num);
		data++;
		*data = TableRead(HOST_CBRECOVERY_DATA_REG8_ADDR, table_num);
		data++;
		*data = TableRead(HOST_CBRECOVERY_DATA_REG9_ADDR, table_num);
		data++;
		*data = TableRead(HOST_CBRECOVERY_DATA_REG10_ADDR, table_num);
		data++;
		*data = TableRead(HOST_CBRECOVERY_DATA_REG11_ADDR, table_num);
		data++;
	}
	return 0;
}

uint32a fp_get_seq_recovery_entry(uint32a seq_gen_recovery_ptr, uint32a *data)
{
	return __fp_get_seq_recovery_entry(seq_gen_recovery_ptr, data, 1);
}

static int32a __fp_smac_vlan_table_init(uint32a table_num)
{
	uint32a cmd = CMD_INIT;
	uint32a cmd_done = 0;
	uint32a index = 0;
	uint32a mac_table_addr = 0;
	uint32a col_ptr = 0;
	uint32a i = 0;

	cmd_done = IssueCommandTable_CS(CB_SMAC_HOST_CMD_REG,
					cmd,
					CB_SMAC_HOST_STATUS_REG,
					CB_ENTRY_STATUS_CMD_DONE,
					CB_ENTRY_STATUS_CLR,
					table_num);
/*
	printk("%s -- cmd_done = %x done = %s, init done = %s\n",
		__FUNCTION__, cmd_done,
		(cmd_done & CB_ENTRY_STATUS_CMD_DONE) ? "TRUE" : "FALSE",
		(cmd_done & STATUS_INIT_DONE)   ? "TRUE" : "FALSE");
*/
	if (cmd_done & CB_ENTRY_STATUS_CMD_DONE) {
		if(cmd_done & STATUS_INIT_DONE) {
			/* initialize mac addresses */
			TableWrite(CB_SMAC_HOST_MAC1_ADDR_REG, 0x0, table_num);
			TableWrite(CB_SMAC_HOST_MAC2_ADDR_REG, 0x0, table_num);
			TableWrite(CB_SMAC_HOST_MAC3_ADDR_REG, 0x0, table_num);
			TableWrite(CB_SMAC_HOST_MAC4_ADDR_REG, 0x0, table_num);
			TableWrite(CB_SMAC_HOST_MAC5_ADDR_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_ENTRY_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_DIRECT_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_ENTRY1_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_ENTRY2_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_ENTRY3_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_ENTRY4_REG, 0x0, table_num);
			TableWrite(CB_TABLE_HOST_ENTRY5_REG, 0x0, table_num);

			/* chain the collision space */
			for (i = 0; i < CB_SMAC_COLL_ENTRIES; i++)
			{
				//direct_wdata = {4'h4 ,col_ptr, 4'h0, 8'h0, 16'h0, 48'h0};
				col_ptr = (0x40041 + i) << 12;
				TableWrite(CB_SMAC_HOST_MAC3_ADDR_REG, col_ptr, table_num);
				index = CB_SMAC_HASH_ENTRIES + i;
				mac_table_addr = (index << 16) + CMD_MEM_WRITE;
				IssueCommandTable_CS(CB_SMAC_HOST_CMD_REG,
								mac_table_addr,
								CB_SMAC_HOST_STATUS_REG,
								CB_ENTRY_STATUS_CMD_DONE,
								CLR_STATUS_REG,
								table_num);
			} /*End of for loop collision space*/

			/* Intialize Free List Head Ptr */
			TableWrite(CB_SMAC_FREELIST_PTR_HEAD, CB_SMAC_INIT_HEAD_PTR, table_num);

			/* Initialize Free List Ptr */
			TableWrite(CB_SMAC_FREELIST_PTR_TAIL, CB_SMAC_INIT_TAIL_PTR, table_num);

			/* Initialize No of entries */
			TableWrite(CB_SMAC_FREELIST_ENTRIES_ADDR, CB_SMAC_COLL_ENTRIES, table_num);

			/* Clear Status Reg */
			TableWrite(CB_SMAC_HOST_STATUS_REG, CLR_STATUS_REG, table_num);

			TPA_D("CB TABLE HASH INIT DONE\r\n");
			return 0;
		}
		else {
			TPA_E("CMD_INIT - Not successful\n");
			return -1;
		}
	}
	TPA_E("CMD_INIT failed (incomplete)\n");
	return -2;
}

int32a fp_smac_vlan_table_init()
{
	if(__fp_smac_vlan_table_init(1) < 0) {
		TPA_E("error in fp_smac_vlan_table_init\n");
		return -1;
	}
	return __fp_smac_vlan_table_init(3);
}
/*!
 Add CB entry

 @param            cb  cb entry to be added
 @return status code   0=success, -1=failure
 **/
static int32a __fp_smac_vlan_add_entry(fp_smac_vlan_entry_t *smac, uint32a table_num)
{
#if 0
	uint32a mac1;
	uint32a mac2;
	uint32a cmd_done;
	uint32a cmd;
	uint32a  field_valids = BIT_SET_SMAC_TBL;

	//reverse_mac(&cb->mac[0]);
	uint32a *entry = (uint32a *)smac->mac;
	mac1 = entry[0];
	mac2 = entry[1] & 0xFFFF;
	/* set mac addr */
	TableWrite(CB_SMAC_HOST_MAC1_ADDR_REG, htonl(mac1), table_num);
	/* set mac addr and vlan */
	TableWrite(CB_SMAC_HOST_MAC2_ADDR_REG, ntohs(mac2), table_num);
	TableWrite(CB_SMAC_HOST_ENTRY_REG, smac->vlan, table_num);

	/* Submit ADD command */
	//cmd = CB_ENTRY_CMD_ADD;
	//cmd = 0x302;
	cmd = (CMD_ADD | field_valids);
	cmd_done = IssueCommandTable_CS(CB_SMAC_HOST_CMD_REG,
					cmd,
					CB_SMAC_HOST_STATUS_REG,
					CB_ENTRY_STATUS_CMD_DONE,
					CB_ENTRY_STATUS_CLR,
					table_num);
/*
	printk("%s -- cmd_done = %x done = %s, added = %s\n",
		__FUNCTION__, cmd_done,
		(cmd_done & CB_ENTRY_STATUS_CMD_DONE) ? "TRUE" : "FALSE",
		(cmd_done & STATUS_ENTRY_ADDED)   ? "TRUE" : "FALSE");
*/
	if (cmd_done & CB_ENTRY_STATUS_CMD_DONE) {
		if(cmd_done & STATUS_ENTRY_ADDED) {
			return 0;	/* entry added */
		} else {
			pr_err("CMD_ADD - VLAN Entry not added\n");
			return -1;
		}
	} else {
		pr_err("CMD_ADD failed\n");
		return -2;
	}
#else
	return -1;
#endif
}

int32a fp_smac_vlan_add_entry(fp_smac_vlan_entry_t *smac)
{
	if(__fp_smac_vlan_add_entry(smac, 1) < 0)
		return -1;
	return __fp_smac_vlan_add_entry(smac, 3);
}

/*!
 Delete CB entry

 @param           mac  mac address of the entry
 @param       vlan_id  vlan id of the entry
 @param   id_type      identification type
 @return status code   0=success, -1=failure
 **/
static int32a __fp_smac_vlan_del_entry (uint8 mac[], uint32a table_num)
{
#if 0
	uint32a cmd_done;
	uint32a cmd;
	uint32a mac1;
	uint32a mac2;
	uint32a field_valids = BIT_SET_SMAC_TBL;

	uint32a *entry = (uint32a *)mac;
	mac1 = entry[0];
	mac2 = entry[1] & 0xFFFF;
	/* set mac addr */
	TableWrite(CB_SMAC_HOST_MAC1_ADDR_REG, htonl(mac1), table_num);
	/* set mac addr and vlan */
	TableWrite(CB_SMAC_HOST_MAC2_ADDR_REG, ntohs(mac2), table_num);
	/* Submit DEL command */
	cmd =  (CMD_DEL | field_valids);
	cmd_done = IssueCommandTable_CS(CB_SMAC_HOST_CMD_REG,
					cmd,
					CB_SMAC_HOST_STATUS_REG,
					CB_ENTRY_STATUS_CMD_DONE,
					CB_ENTRY_STATUS_CLR,
					table_num);
/*
	printk("%s -- cmd_done = %x done = %s, not found = %s\n",
		__FUNCTION__, cmd_done,
		(cmd_done & CB_ENTRY_STATUS_CMD_DONE) ? "TRUE" : "FALSE",
		(cmd_done & STATUS_ENTRY_NOT_FOUND)   ? "TRUE" : "FALSE");
*/
	if (cmd_done & CB_ENTRY_STATUS_CMD_DONE) {
		/* if STATUS_ENTRY_NOT_FOUND = 1 CMD_DEL failed */
		if(cmd_done & STATUS_ENTRY_NOT_FOUND) {
			pr_err("Entry not deleted \n");
			return -1;
		}
	} else {
		pr_err("CMD_DEL failed\n");
		return -2;
	}
#endif
	return 0;
}

int32a fp_smac_vlan_del_entry (uint8 mac[])
{
	if(__fp_smac_vlan_del_entry(mac, 1) < 0)
		return -1;
	return __fp_smac_vlan_del_entry(mac, 3);
}
/*!
 Get CB entry

 @param           mac     mac address of the entry
 @param       vlan_id     vlan id of the entry
 @param   id_type      identification type
 @param             cb    cb entry to be read
 @return  status code:    0=success, -1=failure
 */

static int32a __fp_smac_vlan_get_entry(uint8 mac[], uint32a table_num)
{
#if 0
	uint32a cmd;
	uint32a mac1;
	uint32a mac2;
	uint32a cmd_done;
	uint32a field_valids = BIT_SET_SMAC_TBL;
	uint32a vlan = 0;
	//reverse_mac(&cb->mac[0]);
	uint32a *entry = (uint32a *)mac;
	mac1 = entry[0];
	mac2 = entry[1] & 0xFFFF;
	/* set mac addr */
	TableWrite(CB_SMAC_HOST_MAC1_ADDR_REG, htonl(mac1), table_num);
	/* set mac addr and vlan */
	TableWrite(CB_SMAC_HOST_MAC2_ADDR_REG, ntohs(mac2), table_num);
	/* Submit SEARCh command */
	cmd = (CMD_SEARCH | field_valids);
	cmd_done = IssueCommandTable_CS(CB_SMAC_HOST_CMD_REG,
					cmd,
					CB_SMAC_HOST_STATUS_REG,
					CB_ENTRY_STATUS_CMD_DONE,
					CB_ENTRY_STATUS_CLR,
					table_num);
/*
	printk("%s -- cmd_done = %x done = %s, match = %s\n",
		__FUNCTION__, cmd_done,
		(cmd_done & CB_ENTRY_STATUS_CMD_DONE) ? "TRUE" : "FALSE",
		(cmd_done & STATUS_ENTRY_MATCH)   ? "TRUE" : "FALSE");
*/
	if (cmd_done & CB_ENTRY_STATUS_CMD_DONE) {
		if(cmd_done & STATUS_ENTRY_MATCH) {
			vlan = TableRead(CB_SMAC_HOST_ENTRY_REG, table_num);
			return vlan;
		} else {
			pr_err("Entry not found \n");
			return -1;
		}
	} else {
		pr_err("Search failed\n");
		return -2;
	}
#else
	return -1;
#endif
}

int32a fp_smac_vlan_get_entry(uint8 mac[])
{
	return __fp_smac_vlan_get_entry(mac, 1);
}

