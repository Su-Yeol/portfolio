/**
 * @file MRVL_Q222X.h
 * @brief Q222X General PHY Ctrl API Header File.
 * DUT General Control and Status Access
 *
 * @par Copyright and Version
 * See MRVL_Q222X_Copyright_and_Version.h
 */

#ifndef MRVL_Q222X_H
#define MRVL_Q222X_H

#include "MRVL_Q222X_Types.h"

/** @defgroup PHYCtrl_Top PHY general control top-level group */

/******************************************************************************
 *      Device Detection
 ******************************************************************************/
/** @defgroup PHY_DEVICE PHY Device Init
 * @ingroup PHYCtrl_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_getDeviceInfo(MRVL_DEV_PTR device);

/******************************************************************************
 *      General Status
 ******************************************************************************/
/** @defgroup PHY_STATUS PHY Status Checking
 * @ingroup PHYCtrl_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_checkIsMaster(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isMaster);

EXPORT_FUNC MRVL_APHY_STATUS q222x_checkSupportSGMII(MRVL_DEV_PTR device, MRVL_APHY_BOOL* supportSGMII);

EXPORT_FUNC MRVL_APHY_STATUS q222x_checkLink(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isLinkup);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getRealTimeLinkStatus(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isLinkup);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getLatchedLinkStatus(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isLinkup);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getAnegEnabled(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isEnable);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getAnegDone(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isDone);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getSpeed(MRVL_DEV_PTR device, MRVL_APHY_SPEED* speed);


/******************************************************************************
 *      Mode and Speed Configuration
 ******************************************************************************/
/** @defgroup PHY_MODE PHY Mode Configuration
 * @ingroup PHYCtrl_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_initQ222XFe(MRVL_DEV_PTR device, MRVL_APHY_OPERATION_MODE opMode);

EXPORT_FUNC MRVL_APHY_STATUS q222x_initQ222XGe(MRVL_DEV_PTR device, MRVL_APHY_OPERATION_MODE opMode);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setAneg(MRVL_DEV_PTR device, MRVL_APHY_OPERATION_MODE opMode, MRVL_APHY_U16 flags);

EXPORT_FUNC MRVL_APHY_STATUS q222x_softReset(MRVL_DEV_PTR device);

/******************************************************************************
 *      Advanced Feature
 ******************************************************************************/
/** @defgroup PHY_ADV_FEAT PHY Advanced Feature
 * @ingroup PHYCtrl_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_getSQIReading_8Level(MRVL_DEV_PTR device, MRVL_APHY_U16* sqi);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getCableDiagnostic(MRVL_DEV_PTR device, MRVL_APHY_HARNESS_STATUS* harnessStatus, MRVL_APHY_U16* distanceToFault);

#endif
