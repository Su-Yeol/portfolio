/* SPDX-License-Identifier: (GPL-2.0 WITH Linux-syscall-note) AND MIT */

/*************************************************************************/ /*!
@File
@Title          fp_bd_api.h
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    defines for buffer descriports
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

#ifndef _FP_BD_API_H
#define _FP_BD_API_H

#ifdef __linux__
#include <linux/types.h>
#include <linux/netdevice.h>
#else
#include <sal_internal.h>
#endif

/* buffer descr ctrl flags */
#define BD_CTRL_BD_BUFLEN_MASK	(0xffff)
#define BD_CTRL_PKT_INT_EN	(1 << 0)
#define BD_CTRL_CBD_INT_EN	(1 << 1)
#define BD_CTRL_LIFM		(1 << 2)
#define BD_CTRL_LAST_BD		(1 << 3)
#define BD_CTRL_DIR		(1 << 4)
#define BD_CTRL_PKT_XFER	(1 << 8)
#define BD_CTRL_DESC_EN		(1 << 15)
#define BD_CTRL_PARSE_DISABLE	(1 << 9)
#define BD_CTRL_BRFETCH_DISABLE	(1 << 10)
#define BD_CTRL_RTFETCH_DISABLE	(1 << 11)

#define WB_BD_CTRL_DESC_EN	(1 << 31)

#define NUM_BD_DESCR		32
#define NUM_TX_DESCR		NUM_BD_DESCR
#define NUM_RX_DESCR		NUM_BD_DESCR
#define NUM_TX_WB_DESCR		(NUM_BD_DESCR * 2)
#define NUM_RX_WB_DESCR		(NUM_BD_DESCR * 2)
#define MAX_BUFF_SIZE		MAX_FRAME_SIZE
#define TX_BD_INIT_RING		1
#define RX_BD_INIT_RING		2
#define ALIGN_64_BIT_MASK	64
#define NUM_TOTAL_DESCR		(NUM_TX_DESCR + NUM_RX_DESCR + NUM_WB_DESCR)

struct bd {
	uint16	bd_seqnum;
	uint16	bd_ctrl;
	uint16	bd_buflen;
	uint16	rsvd;
	uint32a	bd_bufaddr;
	uint32a	bd_nextptr;
};

struct wb_bd {
	uint32a	bd_ctrl;	/* rsvd-[31:11] ctrl[10:0] */
	uint16	bd_buflen;	/* seq-[31:16] buflen-[15:0] */
	uint16	bd_seqnum;
};

struct bd_ring {
	spinlock_t	lock;
	struct bd	*bd_tbl_va;	/* 64-bit aligned */
	struct wb_bd	*wb_bd_tbl_va;	/* 64 bit aligned */
	struct wb_bd	*wb_read_ptr;
	dma_addr_t	bd_tbl_pa;
	dma_addr_t	wb_bd_tbl_pa;
	dma_addr_t	bd_buff_pa;
	dma_addr_t	dev_addr;
	void		*cpu_addr;
	void		*bd_buff_va;
	struct bd	*head;
	struct bd	*tail;
	int32a		index;
	int32a		free_bd_cnt;
	int32a		wb_seq_num;
	int32a		seq_num;
	int32a		ring_len;
	int32a		size;
	int32a		wb_ring_len;
	int32a		flag;
};

extern uint32a fp_total_ring_size;


struct bd *fp_get_next_free_bd(struct bd_ring *ring);
int32a fp_check_bd_status(struct bd_ring *ring);
uint32a fp_get_curr_bd_index(struct bd_ring *ring, struct bd *bd);
int32a fp_enque_bd(struct bd_ring *ring, struct bd *);
struct bd *fp_deque_bd(struct bd_ring *ring, uint32a *bd_buflen);
//void fp_dump_bd_info(struct bd *dump_bd);
int32a fp_bd_init(struct fp_private *fp);
//void handle_hif(struct hif_base *hif);
//void handle_channel(struct hif_base *hif, uint32a ch_index);
void fp_disable_hif_ch_interrupts(struct hif_base *hif);
void fp_enable_hif_ch_interrupts(struct hif_base *hif);
int32a fp_bd_reinit(void);

#endif /* _FP_BD_TABLE_H */

