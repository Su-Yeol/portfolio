################################################################################
#
#                           Library Definitions
#
#  Description:
#    This makefile structure assumes that the following variables are defined:
#
#      PRIMARY_FILE = name of the target
#      SRCS = the name of the C++ sources
#      CSRCS = the name of the C sources
#
#      INCLUDEDIRS = list of directories to include 
#      COMPILE_DEPENDS = list of dependencies for creating the object
#      CROSS_COMPILE = Path to compiler 
#      OSTYPE = type of the operating system. Must be defined if not defined in the compilation enviornment
#      SHARED_LIB = 1 if building the shared object is needed
#      LIB = library of the makefile
#      
#      MTDAPI should be defined if using a DIONE chip
#  
#
#	  Example for building for ARM:    
#	  export CROSS_COMPILE=/path/to/cross/tool/bin/aarch64-linux-gnu-
#     export ARCH=arm
#     make SHARED_LIB=1 -f AQ_API.make
#
#
################################################################################

.SUFFIXES: 

.PRECIOUS: $(AQPRECIOUS)

.PHONY: $(AQPHONY)

# define the compiler commands and compile flags for C and C++
ifdef X64
  ifeq ($(OSTYPE),cygwin)
    C++ = C:/usr/MinGW64/bin/x86_64-w64-mingw32-g++
    CC = C:/usr/MinGW64/bin/x86_64-w64-mingw32-gcc 
    AR = C:/usr/MinGW64/bin/x86_64-w64-mingw32-ar
    RANLIB = C:/usr/MinGW64/bin/x86_64-w64-mingw32-ranlib
  else
    ifeq ($(OSTYPE),msys)
      ifeq ($(MSYSTEM),MINGW64)
        C++ = g++
        CC = gcc
        AR = ar
        RANLIB = ranlib
      else
        $(error Attempting to cross-compile for X64 architecture from MINGW32 MSys! Use MINGW64 MSys environment)
      endif
    else  
      $(error Attempting to cross-compile for X64 architecture from $(OSTYPE)! Cygwin and MSys are the only supported windows environments at this time)
    endif
  endif
else
  ifdef CROSS_COMPILE
    $(info Cross compiling flash burn)
    C++ = $(CROSS_COMPILE)g++
    CC = $(CROSS_COMPILE)gcc
    AR = $(CROSS_COMPILE)ar
    RANLIB = $(CROSS_COMPILE)ranlib
  else
    C++ = g++
    CC = gcc
    AR = ar
    RANLIB = ranlib
  endif
endif

#define the flags depending on whether debugging is enabled
ifdef DEBUG
  CFLAGS = -g -O0 -c -static -std=c99 -Wall -fmessage-length=0 
  C++FLAGS = -g -O0 -c -static -std=c99-Wall -Wold-style-cast -Woverloaded-virtual -fmessage-length=0 
else
  CFLAGS = -O3 -c -static -std=c99 -Wall -fmessage-length=0
  C++FLAGS = -O3 -c -static -std=c99 -Wall -Wold-style-cast -Woverloaded-virtual -fmessage-length=0
endif

#needed so compiler won't complain about __aeabi_unwind_cpp_pr
ifdef CROSS_COMPILE
  ifeq ($(ARCH), arm)
    C++FLAGS += -Wl,--start-group,-lgcc,-lc,--end-group -lgcc_eh 
  endif
endif

#set the OS flags
ifeq ($(OSTYPE),solaris)
  $(info Compiling for Solaris)
  C++_USER_FLAGS += -DSOLARIS
  C_USER_FLAGS += -DSOLARIS
else
  ifeq ($(OSTYPE),linux)
    $(info Compiling for Linux)
    C++_USER_FLAGS += -DLINUX
    C_USER_FLAGS += -DLINUX
  else
    ifeq ($(OSTYPE),cygwin)
      ifdef X64
        $(info Compiling for X64)
        C++_USER_FLAGS += -DX64
        C_USER_FLAGS += -DX64
      else
        $(info Compiling for WIN32)
        C++_USER_FLAGS += -DWIN32
        C_USER_FLAGS += -DWIN32
      endif
    else
      ifeq ($(OSTYPE),msys)
        # sanity checking on the correct MSYSTEM is done above
        ifdef X64
          $(info Compiling for X64)
          C++_USER_FLAGS += -DX64
          C_USER_FLAGS += -DX64
        else
          $(info Compiling for WIN32)
          C++_USER_FLAGS += -DWIN32
          C_USER_FLAGS += -DWIN32
        endif
      endif
    endif
  endif
endif

ifeq ($(SHARED_LIB),1)
  C++_USER_FLAGS += -fPIC
  C_USER_FLAGS += -fPIC
endif

ROOT = ..

api_includeDir := -I.
hwiDir := -I ../../maryamj_Dena_rev1.0_2/Systems/tools/windows/hwInterface/include
INCLUDEDIRS = $(api_includeDir) $(hwiDir)


OBJDIR = OBJ


# Primary file definition
PRIMARY_FILE = MRVL_API

CSRCS = MRVL_AMG_API.c MRVL_AMG_API_CMD.c MRVL_AMG_API_FW.c MRVL_AMG_API_Debug.c MRVL_AMG_HwInterface.c MRVL_AMG_Customize.c
COMPILE_DEPENDS +=  MRVL_AMG_API.c MRVL_AMG_API_CMD.c MRVL_AMG_API_FW.c MRVL_AMG_API_Debug.c MRVL_AMG_HwInterface.c MRVL_AMG_Customize.c


COMPILE_DEPENDS += $(PRIMARY_FILE).make

LIB = $(ROOT)/lib$(PRIMARY_FILE).a
LIBSHARED = $(ROOT)/lib$(PRIMARY_FILE).so

ifdef SHARED_LIB
  .DEFAULT_GOAL := $(LIBSHARED)
else
  .DEFAULT_GOAL := $(LIB)
endif

# list of all C and C++ objects.  OBJDIR is the target directory where
# .o files will be placed.  If it doesn't
# exist, OBJDIR wil be created.
ifdef OBJDIR
  # list of all C and C++ objects
  OBJS := $(addprefix $(OBJDIR)/,$(CSRCS:.c=.o))
  OBJSCC = $(SRCS:.cc=.o)
  OBJS += $(addprefix $(OBJDIR)/,$(OBJSCC:.cpp=.o))
  
  $(OBJS): | $(OBJDIR)
  $(OBJDIR):
		mkdir $(OBJDIR)

  # Rule for compiling c++ files
  $(OBJDIR)/%.o : %.cc $(COMPILE_DEPENDS)
		$(C++) $(C++FLAGS) $(C++_USER_FLAGS) $(INCLUDEDIRS) $(OUTPUT_OPTION) $<

  $(OBJDIR)/%.o : %.cpp $(COMPILE_DEPENDS)
		$(C++) $(C++FLAGS) $(C++_USER_FLAGS) $(INCLUDEDIRS) $(OUTPUT_OPTION) $<

  # Rule for compiling c files
  $(OBJDIR)/%.o : %.c $(COMPILE_DEPENDS)
		$(CC) $(CFLAGS) $(C_USER_FLAGS) $(INCLUDEDIRS) $(OUTPUT_OPTION) $<
else
  # list of all C and C++ objects
  OBJS := $(CSRCS:.c=.o)
  OBJSCC = $(SRCS:.cc=.o)
  OBJS += $(OBJSCC:.cpp=.o)
  
  # Rule for compiling c++ files
  %.o : %.cc $(COMPILE_DEPENDS)
		$(C++) $(C++FLAGS) $(C++_USER_FLAGS) $(INCLUDEDIRS) $(OUTPUT_OPTION) $<

  # Rule for compiling c++ files
  %.o : %.cpp $(COMPILE_DEPENDS)
		$(C++) $(C++FLAGS) $(C++_USER_FLAGS) $(INCLUDEDIRS) $(OUTPUT_OPTION) $<

  # Rule for compiling c files
  %.o : %.c $(COMPILE_DEPENDS)
		$(CC) $(CFLAGS) $(C_USER_FLAGS) $(INCLUDEDIRS) $(OUTPUT_OPTION) $<
endif


# Rule for building and installing a library
$(LIB): $(OBJS)
	rm -f $(LIB)
	$(AR) cq $(LIB) $(OBJS)
	$(RANLIB) $(LIB)

$(LIBSHARED): $(OBJS)
	rm -f $(LIBSHARED)
	$(CC) -shared -o $(LIBSHARED) $(OBJS)
	

clean:
	rm -f $(LIB)
	rm -f $(LIBSHARED)
	rm -rf OBJ
