// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
 * @File
 * @Title        fp_hooks.c
 * @Copyright    Copyright (c) Imagination Technologies Ltd. All Rights Reserved
 * @Description  Register user defined hooks at PRE-ROUTING and
 *               POST-ROUTING chains to do the necessary processing
 *               for the fast path. Common function is registered at
 *               both the hooks
 * @License      Dual MIT/GPLv2
 *
 * The contents of this file are subject to the MIT license as set out below.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * the GNU General Public License Version 2 ("GPL") in which case the provisions
 * of GPL are applicable instead of those above.
 *
 * If you wish to allow use of your version of this file only under the terms of
 * GPL, and not to allow others to use your version of this file under the terms
 * of the MIT license, indicate your decision by deleting the provisions above
 * and replace them with the notice and other provisions required by GPL as set
 * out in the file called "GPL-COPYING" included in this distribution. If you do
 * not delete the provisions above,a recipient may use your version of this file
 * under the terms of either the MIT license or GPL.
 *
 * This License is also included in this distribution in the file called
 * "MIT-COPYING".
 *
 * EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 * PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");


/*
 * fp_hooks.c - This file is used to add the functionality of fast path
 *               between Ethernets.
 *               The functionality acheived in this file is
 *               1.Register two user defined hooks at PRE-ROUTING and
 *                 POST-ROUTING chains to do the necessary processing
 *                for the fast path. Common function is registered at
 *                 both the hooks.
 *               2.The registered function gathers the parameters required
 *                 to add the RFT entries. These parameters are either
 *                 stored in skbuff or connection tracking structure
 *                 depending on the type of parameter.
 *               3.There is an output function written like a library call
 *                 has to be called by outgoing fastpath driver,to add the entry
 *                 in the route flow table, from the information gathered in
 *                 the hook functions. Once this entry is added successfully
 *                 with the necessary parameters, the fast path is enabled.
 *               4.When the traffic is going through FP, connection
 *                 tracking entries are deleted after the connection tracking
 *                 timeout, which is wrong. The connection tracking entries
 *                 time out values are to be refreshed from flow entries.
 *                 The timer function is registered to refresh the connection
 *                 tracking entries from flow entries.
 *               5.This file contains functions to delete the flow entries
 *                 when connection tracking entries are deleted.
 *
 * Copyright (c) 2017-2018, Imagination Technologies, Inc.
 * All rights reserved.
 */
/*****************************************************************************
 *                       INCLUDE FILES                                       *
 *****************************************************************************
 */
#include <asm/param.h>
#include <linux/ip.h>
#include <linux/if_pppox.h>	// pppeo_hdr
#include <linux/version.h>
#include <linux/netfilter.h>
#include <linux/netfilter_ipv4.h>
#include <linux/netfilter_ipv6.h>
#include <net/netfilter/nf_conntrack.h>
#include <net/netfilter/nf_conntrack_helper.h>

#include "fp_library.h"
#include "fp_macros.h"
#include "fp_hooks.h"
#include "fp_pppoe.h"
#include "fp_vlan.h"
#include "fp_netd.h"
#include "fp_ip.h"
//#ifdef FP_IPSEC
//#include "fp_sa.h"
//#endif
//static fp_dev_info_t fp_phy[FP_MAX_PORTS];
//fp_dev_info_t  *fp_logical_dev[FP_MAX_PORTS];

//static nfp_dev_info_t fp_priv[FP_MAX_PORTS];

//fp_IfData_t gIfPorts[MAX_PHY_PORTS][MAX_LOGICAL_IFS];
//fp_phyPort_t gPhyPorts[MAX_PHY_PORTS];
void fp_download_logif_cfg(struct net_device *dev, struct IfData *if_data);

//nfp_global_config_t fpathConfig;
//struct net_device *fp_phy_addr[FP_MAX_PORTS] = {0};

/******************************************************************************
 *                              #DEFINES                                      *
 ******************************************************************************
 */
#define  DEBUG                  1    /* To enable DEBUG messages make it 1. */
/* Max flow entries that can be stored in the route flow table. */
#define  MAX_FLOW_TABLE         256

/* Following macros represent bits of the control flags of the flow entry
 * Represents the control connection.
 */
#define CONTROL_FLOW            0x1

/* Represents the established connection. */
#define ESTABLISHED_FLOW        0x2

/* Represents the VLAN flow. */
#define VLAN_ENABLE             0x4

/* Represents the Route flow  (to add into Route FlowTable). */
#define FPROUTE_FLOW            0x8

/* Represents the bridge flow. */
#define FPBRIDGE_FLOW           0x10

/* Represents that the flow is marked  */
#define DIFFSERV_MARK           0x20

/* with diffserv code point. Represents multicast route flow */
#define  FP_MCAST_ROUTE_FLOW    0x40

/* Following macros gives the timeout values for different flows of
 * the connection tracking module
 */
#if 1
#define SECS(s)                    ((s) * HZ)
#define MINS(m)                    ((m) * 60 * SECS(1))
#define HOURS(h)                   ((h) * 60 * MINS(1))
#define DAYS(d)                    ((d) * 24 * HOURS(1))
#endif
/*These timeouts values are taken from
 *  1. netfilter/ip_conntrack_proto_udp.c,
 *  2. netfilter/ip_conntrack_proto_tcp.c and
 *  3. netfilter/ip_conntrack_proto_icmp.c
 *  and the macros in both the files should have same values.
 */

/* Represents the timeout for first/unconfirmed udp packet */
#define UDP_TIMEOUT         (30*HZ)

/* Represents the timeout for established/confirmed udp packet. */
#define UDP_STREAM_TIMEOUT  (180*HZ)

/* Represents the timeout value for icmp traffic */
#define ICMP_TIMEOUT        (30*HZ)

#define GENERIC_TIMEOUT     (600*HZ)

/* This value is used to refresh the connection tracking entries. */
//#define FPROUTE_REFRESH     (5*HZ)
#define FPROUTE_REFRESH     (5000*HZ)

/* The below structure defines the timeouts for different states of TCP */
#if 1
static uint32 tcptimeouts[] = {
	MINS(30),    /*      TCP_CONNTRACK_NONE,          */
	DAYS(5),     /*      TCP_CONNTRACK_ESTABLISHED,   */
	MINS(2),     /*      TCP_CONNTRACK_SYN_SENT,      */
	SECS(60),    /*      TCP_CONNTRACK_SYN_RECV,      */
	MINS(2),     /*      TCP_CONNTRACK_FIN_WAIT,      */
	MINS(2),     /*      TCP_CONNTRACK_TIME_WAIT,     */
	SECS(10),    /*      TCP_CONNTRACK_CLOSE,         */
	SECS(60),    /*      TCP_CONNTRACK_CLOSE_WAIT,    */
	SECS(30),    /*      TCP_CONNTRACK_LAST_ACK,      */
	MINS(2),     /*      TCP_CONNTRACK_LISTEN,        */
};
#endif

/*Below macro represents the maximum RFT entries per flow/connection */

#define  MAX_RFTS_PER_FLOW       2

/* Below Macros represent the Encapsulation configured for different VCs */
#define  LLC 1
#define  VC  0
/* These macros should be same as in linux/net/atm/pppoatm.c **/
#define  PPPOA_LLC       2
#define  PPPOA_VC        1
#define  PPPOA_AUTO      0

/*** Macros to represent RFC2684 header lengths for pppoe packet ***/
#define  PPPOE_LLC_HDR_LEN 10
#define  PPPOE_VC_HDR_LEN  2

/*Below macro is used to get the protocol field from ip header **/
#define  ip_protocol      (*(((uint8 *)piph) + 9))
#define IP_VER(ip)        (((ip)->version & 0xf0) >> 4)
//struct net net;
/*****************************************************************************
 * Function name : fp_route_in_ops - IPV4 route hooks
 * Description   : NF Hooks registration for E2E Route flows
 *****************************************************************************
 */

static struct nf_hook_ops fp_route_in_ops = {
	.hook           = (nf_hookfn *)fp_route_hook,
	.pf             = NFPROTO_IPV4,
	.hooknum        = NF_INET_PRE_ROUTING,
	.priority       = NF_IP_PRI_LAST,
};
static struct nf_hook_ops fp_route_out_ops = {
	.hook           = (nf_hookfn *)fp_route_hook,
	.pf             = NFPROTO_IPV4,
	.hooknum        = NF_INET_POST_ROUTING,
	.priority       = NF_IP_PRI_LAST,
};

/*****************************************************************************
 * Function name : fp_ipv6_route_in_ops - IPV6 route hooks
 * Description   : NF Hooks registration for E2E Route flows
 *****************************************************************************
 */

static struct nf_hook_ops fp_ipv6_route_in_ops = {
	.hook           = (nf_hookfn *)fp_route_hook,
	.pf             = NFPROTO_IPV6,
	.hooknum        = NF_INET_PRE_ROUTING,
	.priority       = NF_IP6_PRI_LAST,
};

static struct nf_hook_ops fp_ipv6_route_out_ops = {
	.hook           = (nf_hookfn *)fp_route_hook,
	.pf             = NFPROTO_IPV6,
	.hooknum        = NF_INET_POST_ROUTING,
	.priority       = NF_IP6_PRI_LAST,
};
/*****************************************************************************
 * Function name     : fp_copy_int16_array
 * Input Parameters  : 2 input parameters src  and count which are
 *                     short integers.
 * Output Parameters : dst which is a short integer.
 * Description:        This function copies from array of  shorts
 *                     to another array of  shorts
 *                     given the count as the number of elements to copy.
 * Result            : void
 * Changes           : -
 *****************************************************************************
 */
static inline void fp_copy_int16_array(uint16 *src,
		uint16 *dst, uint16 count)
{
	uint32a i;

	for (i = 0; i < count;  i++)
		*dst++ = *src++;
}

#if 0
/*****************************************************************************
 * Function name     : get_phyPort_by_device()
 * Description       : This function returns matched device phyport.
 * Input  Parameters : struct net_device*
 * Output Parameters : -
 * Return            : struct phyPort*
 * Changes           :
 *****************************************************************************
 */
fp_phyPort_t *get_phyPort_by_device(struct net_device *txdev)
{
	int32a i;

	for (i = 0; i < MAX_PHY_PORTS; i++) {
		if (gPhyPorts[i].device == txdev)
			return &gPhyPorts[i];
	}
	return NULL;
}
#endif

/*****************************************************************************
 * Function name     : getPPPoESessionId()
 * Description       : This function extracts the session id from the
 *                     packet and returns it.
 * Input  Parameters : struct sk_buff**
 * Output Parameters : -
 * Return            : int
 * Changes           :
 *****************************************************************************
 */
int32a getPPPoESessionId(struct sk_buff *skb)
{
	struct pppoe_hdr *pPppoeHdr = NULL;
	struct vlan_hdr  *pVlanHdr  = NULL;
	struct ethhdr    *pEthHdr   = (struct ethhdr *) skb->data;
	uint16 protocol = pEthHdr->h_proto;
	uint8 *pNextHdr = ((uint8 *) skb->data + sizeof(struct ethhdr));
	int32a iSessionId = 0;

	while (protocol) {
		switch (protocol) {
		case ETH_P_PPP_SES:
			pPppoeHdr  = (struct pppoe_hdr *) pNextHdr;
			iSessionId =  pPppoeHdr->sid;
			pNextHdr  +=  sizeof(struct pppoe_hdr);
			protocol   = ((pNextHdr[0] << 8) + pNextHdr[1]);
			pNextHdr   = pNextHdr + 2;
		break;
#if CONFIG_VLAN_8021Q
		case ETH_P_8021Q:
			pVlanHdr  = (struct vlan_hdr *) pNextHdr;
			pNextHdr += sizeof(struct vlan_hdr);
		break;
#endif
		case ETH_P_IP:
			protocol = 0;
		break;

		default:
			protocol = 0;
		break;
		}
	}

	return iSessionId;
}

/*****************************************************************************
 * Function name     : fp_print_interface()
 * Description       : This function prints interface details.
 * Input  Parameters : struct IfData*
 * Output Parameters : -
 * Return            : void
 * Changes           :
 ******************************************************************************
 */
void fp_print_interface(struct IfData *logicalIf)
{
#if 0
	int32a i = 0;

	for (i = 0; i < 4; i++) {
		pr_debug("INTERFACE: %d\n", i);
		logicalIf++;
	}
#endif
}

/*****************************************************************************
 * Function name     : fp_device_check()
 * Description       : This function check input device is vlan device
 *                     or normal device
 * Input  Parameters : struct sk_buff*
 * Output Parameters : -
 * Return            : int
 * Changes           :
 *****************************************************************************
 */
int32a fp_device_check(struct sk_buff *skb)
{
	int8 devName[20] = "";
	struct net_device *dev = (struct net_device *)skb->dev;

	if (dev != NULL)
		strcpy(devName, dev->name);
	if (devName[5] == '.')
		return 1;
	return 0;
} /*End of fp_device_check() Function*/

/*****************************************************************************
 * Function name     : fp_hooks_linklayer_parsing()
 * Description       : This function parse and set flags for interface match,
 *                     extarct vlanid and sessionid, tells ipv4 or ipv6 type
 *                     ,set parse flags and add interface if not exists.
 * Input  Parameters : struct sk_buff*, int, struct net_device*
 * Output Parameters : -
 * Return            : struct IfData*
 * Changes           :
 ****************************************************************************
 */
#if 1
struct IfData *fp_hooks_linklayer_parsing(struct sk_buff *skb, int32a phyno,
					struct net_device *txdev)
{
	uint16 usLength;
	struct ethhdr *eth_hdr = NULL;
	struct vlanEthhdr *vlanEthHdr = NULL;
	struct fp_pppoe_hdr  *pppoeEthHdr = NULL;
	struct fp_pppoe_vlan_hdr *pppoeVlanEthHdr = NULL;
	uint16 eth_type = 0, pkt_parse_flags = 0;
	int32a flag = 0, vlanid = 0, sid = 0, ucCurLogicalIfs = 0, index = 0;
	struct IfData *logicalIf = NULL, if_data;
	struct phyPort *phyport = NULL;
	uint16 ifParseFlags = 0, if_eth_type = 0;
	uint16  if_vlan_type = 0, if_pppoe_type = 0, type = 0;

	eth_hdr = (struct ethhdr *)skb->data;
	eth_type = ntohs(eth_hdr->h_proto);
#define ETH_IP             (PARSE_ETH_TYPE)
#define VLAN_ETH           (PARSE_IP_TYPE|PARSE_VLAN_TYPE)
#define PPPOE_ETH          (PARSE_IP_TYPE|PARSE_PPPOE_TYPE)
#define PPPOE_VLAN_ETH     (PARSE_IP_TYPE|PARSE_VLAN_TYPE|PARSE_PPPOE_TYPE)
	usLength = ETH_SMAC_DMAC_SIZE;
	while (1) {
		if (eth_type == PROTOCOL_IP) {
			pkt_parse_flags |= PARSE_IP_TYPE;
			ifParseFlags |= IF_MATCH_PHYPORT;
			if_eth_type = 1;
			/* adjust length for IP header */
			usLength = usLength + ETH_PROTO_SIZE;
			break;
		} else if (eth_type == PROTOCOL_IPV6) {
			pkt_parse_flags |= PARSE_IPV6_TYPE;
			ifParseFlags |= IF_MATCH_PHYPORT;
			if_eth_type = 1;
			/* adjust length for IP header */
			usLength = usLength + ETH_PROTO_SIZE;
			pr_debug("%s:IPV6 Pkt\n", __func__);
			break;
		} else if (eth_type == PROTOCOL_ARP) {
			/* set packet type as ARP in the pktbuf */
			pkt_parse_flags |= PARSE_ARP_TYPE;
			return NULL;
		} else if (eth_type == PROTOCOL_VLAN) {
			/*
			 * set packet type as VLAN in the pktbuf and get next
			 * protocol and continue
			 */
			pkt_parse_flags |= PARSE_VLAN_TYPE;
			ifParseFlags |= IF_MATCH_VLAN;
			if_vlan_type = 1;
			vlanEthHdr = (struct vlanEthhdr *)skb->data;
			vlanid = ntohs(vlanEthHdr->h_vlan_TCI) & 0xFFF;
			pr_debug("Hooks Parsing: Vlan ID %u\n", vlanid);

			/* adjust VLAN header length */
			usLength = usLength + VLAN_HDR_SIZE;
			eth_type = *(uint16 *)(skb->data + usLength);
			eth_type = ntohs(eth_type);
		} else if (eth_type == PROTOCOL_PPPOE) {
			/* set packet type as PPPOE data type,get next prot*/
			pkt_parse_flags |= PARSE_PPPOE_TYPE;
			ifParseFlags |= IF_MATCH_PPPOE;
			if_pppoe_type = 1;
			if (pkt_parse_flags & PARSE_VLAN_TYPE) {
				pppoeVlanEthHdr =
					(struct fp_pppoe_vlan_hdr *) skb->data;
				sid = ntohs(pppoeVlanEthHdr->sid);
			} else {
				pppoeEthHdr = (struct fp_pppoe_hdr *)skb->data;
				sid = ntohs(pppoeEthHdr->sid);
			}
			pr_debug("%s:Hooks Parsing: SID %u\n", __func__, sid);

			/* adjust header length */
			usLength = usLength + PPPOE_HDR_SIZE;
			eth_type = *(uint16 *)(skb->data + usLength);
			eth_type = ntohs(eth_type);
			if (eth_type == PROTOCOL_PPP_IPV4)
				eth_type = PROTOCOL_IP;
			else if (eth_type == PROTOCOL_PPP_IPV6)
				eth_type = PROTOCOL_IPV6;

		} else {
			/* unknown ethernet packet type, bail out */
			pr_err("%s:Hooks:UNKNOWN PROTOCOL type %x\n",
						__func__, eth_type);
			return NULL;
		}
	}

	/* Getting physical port from skb */
	phyport = (struct phyPort *)skb->fpNf2CacheFlow.phyTxPort;

	/* get the interfacef type */
	if (if_eth_type && if_vlan_type && if_pppoe_type) {
		type = IF_PPPOE_VLAN;
		phyport->commonIfFlags |= IF_MATCH_VLAN;
		phyport->commonIfFlags |= IF_MATCH_PPPOE;
	} else if (if_vlan_type && if_eth_type) {
		type = IF_VLAN;
		phyport->commonIfFlags |= IF_MATCH_VLAN;
	} else if (if_pppoe_type && if_eth_type) {
		type = IF_PPPOE;
		phyport->commonIfFlags |= IF_MATCH_PPPOE;
	} else {
		type = IF_ETH;
	}

	/*Getting interface from interface structure based on phynumber*/
	logicalIf = (struct IfData *)&gIfPorts[phyno][0];

	/*Printt interface info*/
	fp_print_interface(logicalIf);

	skb->fpNf2CacheFlow.parseFlags = pkt_parse_flags;

	/*Packet is ethernet type no need to add interface*/
	if (type == IF_ETH)
		return logicalIf;

	/* loop for all logical interfaces */
	while (ucCurLogicalIfs < phyport->curLogicalIfs) {

		/* create new logical interface and assign */
		switch (logicalIf->type) {
		case IF_VLAN:
			if ((logicalIf->ifMatchFlags & IF_MATCH_VLAN) &&
			(logicalIf->vlan == vlanid) &&
			(!(logicalIf->ifMatchFlags & IF_MATCH_PPPOE)))
				return &gIfPorts[phyno][ucCurLogicalIfs];

			flag = true;
			break;

		case IF_PPPOE:
			if ((logicalIf->ifMatchFlags & IF_MATCH_PPPOE) &&
					(logicalIf->inSessid == sid))
				return &gIfPorts[phyno][ucCurLogicalIfs];

			flag = true;
			break;

		case IF_PPPOE_VLAN:
			if (((logicalIf->ifMatchFlags & IF_MATCH_PPPOE) &&
				(logicalIf->ifMatchFlags & IF_MATCH_VLAN)) &&
					((logicalIf->vlan == vlanid) &&
					(logicalIf->inSessid == sid)))
				return &gIfPorts[phyno][ucCurLogicalIfs];

			flag = true;
			break;
		case IF_ETH:
			if (ucCurLogicalIfs == 0) {
				flag = true;
			} else {
				flag = false;
				index = ucCurLogicalIfs;
			}
			break;
		default:
			break;
		} /*End of switch */

		logicalIf++;
		ucCurLogicalIfs++;
	}

	/*Condition check to add interface*/
	if (flag == true) {
#ifndef NOTIFIER_EN
		phyport->curLogicalIfs++;
		logicalIf->phyPort = phyno;
		logicalIf->ifMatchFlags  = ifParseFlags;
		logicalIf->type = type;
		logicalIf->inSessid = sid;
		logicalIf->vlan = vlanid;
		logicalIf->valid = 1;
		logicalIf->mac[0] = txdev->dev_addr[0];
		logicalIf->mac[1] = txdev->dev_addr[1];
		logicalIf->mac[2] = txdev->dev_addr[2];
		logicalIf->mac[3] = txdev->dev_addr[3];
		logicalIf->mac[4] = txdev->dev_addr[4];
		logicalIf->mac[5] = txdev->dev_addr[5];
		/* initialize the stats pointers */
		logicalIf->ifNum = ucCurLogicalIfs;
		logicalIf->rtv4Table = fp_router_hash_table;
		logicalIf->u.rtv6Table = NULL;
		logicalIf->ifadmin_status = FP_IF_ADMIN_STATUS_DOWN;
		pr_debug("%s:HOOKS: new interface added succinterface no: %d\n",
						__func__, ucCurLogicalIfs);
#ifdef _FP_PCI_LINUX
		memset((uint8 *)&if_data, 0,
					sizeof(struct IfData));
		memcpy((void *)&if_data, (void *)logicalIf,
					sizeof(struct IfData));
		fp_download_logif_cfg(NFP_DEV_INFO(txdev)->real_dev, &if_data);
#endif /*End of_FP_PCI_LINUX*/
		return logicalIf;
#endif /*End of NOTIFIER_EN*/
	} else {
		return &gIfPorts[phyno][ucCurLogicalIfs];
	}
	skb->fpNf2CacheFlow.parseFlags = 0;
	sid = 0;
	vlanid = 0;
	flag = false;

	return NULL;
}
#endif

#if CONFIG_VLAN_8021Q
/*****************************************************************************
 * Function name     : fp_get_vlanid()
 * Description       : This function extracts the vlan id from the
 *                     packet and returns it.
 * Input  Parameters : struct sk_buff*
 * Output Parameters : -
 * Return            : uint16
 * Changes           : -
 *****************************************************************************
 */
uint16 fp_get_vlanid(struct sk_buff *skb)
{
	uint16  vlan_TCI, vid;
	struct vlan_hdr *pVlanHdr = (struct vlan_hdr *)((int8 *) skb->data +
						sizeof(struct ethhdr));

	vlan_TCI = ntohs(pVlanHdr->h_vlan_TCI);
	vid      = (vlan_TCI & 0xFFF);

	return vid;
}
#endif

/*****************************************************************************
 * Function name     : fp_get_final_proto_by_ct()
 * Description       : This function gets the final protocol from the ct
 * Input  Parameters : struct nf_conntrack *
 * Output Parameters : -
 * Return            : int8
 * Changes           : -
 *****************************************************************************
 */
static int8 fp_get_final_proto_by_ct(struct nf_conntrack *nfct,
	uint8 proto, enum   ip_conntrack_info ctinfo)
{
	struct nf_conn *ct    = (struct nf_conn *)nfct;
	struct nf_conntrack_tuple   *tuple;
	int32a dir = 0;

	/*Condition check for connection reply for established flow*/
	dir    = CTINFO2DIR(ctinfo);
	/*Tuple to get 5Tuple values*/
	tuple = &(ct->tuplehash[dir].tuple);
	if (ct) {
		if (tuple && ((tuple->dst.protonum == IPPROTO_TCP)
		|| (tuple->dst.protonum == IPPROTO_UDP)))
			return tuple->dst.protonum;
	}

	return proto;
}

/****************************************************************************
 *Function name   : fp_route_hook
 *Description     : This function is registered at pre and post hook with
 *                  last priority.
 *                  1.This function verifies the FP support for the incoming
 *                    and outgoing device.If there is no support it just
 *                    returns to netfilter architecture.
 *                  2.It checks the ip/udp/tcp headers to find the
 *                    information about the packet. The control flags of
 *                    fpNf2CacheFlow in skbuff are set based on the
 *                    information in the packet.
 *Input Parameters: hooknum
 *                  skb   - skbuff pointer
 *                  indev - pointer to incoming device (can be null at POST
 *                          ROUTING hook -if the packet is generated from
 *                          the stack)
 *                  outdev- ptr to outgoing device (NULL at PREROUTING)
 *                  okfn  - The function to be called after all hooks if
 *                          they have returned success.
 *Output Parameters: -
 *Return           : Return verdicts like NF_ACCEPT/NF_DROP to return to net
 *                   filter frame work.
 *Changes          : -
 ****************************************************************************
 */
uint32a fp_route_hook(void *priv, struct sk_buff *skb,
				const struct nf_hook_state *state)

{
	struct nf_conn      *ct;
	struct nf_conn_help *help;
	enum   ip_conntrack_info ctinfo;
	struct iphdr             *piph;
	struct tcphdr            *ptcp;
	uint8  verbyte;

	/*Print whole skb elements*/
	if (skb == NULL)
		return NF_ACCEPT;

	//fp_print_skbuff(skb);
	/*Condition check for RX phyport*/
	if (skb->fpNf2CacheFlow.phyRxPort == NULL) {
		//printk("rx phy port not coming\n");
		return NF_ACCEPT;
	}

	/* If there is no dynamic connection structure return. RFT entries
	 * can be added only if connection tracking is enabled
	 */

	/* Save the connection tracking information into the fpNf2CacheFlow
	 * structure as this information is lost as soon as the skb leaves
	 * the hook function This change is added according to 2.6.12 kernel.
	 */
	ct = nf_ct_get(skb, &ctinfo);

	if (ct == NULL) {
		/* printk("ct is NULL ctinfo = %x\n", ctinfo); */
		return NF_ACCEPT;
	}

	/*Getting nfct of skb to our structure*/
	skb->fpNf2CacheFlow.nfct = (struct nf_conntrack *)ct;
	/* Get the pointer to ip header */
	piph = (struct iphdr *)((uint8 *)skb_network_header(skb));

	/* Get the pointer to tcp header */
	ptcp = (struct tcphdr *)((uint8 *)piph + (piph->ihl * 4));
	verbyte = (*(uint8 *)piph);

	/* If the packet is TCP connection oriented packet (like SYN/FIN/RST)
	 * return.
	 */
	/* Condition check for IPV6 & IPV4 */
	if ((verbyte >> 4) == FP_IPV4) {
		if (ip_protocol == IPPROTO_TCP) {
			pr_debug("%s: Protocol is TCP\r\n", __func__);
			if (ptcp->fin || ptcp->syn || ptcp->rst) {
				pr_debug("%s: pkt is SYN:%x FIN:%x RST:%x \r\n",
				__func__, ptcp->syn, ptcp->fin, ptcp->rst);
				return NF_ACCEPT;
			}
		} /*End of ipv4 tcp if condition*/
	} else if ((verbyte >> 4) == FP_IPV6) {
		struct fp_ipv6_hdr_t *ipv6hdr =
			(struct fp_ipv6_hdr_t *)skb_network_header(skb);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0)
		int8 nexthdr = fp_get_final_proto_by_ct(skb_nfct(skb),
#else
		int8 nexthdr = fp_get_final_proto_by_ct(skb->nfct,
#endif
					ipv6hdr->next_hdr, ctinfo);

		if (nexthdr == IPPROTO_TCP) {
			if (ptcp->fin || ptcp->syn || ptcp->rst) {
				pr_debug("%s: pkt is SYN:%x FIN:%x RST:%x \r\n",
				__func__, ptcp->syn, ptcp->fin, ptcp->rst);
				return NF_ACCEPT;
			}
		} /*End of ipv6 tcp if condition*/
	} else {
		pr_debug("%s:Unknown version of ip\n", __func__);
	} /*End of version check IF condition*/

	/* Get the pointer to dynamic connection
	 * tracking structure for the flow
	 */
	//ct = (struct nf_conn *)skb->_nfct;
	//ctinfo = skb->nfctinfo;

	/* If any helper function is registered for any traffic(ex: Algs),
	 * that traffic has to be examined for details of data connections.
	 * So for those type of connections CONTROL_FLOW bit is enabled in
	 * control flags
	 */

	help = (struct nf_conn_help *)nfct_help(ct);

	if (help != NULL) {
		if (help->helper)
			skb->fpNf2CacheFlow.controlFlags = CONTROL_FLOW;
	}

	/* If the connection is in established state then enable the
	 * ESTABLISHED_FLOW in control flags. For UDP traffic , even it is
	 * not established enable the flag. This is because there are
	 * sometimes where we have traffic in only one direction .For
	 * all the other conditions just return
	 */

	if (test_bit(IPS_ASSURED_BIT, &ct->status)) {
		pr_debug("%s:ct status = %lx\r\n", __func__, ct->status);
		skb->fpNf2CacheFlow.controlFlags |= ESTABLISHED_FLOW;
	} else {
		/* If the protocol is UDP then set it ESTABLISHED even the
		 * flow is one direction
		 */
		/* Condition for version ipv4 & ipv6 */
		if ((verbyte >> 4) == FP_IPV6) {
			struct fp_ipv6_hdr_t *ipv6hdr =
				(struct fp_ipv6_hdr_t *)skb_network_header(skb);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0)
			int8 nexthdr = fp_get_final_proto_by_ct(skb_nfct(skb),
#else
			int8 nexthdr = fp_get_final_proto_by_ct(skb->nfct,
#endif
					ipv6hdr->next_hdr, ctinfo);

			if (nexthdr == IPPROTO_UDP)
				skb->fpNf2CacheFlow.controlFlags |=
							ESTABLISHED_FLOW;
			else
				return NF_ACCEPT;

		} else if ((verbyte >> 4) == FP_IPV4) {
			if (ip_protocol == IPPROTO_UDP) {
				skb->fpNf2CacheFlow.controlFlags |=
						ESTABLISHED_FLOW;
#ifdef DEBUG_HOST
				pr_debug("HOOKS: UDP Flow\n");
#endif
			} else {
				return NF_ACCEPT;
			}
		}
	} /*End of Ct status If condition*/

	/* As the packet is routed packet, FPROUTE_FLOW bit of
	 * controlFlags is enabled
	 */

	skb->fpNf2CacheFlow.controlFlags |= FPROUTE_FLOW;

	/* At the post routing hook store the skb->dev in postRtDev of skb.
	 * This postRtDev is stored here , as the skb->dev changes when it
	 * goes to the driver.
	 */

	if (state->hook == 4)
		skb->fpNf2CacheFlow.postRtDev = skb->dev;

	pr_debug("%s:Returning NF_ACCEPT..\r\n", __func__);

	return NF_ACCEPT;
}

/*****************************************************************************
 * Function name     : fp_flow_process()
 * Description       : This function checks all the data available
 *                     in skbuff  to add flow to Ethernets.
 * Input  Parameters : struct sk_buff*, struct net_device*
 * Output Parameters : -
 * Return            : int
 * Changes           : -
 ******************************************************************************
 */
int32a fp_flow_process(struct sk_buff *skb, struct net_device *txdev)
{
	struct phyPort *phyPort = NULL;
	struct IfData *ifPtr = NULL;

	skb->fpNf2CacheFlow.txDev = skb->dev;
	pr_debug("%s: dev name:%s\n", __func__, skb->dev->name);

	if ((NFP_DEV_INFO(txdev)->phyPortNo < 0) &&
		(NFP_DEV_INFO(txdev)->phyPortNo) >= FP_MAX_PORTS) {

		pr_err("%s: Invalid phyport no at %x\n",
				__func__, NFP_DEV_INFO(txdev)->phyPortNo);
		return 0;
	}

	phyPort = (struct phyPort *)&gPhyPorts[NFP_DEV_INFO(txdev)->phyPortNo];

	if (!skb->fpNf2CacheFlow.rxDev)
		return -1;

	/* Check for physical port*/
	if (!phyPort) {
		pr_debug("HOOKS PHYPort NULL\n");
		return 0;
	}

	/* Intialise physical port in fp structure in skbuff*/
	skb->fpNf2CacheFlow.phyTxPort = phyPort;

	pr_debug("\n%s: skb->fpNf2CacheFlow.phyTxPort = %p \r\n",
		__func__, skb->fpNf2CacheFlow.phyTxPort);
	pr_debug("%s: skb->fpNf2CacheFlow.pIfTxPort = %p \r\n",
		__func__, skb->fpNf2CacheFlow.pIfTxPort);
	pr_debug("\n%s: skb->fpNf2CacheFlow.phyRxPort = %p \r\n",
		__func__, skb->fpNf2CacheFlow.phyRxPort);
	pr_debug("%s: skb->fpNf2CacheFlow.pIfRxPort = %p \r\n",
		__func__, skb->fpNf2CacheFlow.pIfRxPort);
	pr_debug("\n%s: rx Dev = %p \r\n",
		__func__, skb->fpNf2CacheFlow.rxDev);
	pr_debug("%s: tx Dev = %p \r\n",
		__func__, skb->fpNf2CacheFlow.txDev);

	/* Check the bridge state to update the port status to FP */
	pr_debug("%s: skb = %p\r\n", __func__, skb);

	fp_print_skbuff(skb);

	/*
	 * return without adding FLOW entry to FPs when tx
	 * device doen't have any  FP support
	 */

	if (!((skb->fpNf2CacheFlow.phyTxPort) &&
			(skb->fpNf2CacheFlow.phyRxPort))) {
		pr_err("%s: invalid phyTxPort:%p  and phyRxPort: %p\r\n",
			__func__, skb->fpNf2CacheFlow.phyTxPort,
				skb->fpNf2CacheFlow.phyRxPort);
		goto saferet;
	}

	/* Adding dynamic logical interface pointer in skb fastpath */
	ifPtr = fp_hooks_linklayer_parsing(skb, phyPort->phyno, txdev);
	if (ifPtr != NULL) {
		skb->fpNf2CacheFlow.pIfTxPort = ifPtr;
		NFP_DEV_INFO(txdev)->ifnum = ifPtr->ifNum;
	} else {
		skb->fpNf2CacheFlow.pIfTxPort = NULL;
		pr_err("TX INTERFACE FAIL\n");
	}

	/* If the flow is not established , dont add flow entry */
	if ((skb->fpNf2CacheFlow.controlFlags & ESTABLISHED_FLOW) == 0) {
		pr_debug("%s: FLOW is not established\r\n", __func__);
		goto saferet;
	}

	/* return, if the connection is Control type */
	if (skb->fpNf2CacheFlow.controlFlags & CONTROL_FLOW) {
		FPATH_TRACE(FP_TRACE_NF_HOOKS, FP_LOG_INFO,
		pr_debug("%s: FLOW is CONTROL type \r\n", __func__));
		goto saferet;
	}

	if (skb->fpNf2CacheFlow.controlFlags & FPROUTE_FLOW) {
		pr_debug("%s: This is Route flow pkt\r\n", __func__);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0)
		pr_debug("%s: nfct = %p\r\n", __func__, skb_nfct(skb));
#else
		pr_debug("%s: nfct = %p\r\n", __func__, skb->nfct);
#endif
		fp_routeflow_process(skb, txdev);
	}
saferet:
	memset(&skb->fpNf2CacheFlow, 0, sizeof(struct fpFlowInfo));
	return 0;
}

uint32a fp_xfrm_proto(uint8 proto)
{
#ifdef _FEATURE_L2TP_
	if (proto ==  IPPROTO_GRE)
		return 1;
#endif
#if 0
#ifdef FP_IPSEC
	if ((proto ==  FP_PROTO_ESP) || (proto ==  FP_PROTO_AH))
		return 1;
#endif
#endif
	return 0;
}

/*****************************************************************************
 * Function name     : fp_routeflow_process()
 * Description       : This function extract route flow info available in
 *                     skbuff and add flow entry to corresponding Rx Ehternet
 * Input  Parameters : struct sk_buff*
 * Output Parameters : -
 * Return            : void
 * Changes           : -
 *****************************************************************************
 */
void fp_routeflow_process(struct sk_buff *skb, struct net_device *txdev)
{
	struct nf_conn *ct = NULL;
	enum   ip_conntrack_info ctinfo;
	struct nf_conntrack *ct_gen = NULL;
	struct nf_conntrack_tuple *tuple = NULL;
	struct cacheFlow *pFlow = NULL, flow;
	struct IfData *Ifdata = NULL;
	struct fp_router_table *RouteTable = NULL;
	struct ethhdr *ethhdr = NULL;
	int32a header_len  = 0;
	uint16	hash;
	uint32a dir;

	pr_debug("%s: skb = %p\r\n", __func__, skb);

	/* All checkings are over by this time, just add Route Flow Entries
	 * using information in skb and conntrack.
	 */
	/* return, if there is no dynamic connection structure */
	if (skb->fpNf2CacheFlow.nfct == NULL) {
		pr_debug("%s: NO Connection tracking entry available\r\n",
							__func__);
		pr_debug("NFCT NULL\n");
		return;
	}

	/*Condition check for fragment flow*/
	if (skb->fpNf2CacheFlow.parseFlags & PARSE_FRAG_FLOW) {
		pr_debug("FRAGMENT FLAG SET\n");
		return;
	}

	/* Initalize required fields of fpFlowEntry structure */
	memset(&flow, 0, sizeof(flow));
	ct = nf_ct_get(skb, &ctinfo);
	/*Getting connection tracking entry from skb fastpath structure*/
	ct     = (struct nf_conn *)skb->fpNf2CacheFlow.nfct;
	ct_gen = (struct nf_conntrack *)&ct->ct_general;

	/*Checking nf_conntrack structure*/
	if (ct_gen == NULL)
		return;
	//ctinfo = skb->nfctinfo;
	dir    = CTINFO2DIR(ctinfo);

	/*Tuple to get 5Tuple values*/
	tuple = &(ct->tuplehash[dir].tuple);
#ifdef DEBUG_PCI1
	pr_debug("src port:%d dst port %d\n",
		tuple->src.u.tcp.port, tuple->dst.u.tcp.port);
	pr_debug("src port:%d dst port %d\n",
		ntohs(tuple->src.u.tcp.port), ntohs(tuple->dst.u.tcp.port));
#endif
#if 0
	if (tuple->dst.protonum == IPPROTO_IPV6) {

		/*Set flag to update remote and local ip addresses*/
		sixrd_flag = 1;
		saddr =  ntohl(tuple->src.u3.ip);
		daddr =  tuple->dst.u3.ip;

		/*Getting transport data for tunnel interface*/
		ctinfo = skb->fpNf2CacheFlow.phyno;
		dir = CTINFO2DIR(ctinfo);
		ct = (struct nf_conn *)skb->fpNf2CacheFlow.classFlags;
		ct_gen = (struct nf_conntrack *)&ct->ct_general;

		/*Extracting tuple information from CT*/
		tuple = &(ct->tuplehash[dir].tuple);
		flow.flowActionflags |= ADD_6RD_HEADER;
		skb->fpNf2CacheFlow.parseFlags |= PARSE_IPV6_TYPE;

		/*Check FTP control connection*/
		if ((ntohs(tuple->src.u.tcp.port) == 21) ||
			(ntohs(tuple->dst.u.tcp.port) == 21)) {
			/*FTP control connection*/
			return;
		}

	} /*End of tunnel interface if condition*/
	else if (tuple->dst.protonum ==  IPPROTO_IPIP) {

		/*Set flag to update remote and local ip addresses*/
		fourrd_flag = 1;
		/*Source ip address*/
		v6saddr[0] =  ntohl(tuple->src.u3.ip6[0]);
		v6saddr[1] =  ntohl(tuple->src.u3.ip6[1]);
		v6saddr[2] =  ntohl(tuple->src.u3.ip6[2]);
		v6saddr[3] =  ntohl(tuple->src.u3.ip6[3]);
		v6daddr[0] =  tuple->dst.u3.ip6[0];
		v6daddr[1] =  tuple->dst.u3.ip6[1];
		v6daddr[2] =  tuple->dst.u3.ip6[2];
		v6daddr[3] =  tuple->dst.u3.ip6[3];

		/*Getting transport data for tunnel interface*/
		ctinfo = skb->fpNf2CacheFlow.phyno;
		dir = CTINFO2DIR(ctinfo);
		ct = (struct nf_conn *)skb->fpNf2CacheFlow.classFlags;
		ct_gen = (struct nf_conntrack *)&ct->ct_general;

		/*Extracting tuple information from CT*/
		tuple = &(ct->tuplehash[dir].tuple);
		flow.flowActionflags |= ADD_4RD_HEADER;
		skb->fpNf2CacheFlow.parseFlags &= 0xFFFFFFBF;
		skb->fpNf2CacheFlow.parseFlags |= PARSE_IP_TYPE;

		/*Check FTP control connection*/
		if ((ntohs(tuple->src.u.tcp.port) == 21) ||
			(ntohs(tuple->dst.u.tcp.port) == 21)) {
			/*FTP control connection*/
			return;
		}
	} else if (fp_xfrm_proto(tuple->dst.protonum)) {

		tuple1 = tuple;
		ctinfo = skb->fpNf2CacheFlow.phyno;
		dir = CTINFO2DIR(ctinfo);
		ct = (struct nf_conn *)skb->fpNf2CacheFlow.classFlags;
		ct_gen = (struct nf_conntrack *)&ct->ct_general;
		tuple = &(ct->tuplehash[dir].tuple);
		skb->fpNf2CacheFlow.parseFlags |= PARSE_IP_TYPE;
	} /*End of tunnel interface if condition*/
#endif  /*End of Macro  6rd and 4rd Flow control*/

	/*Check FTP control connection*/
	if ((ntohs(tuple->src.u.tcp.port) == 21)
			|| (ntohs(tuple->dst.u.tcp.port) == 21)) {
		/*FTP control connection*/
		return;
	}

	/*Fastpath entry offload check*/
	if (ct_gen->fpCt2CacheFlow.rtEntry[dir])
		return;

	/*Getting incoming phyno*/
	Ifdata = (struct IfData *)skb->fpNf2CacheFlow.pIfRxPort;
	if (Ifdata == NULL) {
		pr_debug("%s: No RX Interface Table\n", __func__);
		return;
	}

	flow.inPhyPortNum = Ifdata->phyPort;
	Ifdata = NULL;
	Ifdata = (struct IfData *)skb->fpNf2CacheFlow.pIfTxPort;

	if (Ifdata == NULL) {
		pr_debug("%s: No TX Interface Table\n", __func__);
		return;
	}

	/*Filling Interface and tx port*/
	flow.ifPortNum   = Ifdata->ifNum;
	flow.phyPortNum  = Ifdata->phyPort;

	pr_debug("%s: direction for tuple :%d \r\n", __func__, dir);
	tuple = &(ct->tuplehash[dir].tuple);
	pr_debug("%s: tuple :%p \r\n", __func__, tuple);

	/* At present writing code to handle only UDP and TCP traffic. */
	if (tuple->dst.protonum == IPPROTO_UDP)
		flow.matchFlags |= MATCH_UDP_TUPLE;
	else if (tuple->dst.protonum == IPPROTO_TCP)
		flow.matchFlags |= MATCH_TCP_TUPLE;
	else
		return;

	/* IPV6, copy 5 tuple information into FP flow_entry */
	if (skb->fpNf2CacheFlow.parseFlags & PARSE_IPV6_TYPE) {

		/*Source ip address*/
		flow.u.v6.src_ipv6[0] = tuple->src.u3.ip6[0];
		flow.u.v6.src_ipv6[1] = tuple->src.u3.ip6[1];
		flow.u.v6.src_ipv6[2] = tuple->src.u3.ip6[2];
		flow.u.v6.src_ipv6[3] = tuple->src.u3.ip6[3];

		/*Destination ip address*/
		flow.u.v6.dst_ipv6[0] = tuple->dst.u3.ip6[0];
		flow.u.v6.dst_ipv6[1] = tuple->dst.u3.ip6[1];
		flow.u.v6.dst_ipv6[2] = tuple->dst.u3.ip6[2];
		flow.u.v6.dst_ipv6[3] = tuple->dst.u3.ip6[3];

	} else if (skb->fpNf2CacheFlow.parseFlags & PARSE_IP_TYPE) {

		flow.u.v4.srcIP             = tuple->src.u3.ip;
		flow.u.v4.dstIP             = tuple->dst.u3.ip;
		pr_debug("%s:Srcip:%xDstip:%xtuplesrcip:%x,tupledstip:%x\r\n",
				__func__, flow.u.v4.srcIP, flow.u.v4.dstIP,
				tuple->src.u3.ip, tuple->dst.u3.ip);
	} else {
		pr_debug("%s:Unknown ip version\n", __func__);
	}

	flow.Proto = (uint8)tuple->dst.protonum;

	/* why dst.protonum and piph->protocol */
	pr_debug("%s: tuple protocol:%x  flow:%d\r\n",
		__func__, (uint8)tuple->dst.protonum & 0xff,
							flow.Proto);
	switch (flow.Proto) {
	case IPPROTO_TCP:
		flow.srcPort = tuple->src.u.tcp.port;
		flow.dstPort = tuple->dst.u.tcp.port;
		pr_debug("%s: TCP\r\n", __func__);
		break;
	case IPPROTO_UDP:
		flow.srcPort = tuple->src.u.udp.port;
		flow.dstPort = tuple->dst.u.udp.port;
		pr_debug("%s: UDP\r\n", __func__);
		break;
	case IPPROTO_IPV6:
		break;
	case  IPPROTO_IPIP:
		break;
	default:
		pr_debug("%s: flow.srcIPAddr:%x \r\n",
				__func__, flow.u.v4.srcIP);
		pr_debug("%s: flow.dstIPAddr:%x \r\n",
				__func__, flow.u.v4.dstIP);
		pr_debug("%s: this protocol:%x is not yet supported\r\n",
				__func__, flow.Proto);
		return;
	} /*End of protocol switch*/

	pr_debug("%s: ct->status = %lx\r\n", __func__, ct->status);

	/*Sett TTL Decrement Flag*/
	flow.flowActionflags |= SET_TTL_DECREMENT;

	/*Setting of NAT flags*/
	if (ct->status & IPS_SRC_NAT) {
		if (dir == IP_CT_DIR_ORIGINAL) {
			flow.flowActionflags |= CHANGE_SIP_ADDR;
			flow.flowActionflags |= CHANGE_SPORT;

			pr_debug("%s-SNAT: dir:%d, ip:[%x %x], port:[%x %x]\n",
			__func__, dir,
			(uint32a)ct->tuplehash[!dir].tuple.src.u3.ip,
			(uint32a)ct->tuplehash[!dir].tuple.dst.u3.ip,
			(int32a)ntohs(
				ct->tuplehash[!dir].tuple.src.u.tcp.port),
			(int32a)ntohs(
				ct->tuplehash[!dir].tuple.dst.u.tcp.port));

			flow.chgSrcIp = ct->tuplehash[!dir].tuple.dst.u3.ip;
			flow.chgSrcPort =
				ct->tuplehash[!dir].tuple.dst.u.tcp.port;

		} else if (dir == IP_CT_DIR_REPLY) {
			flow.flowActionflags |= CHANGE_DIP_ADDR;
			flow.flowActionflags |= CHANGE_DPORT;

			pr_debug("%s-SNAT: R dir[%d], IP[%x:%x] PORT[%x %x]\n",
				 __func__, (int32a)dir,
			(uint32a)ct->tuplehash[!dir].tuple.src.u3.ip,
			(uint32a)ct->tuplehash[!dir].tuple.dst.u3.ip,
			(uint32a)ntohs(
				ct->tuplehash[!dir].tuple.src.u.tcp.port),
			(uint32a)ntohs(
				ct->tuplehash[!dir].tuple.dst.u.tcp.port));

			flow.chgDstIp = ct->tuplehash[!dir].tuple.src.u3.ip;
			flow.chgDstPort =
				ct->tuplehash[!dir].tuple.src.u.tcp.port;
		}
	} else if (ct->status & IPS_DST_NAT) {
		if (dir == IP_CT_DIR_ORIGINAL) {
			flow.flowActionflags |= CHANGE_DIP_ADDR;
			flow.flowActionflags |= CHANGE_DPORT;

			pr_debug("%s-DNAT: O dir[%d],IP[%x:%x] PORT[%x:%x]\n",
			 __func__, (int32a)dir,
			(uint32a)ct->tuplehash[!dir].tuple.src.u3.ip,
			(uint32a)ct->tuplehash[!dir].tuple.dst.u3.ip,
			(uint32a)ntohs(
				ct->tuplehash[!dir].tuple.src.u.tcp.port),
			(uint32a)ntohs(
				ct->tuplehash[!dir].tuple.dst.u.tcp.port));

			flow.chgDstIp  = ct->tuplehash[!dir].tuple.src.u3.ip;
			flow.chgDstPort =
				ct->tuplehash[!dir].tuple.src.u.tcp.port;
		} else if (dir == IP_CT_DIR_REPLY) {
			flow.flowActionflags |= CHANGE_SIP_ADDR;
			flow.flowActionflags |= CHANGE_SPORT;

			pr_debug("%s-DNAT: R dir[%d], IP[%x:%x PORT[%x:%x]\n",
			__func__, (int32a) dir,
			(uint32a)ct->tuplehash[!dir].tuple.src.u3.ip,
			(uint32a)ct->tuplehash[!dir].tuple.src.u3.ip,
			(uint32a)ntohs(
				ct->tuplehash[!dir].tuple.src.u.tcp.port),
			(int32a)ntohs(
				ct->tuplehash[!dir].tuple.dst.u.tcp.port));

			flow.chgSrcIp = ct->tuplehash[!dir].tuple.dst.u3.ip;
			flow.chgSrcPort =
				ct->tuplehash[!dir].tuple.dst.u.tcp.port;
		}
	}
    /* FP RFT */
#if 0
	if (skb->fpNf2CacheFlow.rxDev->type == ARPHRD_PPP) {
		pr_debug("%s: Incoming packet is from ppp\n", __func__);
		if (skb->fpNf2CacheFlow.sessionId) {
			pr_debug("%s: Incoming packet is from pppoe", __func__);
			pr_debug("with sessionid :%d\r\n",
				skb->fpNf2CacheFlow.sessionId));
			flow.inSessionId = skb->fpNf2CacheFlow.sessionId;
			flow.operations |= (0x1 << FP_CHECK_PPPOE_BIT);
		}
	}
#endif

	/* copy link layer information into FP flow_entry */
	switch (skb->fpNf2CacheFlow.txDev->type) {

	case ARPHRD_ETHER:
		pr_debug("%s: In ARPHRD_ETHER \r\n", __func__);
		ethhdr = (struct ethhdr *)(skb->data);
		memcpy(flow.dstMacAddr, ethhdr->h_dest, 6);
		memcpy(flow.srcMacAddr, skb->dev->dev_addr, 6);

		flow.flowActionflags |= ADD_ETH_HDR;

		if (skb->fpNf2CacheFlow.postRtDev !=
				skb->fpNf2CacheFlow.txDev) {

			/* PPPOE-ATM, PPPOE-ETH, PPPOE-VLAN-ETH, VLAN-ETH */

			if ((ntohs(((struct ethhdr *)skb->data)->h_proto)
							!= ETH_P_8021Q) &&
			(ntohs(((struct ethhdr *) skb->data)->h_proto)
							!= ETH_P_PPP_SES) &&
			(ntohs(((struct ethhdr *) skb->data)->h_proto)
							!= ETH_P_IP) &&
			(ntohs(((struct ethhdr *) skb->data)->h_proto)
							!= ETH_P_IPV6)) {

				pr_debug("%s:eth proto %x is not supported\r\n",
					__func__,
					(uint32a)ntohs(eth_hdr(skb)->h_proto));
				return;
			}

			/*Condition check for PPPOE*/
			if (skb->fpNf2CacheFlow.parseFlags &
						PARSE_PPPOE_TYPE) {
				/* If PPPOE header exists, get PPPOE sess ID */
				Ifdata = (struct IfData *)
					skb->fpNf2CacheFlow.pIfTxPort;

				if (Ifdata != NULL)
					skb->fpNf2CacheFlow.pppoeSesId =
							Ifdata->inSessid;

				pr_debug("%s: PPPoE Packet - SessionId:%d \r\n",
					__func__,
					(uint32a)skb->fpNf2CacheFlow.pppoeSesId);

				/*
				 * Get the remote mac address for pppoe packet
				 * For LLC encapsulated packet get the remote
				 * mac address by skipping llc header
				 */
				/* Now extract the destination mac address */
				ethhdr = (struct ethhdr *)
					(skb->data + header_len);
				memcpy(flow.dstMacAddr, ethhdr->h_dest, 6);

				flow.pppoeSesId = ntohs(
					skb->fpNf2CacheFlow.pppoeSesId);
#ifdef DEBUG_HOST
				pr_debug("HOST-pppoesid:%x\n",
					skb->fpNf2CacheFlow.pppoeSesId);
#endif
				flow.flowActionflags |= ADD_ETH_HDR;
				flow.flowActionflags  |= ADD_PPPOE_HDR;
			} /*End of PPPOE If condition*/

			/* VLAN implementation */
#if CONFIG_VLAN_8021Q
			/* Adding code for VLAN. If packet type is VLAN, extract
			 * vlan id and add the operations in FP accordingly
			 */
			if (skb->fpNf2CacheFlow.parseFlags & PARSE_VLAN_TYPE) {
				uint16 vid = 0;
				/* VLAN header exists, so get VLAN information
				 * check whether PPPOE protocol exists inside
				 * VLAN header. If yes, get PPPOE session ID,
				 * set flags in flow_entry for VLAN
				 * and PPPOE protocols
				 */

				pr_debug("%s: VLAN Packet Processing (ETH)\r\n",
								__func__);

				Ifdata = (struct IfData *)
					skb->fpNf2CacheFlow.pIfTxPort;
				if (Ifdata != NULL)
					vid  =  Ifdata->vlan;
				pr_debug("%s: Vlan Id : %d\r\n",
						__func__, (int32a) vid);

				flow.vlanId      = ntohs(vid);
				flow.flowActionflags |= ADD_VLAN_HDR;
			}
#endif
		}
		break;

	default:
		pr_debug("%s: this device HW type :%x is not yet supported\r\n",
			__func__, (uint32a)skb->fpNf2CacheFlow.txDev->type);
		return;

	}

	/* set the flow entry is valid */
	flow.entryState = ENTRY_VALID;
	flow.vflag = 0;
	flow.classNotifyFlags = ROUTE_ENTRY_ACTIVE;
	//flow.ct.addr = (void *)((uint32)ntohl((uint32)ct));
	flow.ct.addr = (void *)(uint32)ct;
#ifdef DEBUG_HOST
	pr_debug("FLOw:%x\n", flow.flowActionflags);
	pr_debug("FLOw:%x<-->%x\n", flow.flowActionflags,
			ntohl(flow.flowActionflags));
	pr_debug("USERINFO:%p\n", flow.ct.addr);
	pr_debug("PHYNO: %d IFNO:%d\n", Ifdata->phyPort, Ifdata->ifNum);
#endif
	RouteTable = (struct fp_router_table *)Ifdata->rtv4Table;
	if (RouteTable  == NULL) {
		pr_debug("%s: No routing Table\n", __func__);
		return;
	}
	/*IP version check*/
	if (skb->fpNf2CacheFlow.parseFlags & PARSE_IPV6_TYPE) {
		flow.flag_ipv6 = PARSE_IPV6_TYPE;
		hash = ipv6_hash5Tuple(&flow, (ROUTE_HASH_SIZE-1));
		flow.hash = ntohs(hash);
		flow.flowActionflags = htonl(flow.flowActionflags);
		skb->fpNf2CacheFlow.v4Hash = hash;

		flow.vflag |= ROUTE_ENTRY_VALID;
		flow.vflag |= ROUTE_ENTRY_IPV6_VALID;
		flow.vflag = htonl(flow.vflag);
		pFlow =  fp_add_router_table_entry(hash, &flow, RouteTable);
	} else if ((skb->fpNf2CacheFlow.parseFlags & PARSE_IP_TYPE) &&
				(!ct_gen->fpCt2CacheFlow.rtEntry[dir])) {
		hash = hash5Tuple(&flow, (ROUTE_HASH_SIZE - 1));
		flow.flag_ipv6 = PARSE_IPV4_TYPE;
		skb->fpNf2CacheFlow.v4Hash = hash;
		pr_debug("%s: ADDING FLOW ENTRY to\r\n\n", __func__);
		pr_debug("%s:HASH:%x\n",
			__func__, (uint32a)skb->fpNf2CacheFlow.v4Hash);
		pr_debug("%s:Direction : %x\n", __func__, (uint32a)dir);
		fp_print_routeflow_entry(&flow);
		pr_debug("%s:FastPath Route entry:\n", __func__);
#ifdef DEBUG_HOST
		pr_debug("FLOW ACTIONS:%x vlan:%x\n",
					flow.flowActionflags, flow.vlanId);
#endif

#if 0
#ifdef FP_IPSEC
		if (skb->fpNf2CacheFlow.sec) {
			/* add ipsec info in route entry */
			flow.sa = (uint32a)((uint32)htonl(PCI_TO_PE(
				(uint32)(skb->fpNf2CacheFlow.sec))));
			flow.flowActionflags |= ADD_IPSEC_HDR;
		}
#endif
#endif
		flow.hash = hash;
		flow.flowActionflags = htonl(flow.flowActionflags);
		flow.vflag |= ROUTE_ENTRY_VALID;
		flow.vflag = htonl(flow.vflag);
		pFlow =  fp_add_router_table_entry(hash, &flow, RouteTable);
	} else {
		pr_debug("%s:Unknown ip version\n", __func__);
		return;
	} /*End of version check condition*/

	if (!pFlow) {
		pr_debug("%s:Entry Already Exists in Hash table\r\n",
							__func__);
		return;
	}
	pr_err("%s: FLOW ENTRY : %p ADDED SUCCESSFULLY at hash : %d\r\n\n",
		 __func__, pFlow, skb->fpNf2CacheFlow.v4Hash);
	/*
	 * copy FP flow_entry information into conntrack connection structure
	 * the below conntrack structure members need to be reviewed.
	 */
	pr_debug("%s: FLOW ENTRY : %p ADDED SUCCESSFULLY at hash : %d\r\n\n",
		 __func__, pFlow, skb->fpNf2CacheFlow.v4Hash);
#ifdef DEBUG_HOST
	pr_debug("%s: FLOW ENTRY : %p ADDED SUCCESSFULLY at hash : %d\r\n\n",
		__func__, pFlow, skb->fpNf2CacheFlow.v4Hash);
#endif
	ct_gen->fpCt2CacheFlow.rtEntry[dir]   = pFlow;
	ct_gen->fpCt2CacheFlow.hashValue[dir] = skb->fpNf2CacheFlow.v4Hash;
	ct_gen->fpCt2CacheFlow.pIfPort[dir]   = skb->fpNf2CacheFlow.pIfRxPort;
}

/*****************************************************************************
 * Function name     : fpRouteFlowDelete()
 * Description       : This function is called from destroy_conntrack function
 *                     to delete FP flow entries corresponding to connection
 *                     tracking flows
 * Input Parameters  : ptr - The connection tracking ptr to be deleted
 * Output Parameters : -
 * Result            : void
 * Changes           : -
 ******************************************************************************
 */
void fpRouteFlowDelete(void *ptr)
{
	struct nf_conn *ct = NULL;
	struct nf_conntrack *ct_gen = NULL;
	uint8       i;
	int32a Ret;
	struct IfData *Ifdata;
	struct fp_router_table *RouteTable;
	struct fpEntryInfo *pCacheFlow;

pr_err("fpRouteFlowDelete\n");
return;

	if (ptr == NULL)
		return;

	ct = (struct nf_conn *)ptr;
	if (ct == NULL)
		return;
	ct_gen = (struct nf_conntrack *)&ct->ct_general;
	pCacheFlow = &ct_gen->fpCt2CacheFlow;
#ifdef DEBUG_HOST
	pr_debug("CT:%p ct_gen:%p 0:%p, 1:%p\n",
		ct, ct_gen, pCacheFlow->rtEntry[0],
				pCacheFlow->rtEntry[1]);
#endif
	for (i = 0; i < MAX_RFTS_PER_FLOW; i++) {
		/* if RFT Pointer exists for the connection */
		if (pCacheFlow->rtEntry[i]) {
			pr_debug("%s: delete flow entry:%p \r\n",
			__func__, pCacheFlow->rtEntry[i]);
			Ifdata = (struct IfData *)
					pCacheFlow->pIfPort[i];

			if (Ifdata == NULL) {
				pr_debug("IFData null\n");
				return;
			}

			RouteTable = (struct fp_router_table *)
						Ifdata->rtv4Table;
			if (RouteTable == NULL) {
				pr_debug("Route table NULL\n");
				return;
			}

#ifdef DEBUG_HOST
			pr_debug("FLOW DELETE: HASH: %x RTENTRY:%p\n",
				pCacheFlow->hashValue[i],
				pCacheFlow->rtEntry[i]);
#endif

			/* Call the API to delete the entry from RF Table. */
			Ret = fp_delete_router_table_entry(
				(uint16)pCacheFlow->hashValue[i],
				(struct cacheFlow *)pCacheFlow->rtEntry[i],
				RouteTable);
			if (Ret == 0)
				pCacheFlow->rtEntry[i] = (struct cacheFlow *)NULL;
		} else {
			continue;
		}
	}
}

/*****************************************************************************
 * Function name     : fp_disable_fastpath()
 * Description       : This function sets all FP flow entry values to NULL
 *                     during clid request to disable fastpath
 * Input Parameters  : void
 * Output Parameters : -
 * Return            : void
 * Changes           : -
 *****************************************************************************
 */
void fp_disable_fastpath(void)
{
	struct fp_router_table *tblPtr = fp_router_hash_table;
	struct cacheFlow *rtEntry;
	struct nf_conn *ct;
	int32a i;

#ifdef HASH_ARR_EN
	/*For loop to fectch all hash table entries*/
	for (i = 0; i < tblPtr->tbl_size; i++) {
		if ((ntohl(grtHashArr[i].vflag) & ROUTE_ENTRY_VALID) == 0) {
			continue;
		} else {
			rtEntry = (struct cacheFlow *)(&grtHashArr[i]);
#else
	if (!tblPtr)
		return;

	/*For loop to fectch all hash table entries*/
	for (i = 0; i < tblPtr->tbl_size; i++) {
		if (!tblPtr->table[i]) {
			continue;
		} else {
			rtEntry = (struct cacheFlow *)
				PE_TO_PCI((uint32)tblPtr->table[i]);
#endif
			while (rtEntry != NULL) {
				ct = (struct nf_conn *)
				((uint32)rtEntry->ct.addr);
				//((uint32)ntohl(rtEntry->ct.addr));
				if (ct) {
					struct fpEntryInfo *pfpEntryInfo =
						&ct->ct_general.fpCt2CacheFlow;
					pfpEntryInfo->rtEntry[0] = NULL;
					pfpEntryInfo->rtEntry[1] = NULL;
					pfpEntryInfo->pIfPort[0] = NULL;
					pfpEntryInfo->pIfPort[1] = NULL;
					pfpEntryInfo->phyPort[0] = NULL;
					pfpEntryInfo->phyPort[1] = NULL;
					pfpEntryInfo->hashValue[0] = 0;
					pfpEntryInfo->hashValue[1] = 0;
				}

				/* Call API to del entry from RF Table.*/
				pr_debug("CLEAN: ct:%p entry:%p\n",
							 ct, rtEntry);
				fp_delete_router_table_entry(i,
							rtEntry, tblPtr);
#ifdef HASH_ARR_EN
				rtEntry = (struct cacheFlow *)
				PE_TO_PCI((uint32)
				ntohl(grtHashArr[i].next));
#else
				rtEntry = (struct cacheFlow *)PE_TO_PCI
				((uint32)tblPtr->table[i]);
#endif
			}
		}
	}
}

/*****************************************************************************
 * Function name     : fp_routeflow_cleanup()
 * Description       : This function sets all all FP flow entry values to NULL
 *                     during module cleanup
 * Input Parameters  : void
 * Output Parameters : -
 * Return            : void
 * Changes           : -
 *****************************************************************************
 */
void fp_routeflow_cleanup(void)
{
	struct fp_router_table              *tblPtr = fp_router_hash_table;
	struct cacheFlow                    *rtEntry;
	struct nf_conntrack            *link;
	struct nf_conn                 *ct;
	int32a                            i;

#ifdef HASH_ARR_EN
	/*For loop to fecth all hash table entries*/
	for (i = 0; i < tblPtr->tbl_size; i++) {
		if ((ntohl(grtHashArr[i].vflag) & ROUTE_ENTRY_VALID) == 0) {
			continue;
		} else {
			rtEntry = (struct cacheFlow *)PE_TO_PCI((uint32)
						ntohl(grtHashArr[i].next));

#else
	if (!tblPtr)
		return;

	/*For loop to fecth all hash table entries*/
	for (i = 0; i < tblPtr->tbl_size; i++) {
		if (!tblPtr->table[i]) {
			continue;
		} else {
			if (tblPtr->table[i] == NULL) {
				pr_debug("PT:%x\n",
				(uint32a)tblPtr->table[i]);
				continue;
			}
			rtEntry = (struct cacheFlow *)
			PE_TO_PCI((uint32a)tblPtr->table[i]);

#endif /*End of HASH_ARR_EN*/
			while (rtEntry != NULL && ((ntohl(rtEntry->vflag) &
						ROUTE_ENTRY_VALID) == 1)) {
				ct = (struct nf_conn *)
				((uint32)(rtEntry->ct.addr));
				//((uint32)ntohl(rtEntry->ct.addr));
				pr_debug("CLEANED:%x-->%p ct%p\n",
							i, rtEntry, ct);
				if (ct == NULL || (!ct)) {
					rtEntry = (struct cacheFlow *)
						PE_TO_PCI((uint32)
						ntohl(rtEntry->next));

					if (rtEntry == NULL)
						break;
					continue;
				}
				link = &(ct->ct_general);
				link->fpCt2CacheFlow.rtEntry[0] = NULL;
				link->fpCt2CacheFlow.rtEntry[1] = NULL;
				link->fpCt2CacheFlow.pIfPort[0] = NULL;
				link->fpCt2CacheFlow.pIfPort[1] = NULL;
				link->fpCt2CacheFlow.phyPort[0] = NULL;
				link->fpCt2CacheFlow.phyPort[1] = NULL;
				link->fpCt2CacheFlow.hashValue[0] = 0;
				link->fpCt2CacheFlow.hashValue[1] = 0;

				/*Getting next pointer*/
				rtEntry = (struct cacheFlow *)PE_TO_PCI(
					(uint32)ntohl(rtEntry->next));
			}
		}
	}
}

/*****************************************************************************
 * Function name     : fp_nf_ct_refresh_acct()
 * Description       : Refresh conntrack for this many jiffies and do
 *                      accounting if do_acct is 1
 * Input Parameters  : struct nf_conn*, enum ip_conntrack_info,
 *                     const struct sk_buff *, int
 * Output Parameters : -
 * Return            : void
 * Changes           : -
 ******************************************************************************
 */
void fp_nf_ct_refresh_acct(struct nf_conn *ct,
				enum ip_conntrack_info ctinfo,
				const struct sk_buff *skb,
				uint32 extra_jiffies,
				int32a do_acct)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 9, 0)
       /* If not in hash table, timer will not be active yet */
	if (nf_ct_is_confirmed(ct))
		extra_jiffies += nfct_time_stamp;

	ct->timeout = extra_jiffies;
#else
	/* If not in hash table, timer will not be active yet */
	if (!nf_ct_is_confirmed(ct)) {
		ct->timeout.expires = extra_jiffies;
	} else {
		uint32 newtime = jiffies + extra_jiffies;
		/* Only update the timeout if the new timeout is at least
		 * HZ jiffies from the old timeout. Need del_timer for race
		 * avoidance (may already be dying).
		 */
		if (newtime - ct->timeout.expires >= HZ)
			mod_timer_pending(&ct->timeout, newtime);
	}
#endif

}

void fp_nf_ct_refresh_connection(struct cacheFlow *rtEntry, struct nf_conn *ct)
{
	if (rtEntry->classNotifyFlags == ROUTE_ENTRY_ACTIVE) {
		rtEntry->classNotifyFlags = ROUTE_ENTRY_INACTIVE;
		switch (rtEntry->Proto) {

		case IPPROTO_TCP:
			pr_debug("%s:refresh tcp connection:%lx \r\n",
				__func__, tcptimeouts[ct->proto.tcp.state]);
			fp_nf_ct_refresh_acct(ct, 0, NULL,
				tcptimeouts[ct->proto.tcp.state], 0);
		break;

		case IPPROTO_UDP:
			if (ct->status & IPS_SEEN_REPLY) {
				pr_debug("%s:refresh UDP connection:%x \r\n",
						__func__, UDP_STREAM_TIMEOUT);
				fp_nf_ct_refresh_acct(ct, 0, NULL,
							UDP_STREAM_TIMEOUT, 0);
			} else {
				pr_debug("%s:refresh UDP connection:%x \r\n",
							__func__, UDP_TIMEOUT);
				fp_nf_ct_refresh_acct(ct, 0, NULL,
							UDP_TIMEOUT, 0);
			}
		break;

		case 1:
			/* Currently this is not supported by FPs  */
			pr_debug("%s:refresh ICMP connection:%x \r\n",
					__func__, ICMP_TIMEOUT);
			pr_debug("### ICMP ####\n");
			fp_nf_ct_refresh_acct(ct, 0, NULL, ICMP_TIMEOUT, 0);
		break;

		default:
			pr_debug("%s:refresh unknown protocol:%x conection:%x\r\n",
				__func__, rtEntry->Proto, GENERIC_TIMEOUT);
			fp_nf_ct_refresh_acct(ct, 0, NULL,
						GENERIC_TIMEOUT, 0);
		break;
		}
	}
}
/*****************************************************************************
 * Function name     : fp_routeflow_syncup_timeout()
 * Description       : This functions checks all the FP flow entry connections
 *                     and reset the timeout values for linux conntrack module
 *                     connections.
 * Input Parameters  : The long value  passed to every timer handler
 * Output Parameters : -
 * Return            : void
 * Changes           : -
 ******************************************************************************
 */
void fp_routeflow_syncup_timeout(struct timer_list *t)
{
	struct fp_router_table *tblPtr = fp_router_hash_table;
	struct cacheFlow *rtEntry = NULL;
	struct nf_conn            *ct = NULL;
	int32a i = 0;

	if (!tblPtr) {
		fp_routeflow_timer.expires = jiffies + FPROUTE_REFRESH;
		add_timer(&fp_routeflow_timer);
		mod_timer(&fp_routeflow_timer, jiffies + FPROUTE_REFRESH);

		return;
	}

	/*For loop for Hashtable read*/
	for (i = 0; i < tblPtr->tbl_size; i++) {
#ifdef HASH_ARR_EN
		if ((ntohl(grtHashArr[i].vflag) & ROUTE_ENTRY_VALID) == 0) {
			continue;
		} else {
			rtEntry = (struct cacheFlow *)&grtHashArr[i];
			while ((rtEntry != NULL) && ((ntohl(rtEntry->vflag)
						& ROUTE_ENTRY_VALID) == 1)) {
				ct = (struct nf_conn *)
				((uint32)(rtEntry->ct.addr));
				//((uint32)ntohl(rtEntry->ct.addr));
				if (ct == NULL) {
					rtEntry = (struct cacheFlow *)PE_TO_PCI(
					(uint32)ntohl(rtEntry->next));
					continue;
				}
#else
		if (!tblPtr->table[i]) {
			continue;
		} else {
			if (tblPtr->table[i] == NULL)
				continue;

			rtEntry = (struct cacheFlow *)
				PE_TO_PCI((uint32a)tblPtr->table[i]);
			while ((rtEntry != NULL) && ((ntohl(rtEntry->vflag)
						& ROUTE_ENTRY_VALID) == 1)) {
				ct = (struct nf_conn *)
					(rtEntry->ct.addr);
					//ntohl(rtEntry->ct.addr);
				if ((ct == NULL) || (!ct)) {
					rtEntry = (struct cacheFlow *)PE_TO_PCI(
						ntohl(rtEntry->next));

					if (rtEntry == NULL)
						break;
					continue;
				}
#endif
				fp_nf_ct_refresh_connection(rtEntry, ct);

				rtEntry = (struct cacheFlow *)PE_TO_PCI(
					(uint32)ntohl(rtEntry->next));
			}
		}
	}

	/* Update the refresh timer to call this fucntion again */

	fp_routeflow_timer.expires = jiffies + FPROUTE_REFRESH;
	add_timer(&fp_routeflow_timer);
	mod_timer(&fp_routeflow_timer, jiffies + FPROUTE_REFRESH);
}

/*****************************************************************************
 * Function name     : fp_print_skbuff()
 * Description       : This function prints  skbuff structure members
 * Input Parameters  : struct sk_buff*
 * Output Parameters : -
 * Return            : void
 * Changes           : -
 *****************************************************************************
 */
void fp_print_skbuff(struct sk_buff *skb)
{
return;
	pr_err("SKBUFF info\n");
	pr_err("skb:%p\n", skb);
	pr_err("skb->next:%p\n", skb->next);
	pr_err("skb->prev:%p\r\n", skb->prev);
	pr_err("skb->sk:%p\r\n", skb->sk);
	pr_err("skb->dev:%p\r\n", skb->dev);
	/*pr_debug("skb->dst:%p\r\n", skb->dst); */
	pr_err("skb->len:%x\n", (uint32a)skb->len);
	pr_err("skb->data_len:%x\n", (uint32a)skb->data_len);
	pr_err("skb->pkt_type:%x\n", (uint32a)skb->pkt_type);
#if 0
	pr_debug("skb->priority:%x\r\n", (uint32a)skb->priority);
	pr_debug("skb->truesize:%x\n", (uint32a)skb->truesize);
	pr_debug("skb->head:%p\n", skb->head);
	pr_debug("skb->tail:%p\n", skb->tail);
	pr_debug("skb->data:%p\n", skb->data);
	pr_debug("skb->end:%p\n", skb->end);
	pr_debug("skb->nfct:%p\n", skb->_nfct);
	pr_debug("\n");
	pr_debug("skb->fpNf2CacheFlow.rxDev:%p\n", skb->fpNf2CacheFlow.rxDev);
	pr_debug("skb->fpNf2CacheFlow.txDev:%p\n", skb->fpNf2CacheFlow.txDev);
	pr_debug("skb->fpNf2CacheFlow.nfct:%p\n", skb->fpNf2CacheFlow.nfct);
	pr_debug("skb->fpNf2CacheFlow.pppoeSesId:%x\n",
			(uint32a)skb->fpNf2CacheFlow.pppoeSesId);
	pr_debug("skb->fpNf2CacheFlow.postRtDev:%p\n",
			skb->fpNf2CacheFlow.postRtDev);
	pr_debug("skb->fpNf2CacheFlow.nfct:%p\n", skb->fpNf2CacheFlow.nfct));
	pr_debug("skb->fpNf2CacheFlow.pIfRxPort:%p\n",
			skb->fpNf2CacheFlow.pIfRxPort);
	pr_debug("skb->fpNf2CacheFlow.phyRxPort:%p\n",
			skb->fpNf2CacheFlow.phyRxPort);
	pr_debug("skb->fpNf2CacheFlow.pIfTxPort:%p\n",
			skb->fpNf2CacheFlow.pIfTxPort);
	pr_debug(("skb->fpNf2CacheFlow.phyTxPort:%p\n",
			skb->fpNf2CacheFlow.phyTxPort);
	pr_debug("skb->fpNf2CacheFlow.rxDev:%p\n", skb->fpNf2CacheFlow.rxDev);
	pr_debug("skb->fpNf2CacheFlow.txDev:%p\n", skb->fpNf2CacheFlow.txDev);
	pr_debug("skb->fpNf2CacheFlow.l2hash:%x\n",
			(uint32a)skb->fpNf2CacheFlow.l2Hash);
	pr_debug("skb->fpNf2CacheFlow.v4hash:%x\n",
			(uint32a)skb->fpNf2CacheFlow.v4Hash);
	pr_debug("skb->fpNf2CacheFlow.v6hash:%x\n",
			(uint32a)skb->fpNf2CacheFlow.v6Hash);
	pr_debug("skb->fpNf2CacheFlow.parseFlags:%x\n",
			(uint32a)skb->fpNf2CacheFlow.parseFlags);
	pr_debug("skb->fpNf2CacheFlow.controlFlags:%x\n",
			(uint32a)skb->fpNf2CacheFlow.controlFlags);
	pr_debug("skb->fpNf2CacheFlow.classFlags:%x\n",
			(uint32a)skb->fpNf2CacheFlow.classFlags);
#endif
}

/*****************************************************************************
 * Function name     : fp_print_routeflow_entry()
 * Description       : This function prints route flow entry structure members
 * Input Parameters  : struct cacheFlow*
 * Output Parameters : -
 * Return            : void
 * Changes           : -
 *****************************************************************************
 */
void fp_print_routeflow_entry(struct cacheFlow *pFlow)
{
	pr_debug("pFlow->flowActionflags:%x\n", pFlow->flowActionflags);
	pr_debug("pFlow->entryState:%x\n", pFlow->entryState);
	pr_debug("pFlow->srcIP:%x\n", pFlow->u.v4.srcIP);
	pr_debug("pFlow->dstIP:%x\n", pFlow->u.v4.dstIP);

	pr_debug("pFlow->proto:%x\n", pFlow->Proto);
	pr_debug("pFlow->sport:%x\n", pFlow->srcPort);
	pr_debug("pFlow->dport:%x\n", pFlow->dstPort);
	pr_debug("pFlow->chgSrcPort:%x\n", pFlow->chgSrcPort);
	pr_debug("pFlow->chgSrcIp:%x\n", pFlow->chgSrcIp);
	pr_debug("pFlow->chgDstPort:%x\n", pFlow->chgDstPort);
	pr_debug("pFlow->chgDstIp:%x\n", pFlow->chgDstIp);
	pr_debug("pFlow->pppoeSesId:%x\n", pFlow->pppoeSesId);
	pr_debug("pFlow->srcMacAddr:%02x:%02x:%02x:%02x:%02x:%02x\n",
				(pFlow->srcMacAddr[0] & 0xff),
				(pFlow->srcMacAddr[1] & 0xff),
				(pFlow->srcMacAddr[2] & 0xff),
				(pFlow->srcMacAddr[3] & 0xff),
				(pFlow->srcMacAddr[4] & 0xff),
				(pFlow->srcMacAddr[5] & 0xff));
	pr_debug("pFlow->dstMacAddr:%02x:%02x:%02x:%02x:%02x:%02x\n",
				(pFlow->dstMacAddr[0] & 0xff),
				(pFlow->dstMacAddr[1] & 0xff),
				(pFlow->dstMacAddr[2] & 0xff),
				(pFlow->dstMacAddr[3] & 0xff),
				(pFlow->dstMacAddr[4] & 0xff),
				(pFlow->dstMacAddr[5] & 0xff));
}

/*****************************************************************************
 * Function name     : fp_init_hooks()
 * Description       : This function registers hooks for Netfilter Filter
 * Input Parameters  : int
 * Output Parameters : -
 * Return            : int
 * Changes           : -
 *****************************************************************************
 */
int32a fp_init_hooks(int32a init)
{
	int32a ret = 0;

	if (!init)
		goto cleanupfp_hook4;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
	ret = nf_register_net_hook(&init_net, &fp_route_in_ops);
#else
	ret = nf_register_hook(&fp_route_in_ops);
#endif
	if (ret < 0) {
		pr_debug("%s: can't register pre-routing hook.\n", __func__);
		goto cleanupfp_hook1;
	}
	pr_debug("%s: Added FP PREROUTE Hook\n", __func__);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
	ret = nf_register_net_hook(&init_net, &fp_route_out_ops);
#else
	ret = nf_register_hook(&fp_route_out_ops);
#endif
	if (ret < 0) {
		pr_debug("%s: can't register pre-routing hook.\n", __func__);
		goto cleanupfp_hook2;
	}

	/* IPV6 hooks Registration */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
	ret = nf_register_net_hook(&init_net, &fp_ipv6_route_in_ops);
#else
	ret = nf_register_hook(&fp_ipv6_route_in_ops);
#endif
	if (ret < 0) {
		pr_debug("%s: can't register pre-routing hook.\n", __func__);
		goto cleanupfp_hook3;
	}
	pr_debug("%s: Added FP PREROUTE Hook\n", __func__);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
	ret = nf_register_net_hook(&init_net, &fp_ipv6_route_out_ops);
#else
	ret = nf_register_hook(&fp_ipv6_route_out_ops);
#endif
	if (ret < 0) {
		pr_debug("%s: can't register pre-routing hook.\n", __func__);
		goto cleanupfp_hook4;
	}
	pr_debug("\n%s:Added FP POSTROUTE Hook\n", __func__);

	fpRouteFlowDelete_ptr = fpRouteFlowDelete;

	timer_setup(&fp_routeflow_timer, fp_routeflow_syncup_timeout, 0);
	mod_timer(&fp_routeflow_timer, jiffies + FPROUTE_REFRESH);

	return ret;

cleanupfp_hook4:
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
	nf_unregister_net_hook(&init_net, &fp_ipv6_route_out_ops);
#else
	nf_unregister_hook(&fp_ipv6_route_out_ops);
#endif
cleanupfp_hook3:
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
	nf_unregister_net_hook(&init_net, &fp_ipv6_route_in_ops);
#else
	nf_unregister_hook(&fp_ipv6_route_in_ops);
#endif
cleanupfp_hook2:
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
	nf_unregister_net_hook(&init_net, &fp_route_out_ops);
#else
	nf_unregister_hook(&fp_route_out_ops);
#endif
cleanupfp_hook1:
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
	nf_unregister_net_hook(&init_net, &fp_route_in_ops);
#else
	nf_unregister_hook(&fp_route_in_ops);
#endif
	fpRouteFlowDelete_ptr = NULL;
	fp_routeflow_cleanup();
	//del_timer((struct timer_list *)&fp_routeflow_timer);

	return ret;
}
EXPORT_SYMBOL(fp_flow_process);
