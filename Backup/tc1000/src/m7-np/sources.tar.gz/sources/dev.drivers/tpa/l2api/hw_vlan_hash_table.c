// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          hw_vlan_hash_table.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    routines for vlan hash add, del, update and search
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

/*********************************************************************
*                           Include files
*********************************************************************/
#include "reg_hal.h"
#include "fp_library.h"
#include "global_address_map_fpga.h"
#include "wsp_vlan_hash_table_L.h"

#define FAIL_RETRY_FIX


void update_vlan_mac5_registers(uint32a mac1,
				uint32a mac2,
				uint32a mac3,
				uint32a mac4,
				uint32a mac5,
				int32a table)
{
	TableWrite(VLAN_HASH_HOST_MAC1_ADDR_REG, mac1, table);
	TableWrite(VLAN_HASH_HOST_MAC2_ADDR_REG, mac2, table);
	TableWrite(VLAN_HASH_HOST_MAC3_ADDR_REG, mac3, table);
	TableWrite(VLAN_HASH_HOST_MAC4_ADDR_REG, mac4, table);
	TableWrite(VLAN_HASH_HOST_MAC5_ADDR_REG, mac5, table);
}
/**********************************************************************
* Function Name  : wsp_vlan_entry_search
* Description    : Search vlan grp Table with given vlanid
* Inputs
* Parameters   : - vlanid
* Globals      : -
* Outputs        :
*  Parameters  : -
* Returns      :   Returns Entry Values if Search Found
* Changes        :
************************************************************************/
int32 wsp_vlan_entry_search(uint32a vlanid)
{
	uint32a cmd_done = 0;
	int32a field_valids = BIT_SET_VLAN_1F_VLANTBL;
	uint32a entry1 = 0;
	uint32a entry2 = 0;
	uint64 entry;
	int32a retry = 4;

	TableWrite(VLAN_HASH_HOST_ENTRY_REG, 0x0, DEFAULT_TABLE);
	TableWrite(VLAN_HASH_HOST_DIRECT_REG, 0x0, DEFAULT_TABLE);

	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
		"entered in function wsp_vlan_entry_search base addr is %p\n",
				GetBaseAddr());
	/*Writing mac address*/
	update_vlan_mac5_registers(	vlanid & VLANID_MASK,
					0x0, 0x0, 0x0, 0x0,
					DEFAULT_TABLE);

	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
		"entered in function wsp_vlan_entry_search base addr is %p\n",
				GetBaseAddr());
	/* write the search command */
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "CMDREG %x \r\n",
			CMD_SEARCH | field_valids);
#ifdef FAIL_RETRY_FIX
	do {
#endif
	cmd_done = IssueCommand_CS( VLAN_HASH_HOST_CMD_REG,
					( CMD_SEARCH | field_valids ),
					VLAN_HASH_HOST_STATUS_REG,
					STATUS_CMD_DONE,
					CLR_STATUS_REG);
/*
	printk("cmd_done = %x done = %s, found = %s\n",
		cmd_done,
		(cmd_done & STATUS_CMD_DONE)    ? "TRUE" : "FALSE",
		(cmd_done & STATUS_ENTRY_MATCH) ? "TRUE" : "FALSE");
*/
	/*Bridge entry match done check*/
	if (cmd_done & STATUS_CMD_DONE) {
		if(cmd_done & STATUS_ENTRY_MATCH) {
			/* SEARCH FOUND */
			entry1 = TableRead(VLAN_HASH_HOST_ENTRY_REG, DEFAULT_TABLE);
			entry2 = TableRead(VLAN_HASH_HOST_DIRECT_REG, DEFAULT_TABLE);

			entry = (((uint64)entry2 << 32) | entry1);

			/* Clear req entry reg */
			TableWrite(VLAN_HASH_HOST_ENTRY_REG, 0x0, DEFAULT_TABLE);
			TableWrite(VLAN_HASH_HOST_DIRECT_REG, 0x0, DEFAULT_TABLE);
			return entry;
		} else {
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
				"VLAN ENTRY NOT FOUND\n");
#ifdef FAIL_RETRY_FIX
			if (retry > 0) {
/*
				printk("retrying %i\n",retry);
*/
				retry--;
				continue;
			}
#endif
			return -1;
		}
	} else {
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_EMERG,
				"VLAN SEARCH CMD failed (CMD_DONE = 0\n");
		return -2;
	}
#ifdef FAIL_RETRY_FIX
	} while (1);// end of temporary while
#endif
} /*End of wsp_vlan_entry_search() Function*/

static int32a __wsp_vlan_entry_add(uint32a field_entries[5], uint32a portNo, uint64 action_entry, uint32a field_valids, uint32a table_num);


/**********************************************************************
* Function Name  : wsp_vlan_entry_add
* Description    : Add given Mac Entry into MAC HASH TABLE
* Inputs
* Parameters   : - Mac Address port no and action entry pointer
* Globals      : -
* Outputs        :
*  Parameters  : -
* Returns      :   Returns Entry Add Status
* Changes        :
************************************************************************/
static int32a __wsp_vlan_entry_add(uint32a field_entries[5], uint32a portNo, uint64 action_entry, uint32a field_valids, uint32a table_num)
{
	int32a cmd_done = 0;
	int32a vlanNo = 0;
	uint32a action_entry1;
	uint32a action_entry2;

	action_entry1 = (action_entry & 0xFFFFFFFF);
	action_entry2 = (action_entry >> 32);
	/* FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "TEST:VLAN_HASH_HOST_CMD_REG:%x\n",
							VLAN_HASH_HOST_CMD_REG); */
	/* vlan group table format *
	*======================================================================*
	* valid bits | col_ptr | portNo | field_valids | action entry | vlan   *
	*======================================================================*
	* 4-bit      | 16-bit  | 4-bit  | 8-bit        | 55-bit       | 13-bit *
	*=====================================================================*/
	/* VLAN (BD) Hash table action entry map:*
	*=======================================*
	* [19:0]        - forward port list
	* [39:20]       - untag list
	* [42:40]	- ucast_hit_action
	* [45:43]       - mcast_hit_action
	* [48:46]       - ucast_miss_action
	* [51:49]       - mcast_miss_action
	* [54-52]       - Not used yet
	*=======================================*/

	/* fill vlan reg */
	vlanNo = field_entries[0];
	TPA_D("ADD VID:%x\r\n", vlanNo);
	update_vlan_mac5_registers((vlanNo & VLANID_MASK), 0x0, 0x0, 0x0, 0x0, table_num);

	/* fill ENTRY reg */
	TPA_D("VLAN ENTRY %llx \r\n", action_entry & BRENTRY_ACTION_ENTRY_MASK);
	TableWrite(VLAN_HASH_HOST_ENTRY_REG, action_entry1, table_num);
	TableWrite(VLAN_HASH_HOST_DIRECT_REG,action_entry2, table_num);

	/* Description of ADD CMD REG:
	* 3:0   - CMD
	* 7:4   - Reserved
	* 8     - Vlan Field Valid
	* 15:9 - Reserved
	* 31:16 - Mem Index / portno[16:19]
	*/
	/* Issue ADD cmd */
	TPA_D("VLAN ADD %x \r\n", CMD_ADD | (field_valids & CMD_ENTRY_FIELD_VALID_MASK));

	/* Description of STATUS CMD REG:
	* 0 - req1_cmd_done
	* 1 - req1_sig_entry_not_found
	* 2 - req1_sig_init_done
	* 3 - req1_sig_entry_added
	* 4 - req1_match
	* 31:5 - reserved.
	*/
	/* STATUS reg is returned in cmd done */
	cmd_done = IssueCommandTable_CS(VLAN_HASH_HOST_CMD_REG,
				(CMD_ADD | (field_valids & CMD_ENTRY_FIELD_VALID_MASK)),
				VLAN_HASH_HOST_STATUS_REG,
				STATUS_CMD_DONE,
				CLR_STATUS_REG,
				table_num);

	if(cmd_done & STATUS_CMD_DONE)
	{
		if(cmd_done & STATUS_ENTRY_ADDED)
		{
			/* FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "ADD CMD DONE\n");
			Entry Added Successfully */
			fp_rc_stats.hw_vlan_entry_count++;
			return 0;
		}
		else
		{
			TPA_D("VLAN ADD CMD OK, but ENTRY NOT ADDED\n");
			return -1;
		}
	}
	else
	{
		TPA_E("VLAN ADD CMD failed (CMD_DONE = 0\n");
		return -2;
	}
}

int32a wsp_vlan_entry_add(uint32a field_entries[5],
			uint32a portNo,
			uint64 action_entry,
			uint32a field_valids)
{
	if(__wsp_vlan_entry_add(field_entries, portNo, action_entry, field_valids, 1) == -1)
		return -1;
	return __wsp_vlan_entry_add(field_entries, portNo, action_entry, field_valids, 3);
}

#if 0
int32a wsp_vlan_entry_add_all_tables(	uint32a field_entries[5],
					uint32a portNo,
					uint64 action_entry,
					uint32a field_valids)
{
	int32a ret = 0;
	ret = wsp_vlan_entry_add_table(field_entries, portNo, action_entry, field_valids, 3);
	if(ret == -1)
		return -1;
	//ret = wsp_vlan_entry_add_table(field_entries, portNo, action_entry, field_valids, 1);
	//wsp_vlan_entry_add_table(field_entries, portNo, action_entry, field_valids, 2);
	return ret;
}
#endif

/**********************************************************************
* Function Name  : wsp_vlan_entry_delete
* Description    : Delete given vlan Entry from VLAN HASH TABLE
* Inputs
* Parameters   : - vlan id
* Globals      : -
* Outputs        :
*  Parameters  : -
* Returns      :   Returns Entry Delete Status
* Changes        :
**********************************************************************/
int32a wsp_vlan_entry_delete(uint32a field_entries[5], uint32a field_valids)
{
	int32a cmd_done = 0;
	/* Write entries corresponding MAC REG */
	update_vlan_mac5_registers(	field_entries[0] & VLANID_MASK,
					0x0, 0x0, 0x0, 0x0,
					DEFAULT_TABLE);
	cmd_done = IssueCommand_CS(
				VLAN_HASH_HOST_CMD_REG,
				( CMD_DEL | (field_valids & CMD_ENTRY_FIELD_VALID_MASK)),
				VLAN_HASH_HOST_STATUS_REG,
				STATUS_CMD_DONE,
				CLR_STATUS_REG);
	if (cmd_done & STATUS_CMD_DONE) {
		if(cmd_done & STATUS_ENTRY_NOT_FOUND) {
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_EMERG, "VLAN DEL CMD OK, but ENTRY NOT REMOVED\n");
			return -1;
		} else {
			/* FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "DEL CMD DONE\n");
			Entry removed successfully */
			fp_rc_stats.hw_vlan_entry_count--;
			return 0;
		}
	} else {
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_EMERG, "VLAN DEL CMD FAILED\n");
		return -2;
	}
	return 0;
} /*End of wsp_vlan_entry_delete() Function*/

/**********************************************************************
* Function Name  : wsp_vlan_entry_update
* Description    : Update given BRENTRY PTR into HASH MAC TABLE
* Inputs
* Parameters   : - Mac Address and brentry
* Globals      : -
* Outputs        :
*  Parameters  : -
* Returns      :   Returns Entry Update Status
* Changes        :
**********************************************************************/
int32a wsp_vlan_entry_update(uint32a field_entries[5], uint64 brentry, uint32a field_valids)
{
	int32a cmd_done = 0;
	uint32a entry1;
	uint32a entry2;

	/* Write entries corresponding MAC REG */
	update_vlan_mac5_registers(	field_entries[0] & VLANID_MASK,
					0x0, 0x0, 0x0, 0x0,
					DEFAULT_TABLE);
	entry1 = (brentry & 0xFFFFFFFF);
	entry2 = (brentry >> 32);
	/* fill ENTRY reg if valid */
	TableWrite(VLAN_HASH_HOST_ENTRY_REG,  entry1, DEFAULT_TABLE);
	TableWrite(VLAN_HASH_HOST_DIRECT_REG, entry2, DEFAULT_TABLE);
	/* Issue UPDATE cmd */
	cmd_done = IssueCommand_CS(
				VLAN_HASH_HOST_CMD_REG,
				( CMD_UPDATE
				| (field_valids & CMD_ENTRY_FIELD_VALID_MASK)),
				VLAN_HASH_HOST_STATUS_REG,
				STATUS_CMD_DONE,
							CLR_STATUS_REG);
	if (cmd_done & STATUS_CMD_DONE) {
		if(cmd_done & STATUS_ENTRY_ADDED) {
			return 0;
		} else {
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_EMERG,
				"VLAN UPDATE CMD OK, but ENTRY NOT UPDATED\n");
			return -1;
		}
	} else {
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_EMERG,
				"VLAN UPDATE CMD FAILED\n");
		return -2;
	}
	return 0;
} /*End of wsp_vlan_entry_update() Function*/


/**********************************************************************
* Function Name  : hw_vlan_hash_table_init
* Description    : Initialize MAC HASH TABLE & VLAN HASH TABLE
*                  Initialize the hash collision space
*                  chain the collision space
*                  init the free head, list pointers and no of entries
*                  All initialize done through register programming only
* Inputs
* Parameters   : packet_t * - contains packet header data
* Globals      : -
* Outputs        :
*  Parameters   : -
* Returns      : int
* Changes        :
************************************************************************/
void wsp_vlan_hash_table_init(uint32a table_num)
{
	uint32a index = 0;
	uint32a mac_table_addr = 0;
	uint32a col_ptr = 0;
	uint32a i = 0;
	/* Avoid Multiple PE's Initialization */
	/* vlan group table format *
	*=====================================================================*
	* valid bits | col_ptr | portNO | field_valids | action entry | vlan  *
	*=====================================================================*
	* 4-bit      | 16-bit  | 4-bit  | 8-bit        | 32-bit       | 12-bit*
	* 4-bit      | 16-bit  | 4-bit  | 8-bit        | 55-bit       | 13-bit*
	*=====================================================================*/
	/* VLAN HASH MEMORY INTIALIZATION */
	/* Initialize CMD register for Hash Table Intializes with zeros */
	IssueCommandTable_CS(VLAN_HASH_HOST_CMD_REG,
				CMD_INIT,
				VLAN_HASH_HOST_STATUS_REG,
				STATUS_CMD_DONE,
				CLR_STATUS_REG,
				table_num);

	/* clear mac1 & mac2 registers */
	update_vlan_mac5_registers(0x0, 0x0, 0x0, 0x0, 0x0, table_num);

	/* chain the vlan collision space */
	for (i = 0; i < VLAN_FREE_LIST_ENTRIES; i++)
	{
		col_ptr = (0x40001 + VLAN_HASH_ENTRIES + i);
		TableWrite(VLAN_HASH_HOST_MAC3_ADDR_REG, ((col_ptr & 0xFFFF) << 16), table_num);
		TableWrite(VLAN_HASH_HOST_MAC4_ADDR_REG, (col_ptr >> 16) & 0xF, table_num);
		index = VLAN_HASH_ENTRIES + i;
		mac_table_addr = (index << 16);
		IssueCommandTable_CS(VLAN_HASH_HOST_CMD_REG,
					(CMD_MEM_WRITE | mac_table_addr),
					VLAN_HASH_HOST_STATUS_REG,
					STATUS_CMD_DONE,
					CLR_STATUS_REG,
					table_num);
	} /*End of vlan collision spce for loop*/

	/* Intialize Free List Head Ptr */
	TableWrite(VLAN_HASH_FREELIST_PTR_HEAD,VLAN_INIT_HEAD_PTR, table_num);

	/* Initialize Free List Ptr */
	TableWrite(VLAN_HASH_FREELIST_PTR_TAIL,VLAN_INIT_TAIL_PTR, table_num);

	/* Initialize No of entries */
	TableWrite(VLAN_HASH_FREELIST_ENTRIES_ADDR,VLAN_FREE_LIST_ENTRIES, table_num);

	TPA_D("VLAN INIT DONE\r\n");
} /*end of hw_vlan_hash_table_init() Function*/

/*********************** End of File **********************/
