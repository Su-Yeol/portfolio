// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_library.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    library functions for fast path module
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifdef __linux__
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                     Include Files
 **********************************************************************/
#include <linux/delay.h>
#endif

#include "fp_library.h"
#include "global_base_address.h"
#include <stdarg.h>

//#define TEMPORARY_COMMENTIZE
#ifndef __linux__
/* TSNC note:
    copied from fp_epp_init.c, because fp_epp_init.c won't be used for TSNC */
unsigned char fp_dbgp_arr[FP_MAX_DBGP][FP_MAX_DBGP_LEN] = {
	{"DBGP_FEAT_HIF"},
	{"DBGP_FEAT_BRIDGE"},
	{"DBGP_FEAT_ROUTE"},
	{"DBGP_FEAT_FWD_PE"},
	{"DBGP_FEAT_TMU"},
	{"DBGP_FEAT_CLI"},
	{"DBGP_FEAT_L2CLI"},
	{"DBGP_FEAT_L3CLI"},
	{"DBGP_FEAT_L2API"},
	{"DBGP_FEAT_L3API"},
	{"DBGP_FEAT_IOCTL"},
	{"DBGP_FEAT_LIB"},
	{"DBGP_FEAT_ERR"}
};

#ifdef FP_DEBUG_LEVEL_MAX
unsigned int fp_dbgp_flags = 0x1FFF;
unsigned int fp_trace_level = 7;
#else
unsigned int fp_dbgp_flags = 0x1;
unsigned int fp_trace_level = 1;
#endif
#endif //ifndef __linux__

#include <FreeRTOSConfig.h>
#include <bsp.h>
void tpa_udelay_busy(uint32 us)
{
    uint32  i = 0;
    uint32  cnt = 0;
    uint32 cycle_per_1us = configCPU_CLOCK_HZ / 1000000;
 
    cnt = us * cycle_per_1us;
    for (i = 0UL; i < cnt; i++)
    {
         BSP_NOP_DELAY();
    }
}


#if 0//def TEMPORARY_COMMENTIZE
/* TSNC note : currently not used */
/* define prototype */
static void fp_SwapBytes(void *pv, unsigned int n);


/**********************************************************************
 * Function Name  : fp_printf
 * Description    : print the data in standard output file
 * Inputs
 *   Parameters   : const int8 *, variable no of arguments
 * Outputs        :
 *   Parameters   :
 *   Returns      : returns no of character printed in output
 * Changes        :
 ********************************************************************/
/* TSNC note: this function is used only for route/fp_pci_pe.c */
int32a nkprintf(const int8 *fmt, ...)
{
	va_list args;
	int32a r;
	va_start(args, fmt);
	r = vprintk(fmt, args);
	va_end(args);
	return r;
}

/**********************************************************************
 * Function Name  : fp_SwapBytes
 * Description    : swap the first n no of bytes pointed by pv
 * Inputs
 *   Parameters   : void *, uint32a
 * Outputs        :
 *   Parameters   : void *
 *   Returns      : -
 * Changes        :
 ********************************************************************/
static void fp_SwapBytes(void *pv, uint32a n)
{
	int8 *p = pv;
	uint32a  lo, hi;
	for (lo = 0, hi = n-1; hi > lo; lo++, hi--) {
		int8 tmp = p[lo];
		p[lo] = p[hi];
		p[hi] = tmp;
	}
}

#define fp_SWAP(x) fp_SwapBytes(&x, sizeof(x));
/**********************************************************************
 * Function Name  : fp_convert_le2be
 * Description    : convert little-endian to big-endian
 * Inputs
 *   Parameters   : int8 *, uint32a
 * Outputs        :
 *   Parameters   : int8 *
 *   Returns      : -
 * Changes        :
 ********************************************************************/
void fp_convert_le2be(int8 *data, uint32a size)
{
	int32a i, cnt;
	uint32a *data_ptr = (uint32a *)data;

	cnt  = size >> 2;
	if (size & 0x3)
		cnt++;
	for (i = 0; i < cnt; i++)
		fp_SwapBytes(&data_ptr[i], 4);
	return;
}

void dump_me(volatile uint8 *src, int32a len)
{
	int32a i, k;
	int32a j;
	volatile uint8 *ptr;

	j = len % 8;
	k = len / 8;
	for (i = 0; i < k; i++) {
		ptr = src + (i * 8);
		FP_DEBUG(DBGP_FEAT_LIB, FP_LOG_INFO,
			"0x%02x, 0x%02x, 0x%02x, 0x%02x, 0x%02x, 0x%02x,"
			"0x%02x, 0x%02x\n", ptr[0], ptr[1], ptr[2], ptr[3],
			ptr[4], ptr[5], ptr[6], ptr[7]);
	}
	ptr = src + (i * 8);

	for (i = 0; i < j; i++)
		FP_DEBUG(DBGP_FEAT_LIB, FP_LOG_INFO, "0x%02x ", ptr[i]);

	FP_DEBUG(DBGP_FEAT_LIB, FP_LOG_INFO, "\n");
}

/**********************************************************************
 * Function Name  : SwapBytes
 * Description    :
 * Inputs
 *   Parameters   : void *, size in bytes
 * Outputs        :
 *   Parameters   : void * - swaped bytes
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void SwapBytes(void *pv, size_t n)
{
	int8 *p = pv;
	size_t lo, hi;
	for (lo = 0, hi = n - 1; hi > lo; lo++, hi--) {
		int8 tmp = p[lo];
		p[lo] = p[hi];
		p[hi] = tmp;
	}
}

#define SWAP(x) SwapBytes(&x, sizeof(x));
/**********************************************************************
 * Function Name  : convert_le2be_64
 * Description    : convert given data from little-endian to big-endian
 * Inputs           with 32b bit word swap
 *   Parameters   : int8 * , int
 * Outputs        :
 *   Parameters   : int8 *
 *   Returns      :
 * Changes        :
 *********************************************************************/
void convert_le2be_64(int8 *data, uint32a size)
{
	int32a i, cnt;
	uint64 *data_ptr = (uint64 *)data;

	cnt  = size >> 3;
	if (size & 0x7)
		cnt++;
	/* swap the lsb bytes as msb vice-versa */
	for (i = 0; i < cnt; i++)
		SwapBytes(&data_ptr[i], 8);
	return;
}

/**********************************************************************
 * Function Name  : convert_le2be
 * Description    : convert given data from little-endian to big-endian
 * Inputs
 *   Parameters   : int8 * , int
 * Outputs        :
 *   Parameters   : int8 *
 *   Returns      :
 * Changes        :
 *********************************************************************/
void convert_le2be(int8 *data, uint32a size)
{
	int32a i, cnt;
	uint32a *data_ptr = (uint32a *)data;

	cnt  = size >> 2;
	if (size & 0x3)
		cnt++;
	/* swap the lsb bytes as msb vice-versa */
	for (i = 0; i < cnt; i++)
		SwapBytes(&data_ptr[i], 4);
	return;
}
#endif

/* name must be given */
void spin_lock_init(spinlock_t *lock, const uint8* name)
{
	(void)SAL_SemaphoreCreate(lock, (const uint8*)name, 1UL, SAL_OPT_BLOCKING);
}

void spin_lock_bh(spinlock_t *lock)
{
    /*Acquire Mutex*/
    (void) SAL_SemaphoreWait(*lock, 0, SAL_OPT_BLOCKING);

}

void spin_unlock_bh(spinlock_t *lock)
{
    /*Release Mutex*/
    (void) SAL_SemaphoreRelease(*lock);
}

void spin_lock_deinit(spinlock_t *lock)
{
    (void) SAL_SemaphoreDelete(*lock);
}


