/**
 * @file MRVL_Q222X_Types.h
 * @brief Q222X Types Header File
 * Header file contains common types and defines across Marvell Q222X API
 *
 * @par Copyright and Version
 * See MRVL_Q222X_Copyright_and_Version.h
 */

#ifndef MRVL_Q222X_TYPES_H
#define MRVL_Q222X_TYPES_H

#include "MRVL_Q222X_Copyright_and_Version.h"
#include "MRVL_APHY_HwCntl.h"

#define MRVL_Q222X_PRODUCT_ID				0x0000U     /*!< Product series id, see detailed package id for more information */

#define MRVL_Q222X_PACKAGE_ID_Q2220M		0x0000U	    /*!< 1000/100 speed with RGMII and MACsec */
#define MRVL_Q222X_PACKAGE_ID_Q2221M		0x0001U	    /*!< 1000/100 speed with SGMII and MACsec */
#define MRVL_Q222X_PACKAGE_ID_Q1210M		0x0002U	    /*!< 100 speed with RGMII and MACsec */
#define MRVL_Q222X_PACKAGE_ID_Q1211M		0x0003U	    /*!< 100 speed with RGMII and MACsec */
#define MRVL_Q222X_PACKAGE_ID_Q2220			0x0004U	    /*!< 1000/100 speed with RGMII */
#define MRVL_Q222X_PACKAGE_ID_Q2221			0x0005U	    /*!< 1000/100 speed with SGMII and MACsec */
#define MRVL_Q222X_PACKAGE_ID_Q1210			0x0006U	    /*!< 100 speed with RGMII and MACsec */
#define MRVL_Q222X_PACKAGE_ID_Q1211			0x0007U	    /*!< 100 speed with SGMII and MACsec */
#define MRVL_Q222X_PACKAGE_ID_Q2233M_P0		0x0008U	    /*!< 1000/100 speed two-port PHY with SGMII and MACsec, port 0 */
#define MRVL_Q222X_PACKAGE_ID_Q2233M_P1		0x0009U	    /*!< 1000/100 speed two-port PHY with SGMII and MACsec, port 1 */
#define MRVL_Q222X_PACKAGE_ID_Q2233_P0		0x000CU	    /*!< 1000/100 speed two-port PHY with SGMII, port 0 */
#define MRVL_Q222X_PACKAGE_ID_Q2233_P1		0x000DU	    /*!< 1000/100 speed two-port PHY with SGMII, port 1 */

#define MRVL_Q222X_A0						0x0000U     /*!< A0 is not covered in this API package, A0 is not supported. */
#define MRVL_Q222X_B0						0x0001U     /*!< API supports B0 */
#define MRVL_Q222X_B1						0x0002U     /*!< API supports B1 */

/* Auto-Negotiation Controls - reg 7.0x0200 */
#define MRVL_Q222X_AN_DISABLE     0x0000U
#define MRVL_Q222X_AN_RESET       0x8000U
#define MRVL_Q222X_AN_ENABLE      0x1000U

/* Auto-Negotiation Status - reg 7.0x0201 */
#define MRVL_Q222X_AN_COMPLETE    0x0020U

/* Auto-Negotiation Flags - reg 7.0x0203 */
#define MRVL_Q222X_AN_FE_ABILITY      0x0020U
#define MRVL_Q222X_AN_GE_ABILITY      0x0080U

#define MRVL_Q222X_ACCESS_ATTEMPT_LOWER_BOUND	0
#define MRVL_Q222X_ACCESS_ATTEMPT_UPPER_BOUND	5

#endif
