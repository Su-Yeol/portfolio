/* SPDX-License-Identifier: (GPL-2.0 WITH Linux-syscall-note) AND MIT */

/*************************************************************************/ /*!
@File
@Title          platform.h
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    Functions to handle different hardware platforms
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#ifndef  _PLATFORM_H_
#define  _PLATFORM_H_

#ifdef __linux__
#include <linux/types.h>
#include <linux/pci.h>
#endif

#include "fp_library.h"

#ifdef PLATFORM_FPGA
#define EPP_PLATFORM_BASE_ADDR	(0x0)
#define MAC_REG_0_VALUE		(0x8aae003)
#define NUM_TOTAL_HIF		(1)
#define NUM_HIF_CHANNELS	(4)
#endif

#ifdef PLATFORM_FPGA_CM7
#define EPP_PLATFORM_BASE_ADDR	(0)
#define MAC_REG_0_VALUE		(0x8aae003)
#define NUM_TOTAL_HIF		(1)
#define NUM_HIF_CHANNELS	(4)
//#define NUM_HIF_CHANNELS	(1)
#endif

#ifdef PLATFORM_GENERIC
#define EPP_PLATFORM_BASE_ADDR	(0x0)
#define MAC_REG_0_VALUE		(0x0)
#define NUM_TOTAL_HIF		(1)
#define NUM_HIF_CHANNELS	(4)
#endif

#ifdef PLATFORM_TCN1000_CM7
#define EPP_PLATFORM_BASE_ADDR	(0)
#define MAC_REG_0_VALUE		(0x0)
#define NUM_TOTAL_HIF		(1)
#define NUM_HIF_CHANNELS	(16)
#define HIF_CHNUM_NP        (8)
#define ENABLE_PARITION3
#endif

#if defined(PLATFORM_FPGA_CM7) || defined(PLATFORM_TCN1000_CM7)
	int platform_init(void);
#else
struct memconfig
{
	resource_size_t start;
	resource_size_t end;
	resource_size_t len;
	uint8 *membase;
	uint32a  valid;
};

int32a   platform_init(struct pci_dev *pdev);
#endif

void  platform_start(void);

#if defined(PLATFORM_FPGA_CM7) || defined(PLATFORM_TCN1000_CM7)
void *platform_dma_alloc(uint32a  ch_id,
			uint32a   total_ring_size,
			dma_addr_t     *pdev_addr);
#else
void *platform_dma_alloc(uint32a  ch_id,
			uint32a   total_ring_size,
			struct device  *pdev,
			dma_addr_t     *pdev_addr,
			gfp_t          gfp);
#endif

void  platform_clear_interrupt(void);

/*
 * The following functions are declared here as they should be common
 * across ALL platforms.
 * We generally DO NOT do this due to code bloat, but as these functions
 * are just a single line of code, the compiler SHOULD inlines them
 * without any code bloat.
 *
 * Anybody adding MORE functions here should keep to the principal of
 * having just a single line of code ( 2 at the most !)
 *
 * why not use a macro i.e.
 *     #define Read(x) return *((uint32a*)RegAddr);
 * the reason ..
 *     it means the compiler does the proper type checking
 *     a #define abstracts it and the compiler may not warn if the
 *     supplied/returned parameter(s) are of the wrong type
 */
/*****************************************************************
 * Function Name  : platform_RegRead()
 * Description    : Hardware register read function return register
 *                  read value for given address.
 * Inputs
 *   Parameters   : uint32a
 * Outputs        :
 *   Parameters   : -
 *   Returns      : uint32a
 * Changes        :
 ****************************************************************/
static inline uint32a platform_RegRead(void *RegAddr)
{
	return *((uint32a*)RegAddr);
}

/******************************************************************
 * Function Name  : platform_RegWrite()
 * Description    : Hardware register write function Write given value
 *                  in given address.
 * Inputs
 *   Parameters   : uint32a, uint32a
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *****************************************************************/
static inline void platform_RegWrite(void *RegAddr, uint32a RegData)
{
	*((uint32a *)RegAddr) = RegData;
}

void platform_emac_enable(void);
void platform_check_phy_status(int phy_num);

void *platform_memset(void *s, int32a c, size_t n);
void *platform_memcpy(void *d, void *s, size_t n);
void *platform_memcpy_sw(void *d, void *s, size_t n);

void dump_hif_regs(void);
void dump_mem(uint8* addr, uint32a size);
void dump_byte(uint8* addr, uint32a size);
void wait_init_done_signal_to_main_ap(void);



void diff_egpi_reg(int8 egpi_no, int8 ino);

void diff_cnt_reg(int8 ino);

int32a create_thread(void *data);


extern uint32 tpa_dmastart__;


//GPIO setting
#define MC_GPIO_BASE_ADDR   (0x4B300000)
//-----GPIO offset----//
//GPIO_C
#define       GPC_DAT                     (0x0A8)
#define       GPC_SET                     (0x0AC)
#define       GPC_CLR                     (0x0B0)
#define       GPC_XOR                     (0x0B4)
#define       GPC_OEN                     (0x0B8)
#define       GPC_PE                      (0x0BC)
#define       GPC_PS                      (0x0C0)
#define       GPC_IEN                     (0x0C4)
#define       GPC_IS                      (0x0C8)
#define       GPC_DS0                     (0x0CC)
#define       GPC_DS1                     (0x0D0)
#define       GPC_DS2                     (0x0D4)
#define       GPC_DS3                     (0x0D8)
#define       GPC_FNC0                    (0x0DC)
#define       GPC_FNC1                    (0x0E0)
#define       GPC_FNC2                    (0x0E4)
#define       GPC_FNC3                    (0x0E8)
#define       GPC_SR0                     (0x0EC)
#define       GPC_SR1                     (0x0F0)
#define       GPC_SR2                     (0x0F4)
#define       GPC_SR3                     (0x0F8)

//GPIO_D
#define       GPD_DAT                     (0x0FC)
#define       GPD_SET                     (0x100)
#define       GPD_CLR                     (0x104)
#define       GPD_XOR                     (0x108)
#define       GPD_OEN                     (0x10C)
#define       GPD_PE                      (0x110)
#define       GPD_PS                      (0x114)
#define       GPD_IEN                     (0x118)
#define       GPD_IS                      (0x11C)
#define       GPD_DS0                     (0x120)
#define       GPD_DS1                     (0x124)
#define       GPD_DS2                     (0x128)
#define       GPD_DS3                     (0x12C)
#define       GPD_FNC0                    (0x130)
#define       GPD_FNC1                    (0x134)
#define       GPD_FNC2                    (0x138)
#define       GPD_FNC3                    (0x13C)
#define       GPD_SR0                     (0x140)
#define       GPD_SR1                     (0x144)
#define       GPD_SR2                     (0x148)
#define       GPD_SR3                     (0x14C)

//GPIO_I
#define       GPI_DAT   (0x2A0)
#define       GPI_OEN   (0x2B0)
#define       GPI_IEN   (0x2BC)
#define       GPI_DS0   (0x2C4)
#define       GPI_DS1   (0x2C8)
#define       GPI_FNC0  (0x2D4)
#define       GPI_FNC1  (0x2D8)

//GPIO_L
#define       GPL_DAT   (0x39C)
#define       GPL_OEN   (0x3AC)
#define       GPL_IEN   (0x3B8)
#define       GPL_DS0   (0x3C0)
#define       GPL_DS1   (0x3C4)
#define       GPL_DS2   (0x3C8)
#define       GPL_FNC0  (0x3D0)
#define       GPL_FNC1  (0x3D4)
#define       GPL_FNC2  (0x3D8)

#endif	//	end of #ifndef  _PLATFORM_H_
