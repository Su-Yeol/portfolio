// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_switch_ioctl.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    ioctl for switch
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                     Include Files
 **********************************************************************/
#include <linux/string.h>
#include <linux/netdevice.h>

#include "reg_hal.h"
#include "fp_bridge_table.h"
#include "fp_library.h"
#include "fp_ioctl.h"
#include "fp_switch.h"
#include "global_address_map_fpga.h"
#include "hw_2field_hash_table.h"
#include "nc_conf.h"
#include "wsp_vlan_hash_table_L.h"


/* extern void fp_get_hw_bridge_entries(nc_entries_ops_t *);
extern int32a br_entry_count; */
/*
 * Function: updateBridgeEntry
 */
int32a updateBridgeEntry(fp_bridgeEntry_t *srcEntry, nc_bridge_entry_t *br_entry)
{
	int32a i;

	br_entry->be_pktcount	= srcEntry->pktCount;
	br_entry->be_vlanid	= srcEntry->vlanId;
	br_entry->be_state	= srcEntry->entryState;
	br_entry->be_actions	= srcEntry->flowActionFlags;
	br_entry->be_vlanid	= *(((uint8 *)srcEntry) + 18) & 0xFFFF;
	br_entry->be_state	= 2;

	for (i = 0; i < ETH_ALEN-2; i++)
	{
		br_entry->be_macaddr[3-i] = *(((uint8 *)srcEntry) + 8 + i) & 0xFF;
	}

	br_entry->be_macaddr[5] = *(((uint8 *)srcEntry) + 14) & 0xFF;
	br_entry->be_macaddr[4] = *(((uint8 *)srcEntry) + 15) & 0xFF;
	FP_DEBUG(DBGP_FEAT_IOCTL, FP_LOG_INFO, "********VLANID %x *******\n",
						br_entry->be_vlanid  & 0xFFFF);
	return 0;
}

#define MAC_HASH_TABLE (TWO_FIELD_HASH_ENTRIES + TWO_FIELD_COLL_ENTRIES)

int32a fp_get_hw_bridge_entries(nc_entries_ops_t *pent_ops, nc_entries_ops_t *puser_ent_ops)
{
	int32a i = 0, temp = 0;
	uint32a word1 = 0;
	uint32a word2 = 0;
	uint32a word3 = 0;
	uint32a word4 = 0;
	uint32a word5 = 0;
	uint32a word6 = 0;
	uint32a word7 = 0;
	uint32a hw_br_entry_count = 0;
	uint32a br_entry_size = 0;
	uint32a limitReached = 0;
	nc_bridge_entry_t br_entry;
	if (GetBaseAddr() == NULL) {
		FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_EMERG, "%s: membase is NULL\n", __func__);
		return 0;
	}
	memset(&br_entry, 0, sizeof(br_entry));
	/*==============================================================*
	* MAC1:MAC[31:0]						*
	*===============================================================*
	* MAC2:ACT_ENTRY[31:29] + VLANID[28:16] + MAC[15:0]		*
	*===============================================================*
	* MAC3:FIELD_VALIDS[31:28] + ACT_ENTRY[27:0]			*
	*===============================================================*
	* MAC4:RSVD[31:28]+VALIDBITS[27:24]+COLPTR[23:8]+PORTNO[7:4]+	*
	*					FIELDVALIDS[3:0]	*
	*===============================================================*/
/*    printk("CMD %x STATUS %x MAC1 %x MAC2 %x\n", MAC_HASH_HOST_CMD_REG,
		MAC_HASH_HOST_STATUS_REG, MAC_HASH_HOST_MAC1_ADDR_REG, MAC_HASH_HOST_MAC2_ADDR_REG); */
	/* now all hash block registers are direct access from host */
	for (i = 0; i < MAC_HASH_TABLE; i++) {
		uint32a cmd = (CMD_MEM_READ | (i << 16));
		/* Issue MEM_READ cmd */
		IssueCommand(MAC_HASH_HOST_CMD_REG,
				cmd,
				MAC_HASH_HOST_STATUS_REG,
				STATUS_CMD_DONE);
		word1 = TableRead(MAC_HASH_HOST_MAC1_ADDR_REG, DEFAULT_TABLE);
		word2 = TableRead(MAC_HASH_HOST_MAC2_ADDR_REG, DEFAULT_TABLE);
		word3 = TableRead(MAC_HASH_HOST_MAC3_ADDR_REG, DEFAULT_TABLE);
		/* get entry valid field */
		word4 = TableRead(MAC_HASH_HOST_MAC4_ADDR_REG, DEFAULT_TABLE);
		word5 = TableRead(MAC_HASH_HOST_MAC5_ADDR_REG, DEFAULT_TABLE);
		word6 = TableRead(MAC_HASH_HOST_ENTRY_REG,	   DEFAULT_TABLE);
		word7 = TableRead(MAC_HASH_HOST_DIRECT_REG,    DEFAULT_TABLE);

		/* Clear STATUS reg by writing all 1's */
		TableWrite(MAC_HASH_HOST_STATUS_REG, 0xFFFFFFFF, DEFAULT_TABLE);
		if (word6 & 0x08000000) {
		//if(word1 || word2) {
			/* Reading MAC1 & MAC2 reg */
			word1 = TableRead(MAC_HASH_HOST_MAC1_ADDR_REG, DEFAULT_TABLE);
			word2 = TableRead(MAC_HASH_HOST_MAC2_ADDR_REG, DEFAULT_TABLE);
			/* Reading MAC3 which tells Active/Inactive &
					Static/Dynamic state of entry */
			word3 = TableRead(MAC_HASH_HOST_MAC3_ADDR_REG, DEFAULT_TABLE);
			memset(&br_entry, 0, sizeof(br_entry));
			/* copy bridge entries to user space */
			if (br_entry_size +	sizeof(br_entry) > pent_ops->ent_size)
			{
				limitReached = 1;
				FP_DEBUG(DBGP_FEAT_IOCTL, FP_LOG_DEBUG, "BREAK: br_entry_size %u", br_entry_size);
				FP_DEBUG(DBGP_FEAT_IOCTL, FP_LOG_DEBUG, "total_ent_size %u\n", pent_ops->ent_size);
			}
			/* update mac and state to br_entry */
			fp_convert_le2be((int8 *)&word1, 4);
			memcpy((uint32a *)&br_entry.be_macaddr[0], (uint32a *)&word1, 4);
			br_entry.be_macaddr[5] = word2 & 0xff;
			br_entry.be_macaddr[4] = (word2 >> 8) & 0xff;
			br_entry.be_vlanid = (word2 >> 16 & 0x3ff);
			/* update active state/inactive */
			if (word3 & 0x04000000 /* BRENTRY_STATUS_BIT */) {
				br_entry.be_state = BRIDGE_ENTRY_INACTIVE;
				FP_DEBUG(DBGP_FEAT_IOCTL, FP_LOG_DEBUG, "ACTIVE STATE\n");
			} else {
				FP_DEBUG(DBGP_FEAT_IOCTL, FP_LOG_DEBUG, "INACTIVE STATE\n");
				br_entry.be_state = BRIDGE_ENTRY_ACTIVE;
			}
			/*Update entry acrions*/
			/* extract action entry */
			br_entry.be_actions = ((word3 << 3) | (word2 >> 29)) & 0x7FFFFFFF;
			if (copy_to_user(puser_ent_ops->ent_data+br_entry_size, &br_entry, sizeof(br_entry)))
				temp = sizeof(nc_bridge_entry_t);
			FP_DEBUG(DBGP_FEAT_IOCTL, FP_LOG_DEBUG, "temp %u\n", temp);
			br_entry_size = br_entry_size + sizeof(nc_bridge_entry_t);
			FP_DEBUG(DBGP_FEAT_IOCTL, FP_LOG_DEBUG,
				"br entry size %u cnt %lu brentry size %lu\n",
				br_entry_size, (uint32)
				br_entry_size/(sizeof(br_entry)),
				(uint32)sizeof(br_entry));
			if (limitReached) {
				FP_DEBUG(DBGP_FEAT_IOCTL, FP_LOG_DEBUG, "memory not enough\n");
				/* break; */
			}
			FP_DEBUG(DBGP_FEAT_IOCTL, FP_LOG_DEBUG, "MAC1 %x MAC2 %x word3 %x\n", word1, word2, word3);
			hw_br_entry_count++;
		}
	}
	/* Copy the new size to users */
	if (copy_to_user(&(puser_ent_ops->ent_size), &br_entry_size, sizeof(br_entry_size)))
		return -EFAULT;
	/* Copy the new count to users */
	if (copy_to_user(&(puser_ent_ops->ent_count), &hw_br_entry_count, sizeof(hw_br_entry_count)))
		return -EFAULT;
	return 0;
}

#define VLAN_HASH_TABLE_SIZE (VLAN_HASH_ENTRIES + VLAN_COLL_HASH_ENTRIES)

int32a fp_get_hw_vlan_entries(nc_entries_ops_t *pent_ops, nc_entries_ops_t *puser_ent_ops)
{
	int32a i = 0;
	int32a temp = 0;
	uint32a word1 = 0;
	uint32a word2 = 0;
	uint32a word3 = 0;
	uint32a word4 = 0;
	uint32a hw_vlan_entry_count = 0;
	uint32a vlan_entry_size = 0;
	uint32a limitReached = 0;
	nc_vlan_entry_t vlan_entry;
	int64_t action_entry = 0;
	if (GetBaseAddr() == NULL) {
		FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_EMERG,
			"%s: membase is NULL\n", __func__);
		return 0;
	}
	memset(&vlan_entry, 0, sizeof(vlan_entry));
	/*==============================================================*
	* VLAN1:  ACTION[18:0] + VLAN[12:0]						*
	*===============================================================*
	* VLAN2:  ACTION[50-19]		*
	*===============================================================*
	* VLAN3:FIELD_VALIDS[31:55] + ACTION[54:51]			*
	*===============================================================*
	* VLAN4:RSVD[31:28]+VALIDBITS[27:24]+COLPTR[23:8]+PORTNO[7:4]+	*
	*					FIELDVALIDS[3:0]	*
	*===============================================================*/
	/* now all hash block registers are direct access from host */
	for (i = 0; i < VLAN_HASH_TABLE_SIZE; i++) {
		uint32a cmd;
		update_vlan_mac5_registers(0x0, 0x0, 0x0, 0x0, 0x0, DEFAULT_TABLE);
		/* Issue MEM_READ cmd */
		cmd = (CMD_MEM_READ | (i << 16));
		IssueCommand(	VLAN_HASH_HOST_CMD_REG,
				cmd,
				VLAN_HASH_HOST_STATUS_REG,
				STATUS_CMD_DONE);
		word1 = TableRead(VLAN_HASH_HOST_MAC1_ADDR_REG, DEFAULT_TABLE);
		word2 = TableRead(VLAN_HASH_HOST_MAC2_ADDR_REG, DEFAULT_TABLE);
		word3 = TableRead(VLAN_HASH_HOST_MAC3_ADDR_REG, DEFAULT_TABLE);
		word4 = TableRead(VLAN_HASH_HOST_MAC4_ADDR_REG, DEFAULT_TABLE);
		/* Check entry valid field instead of mac1 */
		//if (word4 & 0x08000000) {
		/* Clear STATUS reg by writing all 1's */
		TableWrite(VLAN_HASH_HOST_STATUS_REG, 0xFFFFFFFF, DEFAULT_TABLE);
		if (word1 != 0) {
			memset(&vlan_entry, 0, sizeof(vlan_entry));
			vlan_entry.vlanid = word1 & 0x1FFF;
			action_entry = (((uint64_t)word3 << 51) | ((uint64_t)word2 << 19) | (word1 >> 13));
			printk("action entry is %llx \n", action_entry);
			vlan_entry.fwd_port_list = (uint32a)(action_entry & 0xFFFFF);
			vlan_entry.untag_list = (uint32a)((action_entry >> 20) & 0xFFFFF);
			vlan_entry.ucast_hit_act = (uint8)((action_entry >> 40) & 0x7);
			vlan_entry.ucast_miss_act = (uint8)((action_entry >> 43) & 0x7);
			vlan_entry.mcast_hit_act = (uint8)((action_entry >> 46) & 0x7);
			vlan_entry.mcast_miss_act = (uint8)((action_entry >> 49) & 0x7);
			vlan_entry.mstp = (uint8)((action_entry >> 52) & 0x7);
			/* copy bridge entries to user space */
			if (vlan_entry_size +
				sizeof(vlan_entry) > pent_ops->ent_size) {
				limitReached = 1;
				FP_DEBUG(DBGP_FEAT_IOCTL, FP_LOG_DEBUG ,
				"BREAK: vlan_entry_size %u", vlan_entry_size);
				FP_DEBUG(DBGP_FEAT_IOCTL, FP_LOG_DEBUG ,
				"total_ent_size %u\n", pent_ops->ent_size);
			}
			if (copy_to_user(puser_ent_ops->ent_data+vlan_entry_size,
					&vlan_entry, sizeof(nc_vlan_entry_t)))
				temp = sizeof(nc_vlan_entry_t);
			FP_DEBUG(DBGP_FEAT_IOCTL, FP_LOG_DEBUG ,
						"temp %u\n", temp);
			vlan_entry_size = vlan_entry_size + sizeof(nc_vlan_entry_t);
			FP_DEBUG(DBGP_FEAT_IOCTL, FP_LOG_DEBUG,
				"br entry size %u cnt %lu brentry size %lu\n",
				vlan_entry_size, (uint32)
				vlan_entry_size/(sizeof(vlan_entry)),
				(uint32)sizeof(vlan_entry));
			if (limitReached) {
				FP_DEBUG(DBGP_FEAT_IOCTL, FP_LOG_DEBUG ,
						"memory not enough\n");
				/* break; */
			}
			FP_DEBUG(DBGP_FEAT_IOCTL, FP_LOG_DEBUG ,
			"MAC1 %x MAC2 %x word3 %x\n", word1, word2, word3);
			hw_vlan_entry_count++;
		}
	}
	/* Copy the new size to users */
	if (copy_to_user(&(puser_ent_ops->ent_size), &vlan_entry_size,
						sizeof(vlan_entry_size)))
		return -EFAULT;
	/* Copy the new count to users */
	if (copy_to_user(&(puser_ent_ops->ent_count), &hw_vlan_entry_count,
						sizeof(hw_vlan_entry_count)))
		return -EFAULT;
	return 0;
}

/* show only bridge entries */
int32a fp_switch_ioctl_entries_ops(struct net_device *dev, struct ifreq *rq, int32a cmd)
{
	int32a ret;
	nc_ioctl_ops_t pnc_ops;
	nc_entries_ops_t ent_ops;
	nc_entries_ops_t *pent_ops;
	nc_entries_ops_t *puser_ent_ops;
	ret = copy_from_user(&pnc_ops, (nc_ioctl_ops_t *)rq->ifr_ifru.ifru_data, sizeof(pnc_ops));
	if (ret)
		return -1;
	ret = copy_from_user(&ent_ops, (nc_entries_ops_t *)pnc_ops.io_data, sizeof(ent_ops));
	if (ret)
		return -1;
	pent_ops = &ent_ops;
	puser_ent_ops = (nc_entries_ops_t *)pnc_ops.io_data;
	FPATH_TRACE(FP_TRACE_CONFIG, FP_LOG_DEBUG,
		("pent_ops->ent_cmd = %d\n", pent_ops->ent_cmd));

	switch (pent_ops->ent_cmd)
	{
		case NC_GET_BRIDGE_ENTRIES:
		case NC_GET_BRIDGE_ENTRIES_EXT:
		case NC_GET_BRIDGE_ENTRIES_TABLE:
			fp_get_hw_bridge_entries(pent_ops, puser_ent_ops);
			break;

		case NC_GET_BRIDGE_ENTRIES_COUNT:
		{
			int32a entries_count = fp_rc_stats.hw_hash_entry_count;
			if (copy_to_user(puser_ent_ops->ent_data, &entries_count, sizeof(entries_count)))
				return -EFAULT;
		}
		break;

		case NC_GET_VLAN_ENTRIES_COUNT:
		{
			int32a entries_count = fp_rc_stats.hw_vlan_entry_count;
			if (copy_to_user(puser_ent_ops->ent_data, &entries_count,
				sizeof(entries_count)))
				return -EFAULT;
		}
		break;

		case NC_GET_VLAN_ENTRIES:
		case NC_GET_VLAN_ENTRIES_EXT:
		case NC_GET_VLAN_ENTRIES_TABLE:
			fp_get_hw_vlan_entries(pent_ops, puser_ent_ops);
			break;
	}

	return 0;
}

