/**
 * @file MRVL_AMG_HwInterface.h
 * @brief Hardware interface source file for API interfacing with registers
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */

#ifndef MRVL_AMG_HWINTF_H
#define MRVL_AMG_HWINTF_H

#include "MRVL_AMG_Device.h"
#include "MRVL_AMG_Customize.h"

extern MRVL_APHY_BOOL MRVL_AMG_MB_OPT;
extern MRVL_APHY_U16 MRVL_AMG_MB_OPT_ADDR_L;
extern MRVL_APHY_U16 MRVL_AMG_MB_OPT_ADDR_H;
extern MRVL_APHY_U16 MRVL_AMG_MB_OPT_DATA_L;
extern MRVL_APHY_U16 MRVL_AMG_MB_OPT_DATA_H;

/******************************************************************************
 *      HW interface functions
 ******************************************************************************/
/** @defgroup HWInterface HW Interface Utility */

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_ReadReg16(MRVL_DEV_PTR device, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16* regVal);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_WriteReg16(MRVL_DEV_PTR device, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16 regVal);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_ReadReg32(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U32* regVal);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_WriteReg32(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U32 regVal);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_Wait(MRVL_DEV_PTR device, MRVL_APHY_U16 waitTime);

void MRVL_AMG_OptimizeMB(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEnable);

#endif
