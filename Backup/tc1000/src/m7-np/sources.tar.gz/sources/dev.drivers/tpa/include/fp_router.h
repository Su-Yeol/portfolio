/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
 * @File
 * @Title        fp_router.h
 * @Copyright    Copyright (c) 2007-2009, Naksha Technologies, Inc.
 * @Copyright    Copyright (c) 2010-2012, Posedge Technologies, Inc.
 * @Copyright    Copyright (c) 2013-2020, Imagination Technologies Ltd.
 * @Copyright    Copyright (c) Imagination Technologies Ltd. All Rights Reserved
 * @Description  data structures and APIs for fpath router functionality
 * @License      Dual MIT/GPLv2
 *
 * The contents of this file are subject to the MIT license as set out below.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * the GNU General Public License Version 2 ("GPL") in which case the provisions
 * of GPL are applicable instead of those above.
 *
 * If you wish to allow use of your version of this file only under the terms of
 * GPL, and not to allow others to use your version of this file under the terms
 * of the MIT license, indicate your decision by deleting the provisions above
 * and replace them with the notice and other provisions required by GPL as set
 * out in the file called "GPL-COPYING" included in this distribution. If you do
 * not delete the provisions above,a recipient may use your version of this file
 * under the terms of either the MIT license or GPL.
 *
 * This License is also included in this distribution in the file called
 * "MIT-COPYING".
 *
 * EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 * PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */ /**************************************************************************/
#ifndef _FP_ROUTER_H_
#define _FP_ROUTER_H_
/*NEW route structure as per new rtl*/
struct  __attribute__((__packed__)) cacheFlow {
	uint32a	next;
	uint32a	vflag; /* valid flag - route entry valid, ipv6 valid etc */
	uint16	srcPort;
	uint16	dstPort;
	uint8	Proto;
	uint8	inPhyPortNum;
	uint16	hash;
	union {
		struct {
			uint32a   srcIP;
			uint32a   dstIP;
		} v4;
		struct {
			uint32a   src_ipv6[4];
			uint32a   dst_ipv6[4];
		} v6;
	} u;
	uint8	entryState;
	uint8	phyPortNum;
	/* information updated by the Classifier */
	uint8	classNotifyFlags;
	uint8	ifPortNum; /*To represent phyport and interface port numbers*/
	/* header construction related infor */
	uint8	srcMacAddr[6];
	uint8	dstMacAddr[6];
	uint32a	flowActionflags;
	uint16	pppoeSesId;
	uint16	vlanId;
	uint32a	chgSrcIp;
	uint32a	chgDstIp;
	uint16	chgSrcPort;
	uint16	chgDstPort;
	uint8	flag_ipv6;
	uint8	matchFlags;
	uint8	meterId;     /*Meter id for tlite, to select meter number*/
	uint8	res1;
	uint8	flow_lbl[3];
	uint8	flow_res;
	union {
		uint32a  sip[4];
		uint32a  dip[4];
	} chv6;
	uint16	vlanId1;
	uint16	reserved;
	uint32a	sa;
	union {
		/* vendor specific information */
		void  *addr;
		uint32a  dummy[2];
	} ct;
	uint32a      rt_orig;
};
/*OLD Route structure*/

/* Hash Table Structure */
struct fp_router_table {
	int32a     tbl_size;         /* size of the table */
	int32a     num_entries;      /* number of entries in this table */
	int32a     refcnt;           /* number of references to this table */
	struct cacheFlow **table;  /* table elements */
};

#define MAX_ROUTER_TABLES        12
struct fp_router_tables {
	int32a      num_tables;     /* number of tables created so far */
	struct fp_router_table *fp_router_tables[MAX_ROUTER_TABLES];
};

extern struct fp_router_tables router_tables;

/* route hash table global variable */
extern struct fp_router_table *fp_router_hash_table;

/* initialize router table array */
extern void init_fp_router_tables(struct fp_router_tables *rtr_tbls);

/* create a router table */
extern struct fp_router_table *fp_create_router_table(int32a size);

/*IPV6 */
extern struct cacheFlow *fp_ipv6_add_router_table_entry(uint16 in_usHashValue,
	struct cacheFlow *in_Entry, struct fp_router_table *in_hashTable);

extern int32a ipv6_hash5Tuple(struct cacheFlow *in_cacheFlow, uint16 hashMask);
extern int32a ipv6_hash5Tuple(struct cacheFlow *in_cacheFlow, uint16 hashMask);

extern struct cacheFlow *fp_ipv6_search_router_table_entry(uint16 in_usHashValue,
	struct cacheFlow *in_Entry, struct fp_router_table *in_hashTable);

/* Lookup address in hash table */
extern struct cacheFlow *fp_search_router_table_entry(uint16 in_usHashValue,
	struct cacheFlow *in_Entry, struct fp_router_table *in_hashTable);

/* Display contents of hash table*/
extern void fp_display_router_table_elements(int32a in_iTable_Size,
			struct fp_router_table *in_hashTable);

/* Count number of addresses available in hash table */
extern int32a fp_count_router_table_entries(struct fp_router_table *in_hashTable);

/* Delete Entry from hash table */
extern int32a fp_delete_router_table_entry(uint16 in_usHashValue,
	struct cacheFlow *in_Entry, struct fp_router_table *in_hashTable);

/* delete a router table */
extern void fp_delete_router_table(struct fp_router_table *router_table);

extern void fp_add_static_route_tables(void);
extern struct cacheFlow *fp_search_rtentry_local(uint16 in_hash, uint8 phyno);
extern void fp_update_rtentry_local(struct cacheFlow *rtEntry, uint16 in_hash, uint8 phyno);
extern uint16 ip_checksum(uint16 *buff, uint16 len);

#ifdef HASH_ARR_EN
extern struct cacheFlow *grtHashArr;
#endif

#endif /*End of _FP_ROUTER_H_ file */

