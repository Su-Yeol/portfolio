/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          fp_pre_header.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    contains tx/rx prepended headers
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifndef _FP_PRE_HEADER_H_
#define _FP_PRE_HEADER_H_

#define FP_TX_HDR_LEN	16
#define FP_RX_HDR_LEN	16
#define FP_EGR_TSR_LEN	16

#define FP_TX_PKT_INJECT_EN	(1 << 0)
#define FP_TX_LAUNCH_TIME_VALID	(1 << 1)
#define FP_TX_PKT_PTP_EN	(1 << 2)
#define FP_EGR_TSR_VALID	(1 << 4)
#define FP_PUNT_VALID		(1 << 5)
#define FP_RX_TS_VALID		(1 << 6)

#define FP_INJECT_TO_EMAC_1	(1 << 0)
#define FP_INJECT_TO_EMAC_2	(1 << 1)
#define FP_INJECT_TO_HIF_1	(1 << 2)
#define FP_INJECT_TO_HIF_2	(1 << 3)

/* Punt reason codes */
#define FP_PUNT_L2_SPL		(1 << 0)
#define FP_PUNT_SA_MISS		(1 << 1)
#define FP_PUNT_SA_RELEARN	(1 << 2)
#define FP_PUNT_SA_IS_ACTIVE	(1 << 3)
#define FP_PUNT_SNOOP_UPPER	(1 << 4)
#define FP_PUNT_REQ		(1 << 5)
#define FP_PUNT_MGMT		(1 << 6)
#define FP_PUNT_IGMP		(1 << 7)
#define FP_PUNT_FLOOD		(1 << 8)
#define FP_PUNT_PARSE		(1 << 9)

#define HIF_ICV_CHECK_IGNORED_BIT 0x80

struct tx_header
{
	uint32a queue: 4;
	uint32a txport_map: 20;
	uint32a ctrl: 8;

	uint32a ref_num:16;
	//uint16 rsvd1;  // bit22
	uint32a ch_num:6;
	uint32a pbc:1;
	uint32a rsvd1:9;

	uint32a sad_ptr;   // sad ptr
	//uint32a rsvd3; //  16 bytes msb ophy--> 16 bytes low

	uint16 in_phy;
	uint16 out_phy;
};

struct rx_header
{
	uint16	punt_reason;
	uint8	rxport_num;
	uint8	ctrl;
	uint32a	rsvd;
	uint32a	rx_timestamp_nsec;
	uint32a	rx_timestamp_sec;
};

struct egress_report
{
	uint8	rsvd[3];
	uint8	ctrl;
	uint32a	rsvd1;
	uint32a	egress_timestamp_nsec;
	uint32a	egress_timestamp_sec;
	uint8	rsvd2;
	uint8	rxport_num;
	uint16	ref_num;
};

#if 0
/* forward declaration to avoid warnings */
struct sk_buff;

int32a fp_fill_tx_ptp_header(struct tx_header *txhdr, struct sk_buff *skb);
int32a fp_add_prepend_tx_header(struct sk_buff *skb);
int32a fp_process_rx_header(struct sk_buff *skb);

#define FLOOD_TO_EMAC_PORTS	1
#ifdef FLOOD_TO_EMAC_PORTS
#define CB_INJ_TX_FLAG		47
#define CB_INJ_TX_PORT		42
#define CB_TX_SA_MISS		0x40
void fp_tx_inject_packet(struct sk_buff *skb, int32a rx_port);
#endif
#endif
#endif  /*End of _FP_PRE_HEADER_H_*/

