/**
 * @file MRVL_Q222X_MACsecTypes.h
 * @brief Q222X MACsec Types Header File
 * Header file contains MACsec Types and Define of Marvell Q222X
 *
 * @par Copyright and Version
 * See MRVL_Q222X_Copyright_and_Version.h
 */

#ifndef MRVL_Q222X_MSEC_TYPES_H
#define MRVL_Q222X_MSEC_TYPES_H

#include "MRVL_Q222X_Types.h"

#define MRVL_Q222X_MSEC_ETHTYPE 0x88E5U
#define MRVL_Q222X_MSEC_SAK_LEN 32
#define MRVL_Q222X_MSEC_HASHKEY_LEN 16
#define MRVL_Q222X_MSEC_SALTKEY_LEN 12
#define MRVL_Q222X_MAC_ADDR_LEN 6

/* capability */
#define MRVL_Q222X_MSEC_MAX_SECY_MAP_NUM 4
#define MRVL_Q222X_MSEC_MAX_SECY_NUM 4
#define MRVL_Q222X_MSEC_MAX_RULE_NUM 4
#define MRVL_Q222X_MSEC_MAX_SC_NUM 4
#define MRVL_Q222X_MSEC_MAX_SA_NUM 8
#define MRVL_Q222X_MSEC_MAX_CUSTOM_TAG_NUM 8
#define MRVL_Q222X_MSEC_MAX_CTRL_PCKT_ETYPE_NUM 8
#define MRVL_Q222X_MSEC_MAX_CTRL_PCKT_DA_NUM 8
#define MRVL_Q222X_MSEC_MAX_CTRL_PCKT_DA_RANGE_NUM 4
#define MRVL_Q222X_MSEC_MAX_CTRL_PCKT_COMBO_NUM 4

/* channel shift */
#define MRVL_Q222X_MSEC_RANGE4 2U
#define MRVL_Q222X_MSEC_RANGE8 4U
#define MRVL_Q222X_MSEC_RANGE16 8U
#define MRVL_Q222X_MSEC_RANGE32 16U
#define MRVL_Q222X_MSEC_RANGE64 32U
#define MRVL_Q222X_MSEC_RANGE128 64U
#define MRVL_Q222X_MSEC_REG_BUS_WIDTH 4U

/* Register Address*/
#define MRVL_Q222X_MAC_DEV 0x1FU
#define	MRVL_Q222X_MMAC_READ_LOW 0x97FEU
#define	MRVL_Q222X_MMAC_READ_HIGH  0x97FFU

#define MRVL_Q222X_MSEC_SLC_CFG 0x8000U
#define MRVL_Q222X_MSEC_PEX_RX_SLAVE 0x380U
#define MRVL_Q222X_MSEC_PEX_TX_SLAVE 0x480U

#define MRVL_Q222X_MSEC_TX_SA_KEY_LOCKOUT 0x19A4U
#define MRVL_Q222X_MSEC_RX_SA_KEY_LOCKOUT 0x634U

#define MRVL_Q222X_MSEC_TX_FLOWID_TCAM_ENABLE 0x1EC0U
#define MRVL_Q222X_MSEC_TX_FLOWID_TCAM_DATA 0x1ED0U
#define MRVL_Q222X_MSEC_TX_FLOWID_TCAM_MASK 0x1F50U
#define MRVL_Q222X_MSEC_TX_SECY_MAP_MEM 0x19B0U
#define MRVL_Q222X_MSEC_TX_SECY_PLCY_MEM 0x19F0U
#define MRVL_Q222X_MSEC_TX_SA_MAP_MEM 0x1A40U
#define MRVL_Q222X_MSEC_TX_SA_ACTIVE 0x1A10U
#define MRVL_Q222X_MSEC_TX_SA_INDEX0_VLD 0x1A20U
#define MRVL_Q222X_MSEC_TX_SA_INDEX1_VLD 0x1A30U
#define MRVL_Q222X_MSEC_TX_AUTO_REKEY 0x1998U
#define MRVL_Q222X_MSEC_TX_SA_PLCY_MEM 0x1A80U
#define MRVL_Q222X_MSEC_TX_SA_PN_TABLE_MEM 0x1E80U
#define MRVL_Q222X_MSEC_TX_PN_THRESHOLD 0x19A0U
#define MRVL_Q222X_MSEC_TX_XPN_THRESHOLD 0x199CU

#define MRVL_Q222X_MSEC_RX_FLOWID_TCAM_ENABLE 0x940U
#define MRVL_Q222X_MSEC_RX_FLOWID_TCAM_DATA 0x950U
#define MRVL_Q222X_MSEC_RX_FLOWID_TCAM_MASK 0x9D0U
#define MRVL_Q222X_MSEC_RX_SECY_MAP_MEM 0x63CU
#define MRVL_Q222X_MSEC_RX_SECY_PLCY_MEM 0x65CU
#define MRVL_Q222X_MSEC_RX_SC_CAM 0xA58U
#define MRVL_Q222X_MSEC_RX_SA_MAP_MEM 0x67CU
#define MRVL_Q222X_MSEC_RX_SA_PLCY_MEM 0x700U
#define MRVL_Q222X_MSEC_RX_SA_PN_TABLE_MEM 0x900U
#define MRVL_Q222X_MSEC_RX_PN_THRESHOLD 0x62CU
#define MRVL_Q222X_MSEC_RX_XPN_THRESHOLD 0x628U
#define MRVL_Q222X_MSEC_RX_DEFAULT_SCI 0x624U

#define MRVL_Q222X_MSEC_RX_SC_CAM_ENABLE 0xA50U
#define MRVL_Q222X_MSEC_PORT_CONFIG_PARSE 0x4U
#define MRVL_Q222X_MSEC_CHANNEL_BYPASS 0x6U
#define MRVL_Q222X_MSEC_CSE_CLR_ON_RD_RX 0x588U
#define MRVL_Q222X_MSEC_CSE_CLR_ON_RD_TX 0x5A0U
#define MRVL_Q222X_MSEC_VLAN_TAG_PARSER_OFFSET 0xAU
#define MRVL_Q222X_MSEC_ETYPE_ENABLE 0xDEU

#define MRVL_Q222X_MSEC_TX_STATS_CLEAR 0x5A8U    /* CSE_TX */
#define MRVL_Q222X_MSEC_RX_STATS_CLEAR 0x590U    /* CSE_RX */

#define MRVL_Q222X_MSEC_CTRL_PCKT_RULE_ETYPE 0x28U
#define MRVL_Q222X_MSEC_CTRL_PCKT_RULE_DA 0x38U
#define MRVL_Q222X_MSEC_CTRL_PCKT_RULE_DA_RANGE 0x58U
#define MRVL_Q222X_MSEC_CTRL_PCKT_RULE_COMBO 0x90U
#define MRVL_Q222X_MSEC_CTRL_PCKT_RULE_MAC 0xD8U
#define MRVL_Q222X_MSEC_CTRL_PCKT_RULE_ENABLE 0xDCU

#define MRVL_Q222X_MSEC_IN_OCETS_SECY_DECRYPTED 0x3400U
#define MRVL_Q222X_MSEC_IN_OCETS_SECY_VALIDATE 0x33F0U
#define MRVL_Q222X_MSEC_IN_PKTS_SECY_NO_SA 0x33D0U
#define MRVL_Q222X_MSEC_IN_PKTS_SECY_NO_SA_ERROR 0x33E0U
#define MRVL_Q222X_MSEC_IN_PKTS_SECY_BAD_TAG 0x33C0U
#define MRVL_Q222X_MSEC_IN_PKTS_SECY_NO_TAG 0x33B0U
#define MRVL_Q222X_MSEC_IN_PKTS_SECY_UNTAGGED 0x33A0U
#define MRVL_Q222X_MSEC_IN_PKTS_CTRL_PORT_DISABLE 0x3390U
#define MRVL_Q222X_MSEC_IN_CTRL_PORT_OCETS 0x3300U
#define MRVL_Q222X_MSEC_IN_CTRL_PORT_UC_PKTS 0x3310U
#define MRVL_Q222X_MSEC_IN_CTRL_PORT_MC_PKTS 0x3320U
#define MRVL_Q222X_MSEC_IN_CTRL_PORT_BC_PKTS 0x3330U
#define MRVL_Q222X_MSEC_IN_UNCTRL_PORT_OCETS 0x3340U
#define MRVL_Q222X_MSEC_IN_UNCTRL_PORT_UC_PKTS 0x3350U
#define MRVL_Q222X_MSEC_IN_UNCTRL_PORT_MC_PKTS 0x3360U
#define MRVL_Q222X_MSEC_IN_UNCTRL_PORT_BC_PKTS 0x3370U

#define MRVL_Q222X_MSEC_OUT_PKTS_CTRL_PORT_DISABLE 0x3520U
#define MRVL_Q222X_MSEC_OUT_PKTS_SECY_UNTAGGED 0x3530U
#define MRVL_Q222X_MSEC_OUT_PKTS_SECY_NO_ACTIVE_SA 0x3540U
#define MRVL_Q222X_MSEC_OUT_PKTS_SECY_TOO_LONG 0x3550U
#define MRVL_Q222X_MSEC_OUT_OCETS_SECY_PROTECTED 0x3560U
#define MRVL_Q222X_MSEC_OUT_OCETS_SECY_ENCRYPTED 0x3570U
#define MRVL_Q222X_MSEC_OUT_CTRL_PORT_OCETS 0x34A0U
#define MRVL_Q222X_MSEC_OUT_CTRL_PORT_UC_PKTS 0x34B0U
#define MRVL_Q222X_MSEC_OUT_CTRL_PORT_MC_PKTS 0x34C0U
#define MRVL_Q222X_MSEC_OUT_CTRL_PORT_BC_PKTS 0x34D0U
#define MRVL_Q222X_MSEC_OUT_UNCTRL_PORT_OCETS 0x34E0U
#define MRVL_Q222X_MSEC_OUT_UNCTRL_PORT_UC_PKTS 0x34F0U
#define MRVL_Q222X_MSEC_OUT_UNCTRL_PORT_MC_PKTS 0x3500U
#define MRVL_Q222X_MSEC_OUT_UNCTRL_PORT_BC_PKTS 0x3510U

#define MRVL_Q222X_MSEC_IN_PKTS_SC_CAM_HIT 0x3620U
#define MRVL_Q222X_MSEC_IN_PKTS_SC_LATE 0x3420U
#define MRVL_Q222X_MSEC_IN_PKTS_SC_NOT_VALID 0x3430U
#define MRVL_Q222X_MSEC_IN_PKTS_SC_INVALID 0x3440U
#define MRVL_Q222X_MSEC_IN_PKTS_SC_DELAYED 0x3450U
#define MRVL_Q222X_MSEC_IN_PKTS_SC_UNCHECKED 0x3460U
#define MRVL_Q222X_MSEC_IN_PKTS_SC_OK 0x3470U

#define MRVL_Q222X_MSEC_OUT_PKTS_PROTECTED 0x3580U
#define MRVL_Q222X_MSEC_OUT_PKTS_ENCRYPTED 0x3590U

#define MRVL_Q222X_MSEC_IN_PKTS_PARSE_ERR 0x3480U
#define MRVL_Q222X_MSEC_IN_PKTS_FLOW_ID_TCAM_MISS 0x3484U
#define MRVL_Q222X_MSEC_IN_PKTS_EARLY_PREEMPT_ERR 0x3488U
#define MRVL_Q222X_MSEC_IN_PKTS_FLOW_ID_TCAM_HIT_0 0x348CU
#define MRVL_Q222X_MSEC_IN_PKTS_FLOW_ID_TCAM_HIT_1 0x3490U
#define MRVL_Q222X_MSEC_IN_PKTS_FLOW_ID_TCAM_HIT_2 0x3494U
#define MRVL_Q222X_MSEC_IN_PKTS_FLOW_ID_TCAM_HIT_3 0x3498U

#define MRVL_Q222X_MSEC_OUT_PKTS_PARSE_ERR 0x35A0U
#define MRVL_Q222X_MSEC_OUT_PKTS_FLOW_ID_TCAM_MISS 0x35A4U
#define MRVL_Q222X_MSEC_OUT_PKTS_EARLY_PREEMPT_ERR 0x35A8U
#define MRVL_Q222X_MSEC_OUT_PKTS_FLOW_ID_TCAM_HIT_0 0x35ACU
#define MRVL_Q222X_MSEC_OUT_PKTS_FLOW_ID_TCAM_HIT_1 0x35B0U
#define MRVL_Q222X_MSEC_OUT_PKTS_FLOW_ID_TCAM_HIT_2 0x35B4U
#define MRVL_Q222X_MSEC_OUT_PKTS_FLOW_ID_TCAM_HIT_3 0x35B8U

#define MRVL_Q222X_SMAC_RX_STATS_GOODOCTETS 0x9000U
#define MRVL_Q222X_SMAC_RX_STATS_ERROROCTETS 0x9004U
#define MRVL_Q222X_SMAC_RX_STATS_JABBER 0x9008U
#define MRVL_Q222X_SMAC_RX_STATS_FRAGMENT 0x900CU
#define MRVL_Q222X_SMAC_RX_STATS_UNDERSIZE 0x9010U
#define MRVL_Q222X_SMAC_RX_STATS_OVERSIZE 0x9014U
#define MRVL_Q222X_SMAC_RX_STATS_RXERROR 0x9018U
#define MRVL_Q222X_SMAC_RX_STATS_CRCERR_TXUNDERRUN 0x901CU
#define MRVL_Q222X_SMAC_RX_STATS_RXOVERRUN_BADFC 0x9020U
#define MRVL_Q222X_SMAC_RX_STATS_GOODPKTS 0x9024U
#define MRVL_Q222X_SMAC_RX_STATS_FCPKT 0x9028U
#define MRVL_Q222X_SMAC_RX_STATS_BROADCAST 0x902CU
#define MRVL_Q222X_SMAC_RX_STATS_MULTICAST 0x9030U
#define MRVL_Q222X_SMAC_RX_STATS_INPASSEMBLYERR 0x9034U
#define MRVL_Q222X_SMAC_RX_STATS_INPFRAMES 0x9038U
#define MRVL_Q222X_SMAC_RX_STATS_INPFRAGS 0x903CU
#define MRVL_Q222X_SMAC_RX_STATS_INPBADFRAGS 0x9040U

#define MRVL_Q222X_SMAC_TX_STATS_GOODOCTETS 0x9080U
#define MRVL_Q222X_SMAC_TX_STATS_ERROROCTETS 0x9084U
#define MRVL_Q222X_SMAC_TX_STATS_JABBER 0x9088U
#define MRVL_Q222X_SMAC_TX_STATS_FRAGMENT 0x908CU
#define MRVL_Q222X_SMAC_TX_STATS_UNDERSIZE 0x9090U
#define MRVL_Q222X_SMAC_TX_STATS_OVERSIZE 0x9094U
#define MRVL_Q222X_SMAC_TX_STATS_RXERROR 0x9098U
#define MRVL_Q222X_SMAC_TX_STATS_CRCERR_TXUNDERRUN 0x909CU
#define MRVL_Q222X_SMAC_TX_STATS_RXOVERRUN_BADFC 0x90A0U
#define MRVL_Q222X_SMAC_TX_STATS_GOODPKTS 0x90A4U
#define MRVL_Q222X_SMAC_TX_STATS_FCPKT 0x90A8U
#define MRVL_Q222X_SMAC_TX_STATS_BROADCAST 0x90ACU
#define MRVL_Q222X_SMAC_TX_STATS_MULTICAST 0x90B0U
#define MRVL_Q222X_SMAC_TX_STATS_OUTPFRAGS 0x90B4U
#define MRVL_Q222X_SMAC_TX_STATS_OUTPFRAMES 0x90B8U

#define MRVL_Q222X_WMAC_RX_STATS_PKTS 0x9180U
#define MRVL_Q222X_WMAC_RX_STATS_DROPPEDPKTS 0x9184U
#define MRVL_Q222X_WMAC_RX_STATS_OCTETS 0x9188U
#define MRVL_Q222X_WMAC_RX_STATS_JABBER 0x918CU
#define MRVL_Q222X_WMAC_RX_STATS_FRAGMENT 0x9190U
#define MRVL_Q222X_WMAC_RX_STATS_UNDERSIZE 0x9194U
#define MRVL_Q222X_WMAC_RX_STATS_RXERROR 0x9198U
#define MRVL_Q222X_WMAC_RX_STATS_CRCERROR 0x919CU
#define MRVL_Q222X_WMAC_RX_STATS_FCPKTS 0x91A0U
#define MRVL_Q222X_WMAC_RX_STATS_BROADCASTPKTS 0x91A4U
#define MRVL_Q222X_WMAC_RX_STATS_MULTICASTPKTS 0x91A8U
#define MRVL_Q222X_WMAC_RX_STATS_INPASSEMBLYERR 0x91DCU
#define MRVL_Q222X_WMAC_RX_STATS_INPFRAMES 0x91E0U
#define MRVL_Q222X_WMAC_RX_STATS_INPFRAGS 0x91E4U
#define MRVL_Q222X_WMAC_RX_STATS_INPBADFRAGS 0x91E8U

#define MRVL_Q222X_WMAC_TX_STATS_PKTS 0x9380U
#define MRVL_Q222X_WMAC_TX_STATS_DROPPEDPKTS 0x9384U
#define MRVL_Q222X_WMAC_TX_STATS_OCTETS 0x9388U
#define MRVL_Q222X_WMAC_TX_STATS_JABBER 0x938CU
#define MRVL_Q222X_WMAC_TX_STATS_FRAGMENT 0x9390U
#define MRVL_Q222X_WMAC_TX_STATS_UNDERSIZE 0x9394U
#define MRVL_Q222X_WMAC_TX_STATS_RXERROR 0x9398U
#define MRVL_Q222X_WMAC_TX_STATS_CRCERROR 0x939CU
#define MRVL_Q222X_WMAC_TX_STATS_FCPKTS 0x93A0U
#define MRVL_Q222X_WMAC_TX_STATS_BROADCASTPKTS 0x93A4U
#define MRVL_Q222X_WMAC_TX_STATS_MULTICASTPKTS 0x93A8U
#define MRVL_Q222X_WMAC_TX_STATS_OUTPFRAGS 0x93DCU
#define MRVL_Q222X_WMAC_TX_STATS_OUTPFRAMES 0x93E0U


#define MRVL_Q222X_COUNTERMASK_MACSEC	0xFFFFFFFFFFFFFFFFU
#define MRVL_Q222X_COUNTERMASK_MMAC	0xFFFFFFFFFFFU

/**
 * @brief Define the MAC forwarding mode enum
 *
 */
typedef enum
{
	MRVL_Q222X_MAC_CUT_THROUGH = 0,
	MRVL_Q222X_MAC_STORE_FWD = 3
} MRVL_Q222X_MAC_FWD_MODE;

/**
 * @brief Define the MAC power mode enum
 *
 */
typedef enum
{
	MRVL_Q222X_MAC_LOW_POWER   = 0,
	MRVL_Q222X_MAC_LOW_LATENCY = 1
} MRVL_Q222X_MAC_POWER_MODE;

/**
 * @brief Define the permit police for frames as defined in 802.1ae
 *
 */
typedef enum
{
	MRVL_Q222X_MSEC_VF_DISABLED = 0,	/*!< Disable validation */
	MRVL_Q222X_MSEC_VF_CHECK = 1, 		/*!< Enable validation, do not discard invalid frames*/
	MRVL_Q222X_MSEC_VF_STRICT = 2, 		/*!< Enable validation and discard invalid frames */
	MRVL_Q222X_MSEC_VF_NA = 3 			/*!< No processing or accounting */
} MRVL_Q222X_MSEC_VALIDATEFRAME;

/**
 * @brief Define SecTag and ICV configuration.
 *
 */
typedef enum
{
	MRVL_Q222X_MSEC_SECTAG_ICV_BOTH_STRIP = 0,		/*!< Strip both SecTag and ICV from packet */
	MRVL_Q222X_MSEC_SECTAG_ICV_RESERVED = 1,
	MRVL_Q222X_MSEC_SECTAG_ICV_STRIP_ICV_ONLY = 2,	/*!< Preserve SecTag, Strip ICV */
	MRVL_Q222X_MSEC_SECTAG_ICV_NO_STRIP = 3 		/*!< Preserve both SecTag and ICV */
} MRVL_Q222X_MSEC_STRIP_SECTAG_ICV;

/**
 * @brief Define Encoded Packet Type from the parser
 *
 */
typedef enum
{
	MRVL_Q222X_MSEC_PACKET_NO_VLAN_OR_MPLS = 0,
	MRVL_Q222X_MSEC_PACKET_SINGLE_VLAN = 1,
	MRVL_Q222X_MSEC_PACKET_DUAL_VLAN = 2,
	MRVL_Q222X_MSEC_PACKET_MPLS = 3,
	MRVL_Q222X_MSEC_PACKET_SINGLE_VLAN_FOLLOW_BY_MPLS = 4,
	MRVL_Q222X_MSEC_PACKET_DUAL_VLAN_FOLLOW_BY_MPLS = 5,
	MRVL_Q222X_MSEC_PACKET_UNSUPPORTED_TYPE = 6
} MRVL_Q222X_MSEC_PACKET_TYPE;

/**
 * @brief Define the cipher suite to use for this SecY
 *
 */
typedef enum
{
	MRVL_Q222X_MSEC_CIPHER_GCM_AES_128 = 0,
	MRVL_Q222X_MSEC_CIPHER_GCM_AES_256 = 1,
	MRVL_Q222X_MSEC_CIPHER_GCM_AES_128_XPN = 2,
	MRVL_Q222X_MSEC_CIPHER_GCM_AES_256_XPN = 3
} MRVL_Q222X_MSEC_CIPHER_SUITE;

/**
 * @brief Structure of SMC RX stats
 *
 */
typedef struct {
	MRVL_APHY_U64 goodOctets;		/*!< Good frame octets */
	MRVL_APHY_U64 errorOctets;		/*!< Bad frame octets */
	MRVL_APHY_U64 jabber;			/*!< Frame of size > MTU and bad CRC */
	MRVL_APHY_U64 fragment;			/*!< Frame < 48B with bad CRC */
	MRVL_APHY_U64 undersize;		/*!< Frame < 48B with good CRC */
	MRVL_APHY_U64 oversize;			/*!< Frame of size > MTU and good CRC */
	MRVL_APHY_U64 rxError;			/*!< sequence, code, symbol errors */
	MRVL_APHY_U64 crcErrTxUnderrun;	/*!< CRC error */
	MRVL_APHY_U64 rxOverrunBadFC;	/*!< Overrun or bad flow control packet */
	MRVL_APHY_U64 goodPkts;			/*!< number of good packets */
	MRVL_APHY_U64 fcPkts;			/*!< flow control packet */
	MRVL_APHY_U64 broadcast;		/*!< number of broadcast packets */
	MRVL_APHY_U64 multicast;		/*!< number of multicast packets */
	MRVL_APHY_U64 inPAssemblyErr;
	MRVL_APHY_U64 inPFrames;
	MRVL_APHY_U64 inPFrags;
	MRVL_APHY_U64 inPBadFrags;
}MRVL_Q222X_MSEC_RX_SMC_STATS;

/**
 * @brief Structure of SMC TX stats
 *
 */
typedef struct {
	MRVL_APHY_U64 goodOctets;		/*!< Good frame octets */
	MRVL_APHY_U64 errorOctets;		/*!< Bad frame octets */
	MRVL_APHY_U64 jabber;			/*!< Frame of size > MTU and bad CRC */
	MRVL_APHY_U64 fragment;			/*!< Frame < 48B with bad CRC */
	MRVL_APHY_U64 undersize;		/*!< Frame < 48B with good CRC */
	MRVL_APHY_U64 oversize;			/*!< Frame of size > MTU and good CRC */
	MRVL_APHY_U64 rxError;			/*!< sequence, code, symbol errors */
	MRVL_APHY_U64 crcErrTxUnderrun;	/*!< CRC error */
	MRVL_APHY_U64 rxOverrunBadFC;	/*!< Overrun or bad flow control packet */
	MRVL_APHY_U64 goodPkts;			/*!< number of good packets */
	MRVL_APHY_U64 fcPkts;			/*!< flow control packet */
	MRVL_APHY_U64 broadcast;		/*!< number of broadcast packets */
	MRVL_APHY_U64 multicast;		/*!< number of multicast packets */
	MRVL_APHY_U64 outPFrags;
	MRVL_APHY_U64 outPFrames;
}MRVL_Q222X_MSEC_TX_SMC_STATS;

/**
 * @brief Structure of WMC RX stats
 *
 */
typedef struct {
	MRVL_APHY_U64 pkts;				/*!< all packets */
	MRVL_APHY_U64 droppedPkts;		/*!< dropped packets */
	MRVL_APHY_U64 octets;			/*!< all packets octets */
	MRVL_APHY_U64 jabber;			/*!< packet > MTU and bad CRC */
	MRVL_APHY_U64 fragment;			/*!< packet < 64B and bad CRC */
	MRVL_APHY_U64 undersize;		/*!< packet < 64B and good CRC */
	MRVL_APHY_U64 rxError;			/*!< seqeunce, code, symbol errors */
	MRVL_APHY_U64 crcError;			/*!< CRC error packet */
	MRVL_APHY_U64 fcPkts;			/*!< flow control packet */
	MRVL_APHY_U64 broadcast;		/*!< number of broadcast packets */
	MRVL_APHY_U64 multicast;		/*!< number of multicast packets */
	MRVL_APHY_U64 inPAssemblyErr;
	MRVL_APHY_U64 inPFrames;
	MRVL_APHY_U64 inPFrags;
	MRVL_APHY_U64 inPBadFrags;
}MRVL_Q222X_MSEC_RX_WMC_STATS;

/**
 * @brief Structure of WMC TX stats
 *
 */
typedef struct {
	MRVL_APHY_U64 pkts;				/*!< all packets */
	MRVL_APHY_U64 droppedPkts;		/*!< dropped packets */
	MRVL_APHY_U64 octets;			/*!< all packets octets */
	MRVL_APHY_U64 jabber;			/*!< packet > MTU and bad CRC */
	MRVL_APHY_U64 fragment;			/*!< packet < 64B and bad CRC */
	MRVL_APHY_U64 undersize;		/*!< packet < 64B and good CRC */
	MRVL_APHY_U64 rxError;			/*!< seqeunce, code, symbol errors */
	MRVL_APHY_U64 crcError;			/*!< CRC error packet */
	MRVL_APHY_U64 fcPkts;			/*!< flow control packet */
	MRVL_APHY_U64 broadcast;		/*!< number of broadcast packets */
	MRVL_APHY_U64 multicast;		/*!< number of multicast packets */
	MRVL_APHY_U64 outPFrags;
	MRVL_APHY_U64 outPFrames;
}MRVL_Q222X_MSEC_TX_WMC_STATS;

/**
 * @brief Structure of SecY Rx stats
 *
 */
typedef struct {
	MRVL_APHY_U64 inOctetsSecYDecrypted;	/*!< The number of plaintext octets recovered from packets that were integrity protected and encrypted. */
	MRVL_APHY_U64 inOctetsSecYValidate;		/*!< The number of plaintext octets recovered from packets that were integrity protected but not encrypted. */
	MRVL_APHY_U64 inPktsSecYNoSAError;		/*!< The number of received packets discarded because the received SCI is unknown on the SA is not in use. */
	MRVL_APHY_U64 inPktsSecYNoSA;			/*!< The number of received packets with an unknown SA or an unused SA. */
	MRVL_APHY_U64 inPktsSecYBadTag;			/*!< The number of received packets discarded with an invalid SecTag, zero value PN, or invalid ICV. */
	MRVL_APHY_U64 inPktsSecYNoTag;			/*!< The number of received packets without a SecTag discarded because SecY.Validate_Frames was STRICT. */
	MRVL_APHY_U64 inPktsSecYUntagged;		/*!< The number of packets without a SecTag received while SecY.Validate_Frames was not STRICT. */
	MRVL_APHY_U64 inPktsCtrlPortDisable;	/*!< The number of packets received which are dropped on disabled SecY. */
	MRVL_APHY_U64 inCtrlPortOctets;			/*!< Ingress Total MSDU and MAC-DA/SA Octets that are permitted by the controlled port policies of this SecY. */
	MRVL_APHY_U64 inCtrlPortUCPkts;			/*!< Ingress Unicast packet count value for controlled ports of this SecY. */
	MRVL_APHY_U64 inCtrlPortMCPkts;			/*!< Ingress Multicast packet count value for controlled ports of this SecY. */
	MRVL_APHY_U64 inCtrlPortBCPkts;			/*!< Ingress Broadcast packet count value for controlled ports of this SecY. */
	MRVL_APHY_U64 inUnCtrlPortOctets;		/*!< Ingress Total MSDUand MAC - DA / SA Octets that are permitted by the uncontrolled port policies of this SecY. */
	MRVL_APHY_U64 inUnCtrlPortUCPkts;		/*!< Ingress Unicast packet count value for uncontrolled ports of this SecY. */
	MRVL_APHY_U64 inUnCtrlPortMCPkts;		/*!< Ingress Multicast packet count value for uncontrolled ports of this SecY. */
	MRVL_APHY_U64 inUnCtrlPortBCPkts;		/*!< Ingress Broadcast packet count value for uncontrolled ports of this SecY. */
}MRVL_Q222X_MSEC_RX_SECY_COUNTER;

/**
 * @brief Structure of SecY Tx stats
 *
 */
typedef struct {
	MRVL_APHY_U64 outPktsCtrlPortDisable;	/*!< The number of packets received on disabled SecY. */
	MRVL_APHY_U64 outPktsSecYUntagged;		/*!< The number of data packets (excluding control packets) transmitted without a SecTag because Protect Frames is false. */
	MRVL_APHY_U64 outPktsSecYNoActiveSA;	/*!< The number of data packets with SA value not matching any active SA value configured. */
	MRVL_APHY_U64 outPktSecYTooLong;		/*!< The number of transmit packets discarded because their length is greater than the configured MTU after SecTag/ICV insertion. */
	MRVL_APHY_U64 outOCTETSSecYProtected;	/*!< The number of plain text octets integrity protected but not encrypted in transmitted frames. */
	MRVL_APHY_U64 outOCTETSSecYEncrypted;	/*!< The number of plain text octets integrity protected and encrypted in transmitted frames. */
	MRVL_APHY_U64 outCtrlPortOctets;		/*!< Egress Total MSDU and MAC-DA/SA Octets that are permitted by the controlled port policies of this SecY. */
	MRVL_APHY_U64 outCtrlPortUCPkts;		/*!< Egress Unicast packet count value for controlled ports of this SecY. */
	MRVL_APHY_U64 outCtrlPortMCPkts;		/*!< Egress Multicast packet count value for controlled ports of this SecY. */
	MRVL_APHY_U64 outCtrlPortBCPkts;		/*!< Egress Broadcast packet count value for controlled ports of this SecY. */
	MRVL_APHY_U64 outUnCtrlPortOctets;		/*!< Egress Total MSDU and MAC-DA/SA Octets that are permitted by the uncontrolled port policies of this SecY. */
	MRVL_APHY_U64 outUnCtrlPortUCPkts;		/*!< Egress Unicast packet count value for uncontrolled ports of this SecY. */
	MRVL_APHY_U64 outUnCtrlPortMCPkts;		/*!< Egress Multicast packet count value for uncontrolled ports of this SecY. */
	MRVL_APHY_U64 outUnCtrlPortBCPkts;		/*!< Egress Broadcast packet count value for uncontrolled ports of this SecY. */
}MRVL_Q222X_MSEC_TX_SECY_COUNTER;

/**
 * @brief Structure of SC Rx stats
 *
 */
typedef struct {
	MRVL_APHY_U64 inPktsSCCamHit;			/*!< The number of Packets which hit an entry in the SC TCAM. Only 1 counter increments per packet. */
	MRVL_APHY_U64 inPktsSCLate;				/*!< The number of packets discarded, because the received PN was lower than the lowest acceptable PN and with replay protect true. */
	MRVL_APHY_U64 inPktsSCNotValid;			/*!< The number of packets discarded, because validation failed and SecY.Validate_Frames is 'STRICT' or the data was encrypted so the original frame could not be recovered. */
	MRVL_APHY_U64 inPktsSCInvalid;			/*!< The number of packets, that failed validation but could be received because SecY.Validate_Frames was 'CHECK' and the data was not encrypted so the original frame could be recovered. */
	MRVL_APHY_U64 inPktsSCDelayed;			/*!< The number of received packets, with PN lower than the lowest acceptable PN and replay protect is false. */
	MRVL_APHY_U64 inPktsSCUnchecked;		/*!< The number of packets received, while Validate_Frames was disabled. */
	MRVL_APHY_U64 inPktsSCOK;				/*!< The number of packets received for this SC successfully validated and within the replay window. */
}MRVL_Q222X_MSEC_RX_SC_COUNTER;

/**
 * @brief Structure of SC Tx stats
 *
 */
typedef struct {
	MRVL_APHY_U64 outPktsProtected;			/*!< The number of integrity protected but not encrypted packets for this transmit SC. */
	MRVL_APHY_U64 outPktsEncrypted;			/*!< The number of integrity protected and encrypted packets for this transmit SC. */
}MRVL_Q222X_MSEC_TX_SC_COUNTER;

/**
 * @brief Structure of Port Rx stats
 *
 */
typedef struct {
	MRVL_APHY_U64 inPktsParseErr;			/*!< The number of packets that have a parse error as indicated by PEX per port. */
	MRVL_APHY_U64 inPktsFlowIDTCAMMiss;		/*!< The number of Flow ID TCAM misses per port. */
	MRVL_APHY_U64 inPktsEarlyPreemptErr;	/*!< The number of packets with Early Preemption violations detected per port. */
	MRVL_APHY_U64 inPktsFlowIDTCAMHit0;		/*!< The number of Packets which hit an entry in the Flow-ID = 0 TCAM. Only 1 counter increments per packet. */
	MRVL_APHY_U64 inPktsFlowIDTCAMHit1;		/*!< The number of Packets which hit an entry in the Flow-ID = 1 TCAM. Only 1 counter increments per packet. */
	MRVL_APHY_U64 inPktsFlowIDTCAMHit2;		/*!< The number of Packets which hit an entry in the Flow-ID = 2 TCAM. Only 1 counter increments per packet. */
	MRVL_APHY_U64 inPktsFlowIDTCAMHit3;		/*!< The number of Packets which hit an entry in the Flow-ID = 3 TCAM. Only 1 counter increments per packet. */
}MRVL_Q222X_MSEC_RX_PORT_COUNTER;

/**
 * @brief Structure of Port Tx stats
 *
 */
typedef struct {
	MRVL_APHY_U64 outPktsParseErr;			/*!< The number of packets that have a parse error as indicated by PEX per port. */
	MRVL_APHY_U64 outPktsFlowIDTCAMMiss;	/*!< The number of Flow ID TCAM misses per port. */
	MRVL_APHY_U64 outPktsEarlyPreemptErr;	/*!< The number of packets with Early Preemption violations detected per port. */
	MRVL_APHY_U64 outPktsFlowIDTCAMHit0;	/*!< The number of Flow ID = 0 TCAM hits. */
	MRVL_APHY_U64 outPktsFlowIDTCAMHit1;	/*!< The number of Flow ID = 1 TCAM hits. */
	MRVL_APHY_U64 outPktsFlowIDTCAMHit2;	/*!< The number of Flow ID = 2 TCAM hits. */
	MRVL_APHY_U64 outPktsFlowIDTCAMHit3;	/*!< The number of Flow ID = 3 TCAM hits. */
}MRVL_Q222X_MSEC_TX_PORT_COUNTER;

/**
 * @brief Structure of Rx SA policy fields.
 * Including SAK, HASHKey, SALT and SSCI.
 * HASHKey needs to be generated per SAK and selected cipher suite.
 *
 */
typedef struct {
	MRVL_APHY_U8 sak[MRVL_Q222X_MSEC_SAK_LEN];				/*!< 256b SAK: Define the key to be used to decrypt this packet. The lower 128 bits are used for 128-bit ciphers. */
	MRVL_APHY_U8 hashKey[MRVL_Q222X_MSEC_HASHKEY_LEN];		/*!< 128b Hash Key: Key used for authentication. */
	MRVL_APHY_U8 salt[MRVL_Q222X_MSEC_SALTKEY_LEN];			/*!< 96b Salt value: Salt value used in XPN ciphers. */
	MRVL_APHY_U32 ssci;										/*!< 32b SSCI value: Short Secure Channel Identifier, used in XPN ciphers. */
}MRVL_Q222X_MSEC_RX_SA_PLCY;

/**
 * @brief Structure of Rx/ingress SAK.
 * Including Key and Salt values required to decrypt the packet. Hashkey need to be generated per key and selected cipher suite.
 *
 */
typedef struct {
	MRVL_APHY_U8 index;										/*!< SA index */
	MRVL_Q222X_MSEC_RX_SA_PLCY policy;						/*!< SA policy related fields: SAK, HASHKey, SALT, and SSCI*/
	MRVL_APHY_U64 nextPN;									/*!< 64b next_pn value: Next packet number expected. */
}MRVL_Q222X_MSEC_RX_SA;

/**
 * @brief Structure of Rx/ingress SC
 * If a packet matches on an SA which is not in use, a policy violation is triggered and the packet is either permitted or denied based on the SecY Policy table.
 *
 */
typedef struct {
	MRVL_APHY_U8 index;					/*!< SC index. */
	MRVL_APHY_U8 secYIndex;				/*!< SecY associated with this packet. */
	MRVL_APHY_U64 sci;					/*!< The Secure Channel Identifier. */
	MRVL_APHY_BOOL enable;				/*!< Set to 1 to enable the this CAM entry to be part of the CAM search/compare. */
	MRVL_APHY_U8 sa_index0;				/*!< Define the 1st SA to use */
	MRVL_APHY_U8 sa_index1;				/*!< Define the 2nd SA to use */
	MRVL_APHY_U8 sa_index2;				/*!< Define the 3rd SA to use */
	MRVL_APHY_U8 sa_index3;				/*!< Define the 4th SA to use */
	MRVL_APHY_BOOL sa_index0_in_use;	/*!< Specifies whether 1st SA is in use or not. */
	MRVL_APHY_BOOL sa_index1_in_use;	/*!< Specifies whether 2nd SA is in use or not.  */
	MRVL_APHY_BOOL sa_index2_in_use;	/*!< Specifies whether 3rd SA is in use or not. */
	MRVL_APHY_BOOL sa_index3_in_use;	/*!< Specifies whether 4th SA is in use or not.  */
}MRVL_Q222X_MSEC_RX_SC;

/**
 * @brief Structure of Rx/Ingress SecY Map
 *
 */
typedef struct {
    MRVL_APHY_U8 secYIndex;			/*!< index for entry in ingress secY policy */
	MRVL_APHY_BOOL isControlPacket;	/*!< Identifies all packets matching the associated Flow-ID lookup as control packets. */
}MRVL_Q222X_MSEC_RX_SECY_MAP;

/**
 * @brief Structure of Rx/ingress SecY.
 * The incoming packet PN must be greater than or equal to the associated next_pn (sa_pn_table_mem) minus this value or the packet must be dropped.
 *
 */
typedef struct {
	MRVL_APHY_U8 index;										/*!< Identifies the SecY for this Flow. */
	MRVL_APHY_BOOL controlled_port_enabled;					/*!< Enable (or disable) operation of the Controlled port associated with this SecY */
	MRVL_Q222X_MSEC_VALIDATEFRAME validate_frames;			/*!< see MRVL_Q222X_MSEC_VALIDATEFRAME */
	MRVL_Q222X_MSEC_STRIP_SECTAG_ICV strip_sectag_icv;		/*!< see MRVL_Q222X_MSEC_STRIP_SECTAG_ICV */
	MRVL_Q222X_MSEC_CIPHER_SUITE cipher;					/*!< Define the cipher suite to use for this SecY */
	MRVL_APHY_U8 confidential_offset;						/*!< Define the number of bytes that are unencrypted following the SecTag. */
	MRVL_APHY_BOOL icv_includes_da_sa;						/*!< When set, the outer DA/SA bytes are included in the authentication GHASH calculation */
	MRVL_APHY_BOOL replay_protect;							/*!< Enables Anti-Replay protection */
	MRVL_APHY_U32 replay_window;							/*!< Unsigned value indicating the size of the anti-replay window. */
}MRVL_Q222X_MSEC_RX_SECY;

/**
 * @brief Structure of Tx SA policy fields.
 * Including SAK, HASHKey, SALT and SSCI. Plus sectag AN
 * HASHKey needs to be generated per SAK and selected cipher suite.
 *
 */
typedef struct {
	MRVL_APHY_U8 sak[MRVL_Q222X_MSEC_SAK_LEN];				/*!< 256b SAK: Define the encryption key to be used to encrypte this packet. The lower 128 bits are used for 128-bit ciphers. */
	MRVL_APHY_U8 hashKey[MRVL_Q222X_MSEC_HASHKEY_LEN];		/*!< 128b Hash Key: Key used for authentication. */
	MRVL_APHY_U8 salt[MRVL_Q222X_MSEC_SALTKEY_LEN];			/*!< 96b Salt value: Salt value used in XPN ciphers. */
	MRVL_APHY_U32 ssci;										/*!< 32b SSCI value: Short Secure Channel Identifier, used in XPN ciphers. */
	MRVL_APHY_U8 AN;										/*!< 2b SecTag Association Number (AN) */
}MRVL_Q222X_MSEC_TX_SA_PLCY;

/**
 * @brief Structure of Tx SAK.
 * Including Key and Salt values required to encrypte the packet. Hashkey need to be generated per key and selected cipher suite.
 *
 */
typedef struct {
	MRVL_APHY_U8 index;										/*!< SA index */
	MRVL_Q222X_MSEC_TX_SA_PLCY policy;						/*!< SA policy related fields: SAK, HASHKey, SALT, SSCI and sectag AN */
	MRVL_APHY_U64 nextPN;									/*!< 64b next_pn value: Next packet number to insert into outgoing packet on a particular SA. */
}MRVL_Q222X_MSEC_TX_SA;

/**
 * @brief Structure of Tx SC
 *
 */
typedef struct {
	MRVL_APHY_U8 index;					/*!< SA index */
	MRVL_APHY_U8 sa_index0;				/*!< First SA index  */
	MRVL_APHY_U8 sa_index1;				/*!< Second SA index */
	MRVL_APHY_BOOL sa_index0_vld;		/*!< When set, indicates that the corresponding SC's SA index0 is valid. */
	MRVL_APHY_BOOL sa_index1_vld;		/*!< When set, indicates that the corresponding SC's SA index1 is valid. */
	MRVL_APHY_BOOL enable_auto_rekey;	/*!< If enabled, then once the pn_threshold is reached, auto rekey will happen. */
	MRVL_APHY_BOOL isActiveSA1;			/*!< If set, then sa_index1 is the currently active SA index. If cleared, the sa_index0 is the currently active SA index). */
}MRVL_Q222X_MSEC_TX_SC;

/**
 * @brief Structure of Tx/Egress SecY Map
 *
 */
typedef struct {
	MRVL_APHY_U64 sectag_sci;		/*!< Identifies the SecTAG SCI for this Flow. */
    MRVL_APHY_U8 secYIndex;			/*!< index for entry in Egress secY Policy */
	MRVL_APHY_BOOL isControlPacket;	/*!< Identifies all packets matching this index lookup as control packets. */
	MRVL_APHY_U8 scIndex;			/*!< Identifies the SC for this Flow. */
	MRVL_APHY_BOOL auxiliary_plcy;	/*!< Auxiliary policy bits. */
}MRVL_Q222X_MSEC_TX_SECY_MAP;

/**
 * @brief Structure of Tx SecY
 *
 */
typedef struct {
	MRVL_APHY_U8 index;						/*!< SecY index */
	MRVL_APHY_BOOL controlled_port_enabled;	/*!< Enable (or disable) operation of the Controlled port associated with this SecY. */
	MRVL_APHY_BOOL protect_frames;			/*!< 0 = do not encrypt or authenticate this packet; 1 = always Authenticate frame and if SecTag.TCI.E = 1 encrypt the packet as well. */
	MRVL_Q222X_MSEC_CIPHER_SUITE cipher;	/*!< Define the cipher suite to use for this SecY */
	MRVL_APHY_U8 confidential_offset;		/*!< Define the number of bytes that are unencrypted following the SecTag. */
	MRVL_APHY_BOOL icv_includes_da_sa;		/*!< When set, the outer DA/SA bytes are included in the authentication GHASH calculation */
	MRVL_APHY_U8 sectag_offset;				/*!< Define the offset in bytes from either the start of the packet or a matching Etype depending on SecTag_Insertion_Mode. */
	MRVL_APHY_U8 sectag_tci;				/*!< Tag Control Information excluding the AN field which originates from the SA Policy table */
	MRVL_APHY_U16 mtu;						/*!< Specifies the outgoing MTU for this SecY */

}MRVL_Q222X_MSEC_TX_SECY;

/**
 * @brief Structure of Vlan tag
 *
 */
typedef struct {
	MRVL_APHY_U16 VID;		/*!< 12 bits */
	MRVL_APHY_U8 PRI_CFI;	/*!< PRI - 3 bits, CFI - 1bit */
}MRVL_Q222X_MSEC_VLANTAG;

/**
 * @brief Structure of MPLS
 *
 */
typedef struct {
	MRVL_APHY_U32 MPLS_label;	/*!< 20 bits */
	MRVL_APHY_U8 exp;			/*!< 3 bits */
}MRVL_Q222X_MSEC_MPLS_OUTER;

/**
 * @brief Define Packet Type (vlan or MPLS)
 *
 */
typedef union
{
	MRVL_Q222X_MSEC_VLANTAG vlanTag;
	MRVL_Q222X_MSEC_MPLS_OUTER mpls;
} MRVL_Q222X_MSEC_PACKETTYPE_OUTER;

/**
 * @brief Structure of MACsec Rule.
 *
 */
typedef struct {
	MRVL_APHY_U8 index;
	MRVL_APHY_U8 key_MAC_DA[MRVL_Q222X_MAC_ADDR_LEN];	/*!< MAC DA field extracted from the packet */
	MRVL_APHY_U8 mask_MAC_DA[MRVL_Q222X_MAC_ADDR_LEN];	/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_U8 key_MAC_SA[MRVL_Q222X_MAC_ADDR_LEN];	/*!< MAC SA field extracted from the packet */
	MRVL_APHY_U8 mask_MAC_SA[MRVL_Q222X_MAC_ADDR_LEN];	/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_U16 key_Ethertype;						/*!< First E-Type found in the packet that doesn't match one of the preconfigured custom tag. */
	MRVL_APHY_U16 mask_Ethertype;						/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_Q222X_MSEC_PACKETTYPE_OUTER key_outer1;		/*!< outermost/1st VLAN ID {8'd0, VLAN_ID[11:0]}, or 20-bit MPLS label. */
	MRVL_Q222X_MSEC_PACKETTYPE_OUTER mask_outer1;		/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_Q222X_MSEC_PACKETTYPE_OUTER key_outer2;		/*!< 2nd outermost VLAN ID {8'd0, VLAN_ID[11:0]}, or 20-bit MPLS label. */
	MRVL_Q222X_MSEC_PACKETTYPE_OUTER mask_outer2;		/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_U16 key_bonus_data;						/*!< 2 bytes of additional bonus data extracted from one of the custom tags. */
	MRVL_APHY_U16 mask_bonus_data;						/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_U8 key_tag_match_bitmap;					/*!< 8 bits total. Maps 1 to 1 bitwise with the set of custom tags. (set bit[N]=1 if check Nth custom tag) */
	MRVL_APHY_U8 mask_tag_match_bitmap;					/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_Q222X_MSEC_PACKET_TYPE key_packet_type;		/*!< Encoded Packet Type, see MRVL_Q222X_MSEC_PACKET_TYPE */
	MRVL_APHY_U8 mask_packet_type;						/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_U16 key_inner_vlan_type;					/*!< 3 bits total. Encoded value indicating which VLAN TPID value matched for the second outermost VLAN Tag. */
	MRVL_APHY_U16 mask_inner_vlan_type;					/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_U16 key_outer_vlan_type;					/*!< 3 bits total. Encoded value indicating which VLAN TPID value matched for the outermost VLAN Tag. */
	MRVL_APHY_U16 mask_outer_vlan_type;					/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_U8 key_num_tags;							/*!< 7 bits total. Number of VLAN/custom tags or MPLS lables detected. Ingress: before SecTag; Egress: total detected. Exclude MCS header tags. i.e. Bit 2: 2 tags/labels before SecTAG...Bit 6: 6 or more tags/labels before SecTAG. */
	MRVL_APHY_U8 mask_num_tags;							/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_U8 key_express;							/*!< 1 bits. Express packet. */
	MRVL_APHY_U8 mask_express;							/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_BOOL isMPLS;
	MRVL_APHY_BOOL isEnable;							/*!< Set to 1 to enable the corresponding TCAM entry to be part of the TCAM search/compare. */
}MRVL_Q222X_MSEC_RULE;

/**
 * @brief Structure of MACsec custom tag
 *
 */
typedef struct {
	MRVL_APHY_U8 index;				/*!< custom tag index (0-7). but only max 6 vlan/custom are enabled the same time.  */
	MRVL_APHY_BOOL hasBonusData;	/*!< TRUE: extract the two bytes immediately following the tag. FALSE: extract after the first non-matching etype as bonus data. */
	MRVL_APHY_BOOL isVLANTag;		/*!< custom tag is VLAN tag */
	MRVL_APHY_U8 size;				/*!< size of custom tag, including tag lable (valid size: 2,4,6,8,10,12,14,16. If 16, set this value to 0) */
	MRVL_APHY_U16 ethType;			/*!< custom tag's e-type value */
	MRVL_APHY_BOOL isEnabled;		/*!< TRUE: enable custom tag. FLASE: disable custom tag. */
}MRVL_Q222X_MSEC_CUSTOM_TAG;

/**
 * @brief Structure of e-type to classify control packet
 *
 */
typedef struct {
	MRVL_APHY_U8 index;			/*!< etype index (0-7). */
	MRVL_APHY_U16 ethType;		/*!< etype value for control packet matching */
	MRVL_APHY_BOOL isEnabled;	/*!< TRUE: enable control packet classification against this e-type. FLASE: disable classification. */
}MRVL_Q222X_MSEC_CTRL_PCKT_ETYPE;

/**
 * @brief Structure of DA to classify control packet
 *
 */
typedef struct {
	MRVL_APHY_U8 index;							/*!< DA index (0-7). */
	MRVL_APHY_U8 DA[MRVL_Q222X_MAC_ADDR_LEN];	/*!< DA value for control packet matching (6 bytes) */
	MRVL_APHY_BOOL isEnabled;					/*!< TRUE: enable control packet classification against this DA. FLASE: disable classification. */
}MRVL_Q222X_MSEC_CTRL_PCKT_DA;

/**
 * @brief Structure of DA MRVL_Q222X_MSEC_RANGE to classify control packet
 *
 */
typedef struct {
	MRVL_APHY_U8 index;								/*!< DA MRVL_Q222X_MSEC_RANGE index (0-3). */
	MRVL_APHY_U8 MAX_DA[MRVL_Q222X_MAC_ADDR_LEN];	/*!< maximun DA address for control packet matching */
	MRVL_APHY_U8 MIN_DA[MRVL_Q222X_MAC_ADDR_LEN];	/*!< minimun DA address for control packet matching */
	MRVL_APHY_BOOL isEnabled;						/*!< TRUE: enable control packet classification against this DA MRVL_Q222X_MSEC_RANGE. FLASE: disable classification. */
}MRVL_Q222X_MSEC_CTRL_PCKT_DA_RANGE;

/**
 * @brief Structure of combo settings to classify control packet
 *
 */
typedef struct {
	MRVL_APHY_U8 index;								/*!< combo index (0-3). */
	MRVL_APHY_U16 ethType;							/*!< etype value for control packet matching */
	MRVL_APHY_U8 MAX_DA[MRVL_Q222X_MAC_ADDR_LEN];	/*!< maximun DA address for control packet matching */
	MRVL_APHY_U8 MIN_DA[MRVL_Q222X_MAC_ADDR_LEN];	/*!< minimun DA address for control packet matching */
	MRVL_APHY_BOOL isEnabled;						/*!< TRUE: enable control packet classification against this combo. FLASE: disable classification. */
}MRVL_Q222X_MSEC_CTRL_PCKT_COMBO;


#endif
