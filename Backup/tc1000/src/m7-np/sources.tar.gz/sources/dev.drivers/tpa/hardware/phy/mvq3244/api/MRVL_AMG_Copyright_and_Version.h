/**
 * @file MRVL_AMG_Copyright_and_Version.h
 * @brief Marvell Multi-gig Automotive Ethernet PHY API Copyright, License and Version Identifier File
 *
 * @copyright
 * Copyright (c) 2023 Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement by and between
 * Marvell and you, your employer or other entity on behalf of whom you act.
 * In the absence of such license agreement the following file is subject to
 * Marvell’s standard Limited Use License Agreement.
 *
 */

#ifndef MRVL_AMG_COPYRIGHT_VERSION_H
#define MRVL_AMG_COPYRIGHT_VERSION_H

#define MARVL_AMG_API_VERSION "1.6.0"
#define MARVL_AMG_API_DATE "09/22/2023"

#endif
