/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          fp_hif_reg.h
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    contains core data structures & defines of hif driver
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

#ifndef _FP_HIF_REG_H
#define _FP_HIF_REG_H

#ifdef __linux__
#include <linux/sched.h>
#endif

#include "fp_macros.h"
#include "fp_net_driver.h"
#include "fp_global_addr_map.h"

#define FP_ASSIGNED_HIF 0

#define HIF_CH_INT           (1 << 0)
#define HIF_CH_RXBD_INT      (1 << 1)
#define HIF_CH_RXPKT_INT     (1 << 2)
#define HIF_CH_TXBD_INT      (1 << 3)
#define HIF_CH_TXPKT_INT     (1 << 4)
#define HIF_CH_INT_EN        (1 << 0)
#define HIF_CH_RXBD_INT_EN   (1 << 1)
#define HIF_CH_RXPKT_INT_EN  (1 << 2)
#define HIF_CH_TXBD_INT_EN   (1 << 3)
#define HIF_CH_TXPKT_INT_EN  (1 << 4)

#define HIF_CH_TX_CTRL_DMA_EN     (1 << 0)
#define HIF_CH_TX_BDP_POLL_CNTR_EN (1 << 1)
#define HIF_CH_RX_CTRL_DMA_EN     (1 << 16)
#define HIF_CH_RX_BDP_POLL_CNTR_EN (1 << 17)

#define HIF_CH_TX_START      (1 << 0)
#define HIF_CH_RX_START      (1 << 0)

#define HIF_QUEUE_MAP_VALID_MASK   3
#define NPU_MAX_TX_QUEUES     4

#define CHANNEL_REG_RESERVED_GAP 0xf00/4
#define HIF_REGS_RESERVED_GAP 0xf00/4

typedef struct channel_reg
{
	volatile uint32a hif_ctrl_ch;
	volatile uint32a hif_rx_bdp_wr_low_addr_ch;
	volatile uint32a hif_rx_bdp_wr_high_addr_ch;
	volatile uint32a hif_rx_bdp_rd_low_addr_ch;

	volatile uint32a hif_rx_bdp_rd_high_addr_ch;
	volatile uint32a hif_tx_bdp_wr_low_addr_ch;
	volatile uint32a hif_tx_bdp_wr_high_addr_ch;
	volatile uint32a hif_tx_bdp_rd_low_addr_ch;

	volatile uint32a hif_tx_bdp_rd_high_addr_ch;
	volatile uint32a hif_rx_wrbk_bd_ch_buffer_size;
	volatile uint32a hif_rx_ch_start;
	volatile uint32a hif_tx_wrbk_bd_ch_buffer_size;

	volatile uint32a hif_tx_ch_start;
	volatile uint32a hif_doorbell_addr_lsb_ch;
	volatile uint32a hif_doorbell_addr_msb_ch;
	volatile uint32a hif_rx_packet_drop_cnt_ch;

	volatile uint32a reserved1[8];

	volatile uint32a hif_ch_int_src;
	volatile uint32a hif_ch_int_en;
	volatile uint32a reserved2[6];

	volatile uint32a hif_tx_rd_curr_bd_low_addr_ch;
	volatile uint32a hif_tx_rd_curr_bd_high_addr_ch;
	volatile uint32a hif_tx_wr_curr_bd_low_addr_ch;
	volatile uint32a hif_tx_wr_curr_bd_high_addr_ch;

	volatile uint32a hif_bdp_ch_tx_fifo_cnt;
	volatile uint32a hif_tx_dma_status_0_ch;
	volatile uint32a hif_tx_status_0_ch;
	volatile uint32a hif_tx_status_1_ch;

	volatile uint32a hif_tx_pkt_cnt0_ch;
	volatile uint32a hif_tx_pkt_cnt1_ch;
	volatile uint32a hif_tx_pkt_cnt2_ch;
	volatile uint32a reserved3[5];

	volatile uint32a hif_rx_rd_curr_bd_low_addr_ch;
	volatile uint32a hif_rx_rd_curr_bd_high_addr_ch;
	volatile uint32a hif_rx_wr_curr_bd_low_addr_ch;
	volatile uint32a hif_rx_wr_curr_bd_high_addr_ch;

	volatile uint32a hif_bdp_ch_rx_fifo_cnt;
	volatile uint32a hif_rx_dma_status_0_ch;
	volatile uint32a hif_rx_status_0_ch;
	volatile uint32a hif_rx_pkt_cnt0_ch0;

	volatile uint32a hif_rx_pkt_cnt1_ch0;
	volatile uint32a hif_ltc_max_pkt_ch;
	volatile uint32a hif_abs_int_timer_ch;
	volatile uint32a hif_abs_frame_count_ch;

	volatile uint32a hif_int_coal_en_ch;
	volatile uint32a reserved4[3];
	volatile uint32a reserved5[CHANNEL_REG_RESERVED_GAP];

} channel_reg_t;

#define HIF_REGS_RESERVED2_GAP 0xf00/4

struct hif_regs
{
	volatile uint32a hif_version;
	volatile uint32a hif_tx_poll_ctrl;
	volatile uint32a hif_rx_poll_ctrl;
	volatile uint32a hif_misc;

	volatile uint32a hif_timeout_reg;
	volatile uint32a hif_soft_reset;
	volatile uint32a hif_doorbell_enable_reg1;
	volatile uint32a hif_doorbell_enable_reg2;

	volatile uint32a hif_single_bit_ecc_err0_en;
	volatile uint32a hif_single_bit_ecc_err0_status;
	volatile uint32a hif_multi_bit_ecc_err0_en;
	volatile uint32a hif_multi_bit_ecc_err0_status;

	volatile uint32a hif_multi_or_addr_bit_ecc_err0_en;
	volatile uint32a hif_multi_or_addr_bit_ecc_err0_status;
	volatile uint32a hif_addr_bit_ecc_err0_en;
	volatile uint32a hif_addr_bit_ecc_err0_status;

	volatile uint32a hif_int_src;
	volatile uint32a hif_int_src_reg2;
	volatile uint32a hif_int_src_reg3;
	volatile uint32a hif_wdt_int_reg1;

	volatile uint32a hif_wdt_int_reg2;
	volatile uint32a hif_rsvd_1;
	volatile uint32a hif_rsvd_2;
	volatile uint32a hif_rx_pkt_drop_en;

	volatile uint32a hif_rx_packet_drop_cnt;
	volatile uint32a hif_rx_packet_drop_threshold;
	volatile uint32a hif_err_int_src;
	volatile uint32a hif_err_int_en;

	volatile uint32a hif_tx_fifo_err_int_src;
	volatile uint32a hif_tx_fifo_err_int_en;
	volatile uint32a hif_rx_fifo_err_int_src;
	volatile uint32a hif_rx_fifo_err_int_en;

	volatile uint32a hif_tx_state;
	volatile uint32a hif_tx_actv;
	volatile uint32a hif_tx_curr_ch_no;
	volatile uint32a hif_dxr_tx_fifo_cnt;

	volatile uint32a hif_tx_ctrl_word_fifo_cnt1;
	volatile uint32a hif_tx_ctrl_word_fifo_cnt2;
	volatile uint32a hif_tx_bvalid_fifo_cnt;
	volatile uint32a hif_tx_pkt_cnt1;

	volatile uint32a hif_tx_pkt_cnt2;
	volatile uint32a hif_rx_state;
	volatile uint32a hif_rx_actv;
	volatile uint32a hif_rx_curr_ch_no;

	volatile uint32a hif_dxr_rx_fifo_cnt;
	volatile uint32a hif_rx_ctrl_word_fifo_cnt;
	volatile uint32a hif_rx_bvalid_fifo_cnt;
	volatile uint32a hif_rx_pkt_cnt1;

	volatile uint32a hif_rx_pkt_cnt2;
	volatile uint32a hif_dma_base_addr;
	volatile uint32a hif_dma_burst_size_addr;
	volatile uint32a hif_rx_queue_map_ch_no_addr;

	volatile uint32a hif_ltc_pkt_ctrl;
	volatile uint32a hif_rx_queue_map_ch_no_reg2_addr;
	volatile uint32a hif_rx_queue_map_ch_no_reg3_addr;
	volatile uint32a hif_rx_queue_map_ch_no_reg4_addr;

	volatile uint32a hif_single_bit_ecc_err1_en;
	volatile uint32a hif_single_bit_ecc_err1_status;
	volatile uint32a hif_multi_bit_ecc_err1_en;
	volatile uint32a hif_multi_bit_ecc_err1_status;

	volatile uint32a hif_multi_or_addr_bit_ecc_err1_en;
	volatile uint32a hif_multi_or_addr_bit_ecc_err1_status;
	volatile uint32a hif_addr_bit_ecc_err1_en;
	volatile uint32a hif_addr_bit_ecc_err1_status;
	volatile uint32a reserved2[HIF_REGS_RESERVED2_GAP];
	volatile channel_reg_t ch[NUM_HIF_CHANNELS];
};

void fp_assign_hif_base_addr(struct fp_private *fp);
void fp_en_hif_rxdma_engine(struct fp_private *fp);
void fp_disable_hif_dma_engine(struct fp_private *fp);
void fp_disable_hif_tx_dma_engine(struct fp_private *fp);
void fp_disable_hif_rx_dma_engine(struct fp_private *fp);
void fp_init_bdp_base_reg(struct fp_private *fp);

#endif
