// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
 * @File
 * @Title        fp_router_table.c
 * @Copyright    Copyright (c) Imagination Technologies Ltd. All Rights Reserved
 * @Description  maintains fast path route tables, add/delete
 *                      route tables in PE, route tables intialzation,
 *                      pool management for route entries, route lookup.
 * @License      Dual MIT/GPLv2
 *
 * The contents of this file are subject to the MIT license as set out below.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * the GNU General Public License Version 2 ("GPL") in which case the provisions
 * of GPL are applicable instead of those above.
 *
 * If you wish to allow use of your version of this file only under the terms of
 * GPL, and not to allow others to use your version of this file under the terms
 * of the MIT license, indicate your decision by deleting the provisions above
 * and replace them with the notice and other provisions required by GPL as set
 * out in the file called "GPL-COPYING" included in this distribution. If you do
 * not delete the provisions above,a recipient may use your version of this file
 * under the terms of either the MIT license or GPL.
 *
 * This License is also included in this distribution in the file called
 * "MIT-COPYING".
 *
 * EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 * PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */ /**************************************************************************/

/**********************************************************************
 *                                     Include Files
 **********************************************************************/
#include "fp_library.h"
#include "fp_macros.h"
#include "fp_router.h"
#include "fp_poolalloc.h"

/**********************************************************************
 *                              Global Declarations                   *
 **********************************************************************/
POOLHEAD_PTR gRtFlowPoolHead;

struct fp_router_tables router_tables;

#if 0
static inline int32a delete_hash_table_entry(uint16 in_usHashValue,
			struct cacheFlow *in_Entry,
			struct fp_router_table *my_hash_table);

/**********************************************************************
 * Function Name  : delete_hash_table_entry
 * Description    : delete entry from PE ddr table by using given hash index
 * Inputs
 *   Parameters   : u16, struct cacheFlow *, struct fp_router_table *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : int
 * Changes        :
 ********************************************************************/
static inline int32a delete_hash_table_entry(uint16 in_usHashValue,
					struct cacheFlow *in_Entry,
					struct fp_router_table *my_hash_table)
{
	struct cacheFlow *list = NULL, *temp = NULL;
	/* Get the first route entry from the hash table, convert the
	 * entry address into pci address, entries are located at PE
	 * ddr memory, so when ever try to access PE memory need to
	 * convert address into PCI address space, by default all
	 * entry pointer will be stored in PE address format
	 */
#ifdef HASH_ARR_EN
	list = (struct cacheFlow *)&grtHashArr[in_usHashValue];
	/*List null check*/
	if (list == NULL)
		return -1;
#ifdef ROUTE_LMEM_EN
	/*Condition check for valid and head match*/
	if ((((list->vflag) & ROUTE_ENTRY_VALID) == 1)
					&& (list == in_Entry)) {
		list->vflag  = 0;
		temp = (struct cacheFlow *) ROUTE_PEL_TO_PCI((uint32)
					((uint32)list->next));
#else
	/*Condition check for valid and head match*/
	if (((ntohl(list->vflag) & ROUTE_ENTRY_VALID) == 1)
					&& (list == in_Entry)) {

		list->vflag  = 0;
		temp = (struct cacheFlow *) PE_TO_PCI((uint32)
					ntohl((uint32)list->next));
#endif
		/*Next pointer null cHeck*/
		if (temp != NULL) {
			int32a i = 0;
			struct nf_conn *ct = NULL;
			my_hash_table->num_entries--;
			memcpy(list, temp, sizeof(struct cacheFlow));
			for (i = 0 ; i < 2; i++) {
				ct = (struct nf_conn *)((uint32)(list->ct.addr));

				printk("ct is %p \n", ct);
				/*Update ct info to singlelevel route pointer*/
				if (ct != NULL) {
					struct fpEntryInfo *flow;
					flow = &ct->ct_general.fpCt2CacheFlow;
					if (temp ==
					((struct cacheFlow *)flow->rtEntry[i]))
						flow->rtEntry[i] =
					(struct cacheFlow *)(uint32)
						&grtHashArr[in_usHashValue];
				}
			}
			memset(temp, 0, sizeof(struct cacheFlow));
			/*Pool free error check*/
			if (poolFree((int8 *)temp, gRtFlowPoolHead) != 0)
				pr_err("PoolFree Error\n");
		} else {
			memset(list, 0, sizeof(struct cacheFlow));
			my_hash_table->num_entries--;
		}
		return 0;
	}
#else
	/*Getting list from hash table*/
	list = (struct cacheFlow *)
		PE_TO_PCI((uint32)my_hash_table->table[in_usHashValue]);
	/*List null check */
	if (list == NULL)
		return -1;
	/* check if entry is at first hash location, delete the entry from
	 * the table, link the hash table with next entry of removed entry
	 */
	if (list == in_Entry) {
		my_hash_table->table[in_usHashValue] = (list->next);
		my_hash_table->num_entries--;
		/*PoolFree error check*/
		if (poolFree((int8 *)list, gRtFlowPoolHead) != 0)
			pr_err("HpoolFree Error\n");
		return 0;
	}
#endif   /*End of HASH_ARR_EN*/
	/* if entry not located at first location loop the hash table
	 * until entry next is null, if entry found delete the from
	 * ddr hash table
	 */
	if (list->next == 0) {
		pr_info("list next null\n");
		return 0;
	}
#ifdef ROUTE_LMEM_EN
	/*While loop for next pointer match*/
	while (((struct cacheFlow *)
			((uint32)list->next)) != NULL) {
		/* convert the entry pointer PE to PCI format */
		temp = (struct cacheFlow *)
			ROUTE_PEL_TO_PCI(((uint32)list->next));
#else
	/*While loop for next pointer match*/
	while ((struct cacheFlow *) ((uint32)htonl(
			(uint32)list->next)) != NULL) {
		/* convert the entry pointer PE to PCI format */
		temp = (struct cacheFlow *)
			PE_TO_PCI((uint32)htonl((uint32)
								list->next));
#endif
		if (temp == in_Entry) {
			/* chain the next entry pointer to next location */
			list->next = temp->next;
			my_hash_table->num_entries--;
			/*Conditon check for poolFree of route entry*/
			if (poolFree((int8 *)temp, gRtFlowPoolHead) == 0)
				pr_err("poolFree Error\n");
			break;
		} else {
			struct cacheFlow *prev;
			/* traverse the linked list to next entry */
			prev = list;
#ifdef ROUTE_LMEM_EN
			list = (struct cacheFlow *)
				ROUTE_PEL_TO_PCI((uint32)list->next);
			if (list == NULL)
				break;
			if (((struct cacheFlow *)((uint32)list->next)) == NULL) {
#else
			list = (struct cacheFlow *)
				PE_TO_PCI((uint32)
					htonl((uint32)list->next));
			if (list == NULL)
				break;
			if (((struct cacheFlow *)((uint32)ntohl(
				(uint32)list->next))) == NULL) {
#endif
				if (list == in_Entry) {
					prev->next = 0;
					my_hash_table->num_entries--;
					if (poolFree((int8 *)list,
						gRtFlowPoolHead) != 0) {
						pr_err("poolFree Error\n");
					}
				}
				break;
			}
		}
	}
	return 0;
}
#endif

/**********************************************************************
 * Function Name  : fp_create_router_table
 * Description    : allocate memory for hash tables and route entries, we have
 *                  pool buffer manager, based on pool allocation memory is
 *                  allocated for route entries on the fly, allocate memory for
 *                  entries and hash tables from external DDR in PE
 * Inputs
 *   Parameters   : struct fp_router_tables *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 ********************************************************************/
struct fp_router_table *fp_create_router_table(int32a tbl_size)
{
	struct fp_router_table *new_table = NULL;

	/* validate minimu hash table size */
	if (tbl_size < 1)
		return NULL;

	/* attempt to allocate memory for the table structure */
	//new_table = (struct fp_router_table *)kmalloc(sizeof(struct fp_router_table), GFP_ATOMIC);
	SAL_MemAlloc((struct fp_router_table *)new_table, sizeof(struct fp_router_table));

	/*Table null hceck*/
	if (new_table == NULL)
		return NULL;

#ifndef HASH_ARR_EN
	/* allocate memory for hash tables */
//	new_table->table = (struct cacheFlow **)fp_pci_malloc((tbl_size << 2), RT_HASH_TABLE);
	SAL_MemAlloc((struct cacheFlow **)new_table->table, tbl_size << 2);

	/* return if table memory null */
	if (new_table->table == NULL)
		return NULL;
#endif

	new_table->tbl_size = tbl_size;
	new_table->num_entries = 0;
	new_table->refcnt = 0;
	/* allocate and initialize memory for route entries
	 * route entries allocation and deallocation completely handled by
	 * pool manager
	 */

//	gRtFlowPoolHead = poolInit(MAX_RTFLOW_ENTRIES, sizeof(struct cacheFlow), 4, RT_ENTRIES_TABLE);

	return new_table;
}

/********************************************************************
 * Function Name  : fp_display_router_table_elements
 * Description    : display route entries in route table
 * Inputs
 *   Parameters   : int, struct fp_router_table *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 ********************************************************************/
void fp_display_router_table_elements(int32a in_iTable_Size,
					struct fp_router_table *in_hashTable)
{
	struct cacheFlow *list = NULL;
	int32a iIndex = 0, iIndex1 = 0;
	/* Display hash table contents */
	FPATH_TRACE(FP_TRACE_ROUTING, FP_LOG_DEBUG,
		("\n\t\t**** ROUTER HASHTABLE****\n"));
	for (iIndex = 0; iIndex < in_iTable_Size; iIndex++) {
		FPATH_TRACE(FP_TRACE_ROUTING, FP_LOG_DEBUG,
			("\n\tHashTable Index[%d]:\n", iIndex));
		for (iIndex1 = 0, list = in_hashTable->table[iIndex];
			list != NULL; list = (struct cacheFlow *)
			((uint32)list->next), iIndex1++) {
			FPATH_TRACE(FP_TRACE_ROUTING, FP_LOG_DEBUG,
				("\tindex = %d\n", iIndex1));
			FPATH_TRACE(FP_TRACE_ROUTING, FP_LOG_DEBUG,
				("\tsrc ip:port 0x%x:%d", list->u.v4.srcIP,
					list->srcPort));
			FPATH_TRACE(FP_TRACE_ROUTING, FP_LOG_DEBUG,
				("\tdst ip:port 0x%x:%d", list->u.v4.dstIP,
					list->dstPort));
		}
	}
}

/********************************************************************
 * Function Name  : fp_count_router_table_entries
 * Description    : return the number of elements in hashtable
 * Inputs
 *   Parameters   : struct fp_router_table *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : Return number of elements in hashtable
 * Changes        :
 ********************************************************************/
int32a fp_count_router_table_entries(struct fp_router_table *in_hashTable)
{
	return in_hashTable->num_entries;

}

#if 0
/********************************************************************
 * Function Name  : fp_delete_router_table_entry
 * Description    : helper routine to delete route entry from hash table
 * Inputs
 *   Parameters   : u16, cacnheFlow_t *, struct fp_router_table *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : int
 * Changes        :
 ********************************************************************/
int32a fp_delete_router_table_entry(uint16 in_usHashValue,
				struct cacheFlow *in_Entry,
				struct fp_router_table *in_hashTable)
{
	return delete_hash_table_entry(in_usHashValue, in_Entry, in_hashTable);
}
#endif

/********************************************************************
 * Function Name  : fp_delete_router_table
 * Description    : free allocated router hashtable memory
 * Inputs
 *   Parameters   : struct fp_router_table *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 ********************************************************************/
void fp_delete_router_table(struct fp_router_table *router_table)
{
#if 0
	poolDelete(gRtFlowPoolHead, RT_ENTRIES_TABLE);
	/* Free hash array */
	if (router_table && router_table->table) {
		fp_pci_free((int8 *)router_table->table, RT_HASH_TABLE);
#ifdef HASH_ARR_EN
		memset(&grtHashArr[0], 0,
			sizeof(struct cacheFlow) * ROUTE_HASH_SIZE);
#endif /*End of HASH_ARR_EN*/
		kfree(router_table);
	}
#endif
}
/**************** End of File *********************************/
