// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
 * @File
 * @Title        fp_poolalloc.c
 * @Copyright    Copyright (c) Imagination Technologies Ltd. All Rights Reserved
 * @Description  bufferpool initialization and management (allocation/free)
 * @License      Dual MIT/GPLv2
 *
 * The contents of this file are subject to the MIT license as set out below.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * the GNU General Public License Version 2 ("GPL") in which case the provisions
 * of GPL are applicable instead of those above.
 *
 * If you wish to allow use of your version of this file only under the terms of
 * GPL, and not to allow others to use your version of this file under the terms
 * of the MIT license, indicate your decision by deleting the provisions above
 * and replace them with the notice and other provisions required by GPL as set
 * out in the file called "GPL-COPYING" included in this distribution. If you do
 * not delete the provisions above,a recipient may use your version of this file
 * under the terms of either the MIT license or GPL.
 *
 * This License is also included in this distribution in the file called
 * "MIT-COPYING".
 *
 * EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 * PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");
/**********************************************************************
 *                                     Include Files
 **********************************************************************/
#include "fp_library.h"
#include "fp_macros.h"
#include "fp_poolalloc.h"
#include "linux/slab.h"
#include "linux/gfp.h"
#include "fp_pci_pe.h"

/**********************************************************************
 *                                      #defines                      *
 **********************************************************************/
#define MAGIC_NUM       0xdeadc0de
uint32 temp_lvalue = 0;

/*******************************************************************************
 * Function name:       poolInit
 * Input Parameters:    Num, Size, Align
 * Output Parameters:   None
 * Result:              Pointer to PoolHead data structure
 * Description:
 *                      This function allocates a big chunk of memory. The
 *                      initial part is allocated for the PoolHead structre and
 *                      rest of the part is used for the linked list of the
 *                      buffers of size "Size" each. The starting location for
 *                      the buffer linked list is aligned at the "Align" byte
 *                      boundary. The Magic number is stored in the first 4
 *                      bytes of each buffer to detect the multiple free
 *                      operations on the same buffer. The value of "Align"
 *                      parameter should be multiple of 4.
 ******************************************************************************/

int8 *pool_ptr = 0;
void word_copy(uint32a *a, uint32a *b, int32a size)
{
	int32a i;
	int32a count = size/4;
	for(i=0; i<count; i++)
		*(a+i) = *(b+i);
}

POOLHEAD_PTR poolInit(uint32a Num, uint32a Size, int32a Align, uint32a type)
{
	int32a iCount = 0;
	uint32a iSize = 0;
	POOLHEAD_PTR pHead = NULL;
	int8 *Ptr = NULL;

	POOLITEM_PTR Last = NULL;
	POOLITEM_PTR Tmp = NULL;
#if 1
	pHead = kmalloc(4096, GFP_KERNEL);
	iSize = Size * Num;
	Ptr = fp_pci_malloc(iSize, type);
	pool_ptr = Ptr;
	return pHead;
#endif

	/* allocate the pool head */
	pHead = kmalloc(sizeof(struct PoolHead), GFP_KERNEL);
	if (pHead == NULL) {
		FPATH_TRACE(FP_TRACE_INIT, FP_LOG_DEBUG,
			("%s: couldn't allocate pool head\n", __func__));
		return NULL;
	}

	iSize = Size * Num;

	Ptr = fp_pci_malloc(iSize, type);
pool_ptr = Ptr;

	FPATH_TRACE(FP_TRACE_INIT, FP_LOG_DEBUG,
		("%s: pool buffer ptr = %p\n", __func__, Ptr));

	if (Ptr == NULL) {
		FPATH_TRACE(FP_TRACE_INIT, FP_LOG_DEBUG,
			("%s: error allocating pool buffer", __func__));
		return NULL;
	}
	/* pool head buffer */
	pHead->Front = Ptr;
	pHead->Start = Ptr;
	iCount = 0;
	/* prepare a linked list of elements of size "Size". */
	for (Tmp = (POOLITEM_PTR)Ptr; iCount < Num; iCount++) {
		Last = Tmp;
		if (Tmp == NULL) {
			FPATH_TRACE(FP_TRACE_INIT, FP_LOG_ERR,
					("%s: PANIC", __func__));
			break;
		}
		/* To avoid route fetch pe crash -added res field in poolitem */
		Tmp->space = 0;
		Tmp->res = 0;
		Tmp->MagicNum = MAGIC_NUM;
		pr_debug("MAGIC %x tmp:%lx\n", Tmp->MagicNum,
				PCI_TO_PE((uint32)Tmp));
#if 1
		Tmp->Ptr = (((int8 *)Tmp) + Size);
		Tmp = (POOLITEM_PTR)((POOLITEM_PTR)Tmp)->Ptr;
#else
{
		temp_lvalue = (uint32)(((int8 *)Tmp) + Size);
		word_copy((uint32a *)&(Tmp->Ptr), (uint32a *)&temp_lvalue, sizeof(int8 *));
		word_copy((uint32a *)&Tmp, (uint32a *)&(Tmp->Ptr), sizeof(int8 *));
}
#endif
	}

#if 1
	Last->Ptr = NULL;
#else
	temp_lvalue = 0;
	word_copy((uint32a *)&(Last->Ptr), (uint32a *)&temp_lvalue, sizeof(int8 *));
#endif
	pHead->Rear = (int8 *)Last;
	pHead->Free = Num;
	pHead->PoolSize = Num;
	FPATH_TRACE(FP_TRACE_INIT, FP_LOG_DEBUG,
		("%s: free = %d, pool size = %d\n",
		 __func__, pHead->Free, pHead->PoolSize));
	return pHead;
}

/*******************************************************************************
 * Function name:       poolAlloc
 * Input Parameters:    Pointer to PoolHead data structure
 * Output Parameters:   None
 * Result:              Pointer to the allocated buffer
 * Description:
 *                      This function allocates a buffer from the free buffer
 *                      pool.
 ******************************************************************************/
int8 *poolAlloc(POOLHEAD_PTR pHead)
{
	int8 *New = NULL;
	POOLITEM_PTR Tmp = NULL;

#if 1
{
	int8 *tmp = pool_ptr;
	pool_ptr += 128;
	return tmp;
}
#endif
	if (pHead == NULL)
		return NULL;

	/* check to see if pool is empty */
	if (pHead->Free == 0)
		return NULL;

	if (pHead->Front != NULL) {
		/* clear off the MAGIC number before allocating */
		New = pHead->Front;
		Tmp = (POOLITEM_PTR)New;
#if 0
		if (((POOLITEM_PTR)Tmp)->MagicNum != MAGIC_NUM) {
			FPATH_TRACE(FP_TRACE_INIT, FP_LOG_ERR,
				("%s: trying to allocate an allocated buffer\n",
				 __func__));
			return NULL;
		}
#endif
		Tmp->space = 0;
		Tmp->res = 0;
		Tmp->MagicNum = 0;
#if 1
		pHead->Front = Tmp->Ptr;
		Tmp->Ptr = NULL;
#else
		word_copy((uint32a *)&(pHead->Front), (uint32a *)&(Tmp->Ptr), sizeof(int8 *));
		temp_lvalue = 0;
		word_copy((uint32a *)&(Tmp->Ptr), (uint32a *)&temp_lvalue, sizeof(int8 *));
#endif
		pHead->Free--;
	} else {  /* Should never come here */
		FPATH_TRACE(FP_TRACE_INIT, FP_LOG_ERR,
			("%s: error while allocating the pool element\n",
			__func__));
		return NULL;
	}
	return New;
}

/*******************************************************************************
 * Function name:       pooFree
 * Input Parameters:    ptr to the buffer, ptr to poolhead
 * Output Parameters:   None
 * Result:              None
 * Description:
 *                      This function frees the given buffer. It basically puts
 *                      back the buffer into the free buffer pool.
 ******************************************************************************/
int32a poolFree(int8 *pDel, POOLHEAD_PTR pHead)
{
return 0;
	if (pHead == NULL) {
		FPATH_TRACE(FP_TRACE_OTHER, FP_LOG_ERR,
				("%s: PANIC\n", __func__));
		return -1;
	}
	/* check to see if pool is full */
	if (pHead->Free == pHead->PoolSize) {
		FPATH_TRACE(FP_TRACE_CLEANUP, FP_LOG_ERR,
			("%s: buffer pool full\n", __func__));
		return -1;
	}
	if (pDel == NULL) {
		FPATH_TRACE(FP_TRACE_CLEANUP, FP_LOG_WARNING,
			("%s: trying to free a NULL ptr\n", __func__));
		return -1;
	}
	if (((POOLITEM_PTR)pDel)->MagicNum == MAGIC_NUM) {
		FPATH_TRACE(FP_TRACE_CLEANUP, FP_LOG_ERR,
			("%s: trying to free a freed buffer\n", __func__));
		return -1;
	}
	if (pHead->Free == 0)
		pHead->Front = pDel;
	else
		((POOLITEM_PTR)pHead->Rear)->Ptr = pDel;
	pHead->Rear = pDel;
	/* put the MAGIC number back */
	((POOLITEM_PTR)pHead->Rear)->space = 0;
	((POOLITEM_PTR)pHead->Rear)->res   = 0;
	((POOLITEM_PTR)pHead->Rear)->MagicNum = MAGIC_NUM;
	((POOLITEM_PTR)pHead->Rear)->Ptr = NULL;
	pHead->Free++;
	pr_debug("FR:%x size:%x,delp:%p\n", pHead->Free, pHead->PoolSize, pDel);
	return 0;
}

/*******************************************************************************
 * Function name:       poolCount
 * Input Parameters:    Pointer to PoolHead data structure
 * Output Parameters:   None
 * Result:              The number of buffers left in the pool
 * Description:
 *                      This function returns a count of the number of buffers
 *                      in the pool.
 ******************************************************************************/
uint32a poolCount(POOLHEAD_PTR pHead)
{
	FPATH_TRACE(FP_TRACE_INIT, FP_LOG_DEBUG,
		("total available memory = %d\n", pHead->Free));
	FPATH_TRACE(FP_TRACE_INIT, FP_LOG_DEBUG,
		("total pool memory = %d\n", pHead->PoolSize));
	return 0;
}

/*******************************************************************************
 * Function name:       poolDelete
 * Input Parameters:    Pointer to PoolHead data structure
 * Output Parameters:   None
 * Result:              success or failure
 * Description:
 *                      This function frees the entire pool
 ******************************************************************************/
uint32a poolDelete(POOLHEAD_PTR pHead, uint32a type)
{
return 0;
	/* will need to add back when we have multiple tables */
	fp_pci_free((int8 *)pHead->Start, type);
	kfree(pHead);
	return 0;
}

