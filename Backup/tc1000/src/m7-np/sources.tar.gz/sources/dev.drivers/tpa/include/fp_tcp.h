/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
 * @File
 * @Title        fp_tcp.h
 * @Copyright    Copyright (c) 2007-2009, Naksha Technologies, Inc.
 * @Copyright    Copyright (c) 2010-2012, Posedge Technologies, Inc.
 * @Copyright    Copyright (c) 2013-2020, Imagination Technologies Ltd.
 * @Copyright    Copyright (c) Imagination Technologies Ltd. All Rights Reserved
 * @Description  This file contains the structure declaration for TCP header
 * @License      Dual MIT/GPLv2
 *
 * The contents of this file are subject to the MIT license as set out below.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * the GNU General Public License Version 2 ("GPL") in which case the provisions
 * of GPL are applicable instead of those above.
 *
 * If you wish to allow use of your version of this file only under the terms of
 * GPL, and not to allow others to use your version of this file under the terms
 * of the MIT license, indicate your decision by deleting the provisions above
 * and replace them with the notice and other provisions required by GPL as set
 * out in the file called "GPL-COPYING" included in this distribution. If you do
 * not delete the provisions above,a recipient may use your version of this file
 * under the terms of either the MIT license or GPL.
 *
 * This License is also included in this distribution in the file called
 * "MIT-COPYING".
 *
 * EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 * PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */ /**************************************************************************/

#ifndef _FP_TCP_H_
#define _FP_TCP_H_


struct my_tcphdr
{
	uint16     src;
	uint16     dst;
	uint32a       seq;
	uint32a       ack_seq;
#ifdef __FP_OS__
	uint16     res1:4;
	uint16     doff:4;
	uint16     fin:1;
	uint16     syn:1;
	uint16     rst:1;
	uint16     psh:1;
	uint16     ack:1;
	uint16     urg:1;
	uint16     res2:2;
#else
	uint16     doff:4;
	uint16     res1:4;
	uint16     res2:2;
	uint16     urg:1;
	uint16     ack:1;
	uint16     psh:1;
	uint16     rst:1;
	uint16     syn:1;
	uint16     fin:1;
#endif
	uint16     window;
	uint16     check;
	uint16     urg_ptr;
};

#endif

