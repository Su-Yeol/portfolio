// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
 * @File
 * @Title        fp_pci_pe.c
 * @Copyright    Copyright (c) Imagination Technologies Ltd. All Rights Reserved
 * @Description  ddr table initialization
 * @License      Dual MIT/GPLv2
 *
 * The contents of this file are subject to the MIT license as set out below.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * the GNU General Public License Version 2 ("GPL") in which case the provisions
 * of GPL are applicable instead of those above.
 *
 * If you wish to allow use of your version of this file only under the terms of
 * GPL, and not to allow others to use your version of this file under the terms
 * of the MIT license, indicate your decision by deleting the provisions above
 * and replace them with the notice and other provisions required by GPL as set
 * out in the file called "GPL-COPYING" included in this distribution. If you do
 * not delete the provisions above,a recipient may use your version of this file
 * under the terms of either the MIT license or GPL.
 *
 * This License is also included in this distribution in the file called
 * "MIT-COPYING".
 *
 * EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 * PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");
/**********************************************************************
 *                                     Include Files
 **********************************************************************/
#include "fp_library.h"
#include "reg_hal.h"
#include "fp_global_addr_map.h"
#include "fp_macros.h"
#include "fp_net_driver.h"
#include "global_address_map_fpga.h"
//#ifdef FP_IPSEC
//#include "fp_sa.h"
//#endif
#include "tables_config.h"

#ifdef HASH_ARR_EN
extern struct cacheFlow *grtHashArr;
#endif

uint8 *fp_get_routetable_address(int32a level);

/* This table contains PE DDR memory allocation details */
struct pci_mem_info_s {

	/* start addres of PE config space for If Data */
	uint8 *pPEConfigIfData;
	/*start addres of PE config space for PhyPorts */
	uint8 *pPEConfigPhyPort;
	uint8 *switch_port;
	uint8 *switch_global;
	uint8 *sw_stats;

	/* start address of route table hash array */
	uint8 *pRtHashTblStart;
	/* end address of route table hash array */
	uint8 *pRtHashTblEnd;
	/* start address of route entries pool */
	uint8 *pRtTblEntriesStart;
	/*  end address of route entries pool */
	uint8 *pRtTblEntriesEnd;
	/* allocate/deallocate status of rt hash array */
	uint8 rtHashTblStatus;
	/* allocate/deallocate status of rt entries pool */
	uint8 rtEntriesStatus;
	/* reserved */
	uint8 res1[2];

	/* start address of Bridge table hash array */
	uint8 *pBrHashTblStart;
	/* end address of Bridge table hash array */
	uint8 *pBrHashTblEnd;
	/*start address of route entries pool */
	uint8 *pBrTblEntriesStart;
	/* end address of bridge entries pool */
	uint8 *pBrTblEntriesEnd;
	/* start address of Bridge table hash array */
	uint8 *pVlanHashTblStart;
	/* end address of Bridge table hash array */
	uint8 *pVlanHashTblEnd;
	/* start address of route entries pool */
	uint8 *pVlanTblEntriesStart;
	/* end address of bridge entries pool */
	uint8 *pVlanTblEntriesEnd;
	/* allocate/deallocate status of Bridge hash array */
	uint8 brHashTblStatus;
	/* allocate/deallocate status of bridge entries pool */
	uint8 brEntriesStatus;
	/* reserved */
	uint8 res2[2];
#if 0
#ifdef FP_IPSEC
	/* ipsec sa */
	/* start address of route table hash array */
	uint8 *pIpsecSaHashTblStart;
	/* end address of route table hash array */
	uint8 *pIpsecSaHashTblEnd;
	/* start address of route entries pool */
	uint8 *pIpsecSaTblEntriesStart;
	/* end address of route entries pool */
	uint8 *pIpsecSaTblEntriesEnd;
	/* allocate/deallocate status of rt hash array */
	uint8 ipsecSaHashTblStatus;
	/* allocate/deallocate status of rt entries pool */
	uint8 ipsecSaEntriesStatus;
	/* reserved */
	uint8 res5[2];
#endif
#endif
} fpPciMem;

extern struct fp_private *fpGlobal;
uint8 *fp_get_routetable_address(int32a level)
{
	//fpGlobal = (struct fp_private *)netdev_priv(fp_net_dev);
	//struct fp_private *fp = netdev_priv((struct net_device *)dev);
	uint8 *BaseAddr = GetBaseAddr();
	uint32a i;

	ENTER;
	if (fpGlobal == NULL) {
		LEAVE;
		return NULL;
	}
#if 0
	if (fpGlobal->pci_dev == NULL) {
		LEAVE;
		return NULL;
	}
	if (&fpGlobal->pci_dev->dev == NULL) {
		LEAVE;
		return NULL;
	}
#endif

	if (level == HASH_SINGLE_LEVEL) {
#ifdef HASH_ARR_EN

#ifdef ROUTE_LMEM_EN
#define LMEM_ROUTE_BASE_ADDR  0x780000  // Partition4, Route/IP Table (512KB)
#define SINGLE_LEVEL_SIZE     0x20000   // 128KB
		fpGlobal->ddr_single_va = BaseAddr + LMEM_ROUTE_BASE_ADDR;
		fpGlobal->ddr_single_pa = (dma_addr_t)(LMEM_ROUTE_BASE_ADDR + 0xC0000000);

		for (i=0; i<FP_MAX_PORTS; i++) {
			if ((EMAC_PORT_LIST_MASK >> i) & 0x1) {
				RegWrite(egpi_base_addr[i] + INGRESS_CLASSIFIER_BASE_ADDR + ROUTE_TABLE_OFFSET,
					 fpGlobal->ddr_single_pa);
			}
		}

		RegWrite(HGPI_CLASS_HW_ROUTE_TABLE_BASE_ADDR, fpGlobal->ddr_single_pa);

		LEAVE;
		return fpGlobal->ddr_single_va;

#else
		dma_addr_t dev_addr;

		fpGlobal->ddr_single_va = (uint8 *)dma_alloc_coherent
			(&fpGlobal->pci_dev->dev, (RT_ENTRIES_POOL_SIZE),
			 &dev_addr, GFP_ATOMIC);
		fpGlobal->ddr_single_pa = dev_addr;
		pr_info("DDR single VA %p DDR single  PA %x\n",
			fpGlobal->ddr_single_va, fpGlobal->ddr_single_pa);
			RegWrite(CLASS_ROUTE_TABLE_BASE_ADDR,
			fpGlobal->ddr_single_pa);
		LEAVE;
		return fpGlobal->ddr_single_va;
#endif

#endif
	} else if (level == HASH_TWO_LEVEL) {
#ifdef ROUTE_LMEM_TWO_LEVEL_EN
		fpGlobal->ddr_va = (uint8 *)(LMEM_ROUTE_BASE_ADDR + SINGLE_LEVEL_SIZE + BaseAddr);
		fpGlobal->ddr_pa = (dma_addr_t)(LMEM_ROUTE_BASE_ADDR + SINGLE_LEVEL_SIZE + 0xC0000000);

		LEAVE;
		return fpGlobal->ddr_va;
#else
		dma_addr_t dev_addr;

		fpGlobal->ddr_va = (uint8 *)dma_alloc_coherent
			(&fpGlobal->pci_dev->dev, (RT_ENTRIES_POOL_SIZE),
			&dev_addr, GFP_ATOMIC);
		fpGlobal->ddr_pa = dev_addr;
		pr_info("DDR VA %p DDR PA %x\n", fpGlobal->ddr_va,
						 fpGlobal->ddr_pa);
		LEAVE;
		return fpGlobal->ddr_va;
#endif
	}
	LEAVE;
	return NULL;

}

void fp_pci_ddr_tbl_init(uint8 *ptr)
{
#ifdef __FP_OS__
	uint32a *test_addr;
	uint32a test_data1 = 0x0;
	uint32a test_data2;
#endif
	ENTER;
	/* HOW to data and CSR
	 * fpPciMem.pPEConfigIfData = ptr + PE_CONFIG_IFDATA_ADDR;
	 * fpPciMem.pPEConfigPhyPort = ptr + PE_CONFIG_PHYPORT_ADDR;
	 * fpPciMem.pPEConfigIfData  = ptr + PE_LMEM_ADDR_IF;
	 * fpPciMem.pPEConfigPhyPort = ptr + PE_LMEM_ADDR_PHY;
	 */
	fpPciMem.switch_port = (uint8 *)(ptr + PE_CONFIG_SWITCH_PORT_ADDR);
	fpPciMem.switch_global = (uint8 *)(ptr + PE_CONFIG_SWITCH_GLOBAL_ADDR);
#ifdef SW_STATS
	fpPciMem.sw_stats = (uint8 *)(ptr + PE_CONFIG_SWITCH_STATS_ADDR);
#endif
	/* Initialize all the ptrs based on the start address of
	 * the PCI DDR memory
	 */
	fpPciMem.pRtHashTblStart = (uint8 *)(ptr + PE_LMEM_ADDR);
	fpPciMem.pRtHashTblEnd = (uint8 *)(fpPciMem.pRtHashTblStart + RT_HASH_TABLE_POOL_SIZE);
	/*Allocated memory for bridge hatable*/
	fpPciMem.pBrHashTblStart = (uint8 *)PE_CONFIG_BTABLE_ADDR;
	fpPciMem.pBrHashTblEnd = (uint8 *)(fpPciMem.pBrHashTblStart + BR_HASH_TABLE_POOL_SIZE);
	/*Allocated memory for Vlanhash table hatable*/
	fpPciMem.pVlanHashTblStart = (uint8 *)PE_CONFIG_VTABLE_ADDR;
	fpPciMem.pVlanHashTblEnd = (uint8 *)(fpPciMem.pVlanHashTblStart + BR_HASH_TABLE_POOL_SIZE);
	fpPciMem.rtHashTblStatus = 0;
	fpPciMem.brHashTblStatus = 0;
#ifdef __FP_OS__
#ifdef HASH_ARR_EN
	grtHashArr = (struct cacheFlow *)fp_get_routetable_address(HASH_SINGLE_LEVEL);
	printk("grtHashArr = %px",grtHashArr);
	if (!grtHashArr) {
		pr_err("Hash arry not allocated\n");
		LEAVE;
		return;
	}
	test_data1 = 0x01020304;
	test_addr  = (uint32a *)grtHashArr;
	*test_addr = test_data1;
#ifdef DEBUG_PCI
	pr_debug("Write Single level Done\n");
#endif
	test_data2 = (uint32a) *test_addr;
	if (test_data2 != test_data1)
		pr_info("Basic HW Rd/WR Failed : %x\n", test_data2);
	else
		pr_info("Basic HW Rd/WR passed : %x\n", test_data2);
#endif
	fpPciMem.pRtTblEntriesStart = fp_get_routetable_address(HASH_TWO_LEVEL);
	if (fpPciMem.pRtTblEntriesStart == NULL) {
		pr_err("Route entries  not allocated\n");
		LEAVE;
		return;
	}
	test_data1 = 0x01020304;
	test_addr  = (uint32a *)fpPciMem.pRtTblEntriesStart;
	*test_addr = test_data1;
#ifdef DEBUG_PCI
	pr_debug("Write Done\n");
#endif
	test_data2 = (uint32a) *test_addr;
	if (test_data2 != test_data1)
		pr_info("Basic HW Rd/WR Failed : %x\n", test_data2);
	else
		pr_info("Basic HW Rd/WR passed : %x\n", test_data2);
#else
#ifdef HASH_ARR_EN
	grtHashArr = (struct cacheFlow *)(ptr + PE_DDR_ADDR_HASH);
#endif
	fpPciMem.pRtTblEntriesStart = (struct cacheFlow *)(ptr + PE_DDR_ADDR);
#endif
	fpPciMem.pRtTblEntriesEnd = (uint8 *)(fpPciMem.pRtTblEntriesStart + RT_ENTRIES_POOL_SIZE);

	/* fpPciMem.pBrTblEntriesStart = fpPciMem.pRtTblEntriesEnd +
	 * PCI_BUFFER_SPACE;
	 */

	/* Bridge table entries */
	fpPciMem.pBrTblEntriesStart = (uint8 *)PE_CONFIG_BENTRY_ADDR;
	/* fpPciMem.pBrHashTblEnd */
	fpPciMem.pBrTblEntriesEnd = (uint8 *)(fpPciMem.pBrTblEntriesStart + BR_ENTRIES_POOL_SIZE);
	/*Vlan table  entries*/
	fpPciMem.pVlanTblEntriesStart = (uint8 *)PE_CONFIG_VENTRY_ADDR;
	/*fpPciMem.pVlanHashTblEnd; */
	fpPciMem.pVlanTblEntriesEnd = (uint8 *)(fpPciMem.pVlanTblEntriesStart + BR_ENTRIES_POOL_SIZE);

	fpPciMem.rtEntriesStatus = 0;  /* not allocated */
	fpPciMem.brEntriesStatus = 0;  /* not allocated */

#if 0
#ifdef FP_IPSEC
	fpPciMem.pIpsecSaHashTblStart = (uint8 *)(ptr + IPSEC_SA_HASH_TABLE_ADDR);
	fpPciMem.pIpsecSaHashTblEnd = (uint8 *)(fpPciMem.pIpsecSaHashTblStart + IPSEC_SA_HASH_TABLE_POOL_SIZE);
	fpPciMem.pIpsecSaTblEntriesStart = (uint8 *)(ptr + IPSEC_SA_HASH_ENTRIES_ADDR);
	fpPciMem.pIpsecSaTblEntriesEnd = (uint8 *)(fpPciMem.pIpsecSaTblEntriesStart + IPSEC_SA_HASH_ENTRIES_POOL_SIZE);
	fpPciMem.ipsecSaHashTblStatus = 0;  /* not allocated */
	fpPciMem.ipsecSaEntriesStatus    = 0;  /* not allocated */
#endif
#endif

#ifdef __FP_OS__
	pr_info("%s\n", __func__);
	/*printk("\n fpPciMem.pPEConfigIfData : %p",fpPciMem.pPEConfigIfData);
	 *printk("\n fpPciMem.pPEConfigPhyPort : %p",fpPciMem.pPEConfigPhyPort);
	 */
	pr_info("\n fpPciMem.pRtHashTblStart: %p-->%p", fpPciMem.pRtHashTblStart
			, (uint8 *)(fpPciMem.pRtHashTblStart-ptr));
	pr_info("\n fpPciMem.pRtHashTblEnd : %p-->%p", fpPciMem.pRtHashTblEnd,
			(uint8 *)(fpPciMem.pRtHashTblEnd-ptr));
	pr_info("\n fpPciMem.pRtTblEntriesStart : %p-->%p",
		fpPciMem.pRtTblEntriesStart,
		(uint8 *)(fpPciMem.pRtTblEntriesStart-ptr));
	pr_info("\n fpPciMem.pRtTblEntriesEnd : %p-->%p",
		fpPciMem.pRtTblEntriesEnd,
		(uint8 *)(fpPciMem.pRtTblEntriesEnd-ptr));
	pr_info("\n fpPciMem.pBrHashTblStart : %p", fpPciMem.pBrHashTblStart);
	pr_info("\n fpPciMem.pBrTblEntriesStart : %p",
			fpPciMem.pBrTblEntriesStart);
	pr_info("\n fpPciMem.pBrTblEntriesEnd : %p", fpPciMem.pBrTblEntriesEnd);

#if 0
#ifdef FP_IPSEC
	pr_info("\n fpPciMem.pIpsecSaHashTblStart : %p-->%p",
			fpPciMem.pIpsecSaHashTblStart,
			(uint8 *)(fpPciMem.pIpsecSaHashTblStart-ptr));
	pr_info("\n fpPciMem.pIpsecSaHashTblEnd   : %p-->%p",
			fpPciMem.pIpsecSaHashTblEnd,
			(uint8 *)(fpPciMem.pIpsecSaHashTblEnd-ptr));
	pr_info("\n fpPciMem.pIpsecSaTblEntriesStart : %p-->%p",
		fpPciMem.pIpsecSaTblEntriesStart,
		(uint8 *)(fpPciMem.pIpsecSaTblEntriesStart-ptr));
	pr_info("\n fpPciMem.pIpsecSaTblEntriesEnd : %p-->%p",
			fpPciMem.pIpsecSaTblEntriesEnd,
			(uint8 *)(fpPciMem.pIpsecSaTblEntriesEnd-ptr));
#endif
#endif
#endif
	LEAVE;

}

uint8  *fp_pci_malloc(uint32a size, uint8 type)
{
	int8 *pAlloc = NULL;
	ENTER;
  /* allocate pci memory */
	switch (type) {
#if ((defined  __FP_OS__) || (defined HW_SIM))
	case RT_ENTRIES_TABLE:
#ifdef __FP_OS__
		pr_info("\n rtEntriesStatus:%x size %x\n",
				fpPciMem.rtEntriesStatus, size);
#endif
		if (fpPciMem.rtEntriesStatus)
			return NULL;

		if ((fpPciMem.pRtTblEntriesStart + size) >
					fpPciMem.pRtTblEntriesEnd) {
			LEAVE;
			return NULL;
		}
		pAlloc = (int8 *)fpPciMem.pRtTblEntriesStart;
#ifdef __FP_OS__
		pr_info("\n  pAlloc:%p", pAlloc);
#endif
		fpPciMem.rtEntriesStatus = 1;
	break;

	case RT_HASH_TABLE:
		if (fpPciMem.rtHashTblStatus) {
			LEAVE;
			return NULL;
		}
		if ((fpPciMem.pRtHashTblStart + size) >
				fpPciMem.pRtHashTblEnd) {
			LEAVE;
			return NULL;
		}
		pAlloc = (int8 *)fpPciMem.pRtHashTblStart;
		fpPciMem.rtHashTblStatus = 1;
	break;
#endif /*End of __FP_OS__*/

	case BR_ENTRIES_TABLE:
#ifdef __FP_OS__
		pr_info("\n brEntriesStatus:%x ",
				fpPciMem.brEntriesStatus);
#endif
		if ((fpPciMem.pBrTblEntriesStart + size) >
				fpPciMem.pBrTblEntriesEnd) {
#ifdef __FP_OS__
			pr_err("Bridge Entry Table Allocation Fail\n");
#else
			nkprintf("Bridge Entry Table Allocation Fail\r\n");
#endif
			LEAVE;
			return NULL;
		}
		pAlloc = (int8 *)fpPciMem.pBrTblEntriesStart;
	break;

	case BR_HASH_TABLE:
		if ((fpPciMem.pBrHashTblStart + size) >
						fpPciMem.pBrHashTblEnd) {
#ifdef __FP_OS__
			pr_err("Bridge Hash Table Allocation Fail\n");
#endif
#ifndef __FP_OS__
			nkprintf("Bridgefail\r\n");
#endif
			LEAVE;
			return NULL;
		}
		pAlloc = (int8 *)fpPciMem.pBrHashTblStart;
#ifndef __FP_OS__
			/*  nkprintf("Bridge:%x\r\n",pAlloc); */
#endif
	break;

	case VLAN_HASH_TABLE:
		if ((fpPciMem.pVlanHashTblStart + size) >
					 fpPciMem.pVlanHashTblEnd) {
#ifdef __FP_OS__
			pr_err("Vlan Hash Table Allocation Fail\n");
#else
			nkprintf("Vlan Hash Table Allocation Fail\n");

#endif
			LEAVE;
			return NULL;
		}
		pAlloc =  (int8 *)fpPciMem.pVlanHashTblStart;
	break;

	/* Adding Vlan Hash & Entries Memorys from DMEME */
	case VLAN_ENTRIES_TABLE:
		if ((fpPciMem.pVlanTblEntriesStart + size) >
				fpPciMem.pVlanTblEntriesEnd) {
#ifdef __FP_OS__
			pr_err("Vlan Entry Table Allocation Fail\n");
#endif
			LEAVE;
			return NULL;
		}
		pAlloc = (int8 *)fpPciMem.pVlanTblEntriesStart;
	break;

#if 0
#ifdef FP_IPSEC
	case IPSEC_SA_ENTRIES_TABLE:
#ifdef __FP_OS__
		pr_info("\n ipsecSaEntriesStatus:%x\n",
				fpPciMem.ipsecSaEntriesStatus);
#endif
		if (fpPciMem.ipsecSaEntriesStatus) {
			LEAVE;
			return NULL;
		}
		if ((fpPciMem.pIpsecSaTblEntriesStart + size) >
					fpPciMem.pIpsecSaTblEntriesEnd) {
			LEAVE;
			return NULL;
		}
		pAlloc = (int8 *)fpPciMem.pIpsecSaTblEntriesStart;
#ifdef __FP_OS__
		pr_info("\n IPSEC SA pAlloc:%p", pAlloc);
#endif
		fpPciMem.ipsecSaEntriesStatus = 1;
	break;

	case IPSEC_SA_HASH_TABLE:
#ifdef __FP_OS__
		pr_info("\n ipsecSaStatus:%x\n",
					fpPciMem.ipsecSaHashTblStatus);
#endif
		if (fpPciMem.ipsecSaHashTblStatus) {
			LEAVE;
			return NULL;
		}
		if ((fpPciMem.pIpsecSaHashTblStart + size) >
					fpPciMem.pIpsecSaHashTblEnd) {
			LEAVE;
			return NULL;
		}
		pAlloc = (int8 *)fpPciMem.pIpsecSaHashTblStart;
#ifdef __FP_OS__
		pr_info("\n IPSEC SA pAlloc:%p", pAlloc);
#endif
		fpPciMem.ipsecSaHashTblStatus = 1;
	break;
#endif
#endif

	default:
#ifdef __FP_OS__
		pr_warn("\n PCI allocation type %x not supported", type);
#endif
	break;
	}
	LEAVE;
	return (uint8 *)pAlloc;
}

int8 fp_pci_free(int8 *ptr, uint8 type)
{
	int8 rc = 0;

	switch (type) {
	case RT_ENTRIES_TABLE:
		if (fpPciMem.rtEntriesStatus)
			fpPciMem.rtEntriesStatus = 0;
		else
			rc = -1;
	break;

	case RT_HASH_TABLE:
		if (fpPciMem.rtHashTblStatus)
			fpPciMem.rtHashTblStatus = 0;
		else
			rc = -1;
	break;

#if 0
#ifdef FP_IPSEC
	case IPSEC_SA_ENTRIES_TABLE:
		if (fpPciMem.ipsecSaEntriesStatus)
			fpPciMem.ipsecSaEntriesStatus = 0;
		else
			rc = -1;
	break;
	case IPSEC_SA_HASH_TABLE:
		if (fpPciMem.ipsecSaHashTblStatus)
			fpPciMem.ipsecSaHashTblStatus = 0;
		else
			rc = -1;
	break;
#endif
#endif

	case BR_ENTRIES_TABLE:
		if (fpPciMem.brEntriesStatus)
			fpPciMem.brEntriesStatus = 0;
		else
			rc = -1;
		break;

	case BR_HASH_TABLE:
		if (fpPciMem.brHashTblStatus)
			fpPciMem.brHashTblStatus = 0;
		else
			rc = -1;
	break;

	default:
		/*printk("\n PCI allocation type %x
		 *	not supported",type);
		 */
	break;
	}
	return rc;
}

int8 *getIfBasePtr(void)
{
	ENTER;
	LEAVE;
	return (int8 *)(fpPciMem.pPEConfigIfData);
}
