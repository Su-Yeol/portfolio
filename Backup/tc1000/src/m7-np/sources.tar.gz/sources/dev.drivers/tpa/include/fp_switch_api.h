/* SPDX-License-Identifier: (GPL-2.0 WITH Linux-syscall-note) AND MIT */

/*************************************************************************/ /*!
@File
@Title          fp_switch_api.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    Structures for hw switch
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

/*!
 * @mainpage NPU L2 Fast Path Control API
 *
 * Copyright (c) Imagination Technologies Ltd. All Rights Reserved
 *
 * The L2 Fast Path Control API is the primary method that the host uses
 * to configure the NPU L2 switch hardware. The API provides access to the
 * MAC table, the Bridge Domain table, and the switch ports.
 *
 * @file fp_switch_api.h
 * API for L2 Bridge Domain table and global configuration
 */

#ifndef  _FP_HW_SW_API_H_
#define  _FP_HW_SW_API_H_

/**********************************************************************
 *                                      #defines
 **********************************************************************/
#if 0
#define BRENTRY_FWD_PORT_LIST_START_POS		0
#define BRENTRY_UNTAG_LIST_START_POS		8
#define BRENTRY_UCAST_HIT_ACT_START_POS		16
#define BRENTRY_MCAST_HIT_ACT_START_POS		19
#define BRENTRY_UCAST_MISS_ACT_START_POS	22
#define BRENTRY_MCAST_MISS_ACT_START_POS	25
#define BRENTRY_MSTP_HIT_ACT_START_POS		28
#define BRENTRY_RESERVED_BIT_MASK_START_POS	31
#endif

#define BRENTRY_FWDPORT				1
#define BRENTRY_UNTAGLIST			2

//#define BRENTRY_UCAST_HIT			3
//#define BRENTRY_MCAST_HIT			4
//#define BRENTRY_UCAST_MISS			5
//#define BRENTRY_MCAST_MISS			6
//#define BRENTRY_MSTP				7

#define BRENTRY_UCAST_HIT			0
#define BRENTRY_MCAST_HIT			1
#define BRENTRY_UCAST_MISS			2
#define BRENTRY_MCAST_MISS			3
#define BRENTRY_MSTP				4


#define PORT_BASE_ADDR				0x400
#define GLOBAL_BR_ENTRY_ADDR			0x48c

/*!
 Add an bridge domain entry into bridge domain hash table.

 @param   wsp_base_addr   base address of the WSP registers
 @param   vlanId  Value in the range of [0 - 4093]
 @param   fwdPortList     Max 8 ports, bit mapped to port from rt to lt [0-0xFF]
 @param   untagList       Max 8 ports, bit mapped to port from rt to lt [0-0xFF]
 @param   ucastHitAct     unicast hit action (see enum fwd_action_e)
 @param   mcastHitAct     multicast hit action (see enum fwd_action_e)
 @param   ucastMissAct    unicast miss action (see enum fwd_action_e)
 @param   mcastMissAct    multicast hit action (see enum fwd_action_e)
 @param   mstpAct         mstp action (see enum fwd_action_e)
 @return status code:       0=success, -1=failure
 */
extern int32a fp_br_entry_add(uint32a vlanId,
				uint32a fwdPortList,
				uint32a untagList,
				uint32a ucastHitAct,
				uint32a mcastHitAct,
				uint32a ucastMissAct,
				uint32a mcastMissAct,
				uint32a mstpAct);

/*!
 Update ports in an existing bridge domain entry.

 @param wsp_base_addr  base address of the WSP registers
 @param vlanId         [0 - 4093]
 @param PortList       Max 8 ports [0-0xFF], bit mapped to port from rt to lt
 @param UnTagList      Max 8 ports [0-0xFF], bit mapped to port from rt to lt [0-0xFF]
 @return status code:       0=success, -1=failure
 **/
extern int32a fp_br_entry_add_ports(uint32a vlanId, uint32a portList, uint32a untagList);

/*!
 Get ports list from bridge domain entry.

 @param wsp_base_addr  base address of the WSP registers
 @param vlanId         [0 - 4093]
 @return PortList Max 8 ports [0-0xFF], bit mapped to port from rt to lt
 **/
extern int32a fp_br_entry_portlist_get(uint32a vlanId);

/*!
 Search for a bridge entry from bridge domain.

 @param wsp_base_addr  base address of the WSP registers
 @param vlanId         [0 - 4093]
 @return bridge entry
 **/
extern int64 fp_br_entry_search(uint32a vlanId);

/*!
 Get port's untag list from bridge domain entry.

 @param wsp_base_addr  base address of the WSP registers
 @param vlanId         [0 - 4093]
 @return UnTagList Max 8 ports [0-0xFF], bit mapped to port from rt to lt [0-0xFF]
 **/
extern int32a fp_br_entry_untaglist_get(uint32a vlanId);

/*!
 Change port's tag value.

 @param wsp_base_addr  base address of the WSP registers
 @param vlanId    [0 - 4093]
 @param portNo         specifies bit mapped port num from [0 - 0xFF]
 @param Tagvalue       mapped to each port tag/untag list from [0 - 0xFF]
 @return status code:       0=success, -1=failure
 **/
extern int32a fp_br_entry_port_tag_chg(uint32a vlanId, uint32a portNo, uint32a TagValue);

/*!
 Get fwd action entry from bridge domain entry.

 @param wsp_base_addr  base address of the WSP registers
 @param vlanId   [0 - 4093]
 @return  bit-coded bridge domain action entry (see below)

 @code
   VLAN (BD) Hash table action entry map:
   =======================================
    [07:00]         - forward port list
    [15:08]         - untag list
    [18:16]         - ucast_hit_action
    [21:19]         - mcast_hit_action
    [24:22]         - ucast_miss_action
    [27:25]         - mcast_miss_action
    [30:28]         - mstp
    [31:31]         - Not used yet
   =======================================
 @endcode

 **/
extern int64 fp_br_entry_fwd_action_get(uint32a vlanId);

/*!
 Get port's config.

 @param wsp_base_addr  base address of the WSP registers
 @param portNo   specifies bit mapped port num from [0 - 0xFF]
 @param pPortInfo[out]  port configuration
 @return status code:       0=success, -1=failure
 **/
extern int32a fp_port_config_get(uint8	*dev, uint32a	portNo, struct port_s	*pPortInfo);

/*!
 Get global (fallback) bridge domain entry's data.

 @param wsp_base_addr  base address of the WSP registers
 @param pGlobal_br_entry[out]    Returns global config structure
 @return status code:       0=success, -1=failure
 **/
extern int32a fp_global_br_entry_config_get(struct global_s *pGlobal_br_entry);

/*!
 Change action fields of an existing bridge domain entry.

 @param wsp_base_addr  base address of the WSP registers
 @param vlanId          [0 - 4093]
 @param field           BRENTRY_UCAST_HIT/BRENTRY_MCAST_HITBRENTRY_UCAST_MISS/BRENTRY_MCAST_MISS/BRENTRY_MSTP
 @param field_value     value should be in the range of [0- 5]
 @return status code   0=success, -1=failure
 **/
extern int32a fp_br_entry_fwd_action_change(uint32a vlanId, uint32a field, uint32a value);

/*!
 Set port configuration.

 @param wsp_base_addr  base address of the WSP registers
 @param portNo         specifies bit mapped port num from [0 - 0xFF]
 @param pPort          port configuration info
 @return status code   0=success, -1=failure
 **/
extern int32a fp_port_config(uint32a portNo, struct port_s *pPort);

/*!
 Configure global (fallback) bridge domain entry.

 @param wsp_base_addr  base address of the WSP registers
 @param pGlobal_br_entry  global configuration info
 @return status code   0=success, -1=failure
 **/
extern int32a fp_global_br_entry_config(struct global_s *pGlobal_br_entry);


/*!
 Delete a bridge domain entry.

 @param wsp_base_addr  base address of the WSP registers
 @param vlanId        [0 - 4093]
 @return status code   0=success, -1=failure
 **/
extern int32a fp_br_entry_del (uint32a vlanId);

/*!
 Delete ports from an existing bridge domain entry.

 @param wsp_base_addr  base address of the WSP registers
 @param vlanId          [0 - 4093]
 @param portList        Max 8 ports [0-0xFF], bit mapped to port from rt to lt
 @return status code   0=success, -1=failure
 **/
extern int32a fp_br_entry_del_ports(uint32a vlanId, uint32a portList);

/*!
 Configure static port initialization information.

 @param wsp_base_addr  base address of the WSP registers
 @param mac char pointer
 @param vlanId          [0 - 4093]
 @param fwd_ports       Max 8 ports [0-0xFF], bit mapped to port from rt to lt
 @param hit_action      [0 - 6]
 @param tc              [0 - 7]
 @return status code   0=success, -1=failure
 **/
int32a fp_static_mac_entry_add(	uint8 *mac,
				uint32a  vlanid,
				uint32a  fwd_ports,
				uint32a  hit_action,
				uint32a  tc);

/*!
 Configure port initialization information.

 @param *dev char pointer
 @return int
 **/
extern int32a fp_mac_entry_add(uint32a phy_port, uint8 *mac, uint32a vlanid);

/*!
 Adds MAC entry into mac hash table

 @param wsp_base_addr base address of the WSP registers
 @param vlanId          [0 - 4093]
 @param phy_port          [0 - 1]
 @param mac               [0 - 255]
 @return status code 0=success, -1=failure
**/
extern int32a fp_mac_entry_del(uint8 *mac, uint32a vlanid);
/*!
 Delete MAC entry from mac hash table

 @param wsp_base_addr base address of the WSP registers
 @param vlanId          [0 - 4093]
 @param mac               [0 - 255]
 @return status code 0=success, -1=failure
**/

extern int32a fp_mac_entry_search(uint8 *mac, uint32a vlanid);
/*!
 Search MAC entry from mac hash table

 @param wsp_base_addr base address of the WSP registers
 @param vlanId          [0 - 4093]
 @param mac               [0 - 255]
 @return status code 0=success, -1=failure
**/

extern int32a fp_mac_entry_update(uint32a mac_entry, uint8 *mac, uint32a  vlanid);
/*!
 Update MAC entry from mac hash table

 @param wsp_base_addr base address of the WSP registers
 @param vlanId          [0 - 4093]
 @param mac               [0 - 255]
 @param mac_entry               [0 - 4093]
 @return status code 0=success, -1=failure
**/

extern uint32a fp_ltc_gettime(uint8 dev_number, uint8 ch_num);
/*!
 Getting ltc time difference between channel head

 @param wsp_base_addr base address of the WSP registers
 @param dev_number	[0-3]
 @param ch_num		[0-7]
 @return time diffvalue of time
**/

extern int32a fp_ltc_hif_config_time(uint32a devId, uint32a value, uint32a type);
/*!
 Config ltc time seconds and nano seconds

 @param devId          [0 - 3]
 @param value          [uint32a min to max value]
 @param type           [1 - 2]
 @return status code 0=success, -1=failure
**/

void fp_portcfg_init(uint8 *dev);

#endif /*End of _FP_HW_SW_API_H_ */

