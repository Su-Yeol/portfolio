/**
 * @file MRVL_Q222X_Copyright_and_Version.h
 * @brief Q222X API Copyright, License and Version Identifier File
 *
 * @copyright
 * Copyright (c) 2023 Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement by and between
 * Marvell and you, your employer or other entity on behalf of whom you act.
 * In the absence of such license agreement the following file is subject to
 * Marvell’s standard Limited Use License Agreement.
 *
 */

#ifndef MRVL_Q222X_COPYRIGHT_VERSION_H
#define MRVL_Q222X_COPYRIGHT_VERSION_H

#define MARVL_Q222X_API_VERSION "0.4.00"
#define MARVL_Q222X_API_DATE "9/22/2023"

#endif
