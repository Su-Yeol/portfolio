#ifndef MRVL_Q222X_API_H__
#define MRVL_Q222X_API_H__

#include "MRVL_APHY_Device.h"

MRVL_APHY_STATUS Sample_Code_Init_FixedSpeed(MRVL_DEV_PTR DUT);
MRVL_APHY_STATUS Sample_Code_Init_Autoneg(MRVL_DEV_PTR DUT);

#endif // MRVL_Q222X_API_H__
