// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
 * @File
 * @Title        fp_hash.c
 * @Copyright    Copyright (c) Imagination Technologies Ltd. All Rights Reserved
 * @Description  5 tuple hash calculation
 * @License      Dual MIT/GPLv2
 *
 * The contents of this file are subject to the MIT license as set out below.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * the GNU General Public License Version 2 ("GPL") in which case the provisions
 * of GPL are applicable instead of those above.
 *
 * If you wish to allow use of your version of this file only under the terms of
 * GPL, and not to allow others to use your version of this file under the terms
 * of the MIT license, indicate your decision by deleting the provisions above
 * and replace them with the notice and other provisions required by GPL as set
 * out in the file called "GPL-COPYING" included in this distribution. If you do
 * not delete the provisions above,a recipient may use your version of this file
 * under the terms of either the MIT license or GPL.
 *
 * This License is also included in this distribution in the file called
 * "MIT-COPYING".
 *
 * EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 * PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");
/**********************************************************************
 *                                     Include Files
 **********************************************************************/
#include "fp_library.h"
#include "fp_router.h"

#ifdef __FP_OS__
#include <linux/module.h>
#endif

#ifdef ASYM_HASH_EN
#define CRCPOLY_BE 0x04c11db7
#endif

#ifdef ASYM_HASH_EN
/**********************************************************************
 * Function Name  : crc32_be
 * Description    : Helper routine to caclculate crc32 in Bigendian
 * Inputs
 *   Parameters   : crc, data, length
 * Outputs        :
 *   Parameters   : crc32 bit value
 *   Returns      : -
 * Changes        :
 *********************************************************************/
uint32a crc32_be(uint32a crc, uint8 *data, uint16 len)
{
	int32a i;

	while (len--) {
		crc ^= *data++ << 24;
		for (i = 0; i < 8; i++)
			crc =
				(crc << 1) ^ ((crc & 0x80000000) ? CRCPOLY_BE :
				0);
	}
	return crc;
}
#endif
/**********************************************************************
 * Function Name  : hash5Tuple
 * Description    : To calculate hash value from 5tuple for ipv4 packets.
 * Inputs
 *   Parameters   : struct cacheFlow *, u16
 * Outputs        :
 *   Parameters   : -
 *   Returns      : int
 * Changes        :
 *********************************************************************/
int32a hash5Tuple(struct cacheFlow *in_cacheFlow, uint16 hashMask)
{
#if ((!defined HW_PARSE_EN) && (!defined HW_FETCH_EN))
	uint32a temp = 0;
#ifdef ASYM_HASH_EN
	uint32a crc = 0xffffffff;
	uint32a sport = 0;
#endif

#ifdef DEBUG_HW
	FPATH_TRACE(FP_TRACE_ROUTING, FP_LOG_DEBUG,
		("SrcIP = %x, DstIP = %x, Srcport = %x, DstPort = %x\r\n",
		(in_cacheFlow->srcIP),
		(in_cacheFlow->dstIP),
		in_cacheFlow->flowSpecific.layer4Info.srcPort,
		in_cacheFlow->flowSpecific.layer4Info.dstPort));

#endif

	/* covert the 5-tuple host byte order to network byte-order */
#if defined(ASYM_HASH_SIP_EN)
	temp = crc32_be(crc, (uint8 *)&in_cacheFlow->u.v4.srcIP, 4);
	temp += htonl(in_cacheFlow->u.v4.dstIP);
	temp += in_cacheFlow->Proto;
	temp += htons(in_cacheFlow->srcPort);
	temp += htons(in_cacheFlow->dstPort);
#elif defined(ASYM_HASH_SPORT_EN)
	sport = fp_ntohl(0xffff & htons(in_cacheFlow->srcPort));
	temp = crc32_be(crc, (uint8 *)&sport, 4);
	temp += htonl(in_cacheFlow->u.v4.srcIP);
	temp += htonl(in_cacheFlow->u.v4.dstIP);
	temp += in_cacheFlow->Proto;
	temp += htons(in_cacheFlow->dstPort);
#elif defined(ASYM_HASH_SIP_SPORT_EN)
	sport = in_cacheFlow->u.v4.srcIP ^
		(htonl(htons(in_cacheFlow->srcPort)));
	temp = crc32_be(crc, (uint8 *)&sport, 4);
	temp += htonl(in_cacheFlow->u.v4.dstIP);
	temp += in_cacheFlow->Proto;
	temp += htons(in_cacheFlow->dstPort);
#else
	temp = htonl(in_cacheFlow->u.v4.srcIP);
	temp += htonl(in_cacheFlow->u.v4.dstIP);
	temp += in_cacheFlow->Proto;
	temp += htons(in_cacheFlow->srcPort);
	temp += htons(in_cacheFlow->dstPort);
#endif
#ifdef CSR_PHYNO_EN
	temp += in_cacheFlow->inPhyPortNum;
#endif
	FPATH_TRACE(FP_TRACE_ROUTING, FP_LOG_DEBUG, (" TUPLE-SUM:%x\n", temp));
	return (temp & hashMask);
#endif
	return 0;
}

/************************************************************************
 * Function Name  : fp_ether_mactohash
 * Description    : calculate hash value for given mac address
 * Inputs
 *   Parameters   : u8 *, u16, u16
 * Outputs        :
 *   Parameters   : -
 *   Returns      : u16
 * Changes        :
 ************************************************************************/
uint16 fp_ether_mactohash(uint8 *mac_address, uint16 vLan, uint16 hashMask)
{
	uint16 usarrTemp[3], usRetvalue = 0, usTempValue = 0;
	uint16 *usHashvalue = (uint16 *)mac_address;

	/* change byte order */
	usTempValue  = usHashvalue[0];
	usarrTemp[0] = ntohs(usTempValue);
	usTempValue  = usHashvalue[1];
	usarrTemp[1] = ntohs(usTempValue);
	usTempValue  =  usHashvalue[2];
	usarrTemp[2] = ntohs(usTempValue);

	/* calculate hash value using XOR */
	usRetvalue = (((usarrTemp[0] ^ usarrTemp[1]) ^ usarrTemp[2]) ^ vLan);

	/* return hash value */
	return (usRetvalue & hashMask);
}

/**********************************************************************
 * Function Name  : ipv6_hash5Tuple
 * Description    : To calculate hash value from 5tuple for ipv6 packets.
 * Inputs
 *   Parameters   : struct cacheFlow *, u16
 * Outputs        :
 *   Parameters   : -
 *   Returns      : int
 * Changes        :
 *********************************************************************/
int32a ipv6_hash5Tuple(struct cacheFlow *in_cacheFlow, uint16 hashMask)
{
#if ((!defined HW_PARSE_EN) && (!defined HW_FETCH_EN))
	uint32 temp = 0;
#ifdef ASYM_HASH_EN
	uint32a sport = 0;
	uint32a  j = 0, crc = 0xffffffff;
#endif

#if defined(ASYM_HASH_SIP_EN)  || defined(ASYM_HASH_SIP_SPORT_EN)
	uint32a crc_ipv6 = 0;

	for (j = 0; j < 4 ; j++)
		crc_ipv6 += (in_cacheFlow->u.v6.src_ipv6[j]);
#endif

#if defined(ASYM_HASH_SIP_EN)
	temp = crc32_be(crc, (uint8 *)&crc_ipv6, 4);
	temp += htonl(in_cacheFlow->u.v6.dst_ipv6[0]);
	temp += htonl(in_cacheFlow->u.v6.dst_ipv6[1]);
	temp += htonl(in_cacheFlow->u.v6.dst_ipv6[2]);
	temp += htonl(in_cacheFlow->u.v6.dst_ipv6[3]);
	temp += in_cacheFlow->Proto;
	temp += htons(in_cacheFlow->srcPort);
	temp += htons(in_cacheFlow->dstPort);
#elif defined(ASYM_HASH_SPORT_EN)
	sport = fp_ntohl(0xffff & htons(in_cacheFlow->srcPort));
	temp = crc32_be(crc, (uint8 *)&sport, 4);
	temp += htonl(in_cacheFlow->u.v6.src_ipv6[0]);
	temp += htonl(in_cacheFlow->u.v6.src_ipv6[1]);
	temp += htonl(in_cacheFlow->u.v6.src_ipv6[2]);
	temp += htonl(in_cacheFlow->u.v6.src_ipv6[3]);
	temp += htonl(in_cacheFlow->u.v6.dst_ipv6[0]);
	temp += htonl(in_cacheFlow->u.v6.dst_ipv6[1]);
	temp += htonl(in_cacheFlow->u.v6.dst_ipv6[2]);
	temp += htonl(in_cacheFlow->u.v6.dst_ipv6[3]);
	temp += in_cacheFlow->Proto;
	temp += htons(in_cacheFlow->dstPort);
#elif defined(ASYM_HASH_SIP_SPORT_EN)
	sport = crc_ipv6 ^ (htonl(htons(in_cacheFlow->srcPort)));
	temp = crc32_be(crc, (uint8 *)&sport, 4);
	temp += htonl(in_cacheFlow->u.v6.dst_ipv6[0]);
	temp += htonl(in_cacheFlow->u.v6.dst_ipv6[1]);
	temp += htonl(in_cacheFlow->u.v6.dst_ipv6[2]);
	temp += htonl(in_cacheFlow->u.v6.dst_ipv6[3]);
	temp += in_cacheFlow->Proto;
	temp += htons(in_cacheFlow->dstPort);
#else
	temp = htonl(in_cacheFlow->u.v6.src_ipv6[0]);
	temp += htonl(in_cacheFlow->u.v6.src_ipv6[1]);
	temp += htonl(in_cacheFlow->u.v6.src_ipv6[2]);
	temp += htonl(in_cacheFlow->u.v6.src_ipv6[3]);
	temp += htonl(in_cacheFlow->u.v6.dst_ipv6[0]);
	temp += htonl(in_cacheFlow->u.v6.dst_ipv6[1]);
	temp += htonl(in_cacheFlow->u.v6.dst_ipv6[2]);
	temp += htonl(in_cacheFlow->u.v6.dst_ipv6[3]);
	temp += in_cacheFlow->Proto;
	temp += htons(in_cacheFlow->srcPort);
	temp += htons(in_cacheFlow->dstPort);
#endif

#ifdef CSR_PHYNO_EN
	temp += in_cacheFlow->inPhyPortNum;
#endif
	return (temp & hashMask);
#endif
	return 0;
}

