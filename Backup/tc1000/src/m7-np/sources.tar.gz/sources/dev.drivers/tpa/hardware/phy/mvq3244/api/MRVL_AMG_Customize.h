/**
 * @file MRVL_AMG_Customize.h
 * @brief Customizable header file
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */

#ifndef MRVL_AMG_CUST_H
#define MRVL_AMG_CUST_H

#include "MRVL_AMG_Device.h"


#define MRVL_AMG_DEBUG /* comment out to remove all print code/data */

#ifdef MRVL_AMG_DEBUG
#include <stdio.h>
#include <stdarg.h>
#include "debug.h"

/**
 * @brief Define the debug print level
 * 
 */
typedef enum
{
    MRVL_AMG_DBG_OFF_LVL,   /*!< turn off all printing */
    MRVL_AMG_DBG_ERR_LVL,   /*!< print only errors */
    MRVL_AMG_DBG_WARN_LVL,  /*!< print errors and warnings */
    MRVL_AMG_DBG_INF_LVL,   /*!< print errors, warnings and general information */
    MRVL_AMG_DBG_CMD_LVL,   /*!< print more, including command related message */
    MRVL_AMG_DBG_ALL_LVL    /*!< print all messages */
} MRVL_AMG_DBG_LEVEL;

#if 0
void mAMGphyDbgPrint(FILE* stream, MRVL_AMG_DBG_LEVEL debug_level, const char* format, ...);

#define MRVL_AMG_DBG_ERROR(...)         mAMGphyDbgPrint(stderr, MRVL_AMG_DBG_ERR_LVL, __VA_ARGS__)  /* macro for error messages */
#define MRVL_AMG_DBG_WARNING(...)       mAMGphyDbgPrint(stdout, MRVL_AMG_DBG_WARN_LVL, __VA_ARGS__) /* macro for warning messages */
#define MRVL_AMG_DBG_INFO(...)          mAMGphyDbgPrint(stdout, MRVL_AMG_DBG_INF_LVL, __VA_ARGS__)  /* macro for informational messages */
#define MRVL_AMG_DBG_CMD(...)           mAMGphyDbgPrint(stdout, MRVL_AMG_DBG_CMD_LVL, __VA_ARGS__)  /* macro for command related  messages */
#define MRVL_AMG_DBG_ALL(...)           mAMGphyDbgPrint(stdout, MRVL_AMG_DBG_ALL_LVL, __VA_ARGS__)  /* macro for all messages */
#else
extern MRVL_AMG_DBG_LEVEL MRVL_AMG_debug_level_global;

#define MRVL_AMG_DBG(level, ...) \
	if (level != MRVL_AMG_DBG_OFF_LVL) { \
		if (level <= MRVL_AMG_debug_level_global) { \
			mcu_printf(__VA_ARGS__); \
		} \
	}

#define MRVL_AMG_DBG_ERROR(...)         MRVL_AMG_DBG(MRVL_AMG_DBG_ERR_LVL, __VA_ARGS__)  /* macro for error messages */
#define MRVL_AMG_DBG_WARNING(...)       MRVL_AMG_DBG(MRVL_AMG_DBG_WARN_LVL, __VA_ARGS__) /* macro for warning messages */
#define MRVL_AMG_DBG_INFO(...)          MRVL_AMG_DBG(MRVL_AMG_DBG_INF_LVL, __VA_ARGS__)  /* macro for informational messages */
#define MRVL_AMG_DBG_CMD(...)           MRVL_AMG_DBG(MRVL_AMG_DBG_CMD_LVL, __VA_ARGS__)  /* macro for command related  messages */
#define MRVL_AMG_DBG_ALL(...)           MRVL_AMG_DBG(MRVL_AMG_DBG_ALL_LVL, __VA_ARGS__)  /* macro for all messages */
#endif

#else /* MRVL_AMG_DEBUG not defined */

#define MRVL_AMG_DBG_ERROR(...)
#define MRVL_AMG_DBG_WARNING(...)
#define MRVL_AMG_DBG_INFO(...)
#define MRVL_AMG_DBG_CMD(...)
#define MRVL_AMG_DBG_ALL(...)

#endif

#if 0
extern MRVL_APHY_BOOL MRVL_AMG_FLASH_BYPASS_CHECK;

#define MRVL_CLOCKS_PER_SEC  1000 /* use 1000 as default, change it in cust environment */
#endif

/** @defgroup Customize_Lib Customizable Utility Functions */

/******************************************************************************
 *      customizable Hardware Interface functions
 ******************************************************************************/
/** @defgroup Customize_Lib_HWI Customizable HW Interface Functions
 * @ingroup Customize_Lib
 */

MRVL_APHY_STATUS MRVL_AMG_ReadReg16_IMP(MRVL_DEV_PTR device, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16* regVal);

MRVL_APHY_STATUS MRVL_AMG_WriteReg16_IMP(MRVL_DEV_PTR device, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16 regVal);

MRVL_APHY_STATUS MRVL_AMG_ReadReg32_IMP(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U32* regVal);

MRVL_APHY_STATUS MRVL_AMG_WriteReg32_IMP(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U32 regVal);

MRVL_APHY_STATUS MRVL_AMG_Wait_IMP(MRVL_DEV_PTR device, MRVL_APHY_U16 waitTime);

#if 0
/******************************************************************************
 *      customizable std utility functions
 ******************************************************************************/
/** @defgroup Customize_Lib_STD Customizable Utility Functions Called in Codes
 * @ingroup Customize_Lib
 */
extern MRVL_AMG_DBG_LEVEL MRVL_AMG_debug_level_global;

void MRVL_AMG_Clock(MRVL_APHY_U32* curTime);

void MRVL_AMG_Time(double* curTime);

FILE* MRVL_AMG_FileOpen(const char* filename);

void MRVL_AMG_FileClose(FILE* filePtr);

void MRVL_AMG_PrintToFile(FILE* filePtr, char* toPrint);

void* MRVL_AMG_MemoryAllocation(MRVL_APHY_U32 size);

void MRVL_AMG_FreeMemory(void* allocated);

void MRVL_AMG_StringCat(char* buffer, const char* str);

void MRVL_AMG_UintToString(char* buffer, MRVL_APHY_U32 number);

void MRVL_AMG_FloatToString(char* buffer, double number);

MRVL_APHY_DOUBLE MRVL_AMG_Pow(MRVL_APHY_DOUBLE X, MRVL_APHY_DOUBLE Y);
#endif
#endif
