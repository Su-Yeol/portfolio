/*
 * fp_pci_pe.h - Function calls for PE intialisation
 *
 * Copyright (c) 2007-2009, Naksha Technologies, Inc.
 * Copyright (c) 2010-2012, Posedge Technologies, Inc.
 * Copyright (c) 2013-2020, Imagination Technologies Ltd.
 * All rights reserved.
 */

#ifndef _FP_PCI_PE_H_
#define _FP_PCI_PE_H_

extern void fp_pci_ddr_tbl_init(uint8 *);
extern uint8 fp_pci_write_PE(uint16 offset, uint16 len, uint8 *pData, uint8 type);
extern uint8 *fp_pci_malloc(uint32a, uint32a);
extern int8 fp_pci_free(int8 *, uint8);
extern int8 *getIfBasePtr(void);

#endif /*End of _FP_PCI_PE_H_ File*/




