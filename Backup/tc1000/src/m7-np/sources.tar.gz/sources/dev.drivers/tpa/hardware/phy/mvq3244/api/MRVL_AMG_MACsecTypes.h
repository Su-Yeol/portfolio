/**
 * @file MRVL_AMG_MACsecTypes.h
 * @brief Marvell Multi-gig Automotive Ethernet PHY MAC and MACsec Types and Defines
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */
#ifndef MRVL_AMG_MCS_TYPES_H
#define MRVL_AMG_MCS_TYPES_H

#include "MRVL_AMG_Types.h"

#define MRVL_AMG_MCS_ETHTYPE 0x88E5
#define MRVL_AMG_MCS_SAK_LEN 32
#define MRVL_AMG_MCS_HASHKEY_LEN 16
#define MRVL_AMG_MCS_SALTKEY_LEN 12
#define MRVL_AMG_MCS_MAC_ADDR_LEN 6
#define MRVL_AMG_MCS_NUM_AN 4

/* capability */
#define MRVL_AMG_MCS_MAX_SECY_MAP_NUM 4						  
#define MRVL_AMG_MCS_MAX_SECY_NUM 4
#define MRVL_AMG_MCS_MAX_RULE_NUM 4
#define MRVL_AMG_MCS_MAX_SC_NUM 4
#define MRVL_AMG_MCS_MAX_SA_NUM 8
#define MRVL_AMG_MCS_MAX_CUSTOM_TAG_NUM 8
#define MRVL_AMG_MCS_MAX_CTRL_PCKT_ETYPE_NUM 8
#define MRVL_AMG_MCS_MAX_CTRL_PCKT_DA_NUM 8
#define MRVL_AMG_MCS_MAX_CTRL_PCKT_DA_RANGE_NUM 4
#define MRVL_AMG_MCS_MAX_CTRL_PCKT_COMBO_NUM 4

/* channel shift */
#define MRVL_AMG_MCS_RANGE4 8U
#define MRVL_AMG_MCS_RANGE8 16U
#define MRVL_AMG_MCS_RANGE16 32U
#define MRVL_AMG_MCS_RANGE32 64U
#define MRVL_AMG_MCS_RANGE64 128U
#define MRVL_AMG_MCS_RANGE128 256U
#define MRVL_AMG_MCS_RANGE256 512U
#define MRVL_AMG_MCS_REG_BUS_WIDTH 8U

/* Register Address*/
#define MRVL_AMG_MCS_RST_RX_CTRL 0x407C2318U
#define MRVL_AMG_MCS_RST_TX_CTRL 0x407C231CU
#define MRVL_AMG_MCS_RST_MASTER_CTRL 0x407C2300U
#define MRVL_AMG_MCS_VERSION 0x407C8C20U
#define MRVL_AMG_MCS_CLK 0x407C2104U
#define MRVL_AMG_MCS_SLICE_CTRL 0x407C4000U
#define MRVL_AMG_MCS_SLICE_MIB_CTRL_CLR_CAP 0x407C40A4U

#define MRVL_AMG_MCS_PEX_RX_SLAVE 0x407C8400U
#define MRVL_AMG_MCS_PEX_TX_SLAVE 0x407C87A0U

#define MRVL_AMG_MCS_PEX_RX_SLAVE_CUSTOM_TAG 0x407C8428U
#define MRVL_AMG_MCS_PEX_RX_ETYPE_ENABLE 0x407C8778U

#define MRVL_AMG_MCS_PEX_TX_SLAVE_CUSTOM_TAG 0x407C87C8U
#define MRVL_AMG_MCS_PEX_TX_ETYPE_ENABLE 0x407C8B18U

#define MRVL_AMG_MCS_TX_FLOWID_TCAM_ENABLE 0x407CA1F0U
#define MRVL_AMG_MCS_TX_FLOWID_TCAM_DATA 0x407CA230U
#define MRVL_AMG_MCS_TX_FLOWID_TCAM_MASK 0x407CA330U
#define MRVL_AMG_MCS_TX_SECY_MAP_MEM 0x407C9810U
#define MRVL_AMG_MCS_TX_SECY_PLCY_MEM 0x407C9890U 
#define MRVL_AMG_MCS_TX_SA_MAP_MEM 0x407C9930U 
#define MRVL_AMG_MCS_TX_SA_ACTIVE 0x407C98D0U
#define MRVL_AMG_MCS_TX_SA_INDEX0_VLD 0x407C98F0U 
#define MRVL_AMG_MCS_TX_SA_INDEX1_VLD 0x407C9910U
#define MRVL_AMG_MCS_TX_AUTO_REKEY 0x407C97D0U
#define MRVL_AMG_MCS_TX_SA_PLCY_MEM 0x407C9970U 
#define MRVL_AMG_MCS_TX_SA_PN_TABLE_MEM 0x407CA170U 
#define MRVL_AMG_MCS_TX_PN_THRESHOLD 0x407C97F0U
#define MRVL_AMG_MCS_TX_XPN_THRESHOLD 0x407C97E0U

#define MRVL_AMG_MCS_TX_PREEMPT_EARLY 0x407C8780U

#define MRVL_AMG_MCS_RX_FLOWID_TCAM_ENABLE 0x407C9390U
#define MRVL_AMG_MCS_RX_FLOWID_TCAM_DATA 0x407C93D0U 
#define MRVL_AMG_MCS_RX_FLOWID_TCAM_MASK 0x407C94D0U
#define MRVL_AMG_MCS_RX_SECY_MAP_MEM 0x407C8D70U
#define MRVL_AMG_MCS_RX_SECY_PLCY_MEM 0x407C8DB0U 
#define MRVL_AMG_MCS_RX_SC_CAM 0x407C95F0U
#define MRVL_AMG_MCS_RX_SA_MAP_MEM 0x407C8DF0U 
#define MRVL_AMG_MCS_RX_SA_PLCY_MEM 0x407C8F10U 
#define MRVL_AMG_MCS_RX_SA_PN_TABLE_MEM 0x407C9310U
#define MRVL_AMG_MCS_RX_PN_THRESHOLD 0x407C8D40U
#define MRVL_AMG_MCS_RX_XPN_THRESHOLD 0x407C8D30U
#define MRVL_AMG_MCS_RX_DEFAULT_SCI 0x407C8D20U
#define MRVL_AMG_MCS_RX_SC_CAM_ENABLE 0x407C95D0U

#define MRVL_AMG_MCS_RX_PREEMPT_EARLY 0x407C8B20U

#define MRVL_AMG_MCS_PORT_CONFIG_PARSE 0x407C8C30U
#define MRVL_AMG_MCS_DATAPATH_BYPASS 0x407C2780U
#define MRVL_AMG_MCS_CHANNEL_BYPASS 0x407C8C38U
#define MRVL_AMG_MCS_CSE_RX_STATS_CLEAR 0x407C8BA0U
#define MRVL_AMG_MCS_CSE_TX_STATS_CLEAR 0x407C8C10U
#define MRVL_AMG_MCS_CSE_CLR_ON_RD_RX 0x407C8B78U
#define MRVL_AMG_MCS_CSE_CLR_ON_RD_Tx 0x407C8BE8U
#define MRVL_AMG_MCS_MCS_VLAN_TAG_REL_OFFSET 0x407C8808U

#define MRVL_AMG_MCS_CTRL_PCKT_RULE_ETYPE_OFFSET 0xA0U
#define MRVL_AMG_MCS_CTRL_PCKT_RULE_DA_OFFSET 0xE0U
#define MRVL_AMG_MCS_CTRL_PCKT_RULE_DA_RANGE_OFFSET 0x160U
#define MRVL_AMG_MCS_CTRL_PCKT_RULE_COMBO_OFFSET 0x240U
#define MRVL_AMG_MCS_CTRL_PCKT_RULE_ENABLE_OFFSET 0x370U

#define MRVL_AMG_MCS_IN_OCETS_SECY_DECRYPTED 0x407CA900U
#define MRVL_AMG_MCS_IN_OCETS_SECY_VALIDATE 0x407CA8C0U
#define MRVL_AMG_MCS_IN_PKTS_SECY_NO_SA 0x407CA840U
#define MRVL_AMG_MCS_IN_PKTS_SECY_NO_SA_ERROR 0x407CA880U
#define MRVL_AMG_MCS_IN_PKTS_SECY_BAD_TAG 0x407CA800U
#define MRVL_AMG_MCS_IN_PKTS_SECY_NO_TAG 0x407CA7C0U
#define MRVL_AMG_MCS_IN_PKTS_SECY_UNTAGGED 0x407CA780U
#define MRVL_AMG_MCS_IN_PKTS_CTRL_PORT_DISABLE 0x407CA740U
#define MRVL_AMG_MCS_IN_CTRL_PORT_OCETS 0x407CA500U
#define MRVL_AMG_MCS_IN_CTRL_PORT_UC_PKTS 0x407CA540U
#define MRVL_AMG_MCS_IN_CTRL_PORT_MC_PKTS 0x407CA580U
#define MRVL_AMG_MCS_IN_CTRL_PORT_BC_PKTS 0x407CA5C0U
#define MRVL_AMG_MCS_IN_UNCTRL_PORT_OCETS 0x407CA600U
#define MRVL_AMG_MCS_IN_UNCTRL_PORT_UC_PKTS 0x407CA640U
#define MRVL_AMG_MCS_IN_UNCTRL_PORT_MC_PKTS 0x407CA680U
#define MRVL_AMG_MCS_IN_UNCTRL_PORT_BC_PKTS 0x407CA6C0U

#define MRVL_AMG_MCS_OUT_PKTS_CTRL_PORT_DISABLE 0x407CAD70U
#define MRVL_AMG_MCS_OUT_PKTS_SECY_UNTAGGED 0x407CADB0U
#define MRVL_AMG_MCS_OUT_PKTS_SECY_NO_ACTIVE_SA 0x407CADF0U
#define MRVL_AMG_MCS_OUT_PKTS_SECY_TOO_LONG 0x407CAE30U
#define MRVL_AMG_MCS_OUT_OCETS_SECY_PROTECTED 0x407CAE70U
#define MRVL_AMG_MCS_OUT_OCETS_SECY_ENCRYPTED 0x407CAEB0U
#define MRVL_AMG_MCS_OUT_CTRL_PORT_OCETS 0x407CAB70U
#define MRVL_AMG_MCS_OUT_CTRL_PORT_UC_PKTS 0x407CABB0U
#define MRVL_AMG_MCS_OUT_CTRL_PORT_MC_PKTS 0x407CABF0U
#define MRVL_AMG_MCS_OUT_CTRL_PORT_BC_PKTS 0x407CAC30U
#define MRVL_AMG_MCS_OUT_UNCTRL_PORT_OCETS 0x407CAC70U
#define MRVL_AMG_MCS_OUT_UNCTRL_PORT_UC_PKTS 0x407CACB0U
#define MRVL_AMG_MCS_OUT_UNCTRL_PORT_MC_PKTS 0x407CACF0U
#define MRVL_AMG_MCS_OUT_UNCTRL_PORT_BC_PKTS 0x407CAD30U

#define MRVL_AMG_MCS_IN_PKTS_SC_CAM_HIT 0x407CA940U
#define MRVL_AMG_MCS_IN_PKTS_SC_LATE 0x407CA980U
#define MRVL_AMG_MCS_IN_PKTS_SC_NOT_VALID 0x407CA9C0U
#define MRVL_AMG_MCS_IN_PKTS_SC_INVALID 0x407CAA00U
#define MRVL_AMG_MCS_IN_PKTS_SC_DELAYED 0x407CAA40U
#define MRVL_AMG_MCS_IN_PKTS_SC_UNCHECKED 0x407CAA80U
#define MRVL_AMG_MCS_IN_PKTS_SC_OK 0x407CAAC0U

#define MRVL_AMG_MCS_OUT_PKTS_PROTECTED 0x407CAEF0U
#define MRVL_AMG_MCS_OUT_PKTS_ENCRYPTED 0x407CAF30U

#define MRVL_AMG_MCS_IN_PKTS_PARSE_ERR 0x407CAB00U
#define MRVL_AMG_MCS_IN_PKTS_FLOW_ID_TCAM_MISS 0x407CAB10U
#define MRVL_AMG_MCS_IN_PKTS_EARLY_PREEMPT_ERR 0x407CAB20U
#define MRVL_AMG_MCS_IN_PKTS_FLOW_ID_TCAM_HIT_0 0x407CAB30U
#define MRVL_AMG_MCS_IN_PKTS_FLOW_ID_TCAM_HIT_1 0x407CAB40U
#define MRVL_AMG_MCS_IN_PKTS_FLOW_ID_TCAM_HIT_2 0x407CAB50U
#define MRVL_AMG_MCS_IN_PKTS_FLOW_ID_TCAM_HIT_3 0x407CAB60U
	
#define MRVL_AMG_MCS_OUT_PKTS_PARSE_ERR 0x407CAF70U
#define MRVL_AMG_MCS_OUT_PKTS_FLOW_ID_TCAM_MISS 0x407CAF80U
#define MRVL_AMG_MCS_OUT_PKTS_EARLY_PREEMPT_ERR 0x407CAF90U
#define MRVL_AMG_MCS_OUT_PKTS_FLOW_ID_TCAM_HIT_0 0x407CAFA0U
#define MRVL_AMG_MCS_OUT_PKTS_FLOW_ID_TCAM_HIT_1 0x407CAFB0U
#define MRVL_AMG_MCS_OUT_PKTS_FLOW_ID_TCAM_HIT_2 0x407CAFC0U
#define MRVL_AMG_MCS_OUT_PKTS_FLOW_ID_TCAM_HIT_3 0x407CAFD0U


/* SMAC, WMAC MIB */
#define MRVL_AMG_MAC_SMAC_RX_STATS_GOODOCTETS 0x407D0000U
#define MRVL_AMG_MAC_SMAC_RX_STATS_ERROROCTETS 0x407D0010U
#define MRVL_AMG_MAC_SMAC_RX_STATS_JABBER 0x407D0020U
#define MRVL_AMG_MAC_SMAC_RX_STATS_FRAGMENT 0x407D0030U
#define MRVL_AMG_MAC_SMAC_RX_STATS_UNDERSIZE 0x407D0040U
#define MRVL_AMG_MAC_SMAC_RX_STATS_OVERSIZE 0x407D0050U
#define MRVL_AMG_MAC_SMAC_RX_STATS_RXERROR 0x407D0060U
#define MRVL_AMG_MAC_SMAC_RX_STATS_CRCERR_TXUNDERRUN 0x407D0070U
#define MRVL_AMG_MAC_SMAC_RX_STATS_RXOVERRUN_BADFC 0x407D0080U
#define MRVL_AMG_MAC_SMAC_RX_STATS_GOODPKTS 0x407D0090U
#define MRVL_AMG_MAC_SMAC_RX_STATS_FCPKT 0x407D00A0U
#define MRVL_AMG_MAC_SMAC_RX_STATS_BROADCAST 0x407D00B0U
#define MRVL_AMG_MAC_SMAC_RX_STATS_MULTICAST 0x407D00C0U
#define MRVL_AMG_MAC_SMAC_RX_STATS_INPASSEMBLYERR 0x407D00D0U
#define MRVL_AMG_MAC_SMAC_RX_STATS_INPFRAMES 0x407D00E0U
#define MRVL_AMG_MAC_SMAC_RX_STATS_INPFRAGS 0x407D00F0U
#define MRVL_AMG_MAC_SMAC_RX_STATS_INPBADFRAGS 0x407D0100U

#define MRVL_AMG_MAC_SMAC_TX_STATS_GOODOCTETS 0x407D1000U
#define MRVL_AMG_MAC_SMAC_TX_STATS_ERROROCTETS 0x407D1010U
#define MRVL_AMG_MAC_SMAC_TX_STATS_JABBER 0x407D1020U
#define MRVL_AMG_MAC_SMAC_TX_STATS_FRAGMENT 0x407D1030U
#define MRVL_AMG_MAC_SMAC_TX_STATS_UNDERSIZE 0x407D1040U
#define MRVL_AMG_MAC_SMAC_TX_STATS_OVERSIZE 0x407D1050U
#define MRVL_AMG_MAC_SMAC_TX_STATS_RXERROR 0x407D1060U
#define MRVL_AMG_MAC_SMAC_TX_STATS_CRCERR_TXUNDERRUN 0x407D1070U
#define MRVL_AMG_MAC_SMAC_TX_STATS_RXOVERRUN_BADFC 0x407D1080U
#define MRVL_AMG_MAC_SMAC_TX_STATS_GOODPKTS 0x407D1090U
#define MRVL_AMG_MAC_SMAC_TX_STATS_FCPKT 0x407D10A0U
#define MRVL_AMG_MAC_SMAC_TX_STATS_BROADCAST 0x407D10B0U
#define MRVL_AMG_MAC_SMAC_TX_STATS_MULTICAST 0x407D10C0U
#define MRVL_AMG_MAC_SMAC_TX_STATS_OUTPFRAGS 0x407D10E0U
#define MRVL_AMG_MAC_SMAC_TX_STATS_OUTPFRAMES 0x407D10F0U

#define MRVL_AMG_MAC_WMAC_RX_STATS_PKTS 0x407D0310U
#define MRVL_AMG_MAC_WMAC_RX_STATS_DROPPEDPKTS 0x407D0320U
#define MRVL_AMG_MAC_WMAC_RX_STATS_OCTETS 0x407D0330U
#define MRVL_AMG_MAC_WMAC_RX_STATS_JABBER 0x407D0340U
#define MRVL_AMG_MAC_WMAC_RX_STATS_FRAGMENT 0x407D0350U
#define MRVL_AMG_MAC_WMAC_RX_STATS_UNDERSIZE 0x407D0360U
#define MRVL_AMG_MAC_WMAC_RX_STATS_RXERROR 0x407D0370U
#define MRVL_AMG_MAC_WMAC_RX_STATS_CRCERROR 0x407D0380U
#define MRVL_AMG_MAC_WMAC_RX_STATS_FCPKTS 0x407D0390U
#define MRVL_AMG_MAC_WMAC_RX_STATS_BROADCASTPKTS 0x407D03A0U
#define MRVL_AMG_MAC_WMAC_RX_STATS_MULTICASTPKTS 0x407D03B0U
#define MRVL_AMG_MAC_WMAC_RX_STATS_INPASSEMBLYERR 0x407D0480U
#define MRVL_AMG_MAC_WMAC_RX_STATS_INPFRAMES 0x407D0490U
#define MRVL_AMG_MAC_WMAC_RX_STATS_INPFRAGS 0x407D04A0U
#define MRVL_AMG_MAC_WMAC_RX_STATS_INPBADFRAGS 0x407D04B0U

#define MRVL_AMG_MAC_WMAC_TX_STATS_PKTS 0x407D1310U
#define MRVL_AMG_MAC_WMAC_TX_STATS_DROPPEDPKTS 0x407D1320U
#define MRVL_AMG_MAC_WMAC_TX_STATS_OCTETS 0x407D1330U
#define MRVL_AMG_MAC_WMAC_TX_STATS_JABBER 0x407D1340U
#define MRVL_AMG_MAC_WMAC_TX_STATS_FRAGMENT 0x407D1350U
#define MRVL_AMG_MAC_WMAC_TX_STATS_UNDERSIZE 0x407D1360U
#define MRVL_AMG_MAC_WMAC_TX_STATS_RXERROR 0x407D1370U
#define MRVL_AMG_MAC_WMAC_TX_STATS_CRCERROR 0x407D1380U
#define MRVL_AMG_MAC_WMAC_TX_STATS_FCPKTS 0x407D1390U
#define MRVL_AMG_MAC_WMAC_TX_STATS_BROADCASTPKTS 0x407D13A0U
#define MRVL_AMG_MAC_WMAC_TX_STATS_MULTICASTPKTS 0x407D13B0U
#define MRVL_AMG_MAC_WMAC_TX_STATS_OUTPFRAGS 0x407D1490U
#define MRVL_AMG_MAC_WMAC_TX_STATS_OUTPFRAMES 0x407D14A0U



#define MRVL_AMG_MCS_COUNTERMASK_MACSEC	0xFFFFFFFFFFFFFFFFU
#define MRVL_AMG_MCS_COUNTERMASK_MMAC	0xFFFFFFFFFFFU

/**
 * @brief Define the MAC forwarding mode enum
 * 
 */
typedef enum
{
	MRVL_AMG_MAC_CUT_THROUGH = 0,
	MRVL_AMG_MAC_STORE_FWD = 3
} MRVL_AMG_MAC_FWD_MODE;

/**
 * @brief Define the MAC power mode enum
 * 
 */
typedef enum
{
	MRVL_AMG_MAC_LOW_POWER   = 0,
	MRVL_AMG_MAC_LOW_LATENCY = 1
} MRVL_AMG_MAC_POWER_MODE;

/**
 * @brief Define the datapath enum
 * 
 */
typedef enum
{
	MRVL_AMG_MCS_DP_BYPASS = 0,	/*!< datapath bypass MACsec */
	MRVL_AMG_MCS_DP_IN = 1		/*!< datapath goes through MACsec */
} MRVL_AMG_MCS_DATAPATH;

/**
 * @brief Define the MACsec direction enum
 * 
 */
typedef enum
{
	MRVL_AMG_MCS_DIR_INGRESS = 0,	/*!< MACsec RX or ingress direction */
	MRVL_AMG_MCS_DIR_EGRESS = 1		/*!< MACsec TX or egress direction */
} MRVL_AMG_MCS_DIR;

/**
 * @brief Define the MACsec block power enum
 * 
 */
typedef enum
{
	MRVL_AMG_MCS_POWER_OFF = 0,	/*!< MACsec block is power-up */
	MRVL_AMG_MCS_POWER_ON = 1	/*!< MACsec block is power-off */
} MRVL_AMG_MCS_POWER;

typedef enum
{
    MRVL_AMG_MAC_POWER_OFF = 0,   /*!< MAC block is power-off */
    MRVL_AMG_MAC_POWER_ON = 1     /*!< MAC block is power-on */
} MRVL_AMG_MAC_POWER;

typedef enum
{
    MRVL_AMG_MAC_DP_BYPASS = 0,   /*!< datapath bypass MAC */
    MRVL_AMG_MAC_DP_IN = 1        /*!< datapath goes through MAC */
} MRVL_AMG_MAC_DATAPATH;


/**
 * @brief Define the permit police for frames as defined in 802.1ae
 * 
 */
typedef enum
{
	MRVL_AMG_MCS_VF_DISABLED = 0,	/*!< Disable validation */
	MRVL_AMG_MCS_VF_CHECK = 1, 		/*!< Enable validation, do not discard invalid frames*/
	MRVL_AMG_MCS_VF_STRICT = 2, 		/*!< Enable validation and discard invalid frames */
	MRVL_AMG_MCS_VF_NA = 3 			/*!< No processing or accounting */
} MRVL_AMG_MCS_VALIDATEFRAME;

/**
 * @brief Define SecTag and ICV configuration.
 * 
 */
typedef enum
{
	MRVL_AMG_MCS_SECTAG_ICV_BOTH_STRIP = 0,		/*!< Strip both SecTag and ICV from packet */
	MRVL_AMG_MCS_SECTAG_ICV_RESERVED = 1,
	MRVL_AMG_MCS_SECTAG_ICV_STRIP_ICV_ONLY = 2,	/*!< Preserve SecTag, Strip ICV */
	MRVL_AMG_MCS_SECTAG_ICV_NO_STRIP = 3 		/*!< Preserve both SecTag and ICV */
} MRVL_AMG_MCS_STRIP_SECTAG_ICV;

/**
 * Define Encoded Packet Type from the parser
 * 
 */
typedef enum
{
	MRVL_AMG_MCS_PACKET_NO_VLAN_OR_MPLS = 0,
	MRVL_AMG_MCS_PACKET_SINGLE_VLAN = 1,
	MRVL_AMG_MCS_PACKET_DUAL_VLAN = 2,
	MRVL_AMG_MCS_PACKET_MPLS = 3,
	MRVL_AMG_MCS_PACKET_SINGLE_VLAN_FOLLOW_BY_MPLS = 4,
	MRVL_AMG_MCS_PACKET_DUAL_VLAN_FOLLOW_BY_MPLS = 5,
	MRVL_AMG_MCS_PACKET_UNSUPPORTED_TYPE = 6
} MRVL_AMG_MCS_PACKET_TYPE;


/**
 * @brief Define the cipher suite to use for this SecY
 * 
 */
typedef enum
{
	MRVL_AMG_MCS_CIPHER_GCM_AES_128 = 0,
	MRVL_AMG_MCS_CIPHER_GCM_AES_256 = 1,
	MRVL_AMG_MCS_CIPHER_GCM_AES_128_XPN = 2,
	MRVL_AMG_MCS_CIPHER_GCM_AES_256_XPN = 3
} MRVL_AMG_MCS_CIPHER_SUITE;

/**
 * @brief Structure of SMC RX stats
 * 
 */
typedef struct {
	MRVL_APHY_U64 goodOctets;		/*!< Good frame octets */
	MRVL_APHY_U64 errorOctets;		/*!< Bad frame octets */
	MRVL_APHY_U64 jabber;			/*!< Frame of size > MTU and bad CRC */
	MRVL_APHY_U64 fragment;			/*!< Frame < 48B with bad CRC */
	MRVL_APHY_U64 undersize;		/*!< Frame < 48B with good CRC */
	MRVL_APHY_U64 oversize;			/*!< Frame of size > MTU and good CRC */
	MRVL_APHY_U64 rxError;			/*!< sequence, code, symbol errors */
	MRVL_APHY_U64 crcErrTxUnderrun;	/*!< CRC error */
	MRVL_APHY_U64 rxOverrunBadFC;	/*!< Overrun or bad flow control packet */
	MRVL_APHY_U64 goodPkts;			/*!< number of good packets */
	MRVL_APHY_U64 fcPkts;			/*!< flow control packet */
	MRVL_APHY_U64 broadcast;		/*!< number of broadcast packets */
	MRVL_APHY_U64 multicast;		/*!< number of multicast packets */
	MRVL_APHY_U64 inPAssemblyErr;	
	MRVL_APHY_U64 inPFrames;		
	MRVL_APHY_U64 inPFrags;
	MRVL_APHY_U64 inPBadFrags;
}MRVL_AMG_MAC_RX_SMC_STATS;

/**
 * @brief Structure of SMC TX stats
 * 
 */
typedef struct {
	MRVL_APHY_U64 goodOctets;		/*!< Good frame octets */
	MRVL_APHY_U64 errorOctets;		/*!< Bad frame octets */
	MRVL_APHY_U64 jabber;			/*!< Frame of size > MTU and bad CRC */
	MRVL_APHY_U64 fragment;			/*!< Frame < 48B with bad CRC */
	MRVL_APHY_U64 undersize;		/*!< Frame < 48B with good CRC */
	MRVL_APHY_U64 oversize;			/*!< Frame of size > MTU and good CRC */
	MRVL_APHY_U64 rxError;			/*!< sequence, code, symbol errors */
	MRVL_APHY_U64 crcErrTxUnderrun;	/*!< CRC error */
	MRVL_APHY_U64 rxOverrunBadFC;	/*!< Overrun or bad flow control packet */
	MRVL_APHY_U64 goodPkts;			/*!< number of good packets */
	MRVL_APHY_U64 fcPkts;			/*!< flow control packet */
	MRVL_APHY_U64 broadcast;		/*!< number of broadcast packets */
	MRVL_APHY_U64 multicast;		/*!< number of multicast packets */
	MRVL_APHY_U64 outPFrags;
	MRVL_APHY_U64 outPFrames;
}MRVL_AMG_MAC_TX_SMC_STATS;

/**
 * @brief Structure of WMC RX stats
 * 
 */
typedef struct {
	MRVL_APHY_U64 pkts;				/*!< all packets */
	MRVL_APHY_U64 droppedPkts;		/*!< dropped packets */
	MRVL_APHY_U64 octets;			/*!< all packets octets */
	MRVL_APHY_U64 jabber;			/*!< packet > MTU and bad CRC */
	MRVL_APHY_U64 fragment;			/*!< packet < 64B and bad CRC */
	MRVL_APHY_U64 undersize;		/*!< packet < 64B and good CRC */
	MRVL_APHY_U64 rxError;			/*!< seqeunce, code, symbol errors */
	MRVL_APHY_U64 crcError;			/*!< CRC error packet */
	MRVL_APHY_U64 fcPkts;			/*!< flow control packet */
	MRVL_APHY_U64 broadcast;		/*!< number of broadcast packets */
	MRVL_APHY_U64 multicast;		/*!< number of multicast packets */
	MRVL_APHY_U64 inPAssemblyErr;
	MRVL_APHY_U64 inPFrames;
	MRVL_APHY_U64 inPFrags;
	MRVL_APHY_U64 inPBadFrags;
}MRVL_AMG_MAC_RX_WMC_STATS;

/**
 * @brief Structure of WMC TX stats
 * 
 */
typedef struct {
	MRVL_APHY_U64 pkts;				/*!< all packets */
	MRVL_APHY_U64 droppedPkts;		/*!< dropped packets */
	MRVL_APHY_U64 octets;			/*!< all packets octets */
	MRVL_APHY_U64 jabber;			/*!< packet > MTU and bad CRC */
	MRVL_APHY_U64 fragment;			/*!< packet < 64B and bad CRC */
	MRVL_APHY_U64 undersize;		/*!< packet < 64B and good CRC */
	MRVL_APHY_U64 rxError;			/*!< seqeunce, code, symbol errors */
	MRVL_APHY_U64 crcError;			/*!< CRC error packet */
	MRVL_APHY_U64 fcPkts;			/*!< flow control packet */
	MRVL_APHY_U64 broadcast;		/*!< number of broadcast packets */
	MRVL_APHY_U64 multicast;		/*!< number of multicast packets */
	MRVL_APHY_U64 outPFrags;
	MRVL_APHY_U64 outPFrames;
}MRVL_AMG_MAC_TX_WMC_STATS;

/**
 * @brief Structure of SecY Rx stats
 * 
 */
typedef struct {
	MRVL_APHY_U64 inOctetsSecYDecrypted;	/*!< The number of plaintext octets recovered from packets that were integrity protected and encrypted. */
	MRVL_APHY_U64 inOctetsSecYValidate;		/*!< The number of plaintext octets recovered from packets that were integrity protected but not encrypted. */
	MRVL_APHY_U64 inPktsSecYNoSAError;		/*!< The number of received packets discarded because the received SCI is unknown on the SA is not in use. */
	MRVL_APHY_U64 inPktsSecYNoSA;			/*!< The number of received packets with an unknown SA or an unused SA. */
	MRVL_APHY_U64 inPktsSecYBadTag;			/*!< The number of received packets discarded with an invalid SecTag, zero value PN, or invalid ICV. */
	MRVL_APHY_U64 inPktsSecYNoTag;			/*!< The number of received packets without a SecTag discarded because SecY.Validate_Frames was STRICT. */
	MRVL_APHY_U64 inPktsSecYUntagged;		/*!< The number of packets without a SecTag received while SecY.Validate_Frames was not STRICT. */
	MRVL_APHY_U64 inPktsCtrlPortDisable;	/*!< The number of packets received which are dropped on disabled SecY. */
	MRVL_APHY_U64 inCtrlPortOctets;			/*!< Ingress Total MSDU and MAC-DA/SA Octets that are permitted by the controlled port policies of this SecY. */
	MRVL_APHY_U64 inCtrlPortUCPkts;			/*!< Ingress Unicast packet count value for controlled ports of this SecY. */
	MRVL_APHY_U64 inCtrlPortMCPkts;			/*!< Ingress Multicast packet count value for controlled ports of this SecY. */
	MRVL_APHY_U64 inCtrlPortBCPkts;			/*!< Ingress Broadcast packet count value for controlled ports of this SecY. */
	MRVL_APHY_U64 inUnCtrlPortOctets;		/*!< Ingress Total MSDUand MAC - DA / SA Octets that are permitted by the uncontrolled port policies of this SecY. */
	MRVL_APHY_U64 inUnCtrlPortUCPkts;		/*!< Ingress Unicast packet count value for uncontrolled ports of this SecY. */
	MRVL_APHY_U64 inUnCtrlPortMCPkts;		/*!< Ingress Multicast packet count value for uncontrolled ports of this SecY. */
	MRVL_APHY_U64 inUnCtrlPortBCPkts;		/*!< Ingress Broadcast packet count value for uncontrolled ports of this SecY. */
}MRVL_AMG_MCS_RX_SECY_COUNTER;

/**
 * @brief Structure of SecY Tx stats
 * 
 */
typedef struct {
	MRVL_APHY_U64 outPktsCtrlPortDisable;	/*!< The number of packets received on disabled SecY. */
	MRVL_APHY_U64 outPktsSecYUntagged;		/*!< The number of data packets (excluding control packets) transmitted without a SecTag because Protect Frames is false. */
	MRVL_APHY_U64 outPktsSecYNoActiveSA;	/*!< The number of data packets with SA value not matching any active SA value configured. */
	MRVL_APHY_U64 outPktSecYTooLong;		/*!< The number of transmit packets discarded because their length is greater than the configured MTU after SecTag/ICV insertion. */
	MRVL_APHY_U64 outOctetsSecYProtected;	/*!< The number of plain text octets integrity protected but not encrypted in transmitted frames. */
	MRVL_APHY_U64 outOctetsSecYEncrypted;	/*!< The number of plain text octets integrity protected and encrypted in transmitted frames. */
	MRVL_APHY_U64 outCtrlPortOctets;		/*!< Egress Total MSDU and MAC-DA/SA Octets that are permitted by the controlled port policies of this SecY. */
	MRVL_APHY_U64 outCtrlPortUCPkts;		/*!< Egress Unicast packet count value for controlled ports of this SecY. */
	MRVL_APHY_U64 outCtrlPortMCPkts;		/*!< Egress Multicast packet count value for controlled ports of this SecY. */
	MRVL_APHY_U64 outCtrlPortBCPkts;		/*!< Egress Broadcast packet count value for controlled ports of this SecY. */
	MRVL_APHY_U64 outUnCtrlPortOctets;		/*!< Egress Total MSDU and MAC-DA/SA Octets that are permitted by the uncontrolled port policies of this SecY. */
	MRVL_APHY_U64 outUnCtrlPortUCPkts;		/*!< Egress Unicast packet count value for uncontrolled ports of this SecY. */
	MRVL_APHY_U64 outUnCtrlPortMCPkts;		/*!< Egress Multicast packet count value for uncontrolled ports of this SecY. */
	MRVL_APHY_U64 outUnCtrlPortBCPkts;		/*!< Egress Broadcast packet count value for uncontrolled ports of this SecY. */
}MRVL_AMG_MCS_TX_SECY_COUNTER;

/**
 * @brief Structure of SC Rx stats
 * 
 */
typedef struct {
	MRVL_APHY_U64 inPktsSCCamHit;			/*!< The number of Packets which hit an entry in the SC TCAM. Only 1 counter increments per packet. */
	MRVL_APHY_U64 inPktsSCLate;				/*!< The number of packets discarded, because the received PN was lower than the lowest acceptable PN and with replay protect true. */
	MRVL_APHY_U64 inPktsSCNotValid;			/*!< The number of packets discarded, because validation failed and SecY.Validate_Frames is 'STRICT' or the data was encrypted so the original frame could not be recovered. */
	MRVL_APHY_U64 inPktsSCInvalid;			/*!< The number of packets, that failed validation but could be received because SecY.Validate_Frames was 'CHECK' and the data was not encrypted so the original frame could be recovered. */
	MRVL_APHY_U64 inPktsSCDelayed;			/*!< The number of received packets, with PN lower than the lowest acceptable PN and replay protect is false. */
	MRVL_APHY_U64 inPktsSCUnchecked;		/*!< The number of packets received, while Validate_Frames was disabled. */
	MRVL_APHY_U64 inPktsSCOK;				/*!< The number of packets received for this SC successfully validated and within the replay window. */
}MRVL_AMG_MCS_RX_SC_COUNTER;

/**
 * @brief Structure of SC Tx stats
 * 
 */
typedef struct {
	MRVL_APHY_U64 outPktsProtected;			/*!< The number of integrity protected but not encrypted packets for this transmit SC. */
	MRVL_APHY_U64 outPktsEncrypted;			/*!< The number of integrity protected and encrypted packets for this transmit SC. */
}MRVL_AMG_MCS_TX_SC_COUNTER;

/**
 * @brief Structure of Port Rx stats
 * 
 */
typedef struct {
	MRVL_APHY_U64 inPktsParseErr;			/*!< The number of packets that have a parse error as indicated by PEX per port. */
	MRVL_APHY_U64 inPktsFlowIDTCAMMiss;		/*!< The number of Flow ID TCAM misses per port. */
	MRVL_APHY_U64 inPktsEarlyPreemptErr;	/*!< The number of packets with Early Preemption violations detected per port. */
	MRVL_APHY_U64 inPktsFlowIDTCAMHit0;		/*!< The number of Packets which hit an entry in the Flow-ID = 0 TCAM. Only 1 counter increments per packet. */
	MRVL_APHY_U64 inPktsFlowIDTCAMHit1;		/*!< The number of Packets which hit an entry in the Flow-ID = 1 TCAM. Only 1 counter increments per packet. */
	MRVL_APHY_U64 inPktsFlowIDTCAMHit2;		/*!< The number of Packets which hit an entry in the Flow-ID = 2 TCAM. Only 1 counter increments per packet. */
	MRVL_APHY_U64 inPktsFlowIDTCAMHit3;		/*!< The number of Packets which hit an entry in the Flow-ID = 3 TCAM. Only 1 counter increments per packet. */
}MRVL_AMG_MCS_RX_PORT_COUNTER;

/**
 * @brief Structure of Port Tx stats
 * 
 */
typedef struct {
	MRVL_APHY_U64 outPktsParseErr;			/*!< The number of packets that have a parse error as indicated by PEX per port. */
	MRVL_APHY_U64 outPktsFlowIDTCAMMiss;	/*!< The number of Flow ID TCAM misses per port. */
	MRVL_APHY_U64 outPktsEarlyPreemptErr;	/*!< The number of packets with Early Preemption violations detected per port. */
	MRVL_APHY_U64 outPktsFlowIDTCAMHit0;	/*!< The number of Flow ID = 0 TCAM hits. */
	MRVL_APHY_U64 outPktsFlowIDTCAMHit1;	/*!< The number of Flow ID = 1 TCAM hits. */
	MRVL_APHY_U64 outPktsFlowIDTCAMHit2;	/*!< The number of Flow ID = 2 TCAM hits. */
	MRVL_APHY_U64 outPktsFlowIDTCAMHit3;	/*!< The number of Flow ID = 3 TCAM hits. */
}MRVL_AMG_MCS_TX_PORT_COUNTER;

/**
 * @brief Structure of Rx SA policy fields. 
 * Including SAK, HASHKey, SALT and SSCI.
 * HASHKey needs to be generated per SAK and selected cipher suite.
 * 
 */
typedef struct {
	MRVL_APHY_U8 sak[MRVL_AMG_MCS_SAK_LEN];				/*!< 256b SAK: Define the key to be used to decrypt this packet. The lower 128 bits are used for 128-bit ciphers. */
	MRVL_APHY_U8 hashKey[MRVL_AMG_MCS_HASHKEY_LEN];		/*!< 128b Hash Key: Key used for authentication. */
	MRVL_APHY_U8 salt[MRVL_AMG_MCS_SALTKEY_LEN];			/*!< 96b Salt value: Salt value used in XPN ciphers. */
	MRVL_APHY_U32 ssci;										/*!< 32b SSCI value: Short Secure Channel Identifier, used in XPN ciphers. */
}MRVL_AMG_MCS_RX_SA_PLCY;

/**
 * @brief Structure of Rx/ingress SC 
 * If a packet matches on an SA which is not in use, a policy violation is triggered and the packet is either permitted or denied based on the SecY Policy table.
 * 
 */
typedef struct {
	MRVL_APHY_U8 secYIndex;				/*!< SecY associated with this packet. */
	MRVL_APHY_U64 sci;					/*!< The Secure Channel Identifier. */
	MRVL_APHY_BOOL enable;				/*!< Set to 1 to enable the this CAM entry to be part of the CAM search/compare. */
	MRVL_APHY_U8 sa_index0;				/*!< Define the 1st SA to use */
	MRVL_APHY_U8 sa_index1;				/*!< Define the 2nd SA to use */
	MRVL_APHY_U8 sa_index2;				/*!< Define the 3rd SA to use */
	MRVL_APHY_U8 sa_index3;				/*!< Define the 4th SA to use */
	MRVL_APHY_BOOL sa_index0_in_use;	/*!< Specifies whether 1st SA is in use or not. */
	MRVL_APHY_BOOL sa_index1_in_use;	/*!< Specifies whether 2nd SA is in use or not.  */
	MRVL_APHY_BOOL sa_index2_in_use;	/*!< Specifies whether 3rd SA is in use or not. */
	MRVL_APHY_BOOL sa_index3_in_use;	/*!< Specifies whether 4th SA is in use or not.  */
}MRVL_AMG_MCS_RX_SC;

/**
 * @brief Structure of Rx/Ingress SecY Map
 * 
 */
typedef struct {
    MRVL_APHY_U8 secYIndex;			/*!< index for entry in ingress secY policy */
	MRVL_APHY_BOOL isControlPacket;	/*!< Identifies all packets matching the associated Flow-ID lookup as control packets. */
}MRVL_AMG_MCS_RX_SECY_MAP;

/**
 * @brief Structure of Rx/ingress SecY.
 * The incoming packet PN must be greater than or equal to the associated next_pn (sa_pn_table_mem) minus this value or the packet must be dropped.
 * 
 */
typedef struct {
	MRVL_APHY_BOOL controlled_port_enabled;	/*!< Enable (or disable) operation of the Controlled port associated with this SecY */
	MRVL_AMG_MCS_VALIDATEFRAME validate_frames;			/*!< see VALIDATEFRAME */
	MRVL_AMG_MCS_STRIP_SECTAG_ICV strip_sectag_icv;		/*!< Enable (or disable) operation of the Controlled port associated with this SecY */
	MRVL_AMG_MCS_CIPHER_SUITE cipher;					/*!< Define the cipher suite to use for this SecY */
	MRVL_APHY_U8 confidential_offset;		/*!< Define the number of bytes that are unencrypted following the SecTag. */
	MRVL_APHY_BOOL icv_includes_da_sa;		/*!< When set, the outer DA/SA bytes are included in the authentication GHASH calculation */
	MRVL_APHY_BOOL replay_protect;			/*!< Enables Anti-Replay protection */
	MRVL_APHY_U32 replay_window;			/*!< Unsigned value indicating the size of the anti-replay window. */
}MRVL_AMG_MCS_RX_SECY;

/**
 * @brief Structure of Tx SA policy fields. 
 * Including SAK, HASHKey, SALT and SSCI. Plus sectag AN
 * HASHKey needs to be generated per SAK and selected cipher suite.
 * 
 */
typedef struct {
	MRVL_APHY_U8 sak[MRVL_AMG_MCS_SAK_LEN];				/*!< 256b SAK: Define the encryption key to be used to encrypte this packet. The lower 128 bits are used for 128-bit ciphers. */
	MRVL_APHY_U8 hashKey[MRVL_AMG_MCS_HASHKEY_LEN];		/*!< 128b Hash Key: Key used for authentication. */
	MRVL_APHY_U8 salt[MRVL_AMG_MCS_SALTKEY_LEN];			/*!< 96b Salt value: Salt value used in XPN ciphers. */
	MRVL_APHY_U32 ssci;										/*!< 32b SSCI value: Short Secure Channel Identifier, used in XPN ciphers. */
	MRVL_APHY_U8 AN;										/*!< 2b SecTag Association Number (AN) */
}MRVL_AMG_MCS_TX_SA_PLCY;

/**
 * @brief Structure of Tx SC 
 * 
 */
typedef struct {
	MRVL_APHY_U8 sa_index0;				/*!< First SA index  */
	MRVL_APHY_U8 sa_index1;				/*!< Second SA index */
	MRVL_APHY_BOOL sa_index0_vld;		/*!< When set, indicates that the corresponding SC's SA index0 is valid. */
	MRVL_APHY_BOOL sa_index1_vld;		/*!< When set, indicates that the corresponding SC's SA index1 is valid. */
	MRVL_APHY_BOOL enable_auto_rekey;	/*!< If enabled, then once the pn_threshold is reached, auto rekey will happen. */
	MRVL_APHY_BOOL isActiveSA1;			/*!< If set, then sa_index1 is the currently active SA index. If cleared, the sa_index0 is the currently active SA index). */
}MRVL_AMG_MCS_TX_SC;

/**
 * @brief Structure of Tx/Egress SecY Map
 * 
 */
typedef struct {
	MRVL_APHY_U64 sectag_sci;		/*!< Identifies the SecTAG SCI for this Flow. */
    MRVL_APHY_U8 secYIndex;			/*!< index for entry in Egress secY Policy */
	MRVL_APHY_BOOL isControlPacket;	/*!< Identifies all packets matching this index lookup as control packets. */
	MRVL_APHY_U8 scIndex;			/*!< Identifies the SC for this Flow. */
	MRVL_APHY_BOOL auxiliary_plcy;	/*!< Auxiliary policy bits. */
}MRVL_AMG_MCS_TX_SECY_MAP;

/**
 * @brief Structure of Tx SecY 
 * 
 */
typedef struct {
	MRVL_APHY_BOOL controlled_port_enabled;	/*!< Enable (or disable) operation of the Controlled port associated with this SecY. */
	MRVL_APHY_BOOL protect_frames;			/*!< 0 = do not encrypt or authenticate this packet; 1 = always Authenticate frame and if SecTag.TCI.E = 1 encrypt the packet as well. */
	MRVL_AMG_MCS_CIPHER_SUITE cipher;					/*!< Define the cipher suite to use for this SecY */
	MRVL_APHY_U8 confidential_offset;		/*!< Define the number of bytes that are unencrypted following the SecTag. */
	MRVL_APHY_BOOL icv_includes_da_sa;		/*!< When set, the outer DA/SA bytes are included in the authentication GHASH calculation */
	MRVL_APHY_U8 sectag_offset;				/*!< Define the offset in bytes from either the start of the packet or a matching Etype depending on SecTag_Insertion_Mode. */
	MRVL_APHY_U8 sectag_tci;				/*!< Tag Control Information excluding the AN field which originates from the SA Policy table */
	MRVL_APHY_U16 mtu;						/*!< Specifies the outgoing MTU for this SecY */

}MRVL_AMG_MCS_TX_SECY;

/**
 * @brief Structure of Vlan tag
 * 
 */
typedef struct {
	MRVL_APHY_U16 VID;		/*!< 12 bits */
	MRVL_APHY_U8 PRI_CFI;	/*!< PRI - 3 bits, CFI - 1bit */
}MRVL_AMG_MCS_VLANTAG;

/**
 * @brief Structure of MPLS
 * 
 */
typedef struct {
	MRVL_APHY_U32 MPLS_label;	/*!< 20 bits */
	MRVL_APHY_U8 exp;			/*!< 3 bits */
}MRVL_AMG_MCS_MPLS_OUTER;

/**
 * @brief Define Packet Type (vlan or MPLS)
 * 
 */
typedef union
{
	MRVL_AMG_MCS_VLANTAG vlanTag;
	MRVL_AMG_MCS_MPLS_OUTER mpls;
} MRVL_AMG_MCS_PACKETTYPE_OUTER;

/**
 * @brief Structure of MACsec Rule.
 * 
 */
typedef struct {
	MRVL_APHY_U8 key_MAC_DA[MRVL_AMG_MCS_MAC_ADDR_LEN];		/*!< MAC DA field extracted from the packet */
	MRVL_APHY_U8 mask_MAC_DA[MRVL_AMG_MCS_MAC_ADDR_LEN];	/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_U8 key_MAC_SA[MRVL_AMG_MCS_MAC_ADDR_LEN];		/*!< MAC SA field extracted from the packet */
	MRVL_APHY_U8 mask_MAC_SA[MRVL_AMG_MCS_MAC_ADDR_LEN];	/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_U16 key_Ethertype;							/*!< First E-Type found in the packet that doesn't match one of the preconfigured custom tag. */
	MRVL_APHY_U16 mask_Ethertype;							/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_AMG_MCS_PACKETTYPE_OUTER key_outer1;			/*!< outermost/1st VLAN ID {8'd0, VLAN_ID[11:0]}, or 20-bit MPLS label. */
	MRVL_AMG_MCS_PACKETTYPE_OUTER mask_outer1;			/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_AMG_MCS_PACKETTYPE_OUTER key_outer2;			/*!< 2nd outermost VLAN ID {8'd0, VLAN_ID[11:0]}, or 20-bit MPLS label. */
	MRVL_AMG_MCS_PACKETTYPE_OUTER mask_outer2;			/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_U16 key_bonus_data;						/*!< 2 bytes of additional bonus data extracted from one of the custom tags. */
	MRVL_APHY_U16 mask_bonus_data;						/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_U8 key_tag_match_bitmap;					/*!< 8 bits total. Maps 1 to 1 bitwise with the set of custom tags. (set bit[N]=1 if check Nth custom tag) */
	MRVL_APHY_U8 mask_tag_match_bitmap;					/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_AMG_MCS_PACKET_TYPE key_packet_type;			/*!< Encoded Packet Type, see PACKET_TYPE */
	MRVL_APHY_U8 mask_packet_type;						/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_U16 key_inner_vlan_type;					/*!< 3 bits total. Encoded value indicating which VLAN TPID value matched for the second outermost VLAN Tag. */
	MRVL_APHY_U16 mask_inner_vlan_type;					/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_U16 key_outer_vlan_type;					/*!< 3 bits total. Encoded value indicating which VLAN TPID value matched for the outermost VLAN Tag. */
	MRVL_APHY_U16 mask_outer_vlan_type;					/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_U8 key_num_tags;							/*!< 7 bits total. Number of VLAN/custom tags or MPLS lables detected. Ingress: before SecTag; Egress: total detected. Exclude MCS header tags. */
	MRVL_APHY_U8 mask_num_tags;							/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_U8 key_express;							/*!< 1 bits. Express packet. */
	MRVL_APHY_U8 mask_express;							/*!< Set bits to 1 to mask/exclude corresponding flowid_tcam_data bit from compare */
	MRVL_APHY_BOOL isMPLS;					
	MRVL_APHY_BOOL isEnable;							/*!< Set to 1 to enable the corresponding TCAM entry to be part of the TCAM search/compare. */
}MRVL_AMG_MCS_RULE;

/**
 * @brief Structure of MACsec custom tag
 * 
 */
typedef struct {
	MRVL_APHY_BOOL hasBonusData;	/*!< TRUE: extract the two bytes immediately following the tag. FALSE: extract after the first non-matching etype as bonus data. */
	MRVL_APHY_BOOL isVLANTag;		/*!< custom tag is VLAN tag */
	MRVL_APHY_U8 size;				/*!< size of custom tag, including tag lable (valid size: 2,4,6,8,10,12,14,16. If 16, set this value to 0) */
	MRVL_APHY_U16 ethType;			/*!< custom tag's e-type value */
	MRVL_APHY_BOOL isEnabled;		/*!< TRUE: enable custom tag. FLASE: disable custom tag. */
}MRVL_AMG_MCS_CUSTOM_TAG;

/**
 * @brief Structure of e-type to classify control packet
 * 
 */
typedef struct {
	MRVL_APHY_U16 ethType;		/*!< etype value for control packet matching */
	MRVL_APHY_BOOL isEnabled;	/*!< TRUE: enable control packet classification against this e-type. FLASE: disable classification. */
}MRVL_AMG_MCS_CTRL_PCKT_ETYPE;

/**
 * @brief Structure of DA to classify control packet
 * 
 */
typedef struct {
	MRVL_APHY_U8 DA[MRVL_AMG_MCS_MAC_ADDR_LEN];	/*!< DA value for control packet matching (6 bytes) */
	MRVL_APHY_BOOL isEnabled;					/*!< TRUE: enable control packet classification against this DA. FLASE: disable classification. */
}MRVL_AMG_MCS_CTRL_PCKT_DA;

/**
 * @brief Structure of DA range to classify control packet
 * 
 */
typedef struct {
	MRVL_APHY_U8 MAX_DA[MRVL_AMG_MCS_MAC_ADDR_LEN];	/*!< maximun DA address for control packet matching */
	MRVL_APHY_U8 MIN_DA[MRVL_AMG_MCS_MAC_ADDR_LEN];	/*!< minimun DA address for control packet matching */
	MRVL_APHY_BOOL isEnabled;						/*!< TRUE: enable control packet classification against this DA range. FLASE: disable classification. */
}MRVL_AMG_MCS_CTRL_PCKT_DA_RANGE;

/**
 * @brief Structure of combo settings to classify control packet
 * 
 */
typedef struct {
	MRVL_APHY_U16 ethType;							/*!< etype value for control packet matching */
	MRVL_APHY_U8 MAX_DA[MRVL_AMG_MCS_MAC_ADDR_LEN];	/*!< maximun DA address for control packet matching */
	MRVL_APHY_U8 MIN_DA[MRVL_AMG_MCS_MAC_ADDR_LEN];	/*!< minimun DA address for control packet matching */
	MRVL_APHY_BOOL isEnabled;						/*!< TRUE: enable control packet classification against this combo. FLASE: disable classification. */
}MRVL_AMG_MCS_CTRL_PCKT_COMBO;

#endif

