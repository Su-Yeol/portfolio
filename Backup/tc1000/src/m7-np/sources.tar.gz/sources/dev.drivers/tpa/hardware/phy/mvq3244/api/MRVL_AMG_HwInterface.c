/**
 * @file MRVL_AMG_HwInterface.c
 * @brief Hardware interface source file for API interfacing with registers
 * This is used for including system-dependent XMDIO/CL45 implementations in order to access PHY device.
 * Modify this file to add:
 * 		Catch return code (MRVL_APHY_STATUS)
 * 		Log/dump registers accesses 
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */

#include "MRVL_AMG_HwInterface.h"


#define MRVL_AMG_CPU 0x1E

#define  MRVL_AMG_SMI2AHB_ADDR0    0x28U
#define  MRVL_AMG_SMI2AHB_ADDR1    0x29U
#define  MRVL_AMG_SMI2AHB_W_DATA0  0x2AU
#define  MRVL_AMG_SMI2AHB_W_DATA1  0x2BU
#define  MRVL_AMG_SMI2AHB_CMD      0x2CU
#define  MRVL_AMG_SMI2AHB_R_DATA0  0x2DU
#define  MRVL_AMG_SMI2AHB_R_DATA1  0x2EU


MRVL_APHY_BOOL MRVL_AMG_MB_OPT = MRVL_APHY_FALSE;
MRVL_APHY_U16 MRVL_AMG_MB_OPT_ADDR_L = 0xFFFF;
MRVL_APHY_U16 MRVL_AMG_MB_OPT_ADDR_H = 0xFFFF;
MRVL_APHY_U16 MRVL_AMG_MB_OPT_DATA_L = 0;
MRVL_APHY_U16 MRVL_AMG_MB_OPT_DATA_H = 0;

/**
 * @brief Read out a 16-bit value from IEEE register through XMDIO interface.
 *
 * @param[in]	device   MRVL_DEV
 * @param[in]	portAddr phy/port address
 * @param[in]	devAddr  Device address
 * @param[in]	regAddr  Register address within section
 * @param[out]	data     Register value
 *
 * @ingroup HWInterface
 */
MRVL_APHY_STATUS MRVL_AMG_ReadReg16(MRVL_DEV_PTR device, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16* regVal)
{
	if (device->use32Bit == MRVL_APHY_TRUE)
	{
		MRVL_AMG_DBG_ERROR("MRVL_AMG_ReadReg16: SSPI does not support 16-bit.\n");
		return MRVL_APHY_STATUS_ERROR_GENERAL;
	}
	else
	{
		return MRVL_AMG_ReadReg16_IMP(device, portAddr, devAddr, regAddr, regVal);
	}	
}

/**
 * @brief Write a 16-bit value to IEEE register through XMDIO interface.
 *
 * @param[in]	device   MRVL_DEV
 * @param[in]	portAddr phy/port address
 * @param[in]	devAddr  Device address
 * @param[in]	regAddr  Register address within section
 * @param[in]	data     Register value
 *
 * @ingroup HWInterface
 */
MRVL_APHY_STATUS MRVL_AMG_WriteReg16(MRVL_DEV_PTR device, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16 regVal)
{
	if (device->use32Bit == MRVL_APHY_TRUE)
	{
		MRVL_AMG_DBG_ERROR("MRVL_AMG_WriteReg16: SSPI does not support 16-bit.\n");
		return MRVL_APHY_STATUS_ERROR_GENERAL;
	}
	else
	{
		return MRVL_AMG_WriteReg16_IMP(device, portAddr, devAddr, regAddr, regVal);
	}
}

/**
 * @brief Read out a 32-bit value from proprietary register through XMDIO or SPI interface.
 *
 * @param[in]	device   MRVL_DEV
 * @param[in]	portAddr phy/port address
 * @param[in]	devAddr  Device address
 * @param[in]	regAddr  Register address within section
 * @param[out]	data     Register value
 *
 * @ingroup HWInterface
 */
MRVL_APHY_STATUS MRVL_AMG_ReadReg32(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U32* regVal)
{
	MRVL_APHY_U16 val = 0;
	MRVL_APHY_U16 val_h = 0;

	if (device->use32Bit == MRVL_APHY_TRUE)
	{
		return MRVL_AMG_ReadReg32_IMP(device, regAddr, regVal);
			
	}

	val = (MRVL_APHY_U16)(regAddr & 0xFFFF);
	val_h = (MRVL_APHY_U16)((regAddr & 0xFFFF0000) >> 16);

	if (MRVL_AMG_MB_OPT == MRVL_APHY_FALSE) 
	{
		if (MRVL_AMG_WriteReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_ADDR0, val) != MRVL_APHY_STATUS_OK)
		{
			return MRVL_APHY_STATUS_ERROR_MDIO;
		}

		if (MRVL_AMG_WriteReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_ADDR1, val_h) != MRVL_APHY_STATUS_OK)
		{
			return MRVL_APHY_STATUS_ERROR_MDIO;
		}
	}
	else if (MRVL_AMG_MB_OPT == MRVL_APHY_TRUE)
	{
		if (MRVL_AMG_MB_OPT_ADDR_L != val)
		{
			if (MRVL_AMG_WriteReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_ADDR0, val) != MRVL_APHY_STATUS_OK)
			{
				return MRVL_APHY_STATUS_ERROR_MDIO;
			}
			MRVL_AMG_MB_OPT_ADDR_L = val;
		}
		if (MRVL_AMG_MB_OPT_ADDR_H != val_h)
		{
			if (MRVL_AMG_WriteReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_ADDR1, val_h) != MRVL_APHY_STATUS_OK)
			{
				return MRVL_APHY_STATUS_ERROR_MDIO;
			}
			MRVL_AMG_MB_OPT_ADDR_H = val_h;
		}
	}

	if (MRVL_AMG_WriteReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_CMD, 0) != MRVL_APHY_STATUS_OK)
	{
		return MRVL_APHY_STATUS_ERROR_MDIO;
	}


	if (MRVL_AMG_ReadReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_R_DATA0, &val) != MRVL_APHY_STATUS_OK)
	{
		return MRVL_APHY_STATUS_ERROR_MDIO;
	}
	*regVal = val;
	if (MRVL_AMG_ReadReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_R_DATA1, &val) != MRVL_APHY_STATUS_OK)
	{
		return MRVL_APHY_STATUS_ERROR_MDIO;
	}
	*regVal += (MRVL_APHY_U32)val << 16;

	MRVL_AMG_DBG_ALL("MRVL_AMG_ReadReg32: 0x%x=0x%x\n", regAddr, *regVal);
	return MRVL_APHY_STATUS_OK;

}

/**
 * @brief Write a 32-bit value to proprietary register through XMDIO or SPI interface.
 *
 * @param[in]	device   MRVL_DEV
 * @param[in]	portAddr phy/port address
 * @param[in]	devAddr  Device address
 * @param[in]	regAddr  Register address within section
 * @param[in]	data     Register value
 *
 * @ingroup HWInterface
 */
MRVL_APHY_STATUS MRVL_AMG_WriteReg32(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U32 regVal)
{
	MRVL_APHY_U16 val = (MRVL_APHY_U16)(regAddr & 0xFFFFU);
	MRVL_APHY_U16 val_h = (MRVL_APHY_U16)((regAddr & 0xFFFF0000U) >> 16);

	if (device->use32Bit == MRVL_APHY_TRUE)
	{
		return MRVL_AMG_WriteReg32_IMP(device, regAddr, regVal); 
	}

	if (MRVL_AMG_MB_OPT == MRVL_APHY_FALSE)
	{	
		if (MRVL_AMG_WriteReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_ADDR0, val) != MRVL_APHY_STATUS_OK)
		{
			return MRVL_APHY_STATUS_ERROR_MDIO;
		}
		if (MRVL_AMG_WriteReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_ADDR1, val_h) != MRVL_APHY_STATUS_OK)
		{
			return MRVL_APHY_STATUS_ERROR_MDIO;
		}
	}
	else if (MRVL_AMG_MB_OPT == MRVL_APHY_TRUE)
	{
		if (MRVL_AMG_MB_OPT_ADDR_L != val)
		{
			if (MRVL_AMG_WriteReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_ADDR0, val) != MRVL_APHY_STATUS_OK)
			{
				return MRVL_APHY_STATUS_ERROR_MDIO;
			}
			MRVL_AMG_MB_OPT_ADDR_L = val;
		}
		if (MRVL_AMG_MB_OPT_ADDR_H != val_h)
		{
			if (MRVL_AMG_WriteReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_ADDR1, val_h) != MRVL_APHY_STATUS_OK)
			{
				return MRVL_APHY_STATUS_ERROR_MDIO;
			}
			MRVL_AMG_MB_OPT_ADDR_H = val_h;
		}
	}

	val = (MRVL_APHY_U16)(regVal & 0xFFFFU);
	val_h = (MRVL_APHY_U16)((regVal & 0xFFFF0000U) >> 16);

	if (MRVL_AMG_MB_OPT == MRVL_APHY_FALSE)
	{
		if (MRVL_AMG_WriteReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_W_DATA0, val) != MRVL_APHY_STATUS_OK)
		{
			return MRVL_APHY_STATUS_ERROR_MDIO;
		}
		if (MRVL_AMG_WriteReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_W_DATA1, val_h) != MRVL_APHY_STATUS_OK)
		{
			return MRVL_APHY_STATUS_ERROR_MDIO;
		}
	}
	else if (MRVL_AMG_MB_OPT == MRVL_APHY_TRUE)
	{
		if (MRVL_AMG_MB_OPT_DATA_L != val)
		{
			if (MRVL_AMG_WriteReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_W_DATA0, val) != MRVL_APHY_STATUS_OK)
			{
				return MRVL_APHY_STATUS_ERROR_MDIO;
			}
			MRVL_AMG_MB_OPT_DATA_L = val;
		}
		if (MRVL_AMG_MB_OPT_DATA_H != val_h)
		{
			if (MRVL_AMG_WriteReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_W_DATA1, val_h) != MRVL_APHY_STATUS_OK)
			{
				return MRVL_APHY_STATUS_ERROR_MDIO;
			}
			MRVL_AMG_MB_OPT_DATA_H = val_h;
		}
	}

	if (MRVL_AMG_WriteReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_CMD, 1) != MRVL_APHY_STATUS_OK)
	{
		return MRVL_APHY_STATUS_ERROR_MDIO;
	}

	MRVL_AMG_DBG_ALL("MRVL_AMG_WriteReg32: 0x%x=0x%x\n", regAddr, regVal);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Delay for specified number of milliseconds.
 *
 * @param[in]	device   MRVL_DEV
 * @param[in]	waitTime wait time in milliseconds
 *
 * @ingroup Utility_Lib
 */
MRVL_APHY_STATUS MRVL_AMG_Wait(MRVL_DEV_PTR device, MRVL_APHY_U16 waitTime)
{
	return MRVL_AMG_Wait_IMP(device, waitTime);
}

/* with 16bit interface, get the current MB reg address/data to avoid setting address/data once more, in order to reduce FW loading time */
void MRVL_AMG_OptimizeMB(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEnable)
{
	MRVL_APHY_U16 val = 0;
	MRVL_AMG_MB_OPT = isEnable;
	if (device->use32Bit == MRVL_APHY_TRUE)
	{
		/* 32bit interface does not use mailbox */
		return; 
	}
	if ((isEnable == MRVL_APHY_TRUE) && (device->use32Bit == MRVL_APHY_FALSE))
	{
		if (MRVL_AMG_ReadReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_ADDR0, &val) != MRVL_APHY_STATUS_OK)
			return;
		MRVL_AMG_MB_OPT_ADDR_L = val;
		if (MRVL_AMG_ReadReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_ADDR1, &val) != MRVL_APHY_STATUS_OK)
			return;
		MRVL_AMG_MB_OPT_ADDR_H = val;
		if (MRVL_AMG_ReadReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_W_DATA0, &val) != MRVL_APHY_STATUS_OK)
			return;
		MRVL_AMG_MB_OPT_DATA_L = val;
		if (MRVL_AMG_ReadReg16(device, device->phyAddr, MRVL_AMG_CPU,  MRVL_AMG_SMI2AHB_W_DATA1, &val) != MRVL_APHY_STATUS_OK)
			return;
		MRVL_AMG_MB_OPT_DATA_H = val;
	}
	else {
		MRVL_AMG_MB_OPT_ADDR_L = 0xFFFF;
		MRVL_AMG_MB_OPT_ADDR_H = 0xFFFF;
		MRVL_AMG_MB_OPT_DATA_L = 0;
		MRVL_AMG_MB_OPT_DATA_H = 0;
	}
}
