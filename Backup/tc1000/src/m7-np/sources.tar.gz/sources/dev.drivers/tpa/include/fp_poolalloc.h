/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
 * @File
 * @Title        fp_poolalloc.h
 * @Copyright    Copyright (c) 2017-2018, Imagination Technologies, Inc.
 * @Copyright    Copyright (c) Imagination Technologies Ltd. All Rights Reserved
 * @Description  Structures for Pool memory
 * @License      Dual MIT/GPLv2
 *
 * The contents of this file are subject to the MIT license as set out below.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * the GNU General Public License Version 2 ("GPL") in which case the provisions
 * of GPL are applicable instead of those above.
 *
 * If you wish to allow use of your version of this file only under the terms of
 * GPL, and not to allow others to use your version of this file under the terms
 * of the MIT license, indicate your decision by deleting the provisions above
 * and replace them with the notice and other provisions required by GPL as set
 * out in the file called "GPL-COPYING" included in this distribution. If you do
 * not delete the provisions above,a recipient may use your version of this file
 * under the terms of either the MIT license or GPL.
 *
 * This License is also included in this distribution in the file called
 * "MIT-COPYING".
 *
 * EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 * PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */ /**************************************************************************/
#ifndef _POOLALLOC_H_
#define _POOLALLOC_H_


/* ============================================================================
 *
 * This file contains the implementation of a memory pool allocator.
 * The user initilizes a pool specifying how many items the pool is to
 * maintain.  The poolAlloc() and poolFree() functions are provided to get
 * and return memory objects to the pool. Following three functions are
 * provided:
 *
 *   POOLHEAD_PTR  poolInit(u32 Num, size_t Size, INT32 Align);
 *   char*  poolAlloc(POOLHEAD_PTR pHead);
 *   VOID poolFree(char *pDel, POOLHEAD_PTR pHead);
 *
 * These functions are "task" safe.
 *
 * I) poolInit() takes three arguments:
 *    - The first argument is the number of items the pool will maintain.
 *    - The second argument the size of each item.
 *      The minimum size of a pool item is 8 bytes (sizeof(PoolItem_t)).
 *    - The third argument is the alignment requirement for the each item
 *      (typically this is 4).
 *
 *    poolInit() returns a pointer to the pool head (type POOLHEAD_PTR).
 *    This pointer must be passed to the poolAlloc() and poolFree() function
 *    calls.
 *
 * II) poolAlloc() returns a pointer to the next free item from the pool's free
 *     list. NULL is returned if no items are available from the free list.
 *     The only parameter passed to this is the pointer to the poolHead as
 *     returned by poolInit() earlier.
 *
 * III) poolFree() returns an item to the pool's free list.
 *      Following are the parameters passed to this function:
 *      - First is the pointer to the item to be freed.
 *      - Second is the pointer to the pool head that was returned by the
 *        poolInit() call.
 *
 * Note that if the same item is returned twice to the free pool, a crash
 * (break point) is forced by this function (this is to facilite quickly finding
 * this bug). poolFree() must not be passed a NULL (again a crash (break point)
 * will result).
 *
 * To use this allocator:
 * 1) First initialize the pool buffer by calling the function poolInit().
 *     eg.
 *        POOLHEAD_PTR  gmbfPoolHead;            //Global declaration
 *        ....
 *
 *        // 100 buffers of size 512bytes each and with 4 byte boundary aligned
 *        gmbfPoolHead = poolInit(100, 512, 4);  // Initialize the pool
 *
 * 2) To Allocate an item use poolAlloc().
 *    eg.
 *        char *ptr=NULL;   //declaration
 *
 *        ptr = poolAlloc(gmbfPoolHead);        //Allocate the buffer.
 *
 * 3) To Free an item use poolFree().
 *    eg.
 *        poolFree(ptr, gmbfPoolHead);         //Free the buffer
 *
 *******************************************************************************
 */


/* Data structure to store the details of the buffer pool */
struct PoolHead {
	int8     *Front;
	int8     *Rear;
	int8     *Start;
	uint32a     Free;
	uint32a     PoolSize;
};

struct PoolItem {
	uint32a     space;   /* unused space */
	uint32a     res;
	int8     *Ptr;
	uint32a     MagicNum;
};

#define POOLHEAD struct PoolHead
#define POOLHEAD_PTR struct PoolHead *
#define POOLITEM POOLITEM struct PoolItem
#define POOLITEM_PTR struct PoolItem *

/* Prototypes */
struct PoolHead *poolInit(uint32a Num, uint32a Size, int32a Align, uint32a type);
int32a poolFree(int8 *pDel, POOLHEAD_PTR pHead);
uint32a poolCount(struct PoolHead *pHead);
uint32a poolDelete(struct PoolHead *pHead, uint32a type);

#endif /*End of _POOLALLOC_H_ File*/

