/**
 * @file MRVL_APHY_Device.h
 * @brief Marvell General Automotive PHY Device Struct
 *
 * @par Copyright and Version
 * See MRVL_Q222X_Copyright_and_Version.h
 */

#ifndef MRVL_APHY_DEVICE_H
#define MRVL_APHY_DEVICE_H

#include "MRVL_APHY_Types.h"

typedef struct _MRVL_DEV MRVL_DEV;

/**
 * @brief Pointer to MRVL_DEV.
 * Indicate device information and features
 *
 */
typedef MRVL_DEV* MRVL_DEV_PTR;

/* The following functions must be implemented. Implementation-specific */
typedef MRVL_APHY_STATUS(*READ_REG_XMDIO)(MRVL_DEV_PTR pDev, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16* data);
typedef MRVL_APHY_STATUS(*WRITE_REG_XMDIO)(MRVL_DEV_PTR pDev, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16 data);
typedef MRVL_APHY_STATUS(*WAIT_FUNC)(MRVL_DEV_PTR pDev, MRVL_APHY_U16 waitTime);

/**
 * @brief Sturcture of PHY device
 *
 */
struct _MRVL_DEV {
	MRVL_APHY_U8 phyAddr; 		/*!< PHY address */
	MRVL_APHY_U8 smiPort;		/*!< SMI port index */
	MRVL_APHY_U16 modelNum;		/*!< Model number. Call q222x_getDeviceInfo to detect */
	MRVL_APHY_U16 packageNum;	/*!< package number. Call q222x_getDeviceInfo to detect */
	MRVL_APHY_U8 revNum;		/*!< Rev number. Call q222x_getDeviceInfo to detect */
	/**
	 * @brief Read out a 16-bit value from a register through XMDIO interface.
	 *
	 * @param[in] MRVL_DEV_PTR Pointer to MRVL_DEV
 	 * @param[in] portAddr phy/port address
 	 * @param[in] devAddr MMD, device address
 	 * @param[in] regAddr register address 16bit
 	 * @param[out] data register value 16bit
	 * @return: MRVL_APHY_STATUS
	 */
	READ_REG_XMDIO readReg;
	/**
	 * @brief Write a 16-bit value into a register through XMDIO interface.
	 *
	 * @param[in] MRVL_DEV_PTR Pointer to MRVL_DEV
 	 * @param[in] portAddr phy/port address
 	 * @param[in] devAddr MMD, device address
 	 * @param[in] regAddr register address 16bit
 	 * @param[in] data register value 16bit
	 * @return: MRVL_APHY_STATUS
	 */
	WRITE_REG_XMDIO writeReg;

	/**
	 * @brief Delay for specified number of milliseconds.
	 *
	 * @param[in] MRVL_DEV_PTR Pointer to MRVL_DEV
	 * @param[in] waitTime delay time
	 * @return: MRVL_APHY_STATUS
	 */
	WAIT_FUNC wait;
};


#endif
