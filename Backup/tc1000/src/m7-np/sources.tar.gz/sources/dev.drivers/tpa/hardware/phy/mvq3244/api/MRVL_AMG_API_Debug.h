/**
 * @file MRVL_AMG_API_Debug.h
 * @brief Marvell Multi-gig Automotive Ethernet PHY Debug API header file for capturing the debug information
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */

#ifndef MRVL_AMG_DEBUG_H
#define MRVL_AMG_DEBUG_H

#include "MRVL_AMG_HwInterface.h"

#define PRINT_BUFFER_SIZE 7000
#define MESSAGE_BUFFER_SIZE 500
#define SMALL_BUFFER_SIZE 100

/**
 * @brief debug trace request status
 * 
 */
typedef enum
{
   MRVL_AMG_TRC_RequestStatus_confirmed,
   MRVL_AMG_TRC_RequestStatus_init,
   MRVL_AMG_TRC_RequestStatus_corruption,
   MRVL_AMG_TRC_RequestStatus_pending,
   MRVL_AMG_TRC_RequestStatus_timeout
}MRVL_AMG_TRACE_RequestStatus;

/**
 * @brief debug trace returnt status
 * 
 */
typedef enum
{
   MRVL_AMG_TRC_ReturntStatus_Success,
   MRVL_AMG_TRC_ReturntStatus_Reserved,
   MRVL_AMG_TRC_ReturntStatus_Warning_Overflow,
   MRVL_AMG_TRC_ReturntStatus_Warning_NoData,
   MRVL_AMG_TRC_ReturntStatus_Warning_ParserError,
   MRVL_AMG_TRC_ReturntStatus_Warning_Resync,
   MRVL_AMG_TRC_ReturntStatus_Error_GenericError,
   MRVL_AMG_TRC_ReturntStatus_Error_FirmwareIsNotLoaded,
   MRVL_AMG_TRC_ReturntStatus_Error_TraceDataCorrupted,
   MRVL_AMG_TRC_ReturntStatus_Error_TraceDataCouldNotBeExtracted,
   MRVL_AMG_TRC_ReturntStatus_Error_HostBufferInfoInvalid,
}MRVL_AMG_TRACE_ReturntStatus;

/**
 * @brief Structure of result
 * 
 */
typedef struct
{
   MRVL_APHY_U32  ResultDict_traceStatus;
   MRVL_AMG_TRACE_ReturntStatus  ResultDict_returnStatus;
   MRVL_AMG_TRACE_RequestStatus  ResultDict_requestStatus;
   MRVL_APHY_U32 ResultDict_length;
   MRVL_APHY_U32* ResultDict_rawMessages_ptr;
   double ResultDict_timestamp;
} MRVL_AMG_TRACE_ResultDict;


/******************************************************************************
 *      Debug Trace
 ******************************************************************************/
/** @defgroup PHY_DEBUG PHY Debug Trace Query */

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_Trace_SaveTraceData(MRVL_DEV_PTR device, const char* filename);


#endif
