// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          platform.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    Functions to handle different hardware platforms
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

#include "reg_hal.h"		/* brings in "InitBaseAddr()" */
#include "platform.h"
#include "tpautil.h"

static uint32a RegBuffer[0x1000];

static void printWords(unsigned int addr, char *buff, int size)
{
	int i=0;
    int *ptr = (int *)buff;
	for(i=0; i< (size/4); i++)
	{
		mcu_printf("%x: %08x ",(addr+i*4), *ptr++);
		if((i>0)&& ((i+1)%4)==0)
		{
			mcu_printf("\n");
		}
	}
	if (size % 16 != 0)
	{
		mcu_printf("\n");
	}
	mcu_printf("\n");
}

/* size : in byte, should be multiple of 4 */
static void dump_regs(uint32 addr, int32a size)
{
	int32a idx=0;
	uint32a *buffer = &RegBuffer[0];
	while(idx<size)
	{
		*buffer = RegRead(addr+idx);
		buffer++;
		idx += 4;
	}

	printWords(addr, (char*)&RegBuffer[0], size);
}

void dump_reg_debug(void)
{
	mcu_printf("\n");
	mcu_printf("***************************** Section 1 - EMAC RX/TX **********************\n");

#if 1
	mcu_printf("temporary moved to end of dump\n");
#else
	mcu_printf("emac1_frames_rxed_ok\n");
	dump_regs(0x2d0780, 0x4);

	mcu_printf("emac2_frames_rxed_ok\n");
	dump_regs(0x2d4780, 0x4);

	mcu_printf("emac3_frames_rxed_ok\n");
	dump_regs(0x2d8900, 0x4);

	mcu_printf("emac1_frames_txed_ok\n");
	dump_regs(0x2d0718, 0x4);
	
	mcu_printf("emac2_frames_txed_ok\n");
	dump_regs(0x2d4718, 0x4);
	
	mcu_printf("emac3_frames_txed_ok\n");
	dump_regs(0x2d881c, 0x4);
#endif	
	mcu_printf("\n");
	mcu_printf("***************************** Section 2 - EGPI RX / TX **********************\n");

	mcu_printf("EGPI1 Debug Registers\n");
	dump_regs(0x200058, 0x68);

	mcu_printf("EGPI1 Packet Counts\n");
	dump_regs(0x200458, 0x68);

	mcu_printf("EGPI2 Debug Registers\n");
	dump_regs(0x201058, 0x68);

	mcu_printf("EGPI2 Packet Counts\n");
	dump_regs(0x201458, 0x68);

	mcu_printf("EGPI3 Debug Registers\n");
	dump_regs(0x202058, 0x68);

	mcu_printf("EGPI3 Packet Counts\n");
	dump_regs(0x202458, 0x68);

	mcu_printf("EGPI4 Debug Registers\n");
	dump_regs(0x400058, 0x68);

	mcu_printf("EGPI4 Packet Counts\n");
	dump_regs(0x400458, 0x68);

	mcu_printf("HGPI Debug Registers\n");
	dump_regs(0x600058, 0x68);

	mcu_printf("HGPI Packet Counts\n");
	dump_regs(0x600458, 0x68);

	
	mcu_printf("\n");
	mcu_printf("***************************** Section 3 - CLASS HW **********************""\n");
	mcu_printf("***************************** CLASS EMAC1 **********************""\n");

	mcu_printf("class_phy1_rx_pkts\n");
	dump_regs(0x20071c, 0x4);

	mcu_printf("class_debug_bus01\n");
	dump_regs(0x200ad0, 0x4);

	mcu_printf("class_debug_bus23\n");
	dump_regs(0x200ad4, 0x4);

	mcu_printf("class_debug_bus45\n");
	dump_regs(0x200ad8, 0x4);

#if 0

	echo "class_debug_bus67"
	./nkcli read_pci_mem 0x200adc 4
	echo "" 
	echo "class_debug_bus89"
	./nkcli read_pci_mem 0x200ae0 4
	echo "" 
	echo "class_debug_bus1011"
	./nkcli read_pci_mem 0x200ae4 4
	echo "" 
	echo "class_state"
	./nkcli read_pci_mem 0x200874 4
	echo "" 
	echo "class_qb_buff_avail"
	./nkcli read_pci_mem 0x200878 4
	echo "" 
	echo "class_ro_buff_avail"
	./nkcli read_pci_mem 0x20087c 4

#endif
	mcu_printf("class_drop_count\n");
	dump_regs(0x200e40, 0x4);

	mcu_printf("\n");
	mcu_printf("***************************** CLASS EMAC2 **********************\n");
	mcu_printf("class_phy1_rx_pkts\n");
	dump_regs(0x20171c, 0x4);

	mcu_printf("class_debug_bus01\n");
	dump_regs(0x201ad0, 0x4);

	mcu_printf("class_debug_bus23\n");
	dump_regs(0x201ad4, 0x4);

	mcu_printf("class_debug_bus45\n");
	dump_regs(0x201ad8, 0x4);

	mcu_printf("class_debug_bus67\n");
	dump_regs(0x201adc, 0x4);

#if 0
	echo "class_debug_bus89"
	./nkcli read_pci_mem 0x201ae0 4
	echo "" 
	echo "class_debug_bus1011"
	./nkcli read_pci_mem 0x201ae4 4
	echo "" 
	echo "class_state"
	./nkcli read_pci_mem 0x201874 4
	echo "" 
	echo "class_qb_buff_avail"
	./nkcli read_pci_mem 0x201878 4
	echo "" 
	echo "class_ro_buff_avail"
	./nkcli read_pci_mem 0x20187c 4
#endif
	mcu_printf("class_drop_count\n");
	dump_regs(0x201e40, 0x4);

	mcu_printf("\n");
	mcu_printf("***************************** CLASS EMAC3 **********************\n");
	mcu_printf("\n");

	mcu_printf("class_phy1_rx_pkts\n");
	dump_regs(0x20271c, 0x4);

	mcu_printf("class_debug_bus01\n");
	dump_regs(0x202ad0, 0x4);

	mcu_printf("class_debug_bus23\n");
	dump_regs(0x202ad4, 0x4);

	mcu_printf("class_debug_bus45\n");
	dump_regs(0x202ad8, 0x4);

	mcu_printf("class_drop_count\n");
	dump_regs(0x202e40, 0x4);

	mcu_printf("\n");
	mcu_printf("***************************** CLASS EMAC4 **********************\n");
	mcu_printf("\n");

	mcu_printf("class_phy1_rx_pkts\n");
	dump_regs(0x40071c, 0x4);

	mcu_printf("class_debug_bus01\n");
	dump_regs(0x400ad0, 0x4);

	mcu_printf("class_debug_bus23\n");
	dump_regs(0x400ad4, 0x4);

	mcu_printf("class_debug_bus45\n");
	dump_regs(0x400ad8, 0x4);

	mcu_printf("class_drop_count\n");
	dump_regs(0x400e40, 0x4);

	mcu_printf("\n");
	mcu_printf("***************************** CLASS HIF**********************\n");
	mcu_printf("\n");

	mcu_printf("class_phy1_rx_pkts\n");
	dump_regs(0x60071c, 0x4);

	mcu_printf("class_debug_bus01\n");
	dump_regs(0x600ad0, 0x4);

	mcu_printf("class_debug_bus23\n");
	dump_regs(0x600ad4, 0x4);

	mcu_printf("class_drop_count\n");
	dump_regs(0x600e40, 0x4);

	mcu_printf("\n");
	mcu_printf("***************************** Section 5 - HIF **********************\n");
	mcu_printf("\n");

	mcu_printf("hif_rx_packet_drop_cnt\n");
	dump_regs(0x680060, 0x4);

	mcu_printf("hif_rx_pkt_cnt1\n");
	dump_regs(0x6800bc, 0x4);

	mcu_printf("hif_rx_pkt_cnt2\n");
	dump_regs(0x6800c0, 0x4);

	mcu_printf("hif_tx_pkt_cnt1\n");
	dump_regs(0x68009c, 0x4);

	mcu_printf("hif_tx_pkt_cnt2\n");
	dump_regs(0x6800a0, 0x4);

	mcu_printf("hif_tx_state\n");
	dump_regs(0x680080, 0x4);

	mcu_printf("hif_tx_activ\n");
	dump_regs(0x680084, 0x4);

	mcu_printf("hif_tx_curr_ch_no\n");
	dump_regs(0x680088, 0x4);

	mcu_printf("hif_dxr_tx_fifo_cnt\n");
	dump_regs(0x68008c, 0x4);

	mcu_printf("hif_tx_ctrl_word_fifo_cnt1\n");
	dump_regs(0x680090, 0x4);

	mcu_printf("hif_tx_ctrl_word_fifo_cnt2\n");
	dump_regs(0x680094, 0x4);

	mcu_printf("hif_tx_bvalid_fifo_cnt\n");
	dump_regs(0x680098, 0x4);

	mcu_printf("hif_tx_bvalid_fifo_cnt\n");
	dump_regs(0x680098, 0x4);

	mcu_printf("hif_rx_state\n");
	dump_regs(0x6800a4, 0x4);

	mcu_printf("hif_rx_actv\n");
	dump_regs(0x6800a8, 0x4);

	mcu_printf("hif_rx_curr_ch_no\n");
	dump_regs(0x6800ac, 0x4);

	mcu_printf("hif_dxr_rx_fifo_cnt\n");
	dump_regs(0x6800b0, 0x4);

	mcu_printf("hif_rx_ctrl_word_fifo_cnt\n");
	dump_regs(0x6800b4, 0x4);

	mcu_printf("hif_rx_bvalid_fifo_cnt\n");
	dump_regs(0x6800b8, 0x4);
	
	mcu_printf("hif_ch0_int_src\n");
	dump_regs(0x681060, 0x4);

	mcu_printf("hif_bdp_ch0_tx_fifo_cnt\n");
	dump_regs(0x681090, 0x4);

	mcu_printf("hif_tx_dma_status_0_ch0\n");
	dump_regs(0x681094, 0x4);

	mcu_printf("hif_tx_status_0_ch0\n");
	dump_regs(0x681098, 0x4);

	mcu_printf("hif_tx_status_1_ch0\n");
	dump_regs(0x68109c, 0x4);

	mcu_printf("hif_tx_pkt_cnt0_ch0\n");
	dump_regs(0x6810a0, 0x4);

	mcu_printf("hif_tx_pkt_cnt1_ch0\n");
	dump_regs(0x6810a4, 0x4);

	mcu_printf("hif_tx_pkt_cnt2_ch0\n");
	dump_regs(0x6810a8, 0x4);

	mcu_printf("hif_bdp_ch0_rx_fifo_cnt\n");
	dump_regs(0x6810d0, 0x4);

	mcu_printf("hif_rx_dma_status_0_ch0\n");
	dump_regs(0x6810d4, 0x4);

	mcu_printf("hif_rx_status_0_ch0\n");
	dump_regs(0x6810d8, 0x4);

	mcu_printf("hif_rx_pkt_cnt0_ch0\n");
	dump_regs(0x6810dc, 0x4);

	mcu_printf("hif_rx_pkt_cnt1_ch0\n");
	dump_regs(0x6810e0, 0x4);

	mcu_printf("\n");
	mcu_printf("***************************** AXON EVM GMAC status**********************\n");

	mcu_printf("emac1_frames_rxed_ok\n");
	dump_regs(0x2d0780, 0x4);

	mcu_printf("emac2_frames_rxed_ok\n");
	dump_regs(0x2d4780, 0x4);

	mcu_printf("emac1_frames_txed_ok\n");
	dump_regs(0x2d0718, 0x4);
	
	mcu_printf("emac2_frames_txed_ok\n");
	dump_regs(0x2d4718, 0x4);
	
	mcu_printf("emac3_xmac1_2.5G_MAC_Rx_Tx_Status\n");	
	dump_regs(0x2d80b8, 0x4);

	mcu_printf("emac3_xmac1_2.5G_Tx_Packet_Count_Good_Bad_Low\n");	
	dump_regs(0x2d881c, 0x4);

	mcu_printf("emac3_xmac1_2.5G_Tx_Packet_Count_Good_Low\n");	
	dump_regs(0x2d888c, 0x4);

	mcu_printf("emac3_xmac1_2.5G_Rx_Packet_Count_Good_Bad_Low\n");	
	dump_regs(0x2d8900, 0x4);

	mcu_printf("emac3_xmac1_2.5G_Rx_Octet_Count_Good_Low\n");	
	dump_regs(0x2d8910, 0x4);

	mcu_printf("emac4_xmac0_5G_MAC_Rx_Tx_Status\n");	
	dump_regs(0x4d00b8, 0x4);

	mcu_printf("emac4_xmac0_5G_Tx_Packet_Count_Good_Bad_Low\n");	
	dump_regs(0x4d081c, 0x4);

	mcu_printf("emac4_xmac0_5G_Tx_Packet_Count_Good_Low\n");	
	dump_regs(0x4d088c, 0x4);

	mcu_printf("emac4_xmac0_5G_Rx_Packet_Count_Good_Bad_Low\n");	
	dump_regs(0x4d0900, 0x4);

	mcu_printf("emac4_xmac0_5G_Rx_Octet_Count_Good_Low\n");	
	dump_regs(0x4d0910, 0x4);

}

void dump_reg_xgmac_debug(int id)
{
	uint32 addr;

	mcu_printf("[%s]\n", __func__);
	if(id==0)
	{
		mcu_printf("XGMAC0-EMAC4 register dump\n");
		addr = 0x4D0000;
	}
	else if(id==1)
	{
		mcu_printf("XGMAC1-EMAC3 register dump\n");
		addr = 0x2D8000;
	}
	else
	{
		mcu_printf("Unsipported XGMAC number. Should be 0 or 1.\n");
		return;
	}

	/* offset 0x0 MAC_Tx_Configuration */
	dump_regs(addr+0x0000, 0x1000);
	//dump_regs(addr+0x0100, 0x100);

	/* offset 0x1000 MTL_Operation_Mode */
	dump_regs(addr+0x1000, 0x200);
	//dump_regs(addr+0x1100, 0x100);
}

