/**
 * @file MRVL_Q222X_MACsec.h
 * @brief Q222X MACsec API Header File
 * DUT MACsec configuration and status checking
 *
 * @par Copyright and Version
 * See MRVL_Q222X_Copyright_and_Version.h
 */

#ifndef MRVL_Q222X_MACSEC_H
#define MRVL_Q222X_MACSEC_H

#include "MRVL_Q222X_MACsecTypes.h"

/** @defgroup MACsec_Top MACsec control top-level group */

/******************************************************************************
 *      MAC 32 and 64 bits register access
 ******************************************************************************/

EXPORT_FUNC void q222x_readMACReg32(MRVL_DEV_PTR device, MRVL_APHY_U16 regAddr, MRVL_APHY_U32* data);

EXPORT_FUNC void q222x_readMACReg64(MRVL_DEV_PTR device, MRVL_APHY_U16 regAddr, MRVL_APHY_U64* data);

EXPORT_FUNC void q222x_writeMACReg32(MRVL_DEV_PTR device, MRVL_APHY_U16 regAddr, MRVL_APHY_U32 data);

EXPORT_FUNC void q222x_writeMACReg64(MRVL_DEV_PTR device, MRVL_APHY_U16 regAddr, MRVL_APHY_U64 data);

/******************************************************************************
 *      General Control for MACsec operation
 ******************************************************************************/
/** @defgroup MSC_CTRL MACsec General Control
 * @ingroup MACsec_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_initMACsec(MRVL_DEV_PTR device, MRVL_APHY_SPEED speed, MRVL_Q222X_MAC_POWER_MODE powerMode, MRVL_Q222X_MAC_FWD_MODE fwdMode);

EXPORT_FUNC MRVL_APHY_STATUS q222x_disableMACsec(MRVL_DEV_PTR device);

/******************************************************************************
 *      MMAC Control
 ******************************************************************************/
/** @defgroup MAC_CNFG MACsec Mode Configuration
 * @ingroup MACsec_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_softResetMMAC(MRVL_DEV_PTR device);

EXPORT_FUNC MRVL_APHY_STATUS q222x_configMMACPower(MRVL_DEV_PTR device, MRVL_APHY_BOOL isPowerup);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getIsMMACPowerup(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isPowerup);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setMMACInPath(MRVL_DEV_PTR device, MRVL_APHY_BOOL isInDatapath);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getIsMMACInPath(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isInDatapath);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setMACSpeed(MRVL_DEV_PTR device, MRVL_APHY_SPEED speed);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getMACSpeed(MRVL_DEV_PTR device, MRVL_APHY_SPEED* speed);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setMACPowerMode(MRVL_DEV_PTR device, MRVL_Q222X_MAC_POWER_MODE powerMode);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getMACPowerMode(MRVL_DEV_PTR device, MRVL_Q222X_MAC_POWER_MODE* powerMode);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setMACFwdMode(MRVL_DEV_PTR device, MRVL_Q222X_MAC_FWD_MODE mode);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getMACFwdMode(MRVL_DEV_PTR device, MRVL_Q222X_MAC_FWD_MODE* mode);

/******************************************************************************
 *      MACsec Operation Control
 ******************************************************************************/
/** @defgroup MSC_OP_CNFG MACsec OP Configuration
 * @ingroup MACsec_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_disableAllMACsecEntry(MRVL_DEV_PTR device);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setMACsecChannelEnable(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEnable);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getIsMACsecChannelEnable(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isEnable);

/******************************************************************************
 *      Rule
 ******************************************************************************/
/** @defgroup MSC_RULE_CNFG MACsec Rule Configuration
 * @ingroup MACsec_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_setMACsecRule(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_RULE* rule, MRVL_APHY_BOOL isEgress);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getMACsecRule(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_Q222X_MSEC_RULE* rule, MRVL_APHY_BOOL isEgress);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setMACsecRuleEnable(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_APHY_BOOL isEgress, MRVL_APHY_BOOL isEnable);

/******************************************************************************
 *      SecY Map
 ******************************************************************************/
/** @defgroup MSC_SECY_MAP_CNFG MACsec SecY Map Configuration
 * @ingroup MACsec_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_setRxSecYMap(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_Q222X_MSEC_RX_SECY_MAP* secyMap);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getRxSecYMap(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_Q222X_MSEC_RX_SECY_MAP* secyMap);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setTxSecYMap(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_Q222X_MSEC_TX_SECY_MAP* secyMap);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getTxSecYMap(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_Q222X_MSEC_TX_SECY_MAP* secyMap);

/******************************************************************************
 *      SecY
 ******************************************************************************/
/** @defgroup MSC_SECY_CNFG MACsec SecY Configuration
 * @ingroup MACsec_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_setRxSecY(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_RX_SECY* secy);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getRxSecY(MRVL_DEV_PTR device, MRVL_APHY_U8 secyIndex, MRVL_Q222X_MSEC_RX_SECY* secy);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setTxSecY(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_TX_SECY* secy);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getTxSecY(MRVL_DEV_PTR device, MRVL_APHY_U8 secyIndex, MRVL_Q222X_MSEC_TX_SECY* secy);

/******************************************************************************
 *      SC
 ******************************************************************************/
/** @defgroup MSC_SC_CNFG MACsec SC Configuration
 * @ingroup MACsec_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_setRxSC(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_RX_SC* rxSC);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getRxSC(MRVL_DEV_PTR device, MRVL_APHY_U8 rxscIndex, MRVL_Q222X_MSEC_RX_SC* rxSC);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setTxSC(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_TX_SC* txSC);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getTxSC(MRVL_DEV_PTR device, MRVL_APHY_U8 txscIndex, MRVL_Q222X_MSEC_TX_SC* txSC);

/******************************************************************************
 *      SA and Key
 ******************************************************************************/
/** @defgroup MSC_SA_CNFG MACsec SA and Key Configuration
 * @ingroup MACsec_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_configSAKLockout(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_APHY_BOOL isEnable);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setRxSA(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_RX_SA* rxSA);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getRxSA(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_Q222X_MSEC_RX_SA* rxSA);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setTxSA(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_TX_SA* txSA);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getTxSA(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_Q222X_MSEC_TX_SA* txSA);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setRxSAPolicy(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_Q222X_MSEC_RX_SA_PLCY* saPlcy);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getRxSAPolicy(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_Q222X_MSEC_RX_SA_PLCY* saPlcy);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setTxSAPolicy(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_Q222X_MSEC_TX_SA_PLCY* saPlcy);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getTxSAPolicy(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_Q222X_MSEC_TX_SA_PLCY* saPlcy);

/******************************************************************************
 *      PN and PN Threshold
 ******************************************************************************/
/** @defgroup MSC_PN_TH_CNFG MACsec PN and PN Threshold Configuration
 * @ingroup MACsec_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_setRxSANextPN(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_APHY_U64 pn);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setTxSANextPN(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_APHY_U64 pn);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getRxSACurrentPN(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_APHY_U64* pn);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getTxSACurrentPN(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_APHY_U64* pn);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setRxPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U32 pnThreshold);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setRxXPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U64 pnThreshold);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getRxPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U32* pnThreshold);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getRxXPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U64* pnThreshold);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setTxPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U32 pnThreshold);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setTxXPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U64 pnThreshold);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getTxPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U32* pnThreshold);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getTxXPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U64* pnThreshold);

/******************************************************************************
 *      Default SCI
 ******************************************************************************/
/** @defgroup MSC_SCI_CNFG MACsec Default SCI Configuration
 * @ingroup MACsec_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_setDefaultSCI(MRVL_DEV_PTR device, MRVL_APHY_U64 sci);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getDefaultSCI(MRVL_DEV_PTR device, MRVL_APHY_U64* sci);

/******************************************************************************
 *      Statistics
 ******************************************************************************/
/** @defgroup MSC_STATS_CTRL MACsec Statistics Control
 * @ingroup MACsec_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_getRxSMCStats(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_RX_SMC_STATS* stats);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getTxSMCStats(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_TX_SMC_STATS* stats);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getRxWMCStats(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_RX_WMC_STATS* stats);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getTxWMCStats(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_TX_WMC_STATS* stats);

EXPORT_FUNC MRVL_APHY_STATUS q222x_clearMIBStats(MRVL_DEV_PTR device);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getRxSecYStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_RX_SECY_COUNTER* stats);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getTxSecYStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_TX_SECY_COUNTER* stats);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getRxSCStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_RX_SC_COUNTER* stats);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getTxSCStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_TX_SC_COUNTER* stats);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getRxMACsecPortStats(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_RX_PORT_COUNTER* stats);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getTxMACsecPortStats(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_TX_PORT_COUNTER* stats);

EXPORT_FUNC MRVL_APHY_STATUS q222x_resetAllMACsecStats(MRVL_DEV_PTR device);

EXPORT_FUNC MRVL_APHY_STATUS q222x_clearRxSecYStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index);

EXPORT_FUNC MRVL_APHY_STATUS q222x_clearTxSecYStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index);

EXPORT_FUNC MRVL_APHY_STATUS q222x_clearRxSCStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index);

EXPORT_FUNC MRVL_APHY_STATUS q222x_clearTxSCStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index);

/******************************************************************************
 *      Custom/VLAN Tag
 ******************************************************************************/
/** @defgroup MSC_TAG_CNFG MACsec Custom/VLAN Tag Configuration
 * @ingroup MACsec_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_setCustomVLANTag(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_Q222X_MSEC_CUSTOM_TAG* tag);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getCustomVLANTag(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_CUSTOM_TAG* tag);

/******************************************************************************
 *      Control Packet
 ******************************************************************************/
/** @defgroup MSC_CTRL_PCKT_CNFG MACsec Control Packet Configuration
 * @ingroup MACsec_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_setCtrlPckt_EthType(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_Q222X_MSEC_CTRL_PCKT_ETYPE* classification);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getCtrlPckt_EthType(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_CTRL_PCKT_ETYPE* classification);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setCtrlPckt_DA(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_Q222X_MSEC_CTRL_PCKT_DA* classification);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getCtrlPckt_DA(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_CTRL_PCKT_DA* classification);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setCtrlPckt_DARange(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_Q222X_MSEC_CTRL_PCKT_DA_RANGE* classification);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getCtrlPckt_DARange(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_CTRL_PCKT_DA_RANGE* classification);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setCtrlPckt_COMBO(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_Q222X_MSEC_CTRL_PCKT_COMBO* classification);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getCtrlPckt_COMBO(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_CTRL_PCKT_COMBO* classification);


#endif  /* defined MRVL_Q222X_MACSEC_H */
