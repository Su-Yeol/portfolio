/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          reg_hal.h
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    all user defined wrapper functions
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifndef REG_HAL_H
#define REG_HAL_H

#ifdef __linux__
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");
#endif

/**********************************************************************
 *                                     Include Files
 **********************************************************************/
#include "sal_com.h"

#define DEFAULT_TABLE (3)

/*****************************************************************
 * Function Name  : InitBaseAddr()
 * Description    : Set base address of EPP memory.
 * Inputs
 *   Parameters   : uint32a
 * Outputs        :
 *   Parameters   : -
 *   Returns      : uint32a
 * Changes        :
 ****************************************************************/
/*inline*/
void InitBaseAddr(void *BaseAddr);

/*****************************************************************
 * Function Name  : GetBaseAddr()
 * Description    : Get base address of EPP memory.
 * Inputs
 *   Parameters   : uint32a
 * Outputs        :
 *   Parameters   : -
 *   Returns      : uint32a
 * Changes        :
 ****************************************************************/
/*inline*/
void *GetBaseAddr(void);


/*****************************************************************
 * Function Name  : RegRead()
 * Description    : Hardware register read function return register
 *                  read value for given address.
 * Inputs
 *   Parameters   : uint32a
 * Outputs        :
 *   Parameters   : -
 *   Returns      : uint32a
 * Changes        :
 ****************************************************************/
/*inline*/
uint32a RegRead(uint32 Register);

/******************************************************************
 * Function Name  : RegWrite()
 * Description    : Hardware register write function Write given value
 *                  in given address.
 * Inputs
 *   Parameters   : uint32a, uint32a
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *****************************************************************/
/*inline*/
void RegWrite(uint32 Register, uint32a RegData);

/* read from absolute address */
uint32a RegAbsRead(uint32 Register);

/* write to absolute address */
void RegAbsWrite(uint32 Register, uint32a RegData);

#if 0 /*TSNC node : comment out to avoid error "declared but never defined" */
/*****************************************************************
 * Function Name  : RegReadOffset()
 * Description    : Hardware register read function return register
 *                  read value for given address.
 * Inputs
 *   Parameters   : uint32a
 * Outputs        :
 *   Parameters   : -
 *   Returns      : uint32a
 * Changes        :
 ****************************************************************/
inline uint32a RegReadOffset(uint32 Register, uint32a Offset);

/******************************************************************
 * Function Name  : RegWriteOffset()
 * Description    : Hardware register write function Write given value
 *                  in given address.
 * Inputs
 *   Parameters   : uint32a, uint32a
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *****************************************************************/
inline void RegWriteOffset(uint32 Register, uint32 Offset, uint32a RegData);
#endif

/*****************************************************************
 * Function Name  : TableRead()
 * Description    : Hardware register read function return register
 *                  read value for given address.
 * Inputs
 *   Parameters   : uint32a
 * Outputs        :
 *   Parameters   : -
 *   Returns      : uint32a
 * Changes        :
 ****************************************************************/
uint32a TableRead(uint32 offset, int32a table);

/******************************************************************
 * Function Name  : TableWrite()
 * Description    : Hardware register write function Write given value
 *                  in given address.
 * Inputs
 *   Parameters   : uint32a, uint32a
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *****************************************************************/
void TableWrite(uint32 offset, uint32a value, int32a table);
//==============================================================================
void ClearStatus(uint32a status_reg, uint32a clear_value);
uint32a CommandWait(uint32a status_reg, uint32a wait_for);
void IssueCommand_nowait(uint32a cmd_reg, uint32a command);
uint32a IssueCommand(uint32a cmd_reg,
				uint32a command,
				uint32a status_reg,
				uint32a wait_for);
uint32a IssueCommand_CS(uint32a cmd_reg,
				uint32a command,
				uint32a status_reg,
				uint32a wait_for,
				uint32a clear_value);
//==============================================================================
void ClearStatusTable(uint32a status_reg,
				uint32a clear_value,
				uint32a table_num);
uint32a CommandWaitTable(uint32a status_reg,
				uint32a wait_for,
				uint32a table_num);
void IssueCommandTable_nowait(uint32a cmd_reg,
				uint32a command,
				uint32a table_num);
uint32a IssueCommandTable(uint32a cmd_reg,
				uint32a command,
				uint32a status_reg,
				uint32a wait_for,
				uint32a table_num);
uint32a IssueCommandTable_CS(uint32a cmd_reg,
					uint32a command,
					uint32a status_reg,
					uint32a wait_for,
					uint32a clear_value,
					uint32a table_num);
//==============================================================================


/* return value : read value,
         or (-1) if busy_flag timeout */
int32a MdioRegRead(uint32a emac_idx, uint32a phy_addr, uint32a reg_addr);

/* return value : written value,
         or (-1) if busy_flag timeout */
int32a MdioRegWrite(uint32a emac_idx, uint32a phy_addr, uint32a reg_addr, uint32a phy_data);

/* return value : < 0, busy_flag timeout expired
                  otherwise, read value */
int32a XMdioRegRead(uint32a emac_idx, uint32a phy_addr, uint32a dev_addr, uint32a reg_addr);

/* return value : < 0, busy_flag timeout expired
                  otherwise, written value */
int32a XMdioRegWrite(uint32a emac_idx, uint32a phy_addr, uint32a dev_addr, uint32a reg_addr, uint32a phy_data);


#endif
