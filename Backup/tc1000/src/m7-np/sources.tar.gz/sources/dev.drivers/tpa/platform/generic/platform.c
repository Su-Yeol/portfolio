// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          platform.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    Functions to handle different hardware platforms
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                      Include Files
 **********************************************************************/
#include <linux/pci.h>
#include <linux/netdevice.h>

#include "fp_net_driver.h"	/* brings in "struct fp_private" */
#include "fp_pci_driver.h"	/* brings in "DRV_NAME" */
#include "reg_hal.h"		/* brings in "InitBaseAddr()" */
#include "platform.h"

struct net_device  *fp_netdev_init(uint8 *membase, uint32a irq);

static struct memconfig config[5];

/**********************************************************************
 * Function Name  : platform_init
 * Description    : platform specific network device initialisation
 * Inputs
 *   Parameters   : struct pci_dev *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
int32a platform_init(struct pci_dev *pdev)
{
	int32a rc = 0;
	int32a c;
	struct net_device *dev;
	struct fp_private *fppriv;

	for (c=0; c<5; c++) {
		// clear the memory before we start
		memset(&config[c],0,sizeof(struct memconfig));
	}
	// set up the arrays for this specific platform
	config[0].start = pci_resource_start(pdev, 0);
	config[0].end   = pci_resource_end(pdev, 0);
	config[0].len   = pci_resource_len(pdev, 0);
	config[0].valid = 1;
	config[1].start = pci_resource_start(pdev, 1);
	config[1].end   = pci_resource_end(pdev, 1);
	config[1].len   = pci_resource_len(pdev, 1);
	config[1].valid = 1;
	rc = pci_request_regions(pdev, DRV_NAME);
	if (rc) {
		printk("\n Can't obtain PCI resources");
		pci_disable_device(pdev);
		pci_set_drvdata(pdev, NULL);
		return 0;
	}
	rc = pci_set_dma_mask(pdev, DMA_BIT_MASK(32));
	if (rc) {
		printk("No usable DMA configuration");
		pci_release_regions(pdev);
		return 0;
	}
	rc = pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(32));
	if (rc) {
		printk("Consistent DMA not available\n");
		pci_release_regions(pdev);
		return 0;
	}
	pci_set_master(pdev);
	pci_enable_msi(pdev);
	config[1].membase = ioremap_nocache(config[1].start, config[1].len);
	InitBaseAddr(config[1].membase);
	dev = fp_netdev_init(config[1].membase, pdev->irq);
	if (dev != NULL)
	{
		pci_set_drvdata(pdev, dev);
		fppriv = netdev_priv(dev);
		fppriv->pci_dev = pdev;
		return 1;	// return success
	}
	pci_set_drvdata(pdev, NULL);
	return 0;	// return fail;
}

/**********************************************************************
 * Function Name  : platform_dma_alloc
 * Description    : get dma allocation done for this specific platform
 * Inputs
 *   Parameters   : - offset
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void *platform_dma_alloc(uint32a ch_id,
			uint32a  total_ring_size,
			struct device *pdev,
			dma_addr_t    *pdev_addr,
			gfp_t         gfp)
{
	size_t size = total_ring_size;
	return dma_alloc_coherent(pdev, size, pdev_addr, GFP_ATOMIC);
}

/**********************************************************************
 * Function Name  : platform_start
 * Description    : write non-EPP registers in memory space to start or
 *                  configure the specific platform
 * Inputs
 *   Parameters   : -
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void platform_start()
{
	; // add code specific to the platform start here
}

/**********************************************************************
 * Function Name  : platform_clear_interrupt
 * Description    : clear platform interrupts ( if needed )
 * Inputs
 *   Parameters   : -
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void platform_clear_interrupt()
{
	; // add code specific to the platform interrupt clearing here
}
