/**
 * @file MRVL_Q222X_TC10Types.h
 * @brief Q222X TC10 Types Header File
 * Header file contains TC10 types and defines of Marvell Q222X
  *
 * @par Copyright and Version
 * See MRVL_Q222X_Copyright_and_Version.h
 */

#ifndef MRVL_Q222X_TC10_TYPES_H
#define MRVL_Q222X_TC10_TYPES_H

#include "MRVL_Q222X_Types.h"

/* TC10 Register and value */
#define MRVL_Q222X_TC10_CONTROL_DEVICE		3U
#define MRVL_Q222X_TC10_ENABLE_REG_100		0x8707U
#define MRVL_Q222X_TC10_ENABLE_REG_1000		0x8027U
#define MRVL_Q222X_TC10_CONTROL_REG_100		0x8702U
#define MRVL_Q222X_TC10_CONTROL_REG_1000	0x8022U
#define MRVL_Q222X_TC10_CONTROL_SLEEP		0x1U
#define MRVL_Q222X_TC10_CONTROL_WAKE		0x10U
#define MRVL_Q222X_TC10_CONTROL_ABORT		0x2U
#define MRVL_Q222X_TC10_CONTROL_CLEAR		0x0U

#define MRVL_Q222X_TC10_STATUS_REG_100		0x8703U
#define MRVL_Q222X_TC10_STATUS_REG_1000		0x8023U

#define MRVL_Q222X_TC10_POWER_DEVICE			4U
#define MRVL_Q222X_TC10_POWER_REG				0xFD21U
#define MRVL_Q222X_TC10_POWER_REMOVE_ENABLE		0x10U
#define MRVL_Q222X_TC10_POWER_REMOVE_DISABLE	0x0U

/**
 * @brief Define TC10 status Enum
 *
 */
typedef enum {
	MRVL_Q222X_TC10_OPNORMAL = 0,          /*!< phy is in normal operation */
	MRVL_Q222X_TC10_SLEEP = 1,             /*!< is in TC10 sleep */
	MRVL_Q222X_TC10_SLEEP_FAILED = 2,      /*!< sleep failed */
	MRVL_Q222X_TC10_REQUEST_ABORTED = 4,   /*!< sleep request has been aborted */
	MRVL_Q222X_TC10_UNKNOWN                /*!< unknow status */
} MRVL_Q222X_TC10_STATUS;

#endif  /* MRVL_Q222X_TC10_TYPES_H */
