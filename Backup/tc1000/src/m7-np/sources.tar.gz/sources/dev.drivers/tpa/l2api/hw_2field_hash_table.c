// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          hw_2field_hash_table.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    routines for mac hash add, del, update and search
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

/*********************************************************************
*                           Include files
*********************************************************************/
#include "reg_hal.h"
#include "fp_library.h"
#include "fp_switch.h"
#include "global_address_map_fpga.h"
#include "hw_2field_hash_table.h"

#define FAIL_RETRY_FIX

static int32a hif_channel_num = 0;		// value set by writing to /proc/HIF_channel

#if 0
/**********************************************************************
* Function Name  : hw_init_mac_reg
* Description    : Initialize Mac Table with given filed params
* Inputs
* Parameters   : -
* Returns      :
* Changes        :
************************************************************************/
static void hw_init_mac_reg(uint32a field_entries[5], uint32a action_entry)
{
	/*volatile uint32a *addr = 0; */
	/* Base address of hash block takes only last byte i.e 0xc2 */
	/*addr = (uint32a *)CLASS_BUS_ACCESS_BASE_ADDR;
	*addr = PE_AHB1_BASE_ADDR;*/
	/*Writing mac address*/
	TableWrite(MAC_HASH_HOST_MAC1_ADDR_REG, ntohl(field_entries[0]), DEFAULT_TABLE);
	TableWrite(MAC_HASH_HOST_MAC2_ADDR_REG, (field_entries[1] & 0xFFFF0000) | ntohs(field_entries[1]), DEFAULT_TABLE);
	TableWrite(MAC_HASH_HOST_MAC3_ADDR_REG, ntohl(field_entries[2]), DEFAULT_TABLE);
	TableWrite(MAC_HASH_HOST_MAC4_ADDR_REG, ntohl(field_entries[3]), DEFAULT_TABLE);
	/*
	TableWrite(MAC_HASH_HOST_MAC5_ADDR_REG, field_entries[4]);
	*/
}

static void hw_init_mac_reg_table(uint32a field_entries[5], uint32a action_entry, uint32a table_num)
{
	/*volatile uint32a *addr = 0; */
	/* Base address of hash block takes only last byte i.e 0xc2 */
	/*addr = (uint32a *)CLASS_BUS_ACCESS_BASE_ADDR;
	*addr = PE_AHB1_BASE_ADDR;*/
	/*Writing mac address*/
	TableWrite(MAC_HASH_HOST_MAC1_ADDR_REG, ntohl(field_entries[0]), table_num);
	TableWrite(MAC_HASH_HOST_MAC2_ADDR_REG, (field_entries[1] & 0xFFFF0000) | ntohs(field_entries[1]), table_num);
	TableWrite(MAC_HASH_HOST_MAC3_ADDR_REG, ntohl(field_entries[2]), table_num);
	TableWrite(MAC_HASH_HOST_MAC4_ADDR_REG, ntohl(field_entries[3]), table_num);
	/*
	TableWrite(MAC_HASH_HOST_MAC5_ADDR_REG, field_entries[4]);
	*/
}
#endif

/**********************************************************************
* Function Name  : hw_hash_table_search
* Description    : Search Mac Hash Table with given Mac Address
* Inputs
* Parameters   : - Mac Address and VLAN ID is Optional
* Globals      : -
* Outputs        :
*  Parameters  : -
* Returns      :   Returns Entry Values if Search Found
* Changes        :
************************************************************************/
int32a hw_hash_table_search(uint32a field_entries[5], uint32a field_valids)
{
	int32a match_done = 0;
	int32a cmd_done = 0;
	int32a entry = 0;
	/* initialize MAC regs */
#ifdef FAIL_RETRY_FIX
	int32a retries = 5;
	do {
#endif







//	hw_init_mac_reg(field_entries, 0);







	cmd_done = IssueCommand_CS(	MAC_HASH_HOST_CMD_REG,
					( CMD_SEARCH
					| (field_valids & CMD_ENTRY_FIELD_VALID_MASK)),
					MAC_HASH_HOST_STATUS_REG,
					STATUS_CMD_DONE,
					CLR_STATUS_REG);
	match_done = cmd_done;
	/*Bridge entry match done check*/
/*
	printk("cmd_done = %x done = %s, found = %s\n",
		cmd_done,
		(cmd_done & STATUS_CMD_DONE)    ? "TRUE" : "FALSE",
		(cmd_done & STATUS_ENTRY_MATCH) ? "TRUE" : "FALSE");
*/
	if (cmd_done & STATUS_CMD_DONE) {
		if(cmd_done & STATUS_ENTRY_MATCH) {
			/* SEARCH FOUND */
			match_done = TableRead(MAC_HASH_HOST_ENTRY_REG, DEFAULT_TABLE);
			entry = match_done & MAC_2F_ACTION_ENTRY_MASK;
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "%s: entry = %x\n",
								__func__, entry);
			/* Clear req entry reg */
			TableWrite(MAC_HASH_HOST_ENTRY_REG, 0x0, DEFAULT_TABLE);
			return entry;
		} else {
			/* SEARCH NOT FOUND */
#ifdef FAIL_RETRY_FIX
			if (retries > 0)
			{
/*
				printk("retrying = %i\n",retries);
*/
				retries--;
				continue;
			}
#endif
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_EMERG, "CMD_SEARCH Not found\n");
			return -1;
		}
	} else {
		/* COMMAND FAILED */
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_EMERG, "CMD_SEARCH failed  (incomplete)\n");
		return -2;
	}
#ifdef FAIL_RETRY_FIX
	} while (1);
#endif
	return 0;
} /*End of hw_hash_table_search() Function*/

/**********************************************************************
* Function Name  : hw_hash_table_add
* Description    : Add given Mac Entry into MAC HASH TABLE
* Inputs
* Parameters   : - Mac Address and bridge entry pointer
* Globals      : -
* Outputs        :
*  Parameters  : -
* Returns      :   Returns Entry Add Status
* Changes        :
************************************************************************/
static int32a __hw_hash_table_add(uint32a field_entries[5], uint32a iport, uint32a brentry, uint32a field_valids, uint32a table_num)
{
	int32a cmd_done = 0;
	int32a chan_num = hif_channel_num;



	/* initialize MAC regs */
//	hw_init_mac_reg_table(field_entries, brentry, table_num);





	TableWrite(MAC_HASH_HOST_ENTRY_REG, brentry | ((chan_num & 0x1) << 31), table_num);
	TableWrite(MAC_HASH_HOST_DIRECT_REG, (chan_num >> 0x1), table_num);

	/* Description of ADD CMD REG:
	* 3:0   - CMD
	* 7:4   - Reserved
	* 8     - DMAC Field Valid
	* 9     - Vlan Field Valid
	* 15:10 - Reserved
	* 31:16 - Mem Index
	*/
	/* Issue ADD cmd */
	cmd_done = IssueCommandTable_CS(
				MAC_HASH_HOST_CMD_REG,
				( CMD_ADD | field_valids ),
				MAC_HASH_HOST_STATUS_REG,
				STATUS_CMD_DONE,
				CLR_STATUS_REG,
				table_num);
	if (cmd_done & STATUS_CMD_DONE) {
		if(cmd_done & STATUS_ENTRY_ADDED) {
			/* FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "ADD CMD DONE\n");
			Entry Added Successfully */
			/* update hash entry count for cli */
			fp_rc_stats.hw_hash_entry_count++;
			return 0;
		} else {
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_EMERG, "ADD CMD FAILED\n");
			return -1;
		}
	} else {
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_EMERG, "ADD CMD FAILED  (incomplete)\n");
		return -2;
	}
	return 0;
}

int32a hw_hash_table_add(uint32a field_entries[5], uint32a iport, uint32a brentry, uint32a field_valids)
{
	if(__hw_hash_table_add(field_entries, iport, brentry, field_valids, 1) == -1)
		return -1;
	return __hw_hash_table_add(field_entries, iport, brentry, field_valids, 3);
}

/**********************************************************************
* Function Name  : hw_hash_table_delete
* Description    : Delete given Mac Entry from MAC HASH TABLE
* Inputs
* Parameters   : - Mac Address
* Globals      : -
* Outputs        :
*  Parameters  : -
* Returns      :   Returns Entry Delete Status
* Changes        :
**********************************************************************/
static int32a __hw_hash_table_delete(uint32a entry1, uint32a entry2, uint32a table_num)
{
//	uint32a  field_entries[5];
	uint32a  field_valids = BIT_SET_MAC_2F_MACTBL;

#if 0
	field_entries[0] = entry1;
	field_entries[1] = entry2;
	field_entries[2] = 0;
	field_entries[3] = 0;
	field_entries[4] = 0;
#endif
	field_valids |= BIT_SET_VLAN_2F_MACTBL;




	/* initialize MAC regs */
//	hw_init_mac_reg_table(field_entries, 0, table_num);





	/* Issue DEL cmd */
	IssueCommandTable_CS(	MAC_HASH_HOST_CMD_REG,
				( CMD_DEL | field_valids ),
				MAC_HASH_HOST_STATUS_REG,
				STATUS_CMD_DONE,
				CLR_STATUS_REG,
				table_num);
	return 0;
}

int32a hw_hash_table_delete(uint32a entry1, uint32a entry2)
{
	if(__hw_hash_table_delete(entry1, entry2, 1) == -1)
		return -1;
	return __hw_hash_table_delete(entry1, entry2, 3);
}

/**********************************************************************
* Function Name  : hw_hash_table_update
* Description    : Update given BRENTRY PTR into HASH MAC TABLE
* Inputs
* Parameters   : - Mac Address and brentry
* Globals      : -
* Outputs        :
*  Parameters  : -
* Returns      :   Returns Entry Update Status
* Changes        :
**********************************************************************/
static int32a __hw_hash_table_update(uint32a field_entries[5],	uint32a brentry, uint32a field_valids, uint32a table_num)
{
	int32a cmd_done = 0;



	/* initialize mac regs */
//	hw_init_mac_reg_table(field_entries, brentry, table_num);







	/* fill ENTRY reg if valid */
	TableWrite(MAC_HASH_HOST_ENTRY_REG, brentry, table_num);
	/* Issue UPDATE cmd */
	cmd_done = IssueCommandTable_CS(
				MAC_HASH_HOST_CMD_REG,
				( CMD_UPDATE
				| (field_valids & CMD_ENTRY_FIELD_VALID_MASK)),
				MAC_HASH_HOST_STATUS_REG,
				STATUS_CMD_DONE,
				CLR_STATUS_REG,
				table_num);
	if (cmd_done & STATUS_CMD_DONE) {
		if(cmd_done & STATUS_ENTRY_ADDED) {
			/* Entry Added/Updated Successfully */
			// Update table2 if enabled
			return 0;
		} else {
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_EMERG, "UPDATE CMD - Not successful\n");
			return -1;
		}
	} else {
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_EMERG, "UPDATE CMD failed (incomplete)\n");
		return -2;
	}
	return 0;
}

int32a hw_hash_table_update(uint32a field_entries[5], uint32a brentry, uint32a field_valids)
{
	if(__hw_hash_table_update(field_entries, brentry, field_valids, 1) == -1)
		return -1;
	return __hw_hash_table_update(field_entries, brentry, field_valids, 3);
}

/**********************************************************************
* Function Name  : hw_hash_table_init
* Description    : Initialize MAC HASH TABLE & VLAN HASH TABLE
*                  Initialize the hash collision space
*                  chain the collision space
*                  init the free head, list pointers and no of entries
*                  All initialize done through register programming only
* Inputs
* Parameters   : packet_t * - contains packet header data
* Globals      : -
* Outputs        :
*  Parameters   : -
* Returns      : int
* Changes        :
************************************************************************/
void hw_hash_table_init(uint32a table_num)
{
	uint32a index = 0, mac_table_addr = 0, col_ptr = 0, i = 0;

/* 2-field Mac table format: Table Depth - 8192(hash 4096 + collison 4096)
*============================================================================*
* valid bits | col_ptr | portNO | field_valids | action entry |vlanid |MAC *
*============================================================================*
* 4-bit      | 16-bit  | 4-bit  | 8-bit        | 31-bit       |13-bit |48-bit *
*============================================================================*/
	TPA_D("HASH INIT START\r\n");

	/* INIT CMD: Init total Hash Space with zeros */
	IssueCommandTable_CS(MAC_HASH_HOST_CMD_REG,
				CMD_INIT,
				MAC_HASH_HOST_STATUS_REG,
				STATUS_CMD_DONE,
				CLR_STATUS_REG,
				table_num);

	TPA_D("HASH INIT DONE\r\n");

	/* initialize mac addresses */
	TableWrite(MAC_HASH_HOST_MAC1_ADDR_REG, 0x0, table_num);
	TableWrite(MAC_HASH_HOST_MAC2_ADDR_REG, 0x0, table_num);
	TableWrite(MAC_HASH_HOST_MAC3_ADDR_REG, 0x0, table_num);
	TableWrite(MAC_HASH_HOST_MAC4_ADDR_REG, 0x0, table_num);
	TableWrite(MAC_HASH_HOST_MAC5_ADDR_REG, 0x0, table_num);
	TableWrite(MAC_HASH_HOST_ENTRY_REG, 0x0, table_num);

	/* chain the collision space */
	for(i = 0; i < TWO_FIELD_COLL_ENTRIES; i++)
	{
		/* 32bit: 4res + 4validbits + 16colptr + 4portnum + (4)part of fieldvalids */
		col_ptr = (0x40201 + i) << 8;
		TableWrite(MAC_HASH_HOST_MAC4_ADDR_REG, col_ptr, table_num);
		index = TWO_FIELD_HASH_ENTRIES + i;
		mac_table_addr = (index << 16) + CMD_MEM_WRITE;
		IssueCommandTable_CS(MAC_HASH_HOST_CMD_REG,
					mac_table_addr,
					MAC_HASH_HOST_STATUS_REG,
					STATUS_CMD_DONE,
					CLR_STATUS_REG,
					table_num);
	} /*End of for loop collision space*/

	/* Intialize Free List Head Ptr */
	TableWrite(MAC_HASH_FREELIST_PTR_HEAD, TWO_FIELD_INIT_HEAD_PTR, table_num);

	/* Initialize Free List Ptr */
	TableWrite(MAC_HASH_FREELIST_PTR_TAIL, TWO_FIELD_INIT_TAIL_PTR, table_num);

	/* Initialize No of entries */
	TableWrite(MAC_HASH_FREELIST_ENTRIES_ADDR, TWO_FIELD_COLL_ENTRIES, table_num);

	/* Clear Status Reg */
	TableWrite(MAC_HASH_HOST_STATUS_REG, CLR_STATUS_REG, table_num);

	TPA_D("MAC CHAIN HASH INIT DONE\r\n");
} /*end of hw_hash_table_init() Function*/

void proc_SetHifnum(uint32a num)
{
	hif_channel_num = num;
}

#if 0 /* org code cause unhandeld page fault. so replace to telechips code */
size_t proc_GetHifnum(int8 __user *ubuf,size_t buf_max)
{
	size_t len;
	size_t ofs = 0;
	len = snprintf((ubuf+ofs),buf_max,"%i\n",hif_channel_num);
	return len;
}

size_t proc_GetHifCounts(int8 __user *ubuf,size_t buf_max)
{
	size_t len;
	size_t ofs = 0;
	int32a port;
//	for (port = HIF_BASE_ADDR+0x10;port < HIF_BASE_ADDR+0xf0;port+=0x10) {
	for (port = 0;port < 16;port++) {
		int32a address = HIF_BASE_ADDR+(0x1000 *port)+0x1000;
		uint32a count1 = RegRead(address+0xdc);
		uint32a count2 = RegRead(address+0xe0);
		len = snprintf((ubuf+ofs),buf_max-ofs,"Chan %2i -- %4i  %4i\n",port,count1,count2);
		ofs += len;
		if (ofs > (buf_max -20)) {
			break;
		}
	}
	return ofs;
}
#else
uint32a proc_GetHifnum(void)
{
	return hif_channel_num;
}

int32a proc_GetHifCounts(uint32a *cnt_array)
{
	int32a ret=0;
	int32a port;

	if(cnt_array != NULL)
	{
		for (port = 0;port < 16;port++) {
			int32a address = HIF_BASE_ADDR+(0x1000*port)+0x1000;
			uint32a count1 = RegRead(address+0xdc);
			uint32a count2 = RegRead(address+0xe0);
			int32a index;

			index = port<<1;
			cnt_array[index]   = count1;
			cnt_array[index+1] = count2;
		}
	}
	else
	{
		ret = -1;
	}

	return ret;
}
#endif


/*********************** End of File **********************/

