/**
 * @file MRVL_AMG_REG_PMP.h
 * @brief Marvell Multi-gig Automotive Ethernet PHY PMP register defines
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */

#ifndef MRVL_AMG_REG_PMP_H
#define MRVL_AMG_REG_PMP_H

/* PMP_MMD Register Address */
#define MRVL_AMG_PMP_CR_CLK_RST_CTRL_CG_PMP    0x407C2000U  /* PMP_MMD.COMMON_REGISTER.CLOCK_RESET.GATES.CTRL_CG_PMP */
#define MRVL_AMG_PMP_CR_HW_CFG_CTRL_HW         0x407C2780U  /* PMP_MMD.COMMON_REGISTER.HW_CONFIG.CTRL_HW */


#endif  /* defined MRVL_AMG_REG_PMP */
