/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          fp_pktbuff.h
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    contains packet buff data structures
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

#ifndef	_FP_PKTBUFF_H_
#define	_FP_PKTBUFF_H_

#include "fp_interface.h"
#include "fp_macros.h"

/* macros for differnent memory allocation pools */
#define	HASHSIZE		12
#define	POOLSIZE		10
#define	RAW_BUFF_SIZE		256
#define	PKTBUFF_SIZE		2048
#define	BRIDGE_POOLSIZE		10
#define	ROUTER_POOLSIZE		10

#define	MIN_IP_HEADER_LENGTH	5

/*******************************************************************************
   PACKET BUFFER STRUCTURE

The packet will be splitted into two parts
    1. First segment of the packet ( 128bytes + 8 bytes of header )
        - CPCPCP 112 bytes of packet data (Ethernet Packet) and 16 bytes of
    header (Internal Structure)
    2. Second segment of the packet ( remaining data + 8 bytes of header )

  Classifier can have max of 4 first segements to do classification

  Before classification
      -------------------------
      |   pktBuff             |
      -------------------------
      |   |    |_____________________________________________________________________
      |    -------------------------------|                                          |
      -------------------------------------------------------------------------------
      |  room for pre-pkt(128bytes) | 12bytes header |   116bytes pkt headers        |
      -------------------------------------------------------------------------------

     CPCPCP 16 bytes of header in the above figure. and 112 bytes of packet header

  After classification
      -------------------------
      |   pktBuff             |
      -------------------------
      |   |    |_____________________________________________________________________
      |    -------------------------------|                                          |
      -------------------------------------------------------------------------------
      |  room for pre-pkt(128bytes) | 12bytes header |   116bytes pkt headers        |
      | Buffer Desc
      -------------------------------------------------------------------------------
*****************************************************************************************************/

typedef struct _pktBuf_t_ {
	/*Buffer related members*/
	void		*pNextBuf;	/*pointer to next buffer of the packet*/
	int8		*pDataStart;
	int8		*pDataEnd;
	int8		*pBufStart;
	int8		*pBufEnd;
	uint16	dataLen;
	uint16	totaldataLen;
	/* packet parsing related members*/
	void		*pLayer2Hdr;
	void		*pLayer3Hdr;
	void		*pLayer4Hdr;
	void		*pAppHdr;
	/*flags are set during on packet parsing*/
	uint32a	parseFlags;
	/* classifier related members*/
	uint32a	classFlags;
	void		*pL2MatchEntry;
	void		*pV4MatchEntry;
	void		*pV6MatchEntry;
	uint16	l2Hash;
	uint16	v4hash;
	uint16	v6hash;
	uint16	ifParseFlags;
	/*input action related members
	output action related members
	vendor related members*/
	void		*pVendorInfo;
	uint32a	mediaInfo;	/*contains VPVC, GEMID, SSID etc.*/
	uint16	ifnum,sid;
	/* unified */
	uint16	phyno,fid_index;
	uint16	vlanid;		/* using for egr vlan membership */
	/*port related members*/
	fp_phyPort_t	*pRxPhyPort;	/* receved physical port*/
	fp_IfData_t	*pRxIfPort;	/* Interface RX port*/
	/*trace information*/
	void     *tracePtr;		/* for debugging purpose*/
} pktBuf_t;				// 88bytes

/*******************************************************************************
 The Classifier Engine has 4 Classfiier buffers and each of size about 256bytes.
 First 128 bytes of data is store into classifier buffer and the remaining
 packet will be stored in DDR memory. Below is the structure format for the
 classifier buffer.
 ******************************************************************************/
typedef struct _bd_clbuf_t_ {
	uint8	num_cpy;	// no of copies to sent out from RO block
	uint8	dma_len;	// len to be DMAed to DDR mem
	uint16	src_addr;	// class buf address
	uint32a	dst_addr;	// DDR memory address
	uint32a	res1;		// reserved 1
	uint16	res2;		// reserved 2
	uint16	tsv;		// time stamp val
} bd_clbuf_t;				// 16 bytes

typedef struct _postPktClsHdr_t_ {
	uint8	start_data_off;	// data start offset
	uint8	start_buf_off;	// buffer start offset
	uint16	pkt_length;	// total packet lenght
	uint8	act_phy;	// action block 7:4 and phyno 3:0
	uint8	queueno;
	uint16	src_mac_msb;	// indicates src_mac 47:32
	uint32a	src_mac_lsb;	// indicates src_mac 31:0
	uint32a	vlanid;		// vlanid
} postPktClsHdr_t;

typedef struct _postPktClsMcastHdr_t_ {
	uint8 start_data_off;	// data start offset
	uint8 start_buf_off;	// buffer start offset
	uint16 pkt_length;	// total packet lenght
	uint8 act_phy;		// action block 7:4 and phyno 3:0
	uint8 queueno;
	uint16 src_mac_msb;	// indicates src_mac 47:32
	uint32a src_mac_lsb;	// indicates src_mac 31:0
	uint32a vlanid;		// vlanid
} postPktClsMcastHdr_t;

typedef struct _packet_t_ {
	bd_clbuf_t	bdClassBuf;
	uint8	headroom[FP_CLSBUF_HEADROOM];
	struct packet_t	*next_ptr;	// ptr to the start of buffer in DDR memory
	uint16	length;		// total packet lenght
	uint16	phyno;		// physical port number
	void		*fp_ptr;	// reserved
	uint32a	res;		// reserved
#ifdef HW_LMEM_ONLY
	uint32a	res1[4];	// reserved
#endif
	uint8	hdr_data[FP_CLASS_DATASIZE];	//First segment of packet
} packet_t;
/*Structres as per hardware design*/
typedef struct _hwparse_t {
	uint16		sid;
	uint16		connid;
	uint8		toevec;
	uint8		pLayer2Hdr;
	uint8		pLayer3Hdr;
	uint8		pLayer4Hdr;
	uint16		vlanid;
	uint16		ifParseFlags;
	uint32a		parseFlags;
	uint16		srcport;
	uint16		dstport;
	uint32a		proto:8;
	uint32a		port:4;
	uint32a		hash:20;
	uint64	rte_res_valid:1;
	uint64	vlan_res_valid:1;
	uint64	dst_res_valid:1;
	uint64	src_res_valid:1;
	uint64	vlan_lookup:20;
	uint64	dst_lookup:20;
	uint64	src_lookup:20;
}hwparse_t;

int32a fp_rx_packet (packet_t *pkt_ptr);
int32a fp_tx_packet (pktBuf_t *pktBuf, uint8 port_cnt, uint8 *port_list);

/* packet buffer allocation function */
pktBuf_t* pkt_buff_alloc(void);

/* link layer parsing function */
extern int32a fp_linklayer_parsing(pktBuf_t *pkt_buff);

/* interface match */
extern int32a fp_interface_match(pktBuf_t *pkt_buff);

/* init function for fastpath */
extern int32a fastPathInit(void);

extern int32a fp_send_packet_host(pktBuf_t *pkt_buff);

extern void fp_linux_tx_packet(uint8 phyPortNum, pktBuf_t *pktBuf, uint32a clone);

#endif /*End of _FP_PKTBUFF_H_ File*/

