// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_acl_api.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    Functions to configure ACL entries
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

/**********************************************************************
 *                                      Include Files
 **********************************************************************/
#include "reg_hal.h"
#include "fp_acl_api.h"


/* Adjust mac address in the acl table entry */
static void reverse_mac(uint8 *ptr)
{
	uint8 temp, i;
	for (i = 0; i < 3; i++)
	{
		temp = ptr[i];
		ptr[i] = ptr[5 - i];
		ptr[5 - i] = temp;
	}
}

/* Adjust the mac addresses according to the h/w expected format */
static void adjust_mac_addresses(struct acl_entry *acl)
{
	reverse_mac(&acl->src_mac[0]);
	reverse_mac(&acl->dst_mac[0]);
	reverse_mac(&acl->mask_src_mac[0]);
	reverse_mac(&acl->mask_dst_mac[0]);
}

#ifdef THIS_DUPLICATES_ADD_ENTRY_
/* Function to initialize the acl table with 0s */
int32a fp_acl_add_invalid_entry(uint32a id, struct acl_entry *acl, uint32a table_num)
{
	uint32a cmd_done;
	uint32a cmd;
	adjust_mac_addresses(acl);
#if 0
if(id == 0)
{
acl->fwd_port_list = 0x70;
//acl->fwd_port_list = 0x400;
acl->action = 0;
acl->valid = 1;
printk("adding  valid entry\n");
}
#endif
	TableWrite(ACL_ENTRY_STATUS_REG, 0xf, table_num);
	TableWrite(ACL_ENTRY_DATA_REG0,  acl->Reg0 , table_num);
	TableWrite(ACL_ENTRY_DATA_REG1,  acl->Reg1 , table_num);
	TableWrite(ACL_ENTRY_DATA_REG2,  acl->Reg2 , table_num);
	TableWrite(ACL_ENTRY_DATA_REG3,  acl->Reg3 , table_num);
	TableWrite(ACL_ENTRY_DATA_REG4,  acl->Reg4 , table_num);
	TableWrite(ACL_ENTRY_DATA_REG5,  acl->Reg5 , table_num);
	TableWrite(ACL_ENTRY_DATA_REG6,  acl->Reg6 , table_num);
	TableWrite(ACL_ENTRY_DATA_REG7,  acl->Reg7 , table_num);
	TableWrite(ACL_ENTRY_DATA_REG8,  acl->Reg8 , table_num);
	TableWrite(ACL_ENTRY_DATA_REG9,  acl->Reg9 , table_num);
	TableWrite(ACL_ENTRY_DATA_REG10, acl->Reg10, table_num);
	TableWrite(ACL_ENTRY_DATA_REG11, acl->Reg11, table_num);
	/* Submit ADD command */
	cmd = (id << ACL_ENTRY_CMD_ID_SHIFT_POS) | ACL_ENTRY_CMD_ADD;
	cmd_done = IssueCommandTable_CS(
				ACL_ENTRY_CMD_CNTRL_REG,
				cmd,
				ACL_ENTRY_STATUS_REG,
				ACL_ENTRY_STATUS_CMD_DONE,
				0xF,
				table_num);
/*
	printk("%s -- cmd_done = %x done = %s, success = %s\n",
		__FUNCTION__, cmd_done,
		(cmd_done & ACL_ENTRY_STATUS_CMD_DONE) ? "TRUE" : "FALSE",
		(cmd_done & ACL_ENTRY_SUCCESS)         ? "TRUE" : "FALSE");
*/
/* According to the TRM the ACL_ENTRY_SUCCESS flag should get set,
 * but it never does
 */
	if (cmd_done & ACL_ENTRY_STATUS_CMD_DONE) {
		return 0;
	} else {
		pr_err("ACL_ENTRY_CMD_ADD - failed\n");
		return -1;
	}
}
#endif
/*!
 Add an ACL entry into ACL table

 @param   id              ACL entry index in the ACL table
 @param   struct acl_entry  acl entry to be added
 @return status code:       0=success, -1=entry not added -2=command failed
 */

static int32a __fp_acl_add_entry(uint32a id, struct acl_entry *acl, uint32a table_num)
{
	uint32a cmd_done;
	uint32a cmd;

	TableWrite(ACL_ENTRY_STATUS_REG, 0xf, table_num);
	TableWrite(ACL_ENTRY_DATA_REG0,  acl->Reg0,  table_num);
	TableWrite(ACL_ENTRY_DATA_REG1,  acl->Reg1,  table_num);
	TableWrite(ACL_ENTRY_DATA_REG2,  acl->Reg2,  table_num);
	TableWrite(ACL_ENTRY_DATA_REG3,  acl->Reg3,  table_num);
	TableWrite(ACL_ENTRY_DATA_REG4,  acl->Reg4,  table_num);
	TableWrite(ACL_ENTRY_DATA_REG5,  acl->Reg5,  table_num);
	TableWrite(ACL_ENTRY_DATA_REG6,  acl->Reg6,  table_num);
	TableWrite(ACL_ENTRY_DATA_REG7,  acl->Reg7,  table_num);
	TableWrite(ACL_ENTRY_DATA_REG8,  acl->Reg8,  table_num);
	TableWrite(ACL_ENTRY_DATA_REG9,  acl->Reg9,  table_num);
	TableWrite(ACL_ENTRY_DATA_REG10, acl->Reg10, table_num);
	TableWrite(ACL_ENTRY_DATA_REG11, acl->Reg11, table_num);
	/* Submit ADD command */
	cmd = (id << ACL_ENTRY_CMD_ID_SHIFT_POS) | ACL_ENTRY_CMD_ADD;
	cmd_done = IssueCommandTable_CS(
				ACL_ENTRY_CMD_CNTRL_REG,
				cmd,
				ACL_ENTRY_STATUS_REG,
				ACL_ENTRY_STATUS_CMD_DONE,
				0xF,
				table_num);
/*
	printk("%s -- cmd_done = %x done = %s, success = %s, added = %s\n",
		__FUNCTION__, cmd_done,
		(cmd_done & ACL_ENTRY_STATUS_CMD_DONE) ? "TRUE" : "FALSE",
		(cmd_done & ACL_ENTRY_SUCCESS)         ? "TRUE" : "FALSE",
		(cmd_done & ACL_ENTRY_ADDED)           ? "TRUE" : "FALSE");
*/
/* According to the TRM the ACL_ENTRY_SUCCESS flag should get set,
 * but it never does
 */
	if (cmd_done & ACL_ENTRY_STATUS_CMD_DONE) {
		if(cmd_done & ACL_ENTRY_ADDED) {
			return 0;
		} else {
			TPA_E("ACL entry NOT added\n");
			return -1;
		}
	} else {
		TPA_E("ACL_ENTRY_CMD_ADD command failed\n");
		return -2;
	}
	return 0;
}

int32a fp_acl_add_entry(uint32a id, struct acl_entry *acl)
{
	adjust_mac_addresses(acl);
	acl->valid = 1;
	if(__fp_acl_add_entry(id, acl, 1) == -1)
		return -1;
	return __fp_acl_add_entry(id, acl, 3);
}

/*!
 Delete an ACL entry

 @param           id   ACL entry index in the ACL table
 @return status code   0=success, -1=failure
 **/
static int32a __fp_acl_del_entry(uint32a id, uint32a table_num)
{
	uint32a cmd_done;
	uint32a cmd;
	ClearStatusTable(ACL_ENTRY_STATUS_REG, 0xF, table_num);
	/* Submit DEL command */
	cmd = (id << ACL_ENTRY_CMD_ID_SHIFT_POS) | ACL_ENTRY_CMD_DEL;
	cmd_done = IssueCommandTable_CS(
				ACL_ENTRY_CMD_CNTRL_REG,
				cmd,
				ACL_ENTRY_STATUS_REG,
				ACL_ENTRY_STATUS_CMD_DONE,
				0xF,
				table_num);
/*
	printk("%s -- cmd_done = %x done = %s, success = %s\n",
		__FUNCTION__, cmd_done,
		(cmd_done & ACL_ENTRY_STATUS_CMD_DONE) ? "TRUE" : "FALSE",
		(cmd_done & ACL_ENTRY_SUCCESS)         ? "TRUE" : "FALSE");
*/
/* According to the TRM the ACL_ENTRY_SUCCESS flag should get set, but it never does
 */
	if (cmd_done & ACL_ENTRY_STATUS_CMD_DONE) {
		return 0;
	} else {
		pr_err("ACL_ENTRY_CMD_DEL failed (incomplete)\n");
		return -1;
	}
	return 0;
}

int32a fp_acl_del_entry(uint32a id)
{
	if(__fp_acl_del_entry(id, 1) == -1)
		return -1;
	return __fp_acl_del_entry(id, 3);
}

/*!
 Get an ACL entry

 @param   id              ACL entry index in the ACL table
 @param   struct acl_entry  acl entry to be read into
 @return  status code:    0=success, -1=failure -2=EPP failed to set done flag
 */

int32a fp_acl_get_entry(uint32a id, struct acl_entry *acl)
{
	uint32a cmd_done;
	uint32a cmd;

	TableWrite(ACL_ENTRY_DATA_REG0,  0x0, DEFAULT_TABLE);
	TableWrite(ACL_ENTRY_DATA_REG1,  0x0, DEFAULT_TABLE);
	TableWrite(ACL_ENTRY_DATA_REG2,  0x0, DEFAULT_TABLE);
	TableWrite(ACL_ENTRY_DATA_REG3,  0x0, DEFAULT_TABLE);
	TableWrite(ACL_ENTRY_DATA_REG4,  0x0, DEFAULT_TABLE);
	TableWrite(ACL_ENTRY_DATA_REG5,  0x0, DEFAULT_TABLE);
	TableWrite(ACL_ENTRY_DATA_REG6,  0x0, DEFAULT_TABLE);
	TableWrite(ACL_ENTRY_DATA_REG7,  0x0, DEFAULT_TABLE);
	TableWrite(ACL_ENTRY_DATA_REG8,  0x0, DEFAULT_TABLE);
	TableWrite(ACL_ENTRY_DATA_REG9,  0x0, DEFAULT_TABLE);
	TableWrite(ACL_ENTRY_DATA_REG10, 0x0, DEFAULT_TABLE);
	TableWrite(ACL_ENTRY_DATA_REG11, 0x0, DEFAULT_TABLE);
	TableWrite(ACL_ENTRY_STATUS_REG, 0xF, DEFAULT_TABLE);
	/* Submit GET command */
	cmd = (id << ACL_ENTRY_CMD_ID_SHIFT_POS) | ACL_ENTRY_CMD_GET;
	cmd_done = IssueCommand_CS(	ACL_ENTRY_CMD_CNTRL_REG,
					cmd,
					ACL_ENTRY_STATUS_REG,
					ACL_ENTRY_STATUS_CMD_DONE,
					0xF);
/*
	printk("ACL cmd_done = %x done = %s, found = %s\n",
		cmd_done,
		(cmd_done & ACL_ENTRY_STATUS_CMD_DONE)    ? "TRUE" : "FALSE",
		(cmd_done & ACL_ENTRY_SUCCESS) ? "TRUE" : "FALSE");
*/
/* According to the TRM the ACL_ENTRY_SUCCESS flag should get set,
 * but it never does
 */
	if (cmd_done & ACL_ENTRY_STATUS_CMD_DONE) {
		/* set iport and vlan id */
		acl->Reg0  = TableRead(ACL_ENTRY_DATA_REG0, DEFAULT_TABLE);
		acl->Reg1  = TableRead(ACL_ENTRY_DATA_REG1, DEFAULT_TABLE);
		acl->Reg2  = TableRead(ACL_ENTRY_DATA_REG2, DEFAULT_TABLE);
		acl->Reg3  = TableRead(ACL_ENTRY_DATA_REG3, DEFAULT_TABLE);
		acl->Reg4  = TableRead(ACL_ENTRY_DATA_REG4, DEFAULT_TABLE);
		acl->Reg5  = TableRead(ACL_ENTRY_DATA_REG5, DEFAULT_TABLE);
		acl->Reg6  = TableRead(ACL_ENTRY_DATA_REG6, DEFAULT_TABLE);
		acl->Reg7  = TableRead(ACL_ENTRY_DATA_REG7, DEFAULT_TABLE);
		acl->Reg8  = TableRead(ACL_ENTRY_DATA_REG8, DEFAULT_TABLE);
		acl->Reg9  = TableRead(ACL_ENTRY_DATA_REG9, DEFAULT_TABLE);
		acl->Reg10 = TableRead(ACL_ENTRY_DATA_REG10, DEFAULT_TABLE);
		acl->Reg11 = TableRead(ACL_ENTRY_DATA_REG11, DEFAULT_TABLE);
		adjust_mac_addresses(acl);
	} else {
		pr_err("ACL_ENTRY_CMD_GET - failed\n");
		return -1;
	}
	return 0;
}

/* Initialize ACL table */
void fp_acl_table_init()
{
	int32a id = 0;
	struct acl_entry acl_entry;

	SAL_MemSet(&acl_entry, 0, sizeof(acl_entry));
	for(id = 0; id < 64; id++)
	{
		SAL_MemSet(&acl_entry, 0, sizeof(struct acl_entry));
		__fp_acl_add_entry(id, &acl_entry, 3);
		__fp_acl_add_entry(id, &acl_entry, 1);
	}
}
