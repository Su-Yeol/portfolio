/**
 * @example MRVL_AMG_Sample_Code.c
 * Sample code to show possible use cases of PHY mode and status API.
 * User should adapt based on individual system requirements.
 *
 * - API init sample:
 * @code
 * Sample_Code_Assign_Device_PTR
 * @endcode
 *
 * - PHY mode configuration samples:
 * @code
 * Sample_Code_Init
 * Sample_Code_Check
 * @endcode
 *
 * @copyright
 * Copyright (c) 2023 Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement by and between
 * Marvell and you, your employer or other entity on behalf of whom you act.
 * In the absence of such license agreement the following file is subject to
 * Marvell’s standard Limited Use License Agreement.
 */

#include <stdint.h>
#include <string.h>
#include "MRVL_porting.h"
#include "MRVL_AMG_API.h"
#include "reg_hal.h"
#include "MRVL_MVQ3244_API.h"

#define DUT_PHY_ADDR 0
#define DUT_SMI_PORT 0
#define DUT_OPMODE MRVL_APHY_OP_SLAVE//MRVL_APHY_OP_MASTER
#define DUT_SPEED_T1 MRVL_APHY_SPEED_2P5G//MRVL_APHY_SPEED_10G
#define DUT_SPEED_SerDes MRVL_APHY_SERDES_2P5G_BASEX//MRVL_APHY_SERDES_10G_BASER


/** prototype **/
static MRVL_APHY_STATUS Sample_Code_readReg(MRVL_DEV_PTR phy, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16* data);
static MRVL_APHY_STATUS Sample_Code_writeReg(MRVL_DEV_PTR phy, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16 data);
static MRVL_APHY_STATUS Sample_Code_wait(MRVL_DEV_PTR phy, MRVL_APHY_U16 delayTime);
static MRVL_APHY_STATUS Sample_Code_Assign_Device_PTR(MRVL_DEV_PTR DUT);
MRVL_APHY_STATUS Sample_Code_Init(MRVL_DEV_PTR DUT);
MRVL_APHY_STATUS Sample_Code_Check(MRVL_DEV_PTR DUT);

/** @defgroup Sample_Top Sample Codes */

/**
 * @brief Read out a 16-bit value from a register through SMI interface CL45.
 *
 * @param phy
 * @param portAddr port address, Q111X has single port, portAddr is equvalent to phy->phyAddr
 * @param devAddr device address/MMD (Ex: 0x07 : Auto-Neg registers)
 * @param regAddr register address within MMD
 * @param data 16-bit to write into register
 * @return MRVL_APHY_STATUS
 */
static MRVL_APHY_STATUS Sample_Code_readReg(MRVL_DEV_PTR phy, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16* data)
{
	MRVL_APHY_STATUS ret = MRVL_APHY_STATUS_OK;
	int32_t readValue;
	uint32_t emac_idx;

	(void)ret;

	/* system-dependent Implementation */
	/* e.g. *data = XMDIOReadRegister(portAddr, devAddr, regAddr); */

	/* TC configuration :
		88Q2220(1Gbps)	  : emac_idx = 1, phy_addr = 5
		88Q2220(1Gbps)	  : emac_idx = 2, phy_addr = 5   (MDIO inteface of emac2 and emac3 are tied)
		MV_Q3244(2.5Gbps) : emac_idx = 3, phy_addr = 0
		88Q5192(5Gbps,switch) : emac_idx = 4, phy_addr = ?
	*/
	emac_idx = phy->smiPort-1;
	readValue = XMdioRegRead(emac_idx, portAddr, devAddr, regAddr);
	if(readValue<0)
	{
		/* if error return MRVL_APHY_STATUS_ERROR_MDIO */
		ret = MRVL_APHY_STATUS_ERROR_MDIO;
	}
	else
	{
		*data = (uint16_t)readValue;
	}	return MRVL_APHY_STATUS_OK;

	/* if error return MRVL_APHY_STATUS_ERROR_MDIO */
}

/**
 * @brief  Write a 16-bit value from a register through SMI interface CL45.
 *
 * @param phy
 * @param portAddr port address, Q111X has single port, portAddr is equvalent to phy->phyAddr
 * @param devAddr device address/MMD (Ex: 0x07 : Auto-Neg registers)
 * @param regAddr register address within MMD
 * @param data 16-bit to write into register
 * @return MRVL_APHY_STATUS
 */
static MRVL_APHY_STATUS Sample_Code_writeReg(MRVL_DEV_PTR phy, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16 data)
{
	/* system-dependent Implementation */
	/* e.g. *data = XMDIOWriteRegister(portAddr, devAddr, regAddr); */

	MRVL_APHY_STATUS ret = MRVL_APHY_STATUS_OK;
	int32_t writtenValue;
	uint32_t emac_idx;

	(void)ret;
	/* system-dependent Implementation */
	/* e.g. *data = XMDIOWriteRegister(portAddr, devAddr, regAddr); */
	emac_idx = phy->smiPort-1;
	writtenValue = XMdioRegWrite(emac_idx, portAddr, devAddr, regAddr, data);
	if(writtenValue<0)
	{
		/* if error return MRVL_APHY_STATUS_ERROR_MDIO */
		ret = MRVL_APHY_STATUS_ERROR_MDIO;
	}

	return MRVL_APHY_STATUS_OK;
	/* if error return MRVL_APHY_STATUS_ERROR_MDIO */
}

/**
 * @brief Delay for specified number of milliseconds.
 *
 * @param phy
 * @param delayTime delay to implement
 * @return MRVL_APHY_STATUS
 */
static MRVL_APHY_STATUS Sample_Code_wait(MRVL_DEV_PTR phy, MRVL_APHY_U16 delayTime)
{
	/* system-dependent Implementation */
	MRVL_PRINT_DEBUG("delay %dms\n", delayTime);
	udelay(10);

	return MRVL_APHY_STATUS_OK;
}


/******************************************************************************
 *      The following functions demonstrate possible use cases
 * 		of basic PHY Control API.
 ******************************************************************************/
/** @defgroup Sample_PHY Sample - PHY CTRL Demo
 * @ingroup Sample_Top
*/

/**
 * @brief Sample code before system initialization: detect device
 *
 * @param[in,out] DUT
 * @return MRVL_APHY_STATUS
 *
 * @ingroup Sample_PHY
 */
static MRVL_APHY_STATUS Sample_Code_Assign_Device_PTR(MRVL_DEV_PTR DUT)
{
	MRVL_APHY_STATUS status;
	/* 1) assign ptr */
	//DUT->smiPort = DUT_SMI_PORT;
	//DUT->phyAddr = DUT_PHY_ADDR;
	/* use XMDIO interface */
	DUT->use32Bit = MRVL_APHY_FALSE;
	DUT->readReg = Sample_Code_readReg;
	DUT->writeReg = Sample_Code_writeReg;
	DUT->wait = Sample_Code_wait;
	status = MRVL_AMG_GetDeviceInfo(DUT);
	if (status != MRVL_APHY_STATUS_OK) {
		MRVL_AMG_DBG_INFO("Device initialization is not yet done.\n");
	}
	return status;
}

/**
 * @brief Sample code during system initialization: init device and check status
 *
 * @param[in,out] DUT
 * @return MRVL_APHY_STATUS
 *
 * @ingroup Sample_PHY
 */
MRVL_APHY_STATUS Sample_Code_Init(MRVL_DEV_PTR DUT) {
	MRVL_APHY_STATUS status;
	/* 1) Call Sample_Code_Assign_Device_PTR if device has not been checked */
	status = Sample_Code_Assign_Device_PTR(DUT);

	/* 2) OPTIONAL: override mode and speed */
	status = MRVL_AMG_T1_SetMasterSlaveStatus(DUT, /*DUT_OPMODE*/DUT->op_mode);
	status |= MRVL_AMG_T1_SetSpeed(DUT, /*DUT_SPEED_T1*/DUT->t1_speed);
	status |= MRVL_AMG_SerDes_SetSpeed(DUT, /*DUT_SPEED_SerDes*/DUT->sd_speed);
	status |= MRVL_AMG_T1_RestartLineLink(DUT);
	status |= MRVL_AMG_SerDes_RestartSysLink(DUT);
	MRVL_AMG_DBG_INFO("Update device configurations\n");
	return status;
}
/**
 * @brief Sample code during system initialization: init device and check status
 *
 * @param[in,out] DUT
 * @return MRVL_APHY_STATUS
 *
 * @ingroup Sample_PHY
 */
MRVL_APHY_STATUS Sample_Code_Check(MRVL_DEV_PTR DUT)
{
	MRVL_AMG_FirmwareInfo fwInfo;
	MRVL_AMG_LinkStatus link;
	MRVL_AMG_Polarity polarity;
	MRVL_APHY_OPERATION_MODE mode;
	MRVL_APHY_SPEED speedT1;
	MRVL_APHY_SERDES_SPEED speedSerDes;
	MRVL_AMG_SNR snr;

	(void)fwInfo;
	/* 1) Call Sample_Code_Assign_Device_PTR if device has not been checked */
	//Sample_Code_Assign_Device_PTR(DUT);

	/* 2) check T1 status */
	MRVL_AMG_T1_GetLinkStatus(DUT, &link);
	MRVL_AMG_T1_GetLinkStatus(DUT, &link); //latched link, read twice to clear previous link status
	if (link != MRVL_AMG_LINK_UP) {
		MRVL_AMG_DBG_INFO("T1: link is not up\n");
		MRVL_AMG_T1_GetPolarity(DUT, &polarity);
		if (MRVL_AMG_POLARITY_REVERSED == polarity) {
			MRVL_AMG_DBG_INFO("T1: reversed polarity\n");
		}
		return MRVL_APHY_STATUS_ERROR_GENERAL;
	}
	MRVL_AMG_DBG_INFO("T1 link is up\n");
	MRVL_AMG_T1_GetMasterSlaveStatus(DUT, &mode);
	MRVL_AMG_T1_GetSpeed(DUT, &speedT1);
	MRVL_AMG_T1_GetSNR(DUT, &snr);
	switch (speedT1) {
	case MRVL_APHY_SPEED_2P5G:
		MRVL_AMG_DBG_INFO("T1: speed 2.5G\n");
		break;
	case MRVL_APHY_SPEED_5G:
		MRVL_AMG_DBG_INFO("T1: speed 5G\n");
		break;
	case MRVL_APHY_SPEED_10G:
		MRVL_AMG_DBG_INFO("T1: speed 10G\n");
		break;
	default:
		MRVL_AMG_DBG_INFO("T1: speed Unknow\n");
		return MRVL_APHY_STATUS_ERROR_GENERAL;
	}
	MRVL_AMG_DBG_INFO("T1: mode %s\n", mode == MRVL_APHY_OP_MASTER ? "MASTER" : "SLAVE");
	MRVL_AMG_DBG_INFO("T1: SNR %f\n", snr.snrOperatingMargin);

	/* 3) check SerDes status */
	MRVL_AMG_SerDes_GetLinkStatus(DUT, &link);
	MRVL_AMG_SerDes_GetLinkStatus(DUT, &link); //latched link, read twice to clear previous link status
	if (link != MRVL_AMG_LINK_UP) {
		MRVL_AMG_DBG_INFO("SerDes: link is not up\n");
		MRVL_AMG_T1_GetPolarity(DUT, &polarity);
		if (MRVL_AMG_POLARITY_REVERSED == polarity) {
			MRVL_AMG_DBG_INFO("SerDes: reversed polarity\n");
		}
		return MRVL_APHY_STATUS_ERROR_GENERAL;
	}
	MRVL_AMG_DBG_INFO("SerDes link is up\n");
	MRVL_AMG_SerDes_GetSpeed(DUT, &speedSerDes);
	switch (speedSerDes) {
	case MRVL_APHY_SERDES_2500_BASEX:
		MRVL_AMG_DBG_INFO("SerDes: speed 2500 BaseX\n");
		break;
	case MRVL_APHY_SERDES_2P5G_BASEX:
		MRVL_AMG_DBG_INFO("SerDes: speed 2.5G BaseX\n");
		break;
	case MRVL_APHY_SERDES_5000_BASER:
		MRVL_AMG_DBG_INFO("SerDes: speed 5000 BaseR\n");
		break;
	case MRVL_APHY_SERDES_5G_BASER:
		MRVL_AMG_DBG_INFO("SerDes: speed 5G BaseR\n");
		break;
	case MRVL_APHY_SERDES_5G_USXGMII:
		MRVL_AMG_DBG_INFO("SerDes: speed 5G USXGMII\n");
		break;
	case MRVL_APHY_SERDES_10G_BASER:
		MRVL_AMG_DBG_INFO("SerDes: speed 10G BaseR\n");
		break;
	case MRVL_APHY_SERDES_10G_USXGMII:
		MRVL_AMG_DBG_INFO("SerDes: speed 10G USXGMII\n");
		break;
	default:
		MRVL_AMG_DBG_INFO("SerDes: speed Unknow\n");
		return MRVL_APHY_STATUS_ERROR_GENERAL;
	}

	return MRVL_APHY_STATUS_OK;
}

/* 2.5G - XGMAC1 - EMAC3 */
MRVL_DEV mrvlDev_e3;

/* 5G - XGMAC0 - EMAC4 */
MRVL_DEV mrvlDev_e4;

int PHY_MVQ3244_Init(int xgmac_index)
{
	MRVL_APHY_STATUS ret;
	(void)ret;

	if(xgmac_index==1) /* 2.5G - XGMAC1 - EMAC3 */
	{
		MRVL_AMG_DBG_INFO("\n[%s] PHY mvq3244 for for 2.5G - XGMAC1 - EMAC3\n", __func__);
		memset(&mrvlDev_e3, 0, sizeof(MRVL_DEV));
		mrvlDev_e3.phyAddr = 0x00;
		mrvlDev_e3.smiPort = 1; //emac number 1~4, xgmac1 mdio line is connected to gmac1 mdio
		mrvlDev_e3.t1_speed = MRVL_APHY_SPEED_2P5G;
		mrvlDev_e3.sd_speed = MRVL_APHY_SERDES_2P5G_BASEX;
		mrvlDev_e3.op_mode = MRVL_APHY_OP_SLAVE;
		ret = Sample_Code_Init(&mrvlDev_e3);
	}
	else if(xgmac_index==0) /* 5G - XGMAC0 - EMAC4 */
	{
		MRVL_AMG_DBG_INFO("\n[%s] PHY mvq3244 for for 5G - XGMAC0 - EMAC4\n", __func__);
		memset(&mrvlDev_e4, 0, sizeof(MRVL_DEV));
		mrvlDev_e4.phyAddr = 0x00;
		mrvlDev_e4.smiPort = 2; //emac number 1~4, xgmac0 mdio line is connected to gmac0 mdio
		mrvlDev_e4.t1_speed = MRVL_APHY_SPEED_5G;
//		mrvlDev_e4.sd_speed = MRVL_APHY_SERDES_5G_USXGMII;
		mrvlDev_e4.sd_speed = MRVL_APHY_SERDES_5G_BASER;
		mrvlDev_e4.op_mode = MRVL_APHY_OP_SLAVE;
		ret = Sample_Code_Init(&mrvlDev_e4);
	}
	else
	{
		MRVL_AMG_DBG_ERROR("\n[%s] PHY Unsupported index=%d, should be 0 or 1.\n", __func__, index);
	}

	return 0;
}

int PHY_MVQ3244_Check(int xgmac_index)
{
	MRVL_APHY_STATUS ret;
	(void)ret;

	if(xgmac_index==1) /* 2.5G - XGMAC1 - EMAC3 */
	{
		ret = Sample_Code_Check(&mrvlDev_e3);
	}
	else if(xgmac_index==0) /* 5G - XGMAC0 - EMAC4 */
	{
		ret = Sample_Code_Check(&mrvlDev_e4);
	}
	else
	{
		MRVL_AMG_DBG_ERROR("\n[%s] PHY Unsupported index=%d, should be 0 or 1.\n", __func__, index);
	}

	return 0;
}

