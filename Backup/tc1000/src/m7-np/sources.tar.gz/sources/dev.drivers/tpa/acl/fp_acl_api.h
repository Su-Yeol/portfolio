/* SPDX-License-Identifier: (GPL-2.0 WITH Linux-syscall-note) AND MIT */

/*************************************************************************/ /*!
@File
@Title          fp_acl_api.h
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    API to configure ACL entries
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#ifndef  _FP_ACL_API_H_
#define  _FP_ACL_API_H_

#include "global_address_map_fpga.h"

/* ACL Registers */
#if 1
#define ACL_ENTRY_DATA_REG0	(ACL_ENTRY_BASE_ADDR)
#define ACL_ENTRY_DATA_REG1	(ACL_ENTRY_BASE_ADDR + 0x4)
#define ACL_ENTRY_DATA_REG2	(ACL_ENTRY_BASE_ADDR + 0x8)
#define ACL_ENTRY_DATA_REG3	(ACL_ENTRY_BASE_ADDR + 0x10)
#define ACL_ENTRY_DATA_REG4	(ACL_ENTRY_BASE_ADDR + 0x14)
#define ACL_ENTRY_DATA_REG5	(ACL_ENTRY_BASE_ADDR + 0x18)
#define ACL_ENTRY_DATA_REG6	(ACL_ENTRY_BASE_ADDR + 0x1C)
#define ACL_ENTRY_DATA_REG7	(ACL_ENTRY_BASE_ADDR + 0x20)
#define ACL_ENTRY_DATA_REG8	(ACL_ENTRY_BASE_ADDR + 0x24)
#define ACL_ENTRY_DATA_REG9	(ACL_ENTRY_BASE_ADDR + 0x28)
#define ACL_ENTRY_DATA_REG10	(ACL_ENTRY_BASE_ADDR + 0x2C)
#define ACL_ENTRY_DATA_REG11	(ACL_ENTRY_BASE_ADDR + 0x30)
#define ACL_ENTRY_CMD_CNTRL_REG	(ACL_ENTRY_BASE_ADDR + 0x34)
#define ACL_ENTRY_STATUS_REG	(HOST_ACL_ENTRY_STATUS_REG_ADDR)
#else
#define ACL_ENTRY_DATA_REG0	ACL_ENTRY_DATA_REG0_ADDR
#define ACL_ENTRY_DATA_REG1	ACL_ENTRY_DATA_REG1_ADDR
#define ACL_ENTRY_DATA_REG2	ACL_ENTRY_DATA_REG2_ADDR
#define ACL_ENTRY_DATA_REG3	ACL_ENTRY_DATA_REG3_ADDR
#define ACL_ENTRY_DATA_REG4	ACL_ENTRY_DATA_REG4_ADDR
#define ACL_ENTRY_DATA_REG5	ACL_ENTRY_DATA_REG5_ADDR
#define ACL_ENTRY_DATA_REG6	ACL_ENTRY_DATA_REG6_ADDR
#define ACL_ENTRY_DATA_REG7	ACL_ENTRY_DATA_REG7_ADDR
#define ACL_ENTRY_DATA_REG8	ACL_ENTRY_DATA_REG8_ADDR
#define ACL_ENTRY_DATA_REG9	ACL_ENTRY_DATA_REG9_ADDR
#define ACL_ENTRY_DATA_REG10	ACL_ENTRY_DATA_REG10_ADDR
#define ACL_ENTRY_DATA_REG11	ACL_ENTRY_DATA_REG11_ADDR
#define ACL_ENTRY_CMD_CNTRL_REG	ACL_ENTRY_CMD_CNTRL_REG_ADDR
#define ACL_ENTRY_STATUS_REG	ACL_ENTRY_STATUS_REG_ADDR
#endif

#define ACL_TABLE_SIZE		64

/* ACL Commands */
#define ACL_ENTRY_CMD_ADD		0x1
#define ACL_ENTRY_CMD_GET		0x2
#define ACL_ENTRY_CMD_DEL		0x3

#define ACL_ENTRY_CMD_SEARCH		0x4

#define ACL_ENTRY_CMD_ID_SHIFT_POS	0x8

/* ACL Status bits */
#define ACL_ENTRY_STATUS_CMD_DONE	0x1
#define ACL_ENTRY_NOT_FOUND		0x2
#define ACL_ENTRY_ADDED			0x4
#define ACL_ENTRY_MATCH			0x8
#define ACL_ENTRY_SUCCESS		0x8

#define ACL_ENTRY_STATUS_CLR		0x1

/* fp_acl_entry structure */
/* based on a byte = 8 bits
 * and an int is 4 bytes .. gives 32 bits per int
 */
struct acl_entry
{
	/* outer vlan id */
	union {
		struct {
			uint32a vlan_id:12;
			/* incoming port bits
			   bit0 - port0
			   bit1 - port1
			   ...
			   bit5 - port5
			   bit6 - host
			 */
			uint32a iport:20;
		};
		uint32a Reg0;
	};
	/* source and mac addresses */
	union {
		struct {
			uint8 src_mac[6];
			uint8 dst_mac[6];
		};
		struct {
			uint32a Reg1;
			uint32a Reg2;
			uint32a Reg3;
		};
	};
	union {
		struct {
			/* TCP or UDP source and destination ports */
			uint16 dst_port;
			uint16 src_port;
		};
		uint32a Reg4;
	};

	union {
		struct {
			uint32a reserved:6;
			/* layer4 valid bit - bit set if TCP/UDP packet */
			uint32a l4_valid:1;
			/* acl entry valid bit */
			uint32a valid:1;
			/* IP Protocol number - 0x1, 0x6 and 0x11 etc */
			uint32a ip_type:8;
			/* Ether Type - 0x0800, 0x8100, 0x86DD etc */
			uint32a eth_type:16;
		};
		uint32a Reg5;
	};
	union {
		struct {
			/* mask for source and mac addresses */
			uint8 mask_src_mac[6];
			uint8 mask_dst_mac[6];
		};
		struct {
			uint32a Reg6;
			uint32a Reg7;
			uint32a Reg8;
		};
	};
	union {
		struct {
			/* masks for TCP or UDP source and destination ports */
			uint16 mask_dst_port;
			uint16 mask_src_port;
		};
		uint32a Reg9;
	};
	union {
		struct {
			uint32a reserved1:8;
			uint32a enable_vlan_range:1;	/* range enable for vlan and layer4 ports */
			uint32a enable_port_range:1;	/* enable match for dest mac address */
			uint32a match_dst_mac:1;		/* enable match for source mac address */
			uint32a match_src_mac:1;		/* enable match for layer4 source port */
			uint32a match_dst_port:1;		/* enable match for layer4 source port */
			uint32a match_src_port:1;		/* enable match for non_vlan */
			uint32a match_non_vlan:1;		/* enable match for vlan id */
			uint32a match_vlan:1;		/* enable match for l4_valid */
			uint32a match_l4_valid:1;		/* enable match for ip_type */
			uint32a match_ip_type:1;		/* enable match for eth_type */
			uint32a match_eth_type:1;		/* if this bit is set only, iport is valid */
			uint32a match_iport:1;		/* mask for VLAN ID */
			uint32a mask_vlan_id:12;
		};
		uint32a Reg10;
	};
	union {
		struct {
			uint32a reserved2:6;
			/* action flags
			   0x0 - Drop
			   0x1 - Port Forward
			   0x2 - Port Forward with queue setting
			   0x4 - Do nothing
			 */
			uint32a action:2;
			/* forward queue list */
			//uint32a action_fwd_queue:4;
			uint32a fwd_queue:4;

			/* forward port list
			   bit0 - port0
			   bit1 - port1
			   ...
			   bit5 - port5
			   bit6 - host
			 */
			//uint32a action_fwd_list:20;
			uint32a fwd_port_list:20;
			//uint32a vlan_tag_type;
		};
		uint32a Reg11;
	};
};

/*!
 Add an ACL entry into ACL table

 @param   wsp_base_addr   Base address of the WSP registers
 @param   id              ACL entry index in the ACL table
 @param   acl             acl entry to be added
 @return status code:       0=success, -1=failure
 */
int32a fp_acl_add_entry(	uint32a id,
			struct acl_entry *acl);

/*!
 Delete an ACL entry

 @param wsp_base_addr  Base address of the EPP registers
 @param           id   ACL entry index in the ACL table
 @return status code   0=success, -1=failure
 **/
int32a fp_acl_del_entry (uint32a id);

/*!
 Get an ACL entry

 @param   wsp_base_addr   Base address of the WSP registers
 @param   id              ACL entry index in the ACL table
 @param   acl             acl entry to be read into
 @return  status code:    0=success, -1=failure
 */
int32a fp_acl_get_entry(	uint32a id,
			struct acl_entry *acl);

/*!
 Initialize ACL table

 @param   wsp_base_addr   Base address of the WSP registers
 */
void fp_acl_table_init(void);
#endif
