/**
 * @file MRVL_AMG_API_FW.c
 * @brief Marvell Multi-gig Automotive Ethernet PHY FW API for loading Fw images 
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */


#include "MRVL_AMG_API_FW.h"
#include "MRVL_AMG_API.h"
#include "MRVL_AMG_REG_MAIN.h"

#define CRC_TABLE_SIZE 256

STATIC MRVL_APHY_U16 m_CRCTableCCITT[CRC_TABLE_SIZE] = {
   0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50a5, 0x60c6, 0x70e7,
   0x8108, 0x9129, 0xa14a, 0xb16b, 0xc18c, 0xd1ad, 0xe1ce, 0xf1ef,
   0x1231, 0x0210, 0x3273, 0x2252, 0x52b5, 0x4294, 0x72f7, 0x62d6,
   0x9339, 0x8318, 0xb37b, 0xa35a, 0xd3bd, 0xc39c, 0xf3ff, 0xe3de,
   0x2462, 0x3443, 0x0420, 0x1401, 0x64e6, 0x74c7, 0x44a4, 0x5485,
   0xa56a, 0xb54b, 0x8528, 0x9509, 0xe5ee, 0xf5cf, 0xc5ac, 0xd58d,
   0x3653, 0x2672, 0x1611, 0x0630, 0x76d7, 0x66f6, 0x5695, 0x46b4,
   0xb75b, 0xa77a, 0x9719, 0x8738, 0xf7df, 0xe7fe, 0xd79d, 0xc7bc,
   0x48c4, 0x58e5, 0x6886, 0x78a7, 0x0840, 0x1861, 0x2802, 0x3823,
   0xc9cc, 0xd9ed, 0xe98e, 0xf9af, 0x8948, 0x9969, 0xa90a, 0xb92b,
   0x5af5, 0x4ad4, 0x7ab7, 0x6a96, 0x1a71, 0x0a50, 0x3a33, 0x2a12,
   0xdbfd, 0xcbdc, 0xfbbf, 0xeb9e, 0x9b79, 0x8b58, 0xbb3b, 0xab1a,
   0x6ca6, 0x7c87, 0x4ce4, 0x5cc5, 0x2c22, 0x3c03, 0x0c60, 0x1c41,
   0xedae, 0xfd8f, 0xcdec, 0xddcd, 0xad2a, 0xbd0b, 0x8d68, 0x9d49,
   0x7e97, 0x6eb6, 0x5ed5, 0x4ef4, 0x3e13, 0x2e32, 0x1e51, 0x0e70,
   0xff9f, 0xefbe, 0xdfdd, 0xcffc, 0xbf1b, 0xaf3a, 0x9f59, 0x8f78,
   0x9188, 0x81a9, 0xb1ca, 0xa1eb, 0xd10c, 0xc12d, 0xf14e, 0xe16f,
   0x1080, 0x00a1, 0x30c2, 0x20e3, 0x5004, 0x4025, 0x7046, 0x6067,
   0x83b9, 0x9398, 0xa3fb, 0xb3da, 0xc33d, 0xd31c, 0xe37f, 0xf35e,
   0x02b1, 0x1290, 0x22f3, 0x32d2, 0x4235, 0x5214, 0x6277, 0x7256,
   0xb5ea, 0xa5cb, 0x95a8, 0x8589, 0xf56e, 0xe54f, 0xd52c, 0xc50d,
   0x34e2, 0x24c3, 0x14a0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
   0xa7db, 0xb7fa, 0x8799, 0x97b8, 0xe75f, 0xf77e, 0xc71d, 0xd73c,
   0x26d3, 0x36f2, 0x0691, 0x16b0, 0x6657, 0x7676, 0x4615, 0x5634,
   0xd94c, 0xc96d, 0xf90e, 0xe92f, 0x99c8, 0x89e9, 0xb98a, 0xa9ab,
   0x5844, 0x4865, 0x7806, 0x6827, 0x18c0, 0x08e1, 0x3882, 0x28a3,
   0xcb7d, 0xdb5c, 0xeb3f, 0xfb1e, 0x8bf9, 0x9bd8, 0xabbb, 0xbb9a,
   0x4a75, 0x5a54, 0x6a37, 0x7a16, 0x0af1, 0x1ad0, 0x2ab3, 0x3a92,
   0xfd2e, 0xed0f, 0xdd6c, 0xcd4d, 0xbdaa, 0xad8b, 0x9de8, 0x8dc9,
   0x7c26, 0x6c07, 0x5c64, 0x4c45, 0x3ca2, 0x2c83, 0x1ce0, 0x0cc1,
   0xef1f, 0xff3e, 0xcf5d, 0xdf7c, 0xaf9b, 0xbfba, 0x8fd9, 0x9ff8,
   0x6e17, 0x7e36, 0x4e55, 0x5e74, 0x2e93, 0x3eb2, 0x0ed1, 0x1ef0 };

STATIC MRVL_APHY_U32 bytesToDw(MRVL_APHY_U32 a_bytesCount) 
{ 
	return a_bytesCount / DWORD_SIZE; 
}


/* ****************  SPI read/write **************** */

STATIC MRVL_APHY_STATUS MRVL_AMG_MB_SPI_setup(MRVL_DEV_PTR device, MRVL_APHY_U8 opcode, MRVL_APHY_U16 wrMode, MRVL_APHY_U16 addrLen, MRVL_APHY_U16 dummyLen, MRVL_APHY_U16 dataLen)
{
    MRVL_APHY_U32 val = 0;
    MRVL_APHY_STATUS result;

    result = MRVL_AMG_ReadReg32( device, FlashCtrlSwInterface2, &val);
    val = (val & 0xfffffffeU) | ((MRVL_APHY_U32)wrMode << sw_wr_mode);
    val = (val & 0xfff8ffffU) | ((MRVL_APHY_U32)dataLen << sw_data_len);
    result |= MRVL_AMG_WriteReg32(device, FlashCtrlSwInterface2, val);

    result |= MRVL_AMG_ReadReg32(device, FlashCtrlSwBurst, &val);
    val = (val & 0xfffffffeU); /* burst_en = 0 */
    result |= MRVL_AMG_WriteReg32(device, FlashCtrlSwBurst, val); 
    
    result |= MRVL_AMG_ReadReg32(device, FlashCtrlSwInterface1, &val);
    val = (val & 0xffffff00U) | ((MRVL_APHY_U32)opcode << sw_opcode);
    val = (val & 0xffcfffffU) | ((MRVL_APHY_U32)addrLen << sw_addr_len);
    val = (val & 0xc0ffffffU) | ((MRVL_APHY_U32)dummyLen << sw_dummy_len);
    result |= MRVL_AMG_WriteReg32(device, FlashCtrlSwInterface1, val);

	return  result;
}

STATIC MRVL_APHY_STATUS MRVL_AMG_MB_SPI_execute(MRVL_DEV_PTR device)
{
    MRVL_APHY_U16 i = 0;
    const MRVL_APHY_U16 BUSY_TIMEOUT_MS = 4000;
    MRVL_APHY_U32 val = 0;
    MRVL_APHY_STATUS result;
	if (MRVL_APHY_TRUE == MRVL_AMG_FLASH_BYPASS_CHECK) {
		result = MRVL_AMG_WriteReg32(device, FlashCtrlSwStart, 1);
		/* bypass status checking */
	}
	else 
	{
		result = MRVL_AMG_ReadReg32(device, FlashCtrlSwStart, &val);
		val = (val & 0xfffffffeU) | (1U << start_);
		result |= MRVL_AMG_WriteReg32(device, FlashCtrlSwStart, val);
		while (i < BUSY_TIMEOUT_MS)
		{
			result |= MRVL_AMG_ReadReg32(device, FlashStatSwBusy, &val);

			if ((val & (0x1U << busy)) == 0)
			{
				result |= MRVL_APHY_STATUS_OK;
				break;
			}
			i++;
			result |= MRVL_AMG_Wait(device, 1);
		}

		if (i >= BUSY_TIMEOUT_MS)
		{
			MRVL_AMG_DBG_ERROR("SPI error: execution timeout\n");
			result |= MRVL_APHY_STATUS_ERROR_TIMEOUT;	
		}		
	}

	return result;   
}

STATIC MRVL_APHY_STATUS MRVL_AMG_MB_SPI_writeEnable(MRVL_DEV_PTR device, MRVL_APHY_U8 write_enable_opcode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
    status |= MRVL_AMG_MB_SPI_setup(device, write_enable_opcode, 0, 0, 0, 0);
	status |= MRVL_AMG_MB_SPI_execute(device);
	return status;
}

STATIC MRVL_APHY_STATUS MRVL_AMG_MB_SPI_readReg32(MRVL_DEV_PTR device, MRVL_APHY_U32 *regVal)
{
    MRVL_APHY_U32 val = 0;
    MRVL_APHY_STATUS result;

    result = MRVL_AMG_ReadReg32(device, FlashStatSwRdData, &val);

    *regVal = val;
    return result;
}

STATIC MRVL_APHY_U8 MRVL_AMG_MB_SPI_readStatus(MRVL_DEV_PTR device, MRVL_APHY_U8 opCode)
{
	MRVL_APHY_STATUS result = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 status = 0;
	result |= MRVL_AMG_MB_SPI_setup(device, opCode, 0, 0, 0, 1);
	result |= MRVL_AMG_MB_SPI_execute(device);
	result |= MRVL_AMG_MB_SPI_readReg32(device, &status);
	if (result != MRVL_APHY_STATUS_OK)
	{
		MRVL_AMG_DBG_ERROR("SPI error: error happened in MRVL_AMG_MB_SPI_readStatus\n");
	}
	return status & 0xFFU;
}

STATIC MRVL_APHY_U16 MRVL_AMG_MB_SPI_readSR(MRVL_DEV_PTR device, MRVL_APHY_U8 read_status_opcode, MRVL_APHY_U8 read_status_reg2_opcode, MRVL_APHY_BOOL isNeedReg2)
{
	MRVL_APHY_U8 tmp = 0;
	MRVL_APHY_U16 status = 0;
	tmp = MRVL_AMG_MB_SPI_readStatus(device, read_status_opcode);
	status = tmp;
	if (isNeedReg2 == MRVL_APHY_TRUE) {
		tmp = MRVL_AMG_MB_SPI_readStatus(device, read_status_reg2_opcode);
		status |= ((MRVL_APHY_U16)tmp << 8);
	}
	return status;
}

STATIC MRVL_APHY_STATUS MRVL_AMG_MB_SPI_waitWriteReady(MRVL_DEV_PTR device, MRVL_APHY_U8 opcode)
{
    MRVL_APHY_U16 i = 0;
    MRVL_APHY_U16 writestatus = 0;
    MRVL_APHY_STATUS result = MRVL_APHY_STATUS_ERROR_TIMEOUT;
    const MRVL_APHY_U32 loopLimit = 30000;

    while (i < loopLimit)
    {
        writestatus = MRVL_AMG_MB_SPI_readStatus(device, opcode);

        if ((writestatus & 1) == 0)
        {
            result = MRVL_APHY_STATUS_OK;
            break;
        }
        i++;
        result = MRVL_AMG_Wait(device, 1);
    }

    if (result == MRVL_APHY_STATUS_ERROR_TIMEOUT)
    {
		MRVL_AMG_DBG_ERROR("SPI error: waitWriteReady timeout\n");
    }

    return result;
}

STATIC MRVL_APHY_STATUS MRVL_AMG_MB_readDmaBuffer(MRVL_DEV_PTR device, MRVL_APHY_U16 a_buffId, MRVL_APHY_U8 a_data[], MRVL_APHY_U32 a_size, MRVL_APHY_U32* totalsize)
{
    MRVL_APHY_U32 buffer_address;
    MRVL_APHY_U32 read_data = 0;
    MRVL_APHY_U32 cur = *totalsize;
    MRVL_APHY_U32 ii,kk;
    MRVL_APHY_STATUS result = MRVL_APHY_STATUS_OK;
    const MRVL_APHY_U16 loopLimit = 4;

    if (a_buffId == 1U)
    {
    	buffer_address = SPI_DMA_BUFFER0_ADDR;
    }
    else
    {
    	buffer_address = SPI_DMA_BUFFER1_ADDR;
    }
   
    for (ii = 0; ii < a_size; ii++)
    {
        result |= MRVL_AMG_ReadReg32(device, buffer_address + ii * 4, &read_data);
		for (kk = 0; kk < loopLimit; kk++) {
			a_data[cur] = (MRVL_APHY_U8)((read_data >> (8 * kk)) & 0xFFU);
			cur++;
		}

    }
	*totalsize = cur;
    return result;
}

STATIC MRVL_APHY_STATUS MRVL_AMG_MB_dmaReadAck(MRVL_DEV_PTR device, MRVL_APHY_U16 a_buffId)
{
    MRVL_APHY_U32 tmp = 0;
    MRVL_APHY_STATUS result = MRVL_APHY_STATUS_OK;

    if (a_buffId > 1)
    {
    	result = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
    }     
 	else
 	{
 		result |= MRVL_AMG_ReadReg32(device, FlashCtrlDmaRdAck, &tmp);

	    if (a_buffId == 0)
	    {
	        tmp = (tmp & 0xfffffffeU) | (1U << buf0_rd_ack);
	    }
	    else
	    {
	        tmp = (tmp & 0xffffffefU) | (1U << buf1_rd_ack);
	    }
	    result |= MRVL_AMG_WriteReg32(device, FlashCtrlDmaRdAck, tmp);
 	}
    
    return result;
}


/* **************** CRC **************** */

STATIC MRVL_APHY_U16 calculateCRC16(MRVL_APHY_U8 a_data[], MRVL_APHY_U32 a_size)
{
	MRVL_APHY_U16 crc16Calculated = 0x0000;
	MRVL_APHY_U32 i;
	MRVL_AMG_DBG_INFO("CRC: caculate CRC\n");

	for (i = 0; i < a_size; i++)
	{
		crc16Calculated = ((crc16Calculated & 0xFFU) << 8) ^ m_CRCTableCCITT[(crc16Calculated >> 8) ^ a_data[i]];
	}
	return crc16Calculated;
}

/* **************** Flash related **************** */

STATIC MRVL_APHY_STATUS MRVL_AMG_FLASH_liftProtection(MRVL_DEV_PTR device, const MRVL_AMG_FLASH* flashInfo)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
    MRVL_APHY_U32 protectStatus = 0;

	protectStatus = MRVL_AMG_MB_SPI_readSR(device, flashInfo->read_status_opcode, flashInfo->read_status_reg2_opcode, flashInfo->status_reg_len > 1 ? MRVL_APHY_TRUE : MRVL_APHY_FALSE);

	if ((protectStatus & (0x1U << flashInfo->srl_bit)) == 1)
	{
		MRVL_AMG_DBG_ERROR("Flash error: status register writing was disabled. Need powercycle.\n");
		status = MRVL_APHY_STATUS_ERROR_GENERAL;
	}
	else if (0 != (protectStatus & (1 << flashInfo->cmp_bit)) )
	{
		if (flashInfo->volatile_sr_write_en_opcode != MRVL_AMG_FLASH_INVALID_OPCODE) 
		{
			status |= MRVL_AMG_MB_SPI_setup(device, flashInfo->volatile_sr_write_en_opcode, 0, 0, 0, 0);
			status |= MRVL_AMG_MB_SPI_execute(device);
			if (status != MRVL_APHY_STATUS_OK)
			{
				MRVL_AMG_DBG_ERROR("Flash error: volatile write cannot be enabled.\n");
			}
		}

		if (status == MRVL_APHY_STATUS_OK)
		{
			protectStatus &= ~(0x1U << flashInfo->cmp_bit);
			status |= MRVL_AMG_MB_SPI_setup(device, flashInfo->write_status_opcode, 1, 0, 0, 2);
			status |= MRVL_AMG_WriteReg32(device, FlashCtrlSwWrData, protectStatus);
			/* MRVL_AMG_ReadReg32(device, FlashCtrlSwAddr, &tmp); */
			/* tmp = (tmp & 0xff000000); */
			status |= MRVL_AMG_WriteReg32(device, FlashCtrlSwAddr, 0);
			status |= MRVL_AMG_MB_SPI_execute(device);
			if (status != MRVL_APHY_STATUS_OK)
			{
				MRVL_AMG_DBG_ERROR("Flash error: SPI timeout.\n");
			}
		}
		
	}
	else
	{
		status |= MRVL_APHY_STATUS_OK;
	}

	if (status == MRVL_APHY_STATUS_OK)
		MRVL_AMG_DBG_INFO("Flash: lift erase protection.\n");
	return status;
}

STATIC MRVL_APHY_BOOL MRVL_AMG_FLASH_isDmaTimeout(MRVL_DEV_PTR device, MRVL_APHY_U32 lastDataReady)
{
	MRVL_APHY_U32 timed;

	MRVL_AMG_Clock(&timed);
	
	if ((timed - lastDataReady) > DMA_TIMEOUT_MS)
	{
		return MRVL_APHY_TRUE;
	}
	else
	{
		return MRVL_APHY_FALSE;
	}

}

STATIC MRVL_APHY_STATUS MRVL_AMG_FLASH_readSFDP(MRVL_DEV_PTR device, MRVL_APHY_U32 regaddr, MRVL_APHY_U32* regVal)
{
	MRVL_APHY_STATUS status;
	*regVal = 0;

	status = MRVL_AMG_WriteReg32(device, FlashCtrlSwAddr, (0xff000000U + regaddr));
	status |= MRVL_AMG_MB_SPI_setup(device, 0x5A, 0, 3, 8, 4);
	status |= MRVL_AMG_MB_SPI_execute(device);

	status |= MRVL_AMG_MB_SPI_readReg32(device, regVal);
	MRVL_AMG_DBG_ALL("SFDP regAddr:0x%x :: regVal:0x%x\n", regaddr, *regVal);

	return status;
}

STATIC MRVL_APHY_STATUS MRVL_AMG_FLASH_getSFDP_ptpInfo(MRVL_DEV_PTR device, SFDP_PARAMETER_TABLE_1* parameter_table_pt) {
	MRVL_APHY_STATUS status;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U32 ptpAddr = 0;
	MRVL_APHY_U32 pt1_array[PTP_ARRAY_SIZE] = { 0 };
	MRVL_APHY_U32 indx;

	status = MRVL_AMG_FLASH_readSFDP(device, 0x8, &regVal);
	status |= MRVL_AMG_FLASH_readSFDP(device, 0xc, &regVal);
	ptpAddr = regVal & 0xFFFFFFU;

	for (indx = 1; indx <= PTP_ARRAY_SIZE; indx++) {
		status |= MRVL_AMG_FLASH_readSFDP(device, ptpAddr + ((indx - 1) * 4), &pt1_array[indx - 1]);
		MRVL_AMG_DBG_ALL("SFDP DWORD_%d : 0x%x\n", indx, pt1_array[indx - 1]);
	}

	indx = 0;
	parameter_table_pt->DWORD_1.whole = pt1_array[indx++];
	parameter_table_pt->DWORD_2.whole = pt1_array[indx++];
	parameter_table_pt->DWORD_3.whole = pt1_array[indx++];
	parameter_table_pt->DWORD_4.whole = pt1_array[indx++];
	parameter_table_pt->DWORD_5.whole = pt1_array[indx++];
	parameter_table_pt->DWORD_6.whole = pt1_array[indx++];
	parameter_table_pt->DWORD_7.whole = pt1_array[indx++];
	parameter_table_pt->DWORD_8.whole = pt1_array[indx++];
	parameter_table_pt->DWORD_9.whole = pt1_array[indx++];
	parameter_table_pt->DWORD_10.whole = pt1_array[indx++];
	parameter_table_pt->DWORD_11.whole = pt1_array[indx++];
	parameter_table_pt->DWORD_12.whole = pt1_array[indx++];
	parameter_table_pt->DWORD_13.whole = pt1_array[indx++];
	parameter_table_pt->DWORD_14.whole = pt1_array[indx++];
	parameter_table_pt->DWORD_15.whole = pt1_array[indx++];
	parameter_table_pt->DWORD_16.whole = pt1_array[indx];

	return status;
}

STATIC MRVL_APHY_U32 number_of_erase_cycle_req(MRVL_APHY_U32 flash_size, MRVL_APHY_U8 erase_size_N) 
{
	MRVL_APHY_U32 erase_cycle = 0; /* Error, it must be > 0 */
	MRVL_APHY_U32 temp_max_erase_size;

	MRVL_AMG_DBG_ALL("INFO: Erase Size N: 0x%x\n", erase_size_N);
	if (erase_size_N == 0) 
	{
		MRVL_AMG_DBG_INFO("Warning: Size 0, erase type does not exist\n");
	}
	else
	{
		temp_max_erase_size = (MRVL_APHY_U32) MRVL_AMG_Pow(2, erase_size_N);
		MRVL_AMG_DBG_ALL("INFO: Erase Size in bytes: 0x%x\n", temp_max_erase_size);
		MRVL_AMG_DBG_ALL("INFO: Flash  Size in bytes: 0x%x\n", (flash_size+1)/8);

		erase_cycle = ((flash_size + 1) / 8) / temp_max_erase_size;
		MRVL_AMG_DBG_ALL("INFO: Number of erase cycle required to erase flash: %d\n", erase_cycle);
		MRVL_AMG_DBG_ALL("INFO: Number of remaing bytes: %d\n", ((flash_size + 1) / 8) % temp_max_erase_size);
	}
	
	return erase_cycle;
}

STATIC MRVL_APHY_STATUS MRVL_AMG_FLASH_initFlashInfo(MRVL_DEV_PTR device, MRVL_AMG_FLASH* flashInfo){

	MRVL_APHY_U32 flashId = 0;
	MRVL_APHY_STATUS status;
	MRVL_APHY_U32 tmp_erase_cycle = 0;
	SFDP_PARAMETER_TABLE_1 pt;

	pt.DWORD_1.whole = 0;
	pt.DWORD_2.whole = 0;
	pt.DWORD_3.whole = 0;
	pt.DWORD_4.whole = 0;
	pt.DWORD_5.whole = 0;
	pt.DWORD_6.whole = 0;
	pt.DWORD_7.whole = 0;
	pt.DWORD_8.whole = 0;
	pt.DWORD_9.whole = 0;
	pt.DWORD_10.whole = 0;
	pt.DWORD_11.whole = 0;
	pt.DWORD_12.whole = 0;
	pt.DWORD_13.whole = 0;
	pt.DWORD_14.whole = 0;
	pt.DWORD_15.whole = 0;
	pt.DWORD_16.whole = 0;

	/* Read 1st Parameter Table (0) */
	status = MRVL_AMG_FLASH_getSFDP_ptpInfo(device, &pt);


	/* Get & Set Flash manufacturer_id & device_id */
	status |= MRVL_AMG_WriteReg32(device, FlashCtrlSwAddr, 0xff000000U);
	status |= MRVL_AMG_MB_SPI_setup(device, 0x9F, 0, 0, 0, 4);
	status |= MRVL_AMG_MB_SPI_execute(device);

	status |= MRVL_AMG_MB_SPI_readReg32(device, &flashId);

	MRVL_AMG_DBG_INFO("Flash ID: 0x%x\n", flashId);


	flashInfo->manufacturer_id = flashId & 0xFFU;
	flashInfo->device_id = (flashId & 0xFFFFFFU) >> 8;


	/* init flashInfo Struct  */

	/* Flash Size */
	/* For densities 2 gigabits or less, bit-31 is set to 0b. The field 30:0 defines the size in bits.  */
	/* 	Example: 00FFFFFFh = 16 megabits */
	/* For densities 4 gigabits and above, bit - 31 is set to 1b.The field 30:0 defines �N� where the density is computed as 2 ^ N bits(N must be >= 32). */
	/* 	Example : 80000021h = 2 ^ 33 = 8 gigabits */
	flashInfo->flash_size = pt.DWORD_2.whole;

	/* Find Minimum Erase Cycle required */
	/* Check with erase type 1 */
	tmp_erase_cycle = number_of_erase_cycle_req(flashInfo->flash_size, pt.DWORD_8.bits.erase_type_1_size);
	if (tmp_erase_cycle == 0)
	{
		status |= MRVL_APHY_STATUS_ERROR_GENERAL;
	}
	else 
	{
		flashInfo->erase_cycle = tmp_erase_cycle;
		flashInfo->max_flash_erase_size = pt.DWORD_8.bits.erase_type_1_size;
		flashInfo->max_erase_opcode = pt.DWORD_8.bits.erase_type_1_instruction;
	
		/* Check with erase type 2 */
		tmp_erase_cycle = number_of_erase_cycle_req(flashInfo->flash_size, pt.DWORD_8.bits.erase_type_2_size);
		if (tmp_erase_cycle != 0 && tmp_erase_cycle < flashInfo->erase_cycle){
			flashInfo->erase_cycle = tmp_erase_cycle;
			flashInfo->max_flash_erase_size = pt.DWORD_8.bits.erase_type_2_size;
			flashInfo->max_erase_opcode = pt.DWORD_8.bits.erase_type_2_instruction;
		}
		/* Check with erase type 3 */
		tmp_erase_cycle = number_of_erase_cycle_req(flashInfo->flash_size, pt.DWORD_9.bits.erase_type_3_size);
		if (tmp_erase_cycle != 0 && tmp_erase_cycle < flashInfo->erase_cycle){
			flashInfo->erase_cycle = tmp_erase_cycle;
			flashInfo->max_flash_erase_size = pt.DWORD_9.bits.erase_type_3_size;
			flashInfo->max_erase_opcode = pt.DWORD_9.bits.erase_type_3_instruction;
		}
		/* Check with erase type 4 */
		tmp_erase_cycle = number_of_erase_cycle_req(flashInfo->flash_size, pt.DWORD_9.bits.erase_type_4_size);
		if (tmp_erase_cycle != 0 && tmp_erase_cycle < flashInfo->erase_cycle){
			flashInfo->erase_cycle = tmp_erase_cycle;
			flashInfo->max_flash_erase_size = pt.DWORD_9.bits.erase_type_4_size;
			flashInfo->max_erase_opcode = pt.DWORD_9.bits.erase_type_4_instruction;
		}
		MRVL_AMG_DBG_INFO("Number of Max erase size = 0x%x & number of erase cycle: %d\n", flashInfo->max_flash_erase_size, flashInfo->erase_cycle);

		
		/* 15th DWORD: bits 22:20 */
		/* Quad Enable Requirements (QER) */
		MRVL_AMG_DBG_ALL("15th DWORD: bits 22:20: 0x%x\n", pt.DWORD_15.bits.quad_enable_requirements_QER);
		switch (pt.DWORD_15.bits.quad_enable_requirements_QER) 
		{
			case(0b001):
				/* QE is bit 1 of status register 2. It is set via Write Status with two data bytes where bit 1 of the second byte is one. */
				/* Writing only one byte to the status register has the side-effect of clearing status register 2, including the QE bit. */
				flashInfo->status_reg_len = 2;
				flashInfo->quad_enable_bit = (8+1);
				flashInfo->read_status_reg2_opcode = 0x35;
				break;
			case(0b010):
				/* QE is bit 6 of status register 1. It is set via Write Status with one data byte where bit 6 is one. */
				flashInfo->quad_enable_bit = 6;
				break;
			case(0b011):
				/* QE is bit 7 of status register 2. It is set via Write status register 2 instruction 3Eh with one data byte where bit 7 is one. */
				/* It is cleared via Write status register 2 instruction 3Eh with one data byte where bit 7 is zero. The status register 2 is read using instruction 3Fh. */
				flashInfo->status_reg_len = 2;
				flashInfo->quad_enable_bit = (8 + 7);
				flashInfo->read_status_reg2_opcode = 0x3F;
				flashInfo->write_status_reg2_opcode = 0x3E;
				break;
			case(0b100):
				/* QE is bit 1 of status register 2. It is set via Write Status with two data bytes where bit 1 of the second byte is one. */
				/* In contrast to the 001b code, writing one byte to the status register does not modify status register 2. */
				flashInfo->status_reg_len = 2;
				flashInfo->quad_enable_bit = (8 + 1);
				flashInfo->read_status_reg2_opcode = 0x35;
				break;
			case(0b101):
				/* QE is bit 1 of the status register 2. Status register 1 is read using Read Status instruction 05h. Status register 2 is read using instruction 35h. */
				/* QE is set via Write Status instruction 01h with two data bytes where bit 1 of the second byte is one.It is cleared via Write Status with two data bytes  */
				/* where bit 1 of the second byte is zero. */
				flashInfo->status_reg_len = 2;
				flashInfo->quad_enable_bit = (8 + 1);
				flashInfo->read_status_reg2_opcode = 0x35;
				break;
			case(0b110):
				/* QE is bit 1 of the status register 2. Status register 1 is read using Read Status instruction 05h.  */
				/* Status register 2 is read using instruction 35h, and status register 3 is read using instruction 15h. */
				/* QE is set via Write Status Register instruction 31h with one data byte where bit 1 is one.  */
				/* It is cleared via Write Status Register instruction 31h with one data byte where bit 1 is zero. */
				flashInfo->status_reg_len = 3;
				flashInfo->quad_enable_bit = (8 + 1);
				flashInfo->read_status_reg2_opcode = 0x35;
				flashInfo->write_status_reg2_opcode = 0x31;
				break;

			case(0b000):
				/* Device does not have a QE bit.Device detects 1S - 1S - 4S and 1S - 4S - 4S reads based on instruction. */
				/* IO3/HOLD# functions as hold during instruction phase. */
			case(0b111):
			default:
				MRVL_AMG_DBG_INFO("Device does not have QE bit\n");
				flashInfo->is_quad_enable_supported = MRVL_APHY_FALSE;
				break;
		}
		flashInfo->chip_erase_addr_len = 3; 
	}

	return status;
}


/******************************************************************************
 *      Image and Flash
 ******************************************************************************/

/**
 * @brief reset fw flash
 * @param[in] device	pointer to MRVL_DEV
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_FW
 */
MRVL_APHY_STATUS MRVL_AMG_FLASH_resetFWFlash(MRVL_DEV_PTR device)
{
    MRVL_APHY_U32 regData = 0;
    MRVL_APHY_STATUS result = MRVL_APHY_STATUS_OK;

    /* reset */
    result |= MRVL_AMG_ReadReg32(device, CommonRegisterClockResetRstCtrlRstFlash, &regData);

    regData = (regData | (0x1U << dma_rst) | (0x1U << if_rst));
    result |= MRVL_AMG_WriteReg32(device, CommonRegisterClockResetRstCtrlRstFlash, regData);

    /* set clk div */
    result |= MRVL_AMG_ReadReg32(device, FlashCtrlSwInterface1, &regData);
    regData = (regData & 0xFFFE00FFU) | (SPI_CLOCK_DIVIDER << sw_clk_div);
    result |= MRVL_AMG_WriteReg32( device, FlashCtrlSwInterface1, regData);

    if (result == MRVL_APHY_STATUS_OK)
    {
		MRVL_AMG_DBG_INFO("Flash: reset flash.\n");
    }
    return result;
}

/**
 * @brief soft reset flash
 * @param[in] device	pointer to MRVL_DEV
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_FW
 */
MRVL_APHY_STATUS MRVL_AMG_FLASH_softResetFlash(MRVL_DEV_PTR device)
{
    MRVL_APHY_STATUS status;

    status = MRVL_AMG_MB_SPI_setup(device, 0x66, 0, 0, 0, 0);
	status |= MRVL_AMG_MB_SPI_execute(device);
	if (status == MRVL_APHY_STATUS_OK)
	{
		status |= MRVL_AMG_MB_SPI_setup(device, 0x99, 0, 0, 0, 0);
		status |= MRVL_AMG_MB_SPI_execute(device);
	}

    return status;
}

/**
 * @brief erase flash
 * @param[in] device			pointer to MRVL_DEV
 * @param[in] flashInfo			pointer to MRVL_AMG_FLASH
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_FW
 */
MRVL_APHY_STATUS MRVL_AMG_FLASH_eraseFlash(MRVL_DEV_PTR device, const MRVL_AMG_FLASH* flashInfo)
{
    MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
    /* MRVL_APHY_U32 tmp = 0; */
    MRVL_APHY_U16 execDelay; /* in ms */
	MRVL_APHY_U32 start_all, timed;

	execDelay = 20;

	MRVL_AMG_DBG_INFO("Flash: start erasing flash...\n");
	MRVL_AMG_Clock(&start_all);

	if (flashInfo->erase_protection == MRVL_APHY_FALSE) 
	{
		status = MRVL_AMG_FLASH_liftProtection(device, flashInfo);
	}

	if (status == MRVL_APHY_STATUS_OK)
	{
		/* mb write */
		status |= MRVL_AMG_WriteReg32(device, FlashCtrlSwAddr, 0);
	    /* MRVL_AMG_ReadReg32( device, SpiMboxCntl4, &tmp); */
	    /* tmp &= 0xff000000; */
	    status |= MRVL_AMG_WriteReg32( device, FlashCtrlSwWrData, 0);

		status |= MRVL_AMG_MB_SPI_writeEnable(device, flashInfo->write_enable_opcode);
		
	    status |= MRVL_AMG_MB_SPI_waitWriteReady(device, flashInfo->read_status_opcode);
	    
	    /* mb write */
	    /* MRVL_AMG_ReadReg32( device, FlashCtrlSwAddr, &tmp); */
	    /* tmp &= 0xff000000; */
	    status |= MRVL_AMG_WriteReg32( device, FlashCtrlSwAddr, 0);
	    status |= MRVL_AMG_WriteReg32( device, FlashCtrlSwWrData, 0);

	    /* check write status */
	    status |= MRVL_AMG_MB_SPI_setup(device, flashInfo->write_status_opcode, 0, 1, 0, 0);
		status |= MRVL_AMG_MB_SPI_execute(device);
		
	    status |= MRVL_AMG_Wait(device, execDelay);

	    status |= MRVL_AMG_MB_SPI_waitWriteReady(device, flashInfo->read_status_opcode);
	    
	    /* write enalbe */
		status |= MRVL_AMG_MB_SPI_writeEnable(device, flashInfo->write_enable_opcode);
		
	    status |= MRVL_AMG_MB_SPI_waitWriteReady(device, flashInfo->read_status_opcode);
	    
	    /* erase */
	    status |= MRVL_AMG_MB_SPI_setup(device, flashInfo->chip_erase_opcode, 0, flashInfo->chip_erase_addr_len, 0, 0);
		status |= MRVL_AMG_MB_SPI_execute(device);
		
	    status |= MRVL_AMG_MB_SPI_waitWriteReady(device, flashInfo->read_status_opcode);
	    
	}

	if (status == MRVL_APHY_STATUS_OK)
	{
		MRVL_AMG_Clock(&timed);
		MRVL_AMG_DBG_INFO("Flash: done erasing, duration(s): %u\n", (timed - start_all) / MRVL_CLOCKS_PER_SEC);
	}

    return status;
}

/**
 * @brief write flash
 * @param[in] device			pointer to MRVL_DEV
 * @param[in] flashInfo			pointer to MRVL_AMG_FLASH
 * @param[in] image				pointer/array to image bytes to write to flash
 * @param[in] imageSize			size of bytes to write
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_FW
 */
MRVL_APHY_STATUS MRVL_AMG_FLASH_writeFlash(MRVL_DEV_PTR device, const MRVL_AMG_FLASH* flashInfo, MRVL_APHY_U8 image[], MRVL_APHY_U32 imageSize)
{
    MRVL_APHY_U32 bytesWritten = 0;
    MRVL_APHY_U32 pagePointer = 0;
    const MRVL_APHY_U32 page_size = flashInfo->page_size;
	MRVL_APHY_U32 write_data = 0;
	MRVL_APHY_U32 prev_data = 0xFFFFFFFFU;
    MRVL_APHY_BOOL init_needed = MRVL_APHY_TRUE;
	MRVL_APHY_U32 byte_count;
    MRVL_APHY_U32 tmpVal = 0;
    MRVL_APHY_U32 bytesLeftInPage = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 start_all, timed;

	MRVL_AMG_DBG_INFO("Flash: entering service mode...\n");

	status = MRVL_AMG_enterServiceMode(device);

	if (status != MRVL_APHY_STATUS_OK)
	{
		MRVL_AMG_DBG_ERROR("Could not enter service mode before reading the flash.\n");
	}
	else
	{
		MRVL_AMG_DBG_INFO("Flash: entered service mode.\n");
		MRVL_AMG_OptimizeMB(device, MRVL_APHY_TRUE);


		MRVL_AMG_DBG_INFO("Flash: start writing flash...\n");
		MRVL_AMG_Clock(&start_all);

	    while (bytesWritten < imageSize)
	    {
	        status = MRVL_AMG_MB_SPI_waitWriteReady(device, flashInfo->read_status_opcode);
	        if (status != MRVL_APHY_STATUS_OK)
	        {
				MRVL_AMG_DBG_ERROR("Flash error: SPI write is not ready.\n");
	            break;
	        }
	        status = MRVL_AMG_MB_SPI_writeEnable(device, flashInfo->write_enable_opcode);
	        if (status != MRVL_APHY_STATUS_OK)
	        {
				MRVL_AMG_DBG_ERROR("Flash error: SPI write is not enabled.\n");
	            break;
	        }
	        /* program */
	        status |= MRVL_AMG_MB_SPI_setup(device, flashInfo->program_opcode, 1, 3, 0, 4);
			/* mb write */
			status |= MRVL_AMG_ReadReg32(device, FlashCtrlSwBurst, &tmpVal);
			tmpVal |= (0x1U << burst_en); 
			status |= MRVL_AMG_WriteReg32(device, FlashCtrlSwBurst, tmpVal);
			/* MRVL_AMG_ReadReg32(device, FlashCtrlSwAddr, &tmpVal); */
			tmpVal = bytesWritten;
			status |= MRVL_AMG_WriteReg32(device, FlashCtrlSwAddr, tmpVal);
	        /* sync write page */
			prev_data = 0xFFFFFFFFU;
			init_needed = MRVL_APHY_TRUE;

	        while (pagePointer + 4 < page_size && bytesWritten + 4 < imageSize)
	        {
				byte_count = 0;
	        	write_data = 0;
				while(byte_count < 4)
				{
					write_data |= (MRVL_APHY_U32)(image[bytesWritten++]) << (8 * (byte_count++));
	            	pagePointer++;
				}
				if(init_needed == MRVL_APHY_TRUE || prev_data != write_data)
				{
					status |= MRVL_AMG_WriteReg32( device, FlashCtrlSwWrData, write_data);
					init_needed = MRVL_APHY_FALSE;
					prev_data = write_data;
				}
				
				status |= MRVL_AMG_MB_SPI_execute(device);
	            if (status != MRVL_APHY_STATUS_OK)
	            {
					MRVL_AMG_DBG_ERROR("Flash error: sync write times out.\n");
	                break;
	            }
	        }

			if (status != MRVL_APHY_STATUS_OK)
			{
				break;
			}

	        if (pagePointer + 4 >= page_size)
	        {
	            bytesLeftInPage = page_size - pagePointer;
	        }
	        else
	        {
	            bytesLeftInPage = imageSize - bytesWritten;
	        }

			byte_count = 0;
			write_data = 0;
			while (byte_count < bytesLeftInPage) 
			{
				write_data |= (MRVL_APHY_U32)(image[bytesWritten++]) << (8 * (byte_count++));
			}

			status |= MRVL_AMG_ReadReg32(device, FlashCtrlSwInterface1, &tmpVal);
			tmpVal = (tmpVal & 0xc0ffffffU) | (MRVL_APHY_U32)(3U << sw_dummy_len);
			status |= MRVL_AMG_WriteReg32(device, FlashCtrlSwInterface1, tmpVal);

			status |= MRVL_AMG_ReadReg32(device, FlashCtrlSwInterface2, &tmpVal);
			tmpVal = (tmpVal & 0xfff8ffffU) | (bytesLeftInPage << sw_data_len);
			status |= MRVL_AMG_WriteReg32(device, FlashCtrlSwInterface2, tmpVal);

			status |= MRVL_AMG_ReadReg32( device,FlashCtrlSwBurst, &tmpVal);
			tmpVal = (tmpVal & 0xfffffffeU); /* burst_en = 0 */
			status |= MRVL_AMG_WriteReg32( device,FlashCtrlSwBurst, tmpVal);

			status |= MRVL_AMG_WriteReg32(device, FlashCtrlSwWrData, write_data);

			status |= MRVL_AMG_MB_SPI_execute(device);
			if (status != MRVL_APHY_STATUS_OK)
			{
				MRVL_AMG_DBG_ERROR("Flash error: write times out.\n");
			    break;
			}

			pagePointer = 0;


			if (bytesWritten % 0x2000 == 0)
			{
			    MRVL_AMG_DBG_INFO("Flash: FW write - bytes 0x%x\n", bytesWritten);
			}

	    }

	}

	MRVL_AMG_OptimizeMB(device, MRVL_APHY_FALSE);	


    if (status == MRVL_APHY_STATUS_OK)
    {
        status = MRVL_AMG_MB_SPI_waitWriteReady(device, flashInfo->read_status_opcode);
        MRVL_AMG_Clock(&timed);
        MRVL_AMG_DBG_INFO("Flash: done writing, duration(s): %u\n", (timed - start_all) / MRVL_CLOCKS_PER_SEC);
    }
	else
	{
		MRVL_AMG_DBG_INFO("Flash: writing encountered erros.\n");
	}
    return status;
}

/**
 * @brief read flash
 * @param[in] device			pointer to MRVL_DEV
 * @param[in] flashInfo			pointer to MRVL_AMG_FLASH
 * @param[out] image			pointer/array to image bytes to read from flash
 * @param[in] imageSize			size of bytes to read
 * @param[in] standAloneRead	
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_FW
 */
MRVL_APHY_STATUS MRVL_AMG_FLASH_readFlash(MRVL_DEV_PTR device, const MRVL_AMG_FLASH* flashInfo, MRVL_APHY_U8 image[], MRVL_APHY_U32 imageSize, MRVL_APHY_BOOL standAloneRead)
{
    MRVL_APHY_U32 dw_count = imageSize / 4;
    MRVL_APHY_U32 tmp = 0;
    MRVL_APHY_U16 buf_id = 2;
	MRVL_APHY_U16 buf0_rdy,buf1_rdy;
    MRVL_APHY_U32 start_all, lastDataReady, timed;
    MRVL_APHY_U8 *a_data;
    MRVL_APHY_U32 data_size = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_BOOL dma_done = MRVL_APHY_FALSE;
	MRVL_APHY_U32 curr_addr = 0;
	MRVL_APHY_U32 num_xfers, words_cnt, words_to_read;

	if (standAloneRead == MRVL_APHY_TRUE)
	{
		MRVL_AMG_DBG_INFO("Flash: entering service mode...\n");

		status = MRVL_AMG_enterServiceMode(device);

		if (status != MRVL_APHY_STATUS_OK)
		{
			MRVL_AMG_DBG_ERROR("Could not enter service mode before reading the flash.\n");
		}
		else
		{
			MRVL_AMG_DBG_INFO("Flash: entered service mode.\n");
			MRVL_AMG_DBG_INFO("Flash: start reading flash for verification...\n");
		}
	}
	else
	{

		MRVL_AMG_OptimizeMB(device, MRVL_APHY_TRUE);

		a_data = (MRVL_APHY_U8*)MRVL_AMG_MemoryAllocation(imageSize);

		MRVL_AMG_Clock(&start_all);

	    if (imageSize % 4 > 0)
	    {
	        dw_count++;
	    }


	    while(imageSize > curr_addr)
	    {
	        if (dw_count-(curr_addr>>2) > MAX_NUM_XFERS)
	        {
	        	num_xfers = MAX_NUM_XFERS;
	        }
	        else
	        {
	        	num_xfers = dw_count-(curr_addr>>2);
	        }

	        if (num_xfers != 0)
	        {

		        status |= MRVL_AMG_ReadReg32(device, FlashStatDmaFsm, &tmp);
			    if ((tmp & 7U) != 0)
			    {
					MRVL_AMG_DBG_ERROR("Flash error: DMA is busy.\n");
					MRVL_AMG_FreeMemory(a_data);
					a_data = NULL;
			        status |= MRVL_APHY_STATUS_ERROR_TIMEOUT;
			        break;
			    }
		        /* setup dma */
				/* SPI_INPUT_DUAL = 1 */
			    /* SPI_CLOCK_DIVIDER = 0x6 */
			    status |= MRVL_AMG_ReadReg32(device, FlashCtrlDmaSpiInterface, &tmp);
			    tmp = (tmp & 0xffffff00U) | (flashInfo->fast_read_dual_output_opcode);
			    tmp = (tmp & 0xfffe00ffU) | (SPI_CLOCK_DIVIDER << dma_clk_div);
			    tmp = (tmp & 0xffcfffffU) | (0x3U << dma_addr_len);
			    tmp = (tmp & 0xc0ffffffU) | (0x8U << dma_dummy_len);
			    status |= MRVL_AMG_WriteReg32( device, FlashCtrlDmaSpiInterface, tmp);

			    status |= MRVL_AMG_ReadReg32(device, FlashCtrlDmaInputMode, &tmp);
			    tmp = (tmp & 0xfffffffcU) | SPI_INPUT_DUAL; 
			    status |= MRVL_AMG_WriteReg32(device, FlashCtrlDmaInputMode, tmp);

			    /* MRVL_AMG_ReadReg32( device, SpiGlbCntl3, &tmp); */
			    /* tmp = (tmp & 0xfffffffe); */
			    /* MRVL_AMG_WriteReg32( device, SpiGlbCntl3, tmp); */

			    /* set address and dw and mode */
			    /* MRVL_AMG_ReadReg32( device, FlashCtrlDmaStartAddr, &tmp); */
			    /* tmp = (tmp & 0xff000000); */
			    status |= MRVL_AMG_WriteReg32(device, FlashCtrlDmaStartAddr, 0);

			    status |= MRVL_AMG_ReadReg32( device, FlashCtrlDmaTransfers, &tmp);
			    tmp = (tmp & 0xfff00000U) | dw_count;
			    status |= MRVL_AMG_WriteReg32( device, FlashCtrlDmaTransfers, tmp);

			    /* dma start */
			    status |= MRVL_AMG_ReadReg32( device, FlashCtrlDmaStart, &tmp);
			    tmp = (tmp & 0xfffffffeU) | 1U;
			    status |= MRVL_AMG_WriteReg32( device, FlashCtrlDmaStart, tmp);
	        }
	        
	        MRVL_AMG_Clock(&lastDataReady);

	        words_cnt = num_xfers;
        
	        while (1)
	        {
	        	status |= MRVL_AMG_ReadReg32( device, FlashStatDmaRd, &tmp);
		        dma_done = ((tmp >> done_dma) & 0x1U) == 1 ? MRVL_APHY_TRUE: MRVL_APHY_FALSE;
				buf_id = (tmp >> rdy_next) & 0x3U;
				buf0_rdy = (tmp >> data_rdy0) & 0x1U;
				buf1_rdy = (tmp >> data_rdy1) & 0x1U;

	            if ((buf_id != 0) && ((buf0_rdy != 0) || (buf1_rdy!= 0)))
	            {
	                if (words_cnt > bytesToDw(SPI_SHA_BUFFER_SIZE))
	                {
			        	words_to_read = bytesToDw(SPI_SHA_BUFFER_SIZE);
	                }
			        else
			        {
			        	words_to_read = words_cnt;
			        }

	                if (MRVL_AMG_MB_readDmaBuffer(device, buf_id, a_data, words_to_read, &data_size) != MRVL_APHY_STATUS_OK)
	                {
	                	MRVL_AMG_DBG_ERROR("Flash error: DMA read error.\n");
	                    MRVL_AMG_FreeMemory(a_data);
	                    a_data = NULL;
	                    status |= MRVL_APHY_STATUS_ERROR_GENERAL;
						break;
	                }

	                curr_addr += (words_to_read << 2);
	                data_size = curr_addr;
	                if (data_size % 0x2000 == 0)
	                {
	                    MRVL_AMG_DBG_INFO("Flash: FW read - bytes 0x%x\n", data_size);
	                }
	                words_cnt -= words_to_read;
	                status |= MRVL_AMG_MB_dmaReadAck(device, buf_id - 1);
	                MRVL_AMG_Clock(&lastDataReady);
	                
	            }
	            else if ((dma_done == MRVL_APHY_FALSE) && (MRVL_AMG_FLASH_isDmaTimeout(device, lastDataReady) == MRVL_APHY_FALSE))
	            {
	            	MRVL_AMG_DBG_ERROR("Flash error: DMA timeout.\n");
	                status |= MRVL_APHY_STATUS_ERROR_TIMEOUT;
	                break;
	            }

	            if (bytesToDw(data_size) >= dw_count || ((dma_done == MRVL_APHY_TRUE) && (buf_id == 0) && (buf0_rdy == 0) && (buf1_rdy == 0)))
	            {
	                status = MRVL_APHY_STATUS_OK;
	                break;
	            }
	        }

		}	

	    if (status == MRVL_APHY_STATUS_OK)
	    {
	    	MRVL_AMG_Clock(&timed);

    		MRVL_AMG_DBG_INFO("Flash: done reading, duration(s): %u\n", (timed - start_all) / MRVL_CLOCKS_PER_SEC);

		    for (MRVL_APHY_U32 i = 0; i < imageSize; i++)
		    {
		        if (i < data_size)
		        {
		            image[i] = a_data[i];
		        }
		        else {
		            image[i] = 0;
		        }
		    }
	        
		    MRVL_AMG_FreeMemory(a_data);
		    a_data = NULL;
	    }
	}
	

	MRVL_AMG_OptimizeMB(device, MRVL_APHY_FALSE);
	
    return status;
}

/**
 * @brief get flash information with control codes
 * @param[in] device		pointer to MRVL_DEV
 * @param[out] flashInfo	pointer to MRVL_AMG_FLASH
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_FW
 */
MRVL_APHY_STATUS MRVL_AMG_FLASH_getFlashInfo(MRVL_DEV_PTR device, MRVL_AMG_FLASH* flashInfo)
{
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_STATUS status;
	MRVL_APHY_U8 SFDP_Minor_Revision = 0;
	MRVL_APHY_U8 SFDP_Major_Revision = 0;
	MRVL_APHY_U8 SFDP_NPH;

	flashInfo->read_id_opcode = 0x9F;               /**< Read Jedec ID (usually 0x9F) */
    flashInfo->read_status_opcode = 0x05;           /**< Read Status Register (usually 0x05) */
    flashInfo->write_status_opcode = 0x01;          /**< Write Status Register (usually 0x01) */
    flashInfo->write_enable_opcode = 0x06;          /**< Write Enable (usually 0x06) */
    flashInfo->chip_erase_opcode = 0xC7;            /**< Chip Erase (usually 0xC7) */
    flashInfo->sector_erase_opcode = 0x20;          /**< Sector Erase - smallest erase area (usually 0x20) */
    flashInfo->read_opcode = 0x03;                  /**< Read Data (usually 0x03) */
    flashInfo->fast_read_opcode = 0x0B;             /**< Fast Read Data (usually 0x0B) */
    flashInfo->fast_read_dual_output_opcode = 0x3B; /**< Fast Read Data with Dual Output (usually 0x3B) */
    flashInfo->fast_read_quad_output_opcode = 0x6B; /**< Fast Read Data with Quad Output (usually 0x6B) */
    flashInfo->program_opcode = 0x02;               /**< Page Program (usually 0x02) */
    flashInfo->erase_program_resume_opcode = 0x7A;  /**< Erase/Programm resume (usually 0x7A) */
    flashInfo->volatile_sr_write_en_opcode = 0x50;  /**< Enable writing volatile bits of statur register */
    flashInfo->enable_reset_opcode = 0x66;          /**< Enable flash reset */
    flashInfo->soft_reset_opcode = 0x99;            /**< Soft reset */
    flashInfo->status_mask = 0x01;                  /**< Mask for Status Register that isolates ready / busy bit (usually 0x01) */
    flashInfo->status_value = 0x00;                 /**< Masked value that indicates that flash is NOT busy (usually 0x00) */
    flashInfo->chip_erase_addr_len = 0;             /**< Address length for Chip Erase command (usually 0) */
    flashInfo->page_size = 256;                    /**< Page Size (usually 256) */
    flashInfo->sector_page_size = 16;              /**< Number of Pages in Sector (usually 16) */
    flashInfo->read_status_reg2_opcode = 0xFF;      /**< Read status register address which contains quad enable bit */
    flashInfo->write_status_reg2_opcode = 0xFF;     /**< Write status register address which contains quad enable bit : W25Q32JV */
    flashInfo->status_reg_len = 1;                  /**< Length of Status Register */
  	flashInfo->is_quad_enable_supported = MRVL_APHY_TRUE;
    flashInfo->quad_enable_bit = 1;                 /**< QE bit offset */
    flashInfo->cmp_bit = 14;                         /**< Complement protect */
    flashInfo->srl_bit = 8;                         /**< Status register lock */
    flashInfo->erase_protection = MRVL_APHY_TRUE;                /**< Protection which should be cleared before erase */
    flashInfo->write_enable_before_qe = MRVL_APHY_FALSE;         /**< Need to enable writing to set QE bit */

	flashInfo->max_flash_erase_size = 0;
	flashInfo->max_erase_opcode = 0;
	flashInfo->erase_cycle = 0;
	flashInfo->is_SFDP_supported = MRVL_APHY_FALSE;



	MRVL_AMG_DBG_INFO("Flash: detect flash.\n");

	status = MRVL_AMG_FLASH_readSFDP(device, 0x0, &regVal);
	if (status == MRVL_APHY_STATUS_OK)
	{
		if (regVal != 0x50444653) 
		{
			MRVL_AMG_DBG_ERROR("Flash error: Unknown flash\n");
			MRVL_AMG_DBG_ERROR("Flash error: Device does not supports Serial Flash DiscoverableParameters(SFDP)\n");
			status = MRVL_APHY_STATUS_ERROR_GENERAL;
		}
		else
		{
			MRVL_AMG_DBG_INFO("Flash: Detected.\n");

			status |= MRVL_AMG_FLASH_readSFDP(device, 0x4, &regVal);

			SFDP_Minor_Revision = (MRVL_APHY_U8)(regVal & 0xFFU);
			SFDP_Major_Revision = (regVal >> 0x8) & 0xFFU;
			SFDP_NPH = (MRVL_APHY_U8)((regVal >> 0xF) & 0xFFU);
			MRVL_AMG_DBG_INFO("SFDP: Major_Revision::0x%x, Minor_Revision::0x%x,  Number of Parameter Header (NPH):: 0x%x\n", SFDP_Major_Revision, SFDP_Minor_Revision, SFDP_NPH);

			if (SFDP_Major_Revision != 0x1 || SFDP_Minor_Revision > 0x6) 
			{
				MRVL_AMG_DBG_INFO("Flash: Current SFDP reivison is not supported.\n");
				status = MRVL_APHY_STATUS_ERROR_GENERAL;
			}
			else
			{
				MRVL_AMG_DBG_INFO("Flash: Supports SFDP.\n");
				/*
				if (SFDP_NPH+1 == 0) 
				{
					MRVL_AMG_DBG_INFO("SFDP: Number of Parameter Header (NPH) must be > 0.\n");
					MRVL_AMG_DBG_INFO("SFDP: ERROR: insufficient infromation.\n");
					status = MRVL_APHY_STATUS_ERROR_GENERAL;
				}
				*/
				/* Initialize flashInfo */
				status |= MRVL_AMG_FLASH_initFlashInfo(device, flashInfo);
				/*
				if (status != MRVL_APHY_STATUS_OK) 
				{
					MRVL_AMG_DBG_INFO("SFDP: ERROR during flashInfo initialization.\n");
					return MRVL_APHY_STATUS_ERROR_GENERAL;
				}
				*/
			}
			
		}
		
	}

	return status;
}

/**
 * @brief get FW information
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] fwInfo	pointer to MRVL_AMG_FirmwareInfo
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_FW
 */
MRVL_APHY_STATUS MRVL_AMG_GetFirmwareInfo(MRVL_DEV_PTR device, MRVL_AMG_FirmwareInfo* fwInfo)
{
	MRVL_APHY_U32 regData = 0;
	MRVL_APHY_STATUS status;
	

	status = MRVL_AMG_ReadReg32(device, FwMmd1eSet0InfoFwVersion0, &regData);
	fwInfo->candidateRevision = (MRVL_APHY_U8)((regData >> revision_) & 0xFFU);
	fwInfo->minorRevision = (MRVL_APHY_U8)((regData >> minor_) & 0xFFU);

	status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0InfoFwVersion1, &regData);
	fwInfo->majorRevision =  (MRVL_APHY_U16)((regData >> major_) & 0xFFFU);
	fwInfo->streamRevision = (MRVL_APHY_U8)((regData >> stream_) & 0xFU);

	status |= MRVL_AMG_ReadReg32(device, FwSet0HeartbeatTimeLo, &regData);
	fwInfo->heartbeat = regData;
	status |= MRVL_AMG_ReadReg32(device, FwSet0HeartbeatTimeHi, &regData);
	fwInfo->heartbeat |= (MRVL_APHY_U64)(regData) << 32;

	status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0InfoProvIdPlatformId, &regData);
	fwInfo->platformID = regData & 0xFFFFU;
	status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0InfoProvIdProvFileVersion, &regData);
	fwInfo->provisioningBaseRevision = regData & 0xFFFFU;

	return status;
}


/**
 * @brief load flash
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] image	pointer/array to image bytes to write to flash
 * @param[in] imageSize	size of bytes to write
 * @param[in] performVerification	TRUE: readback flash and perform crc check; FALSE: skip verification
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_FW
 */
MRVL_APHY_STATUS MRVL_AMG_LoadFlash(MRVL_DEV_PTR device, MRVL_APHY_U8 image[], MRVL_APHY_U32 size, MRVL_APHY_BOOL performVerification)
{
	MRVL_AMG_FLASH flashInfo;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 imagecrc, fwcrc;

	status |= MRVL_AMG_FLASH_resetFWFlash(device);
	status |= MRVL_AMG_FLASH_getFlashInfo(device, &flashInfo);

	if (MRVL_APHY_STATUS_OK != status) {
		MRVL_AMG_DBG_INFO("Detect flash FAILED\n");
		MRVL_AMG_OptimizeMB(device, MRVL_APHY_FALSE);
	}
	else
	{
		if (performVerification == MRVL_APHY_TRUE) 
		{
			imagecrc = calculateCRC16(image, size);
		}
		
		status |= MRVL_AMG_FLASH_eraseFlash(device, &flashInfo);
		if (MRVL_APHY_STATUS_OK != status) 
		{
			MRVL_AMG_DBG_INFO("Erase flash FAILED\n");
			MRVL_AMG_OptimizeMB(device, MRVL_APHY_FALSE);
		}

		MRVL_AMG_DBG_INFO("Erase flash SUCCEEDED\n");
		
		status |= MRVL_AMG_FLASH_writeFlash(device, &flashInfo, image, size);
		if (MRVL_APHY_STATUS_OK != status) {
			MRVL_AMG_DBG_INFO("Write flash FAILED\n");
			MRVL_AMG_OptimizeMB(device, MRVL_APHY_FALSE);
		}
		else
		{
			if (performVerification == MRVL_APHY_TRUE) 
			{
				status |= MRVL_AMG_FLASH_readFlash(device, &flashInfo, image, size, MRVL_APHY_FALSE);
				if (MRVL_APHY_STATUS_OK == status)
				{
					fwcrc = calculateCRC16(image, size);
					if (imagecrc == fwcrc) {
						MRVL_AMG_DBG_INFO("Flash burned and verified. SUCCEEDED\n");
					}
					else {
						MRVL_AMG_DBG_INFO("CRC mismatch. Image verification FAILED\n");
						status = MRVL_APHY_STATUS_ERROR_GENERAL;
					}
				}
			}

			if (MRVL_APHY_STATUS_OK == status) 
			{
				status |= MRVL_AMG_ResetChip(device);
				MRVL_AMG_DBG_INFO("Reset chip and load FW\n");
				MRVL_AMG_DBG_INFO("Write flash SUCCEEDED\n");
			}
		}
	}	

	
	return status;
}
