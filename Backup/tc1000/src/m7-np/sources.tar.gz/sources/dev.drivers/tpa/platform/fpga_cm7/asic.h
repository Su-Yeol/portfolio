#ifndef ASCI_H_
#define ASCI_H_

extern void asic_setting(void);

#endif //ASCI_H_
