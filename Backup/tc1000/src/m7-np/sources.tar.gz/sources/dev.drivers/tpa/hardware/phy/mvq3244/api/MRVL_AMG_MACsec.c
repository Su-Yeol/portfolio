/**
 * @file MRVL_AMG_MACsec.c
 * @brief Marvell Multi-gig Automotive Ethernet PHY MAC and MACsec API source file 
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */

#include "MRVL_AMG_MACsec.h"
#include "MRVL_AMG_REG_PMP.h"


/******************************************************************************
 *      Static functions
 ******************************************************************************/

/**
 * @brief Read out a 48b value from a register through XMDI interface.
 *
 * @param[in] device PHY pointer
 * @param[in] regAddr register address within MAC section
 * @param[out] data pointer, function modifies this pointer to reflect readback 32b value
 * @return void
 *
 */
STATIC void readMACReg48(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U64* data)
{
	MRVL_APHY_U32 temp = 0;
	MRVL_APHY_U64 val = 0;

	MRVL_AMG_ReadReg32(device, regAddr, &temp);
	val = (MRVL_APHY_U64)temp;
	MRVL_AMG_ReadReg32(device, regAddr + 4, &temp);
	val |= (MRVL_APHY_U64)temp << 16;
	MRVL_AMG_ReadReg32(device, regAddr + 8, &temp);
	val |= (MRVL_APHY_U64)temp << 32;

	*data = val;
}

/**
 * @brief Calculate MACsec register address with register offset
 * 
 * @param[in]	base   base register
 * @param[in]	index  offset index
 * @param[in]	range  offset width
 * @return MRVL_APHY_U32 register address 
 * 
 */
STATIC MRVL_APHY_U32 GETADDR(MRVL_APHY_U32 base, MRVL_APHY_U8 index, MRVL_APHY_U32 range)
{
	return base + range * (MRVL_APHY_U32)index;
}

/* convert to VALIDATEFRAME Enum */
STATIC void convert2ValidateFrameEnum(MRVL_APHY_U16 value, MRVL_AMG_MCS_VALIDATEFRAME* validateFrame)
{
	if (0 == value)
	{
		*validateFrame = MRVL_AMG_MCS_VF_DISABLED;
	}
	else if (0x1U ==value )
	{
		*validateFrame = MRVL_AMG_MCS_VF_CHECK;
	}
	else if (0x2U == value)
	{
		*validateFrame = MRVL_AMG_MCS_VF_STRICT;
	}
	else
	{
		/* other values are considered as VF_NA */
		*validateFrame = MRVL_AMG_MCS_VF_NA;
	}
}

/* convert to STRIP_SECTAG_ICV Enum */
STATIC void convert2StripSectagEnum(MRVL_APHY_U16 value, MRVL_AMG_MCS_STRIP_SECTAG_ICV *stripSectag)
{
	if (0 == value)
	{
		*stripSectag = MRVL_AMG_MCS_SECTAG_ICV_BOTH_STRIP;
	}
	else if (0x1U ==value )
	{
		*stripSectag = MRVL_AMG_MCS_SECTAG_ICV_RESERVED;
	}
	else if (0x2U == value)
	{
		*stripSectag = MRVL_AMG_MCS_SECTAG_ICV_STRIP_ICV_ONLY;
	}
	else
	{
		/* other values are considered as NO_STRIP */
		*stripSectag = MRVL_AMG_MCS_SECTAG_ICV_NO_STRIP;
	}
}

/* convert to CIPHER_SUITE Enum */
STATIC MRVL_APHY_STATUS convert2CipherSuiteEnum(MRVL_APHY_U16 value, MRVL_AMG_MCS_CIPHER_SUITE *cipherSuite)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	if (0 == value)
	{
		*cipherSuite = MRVL_AMG_MCS_CIPHER_GCM_AES_128;
	}
	else if (0x1U ==value)
	{
		*cipherSuite = MRVL_AMG_MCS_CIPHER_GCM_AES_256;
	}
	else if (0x2U == value)
	{
		*cipherSuite = MRVL_AMG_MCS_CIPHER_GCM_AES_128_XPN;
	}
	else if (0x3U == value)
	{
		*cipherSuite = MRVL_AMG_MCS_CIPHER_GCM_AES_256_XPN;
	}
	else
	{
		/* report error */
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	return status;
}

/* convert to PACKET_TYPE Enum */
STATIC void convert2PacketTypeEnum(MRVL_APHY_U16 value, MRVL_AMG_MCS_PACKET_TYPE *packetType)
{
	switch (value)
	{
	case 0:
		*packetType = MRVL_AMG_MCS_PACKET_NO_VLAN_OR_MPLS;
		break;
	case 0x1U:
		*packetType = MRVL_AMG_MCS_PACKET_SINGLE_VLAN;
		break;
	case 0x2U:
		*packetType = MRVL_AMG_MCS_PACKET_DUAL_VLAN;
		break;
	case 0x3U:
		*packetType = MRVL_AMG_MCS_PACKET_MPLS;
		break;
	case 0x4U:
		*packetType = MRVL_AMG_MCS_PACKET_SINGLE_VLAN_FOLLOW_BY_MPLS;
		break;
	case 0x5U:
		*packetType = MRVL_AMG_MCS_PACKET_DUAL_VLAN_FOLLOW_BY_MPLS;
		break;
	default:
		/* rest values are all considered as unsupported */
		*packetType = MRVL_AMG_MCS_PACKET_UNSUPPORTED_TYPE;
		break;
	}
}

/* readback reg values and write to array */
STATIC void readValConvert2RuleArray(MRVL_DEV_PTR device, MRVL_APHY_U32 baseAddrData, MRVL_APHY_U32 baseAddrMask, MRVL_APHY_U32 keyMaskPair[][7])
{
	
	MRVL_APHY_U64 regVal64 = 0;
	MRVL_APHY_U64 regValMask64 = 0;
	MRVL_APHY_U32 i = 0;
	for (i = 0; i < 8; i = i + 2)
	{
		MRVL_AMG_MCS_ReadReg64(device, baseAddrData + MRVL_AMG_MCS_REG_BUS_WIDTH * i, &regVal64);
		MRVL_AMG_MCS_ReadReg64(device, baseAddrMask + MRVL_AMG_MCS_REG_BUS_WIDTH * i, &regValMask64);
		if (i < 6)
		{
			/* data */
			keyMaskPair[0][i] = (MRVL_APHY_U32)regVal64 & 0xFFFFFFFFU;
			keyMaskPair[0][i + 1] = (MRVL_APHY_U32)(regVal64 >> 32) & 0xFFFFFFFFU;
			/* mask */
			keyMaskPair[1][i] = (MRVL_APHY_U32)regValMask64 & 0xFFFFFFFFU;
			keyMaskPair[1][i + 1] = (MRVL_APHY_U32)(regValMask64 >> 32) & 0xFFFFFFFFU;
		}
		else
		{
			/* data */
			keyMaskPair[0][i] = (MRVL_APHY_U32)regVal64 & 0xFFFFFFFFU;
			/* mask */
			keyMaskPair[1][i] = (MRVL_APHY_U32)regValMask64 & 0xFFFFFFFFU;
		}
	}
}

/* convert array to rule */
STATIC void convert2Rule(MRVL_AMG_MCS_RULE* rule, MRVL_APHY_U32 keyMaskPair[][7])
{
	MRVL_APHY_U16 i = 0;
	/* assgin DA and SA values. each 6 bytpes */
	for (i = 0; i < 4; i++)
	{
		/* DA index 2 - 5 */
		rule->key_MAC_DA[i + 2] = (MRVL_APHY_U8)((keyMaskPair[0][0] >> ((3 - i) * 8)) & 0xFFU);
		rule->mask_MAC_DA[i + 2] = (MRVL_APHY_U8)((keyMaskPair[1][0] >> ((3 - i) * 8)) & 0xFFU);
	}
	for (i = 0; i < 2; i++)
	{
		/* DA index 0 and 1 */
		rule->key_MAC_DA[i] = (MRVL_APHY_U8)((keyMaskPair[0][1] >> ((1 - i) * 8)) & 0xFFU);
		rule->mask_MAC_DA[i] = (MRVL_APHY_U8)((keyMaskPair[1][1] >> ((1 - i) * 8)) & 0xFFU);
		/* SA index 4 and 5 */
		rule->key_MAC_SA[4 + i] = (MRVL_APHY_U8)((keyMaskPair[0][1] >> ((3 - i) * 8)) & 0xFFU);
		rule->mask_MAC_SA[4 + i] = (MRVL_APHY_U8)((keyMaskPair[1][1] >> ((3 - i) * 8)) & 0xFFU);
	}
	for (i = 0; i < 4; i++)
	{
		/* SA index 0 - 3 */
		rule->key_MAC_SA[i] = (MRVL_APHY_U8)((keyMaskPair[0][2] >> ((3 - i) * 8)) & 0xFFU);
		rule->mask_MAC_SA[i] = (MRVL_APHY_U8)((keyMaskPair[1][2] >> ((3 - i) * 8)) & 0xFFU);
	}
	/* assgin e types */
	rule->key_Ethertype = (MRVL_APHY_U16)(keyMaskPair[0][3] & 0xFFFFU);
	rule->mask_Ethertype = (MRVL_APHY_U16)(keyMaskPair[1][3] & 0xFFFFU);

	if (MRVL_APHY_TRUE == rule->isMPLS)
	{
		/* assgin mpls related */
		rule->key_outer1.mpls.MPLS_label = ((keyMaskPair[0][3] >> 16) & 0xFFFFU) + ((keyMaskPair[0][4] & 0xFU) << 16);
		rule->mask_outer1.mpls.MPLS_label = ((keyMaskPair[1][3] >> 16) & 0xFFFFU) + ((keyMaskPair[1][4] & 0xFU) << 16);
		rule->key_outer1.mpls.exp = (MRVL_APHY_U8)((keyMaskPair[0][4] >> 4) & 0x7U);
		rule->mask_outer1.mpls.exp = (MRVL_APHY_U8)((keyMaskPair[1][4] >> 4) & 0x7U);
		rule->key_outer2.mpls.MPLS_label = (keyMaskPair[0][4] >> 8) & 0xFFFFFU;
		rule->mask_outer2.mpls.MPLS_label = (keyMaskPair[1][4] >> 8) & 0xFFFFFU;
		rule->key_outer2.mpls.exp = (MRVL_APHY_U8)((keyMaskPair[0][4] >> 28) & 0xFU);
		rule->mask_outer2.mpls.exp = (MRVL_APHY_U8)((keyMaskPair[1][4] >> 28) & 0xFU);
	}
	else
	{
		/* assgin vlan related */
		rule->key_outer1.vlanTag.VID = (MRVL_APHY_U16)((keyMaskPair[0][3] >> 16) & 0xFFFU);
		rule->mask_outer1.vlanTag.VID = (MRVL_APHY_U16)((keyMaskPair[1][3] >> 16) & 0xFFFU);
		rule->key_outer1.vlanTag.PRI_CFI = (MRVL_APHY_U8)((keyMaskPair[0][4] >> 4) & 0xFU);
		rule->mask_outer1.vlanTag.PRI_CFI = (MRVL_APHY_U8)((keyMaskPair[1][4] >> 4) & 0xFU);
		rule->key_outer2.vlanTag.VID = (MRVL_APHY_U16)((keyMaskPair[0][4] >> 8) & 0xFFFU);
		rule->mask_outer2.vlanTag.VID = (MRVL_APHY_U16)((keyMaskPair[1][4] >> 8) & 0xFFFU);
		rule->key_outer2.vlanTag.PRI_CFI = (MRVL_APHY_U8)((keyMaskPair[0][4] >> 28) & 0xFU);
		rule->mask_outer2.vlanTag.PRI_CFI = (MRVL_APHY_U8)((keyMaskPair[1][4] >> 28) & 0xFU);
	}
	/* assgin bonus data, set custom tag */
	rule->key_bonus_data = (MRVL_APHY_U16)(keyMaskPair[0][5] & 0xFFFFU);
	rule->mask_bonus_data = (MRVL_APHY_U16)(keyMaskPair[1][5] & 0xFFFFU);
	/* assgin tag match, set custom tag */
	rule->key_tag_match_bitmap = (MRVL_APHY_U8)((keyMaskPair[0][5] >> 16) & 0xFFU);
	rule->mask_tag_match_bitmap = (MRVL_APHY_U8)((keyMaskPair[1][5] >> 16) & 0xFFU);
	/* assgin packet_type */
	convert2PacketTypeEnum((MRVL_APHY_U16)((keyMaskPair[0][5] >> 24) & 0xFU), &(rule->key_packet_type));
	rule->mask_packet_type = (MRVL_APHY_U8)((keyMaskPair[1][5] >> 24) & 0xFU);
	/* assgin vlan tag related */
	rule->key_outer_vlan_type = (MRVL_APHY_U16)((keyMaskPair[0][5] >> 28) & 0x7U);
	rule->mask_outer_vlan_type = (MRVL_APHY_U16)((keyMaskPair[1][5] >> 28) & 0x7U);
	rule->key_inner_vlan_type = (MRVL_APHY_U16)(((keyMaskPair[0][5] >> 31) & 0x1U) + ((keyMaskPair[0][6] & 0x3U) << 1));
	rule->mask_inner_vlan_type = (MRVL_APHY_U16)(((keyMaskPair[1][5] >> 31) & 0x1U) + ((keyMaskPair[1][6] & 0x3U) << 1));
	rule->key_num_tags = (MRVL_APHY_U8)((keyMaskPair[0][6] >> 2) & 0x7FU);
	rule->mask_num_tags = (MRVL_APHY_U8)((keyMaskPair[1][6] >> 2) & 0x7FU);
	/* assgin mpls related */
	rule->key_express = (MRVL_APHY_U8)((keyMaskPair[0][6] >> 9) & 0x1U);
	rule->mask_express = (MRVL_APHY_U8)((keyMaskPair[1][6] >> 9) & 0x1U);
}

/* covert rule to array */
STATIC void convert2ArrayFromRule(MRVL_AMG_MCS_RULE* rule, MRVL_APHY_U32 keyMaskPair[][7])
{
	MRVL_APHY_U16 i = 0;
	/* place DA and SA in array for later reg write */
	for (i = 0; i < 4; i++)
	{
		/* 32bit array[][0] stores DA 2 - 5, 4 bytes */
		keyMaskPair[0][0] += (MRVL_APHY_U32)rule->key_MAC_DA[2 + i] << ((3 - i) * 8);
		keyMaskPair[1][0] += (MRVL_APHY_U32)rule->mask_MAC_DA[2 + i] << ((3 - i) * 8);
	}
	for (i = 0; i < 2; i++)
	{
		/* 32bit array[][1] stores DA 0,1 and SA 4,5, 4 bytes */
		keyMaskPair[0][1] += (MRVL_APHY_U32)rule->key_MAC_DA[i] << ((1 - i) * 8);
		keyMaskPair[1][1] += (MRVL_APHY_U32)rule->mask_MAC_DA[i] << ((1 - i) * 8);
		keyMaskPair[0][1] += (MRVL_APHY_U32)rule->key_MAC_SA[4 + i] << ((3 - i) * 8);
		keyMaskPair[1][1] += (MRVL_APHY_U32)rule->mask_MAC_SA[4 + i] << ((3 - i) * 8);
	}
	for (i = 0; i < 4; i++)
	{
		/* 32bit array[][2] stores SA 0 - 3, 4 bytes */
		keyMaskPair[0][2] += (MRVL_APHY_U32)rule->key_MAC_SA[i] << ((3 - i) * 8);
		keyMaskPair[1][2] += (MRVL_APHY_U32)rule->mask_MAC_SA[i] << ((3 - i) * 8);
	}
	if (MRVL_APHY_TRUE == rule->isMPLS)
	{
		/* compose array[][3,4] with mpls settings */
		keyMaskPair[0][3] = (MRVL_APHY_U32)rule->key_Ethertype + (((rule->key_outer1.mpls.MPLS_label & 0xFFFFFU) & 0xFFFFU) << 16);
		keyMaskPair[1][3] = (MRVL_APHY_U32)rule->mask_Ethertype + (((rule->mask_outer1.mpls.MPLS_label & 0xFFFFFU) & 0xFFFFU) << 16);
		keyMaskPair[0][4] = (((rule->key_outer1.mpls.MPLS_label & 0xFFFFFU) >> 16) & 0xFU) 
							+ (((MRVL_APHY_U32)rule->key_outer1.mpls.exp & 0x7U) << 4) 
							+ ((rule->key_outer2.mpls.MPLS_label & 0xFFFFFU) << 8) 
							+ (((MRVL_APHY_U32)rule->key_outer2.mpls.exp & 0x7U) << 28);
		keyMaskPair[1][4] = (((rule->mask_outer1.mpls.MPLS_label & 0xFFFFFU) >> 16) & 0xFU) 
							+ (((MRVL_APHY_U32)rule->mask_outer1.mpls.exp & 0x7U) << 4) 
							+ ((rule->mask_outer2.mpls.MPLS_label & 0xFFFFFU) << 8) 
							+ (((MRVL_APHY_U32)rule->mask_outer2.mpls.exp & 0x7U) << 28);
	}
	else
	{
		/* compose array[][3,4] with vlan settings */
		keyMaskPair[0][3] = (MRVL_APHY_U32)rule->key_Ethertype + ((((MRVL_APHY_U32)rule->key_outer1.vlanTag.VID & 0xFFFU) & 0xFFFU) << 16);
		keyMaskPair[1][3] = (MRVL_APHY_U32)rule->mask_Ethertype + ((((MRVL_APHY_U32)rule->mask_outer1.vlanTag.VID & 0xFFFU) & 0xFFFU) << 16) + ((MRVL_APHY_U32)0xFU << 28);
		keyMaskPair[0][4] = (((MRVL_APHY_U32)rule->key_outer1.vlanTag.PRI_CFI & 0xFU) << 4) 
							+ ((((MRVL_APHY_U32)rule->key_outer2.vlanTag.VID & 0xFFFU)) << 8) 
							+ (((MRVL_APHY_U32)rule->key_outer2.vlanTag.PRI_CFI & 0xFU) << 28);
		keyMaskPair[1][4] = 0xFU + (((MRVL_APHY_U32)rule->mask_outer1.vlanTag.PRI_CFI & 0xFU) << 4) 
							+ (((MRVL_APHY_U32)rule->mask_outer2.vlanTag.VID & 0xFFFU) << 8) 
							+ ((MRVL_APHY_U32)0xFFU << 20) 
							+ (((MRVL_APHY_U32)rule->mask_outer2.vlanTag.PRI_CFI & 0xFU) << 28);
	}
	/* compose array[][5,6] with custom tag settings */
	keyMaskPair[0][5] = ((MRVL_APHY_U32)rule->key_bonus_data & 0xFFFFU) 
						+ (((MRVL_APHY_U32)rule->key_tag_match_bitmap & 0xFFU) << 16) 
						+ (((MRVL_APHY_U32)rule->key_packet_type & 0xFU) << 24) 
						+ (((MRVL_APHY_U32)rule->key_outer_vlan_type & 0x7U) << 28) 
						+ ((((MRVL_APHY_U32)rule->key_inner_vlan_type & 0x7U) & 1U) << 31);
	keyMaskPair[1][5] = ((MRVL_APHY_U32)rule->mask_bonus_data & 0xFFFFU) 
						+ (((MRVL_APHY_U32)rule->mask_tag_match_bitmap & 0xFFU) << 16) 
						+ (((MRVL_APHY_U32)rule->mask_packet_type & 0xFU) << 24) 
						+ (((MRVL_APHY_U32)rule->mask_outer_vlan_type & 0x7U) << 28) 
						+ ((((MRVL_APHY_U32)rule->mask_inner_vlan_type & 0x7U) & 1U) << 31);
	keyMaskPair[0][6] = ((((MRVL_APHY_U32)rule->key_inner_vlan_type & 0x7U) >> 1) & 0x3U) 
						+ (((MRVL_APHY_U32)rule->key_num_tags & 0x7FU) << 2) 
						+ (((MRVL_APHY_U32)rule->key_express & 0x1U) << 9);
	keyMaskPair[1][6] = ((((MRVL_APHY_U32)rule->mask_inner_vlan_type & 0x7U) >> 1) & 0x3U) 
						+ (((MRVL_APHY_U32)rule->mask_num_tags & 0x7FU) << 2) 
						+ (((MRVL_APHY_U32)rule->mask_express & 0x1U) << 9) 
						+ ((MRVL_APHY_U32)0x3FFFFFU << 10);
}

/* write array into register */
STATIC void writeValFromArray(MRVL_DEV_PTR device, MRVL_APHY_U32 BaseAddr_Data, MRVL_APHY_U32 BaseAddr_Mask, MRVL_APHY_U32 keyMaskPair[][7])
{
	MRVL_APHY_U64 regVal64 = 0;
	MRVL_APHY_U32 regVal32, i = 0;
	for (i = 0; i < 6; i = i + 2)
	{
		/* compose 64bit value from 32bit key array */
		regVal64 = keyMaskPair[0][i] | ((MRVL_APHY_U64)keyMaskPair[0][i + 1] << 32);
		regVal32 = BaseAddr_Data + MRVL_AMG_MCS_REG_BUS_WIDTH * i;
		/* write 64bit value */
		MRVL_AMG_MCS_WriteReg64(device, regVal32, regVal64);
		/* compose 64bit value from 32bit mask array */
		regVal64 = keyMaskPair[1][i] | ((MRVL_APHY_U64)keyMaskPair[1][i + 1] << 32);
		regVal32 = BaseAddr_Mask + MRVL_AMG_MCS_REG_BUS_WIDTH * i;
		/* write 64bit value */
		MRVL_AMG_MCS_WriteReg64(device, regVal32, regVal64);
	}
	/* the last 64bit reg value is actually 32bit */
	regVal32 = BaseAddr_Data + MRVL_AMG_MCS_REG_BUS_WIDTH * 6;
	/* but still need to call 64bit write */
	MRVL_AMG_MCS_WriteReg64(device, regVal32, keyMaskPair[0][6]);
	regVal32 = BaseAddr_Mask + MRVL_AMG_MCS_REG_BUS_WIDTH * 6;
	MRVL_AMG_MCS_WriteReg64(device, regVal32, 0xFFFFFFFF00000000U | keyMaskPair[1][6]);
}

/* write SAK value to register */
STATIC void writeSAKValue(MRVL_DEV_PTR device, MRVL_APHY_U32 BaseAddr, MRVL_APHY_U8* keyId)
{
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 i = 0;

	for (i = 8; i > 0; i -= 2)
	{
		/* compose every 64bit value from array */
		regVal = ((MRVL_APHY_U64)keyId[(i - 2) * 4]) << 24;
		regVal |= ((MRVL_APHY_U64)keyId[(i - 2) * 4 + 1]) << 16;
		regVal |= ((MRVL_APHY_U64)keyId[(i - 2) * 4 + 2]) << 8;
		regVal |= (MRVL_APHY_U64)keyId[(i - 2) * 4 + 3];
		regVal <<= 32;

		regVal |= ((MRVL_APHY_U64)keyId[(i - 1) * 4]) << 24;
		regVal |= ((MRVL_APHY_U64)keyId[(i - 1) * 4 + 1]) << 16;
		regVal |= ((MRVL_APHY_U64)keyId[(i - 1) * 4 + 2]) << 8;
		regVal |= (MRVL_APHY_U64)keyId[(i - 1) * 4 + 3];
		/* write the value to register */
		MRVL_AMG_MCS_WriteReg64(device, BaseAddr + (8 - i) * MRVL_AMG_MCS_REG_BUS_WIDTH, regVal);
	}
}

/* write Hash value to register */
STATIC void writeHashValue(MRVL_DEV_PTR device, MRVL_APHY_U32 BaseAddr, MRVL_APHY_U8* hashKeyId)
{
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 i = 0;

	for (i = 4; i > 0; i -= 2)
	{
		/* compose every 64bit value from array */
		regVal = ((MRVL_APHY_U64)hashKeyId[(i - 2) * 4]) << 24;
		regVal |= ((MRVL_APHY_U64)hashKeyId[(i - 2) * 4 + 1]) << 16;
		regVal |= ((MRVL_APHY_U64)hashKeyId[(i - 2) * 4 + 2]) << 8;
		regVal |= (MRVL_APHY_U64)hashKeyId[(i - 2) * 4 + 3];
		regVal <<= 32;

		regVal |= ((MRVL_APHY_U64)hashKeyId[(i - 1) * 4]) << 24;
		regVal |= ((MRVL_APHY_U64)hashKeyId[(i - 1) * 4 + 1]) << 16;
		regVal |= ((MRVL_APHY_U64)hashKeyId[(i - 1) * 4 + 2]) << 8;
		regVal |= (MRVL_APHY_U64)hashKeyId[(i - 1) * 4 + 3];

		/* write the value to register */
		MRVL_AMG_MCS_WriteReg64(device, BaseAddr + (4 - i) * MRVL_AMG_MCS_REG_BUS_WIDTH, regVal);
	}
}

/* write Salt and SSCI value to register */
STATIC void writeSaltAndSSCIValue(MRVL_DEV_PTR device, MRVL_APHY_U32 BaseAddr, MRVL_APHY_U32 ssci, MRVL_APHY_U8* salt)
{
	MRVL_APHY_U64 regVal = 0;
	/* compose 64bit value from array */
	regVal = ((MRVL_APHY_U64)salt[4]) << 24;
	regVal |= ((MRVL_APHY_U64)salt[5]) << 16;
	regVal |= ((MRVL_APHY_U64)salt[6]) << 8;
	regVal |= ((MRVL_APHY_U64)salt[7]);
	regVal <<= 32;
	regVal |= (MRVL_APHY_U64)salt[8] << 24;
	regVal |= ((MRVL_APHY_U64)salt[9]) << 16;
	regVal |= ((MRVL_APHY_U64)salt[10]) << 8;
	regVal |= ((MRVL_APHY_U64)salt[11]);
	/* write the value to register */
	MRVL_AMG_MCS_WriteReg64(device, BaseAddr + 24, regVal);
	/* compose another 64bit value from array */
	regVal = ((MRVL_APHY_U64)ssci) << 32;
	regVal |= ((MRVL_APHY_U64)salt[0]) << 24;
	regVal |= ((MRVL_APHY_U64)salt[1]) << 16;
	regVal |= ((MRVL_APHY_U64)salt[2]) << 8;
	regVal |= ((MRVL_APHY_U64)salt[3]);
	/* write the value to register */
	MRVL_AMG_MCS_WriteReg64(device, BaseAddr + 40, regVal);
}

/* write SAK value to register */
STATIC void readValConvert2SAK(MRVL_DEV_PTR device, MRVL_APHY_U32 baseAddr, MRVL_APHY_U8* keyId)
{
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 i = 0;

	for (i = 8; i > 0; i -= 2)
	{
		/* readback value from reg */
		MRVL_AMG_MCS_ReadReg64(device, baseAddr + (8 - i) * MRVL_AMG_MCS_REG_BUS_WIDTH, &regVal);
		/* convert value to array */
		keyId[(i - 1) * 4] = (MRVL_APHY_U8)((regVal >> 24) & 0xFFU);
		keyId[(i - 1) * 4 + 1] = (MRVL_APHY_U8)((regVal >> 16) & 0xFFU);
		keyId[(i - 1) * 4 + 2] = ((MRVL_APHY_U8)(regVal >> 8) & 0xFFU);
		keyId[(i - 1) * 4 + 3] = (MRVL_APHY_U8)((regVal >> 0) & 0xFFU);
		keyId[(i - 2) * 4] = (MRVL_APHY_U8)((regVal >> 56) & 0xFFU);
		keyId[(i - 2) * 4 + 1] = (MRVL_APHY_U8)((regVal >> 48) & 0xFFU);
		keyId[(i - 2) * 4 + 2] = (MRVL_APHY_U8)((regVal >> 40) & 0xFFU);
		keyId[(i - 2) * 4 + 3] = (MRVL_APHY_U8)((regVal >> 32) & 0xFFU);
	}
}

/* write Hash value to register */
STATIC void readValConvert2Hash(MRVL_DEV_PTR device, MRVL_APHY_U32 BaseAddr, MRVL_APHY_U8* hashKeyId)
{
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U32 i = 0;

	for (i = 4; i > 0; i -= 2)
	{
		/* readback value from reg */
		MRVL_AMG_MCS_ReadReg64(device, BaseAddr + (4 - i) * MRVL_AMG_MCS_REG_BUS_WIDTH, &regVal);
		/* convert value to array */
		hashKeyId[(i - 1) * 4] = (MRVL_APHY_U8)((regVal >> 24) & 0xFFU);
		hashKeyId[(i - 1) * 4 + 1] = (MRVL_APHY_U8)((regVal >> 16) & 0xFFU);
		hashKeyId[(i - 1) * 4 + 2] = (MRVL_APHY_U8)((regVal >> 8) & 0xFFU);
		hashKeyId[(i - 1) * 4 + 3] = (MRVL_APHY_U8)((regVal >> 0) & 0xFFU);
		hashKeyId[(i - 2) * 4] = (MRVL_APHY_U8)((regVal >> 56) & 0xFFU);
		hashKeyId[(i - 2) * 4 + 1] = (MRVL_APHY_U8)((regVal >> 48) & 0xFFU);
		hashKeyId[(i - 2) * 4 + 2] = (MRVL_APHY_U8)((regVal >> 40) & 0xFFU);
		hashKeyId[(i - 2) * 4 + 3] = (MRVL_APHY_U8)((regVal >> 32) & 0xFFU);
	}
}

/* write Salt and SSCI value to register */
STATIC void readValConvert2SaltSSCI(MRVL_DEV_PTR device, MRVL_APHY_U32 BaseAddr, MRVL_APHY_U32* ssci, MRVL_APHY_U8* salt)
{
	MRVL_APHY_U64 regVal = 0;
	MRVL_AMG_MCS_ReadReg64(device, BaseAddr + 24, &regVal);
	/* big endian, assign value in reverse order */
	salt[4] = (MRVL_APHY_U8)((regVal >> 56) & 0xFFU);
	salt[5] = (MRVL_APHY_U8)((regVal >> 48) & 0xFFU);
	salt[6] = (MRVL_APHY_U8)((regVal >> 40) & 0xFFU);
	salt[7] = (MRVL_APHY_U8)((regVal >> 32) & 0xFFU);
	salt[8] = (MRVL_APHY_U8)((regVal >> 24) & 0xFFU);
	salt[9] = (MRVL_APHY_U8)((regVal >> 16) & 0xFFU);
	salt[10] = (MRVL_APHY_U8)((regVal >> 8) & 0xFFU);
	salt[11] = (MRVL_APHY_U8)((regVal) & 0xFFU);
	MRVL_AMG_MCS_ReadReg64(device, BaseAddr + 40, &regVal);
	salt[0] = (MRVL_APHY_U8)((regVal >> 24) & 0xFFU);
	salt[1] = (MRVL_APHY_U8)((regVal >> 16) & 0xFFU);
	salt[2] = (MRVL_APHY_U8)((regVal >> 8) & 0xFFU);
	salt[3] = (MRVL_APHY_U8)((regVal) & 0xFFU);
	*ssci = (MRVL_APHY_U32)((regVal >> 32) & 0xFFFFFFFFU);
}



/******************************************************************************
 *      MCS register access
 ******************************************************************************/

 /**
  * @brief Read out a 16b value from a register through XMDI interface.
  *
  * @param[in] device PHY pointer
  * @param[in] regAddr register address within MAC section
  * @param[out] data pointer, function modifies this pointer to reflect readback 16b value
  * @return void
  *
  * @ingroup MCS_Reg_Access
  */
void MRVL_AMG_MCS_ReadReg16(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U16* data)
{
	MRVL_APHY_U32 temp = 0;
	MRVL_AMG_ReadReg32(device, regAddr, &temp);
	*data = (MRVL_APHY_U16) (temp & 0xFFFFU);
}

/**
 * @brief Write a 16b value into a register through XMDI interface.
 *
 * @param[in] device PHY pointer
 * @param[in] regAddr register address within MAC section
 * @param[in] data 16b value to write into register
 * @return void
 *
 * @ingroup MCS_Reg_Access
 */
void MRVL_AMG_MCS_WriteReg16(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U16 data)
{
	MRVL_AMG_WriteReg32(device, regAddr, data & 0xFFFFU);
}

/**
 * @brief Read out a 32b value from a register through XMDI interface.
 * 
 * @param[in] device PHY pointer
 * @param[in] regAddr register address within MAC section
 * @param[out] data pointer, function modifies this pointer to reflect readback 32b value
 * @return void 
 * 
 * @ingroup MCS_Reg_Access
 */
void MRVL_AMG_MCS_ReadReg32(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U32* data)
{
	MRVL_APHY_U32 temp = 0;
	MRVL_APHY_U32 val = 0;

	MRVL_AMG_ReadReg32(device, regAddr, &temp);
	val = temp;
	MRVL_AMG_ReadReg32(device, regAddr + 4, &temp);
	val |= temp << 16;

	*data = val;
}

/**
 * @brief Write a 32b value into a register through XMDI interface.
 * 
 * @param[in] device PHY pointer
 * @param[in] regAddr register address within MAC section
 * @param[in] data 32b value to write into register
 * @return void 
 * 
 * @ingroup MCS_Reg_Access
 */
void MRVL_AMG_MCS_WriteReg32(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U32 data)
{
	MRVL_AMG_WriteReg32(device, regAddr, data & 0xFFFFU);
	MRVL_AMG_WriteReg32(device, regAddr + 4, (data >> 16) & 0xFFFFU);
}

/**
 * @brief Read out a 64b value from a register through XMDI interface.
 * 
 * @param[in] device PHY pointer
 * @param[in] regAddr register address within MAC section
 * @param[out] data data pointer function modifies this pointer to reflect readback 64b value
 * @return void 
 * 
 * @ingroup MCS_Reg_Access
 */
void MRVL_AMG_MCS_ReadReg64(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U64* data)
{
	MRVL_APHY_U32 temp = 0;
	MRVL_APHY_U64 val = 0;

	MRVL_AMG_MCS_ReadReg32(device, regAddr, &temp);
	val = temp;
	MRVL_AMG_MCS_ReadReg32(device, regAddr + 8, &temp);
	val |= (MRVL_APHY_U64)temp << 32;
	*data = val;
}

/**
 * @brief Write a 64b value into a register through XMDI interface.
 * 
 * @param[in] device PHY pointer
 * @param[in] regAddr register address within MAC section
 * @param[in] data 64b value to write into register
 * @return void 
 * 
 * @ingroup MCS_Reg_Access
 */
void MRVL_AMG_MCS_WriteReg64(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U64 data)
{
	MRVL_AMG_MCS_WriteReg32(device, regAddr, (MRVL_APHY_U32)(data & 0xFFFFFFFFU));
	MRVL_AMG_MCS_WriteReg32(device, regAddr + 8, (MRVL_APHY_U32)((data >> 32) & 0xFFFFFFFFU));
}


/******************************************************************************
 *      General Control for MACsec operation
 ******************************************************************************/

/**
 * @brief initialization sequence to config, enable and deploy MACsec
 * 
 * @param[in] device PHY pointer
 * @param[in] speed MAC speed: 10G, 5G or 2.5G
 * @param[in] powerMode MAC power mode. MRVL_AMG_MAC_LOW_LATENCY or MRVL_AMG_MAC_LOW_POWER
 * @param[in] fwdMode forward mode: cut-through or store&forward
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_Init(MRVL_DEV_PTR device, MRVL_AMG_MAC_POWER_MODE powerMode, MRVL_AMG_MAC_FWD_MODE fwdMode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;

	MRVL_AMG_MAC_Init(device, powerMode, fwdMode);

	/* disable tx / rx reset */
	MRVL_AMG_MCS_WriteReg16(device, MRVL_AMG_MCS_RST_RX_CTRL, 0);
	MRVL_AMG_MCS_WriteReg16(device, MRVL_AMG_MCS_RST_TX_CTRL, 0);

	/* release reset */
	MRVL_AMG_MCS_WriteReg16(device, MRVL_AMG_MCS_RST_MASTER_CTRL, 0x0);

	/* enable, deploy MACsec */
	status |= MRVL_AMG_MCS_SetMCSPower(device, MRVL_AMG_MCS_POWER_ON);
	status |= MRVL_AMG_MCS_SetDataPath(device, MRVL_AMG_MCS_DP_IN);

	/* reset all MACsec entries */
	status |= MRVL_AMG_MCS_DisableAllEntry(device);

	/* configure preempt early tx / rx */
	MRVL_AMG_MCS_WriteReg32(device, MRVL_AMG_MCS_TX_PREEMPT_EARLY, 0xB);
	MRVL_AMG_MCS_WriteReg32(device, MRVL_AMG_MCS_RX_PREEMPT_EARLY, 0xF);

	return status;
}

/**
 * @brief disable MACsec and remove MACsec from datapath
 * 
 * @param[in] device PHY pointer
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_Disable(MRVL_DEV_PTR device)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	/* powerdown MAC */
	status |= MRVL_AMG_MCS_SetMCSPower(device, MRVL_AMG_MCS_POWER_OFF);
	/* remove MAC from datapath */
	status |= MRVL_AMG_MCS_SetDataPath(device, MRVL_AMG_MCS_DP_BYPASS);
	return status;
}

/**
 * @brief config MACsec block power
 * 
 * @param device PHY pointer
 * @param power MRVL_AMG_MCS_POWER_ON: powerup MACsec. MRVL_AMG_MCS_POWER_OFF powerdown MACsec
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetMCSPower(MRVL_DEV_PTR device, MRVL_AMG_MCS_POWER power)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regAddr = MRVL_AMG_PMP_CR_CLK_RST_CTRL_CG_PMP;
	MRVL_APHY_U16 data = 0;
	MRVL_AMG_MCS_ReadReg16(device, regAddr, &data);
	if(MRVL_AMG_MCS_POWER_ON == power)
	{
		/* power up MACsec */
		data = (data & 0xFFEFU) | (0x1U << 4);
	}
	else
	{
		/* power down MACsec */
		data = data & 0xFFEFU;
	
	}
	
	MRVL_AMG_MCS_WriteReg16(device, regAddr, data);
	return status;
}

/**
 * @brief check if MACsec is powered up and ok to program
 * 
 * @param[in] device PHY pointer
 * @param[out] power function modifies this pointer to reflect MACsec power: MRVL_AMG_MCS_POWER_OFF or MRVL_AMG_MCS_POWER_ON
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetMCSPower(MRVL_DEV_PTR device, MRVL_AMG_MCS_POWER *power)
{
	MRVL_APHY_U32 regAddr = MRVL_AMG_PMP_CR_CLK_RST_CTRL_CG_PMP;
	MRVL_APHY_U16 data = 0;
	MRVL_AMG_MCS_ReadReg16(device, regAddr, &data);
	data &= 0x10U;

	if (0x0 == data)
	{
		*power = MRVL_AMG_MCS_POWER_OFF;
	}
	else
	{
		*power = MRVL_AMG_MCS_POWER_ON;
	}
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Set MMAC in path or bypass MMAC.
 * Use this function to deploy/undeploy MACsec after initialization
 * 
 * @param[in] device PHY pointer
 * @param[in] path MRVL_AMG_MCS_DP_BYPASS or MRVL_AMG_MCS_DP_IN
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetDataPath(MRVL_DEV_PTR device, MRVL_AMG_MCS_DATAPATH path)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regAddr = MRVL_AMG_PMP_CR_HW_CFG_CTRL_HW;
	MRVL_APHY_U16 data = 0;

	MRVL_AMG_MCS_ReadReg16(device, regAddr, &data);
	/* enable/bypass MACsec, bit 1 */
	if (MRVL_AMG_MCS_DP_IN == path)
	{
		data &= ~((MRVL_APHY_U16)0x2);
	}
	else
	{
		data |= 0x2U;
	}

	MRVL_AMG_MCS_WriteReg16(device, regAddr, data);

	return status;
}

/**
 * @brief check if MMAC is in datapath
 * 
 * @param[in] device PHY pointer
 * @param[out] path function modifies this pointer to reflect datapath setting: MRVL_AMG_MCS_DP_BYPASS or MRVL_AMG_MCS_DP_IN
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetDataPath(MRVL_DEV_PTR device, MRVL_AMG_MCS_DATAPATH* path)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regAddr = MRVL_AMG_PMP_CR_HW_CFG_CTRL_HW;
	MRVL_APHY_U16 data = 0;

	MRVL_AMG_MCS_ReadReg16(device, regAddr, &data);
	/* enable/bypass MACsec, bit 1 */
	if (((data >> 1) & 0x1U) == 0x1)
	{
		*path = MRVL_AMG_MCS_DP_BYPASS;
	}
	else
	{
		*path = MRVL_AMG_MCS_DP_IN;
	}

	return status;
}

/**
 * @brief Reset MACsec: disable all cam entry
 * 
 * @param[in] device PHY pointer
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_DisableAllEntry(MRVL_DEV_PTR device)
{
	/* dsiable cam rule entries */
	MRVL_AMG_MCS_WriteReg32(device,  MRVL_AMG_MCS_TX_FLOWID_TCAM_ENABLE, 0);
	MRVL_AMG_MCS_WriteReg32(device, MRVL_AMG_MCS_RX_FLOWID_TCAM_ENABLE, 0);
	
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief MACsec Operation configuration
 * 
 * @param[in] device PHY pointer
 * @param[in] isEnable TRUE: enable MACsec operation: handle traffic. FALSE: disable operation, traffic flows through without modification.
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetChannelEnable(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEnable)
{
	if (MRVL_APHY_TRUE == isEnable)
	{
		MRVL_AMG_MCS_WriteReg32(device, MRVL_AMG_MCS_CHANNEL_BYPASS, 0);
		MRVL_AMG_MCS_WriteReg32(device, MRVL_AMG_MCS_CHANNEL_BYPASS + 8, 0);
	}
	else
	{
		MRVL_AMG_MCS_WriteReg32(device, MRVL_AMG_MCS_CHANNEL_BYPASS, 1);
		MRVL_AMG_MCS_WriteReg32(device, MRVL_AMG_MCS_CHANNEL_BYPASS + 8, 1);
	}
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief check if MACsec operation is enabled
 * 
 * @param[in] device PHY pointer
 * @param[out] isEnable function modifies this pointer to reflect if MACsec operation is enabled or not
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetChannelEnable(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isEnable)
{
	MRVL_APHY_U32 regVal;
	MRVL_AMG_MCS_ReadReg32(device, MRVL_AMG_MCS_CHANNEL_BYPASS, &regVal);
	*isEnable = (regVal & 0x1U) == 0 ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
	return MRVL_APHY_STATUS_OK;
}


/******************************************************************************
 *      MAC Control
 ******************************************************************************/

/**
 * @brief Initialize MAC(Power on MAC and datapath go through MAC)
 * 
 * @param[in] device PHY pointer
 * @param[in] speed MAC speed: 10G, 5G or 2.5G
 * @param[in] powerMode MAC power mode. MRVL_AMG_MAC_LOW_LATENCY or MRVL_AMG_MAC_LOW_POWER
 * @param[in] mode forward mode: cut-through or store&forward
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MAC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MAC_Init(MRVL_DEV_PTR device, MRVL_AMG_MAC_POWER_MODE powerMode, MRVL_AMG_MAC_FWD_MODE fwdMode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;

	status |= MRVL_AMG_MAC_SetMACPower(device, MRVL_AMG_MAC_POWER_ON);
	status |= MRVL_AMG_MAC_SetDataPath(device, MRVL_AMG_MAC_DP_IN);
	status |= MRVL_AMG_MAC_SetPowerMode(device, powerMode);
	status |= MRVL_AMG_MAC_SetFwdMode(device, fwdMode);

	return status;
}

/**
 * @brief Disable MAC power and remove MAC from datapath
 * 
 * @param[in] device PHY pointer
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MAC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MAC_Disable(MRVL_DEV_PTR device)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	/* power off MAC */
	status |= MRVL_AMG_MAC_SetMACPower(device, MRVL_AMG_MAC_POWER_OFF);
	/* remove MAC from datapath */
	status |= MRVL_AMG_MAC_SetDataPath(device, MRVL_AMG_MAC_DP_BYPASS);
	return status;
}

/**
 * @brief config MAC block power
 * 
 * @param device PHY pointer
 * @param power MRVL_AMG_MAC_POWER_ON: powerup MAC. MRVL_AMG_MAC_POWER_OFF powerdown MAC
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MAC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MAC_SetMACPower(MRVL_DEV_PTR device, MRVL_AMG_MAC_POWER power)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regAddr = MRVL_AMG_PMP_CR_CLK_RST_CTRL_CG_PMP;
	MRVL_APHY_U32 data = 0;
	
	status |= MRVL_AMG_ReadReg32(device, regAddr, &data);
	if(MRVL_AMG_MAC_POWER_ON == power)
	{
		/* power on MAC */
		data = (data & 0xFFF0U) | 0x000FU;
	}
	else
	{
		/* power off MAC */
		data = data & 0xFFF0U;
	}
	status |= MRVL_AMG_WriteReg32(device, regAddr, data);
	
	return status;
}

/**
 * @brief check if MAC is power up
 * 
 * @param[in] device PHY pointer
 * @param[out] path function modifies this pointer to reflect MAC poewr setting: MRVL_AMG_MAC_POWER_ON or MRVL_AMG_MAC_POWER_OFF
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MAC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MAC_GetMACPower(MRVL_DEV_PTR device, MRVL_AMG_MAC_POWER *power)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regAddr = MRVL_AMG_PMP_CR_CLK_RST_CTRL_CG_PMP;
	MRVL_APHY_U32 data = 0;
	
	MRVL_AMG_ReadReg32(device, regAddr, &data);
	data &= 0xFU;
	
	if(0xFU == data)
	{
		/* power on MAC */
		*power = MRVL_AMG_MAC_POWER_ON;
	}
	else if(0 == data)
	{
		/* power off MAC */
		*power = MRVL_AMG_MAC_POWER_OFF;
	}
	else
	{
		status = MRVL_APHY_STATUS_ERROR_GENERAL;
	}
	
	return status;
}

/**
 * @brief Set MAC in path or bypass MAC.
 * Use this function to deploy/undeploy MAC after initialization
 * 
 * @param[in] device PHY pointer
 * @param[in] path MRVL_AMG_MAC_DP_BYPASS or MRVL_AMG_MAC_DP_IN
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MAC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MAC_SetDataPath(MRVL_DEV_PTR device, MRVL_AMG_MAC_DATAPATH path)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regAddr = MRVL_AMG_PMP_CR_HW_CFG_CTRL_HW;
	MRVL_APHY_U32 data = 0;
	
	status |= MRVL_AMG_ReadReg32(device, regAddr, &data);
	/* enable/bypass MAC, bit 0*/
	if(MRVL_AMG_MAC_DP_IN == path)
	{
		data &= ~0x1U;
	}
	else
	{
		data |= 0x1U;
	}
	status |= MRVL_AMG_WriteReg32(device, regAddr, data);
	
	return status;
}

/**
 * @brief check if MAC is in datapath
 * 
 * @param[in] device PHY pointer
 * @param[out] path function modifies this pointer to reflect datapath setting: MRVL_AMG_MAC_DP_BYPASS or MRVL_AMG_MAC_DP_IN
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MAC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MAC_GetDataPath(MRVL_DEV_PTR device, MRVL_AMG_MAC_DATAPATH *path)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regAddr = MRVL_AMG_PMP_CR_HW_CFG_CTRL_HW;
	MRVL_APHY_U32 data = 0;
	
	MRVL_AMG_ReadReg32(device, regAddr, &data);
	data &= 0x1U;
	/* enable/bypass MAC, bit 0*/
	if(0 == data)
	{
		*path = MRVL_AMG_MAC_DP_IN;
	}
	else
	{
		*path = MRVL_AMG_MAC_DP_BYPASS;
	}
	
	return status;
}

/**
 * @brief set MAC mode
 * 
 * @param[in] device PHY pointer
 * @param[in] powerMode MAC power mode. MRVL_AMG_MAC_LOW_LATENCY or MRVL_AMG_MAC_LOW_POWER (only affects 2p5G or 5G, core clk to the macsec is reduced)
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MAC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MAC_SetPowerMode(MRVL_DEV_PTR device, MRVL_AMG_MAC_POWER_MODE powerMode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regAddr = MRVL_AMG_MCS_CLK;
	MRVL_APHY_U32 data = 0;

	status |= MRVL_AMG_ReadReg32(device, regAddr, &data);
	if (powerMode == MRVL_AMG_MAC_LOW_LATENCY)
	{
		/* low-latency mode */
		data |= 0x11U;
	}
	else
	{
		/* low-power mode */
		data &= ~((MRVL_APHY_U32)0x1);
	}
	status |= MRVL_AMG_WriteReg32(device, regAddr, data);

	return status;
}

/**
 * @brief check if MMAC is in low latency mode or low power mode
 * 
 * @param[in] device PHY pointer 
 * @param[out] powerMode MAC power mode. MRVL_AMG_MAC_LOW_LATENCY or MRVL_AMG_MAC_LOW_POWER
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MAC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MAC_GetPowerMode(MRVL_DEV_PTR device, MRVL_AMG_MAC_POWER_MODE* powerMode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regAddr = MRVL_AMG_MCS_CLK;
	MRVL_APHY_U32 data = 0;

	MRVL_AMG_ReadReg32(device, regAddr, &data);
	/* low latency/power mode, bit0 */
	if ((data & 0x11U) == 0x11)
	{
		*powerMode = MRVL_AMG_MAC_LOW_LATENCY;
	}
	else
	{
		*powerMode = MRVL_AMG_MAC_LOW_POWER;
	}

	return status;
}

/**
 * @brief configurate MAC fowarding mode
 * 
 * @param[in] device PHY pointer
 * @param[in] fwdMode MAC forwardind mode
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MAC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MAC_SetFwdMode(MRVL_DEV_PTR device, MRVL_AMG_MAC_FWD_MODE fwdMode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regAddr = MRVL_AMG_MCS_SLICE_CTRL;
	MRVL_APHY_U32 data = 0;

	MRVL_AMG_ReadReg32(device, regAddr, &data);
	/* forward mode, reg bit[1:0] */
	data = (data & 0xFFFCU) | fwdMode;
	MRVL_AMG_WriteReg32(device, regAddr, data);

	return status;
}

/**
 * @brief get MAC fowarding mode configuration
 * 
 * @param[in] device PHY pointer
 * @param[out] mode function modifies this pointer to reflect MAC forwardind mode
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MAC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MAC_GetFwdMode(MRVL_DEV_PTR device, MRVL_AMG_MAC_FWD_MODE* fwdMode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regAddr = MRVL_AMG_MCS_SLICE_CTRL;
	MRVL_APHY_U32 data = 0;

	MRVL_AMG_ReadReg32(device, regAddr, &data);
	/* forward mode, reg bit[1:0] */
	if ((data & 0x3U) == 0x0)
	{
		*fwdMode = MRVL_AMG_MAC_CUT_THROUGH;
	}
	else
	{
		*fwdMode = MRVL_AMG_MAC_STORE_FWD;
	}

	return status;
}

/**
 * @brief software reset MAC
 * 
 * @param[in] device PHY pointer
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MAC_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MAC_SoftReset(MRVL_DEV_PTR device) {
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regAddr = MRVL_AMG_MCS_RST_MASTER_CTRL;
	MRVL_APHY_U32 data = 0;

	/* reset MMAC, bit 14 */
	status |= MRVL_AMG_ReadReg32(device, regAddr, &data);

	/* write 0x1 to reset */
	data = (data & 0xBFFFU) | (0x1U << 14);
	status |= MRVL_AMG_WriteReg32(device, regAddr, data);

	/* write 0x0 to release */
	data = data & 0xBFFFU;
	status |= MRVL_AMG_WriteReg32(device, regAddr, data);

	return status;
}


/******************************************************************************
 *      Rule
 ******************************************************************************/

/**
 * @brief set MACsec rule in memory
 * 
 * @param[in] device PHY pointer
 * @param[in] direction TRUE = egress/Tx, FALSE = ingress/Rx
 * @param[in] ruleIndex MACsec rule index
 * @param[in] rule MACsec rule pointer
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_RULE_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetRule(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 ruleIndex, MRVL_AMG_MCS_RULE* rule)
{
	MRVL_APHY_U32 BaseAddr_Data = 0;
	MRVL_APHY_U32 BaseAddr_Mask = 0;
	MRVL_APHY_U32 keyMaskPair[2][7] = { 0 };
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	if (ruleIndex >= MRVL_AMG_MCS_MAX_RULE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		if (direction == MRVL_AMG_MCS_DIR_EGRESS)
		{
			/* egress/tx reg addr */
			BaseAddr_Data = GETADDR(MRVL_AMG_MCS_TX_FLOWID_TCAM_DATA, ruleIndex, MRVL_AMG_MCS_RANGE32);
			BaseAddr_Mask = GETADDR(MRVL_AMG_MCS_TX_FLOWID_TCAM_MASK, ruleIndex, MRVL_AMG_MCS_RANGE32);
		}
		else
		{
			/* ingress/rx reg addr */
			BaseAddr_Data = GETADDR(MRVL_AMG_MCS_RX_FLOWID_TCAM_DATA, ruleIndex, MRVL_AMG_MCS_RANGE32);
			BaseAddr_Mask = GETADDR(MRVL_AMG_MCS_RX_FLOWID_TCAM_MASK, ruleIndex, MRVL_AMG_MCS_RANGE32);
		}

		/* covert rule to array */
		convert2ArrayFromRule(rule, keyMaskPair);
		
		/* write array into register */
		writeValFromArray(device, BaseAddr_Data, BaseAddr_Mask, keyMaskPair);

		/* enable or disable */
		status = MRVL_AMG_MCS_SetRuleEnable(device, direction, ruleIndex, rule->isEnable);
	}

	return status;
}

/**
 * @brief get MACsec rule from memory
 * 
 * @param[in] device PHY pointer
 * @param[in] direction TRUE = egress/Tx, FALSE = ingress/Rx
 * @param[in] ruleIndex MACsec rule index
 * @param[out] rule function modifies this pointer to reflect MACsec rule/police

 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_RULE_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetRule(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 ruleIndex, MRVL_AMG_MCS_RULE* rule)
{
	MRVL_APHY_U32 BaseAddr_Data = 0;
	MRVL_APHY_U32 BaseAddr_Mask = 0;
	MRVL_APHY_U32 BaseAddr_Enable = 0;
	MRVL_APHY_U32 keyMaskPair[2][7] = { 0 };
	MRVL_APHY_U32 regVal32 = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;

	if (ruleIndex >= MRVL_AMG_MCS_MAX_RULE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		if (direction == MRVL_AMG_MCS_DIR_EGRESS)
		{
			/* egress/tx reg addr */
			BaseAddr_Data = GETADDR(MRVL_AMG_MCS_TX_FLOWID_TCAM_DATA, ruleIndex, MRVL_AMG_MCS_RANGE32);
			BaseAddr_Mask = GETADDR(MRVL_AMG_MCS_TX_FLOWID_TCAM_MASK, ruleIndex, MRVL_AMG_MCS_RANGE32);
			BaseAddr_Enable = MRVL_AMG_MCS_TX_FLOWID_TCAM_ENABLE;
		}
		else
		{
			/* ingress/rx reg addr */
			BaseAddr_Data = GETADDR(MRVL_AMG_MCS_RX_FLOWID_TCAM_DATA, ruleIndex, MRVL_AMG_MCS_RANGE32);
			BaseAddr_Mask = GETADDR(MRVL_AMG_MCS_RX_FLOWID_TCAM_MASK, ruleIndex, MRVL_AMG_MCS_RANGE32);
			BaseAddr_Enable = MRVL_AMG_MCS_RX_FLOWID_TCAM_ENABLE;
		}
		/* readback reg values and write to array */
		readValConvert2RuleArray(device, BaseAddr_Data, BaseAddr_Mask, keyMaskPair);

		/* convert array to rule */
		convert2Rule(rule, keyMaskPair);

		/* check enabled or disabled */
		MRVL_AMG_MCS_ReadReg32(device, BaseAddr_Enable, &regVal32);
		rule->isEnable = (0 == ((regVal32 >> ruleIndex) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
	}

	return status;
}

/**
 * @brief enable or disable rule
 * 
 * @param[in] device PHY pointer
 * @param[in] direction TRUE = egress/Tx, FALSE = ingress/Rx
 * @param[in] ruleIndex  MACsec rule index/ID
 * @param[in] isEnable TRUE: enable MACsec rule. FALSE: disable MACsec rule.
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_RULE_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetRuleEnable(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 ruleIndex, MRVL_APHY_BOOL isEnable)
{
	MRVL_APHY_U32 BaseAddr_Enable = 0;
	MRVL_APHY_U32 regVal32 = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	if (ruleIndex >= MRVL_AMG_MCS_MAX_RULE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* get reg addr per direction */
		if (direction == MRVL_AMG_MCS_DIR_EGRESS)
		{
			BaseAddr_Enable = MRVL_AMG_MCS_TX_FLOWID_TCAM_ENABLE;
		}
		else
		{
			BaseAddr_Enable = MRVL_AMG_MCS_RX_FLOWID_TCAM_ENABLE;
		}
		/* enable or disable */
		MRVL_AMG_MCS_ReadReg32(device, BaseAddr_Enable, &regVal32);
		if (MRVL_APHY_TRUE == isEnable)
		{
			regVal32 |=  (MRVL_APHY_U32)1U << ruleIndex;
		}
		else
		{
			regVal32 &= ~( (MRVL_APHY_U32)1U << ruleIndex);
		}
		MRVL_AMG_MCS_WriteReg32(device, BaseAddr_Enable, regVal32);
	}

	return status;
}


/******************************************************************************
 *      SecY Map
 ******************************************************************************/

/**
 * @brief set MACsec Rx SecY and Rule Map in memory
 * 
 * @param[in] device PHY pointer
 * @param[in] ruleIndex Rx rule index
 * @param[in] secyMap Rx SecY Map pointer
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SECY_MAP_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetRxSecYMap(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_AMG_MCS_RX_SECY_MAP* secyMap)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 BaseAddr_SecY_Map = 0;
	MRVL_APHY_U32 val32 = 0;

	if (ruleIndex >= MRVL_AMG_MCS_MAX_RULE_NUM || secyMap->secYIndex >= MRVL_AMG_MCS_MAX_SECY_MAP_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_SecY_Map = GETADDR(MRVL_AMG_MCS_RX_SECY_MAP_MEM, ruleIndex, MRVL_AMG_MCS_RANGE8);
		val32 = (MRVL_APHY_U32)secyMap->secYIndex & 0x3U;
		val32 +=  (MRVL_APHY_U32)((MRVL_APHY_TRUE == secyMap->isControlPacket) ? 1 : 0) << 2;
		MRVL_AMG_MCS_WriteReg32(device, BaseAddr_SecY_Map, val32);
	}

	return status;
}

/**
 * @brief get MACsec Rx SecY and Rule Map from memory
 * 
 * @param[in] device PHY pointer
 * @param[in] ruleIndex Rx rule index
 * @param[out] secyMap function modifies this pointer to reflect Rx SecY map
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SECY_MAP_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxSecYMap(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_AMG_MCS_RX_SECY_MAP* secyMap)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 BaseAddr_SecY_Map = 0;
	MRVL_APHY_U32 regVal32 = 0;

	if (ruleIndex >= MRVL_AMG_MCS_MAX_RULE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_SecY_Map = GETADDR(MRVL_AMG_MCS_RX_SECY_MAP_MEM, ruleIndex, MRVL_AMG_MCS_RANGE8);
		MRVL_AMG_MCS_ReadReg32(device, BaseAddr_SecY_Map, &regVal32);

		secyMap->secYIndex = (MRVL_APHY_U8)(regVal32 & 0x3U);
		secyMap->isControlPacket = (0 == ((regVal32 >> 2) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
	}

	return status;
}

/**
 * @brief Set MACsec Tx SecY and Rule Map in memory
 * 
 * @param[in] device PHY pointer
 * @param[in] ruleIndex Tx rule index
 * @param[in] secyMap Tx SecY Map pointer
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SECY_MAP_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetTxSecYMap(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_AMG_MCS_TX_SECY_MAP* secyMap)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 BaseAddr_SecY_Map = 0;
	MRVL_APHY_U64 regVal = 0;

	if (ruleIndex >= MRVL_AMG_MCS_MAX_RULE_NUM || secyMap->secYIndex >= MRVL_AMG_MCS_MAX_SECY_MAP_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_SecY_Map = GETADDR(MRVL_AMG_MCS_TX_SECY_MAP_MEM, ruleIndex, MRVL_AMG_MCS_RANGE16);
		MRVL_AMG_MCS_WriteReg64(device, BaseAddr_SecY_Map, secyMap->sectag_sci);

		regVal = (MRVL_APHY_U64)secyMap->secYIndex & 0x3U;
		regVal += ((MRVL_APHY_U64)(MRVL_APHY_TRUE == secyMap->isControlPacket ? 1 : 0)) << 2;
		regVal += (((MRVL_APHY_U64)secyMap->scIndex & 0x3U)) << 3;
		regVal += ((MRVL_APHY_U64)(MRVL_APHY_TRUE == secyMap->auxiliary_plcy ? 1 : 0)) << 5;
		MRVL_AMG_MCS_WriteReg64(device, BaseAddr_SecY_Map + 16, regVal);
	}

	return status;
}

/**
 * @brief Get MACsec Tx SecY and Rule Map from memory
 * 
 * @param[in] device PHY pointer
 * @param[in] ruleIndex Tx rule index
 * @param[out] secyMap function modifies this pointer to reflect Tx SecY map
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SECY_MAP_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxSecYMap(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_AMG_MCS_TX_SECY_MAP* secyMap)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 BaseAddr_SecY_Map = 0;
	MRVL_APHY_U64 regVal = 0;

	if (ruleIndex >= MRVL_AMG_MCS_MAX_RULE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_SecY_Map = GETADDR(MRVL_AMG_MCS_TX_SECY_MAP_MEM, ruleIndex, MRVL_AMG_MCS_RANGE16);
		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_SecY_Map, &regVal);
		secyMap->sectag_sci = regVal;
		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_SecY_Map + 16, &regVal);
		secyMap->secYIndex = (MRVL_APHY_U8)(regVal & 0x3U);
		secyMap->isControlPacket = (0 == ((regVal >> 2) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
		secyMap->scIndex =  (MRVL_APHY_U8)((regVal >> 3) & 0x3U);
		secyMap->auxiliary_plcy = (0 == ((regVal >> 5) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
	}

	return status;
}


/******************************************************************************
 *      SecY
 ******************************************************************************/

/**
 * @brief Set MACsec Rx SecY in memory
 * 
 * @param[in] device PHY pointer
 * @param[in] secy Rx SecY pointer
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SECY_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetRxSecY(MRVL_DEV_PTR device, MRVL_APHY_U8 secyIndex, MRVL_AMG_MCS_RX_SECY* secy)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 BaseAddr_SecY_Plcy = 0;
	MRVL_APHY_U64 regVal = 0;
	if (secyIndex >= MRVL_AMG_MCS_MAX_SECY_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_SecY_Plcy = GETADDR(MRVL_AMG_MCS_RX_SECY_PLCY_MEM, secyIndex, MRVL_AMG_MCS_RANGE8);

		regVal = (MRVL_APHY_U64)(MRVL_APHY_TRUE == secy->controlled_port_enabled ? 1 : 0);
		regVal += ((MRVL_APHY_U64)secy->validate_frames & 0x3U) << 4;
		regVal += ((MRVL_APHY_U64)secy->strip_sectag_icv & 0x3U) << 8;
		regVal += ((MRVL_APHY_U64)secy->cipher & 0xFU) << 12;
		regVal += ((MRVL_APHY_U64)secy->confidential_offset & 0x7FU) << 20;
		regVal += ((MRVL_APHY_U64)((MRVL_APHY_TRUE == secy->icv_includes_da_sa) ? 1 : 0)) << 28;
		regVal += ((MRVL_APHY_U64)((MRVL_APHY_TRUE == secy->replay_protect) ? 1 : 0)) << 30;
		regVal |= ((MRVL_APHY_U64)secy->replay_window & 0xFFFFFFFFU) << 32;

		MRVL_AMG_MCS_WriteReg64(device, BaseAddr_SecY_Plcy, regVal);
	}

	return status;
}

/**
 * @brief Get MACsec Rx SecY from memory
 * 
 * @param[in] device PHY pointer
 * @param[in] secyIndex Rx SecY index
 * @param[out] secy function modifies this pointer to reflect Rx SecY
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SECY_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxSecY(MRVL_DEV_PTR device, MRVL_APHY_U8 secyIndex, MRVL_AMG_MCS_RX_SECY* secy)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 BaseAddr_SecY_Plcy = 0;
	MRVL_APHY_U64 regVal64 = 0;
	MRVL_APHY_U64 validateFrameVal = 0;
	MRVL_APHY_U64 stripSectagIcvVal = 0;
	MRVL_APHY_U64 cipherSuiteVal = 0;
	if (secyIndex >= MRVL_AMG_MCS_MAX_SECY_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_SecY_Plcy = GETADDR(MRVL_AMG_MCS_RX_SECY_PLCY_MEM, secyIndex, MRVL_AMG_MCS_RANGE8);
		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_SecY_Plcy, &regVal64);
		/* assign secy with reg value */
		secy->controlled_port_enabled = (0 == (regVal64 & 0x1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
		secy->confidential_offset = (MRVL_APHY_U8)((regVal64 >> 20) & 0x7FU);
		secy->icv_includes_da_sa = (0 == ((regVal64 >> 28) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
		secy->replay_protect = (0 == ((regVal64 >> 30) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
		secy->replay_window = (MRVL_APHY_U32)((regVal64 >> 32) & 0xFFFFFFFFU);

		/* validate frame Enum */
		validateFrameVal = (regVal64 >> 4) & 0x3U;
		convert2ValidateFrameEnum((MRVL_APHY_U16)validateFrameVal, &(secy->validate_frames));

		/* strip sectag icv Enum */
		stripSectagIcvVal = (regVal64 >> 8) & 0x3U;
		convert2StripSectagEnum((MRVL_APHY_U16)stripSectagIcvVal, &(secy->strip_sectag_icv));

		/* cipher suite Enum */
		cipherSuiteVal = (regVal64 >> 12) & 0xFU;
		status = convert2CipherSuiteEnum((MRVL_APHY_U16)cipherSuiteVal, &(secy->cipher));
	}

	return status;
}

/**
 * @brief Set MACsec Tx SecY in memory
 * 
 * @param[in] device PHY pointer
 * @param[in] secy Tx SecY pointer
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SECY_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetTxSecY(MRVL_DEV_PTR device, MRVL_APHY_U8 secyIndex, MRVL_AMG_MCS_TX_SECY* secy)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 BaseAddr_SecY_Plcy = 0;
	MRVL_APHY_U64 regVal = 0;
	if (secyIndex >= MRVL_AMG_MCS_MAX_SECY_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_SecY_Plcy = GETADDR(MRVL_AMG_MCS_TX_SECY_PLCY_MEM, secyIndex, MRVL_AMG_MCS_RANGE8);

		regVal = (MRVL_APHY_U64)secy->sectag_offset & 0x7FU;
		regVal += ((MRVL_APHY_U64)secy->sectag_tci & 0x3FU) << 8;
		regVal += ((MRVL_APHY_U64)secy->mtu & 0xFFFFU) << 16;
		regVal <<= 32;
		regVal += (MRVL_APHY_U64)((MRVL_APHY_TRUE == secy->controlled_port_enabled) ? 1 : 0);
		regVal += (MRVL_APHY_U64)(MRVL_APHY_TRUE == secy->protect_frames ? 1 : 0) << 4;
		regVal += ((MRVL_APHY_U64)secy->cipher & 0x7U) << 12;
		regVal += ((MRVL_APHY_U64)secy->confidential_offset & 0x7FU) << 20;
		regVal += (MRVL_APHY_U64)((MRVL_APHY_TRUE == secy->icv_includes_da_sa) ? 1 : 0) << 28;
		regVal += (MRVL_APHY_U64)1 << 30;
		MRVL_AMG_MCS_WriteReg64(device, BaseAddr_SecY_Plcy, regVal);
	}

	return status;
}

/**
 * @brief Get MACsec Tx SecY in memory
 * 
 * @param[in] device PHY pointer
 * @param[in] secyIndex Tx SecY index
 * @param[out] secy function modifies this pointer to reflect Tx SecY
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SECY_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxSecY(MRVL_DEV_PTR device, MRVL_APHY_U8 secyIndex, MRVL_AMG_MCS_TX_SECY* secy)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 BaseAddr_SecY_Plcy = 0;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U64 cipherSuiteVal = 0;
	if (secyIndex >= MRVL_AMG_MCS_MAX_SECY_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_SecY_Plcy = GETADDR(MRVL_AMG_MCS_TX_SECY_PLCY_MEM, secyIndex, MRVL_AMG_MCS_RANGE8);

		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_SecY_Plcy, &regVal);
		secy->controlled_port_enabled = (0 == (regVal & 0x1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
		secy->protect_frames = (0 == ((regVal >> 4) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
		secy->confidential_offset = (MRVL_APHY_U8)((regVal >> 20) & 0x7FU);
		secy->icv_includes_da_sa = (0 == ((regVal >> 28) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
		secy->sectag_offset = (MRVL_APHY_U8)((regVal >> 32) & 0x7FU);
		secy->sectag_tci = (MRVL_APHY_U8)((regVal >> 40) & 0x3FU);
		secy->mtu = (MRVL_APHY_U16)((regVal >> 48) & 0xFFFFU);
		cipherSuiteVal = (regVal >> 12) & 0xFU;		
		switch (cipherSuiteVal)
		{
		case 0:
			secy->cipher = MRVL_AMG_MCS_CIPHER_GCM_AES_128;
			break;
		case 0x1U:
			secy->cipher = MRVL_AMG_MCS_CIPHER_GCM_AES_256;
			break;
		case 0x2U:
			secy->cipher = MRVL_AMG_MCS_CIPHER_GCM_AES_128_XPN;
			break;
		case 0x3U:
			secy->cipher = MRVL_AMG_MCS_CIPHER_GCM_AES_256_XPN;
			break;
		default:
			status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
			break;
		}
	}

	return status;
}


/******************************************************************************
 *      SC
 ******************************************************************************/

/**
 * @brief MACsec Rx SC in memory
 * 
 * @param[in] device PHY pointer
 * @param[in] rx_sc Rx SC pointer
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SC_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetRxSC(MRVL_DEV_PTR device, MRVL_APHY_U8 rxscIndex, MRVL_AMG_MCS_RX_SC* sc)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U32 BaseAddr_rxCAM, BaseAddr_rxCAM_enable, BaseAddr_rx_saMap;
	if (rxscIndex >= MRVL_AMG_MCS_MAX_SC_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_rxCAM = GETADDR(MRVL_AMG_MCS_RX_SC_CAM, rxscIndex, MRVL_AMG_MCS_RANGE16);
		BaseAddr_rxCAM_enable = MRVL_AMG_MCS_RX_SC_CAM_ENABLE;
		BaseAddr_rx_saMap = GETADDR(MRVL_AMG_MCS_RX_SA_MAP_MEM, rxscIndex, MRVL_AMG_MCS_RANGE32);
		/* RX CAM */
		MRVL_AMG_MCS_WriteReg64(device, BaseAddr_rxCAM, sc->sci);
		MRVL_AMG_MCS_WriteReg64(device, BaseAddr_rxCAM + 16, (MRVL_APHY_U64)sc->secYIndex & 0x3U);

		/* CAM enable */
		MRVL_AMG_MCS_ReadReg32(device, BaseAddr_rxCAM_enable, &regVal);
		if (MRVL_APHY_TRUE == sc->enable)
		{
			regVal |= (MRVL_APHY_U32)1U << rxscIndex;
		}
		else
		{
			regVal &= ~((MRVL_APHY_U32)1U << rxscIndex);
		}
		MRVL_AMG_MCS_WriteReg32(device, BaseAddr_rxCAM_enable, regVal);
		/* SA map: four entries */
		regVal = (MRVL_APHY_U32)sc->sa_index0 & 0x7U;
		if (MRVL_APHY_TRUE == sc->sa_index0_in_use)
		{
			regVal |= (MRVL_APHY_U32)1U << 3;
		}
		else
		{
			regVal &= ~((MRVL_APHY_U32)1U << 3);
		}
		MRVL_AMG_MCS_WriteReg32(device, BaseAddr_rx_saMap, regVal);

		regVal = (MRVL_APHY_U32)sc->sa_index1 & 0x7U;
		if (MRVL_APHY_TRUE == sc->sa_index1_in_use)
		{
			regVal |= (MRVL_APHY_U32)1U << 3;
		}
		else
		{
			regVal &= ~((MRVL_APHY_U32)1U << 3);
		}
		MRVL_AMG_MCS_WriteReg32(device, BaseAddr_rx_saMap + 16, regVal);

		regVal = (MRVL_APHY_U32)sc->sa_index2 & 0x7U;
		if (MRVL_APHY_TRUE == sc->sa_index2_in_use)
		{
			regVal |= (MRVL_APHY_U32)1U << 3;
		}
		else
		{
			regVal &= ~((MRVL_APHY_U32)1U << 3);
		}
		MRVL_AMG_MCS_WriteReg32(device, BaseAddr_rx_saMap + 32, regVal);

		regVal = (MRVL_APHY_U32)sc->sa_index3 & 0x7U;
		if (MRVL_APHY_TRUE == sc->sa_index3_in_use)
		{
			regVal |= (MRVL_APHY_U32)1U << 3;
		}
		else
		{
			regVal &= ~((MRVL_APHY_U32)1U << 3);
		}
		MRVL_AMG_MCS_WriteReg32(device, BaseAddr_rx_saMap + 48, regVal);
	}

	return status;
}

/**
 * @brief Get MACsec Rx SC in memory
 * 
 * @param[in] device PHY pointer
 * @param[in] rxscIndex Rx SC index
 * @param[out] rx_sc function modifies this pointer to reflect Rx SC
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SC_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxSC(MRVL_DEV_PTR device, MRVL_APHY_U8 rxscIndex, MRVL_AMG_MCS_RX_SC* sc)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal32 = 0;
	MRVL_APHY_U64 regVal64 = 0;
	MRVL_APHY_U32 BaseAddr_rxCAM, BaseAddr_rxCAM_enable, BaseAddr_rx_saMap;
	if (rxscIndex >= MRVL_AMG_MCS_MAX_SC_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;	
	}
	else
	{
		BaseAddr_rxCAM = GETADDR(MRVL_AMG_MCS_RX_SC_CAM, rxscIndex, MRVL_AMG_MCS_RANGE16);
		BaseAddr_rxCAM_enable = MRVL_AMG_MCS_RX_SC_CAM_ENABLE;
		BaseAddr_rx_saMap = GETADDR(MRVL_AMG_MCS_RX_SA_MAP_MEM, rxscIndex, MRVL_AMG_MCS_RANGE32);

		MRVL_AMG_MCS_ReadReg32(device, BaseAddr_rxCAM_enable, &regVal32);
		sc->enable = (0 == ((regVal32 >> rxscIndex) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
		/* RX CAM */
		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_rxCAM, &regVal64);
		sc->sci = regVal64;
		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_rxCAM + 16, &regVal64);
		sc->secYIndex = (MRVL_APHY_U8)(regVal64 & 0x7U);
		/* SA map: four entries */
		MRVL_AMG_MCS_ReadReg32(device, BaseAddr_rx_saMap, &regVal32);
		sc->sa_index0 = (MRVL_APHY_U8)(regVal32 & 0x7U);
		sc->sa_index0_in_use = (0 == ((regVal32 >> 3) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;

		MRVL_AMG_MCS_ReadReg32(device, BaseAddr_rx_saMap + 16, &regVal32);
		sc->sa_index1 = (MRVL_APHY_U8)(regVal32 & 0x7U);
		sc->sa_index1_in_use = (0 == ((regVal32 >> 3) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;

		MRVL_AMG_MCS_ReadReg32(device, BaseAddr_rx_saMap + 32, &regVal32);
		sc->sa_index2 = (MRVL_APHY_U8)(regVal32 & 0x7U);
		sc->sa_index2_in_use = (0 == ((regVal32 >> 3) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;

		MRVL_AMG_MCS_ReadReg32(device, BaseAddr_rx_saMap + 48, &regVal32);
		sc->sa_index3 = (MRVL_APHY_U8)(regVal32 & 0x7U);
		sc->sa_index3_in_use = (0 == ((regVal32 >> 3) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
	}
		
	return status;
}

/**
 * @brief Set MACsec Tx SC in memory
 * 
 * @param[in] device PHY pointer
 * @param[in] tx_sc Tx SC pointer
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SC_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetTxSC(MRVL_DEV_PTR device, MRVL_APHY_U8 txscIndex, MRVL_AMG_MCS_TX_SC* sc)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U32 BaseAddr_txSC, BaseAddr_autorekey, BaseAddr_activeSA, BaseAddr_SA0_VLD, BaseAddr_SA1_VLD;
	if (txscIndex >= MRVL_AMG_MCS_MAX_SC_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_txSC = GETADDR(MRVL_AMG_MCS_TX_SA_MAP_MEM, txscIndex, MRVL_AMG_MCS_RANGE8);
		BaseAddr_autorekey = MRVL_AMG_MCS_TX_AUTO_REKEY;
		BaseAddr_activeSA = GETADDR(MRVL_AMG_MCS_TX_SA_ACTIVE, txscIndex, MRVL_AMG_MCS_RANGE4);
		BaseAddr_SA0_VLD = GETADDR(MRVL_AMG_MCS_TX_SA_INDEX0_VLD, txscIndex, MRVL_AMG_MCS_RANGE4);
		BaseAddr_SA1_VLD = GETADDR(MRVL_AMG_MCS_TX_SA_INDEX1_VLD, txscIndex, MRVL_AMG_MCS_RANGE4);
		regVal = (MRVL_APHY_U32)sc->sa_index0 & 0x7U;
		regVal |=  ((MRVL_APHY_U32)sc->sa_index1 & 0x7U) << 3;
		MRVL_AMG_MCS_WriteReg32(device, BaseAddr_txSC, regVal);
		MRVL_AMG_MCS_ReadReg32(device, BaseAddr_autorekey, &regVal);
		if (MRVL_APHY_TRUE == sc->enable_auto_rekey)
		{
			regVal |=  (MRVL_APHY_U32)1U << txscIndex;
		}
		else
		{
			regVal &= ~( (MRVL_APHY_U32)1U << txscIndex);
		}
		MRVL_AMG_MCS_WriteReg32(device, BaseAddr_autorekey, regVal);
		MRVL_AMG_MCS_WriteReg32(device, BaseAddr_activeSA, (MRVL_APHY_U32)((MRVL_APHY_TRUE == sc->isActiveSA1) ? 1 : 0));
		MRVL_AMG_MCS_WriteReg32(device, BaseAddr_SA0_VLD, (MRVL_APHY_U32)((MRVL_APHY_TRUE == sc->sa_index0_vld) ? 1 : 0));
		MRVL_AMG_MCS_WriteReg32(device, BaseAddr_SA1_VLD, (MRVL_APHY_U32)((MRVL_APHY_TRUE == sc->sa_index1_vld) ? 1 : 0));
	}

	return status;
}

/**
 * @brief Get MACsec Tx SC in memory
 * 
 * @param[in] device PHY pointer
 * @param[in] txscIndex Tx SC index
 * @param[out] sc function modifies this pointer to reflect Tx SC
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SC_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxSC(MRVL_DEV_PTR device, MRVL_APHY_U8 txscIndex, MRVL_AMG_MCS_TX_SC* sc)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U32 BaseAddr_txSC, BaseAddr_autorekey, BaseAddr_activeSA, BaseAddr_SA0_VLD, BaseAddr_SA1_VLD;
	if (txscIndex >= MRVL_AMG_MCS_MAX_SC_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_txSC = GETADDR(MRVL_AMG_MCS_TX_SA_MAP_MEM, txscIndex, MRVL_AMG_MCS_RANGE8);
		BaseAddr_autorekey = MRVL_AMG_MCS_TX_AUTO_REKEY;
		BaseAddr_activeSA = GETADDR(MRVL_AMG_MCS_TX_SA_ACTIVE, txscIndex, MRVL_AMG_MCS_RANGE4);
		BaseAddr_SA0_VLD = GETADDR(MRVL_AMG_MCS_TX_SA_INDEX0_VLD, txscIndex, MRVL_AMG_MCS_RANGE4);
		BaseAddr_SA1_VLD = GETADDR(MRVL_AMG_MCS_TX_SA_INDEX1_VLD, txscIndex, MRVL_AMG_MCS_RANGE4);

		MRVL_AMG_MCS_ReadReg32(device, BaseAddr_txSC, &regVal);
		sc->sa_index0 = (MRVL_APHY_U8)(regVal & 0x7U);
		sc->sa_index1 = (MRVL_APHY_U8)((regVal >> 3) & 0x7U);

		MRVL_AMG_MCS_ReadReg32(device, BaseAddr_autorekey, &regVal);
		sc->enable_auto_rekey = (0 == ((regVal >> txscIndex) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;

		MRVL_AMG_MCS_ReadReg32(device, BaseAddr_activeSA, &regVal);
		sc->isActiveSA1 = (0 == (regVal & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;

		MRVL_AMG_MCS_ReadReg32(device, BaseAddr_SA0_VLD, &regVal);
		sc->sa_index0_vld = (0 == (regVal & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
		MRVL_AMG_MCS_ReadReg32(device, BaseAddr_SA1_VLD, &regVal);
		sc->sa_index1_vld = (0 == (regVal & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
	}

	return status;
}


/******************************************************************************
 *      SA
 ******************************************************************************/

/**
 * @brief Set MACsec Rx SA policy in memory. Rx SA policy includes SAK, HASHKey, SALT and SSCI.
 * 
 * @param[in] device PHY pointer
 * @param[in] rxsaIndex Rx SA pointer
 * @param[in] saPlcy    Rx SA policy struct pointer
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SA_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetRxSAPolicy(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_AMG_MCS_RX_SA_PLCY* saPlcy)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 BaseAddr_rx_sa;
	if (rxsaIndex >= MRVL_AMG_MCS_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_rx_sa = GETADDR(MRVL_AMG_MCS_RX_SA_PLCY_MEM, rxsaIndex, MRVL_AMG_MCS_RANGE64);
		/* write SAK value to register */
		writeSAKValue(device, BaseAddr_rx_sa, saPlcy->sak);
		/* write Hash value to register */
		writeHashValue(device, BaseAddr_rx_sa + 64, saPlcy->hashKey);
		/* write Salt and SSCI value to register */
		writeSaltAndSSCIValue(device, BaseAddr_rx_sa + 72, saPlcy->ssci, saPlcy->salt);
	}

	return status;
}

/**
 * @brief Get MACsec Rx SA policy from memory. Rx SA policy includes SAK, HASHKey, SALT and SSCI.
 * 
 * @param[in] device PHY pointer
 * @param[in] rxsaIndex Rx SA index
 * @param[out] saPlcy Rx SA policy struct pointer
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SA_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxSAPolicy(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_AMG_MCS_RX_SA_PLCY* saPlcy)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 BaseAddr_rxSA;
	if (rxsaIndex >= MRVL_AMG_MCS_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_rxSA = GETADDR(MRVL_AMG_MCS_RX_SA_PLCY_MEM, rxsaIndex, MRVL_AMG_MCS_RANGE64);
		/* read SAK value from register */
		readValConvert2SAK(device, BaseAddr_rxSA, saPlcy->sak);
		/* read Hash value from register */
		readValConvert2Hash(device, BaseAddr_rxSA + 64, saPlcy->hashKey);
		/* read Salt and SSCI value from register */
		readValConvert2SaltSSCI(device, BaseAddr_rxSA + 72, &(saPlcy->ssci), saPlcy->salt);
	}

	return status;
}

/**
 * @brief Set MACsec Tx SA policy in memory. Tx SA policy includes SAK, HASHKey, SALT and SSCI. Plus sectag AN.
 * 
 * @param[in] device PHY pointer
 * @param[in] txsaIndex Tx SA pointer
 * @param[in] saPlcy    Tx SA policy struct pointer
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SA_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetTxSAPolicy(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_AMG_MCS_TX_SA_PLCY* saPlcy)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 BaseAddr_txSA;
	if (txsaIndex >= MRVL_AMG_MCS_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_txSA = GETADDR(MRVL_AMG_MCS_TX_SA_PLCY_MEM, txsaIndex, MRVL_AMG_MCS_RANGE128);
		/* write SAK value to register */
		writeSAKValue(device, BaseAddr_txSA, saPlcy->sak);
		/* write Hash value to register */
		writeHashValue(device, BaseAddr_txSA + 64, saPlcy->hashKey);
		/* write Salt and SSCI value to register */
		writeSaltAndSSCIValue(device, BaseAddr_txSA + 72, saPlcy->ssci, saPlcy->salt);
		/* write AN to register */
		MRVL_AMG_MCS_WriteReg64(device, BaseAddr_txSA + 128, saPlcy->AN);
	}

	return status;
}

/**
 * @brief Get MACsec Tx SA policy from memory. Tx SA policy includes SAK, HASHKey, SALT and SSCI. Plus sectag AN.
 * 
 * @param[in] device PHY pointer
 * @param[in] txsaIndex Tx SA index
 * @param[out] saPlcy    Tx SA policy struct pointer
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SA_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxSAPolicy(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_AMG_MCS_TX_SA_PLCY* saPlcy)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U32 BaseAddr_txSA;
	if (txsaIndex >= MRVL_AMG_MCS_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_txSA = GETADDR(MRVL_AMG_MCS_TX_SA_PLCY_MEM, txsaIndex, MRVL_AMG_MCS_RANGE128);

		/* readback SAK value from register */
		readValConvert2SAK(device, BaseAddr_txSA, saPlcy->sak);
		/* readback Hash value from register */
		readValConvert2Hash(device, BaseAddr_txSA + 64, saPlcy->hashKey);
		/* readback Salt and SSCI value from register */
		readValConvert2SaltSSCI(device, BaseAddr_txSA + 72, &(saPlcy->ssci), saPlcy->salt);
		/* readback AN value from register */
		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_txSA + 128, &regVal);
		saPlcy->AN = (MRVL_APHY_U8)(regVal & 0x3U);
	}

	return status;
}


/******************************************************************************
 *      PN and PN Threshold
 ******************************************************************************/

/**
 * @brief Set MACsec Rx SA next packet number. To readback next PN, call MRVL_AMG_MCS_GetTxSACurrentPN + 1
 * 
 * @param[in]	device    PHY pointer
 * @param[in]	rxsaIndex Rx SA index
 * @param[in]	pn Packet number
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetRxSANextPN(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_APHY_U64 pn)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 BaseAddr_nextPN;
	if (rxsaIndex >= MRVL_AMG_MCS_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_nextPN = GETADDR(MRVL_AMG_MCS_RX_SA_PN_TABLE_MEM, rxsaIndex, MRVL_AMG_MCS_RANGE8);
		/* write next PN to register */
		MRVL_AMG_MCS_WriteReg64(device, BaseAddr_nextPN, pn);
	}

	return status;
}

/**
 * @brief Set MACsec Tx SA next packet number. To readback next PN, call MRVL_AMG_MCS_GetTxSACurrentPN + 1
 * 
 * @param[in]	device    PHY pointer
 * @param[in]	txsaIndex Tx SA index
 * @param[in]	pn Packet number
 * @return MRVL_APHY_STATUS.
 * 
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetTxSANextPN(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_APHY_U64 pn)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 BaseAddr_nextPN;
	if (txsaIndex >= MRVL_AMG_MCS_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_nextPN = GETADDR(MRVL_AMG_MCS_TX_SA_PN_TABLE_MEM, txsaIndex, MRVL_AMG_MCS_RANGE8);
		/* write next PN to register */
		MRVL_AMG_MCS_WriteReg64(device, BaseAddr_nextPN, pn);
	}

	return status;
}

/**
 * @brief Get MACsec Rx SA current packet number. Support both PN and XPN.
 * 
 * @param[in]	device    PHY pointer
 * @param[in]	rxsaIndex Rx SA index
 * @param[out]	pn Packet number
 * @return MRVL_APHY_STATUS. Only when return status is MRVL_APHY_STATUS_OK, the pn is valid.
 * 
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxSACurrentPN(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_APHY_U64* pn)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U32 BaseAddr_nextPN;
	if (rxsaIndex >= MRVL_AMG_MCS_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_nextPN = GETADDR(MRVL_AMG_MCS_RX_SA_PN_TABLE_MEM, rxsaIndex, MRVL_AMG_MCS_RANGE8);
		/* read next PN value from register */
		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_nextPN, &regVal);
		/* get current PN */
		if (regVal > 0)
		{
			regVal = regVal - 1;
		}
		else
		{
			status = MRVL_APHY_STATUS_ERROR_GENERAL;
		}
	}
	*pn = regVal;
	return status;
}

/**
 * @brief Get MACsec Tx SA current packet number. Support both PN and XPN.
 * 
 * @param[in]	device    PHY pointer
 * @param[in]	txsaIndex Tx SA index
 * @param[out]	pn Packet number
 * @return MRVL_APHY_STATUS. Only when return status is MRVL_APHY_STATUS_OK, the pn is valid.
 * 
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxSACurrentPN(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_APHY_U64* pn)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U32 BaseAddr_nextPN;
	if (txsaIndex >= MRVL_AMG_MCS_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_nextPN = GETADDR(MRVL_AMG_MCS_TX_SA_PN_TABLE_MEM, txsaIndex, MRVL_AMG_MCS_RANGE8);
		/* readback nextPN value from register */
		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_nextPN, &regVal);
		/* get current PN */
		if (regVal > 0)
		{
			regVal = regVal - 1;
		}
		else
		{
			status = MRVL_APHY_STATUS_ERROR_GENERAL;
		}
	}
	*pn = regVal;
	return status;
}

/**
 * @brief Set Rx 32b PN Threshold
 * 
 * @param[in] device PHY pointer
 * @param[in] pnThreshold PN threshold
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetRxPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U32 pnThreshold)
{
	MRVL_AMG_MCS_WriteReg32(device, MRVL_AMG_MCS_RX_PN_THRESHOLD, pnThreshold);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Set Rx 64b XPN Threshold
 * 
 * @param[in] device PHY pointer
 * @param[in] pnThreshold XPN threshold
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetRxXPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U64 pnThreshold)
{
	MRVL_AMG_MCS_WriteReg64(device, MRVL_AMG_MCS_RX_XPN_THRESHOLD, pnThreshold);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get Rx 32b PN Threshold
 * 
 * @param[in] device PHY pointer
 * @param[out] pnThreshold function modifies this pointer to reflect Rx PN threshold
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U32* pnThreshold)
{
	MRVL_AMG_MCS_ReadReg32(device, MRVL_AMG_MCS_RX_PN_THRESHOLD, pnThreshold);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get Rx 64b XPN Threshold
 * 
 * @param[in] device PHY pointer
 * @param[out] pnThreshold function modifies this pointer to reflect Rx XPN threshold
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxXPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U64* pnThreshold)
{
	MRVL_AMG_MCS_ReadReg64(device, MRVL_AMG_MCS_RX_XPN_THRESHOLD, pnThreshold);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Set Tx 32b PN Threshold
 * 
 * @param[in] device PHY pointer
 * @param[in] pnThreshold PN threshold
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetTxPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U32 pnThreshold)
{
	MRVL_AMG_MCS_WriteReg32(device, MRVL_AMG_MCS_TX_PN_THRESHOLD, pnThreshold);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Set Tx 64b XPN Threshold
 * 
 * @param[in] device PHY pointer 
 * @param[in] pnThreshold PN threshold
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetTxXPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U64 pnThreshold)
{
	MRVL_AMG_MCS_WriteReg64(device, MRVL_AMG_MCS_TX_XPN_THRESHOLD, pnThreshold);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get Tx 32b PN Threshold
 * 
 * @param[in] device PHY pointer
 * @param[out] pnThreshold function modifies this pointer to reflect Tx PN threshold
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U32* pnThreshold)
{
	MRVL_AMG_MCS_ReadReg32(device, MRVL_AMG_MCS_TX_PN_THRESHOLD, pnThreshold);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get Tx 64b PN Threshold
 * 
 * @param[in] device PHY pointer
 * @param[out] pnThreshold function modifies this pointer to reflect Tx XPN threshold
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxXPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U64* pnThreshold)
{
	MRVL_AMG_MCS_ReadReg64(device, MRVL_AMG_MCS_TX_XPN_THRESHOLD, pnThreshold);
	return MRVL_APHY_STATUS_OK;
}


/******************************************************************************
 *      Default SCI
 ******************************************************************************/

/**
 * @brief Set Rx default SCI value
 * 
 * @param[in] device PHY pointer
 * @param[in] sci default sci value
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SCI_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetDefaultSCI(MRVL_DEV_PTR device, MRVL_APHY_U64 sci)
{
	MRVL_AMG_MCS_WriteReg64(device, MRVL_AMG_MCS_RX_DEFAULT_SCI, sci);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get Rx default SCI value
 * 
 * @param[in] device PHY pointer
 * @param[out] sci function modifies this pointer to reflect default sci
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_SCI_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetDefaultSCI(MRVL_DEV_PTR device, MRVL_APHY_U64* sci)
{
	MRVL_AMG_MCS_ReadReg64(device, MRVL_AMG_MCS_RX_DEFAULT_SCI, sci);
	return MRVL_APHY_STATUS_OK;
}


/******************************************************************************
 *      Statistics
 ******************************************************************************/

/**
 * @brief Get SMC Rx Statistics
 * 
 * @param[in] device PHY pointer
 * @param[out] stats function modifies this pointer to reflect SMC Rx Stats
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MAC_STATS_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MAC_GetRxSMCStats(MRVL_DEV_PTR device, MRVL_AMG_MAC_RX_SMC_STATS* stats)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U64 counterMask = 0xFFFFFFFFFFFFU;

	/* read SMCRxGoodOctets cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_RX_STATS_GOODOCTETS, &regVal);
	stats->goodOctets = regVal & counterMask;
	/* read SMCRxErrorOctets cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_RX_STATS_ERROROCTETS, &regVal);
	stats->errorOctets = regVal & counterMask;
	/* read SMCRxJabber cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_RX_STATS_JABBER, &regVal);
	stats->jabber = regVal & counterMask;
	/* read SMCRxFragment cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_RX_STATS_FRAGMENT, &regVal);
	stats->fragment = regVal & counterMask;
	/* read SMCRxUndersize cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_RX_STATS_UNDERSIZE, &regVal);
	stats->undersize = regVal & counterMask;
	/* read SMCRxOversize cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_RX_STATS_OVERSIZE, &regVal);
	stats->oversize = regVal & counterMask;
	/* read SMCRxRxError cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_RX_STATS_RXERROR, &regVal);
	stats->rxError = regVal & counterMask;
	/* read SMCRxCrcErrTxUnderrun cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_RX_STATS_CRCERR_TXUNDERRUN, &regVal);
	stats->crcErrTxUnderrun = regVal & counterMask;
	/* read SMCRxRxOverrunBadFC cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_RX_STATS_RXOVERRUN_BADFC, &regVal);
	stats->rxOverrunBadFC = regVal & counterMask;
	/* read SMCRxGoodPkts cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_RX_STATS_GOODPKTS, &regVal);
	stats->goodPkts = regVal & counterMask;
	/* read SMCRxFcPkts cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_RX_STATS_FCPKT, &regVal);
	stats->fcPkts = regVal & counterMask;
	/* read SMCRxBroadcast cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_RX_STATS_BROADCAST, &regVal);
	stats->broadcast = regVal & counterMask;
	/* read SMCRxMulticast cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_RX_STATS_MULTICAST, &regVal);
	stats->multicast = regVal & counterMask;
	/* read SMCRxInPAssemblyErr cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_RX_STATS_INPASSEMBLYERR, &regVal);
	stats->inPAssemblyErr = regVal & counterMask;
	/* read SMCRxInPFrames cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_RX_STATS_INPFRAMES, &regVal);
	stats->inPFrames = regVal & counterMask;
	/* read SMCRxInPFrags cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_RX_STATS_INPFRAGS, &regVal);
	stats->inPFrags = regVal & counterMask;
	/* read SMCRxInPBadFrags cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_RX_STATS_INPBADFRAGS, &regVal);
	stats->inPBadFrags = regVal & counterMask;

	return status;
}

/**
 * @brief Get SMC Tx Statistics
 * 
 * @param[in] device PHY pointer
 * @param[out] stats function modifies this pointer to reflect SMC Tx Stats
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MAC_STATS_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MAC_GetTxSMCStats(MRVL_DEV_PTR device, MRVL_AMG_MAC_TX_SMC_STATS* stats)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U64 counterMask = 0xFFFFFFFFFFFFU;

	/* read SMCTxGoodOctets cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_TX_STATS_GOODOCTETS, &regVal);
	stats->goodOctets = regVal & counterMask;
	/* read SMCTxErrorOctets cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_TX_STATS_ERROROCTETS, &regVal);
	stats->errorOctets = regVal & counterMask;
	/* read SMCTxJabber cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_TX_STATS_JABBER, &regVal);
	stats->jabber = regVal & counterMask;
	/* read SMCTxFragment cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_TX_STATS_FRAGMENT, &regVal);
	stats->fragment = regVal & counterMask;
	/* read SMCTxUndersize cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_TX_STATS_UNDERSIZE, &regVal);
	stats->undersize = regVal & counterMask;
	/* read SMCTxOversize cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_TX_STATS_OVERSIZE, &regVal);
	stats->oversize = regVal & counterMask;
	/* read SMCTxRxError cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_TX_STATS_RXERROR, &regVal);
	stats->rxError = regVal & counterMask;
	/* read SMCTxCrcErrTxUnderrun cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_TX_STATS_CRCERR_TXUNDERRUN, &regVal);
	stats->crcErrTxUnderrun = regVal & counterMask;
	/* read SMCTxRxOverrunBadFC cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_TX_STATS_RXOVERRUN_BADFC, &regVal);
	stats->rxOverrunBadFC = regVal & counterMask;
	/* read SMCTxGoodPkts cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_TX_STATS_GOODPKTS, &regVal);
	stats->goodPkts = regVal & counterMask;
	/* read SMCTxFcPkts cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_TX_STATS_FCPKT, &regVal);
	stats->fcPkts = regVal & counterMask;
	/* read SMCTxBroadcast cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_TX_STATS_BROADCAST, &regVal);
	stats->broadcast = regVal & counterMask;
	/* read SMCTxMulticast cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_TX_STATS_MULTICAST, &regVal);
	stats->multicast = regVal & counterMask;
	/* read SMCTxOutPFrames cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_TX_STATS_OUTPFRAGS, &regVal);
	stats->outPFrames = regVal & counterMask;
	/* read SMCTxInPFrags cnt */
	readMACReg48(device, MRVL_AMG_MAC_SMAC_TX_STATS_OUTPFRAMES, &regVal);
	stats->outPFrags = regVal & counterMask;

	return status;
}

/**
 * @brief Get WMC Rx Statistics
 * 
 * @param[in] device PHY pointer
 * @param[out] stats function modifies this pointer to reflect WMC Rx Stats
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MAC_STATS_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MAC_GetRxWMCStats(MRVL_DEV_PTR device, MRVL_AMG_MAC_RX_WMC_STATS* stats)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U64 counterMask = 0xFFFFFFFFFFFFU;

	/* read WMCRxPkts cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_RX_STATS_PKTS, &regVal);
	stats->pkts = regVal & counterMask;
	/* read WMCRxDroppedPkts cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_RX_STATS_DROPPEDPKTS, &regVal);
	stats->droppedPkts = regVal & counterMask;
	/* read WMCRxOctets cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_RX_STATS_OCTETS, &regVal);
	stats->octets = regVal & counterMask;
	/* read WMCRxJabber cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_RX_STATS_JABBER, &regVal);
	stats->jabber = regVal & counterMask;
	/* read WMCRxFragment cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_RX_STATS_FRAGMENT, &regVal);
	stats->fragment = regVal & counterMask;
	/* read WMCRxUndersize cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_RX_STATS_UNDERSIZE, &regVal);
	stats->undersize = regVal & counterMask;
	/* read WMCRxRxError cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_RX_STATS_RXERROR, &regVal);
	stats->rxError = regVal & counterMask;
	/* read WMCRxCrcError cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_RX_STATS_CRCERROR, &regVal);
	stats->crcError = regVal & counterMask;
	/* read WMCRxFcPkts cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_RX_STATS_FCPKTS, &regVal);
	stats->fcPkts = regVal & counterMask;
	/* read WMCRxBroadcast cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_RX_STATS_BROADCASTPKTS, &regVal);
	stats->broadcast = regVal & counterMask;
	/* read WMCRxMulticast cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_RX_STATS_MULTICASTPKTS, &regVal);
	stats->multicast = regVal & counterMask;
	/* read WMCRxInPAssemblyErr cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_RX_STATS_INPASSEMBLYERR, &regVal);
	stats->inPAssemblyErr = regVal & counterMask;
	/* read WMCRxInPFrames cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_RX_STATS_INPFRAMES, &regVal);
	stats->inPFrames = regVal & counterMask;
	/* read WMCRxInPFrags cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_RX_STATS_INPFRAGS, &regVal);
	stats->inPFrags = regVal & counterMask;
	/* read WMCRxInPBadFrags cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_RX_STATS_INPBADFRAGS, &regVal);
	stats->inPBadFrags = regVal & counterMask;

	return status;
}

/**
 * @brief Get WMC Tx Statistics
 * 
 * @param[in] device PHY pointer
 * @param[out] stats function modifies this pointer to reflect WMC Tx Stats
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MAC_STATS_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MAC_GetTxWMCStats(MRVL_DEV_PTR device, MRVL_AMG_MAC_TX_WMC_STATS* stats)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U64 counterMask = 0xFFFFFFFFFFFFU;

	/* read WMCTxPkts cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_TX_STATS_PKTS, &regVal);
	stats->pkts = regVal & counterMask;
	/* read WMCTxDroppedPkts cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_TX_STATS_DROPPEDPKTS, &regVal);
	stats->droppedPkts = regVal & counterMask;
	/* read WMCTxOctets cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_TX_STATS_OCTETS, &regVal);
	stats->octets = regVal & counterMask;
	/* read WMCTxJabber cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_TX_STATS_JABBER, &regVal);
	stats->jabber = regVal & counterMask;
	/* read WMCTxFragment cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_TX_STATS_FRAGMENT, &regVal);
	stats->fragment = regVal & counterMask;
	/* read WMCTxUndersize cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_TX_STATS_UNDERSIZE, &regVal);
	stats->undersize = regVal & counterMask;
	/* read WMCTxRxError cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_TX_STATS_RXERROR, &regVal);
	stats->rxError = regVal & counterMask;
	/* read WMCTxCrcError cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_TX_STATS_CRCERROR, &regVal);
	stats->crcError = regVal & counterMask;
	/* read WMCTxFcPkts cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_TX_STATS_FCPKTS, &regVal);
	stats->fcPkts = regVal & counterMask;
	/* read WMCTxBroadcast cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_TX_STATS_BROADCASTPKTS, &regVal);
	stats->broadcast = regVal & counterMask;
	/* read WMCTxMulticast cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_TX_STATS_MULTICASTPKTS, &regVal);
	stats->multicast = regVal & counterMask;
	/* read WMCTxOutPFrames cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_TX_STATS_OUTPFRAGS, &regVal);
	stats->outPFrames = regVal & counterMask;
	/* read WMCTxOutPFrags cnt */
	readMACReg48(device, MRVL_AMG_MAC_WMAC_TX_STATS_OUTPFRAMES, &regVal);
	stats->outPFrags = regVal & counterMask;

	return status;
}

/**
 * @brief clear SMC and WMC stats.
 * 
 * @param[in] device PHY pointer
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MAC_STATS_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MAC_ClearMIBStats(MRVL_DEV_PTR device)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 clearStatsValue = 0x0303U;
	MRVL_APHY_U16 data = 0;
	MRVL_AMG_MCS_ReadReg16(device, MRVL_AMG_MCS_SLICE_MIB_CTRL_CLR_CAP, &data);
	data |= clearStatsValue;
	MRVL_AMG_MCS_WriteReg16(device, MRVL_AMG_MCS_SLICE_MIB_CTRL_CLR_CAP, data);
	return status;
}


/**
 * @brief Get RX SecY Statistics
 * 
 * @param[in] device PHY pointer
 * @param[in] index SecY index
 * @param[out] stats function modifies this pointer to reflect Rx SecY Stats
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxSecYStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_AMG_MCS_RX_SECY_COUNTER* stats)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U64 counterMask = 0xFFFFFFFFFFFFFFFFU;

	if (index >= MRVL_AMG_MCS_MAX_SECY_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* read decrepted octets cnt */
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_IN_OCETS_SECY_DECRYPTED, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->inOctetsSecYDecrypted = regVal & counterMask;
		/* read validated octets cnt */
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_IN_OCETS_SECY_VALIDATE, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->inOctetsSecYValidate = regVal & counterMask;
		/* read SCI is unknown packets cnt */
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_IN_PKTS_SECY_NO_SA, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->inPktsSecYNoSA = regVal & counterMask;
		/* read unknown SA packets cnt */
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_IN_PKTS_SECY_NO_SA_ERROR, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->inPktsSecYNoSAError = regVal & counterMask;
		/* read invalid packets cnt */
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_IN_PKTS_SECY_BAD_TAG, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->inPktsSecYBadTag = regVal & counterMask;
		/* read without a SecTag packets cnt */
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_IN_PKTS_SECY_NO_TAG, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->inPktsSecYNoTag = regVal & counterMask;
		/* read without a SecTag packets cnt */
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_IN_PKTS_SECY_UNTAGGED, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->inPktsSecYUntagged = regVal & counterMask;
		/* read disabled packets cnt */
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_IN_PKTS_CTRL_PORT_DISABLE, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->inPktsCtrlPortDisable = regVal & counterMask;
		
		/* controlled port counters */
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_IN_CTRL_PORT_OCETS, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->inCtrlPortOctets = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_IN_CTRL_PORT_UC_PKTS, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->inCtrlPortUCPkts = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_IN_CTRL_PORT_MC_PKTS, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->inCtrlPortMCPkts = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_IN_CTRL_PORT_BC_PKTS, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->inCtrlPortBCPkts = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_IN_UNCTRL_PORT_OCETS, index, MRVL_AMG_MCS_RANGE8), &regVal);
		/* uncontrolled port counters */
		stats->inUnCtrlPortOctets = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_IN_UNCTRL_PORT_UC_PKTS, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->inUnCtrlPortUCPkts = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_IN_UNCTRL_PORT_MC_PKTS, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->inUnCtrlPortMCPkts = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_IN_UNCTRL_PORT_BC_PKTS, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->inUnCtrlPortBCPkts = regVal & counterMask;
	}

	return status;
}

/**
 * @brief Get TX SecY Statistics
 * 
 * @param[in] device PHY pointer
 * @param[in] index SecY index
 * @param[out] stats function modifies this pointer to reflect Tx SecY Stats
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxSecYStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_AMG_MCS_TX_SECY_COUNTER* stats)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U64 counterMask = 0xFFFFFFFFFFFFFFFFU;

	if (index >= MRVL_AMG_MCS_MAX_SECY_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* The number of packets received on disabled SecY. */
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_OUT_PKTS_CTRL_PORT_DISABLE, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->outPktsCtrlPortDisable = regVal & counterMask;
		/* The number of packets without a SecTag */
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_OUT_PKTS_SECY_UNTAGGED, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->outPktsSecYUntagged = regVal & counterMask;
		/* The number of packets without matching SA */
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_OUT_PKTS_SECY_NO_ACTIVE_SA, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->outPktsSecYNoActiveSA = regVal & counterMask;
		/* The number of packets too long */
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_OUT_PKTS_SECY_TOO_LONG, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->outPktSecYTooLong = regVal & counterMask;
		/* The number of octets integrity protected but not encrypted */
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_OUT_OCETS_SECY_PROTECTED, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->outOctetsSecYProtected = regVal & counterMask;
		/* The number of octets integrity protected and encrypted */
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_OUT_OCETS_SECY_ENCRYPTED, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->outOctetsSecYEncrypted = regVal & counterMask;

		/* control port counters */
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_OUT_CTRL_PORT_OCETS, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->outCtrlPortOctets = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_OUT_CTRL_PORT_UC_PKTS, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->outCtrlPortUCPkts = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_OUT_CTRL_PORT_MC_PKTS, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->outCtrlPortMCPkts = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_OUT_CTRL_PORT_BC_PKTS, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->outCtrlPortBCPkts = regVal & counterMask;
		/* uncontrolled port counters */
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_OUT_UNCTRL_PORT_OCETS, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->outUnCtrlPortOctets = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_OUT_UNCTRL_PORT_UC_PKTS, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->outUnCtrlPortUCPkts = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_OUT_UNCTRL_PORT_MC_PKTS, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->outUnCtrlPortMCPkts = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, GETADDR(MRVL_AMG_MCS_OUT_UNCTRL_PORT_BC_PKTS, index, MRVL_AMG_MCS_RANGE8), &regVal);
		stats->outUnCtrlPortBCPkts = regVal & counterMask;
	}

	return status;
}

/**
 * @brief Get RX SC Statistics
 * 
 * @param[in] device PHY pointer
 * @param[in] index SC index
 * @param[out] stats function modifies this pointer to reflect Rx SC Stats
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxSCStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_AMG_MCS_RX_SC_COUNTER* stats)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U64 counterMask = 0xFFFFFFFFFFFFFFFFU;
	MRVL_APHY_U32 BaseAddr_InPktsSCCamHit, BaseAddr_InPktsSCLate, BaseAddr_InPktsSCNotValid, BaseAddr_InPktsSCInvalid, BaseAddr_InPktsSCDelayed
		, BaseAddr_InPktsSCUnchecked, BaseAddr_InPktsSCOK;

	if (index >= MRVL_AMG_MCS_MAX_SC_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_InPktsSCCamHit = GETADDR(MRVL_AMG_MCS_IN_PKTS_SC_CAM_HIT, index, MRVL_AMG_MCS_RANGE8);
		BaseAddr_InPktsSCLate = GETADDR(MRVL_AMG_MCS_IN_PKTS_SC_LATE, index, MRVL_AMG_MCS_RANGE8);
		BaseAddr_InPktsSCNotValid = GETADDR(MRVL_AMG_MCS_IN_PKTS_SC_NOT_VALID, index, MRVL_AMG_MCS_RANGE8);
		BaseAddr_InPktsSCInvalid = GETADDR(MRVL_AMG_MCS_IN_PKTS_SC_INVALID, index, MRVL_AMG_MCS_RANGE8);
		BaseAddr_InPktsSCDelayed = GETADDR(MRVL_AMG_MCS_IN_PKTS_SC_DELAYED, index, MRVL_AMG_MCS_RANGE8);
		BaseAddr_InPktsSCUnchecked = GETADDR(MRVL_AMG_MCS_IN_PKTS_SC_UNCHECKED, index, MRVL_AMG_MCS_RANGE8);
		BaseAddr_InPktsSCOK = GETADDR(MRVL_AMG_MCS_IN_PKTS_SC_OK, index, MRVL_AMG_MCS_RANGE8);

		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_InPktsSCCamHit, &regVal);
		stats->inPktsSCCamHit = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_InPktsSCLate, &regVal);
		stats->inPktsSCLate = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_InPktsSCNotValid, &regVal);
		stats->inPktsSCNotValid = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_InPktsSCInvalid, &regVal);
		stats->inPktsSCInvalid = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_InPktsSCDelayed, &regVal);
		stats->inPktsSCDelayed = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_InPktsSCUnchecked, &regVal);
		stats->inPktsSCUnchecked = regVal & counterMask;
		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_InPktsSCOK, &regVal);
		stats->inPktsSCOK = regVal & counterMask;
	}

	return status;
}

/**
 * @brief Get TX SC Statistics
 * 
 * @param[in] device PHY pointer
 * @param[in] index SC index
 * @param[out] stats function modifies this pointer to reflect Tx SC Stats
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxSCStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_AMG_MCS_TX_SC_COUNTER* stats)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U64 counterMask = 0xFFFFFFFFFFFFFFFFU;
	MRVL_APHY_U32 BaseAddr_OutPktsProtected, BaseAddr_OutPktsEncrypted;
	if (index >= MRVL_AMG_MCS_MAX_SC_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_OutPktsProtected = GETADDR(MRVL_AMG_MCS_OUT_PKTS_PROTECTED, index, MRVL_AMG_MCS_RANGE8);
		BaseAddr_OutPktsEncrypted = GETADDR(MRVL_AMG_MCS_OUT_PKTS_ENCRYPTED, index, MRVL_AMG_MCS_RANGE8);

		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_OutPktsProtected, &regVal);
		stats->outPktsProtected = regVal & counterMask;

		MRVL_AMG_MCS_ReadReg64(device, BaseAddr_OutPktsEncrypted, &regVal);
		stats->outPktsEncrypted = regVal & counterMask;
	}

	return status;
}

/**
 * @brief Get RX General Statistics per Port
 * 
 * @param[in] device PHY pointer 
 * @param[out] stats function modifies this pointer to reflect port Stats
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxPortStats(MRVL_DEV_PTR device, MRVL_AMG_MCS_RX_PORT_COUNTER* stats)
{
	MRVL_APHY_U64 regVal = 0;
	MRVL_AMG_MCS_ReadReg64(device, MRVL_AMG_MCS_IN_PKTS_PARSE_ERR, &regVal);
	stats->inPktsParseErr = regVal;
	MRVL_AMG_MCS_ReadReg64(device, MRVL_AMG_MCS_IN_PKTS_FLOW_ID_TCAM_MISS, &regVal);
	stats->inPktsFlowIDTCAMMiss = regVal;
	MRVL_AMG_MCS_ReadReg64(device, MRVL_AMG_MCS_IN_PKTS_EARLY_PREEMPT_ERR, &regVal);
	stats->inPktsEarlyPreemptErr = regVal;
	MRVL_AMG_MCS_ReadReg64(device, MRVL_AMG_MCS_IN_PKTS_FLOW_ID_TCAM_HIT_0, &regVal);
	stats->inPktsFlowIDTCAMHit0 = regVal;
	MRVL_AMG_MCS_ReadReg64(device, MRVL_AMG_MCS_IN_PKTS_FLOW_ID_TCAM_HIT_1, &regVal);
	stats->inPktsFlowIDTCAMHit1 = regVal;
	MRVL_AMG_MCS_ReadReg64(device, MRVL_AMG_MCS_IN_PKTS_FLOW_ID_TCAM_HIT_2, &regVal);
	stats->inPktsFlowIDTCAMHit2 = regVal;
	MRVL_AMG_MCS_ReadReg64(device, MRVL_AMG_MCS_IN_PKTS_FLOW_ID_TCAM_HIT_3, &regVal);
	stats->inPktsFlowIDTCAMHit3 = regVal;

	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get TX General Statistics per Port
 * 
 * @param[in] device PHY pointer 
 * @param[out] stats function modifies this pointer to reflect port Stats
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxPortStats(MRVL_DEV_PTR device, MRVL_AMG_MCS_TX_PORT_COUNTER* stats)
{
	MRVL_APHY_U64 regVal = 0;
	MRVL_AMG_MCS_ReadReg64(device, MRVL_AMG_MCS_OUT_PKTS_PARSE_ERR, &regVal);
	stats->outPktsParseErr = regVal;
	MRVL_AMG_MCS_ReadReg64(device, MRVL_AMG_MCS_OUT_PKTS_FLOW_ID_TCAM_MISS, &regVal);
	stats->outPktsFlowIDTCAMMiss = regVal;
	MRVL_AMG_MCS_ReadReg64(device, MRVL_AMG_MCS_OUT_PKTS_EARLY_PREEMPT_ERR, &regVal);
	stats->outPktsEarlyPreemptErr = regVal;
	MRVL_AMG_MCS_ReadReg64(device, MRVL_AMG_MCS_OUT_PKTS_FLOW_ID_TCAM_HIT_0, &regVal);
	stats->outPktsFlowIDTCAMHit0 = regVal;
	MRVL_AMG_MCS_ReadReg64(device, MRVL_AMG_MCS_OUT_PKTS_FLOW_ID_TCAM_HIT_1, &regVal);
	stats->outPktsFlowIDTCAMHit1 = regVal;
	MRVL_AMG_MCS_ReadReg64(device, MRVL_AMG_MCS_OUT_PKTS_FLOW_ID_TCAM_HIT_2, &regVal);
	stats->outPktsFlowIDTCAMHit2 = regVal;
	MRVL_AMG_MCS_ReadReg64(device, MRVL_AMG_MCS_OUT_PKTS_FLOW_ID_TCAM_HIT_3, &regVal);
	stats->outPktsFlowIDTCAMHit3 = regVal;

	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Clear all secy, sc and port stats counter to 0.
 * 
 * @param[in] device PHY pointer
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_ClearMCSStats(MRVL_DEV_PTR device)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 clearStatsValue = 0xF;
	MRVL_AMG_MCS_WriteReg32(device, MRVL_AMG_MCS_CSE_TX_STATS_CLEAR, clearStatsValue);
	MRVL_AMG_MCS_WriteReg32(device, MRVL_AMG_MCS_CSE_RX_STATS_CLEAR, clearStatsValue);

	return status;
}


/******************************************************************************
 *      Custom/VLAN Tag
 ******************************************************************************/

/**
 * @brief Set custom/VLAN tag information
 * 
 * @param[in] device PHY pointer
 * @param[in] direction TRUE: egress/tx; FALSE: ingress/rx 
 * @param[in] tag MSEC_CUSTOM_TAG
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_TAG_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetCustomVLANTag(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CUSTOM_TAG* tag)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U32 addr = (MRVL_APHY_U32)index * MRVL_AMG_MCS_REG_BUS_WIDTH;
	if (direction == MRVL_AMG_MCS_DIR_EGRESS)
	{
		addr += MRVL_AMG_MCS_PEX_TX_SLAVE_CUSTOM_TAG;
	}
	else
	{
		addr += MRVL_AMG_MCS_PEX_RX_SLAVE_CUSTOM_TAG;
	}

	if (index >= MRVL_AMG_MCS_MAX_CUSTOM_TAG_NUM || (tag->isVLANTag == MRVL_APHY_TRUE && tag->size != 4))
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		regVal = ((MRVL_APHY_U32)index << 22) 
			| ((MRVL_APHY_U32)((tag->hasBonusData == MRVL_APHY_TRUE) ? 1:0) << 21)
			| ((MRVL_APHY_U32)((tag->isVLANTag == MRVL_APHY_TRUE) ? 1 : 0) << 20)
			| (((MRVL_APHY_U32)tag->size & 0xFU) << 16) 
			| (MRVL_APHY_U32)tag->ethType;
		MRVL_AMG_MCS_WriteReg32(device, addr, regVal);

		/* rule ether type enable */
		if (direction == MRVL_AMG_MCS_DIR_EGRESS)
		{
			addr = MRVL_AMG_MCS_PEX_TX_ETYPE_ENABLE;
		}
		else
		{
			addr = MRVL_AMG_MCS_PEX_RX_ETYPE_ENABLE;
		}
		MRVL_AMG_MCS_ReadReg32(device, addr, &regVal);

		if (tag->isEnabled == MRVL_APHY_TRUE)
		{
			regVal |= (MRVL_APHY_U32)1U << index;
		}
		else
		{
			regVal &= ~((MRVL_APHY_U32)1U << index);
		}
		MRVL_AMG_MCS_WriteReg32(device, addr, regVal);
	}

	return status;
}

/**
 * @brief Get custom/VLAN tag information
 * 
 * @param[in] device PHY pointer
 * @param[in] direction TRUE: egress/tx; FALSE: ingress/rx
 * @param[in] index 
 * @param[out] tag function modifies this pointer to reflect custom/VLAN tag information
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_TAG_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetCustomVLANTag(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CUSTOM_TAG* tag)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U32 addr = (MRVL_APHY_U32)index * MRVL_AMG_MCS_REG_BUS_WIDTH;
	if (direction == MRVL_AMG_MCS_DIR_EGRESS)
	{
		addr += MRVL_AMG_MCS_PEX_TX_SLAVE_CUSTOM_TAG;
	}
	else
	{
		addr += MRVL_AMG_MCS_PEX_RX_SLAVE_CUSTOM_TAG;
	}

	if (index >= MRVL_AMG_MCS_MAX_CUSTOM_TAG_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		MRVL_AMG_MCS_ReadReg32(device, addr, &regVal);
		tag->hasBonusData = (0 != (regVal & 0x200000U)) ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
		tag->isVLANTag = (0 != (regVal & 0x100000U)) ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
		tag->size = (MRVL_APHY_U8) ((regVal & 0xF0000U) >> 16);
		tag->ethType = (MRVL_APHY_U16)(regVal & 0xFFFFU);

		/* rule ether type enable */
		if (direction == MRVL_AMG_MCS_DIR_EGRESS)
		{
			addr = MRVL_AMG_MCS_PEX_TX_ETYPE_ENABLE;
		}
		else
		{
			addr = MRVL_AMG_MCS_PEX_RX_ETYPE_ENABLE;
		}
		MRVL_AMG_MCS_ReadReg32(device, addr, &regVal);
		regVal &=  (MRVL_APHY_U32)1U << index;
		tag->isEnabled = (0 != regVal) ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
	}

	return status;
}


/******************************************************************************
 *      Control Packet
 ******************************************************************************/

/**
 * @brief Set control packet classification with e-type
 * 
 * @param[in] device PHY pointer
 * @param[in] direction TRUE: egress/tx; FALSE: ingress/rx
 * @param[in] classification MSEC_CTRL_PCKT_ETYPE
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_CTRL_PCKT_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetCtrlPckt_EthType(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CTRL_PCKT_ETYPE* classification)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U32 addr = MRVL_AMG_MCS_CTRL_PCKT_RULE_ETYPE_OFFSET + (MRVL_APHY_U32)index * MRVL_AMG_MCS_REG_BUS_WIDTH;
	MRVL_APHY_U32 addrEnable = MRVL_AMG_MCS_CTRL_PCKT_RULE_ENABLE_OFFSET;
	if (direction == MRVL_AMG_MCS_DIR_EGRESS)
	{
		addr += MRVL_AMG_MCS_PEX_TX_SLAVE;
		addrEnable += MRVL_AMG_MCS_PEX_TX_SLAVE;
	}
	else
	{
		addr += MRVL_AMG_MCS_PEX_RX_SLAVE;
		addrEnable += MRVL_AMG_MCS_PEX_RX_SLAVE;
	}

	if (index >= MRVL_AMG_MCS_MAX_CTRL_PCKT_ETYPE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		MRVL_AMG_MCS_WriteReg32(device, addr, (MRVL_APHY_U32)classification->ethType);

		MRVL_AMG_MCS_ReadReg32(device, addrEnable, &regVal);
		if (classification->isEnabled == MRVL_APHY_TRUE)
		{
			regVal |=  (MRVL_APHY_U32)1U << index;
		}
		else
		{
			regVal &= ~( (MRVL_APHY_U32)1U << index);
		}
		MRVL_AMG_MCS_WriteReg32(device, addrEnable, regVal);
	}

	return status;
}

/**
 * @brief Get ctrl packet etype classification information
 * 
 * @param[in] device PHY pointer
 * @param[in] direction TRUE: egress/tx; FALSE: ingress/rx
 * @param[in] index 
 * @param[out] classification function modifies this pointer to reflect MSEC_CTRL_PCKT_ETYPE
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_CTRL_PCKT_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetCtrlPckt_EthType(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CTRL_PCKT_ETYPE* classification)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U32 addr = MRVL_AMG_MCS_CTRL_PCKT_RULE_ETYPE_OFFSET + (MRVL_APHY_U32)index * MRVL_AMG_MCS_REG_BUS_WIDTH;
	MRVL_APHY_U32 addrEnable = MRVL_AMG_MCS_CTRL_PCKT_RULE_ENABLE_OFFSET;
	if (direction == MRVL_AMG_MCS_DIR_EGRESS)
	{
		addr += MRVL_AMG_MCS_PEX_TX_SLAVE;
		addrEnable += MRVL_AMG_MCS_PEX_TX_SLAVE;
	}
	else
	{
		addr += MRVL_AMG_MCS_PEX_RX_SLAVE;
		addrEnable += MRVL_AMG_MCS_PEX_RX_SLAVE;
	}

	if (index >= MRVL_AMG_MCS_MAX_CTRL_PCKT_ETYPE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		index = index;

		MRVL_AMG_MCS_ReadReg32(device, addr, &regVal);
		classification->ethType = (MRVL_APHY_U16)(regVal & 0xFFFFU);

		MRVL_AMG_MCS_ReadReg32(device, addrEnable, &regVal);
		if (0 == (regVal & ((MRVL_APHY_U32)1U << index)))
		{
			classification->isEnabled = MRVL_APHY_FALSE;
		}
		else
		{
			classification->isEnabled = MRVL_APHY_TRUE;
		}
	}

	return status;
}

/**
 * @brief Set control packet classification with DA
 * 
 * @param[in] device PHY pointer
 * @param[in] direction RUE: egress/tx; FALSE: ingress/rx 
 * @param[in] classification MSEC_CTRL_PCKT_DA
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_CTRL_PCKT_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetCtrlPckt_DA(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CTRL_PCKT_DA* classification)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U64 regVal64 = 0;
	MRVL_APHY_U32 addr = MRVL_AMG_MCS_CTRL_PCKT_RULE_DA_OFFSET + (MRVL_APHY_U32)index * 0x10U;
	MRVL_APHY_U32 addrEnable = MRVL_AMG_MCS_CTRL_PCKT_RULE_ENABLE_OFFSET;
	MRVL_APHY_U8 i = 0;
	if (direction == MRVL_AMG_MCS_DIR_EGRESS)
	{
		addr += MRVL_AMG_MCS_PEX_TX_SLAVE;
		addrEnable += MRVL_AMG_MCS_PEX_TX_SLAVE;
	}
	else
	{
		addr += MRVL_AMG_MCS_PEX_RX_SLAVE;
		addrEnable += MRVL_AMG_MCS_PEX_RX_SLAVE;
	}

	if (index >= MRVL_AMG_MCS_MAX_CTRL_PCKT_DA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		for (i = 0; i < 6; i++)
		{
			regVal64 += ((MRVL_APHY_U64)classification->DA[5 - i]) << (i * 8);
		}
		MRVL_AMG_MCS_WriteReg64(device, addr, regVal64);

		MRVL_AMG_MCS_ReadReg32(device, addrEnable, &regVal);
		if (classification->isEnabled == MRVL_APHY_TRUE)
		{
			regVal |= (MRVL_APHY_U32)0x100U << index;
		}
		else
		{
			regVal &= ~((MRVL_APHY_U32)0x100U << index);
		}
		MRVL_AMG_MCS_WriteReg32(device, addrEnable, regVal);
	}

	return status;
}

/**
 * @brief Get ctrl packet DA classification information
 * 
 * @param[in] device PHY pointer
 * @param[in] direction TRUE: egress/tx; FALSE: ingress/rx
 * @param[in] index 
 * @param[out] classification function modifies this pointer to reflect MSEC_CTRL_PCKT_DA
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_CTRL_PCKT_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetCtrlPckt_DA(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CTRL_PCKT_DA* classification)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U64 regVal64 = 0;
	MRVL_APHY_U32 addr = MRVL_AMG_MCS_CTRL_PCKT_RULE_DA_OFFSET + (MRVL_APHY_U32)index * 0x10U;
	MRVL_APHY_U32 addrEnable = MRVL_AMG_MCS_CTRL_PCKT_RULE_ENABLE_OFFSET;
	MRVL_APHY_U8 i = 0;
	if (direction == MRVL_AMG_MCS_DIR_EGRESS)
	{
		addr += MRVL_AMG_MCS_PEX_TX_SLAVE;
		addrEnable += MRVL_AMG_MCS_PEX_TX_SLAVE;
	}
	else
	{
		addr += MRVL_AMG_MCS_PEX_RX_SLAVE;
		addrEnable += MRVL_AMG_MCS_PEX_RX_SLAVE;
	}

	if (index >= MRVL_AMG_MCS_MAX_CTRL_PCKT_DA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		index = index;

		MRVL_AMG_MCS_ReadReg64(device, addr, &regVal64);

		for (i = 0; i < 6; i++)
		{
			classification->DA[5 - i] = (MRVL_APHY_U8)((regVal64 >> (i * 8)) & 0xFFU);
		}

		MRVL_AMG_MCS_ReadReg32(device, addrEnable, &regVal);
		if (0 == (regVal & ((MRVL_APHY_U32)0x100U << index)))
		{
			classification->isEnabled = MRVL_APHY_FALSE;
		}
		else
		{
			classification->isEnabled = MRVL_APHY_TRUE;
		}
	}

	return status;
}

/**
 * @brief Set control packet classification with DA range
 * 
 * @param[in] device PHY pointer
 * @param[in] direction TRUE: egress/tx; FALSE: ingress/rx
 * @param[in] classification MSEC_CTRL_PCKT_DA_RANGE
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_CTRL_PCKT_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetCtrlPckt_DARange(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CTRL_PCKT_DA_RANGE* classification)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U64 regVal64 = 0;
	MRVL_APHY_U32 addr = MRVL_AMG_MCS_CTRL_PCKT_RULE_DA_RANGE_OFFSET + (MRVL_APHY_U32)index * 0x20U;
	MRVL_APHY_U32 addrEnable = MRVL_AMG_MCS_CTRL_PCKT_RULE_ENABLE_OFFSET;
	MRVL_APHY_U8 i = 0;
	if (direction == MRVL_AMG_MCS_DIR_EGRESS)
	{
		addr += MRVL_AMG_MCS_PEX_TX_SLAVE;
		addrEnable += MRVL_AMG_MCS_PEX_TX_SLAVE;
	}
	else
	{
		addr += MRVL_AMG_MCS_PEX_RX_SLAVE;
		addrEnable += MRVL_AMG_MCS_PEX_RX_SLAVE;
	}

	if (index >= MRVL_AMG_MCS_MAX_CTRL_PCKT_DA_RANGE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		for (i = 0; i < 6; i++)
		{
			regVal64 += ((MRVL_APHY_U64)classification->MIN_DA[5 - i]) << (i * 8);
		}
		MRVL_AMG_MCS_WriteReg64(device, addr, regVal64);

		regVal64 = 0;
		for (i = 0; i < 6; i++)
		{
			regVal64 += ((MRVL_APHY_U64)classification->MAX_DA[5 - i]) << (i * 8);
		}
		MRVL_AMG_MCS_WriteReg64(device, addr + 0x10, regVal64);

		MRVL_AMG_MCS_ReadReg32(device, addrEnable, &regVal);
		if (classification->isEnabled == MRVL_APHY_TRUE)
		{
			regVal |= 0x10000U << index;
		}
		else
		{
			regVal &= ~(0x10000U << index);
		}
		MRVL_AMG_MCS_WriteReg32(device, addrEnable, regVal);
	}

	return status;
}

/**
 * @brief Get ctrl packet DA range classification information
 * 
 * @param[in] device PHY pointer
 * @param[in] direction TRUE: egress/tx; FALSE: ingress/rx
 * @param[in] index 
 * @param[out] classification function modifies this pointer to reflect MSEC_CTRL_PCKT_DA_RANGE
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_CTRL_PCKT_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetCtrlPckt_DARange(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CTRL_PCKT_DA_RANGE* classification)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U64 regVal64 = 0;
	MRVL_APHY_U32 addr = MRVL_AMG_MCS_CTRL_PCKT_RULE_DA_RANGE_OFFSET + (MRVL_APHY_U32)index * 0x20U;
	MRVL_APHY_U32 addrEnable = MRVL_AMG_MCS_CTRL_PCKT_RULE_ENABLE_OFFSET;
	MRVL_APHY_U8 i = 0;

	if (direction == MRVL_AMG_MCS_DIR_EGRESS)
	{
		addr += MRVL_AMG_MCS_PEX_TX_SLAVE;
		addrEnable += MRVL_AMG_MCS_PEX_TX_SLAVE;
	}
	else
	{
		addr += MRVL_AMG_MCS_PEX_RX_SLAVE;
		addrEnable += MRVL_AMG_MCS_PEX_RX_SLAVE;
	}

	if (index >= MRVL_AMG_MCS_MAX_CTRL_PCKT_DA_RANGE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		index = index;

		MRVL_AMG_MCS_ReadReg64(device, addr, &regVal64);
		for (i = 0; i < 6; i++)
		{
			classification->MIN_DA[5 - i] = (MRVL_APHY_U8)((regVal64 >> (i * 8)) & 0xFFU);
		}
		MRVL_AMG_MCS_ReadReg64(device, addr + 0x10, &regVal64);

		for (i = 0; i < 6; i++)
		{
			classification->MAX_DA[5 - i] = (MRVL_APHY_U8)((regVal64 >> (i * 8)) & 0xFFU);
		}

		MRVL_AMG_MCS_ReadReg32(device, addrEnable, &regVal);
		if (0 == (regVal & (0x10000U << index)))
		{
			classification->isEnabled = MRVL_APHY_FALSE;
		}
		else
		{
			classification->isEnabled = MRVL_APHY_TRUE;
		}
	}

	return status;
}

/**
 * @brief Set control packet classification with combo settings
 * 
 * @param[in] device PHY pointer
 * @param[in] direction TRUE: egress/tx; FALSE: ingress/rx 
 * @param[in] classification MSEC_CTRL_PCKT_COMBO
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_CTRL_PCKT_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_SetCtrlPckt_COMBO(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CTRL_PCKT_COMBO* classification)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U64 regVal64 = 0;
	MRVL_APHY_U32 addr = MRVL_AMG_MCS_CTRL_PCKT_RULE_COMBO_OFFSET + (MRVL_APHY_U32)index * 0x40U;
	MRVL_APHY_U32 addrEnable = MRVL_AMG_MCS_CTRL_PCKT_RULE_ENABLE_OFFSET;
	MRVL_APHY_U8 i = 0;

	if (direction == MRVL_AMG_MCS_DIR_EGRESS)
	{
		addr += MRVL_AMG_MCS_PEX_TX_SLAVE;
		addrEnable += MRVL_AMG_MCS_PEX_TX_SLAVE;
	}
	else
	{
		addr += MRVL_AMG_MCS_PEX_RX_SLAVE;
		addrEnable += MRVL_AMG_MCS_PEX_RX_SLAVE;
	}

	if (index >= MRVL_AMG_MCS_MAX_CTRL_PCKT_COMBO_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		for (i = 0; i < 6; i++)
		{
			regVal64 += ((MRVL_APHY_U64)classification->MIN_DA[5 - i]) << (i * 8);
		}
		MRVL_AMG_MCS_WriteReg64(device, addr, regVal64);

		regVal64 = 0;
		for (i = 0; i < 6; i++)
		{
			regVal64 += ((MRVL_APHY_U64)classification->MAX_DA[5 - i]) << (i * 8);
		}
		MRVL_AMG_MCS_WriteReg64(device, addr + 0x10, regVal64);

		MRVL_AMG_MCS_WriteReg32(device, addr + 0x20, (MRVL_APHY_U32)classification->ethType & 0xFFFFU);

		MRVL_AMG_MCS_ReadReg32(device, addrEnable, &regVal);
		if (classification->isEnabled == MRVL_APHY_TRUE)
		{
			regVal |= 0x100000U << index;
		}
		else
		{
			regVal &= ~(0x100000U << index);
		}
		MRVL_AMG_MCS_WriteReg32(device, addrEnable, regVal);
	}

	return status;
}

/**
 * @brief Get ctrl packet combo settings classification information
 * 
 * @param[in] device PHY pointer
 * @param[in] direction TRUE: egress/tx; FALSE: ingress/rx
 * @param[in] index 
 * @param[out] classification function modifies this pointer to reflect MSEC_CTRL_PCKT_COMBO
 * @return MRVL_APHY_STATUS 
 * 
 * @ingroup MSC_CTRL_PCKT_CNFG
 */
MRVL_APHY_STATUS MRVL_AMG_MCS_GetCtrlPckt_COMBO(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CTRL_PCKT_COMBO* classification)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U64 regVal64 = 0;
	MRVL_APHY_U32 addr = MRVL_AMG_MCS_CTRL_PCKT_RULE_COMBO_OFFSET + (MRVL_APHY_U32)index * 0x40U;
	MRVL_APHY_U32 addrEnable = MRVL_AMG_MCS_CTRL_PCKT_RULE_ENABLE_OFFSET;
	MRVL_APHY_U8 i = 0;

	if (direction == MRVL_AMG_MCS_DIR_EGRESS)
	{
		addr += MRVL_AMG_MCS_PEX_TX_SLAVE;
		addrEnable += MRVL_AMG_MCS_PEX_TX_SLAVE;
	}
	else
	{
		addr += MRVL_AMG_MCS_PEX_RX_SLAVE;
		addrEnable += MRVL_AMG_MCS_PEX_RX_SLAVE;
	}

	if (index >= MRVL_AMG_MCS_MAX_CTRL_PCKT_COMBO_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		index = index;

		MRVL_AMG_MCS_ReadReg64(device, addr, &regVal64);
		for (i = 0; i < 6; i++)
		{
			classification->MIN_DA[5 - i] = (MRVL_APHY_U8)((regVal64 >> (i * 8)) & 0xFFU);
		}
		MRVL_AMG_MCS_ReadReg64(device, addr + 0x10, &regVal64);
		for (i = 0; i < 6; i++)
		{
			classification->MAX_DA[5 - i] = (MRVL_APHY_U8)((regVal64 >> (i * 8)) & 0xFFU);
		}

		MRVL_AMG_MCS_ReadReg32(device, addr + 0x20, &regVal);
		classification->ethType = (MRVL_APHY_U16)(regVal & 0xFFFFU);

		MRVL_AMG_MCS_ReadReg32(device, addrEnable, &regVal);
		if (0 == (regVal & (0x100000U << index)))
		{
			classification->isEnabled = MRVL_APHY_FALSE;
		}
		else
		{
			classification->isEnabled = MRVL_APHY_TRUE;
		}
	}

	return status;
}
