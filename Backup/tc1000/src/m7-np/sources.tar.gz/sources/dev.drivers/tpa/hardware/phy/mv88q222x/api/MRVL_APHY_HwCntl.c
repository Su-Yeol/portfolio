/**
 * @file MRVL_APHY_HwCntl.c
 * @brief APHY hardware control Source File for API interfacing with APHY and register
 * This is used for including system-dependent XMDIO/CL45 implementations in order to access PHY device.
 * Modify this file to add:
 * 		Catch return code (MRVL_APHY_STATUS)
 * 		Log/dump registers accesses
 *
 * @par Copyright and Version
 * See MRVL_Q222X_Copyright_and_Version.h
 */

#include "MRVL_APHY_HwCntl.h"

/**
 * @brief Read out a 16-bit value from a register through XMDIO interface.
 * A wrapper function for _MRVL_DEV readReg
 *
 * @param[in]	device   MRVL_DEV
 * @param[in]	portAddr phy/port address
 * @param[in]	devAddr  Device address
 * @param[in]	regAddr  Register address within section
 * @param[out]	data     Register value
 *
 * @ingroup Utility_Lib
 */
/* polyspace +1 CODE-METRICS:CALLING [Justified] "Deviation ASH-926" */
void mrvl_aphy_hwXmdioRead(MRVL_DEV_PTR device, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16* data)
{
	device->readReg(device, portAddr, devAddr, regAddr, data);
	/* Add logic to catch return code or log register */
}

/**
 * @brief Write a 16-bit value to a register through XMDIO interface.
 * A wrapper function for _MRVL_DEV writeReg
 *
 * @param[in]	device   MRVL_DEV
 * @param[in]	portAddr phy/port address
 * @param[in]	devAddr  Device address
 * @param[in]	regAddr  Register address within section
 * @param[in]	data     Register value
 *
 * @ingroup Utility_Lib
 */
/* polyspace +1 CODE-METRICS:CALLING [Justified] "Deviation ASH-926" */
void mrvl_aphy_hwXmdioWrite(MRVL_DEV_PTR device, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16 data)
{
	device->writeReg(device, portAddr, devAddr, regAddr, data);
	/* Add logic to catch return code or log register */
}

/**
 * @brief Delay for specified number of milliseconds.
 * A wrapper function for _MRVL_DEV wait
 *
 * @param[in]	device   MRVL_DEV
 * @param[in]	waitTime Milliseconds
 *
 * @ingroup Utility_Lib
 */
/* polyspace +1 CODE-METRICS:CALLING [Justified] "Deviation ASH-926" */
void mrvl_aphy_wait(MRVL_DEV_PTR device, MRVL_APHY_U16 waitTime)
{
	device->wait(device, waitTime);
	/* Add logic to catch return code or log wait time */
}
