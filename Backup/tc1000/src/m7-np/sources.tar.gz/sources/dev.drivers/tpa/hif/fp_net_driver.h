/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          fp_net_driver.h
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    contains cor data stryctures & defines of net driver
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

#ifndef _FP_NET_DRIVER_H_
#define _FP_NET_DRIVER_H_

#ifdef __linux__
#include <linux/netdevice.h>
#include <linux/pci.h>
#endif
#include "platform.h"

#define DRV_NAME "fp"

struct hif_chan {
	struct bd_ring *txring;
	struct bd_ring *rxring;
	//struct tasklet_struct tx_tasklet;
	//struct tasklet_struct rx_tasklet;
};

struct hif_base {
	struct hif_regs *regs;
	struct hif_chan ch[NUM_HIF_CHANNELS];
};

struct fp_private {
#ifdef __linux__
	volatile uint8 *pcimem_base; /* Memory mapped physical address */
#endif
	volatile struct hif_regs *mmio_addr; /* Memory mapped physical address */
#ifdef __linux__
	struct pci_dev  *pci_dev;            /* PCI device Index */
	struct net_device *dev;
#endif
	spinlock_t lock;                     /* Spin lock flag */
	spinlock_t rx_lock;                     /* Spin lock flag */
	struct hif_base  hif[NUM_TOTAL_HIF];
	//uint32a txq_stopped;
#ifdef __linux__
	struct net_device_stats netstats;
#endif
	uint32a   reset_bd;
	uint32a safety_reset_with_failstop;
	uint32a safety_reset_without_failstop;
	uint32a num_hif_rx_interrupts;
	uint32a num_hif_tx_interrupts;
	uint8 *ddr_va;
	uint32a   ddr_pa;
	uint8 *bmusec_buf_va;
	uint32a   bmusec_buf_pa;
	uint8 *llm_buf_va;
	uint32a   llm_buf_pa;
#ifdef HASH_ARR_EN
	uint8 *ddr_single_va;
	uint32a   ddr_single_pa;
#endif /*End of HASH_ARR_EN*/

};

// moved to AFTER the definition of fp_private
struct tasklet_data
{
	struct fp_private *fp;
	int32a ch_index;
	int32a hif_index;
};


//#define MIN_FRAME_SIZE 46

//#define MAX_BUF_ALLOCSIZE 2048

#ifdef DEBUG
#define DPRINTK(lvl, fmt, args...) printk(lvl fmt, ##args)
#else
#define DPRINTK(lvl, fmt, args...)
#endif

#define RX_LOOP_THRESH 16
#define ENABLE_HIF_INTERRUPTS 1
#define NFP_IFS  1
extern struct fp_private *fpGlobal;
void load_hwinit_config(uint32a peAddr, uint32a *data, uint32a len);
int32a fp_switch_init_timer(int32a init);
int32a fp_init_fastpath(void);
#ifdef __linux__
irqreturn_t fp_interrupt(int32a irq, void *dev);
#else
int32a fp_interrupt(void *fpHandle);
#endif
#ifdef __linux__
void fp_rx_tasklet(uint32 data);
#endif
void fp_tx_tasklet(uint32 data);
void fp_en_hif_rx_engine(struct fp_private *fp);
void fp_disable_interrupts(struct fp_private *fp);
#ifdef __linux__
int32a fp_net_xmit(struct sk_buff *skb, struct net_device *dev);
#else
int32a fp_net_xmit(uint8 *buffer, uint16 size);
#endif
int32a fp_hw_sw_init(void);
int32a fp_hw_vlantable_add(void);
#ifdef __linux__
int32a fp_net_release(struct net_device *dev);
extern const struct net_device_ops fp_netdev_ops;
extern struct ethtool_ops fp_ethtool_ops;
#endif
void fp_enable_interrupts(struct fp_private *fp);
#if 1//def __linux__
void fp_init_rx_tasklet(struct fp_private *fp);
void fp_init_tx_tasklet(struct fp_private *fp);
#endif

int32a fp_net_open(void);

int32a fp_receive_ethframe(void *fpHandle, uint8 *buffer, uint16 buffer_size);
int32a fp_send_ethframe(void *fpHandle, uint8 *buffer, uint16 size);

int32a fp_net_init(void);

#endif /* _fp_net_driver_*/
