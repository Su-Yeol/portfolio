/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          nc_conf.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    This file contains prototypes to handle fpath config
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifndef _NC_CONF_H_
#define _NC_CONF_H_

#include <linux/if_ether.h>

#include "fp_types.h"

/* table information data structure */
typedef struct nc_table_info_s {
	fp_table_type_t	 tbl_type;		/* table type */
	uint16	tbl_size;		/* table size */
	uint16	tbl_num_entries;	/* number of entries in this table */
	uint16	tbl_id;			/* table id */
	uint16	tbl_refcnt;		/* TODO: u_int16_t or u_in32_t ?? */
	/* TODO: add port info */
} nc_table_info_t;

typedef struct nc_router_entry_s {
	struct cacheFlow_s	*next;
	uint32a		valid;
	uint16		srcPort;
	uint16		dstPort;
	uint8		proto;
	uint8		inPhyPortNum;
	uint16		hash;
	union {
	 struct {
		uint32a	srcIP;
		uint32a	dstIP;
	 } v4;
	 struct {
		uint32a	src_ipv6[4];
		uint32a	dst_ipv6[4];
	 } v6;
	} u;
	uint8	entryState;
	uint8	phyPortNum; /* changed res1 to egr phy no as per hardware req */
	/* information updated by the Classifier */
	uint8	classNotifyFlags;
	uint8	ifPortNum; /*To represent phyport and interface port numbers*/
	/* header construction related infor */
	uint8	rcMacAddr[6];
	uint8	dstMacAddr[6];
	uint32a	flowActionFlags;
	uint16	pppoeSesId;
	uint16	vlanId;
	uint32a	chgSrcIP;
	uint32a	chgDstIP;
	uint16	chgSrcPort;
	uint16	chgDstPort;
	uint8	flag_ipv6;
	uint8	res1[3];
	uint32a	res[9];
	void		*res_next; /*Storing entry pointer in structure*/
} nc_router_entry_t;

#if 0
/* structure for router table entries */
typedef struct nc_router_entry_s {
	uint32a	srcIP;
	uint32a	dstIP;
	union {
		struct {
			uint16	srcPort;	/* src port for TCP/UDP packets */
			uint16	dstPort;	/* dst port for TCP/UDP packets */
		 } layer4Info;
		 uint16		fragId;		/* IP fragmentation id */
		 uint32a		spiIndex;	/* for IPSEC packets */
	} flowSpecific;
	uint32a	flowActionFlags;		/* FLOW Action flags */
	uint32a	chgSrcIP;
	uint32a	chgDstIP;
	uint32a	pktCount;			/* EXT */
	uint16	chgSrcPort;
	uint16	chgDstPort;
	uint8	proto;				/* IP protocol */
	uint8	chgRos;
	uint8	rsvd[2];
	/* IPV6 fields added */
	uint32a	src_ipv6[4];
	uint32a	dst_ipv6[4];
	uint8	flag_ipv6;
	uint8	res_ipv6;
	/* TODO Check if we need to upload the information on flags */
	uint8	srcMacAddr[ETH_ALEN];
	uint8	dstMacAddr[ETH_ALEN];
	uint16	hash;
	uint16	res1;
} nc_router_entry_t;
#endif

#define IF_NAME_LEN 10

/* structure for bridge table entries */
typedef struct nc_bridge_entry_s {
	uint32a	be_pktcount;			/* packet count */
	uint16	be_vlanid;			/* VLAN id */
	uint8	be_macaddr[ETH_ALEN];		/* MAC address */
	uint8	be_state;			/* entry state */
	uint32a	be_actions;			/* actions on this entry */
} nc_bridge_entry_t;

/* structure for vlan table entries */
typedef struct nc_vlan_entry_s {
	uint16	vlanid;		/* VLAN id */
	uint32a	fwd_port_list;	/* fwd port list */
	uint32a	untag_list;	/* untag list */
	uint8	ucast_hit_act;	/* ucast hit action */
	uint8	ucast_miss_act;	/* ucast miss action */
	uint8	mcast_hit_act;	/* mcast hit action */
	uint8	mcast_miss_act;	/* mcast miss action */
	uint8	mstp;		/* mstp */
} nc_vlan_entry_t;

/* data structure for port related information */
/* data structure for port related information */
typedef struct nc_port_info_s {
	uint32a	pidx;		/* port index */
	uint16	media_type;	/* media type */
	uint16	max_num_ifls;	/* max. number of ifls on this physical port */
	uint16	cur_num_ifls;	/* current number of ifls on this port */
	uint32a	rx_pkts;	/* rx packet count */
	uint32a	tx_pkts;	/* tx packet count */
} nc_port_info_t;

/* data structure for logical interface related information */
typedef struct nc_ifl_info_s {
	uint32a	pidx;		/* physical port index */
	uint32a	ifidx;		/* interface index */
	uint32a	opflags;	/* IF_ROUTE/IF_BRIDGE/IF_VLAN_BRIDGE modes */
	uint32a	rx_pkts;	/* rx packet count */
	uint32a	tx_pkts;	/* tx packet count */
	uint32a	iftype;		/* interface type */
	uint32a	ipaddr;		/* ip address, if any */
} nc_ifl_info_t;

#endif /*End of _FP_CONFIG_H_ File*/

