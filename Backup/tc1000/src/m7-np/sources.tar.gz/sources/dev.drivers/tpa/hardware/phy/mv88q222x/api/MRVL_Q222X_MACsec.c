/**
 * @file MRVL_Q222X_MACsec.c
 * @brief Q222X MACsec API Source File
 * DUT MACsec configuration and status checking
 *
 * @par Copyright and Version
 * See MRVL_Q222X_Copyright_and_Version.h
 */

#include "MRVL_Q222X_MACsec.h"


/******************************************************************************
 *      MACsec static function
 ******************************************************************************/

/**
 * @brief Calculate MACsec register address with register offset
 *
 * @param[in]	base   base register
 * @param[in]	index  offset index
 * @param[in]	range  offset width
 * @return MRVL_APHY_U16 register address
 *
 */
/* polyspace +1 CODE-METRICS:CALLING [Justified] "Deviation ASH-926" */
STATIC MRVL_APHY_U16 GETADDR(MRVL_APHY_U16 base, MRVL_APHY_U8 index, MRVL_APHY_U16 range)
{
	return base + range * index;
}

/* Set MACsec default settings during initialization */
STATIC void setMACsecDefaultSetting(MRVL_DEV_PTR device)
{
	MRVL_APHY_U32 regVal32;
	/* init MAC */
	q222x_readMACReg32(device, MRVL_Q222X_MSEC_SLC_CFG, &regVal32);
	q222x_writeMACReg32(device, MRVL_Q222X_MSEC_SLC_CFG, 0x42500f03U | (regVal32 & 0xCU));
	/* CFG_VLAN_ET register, IPG and scheduler enable related*/
	q222x_writeMACReg32(device, 0x8048U, 0x6529U);
	/* QOS_FC */
	q222x_writeMACReg32(device, 0x80a4U, 0x5U);
	/* QOS_ETHERTYPE */
	q222x_writeMACReg32(device, 0x80a6U, 0x88a88100U);
	/* SMC_MAC_PREEMPT_CTRL */
	q222x_writeMACReg32(device, 0x80deU, 0x400U);
	/* WMC_MAC_PREEMPT_CTRL */
	q222x_writeMACReg32(device, 0x80eaU, 0x400U);
	/* PAUSE control: close loop*/
	q222x_readMACReg32(device, 0x800eU, &regVal32);
	q222x_writeMACReg32(device, 0x800eU,((regVal32 & 0xFFFFFFF0U) | 0xaU));
	/* TX_PORT_CFG_0 register SECTAG_ETYPE */
	q222x_writeMACReg32(device, 0x199AU, MRVL_Q222X_MSEC_ETHTYPE);
	/* LINK_RESET_CFG */
	q222x_writeMACReg32(device, 0x80B2U, 0x3000000U);
}

/* Convert a unsigned value to MRVL_Q222X_MSEC_VALIDATEFRAME Enum */
STATIC void convert2ValidateFrameEnum(MRVL_APHY_U16 value, MRVL_Q222X_MSEC_VALIDATEFRAME *vf)
{
	if (0 == value)
	{
		*vf = MRVL_Q222X_MSEC_VF_DISABLED;
	}
	else if (0x1U ==value )
	{
		*vf = MRVL_Q222X_MSEC_VF_CHECK;
	}
	else if (0x2U == value)
	{
		*vf = MRVL_Q222X_MSEC_VF_STRICT;
	}
	else
	{
		/* other values are considered as MRVL_Q222X_MSEC_VF_NA */
		*vf = MRVL_Q222X_MSEC_VF_NA;
	}
}

/* Convert a unsigned value to MRVL_Q222X_MSEC_STRIP_SECTAG_ICV Enum */
STATIC void convert2StripSectagEnum(MRVL_APHY_U16 value, MRVL_Q222X_MSEC_STRIP_SECTAG_ICV *stripSectag)
{
	if (0 == value)
	{
		*stripSectag = MRVL_Q222X_MSEC_SECTAG_ICV_BOTH_STRIP;
	}
	else if (0x1U ==value )
	{
		*stripSectag = MRVL_Q222X_MSEC_SECTAG_ICV_RESERVED;
	}
	else if (0x2U == value)
	{
		*stripSectag = MRVL_Q222X_MSEC_SECTAG_ICV_STRIP_ICV_ONLY;
	}
	else
	{
		/* other values are considered as MRVL_Q222X_MSEC_SECTAG_ICV_NO_STRIP */
		*stripSectag = MRVL_Q222X_MSEC_SECTAG_ICV_NO_STRIP;
	}
}

/* Convert a unsigned value to MRVL_Q222X_MSEC_CIPHER_SUITE Enum */
STATIC MRVL_APHY_STATUS convert2CipherSuiteEnum(MRVL_APHY_U16 value, MRVL_Q222X_MSEC_CIPHER_SUITE *cipherSuite)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	if (0 == value)
	{
		*cipherSuite = MRVL_Q222X_MSEC_CIPHER_GCM_AES_128;
	}
	else if (0x1U ==value )
	{
		*cipherSuite = MRVL_Q222X_MSEC_CIPHER_GCM_AES_256;
	}
	else if (0x2U == value)
	{
		*cipherSuite = MRVL_Q222X_MSEC_CIPHER_GCM_AES_128_XPN;
	}
	else if (0x3U == value)
	{
		*cipherSuite = MRVL_Q222X_MSEC_CIPHER_GCM_AES_256_XPN;
	}
	else
	{
		/* report error */
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	return status;
}

/* Convert a unsigned value to MRVL_Q222X_MSEC_PACKET_TYPE Enum */
STATIC void convert2PacketTypeEnum(MRVL_APHY_U16 value, MRVL_Q222X_MSEC_PACKET_TYPE *packetType)
{
	switch (value)
	{
		case 0:
		{
			*packetType = MRVL_Q222X_MSEC_PACKET_NO_VLAN_OR_MPLS;
			break;
		}
		case 0x1U:
		{
			*packetType = MRVL_Q222X_MSEC_PACKET_SINGLE_VLAN;
			break;
		}
		case 0x2U:
		{
			*packetType = MRVL_Q222X_MSEC_PACKET_DUAL_VLAN;
			break;
		}
		case 0x3U:
		{
			*packetType = MRVL_Q222X_MSEC_PACKET_MPLS;
			break;
		}
		case 0x4U:
		{
			*packetType = MRVL_Q222X_MSEC_PACKET_SINGLE_VLAN_FOLLOW_BY_MPLS;
			break;
		}
		case 0x5U:
		{
			*packetType = MRVL_Q222X_MSEC_PACKET_DUAL_VLAN_FOLLOW_BY_MPLS;
			break;
		}
		default:
		{
			/* rest values are all considered as unsupported */
			*packetType = MRVL_Q222X_MSEC_PACKET_UNSUPPORTED_TYPE;
			break;
		}
	}
}

/**
 * @brief Read value from Rule(FLOWID_TCAM_DATA/MASK) register, and assign the value to array
 *
 * @param[in]	device       PHY pointer
 * @param[in]	baseAddrData FLOWID_TCAM_DATA or FLOWID_TCAM_MASK register base address
 * @param[out]	valArray     array to store data or mask
 * @return void
 *
 */
STATIC void readValConvert2RuleArray(MRVL_DEV_PTR device, MRVL_APHY_U16 baseAddrData, MRVL_APHY_U32 valArray[])
{

	MRVL_APHY_U64 regVal64 = 0;
	MRVL_APHY_U16 i = 0;
	for (i = 0; i < 8; i = i + 2)
	{
		/* Read back register value */
		q222x_readMACReg64(device, baseAddrData + MRVL_Q222X_MSEC_REG_BUS_WIDTH * i / 2, &regVal64);
		if (i < 6)
		{
			/* split 64bit value to 32bit array data */
			valArray[i] = (MRVL_APHY_U32)regVal64 & 0xFFFFFFFFU;
			valArray[i + 1] = (MRVL_APHY_U32)(regVal64 >> 32) & 0xFFFFFFFFU;
		}
		else
		{
			/* last one is 32bit valid */
			valArray[i] = (MRVL_APHY_U32)regVal64 & 0xFFFFFFFFU;
		}
	}
}

/**
 * @brief Convert to rule struct from array
 *
 * @param[in]	keyArray    Array to store data
 * @param[in]	maskArray   Array to store mask
 * @param[out]	rule        MACsec rule struct pointer
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void convert2RuleFromArray(MRVL_APHY_U32 keyArray[], MRVL_APHY_U32 maskArray[],  MRVL_Q222X_MSEC_RULE* rule)
{
	MRVL_APHY_U16 i = 0;
	/* assgin DA and SA values. each 6 bytpes */
	for (i = 0; i < 4; i++)
	{
		/* DA index 2 - 5 */
		rule->key_MAC_DA[i + 2] = (MRVL_APHY_U8)((keyArray[0] >> ((3 - i) * 8)) & 0xFFU);
		rule->mask_MAC_DA[i + 2] = (MRVL_APHY_U8)((maskArray[0] >> ((3 - i) * 8)) & 0xFFU);
	}
	for (i = 0; i < 2; i++)
	{
		/* DA index 0 and 1 */
		rule->key_MAC_DA[i] = (MRVL_APHY_U8)((keyArray[1] >> ((1 - i) * 8)) & 0xFFU);
		rule->mask_MAC_DA[i] = (MRVL_APHY_U8)((maskArray[1] >> ((1 - i) * 8)) & 0xFFU);
		/* SA index 4 and 5 */
		rule->key_MAC_SA[4 + i] = (MRVL_APHY_U8)((keyArray[1] >> ((3 - i) * 8)) & 0xFFU);
		rule->mask_MAC_SA[4 + i] = (MRVL_APHY_U8)((maskArray[1] >> ((3 - i) * 8)) & 0xFFU);
	}
	for (i = 0; i < 4; i++)
	{
		/* SA index 0 - 3 */
		rule->key_MAC_SA[i] = (MRVL_APHY_U8)((keyArray[2] >> ((3 - i) * 8)) & 0xFFU);
		rule->mask_MAC_SA[i] = (MRVL_APHY_U8)((maskArray[2] >> ((3 - i) * 8)) & 0xFFU);
	}
	/* assgin e types */
	rule->key_Ethertype = (MRVL_APHY_U16)(keyArray[3] & 0xFFFFU);
	rule->mask_Ethertype = (MRVL_APHY_U16)(maskArray[3] & 0xFFFFU);

	if (MRVL_APHY_TRUE == rule->isMPLS)
	{
		/* assgin mpls related */
		rule->key_outer1.mpls.MPLS_label = ((keyArray[3] >> 16) & 0xFFFFU) + ((keyArray[4] & 0xFU) << 16);
		rule->mask_outer1.mpls.MPLS_label = ((maskArray[3] >> 16) & 0xFFFFU) + ((maskArray[4] & 0xFU) << 16);
		rule->key_outer1.mpls.exp = (MRVL_APHY_U8)((keyArray[4] >> 4) & 0x7U);
		rule->mask_outer1.mpls.exp = (MRVL_APHY_U8)((maskArray[4] >> 4) & 0x7U);
		rule->key_outer2.mpls.MPLS_label = (keyArray[4] >> 8) & 0xFFFFFU;
		rule->mask_outer2.mpls.MPLS_label = (maskArray[4] >> 8) & 0xFFFFFU;
		rule->key_outer2.mpls.exp = (MRVL_APHY_U8)((keyArray[4] >> 28) & 0xFU);
		rule->mask_outer2.mpls.exp = (MRVL_APHY_U8)((maskArray[4] >> 28) & 0xFU);
	}
	else
	{
		/* assgin vlan related */
		rule->key_outer1.vlanTag.VID = (MRVL_APHY_U16)((keyArray[3] >> 16) & 0xFFFU);
		rule->mask_outer1.vlanTag.VID = (MRVL_APHY_U16)((maskArray[3] >> 16) & 0xFFFU);
		rule->key_outer1.vlanTag.PRI_CFI = (MRVL_APHY_U8)((keyArray[4] >> 4) & 0xFU);
		rule->mask_outer1.vlanTag.PRI_CFI = (MRVL_APHY_U8)((maskArray[4] >> 4) & 0xFU);
		rule->key_outer2.vlanTag.VID = (MRVL_APHY_U16)((keyArray[4] >> 8) & 0xFFFU);
		rule->mask_outer2.vlanTag.VID = (MRVL_APHY_U16)((maskArray[4] >> 8) & 0xFFFU);
		rule->key_outer2.vlanTag.PRI_CFI = (MRVL_APHY_U8)((keyArray[4] >> 28) & 0xFU);
		rule->mask_outer2.vlanTag.PRI_CFI = (MRVL_APHY_U8)((maskArray[4] >> 28) & 0xFU);
	}
	/* assgin bonus data, set custom tag */
	rule->key_bonus_data = (MRVL_APHY_U16)(keyArray[5] & 0xFFFFU);
	rule->mask_bonus_data = (MRVL_APHY_U16)(maskArray[5] & 0xFFFFU);
	/* assgin tag match, set custom tag */
	rule->key_tag_match_bitmap = (MRVL_APHY_U8)((keyArray[5] >> 16) & 0xFFU);
	rule->mask_tag_match_bitmap = (MRVL_APHY_U8)((maskArray[5] >> 16) & 0xFFU);
	/* assgin packet_type */
	convert2PacketTypeEnum((MRVL_APHY_U16)((keyArray[5] >> 24) & 0xFU), &(rule->key_packet_type));
	rule->mask_packet_type = (MRVL_APHY_U8)((maskArray[5] >> 24) & 0xFU);
	/* assgin vlan tag related */
	rule->key_outer_vlan_type = (MRVL_APHY_U16)((keyArray[5] >> 28) & 0x7U);
	rule->mask_outer_vlan_type = (MRVL_APHY_U16)((maskArray[5] >> 28) & 0x7U);
	rule->key_inner_vlan_type = (MRVL_APHY_U16)(((keyArray[5] >> 31) & 0x1U) + ((keyArray[6] & 0x3U) << 1));
	rule->mask_inner_vlan_type = (MRVL_APHY_U16)(((maskArray[5] >> 31) & 0x1U) + ((maskArray[6] & 0x3U) << 1));
	rule->key_num_tags = (MRVL_APHY_U8)((keyArray[6] >> 2) & 0x7FU);
	rule->mask_num_tags = (MRVL_APHY_U8)((maskArray[6] >> 2) & 0x7FU);
	/* assgin mpls related */
	rule->key_express = (MRVL_APHY_U8)((keyArray[6] >> 9) & 0x1U);
	rule->mask_express = (MRVL_APHY_U8)((maskArray[6] >> 9) & 0x1U);
}

/**
 * @brief Convert to one-dimensional arrays from MACsec rule struct
 *
 * @param[in]	rule        MACsec rule pointer
 * @param[out]	keyArray    Array to store data
 * @param[out]	maskArray   Array to store mask
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void convert2ArrayFromRule(MRVL_Q222X_MSEC_RULE* rule, MRVL_APHY_U32 keyArray[], MRVL_APHY_U32 maskArray[])
{
	MRVL_APHY_U16 i = 0;
	/* place DA and SA in array for later reg write */
	for (i = 0; i < 4; i++)
	{
		/* 32bit array[][0] stores DA 2 - 5, 4 bytes */
		keyArray[0] += (MRVL_APHY_U32)rule->key_MAC_DA[2 + i] << ((3 - i) * 8);
		maskArray[0] += (MRVL_APHY_U32)rule->mask_MAC_DA[2 + i] << ((3 - i) * 8);
	}
	for (i = 0; i < 2; i++)
	{
		/* 32bit array[][1] stores DA 0,1 and SA 4,5, 4 bytes */
		keyArray[1] += (MRVL_APHY_U32)rule->key_MAC_DA[i] << ((1 - i) * 8);
		maskArray[1] += (MRVL_APHY_U32)rule->mask_MAC_DA[i] << ((1 - i) * 8);
		keyArray[1] += (MRVL_APHY_U32)rule->key_MAC_SA[4 + i] << ((3 - i) * 8);
		maskArray[1] += (MRVL_APHY_U32)rule->mask_MAC_SA[4 + i] << ((3 - i) * 8);
	}
	for (i = 0; i < 4; i++)
	{
		/* 32bit array[][2] stores SA 0 - 3, 4 bytes */
		keyArray[2] += (MRVL_APHY_U32)rule->key_MAC_SA[i] << ((3 - i) * 8);
		maskArray[2] += (MRVL_APHY_U32)rule->mask_MAC_SA[i] << ((3 - i) * 8);
	}
	if (MRVL_APHY_TRUE == rule->isMPLS)
	{
		/* compose array[][3,4] with mpls settings */
		keyArray[3] = (MRVL_APHY_U32)rule->key_Ethertype + (((rule->key_outer1.mpls.MPLS_label & 0xFFFFFU) & 0xFFFFU) << 16);
		maskArray[3] = (MRVL_APHY_U32)rule->mask_Ethertype + (((rule->mask_outer1.mpls.MPLS_label & 0xFFFFFU) & 0xFFFFU) << 16);
		keyArray[4] = (((rule->key_outer1.mpls.MPLS_label & 0xFFFFFU) >> 16) & 0xFU)
							+ (((MRVL_APHY_U32)rule->key_outer1.mpls.exp & 0x7U) << 4)
							+ ((rule->key_outer2.mpls.MPLS_label & 0xFFFFFU) << 8)
							+ (((MRVL_APHY_U32)rule->key_outer2.mpls.exp & 0x7U) << 28);
		maskArray[4] = (((rule->mask_outer1.mpls.MPLS_label & 0xFFFFFU) >> 16) & 0xFU)
							+ (((MRVL_APHY_U32)rule->mask_outer1.mpls.exp & 0x7U) << 4)
							+ ((rule->mask_outer2.mpls.MPLS_label & 0xFFFFFU) << 8)
							+ (((MRVL_APHY_U32)rule->mask_outer2.mpls.exp & 0x7U) << 28);
	}
	else
	{
		/* compose array[][3,4] with vlan settings */
		keyArray[3] = (MRVL_APHY_U32)rule->key_Ethertype + ((((MRVL_APHY_U32)rule->key_outer1.vlanTag.VID & 0xFFFU) & 0xFFFU) << 16);
		maskArray[3] = (MRVL_APHY_U32)rule->mask_Ethertype + ((((MRVL_APHY_U32)rule->mask_outer1.vlanTag.VID & 0xFFFU) & 0xFFFU) << 16) + ((MRVL_APHY_U32)0xFU << 28);
		keyArray[4] = (((MRVL_APHY_U32)rule->key_outer1.vlanTag.PRI_CFI & 0xFU) << 4)
							+ ((((MRVL_APHY_U32)rule->key_outer2.vlanTag.VID & 0xFFFU)) << 8)
							+ (((MRVL_APHY_U32)rule->key_outer2.vlanTag.PRI_CFI & 0xFU) << 28);
		maskArray[4] = 0xFU + (((MRVL_APHY_U32)rule->mask_outer1.vlanTag.PRI_CFI & 0xFU) << 4)
							+ (((MRVL_APHY_U32)rule->mask_outer2.vlanTag.VID & 0xFFFU) << 8)
							+ ((MRVL_APHY_U32)0xFFU << 20)
							+ (((MRVL_APHY_U32)rule->mask_outer2.vlanTag.PRI_CFI & 0xFU) << 28);
	}
	/* compose array[][5,6] with custom tag settings */
	keyArray[5] = ((MRVL_APHY_U32)rule->key_bonus_data & 0xFFFFU)
						+ (((MRVL_APHY_U32)rule->key_tag_match_bitmap & 0xFFU) << 16)
						+ (((MRVL_APHY_U32)rule->key_packet_type & 0xFU) << 24)
						+ (((MRVL_APHY_U32)rule->key_outer_vlan_type & 0x7U) << 28)
						+ ((((MRVL_APHY_U32)rule->key_inner_vlan_type & 0x7U) & 1U) << 31);
	maskArray[5] = ((MRVL_APHY_U32)rule->mask_bonus_data & 0xFFFFU)
						+ (((MRVL_APHY_U32)rule->mask_tag_match_bitmap & 0xFFU) << 16)
						+ (((MRVL_APHY_U32)rule->mask_packet_type & 0xFU) << 24)
						+ (((MRVL_APHY_U32)rule->mask_outer_vlan_type & 0x7U) << 28)
						+ ((((MRVL_APHY_U32)rule->mask_inner_vlan_type & 0x7U) & 1U) << 31);
	keyArray[6] = ((((MRVL_APHY_U32)rule->key_inner_vlan_type & 0x7U) >> 1) & 0x3U)
						+ (((MRVL_APHY_U32)rule->key_num_tags & 0x7FU) << 2)
						+ (((MRVL_APHY_U32)rule->key_express & 0x1U) << 9);
	maskArray[6] = ((((MRVL_APHY_U32)rule->mask_inner_vlan_type & 0x7U) >> 1) & 0x3U)
						+ (((MRVL_APHY_U32)rule->mask_num_tags & 0x7FU) << 2)
						+ (((MRVL_APHY_U32)rule->mask_express & 0x1U) << 9)
						+ ((MRVL_APHY_U32)0x3FFFFFU << 10);
}

/* Write value to FLOWID_TCAM_DATA or FLOWID_TCAM_MASK register from array */
STATIC void writeValFromRuleArray(MRVL_DEV_PTR device, MRVL_APHY_U16 baseAddrData, MRVL_APHY_U32 valArray[], MRVL_APHY_BOOL isMaskSetting)
{
	MRVL_APHY_U64 regVal64 = 0;
	MRVL_APHY_U16 regAddr = 0, i = 0;
	for (i = 0; i < 6; i = i + 2)
	{
		/* compose 64bit value from 32bit key array */
		regVal64 = valArray[i] | ((MRVL_APHY_U64)valArray[i + 1] << 32);
		regAddr = baseAddrData + MRVL_Q222X_MSEC_REG_BUS_WIDTH * i / 2;
		/* write 64bit value */
		q222x_writeMACReg64(device, regAddr, regVal64);
	}
	regAddr = baseAddrData + MRVL_Q222X_MSEC_REG_BUS_WIDTH * 3;
	if(MRVL_APHY_TRUE == isMaskSetting)
	{
		/* in MASK reg, need to set high 32bit to 1*/
		q222x_writeMACReg64(device, regAddr, 0xFFFFFFFF00000000U | valArray[6]);
	}
	else
	{
		/* the last 64bit reg value has valid 32bit */
		q222x_writeMACReg64(device, regAddr, valArray[6]);
	}
}

/* Compose a 64bit value from array */
STATIC MRVL_APHY_U64 compose64BitValFromArrayBigEnd(MRVL_APHY_U16 startIndex, MRVL_APHY_U8 valArray[])
{
	MRVL_APHY_U64 regVal = 0;
	regVal  = (MRVL_APHY_U64)valArray[startIndex + 7];
	regVal |= (MRVL_APHY_U64)valArray[startIndex + 6] << 8;
	regVal |= (MRVL_APHY_U64)valArray[startIndex + 5] << 16;
	regVal |= (MRVL_APHY_U64)valArray[startIndex + 4] << 24;
	regVal |= (MRVL_APHY_U64)valArray[startIndex + 3] << 32;
	regVal |= (MRVL_APHY_U64)valArray[startIndex + 2] << 40;
	regVal |= (MRVL_APHY_U64)valArray[startIndex + 1] << 48;
	regVal |= (MRVL_APHY_U64)valArray[startIndex]     << 56;
	return regVal;
}

/* Decompose a 64bit value to 8 one-byte value and assgin to array */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void decompose64BitVal2ArrayBigEnd(MRVL_APHY_U64 value, MRVL_APHY_U16 startIndex, MRVL_APHY_U8 valArray[])
{
	valArray[startIndex + 7] = (MRVL_APHY_U8)((value >> 0) & 0xFFU);
	valArray[startIndex + 6] = (MRVL_APHY_U8)((value >> 8) & 0xFFU);
	valArray[startIndex + 5] = (MRVL_APHY_U8)((value >> 16) & 0xFFU);
	valArray[startIndex + 4] = (MRVL_APHY_U8)((value >> 24) & 0xFFU);
	valArray[startIndex + 3] = (MRVL_APHY_U8)((value >> 32) & 0xFFU);
	valArray[startIndex + 2] = (MRVL_APHY_U8)((value >> 40) & 0xFFU);
	valArray[startIndex + 1] = (MRVL_APHY_U8)((value >> 48) & 0xFFU);
	valArray[startIndex]     = (MRVL_APHY_U8)((value >> 56) & 0xFFU);
}

/**
 * @brief Write SAK value to register
 *
 * @param[in]	device   PHY pointer
 * @param[in]	baseAddr SA policy register base address
 * @param[in]	sak      SAK array
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void writeSAKValue(MRVL_DEV_PTR device, MRVL_APHY_U16 baseAddr, MRVL_APHY_U8 sak[])
{
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 i = 0;

	for (i = 4; i >= 1; --i)
	{
		/* compose every 64bit value from array */
		regVal = compose64BitValFromArrayBigEnd((i - 1) * 8U, sak);
		/* write the value to register */
		q222x_writeMACReg64(device, baseAddr + (4 - i) * 4U, regVal);
	}
}

/**
 * @brief Write Hash key value to register
 *
 * @param[in]	device    PHY pointer
 * @param[in]	baseAddr  SA policy register base address
 * @param[in]	hashKey   Hash key array
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void writeHashValue(MRVL_DEV_PTR device, MRVL_APHY_U16 baseAddr, MRVL_APHY_U8 hashKey[])
{
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 i = 0;
	MRVL_APHY_U16 hashKeyRegAddr = baseAddr + 16;  /* hash key register address */

	for (i = 2; i >= 1; --i)
	{
		/* compose every 64bit value from array */
		regVal = compose64BitValFromArrayBigEnd((i - 1) * 8U, hashKey);
		/* write the value to register */
		q222x_writeMACReg64(device, hashKeyRegAddr + (2 - i) * 4U, regVal);
	}
}

/**
 * @brief Write Salt and SSCI value to register
 *
 * @param[in]	device   PHY pointer
 * @param[in]	baseAddr SA policy register base address
 * @param[in]	ssci     SSCI value
 * @param[in]	salt     Salt array
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void writeSaltAndSSCIValue(MRVL_DEV_PTR device, MRVL_APHY_U16 baseAddr, MRVL_APHY_U32 ssci, MRVL_APHY_U8 salt[])
{
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 saltRegAddr = baseAddr + 24;  /* salt register address */
	/* compose 64bit value from array */
	regVal = ((MRVL_APHY_U64)salt[4]) << 24;
	regVal |= ((MRVL_APHY_U64)salt[5]) << 16;
	regVal |= ((MRVL_APHY_U64)salt[6]) << 8;
	regVal |= ((MRVL_APHY_U64)salt[7]);
	regVal <<= 32;
	regVal |= (MRVL_APHY_U64)salt[8] << 24;
	regVal |= ((MRVL_APHY_U64)salt[9]) << 16;
	regVal |= ((MRVL_APHY_U64)salt[10]) << 8;
	regVal |= ((MRVL_APHY_U64)salt[11]);
	/* write the value to register */
	q222x_writeMACReg64(device, saltRegAddr, regVal);
	/* compose another 64bit value from array */
	regVal = ((MRVL_APHY_U64)ssci) << 32;
	regVal |= ((MRVL_APHY_U64)salt[0]) << 24;
	regVal |= ((MRVL_APHY_U64)salt[1]) << 16;
	regVal |= ((MRVL_APHY_U64)salt[2]) << 8;
	regVal |= ((MRVL_APHY_U64)salt[3]);
	/* write the value to register */
	q222x_writeMACReg64(device, saltRegAddr + 4, regVal);
}

/**
 * @brief Write SecTag Association Number(AN)
 *
 * @param[in]	device   PHY pointer
 * @param[in]	baseAddr SA policy register base address
 * @param[in]	secTagAN SecTag Association Number
 * @return void
 */
STATIC void writeSecTagANValue(MRVL_DEV_PTR device, MRVL_APHY_U16 baseAddr, MRVL_APHY_U64 secTagAN)
{
	MRVL_APHY_U16 sectagANRegAddr = baseAddr + 32U;  /* SecTag AN register address */

	/* write AN to register */
	q222x_writeMACReg64(device, sectagANRegAddr, secTagAN);
}

/**
 * @brief Read SAK value from register, assign value to array
 *
 * @param[in]	device   PHY pointer
 * @param[in]	baseAddr SA policy register base address
 * @param[out]	sak      SAK array
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void readValConvert2SAK(MRVL_DEV_PTR device, MRVL_APHY_U16 baseAddr, MRVL_APHY_U8 sak[])
{
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 i = 0;

	for (i = 4; i >= 1; --i)
	{
		/* readback value from reg */
		q222x_readMACReg64(device, baseAddr + (4 - i) * 4, &regVal);
		/* decompose 64bit value 2 array */
		decompose64BitVal2ArrayBigEnd(regVal, (i - 1) * 8, sak);
	}
}

/**
 * @brief Read hash key value from register, assign value to array
 *
 * @param[in]	device    PHY pointer
 * @param[in]	baseAddr  SA policy register base address
 * @param[out]	hashKey   Hash key array
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void readValConvert2Hash(MRVL_DEV_PTR device, MRVL_APHY_U16 baseAddr, MRVL_APHY_U8 hashKey[])
{
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 i = 0;
	MRVL_APHY_U16 hashKeyRegAddr = baseAddr + 16;  /* hash key register address */

	for (i = 2; i >= 1; --i)
	{
		/* readback value from reg */
		q222x_readMACReg64(device, hashKeyRegAddr + (2 - i) * 4, &regVal);
		/* decompose 64bit value 2 array */
		decompose64BitVal2ArrayBigEnd(regVal, (i - 1) * 8, hashKey);
	}
}

/**
 * @brief Read Salt and SSCI value from register, assign value to array and pointer
 *
 * @param[in]	device   PHY pointer
 * @param[in]	baseAddr SA policy register base address
 * @param[out]	ssci     SSCI value pointer
 * @param[out]	salt     Salt array
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void readValConvert2SaltSSCI(MRVL_DEV_PTR device, MRVL_APHY_U16 baseAddr, MRVL_APHY_U32* ssci, MRVL_APHY_U8 salt[])
{
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 saltRegAddr = baseAddr + 24;    /* salt register address */
	q222x_readMACReg64(device, saltRegAddr, &regVal);
	/* big endian, assign value in reverse order */
	salt[4] = (MRVL_APHY_U8)((regVal >> 56) & 0xFFU);
	salt[5] = (MRVL_APHY_U8)((regVal >> 48) & 0xFFU);
	salt[6] = (MRVL_APHY_U8)((regVal >> 40) & 0xFFU);
	salt[7] = (MRVL_APHY_U8)((regVal >> 32) & 0xFFU);
	salt[8] = (MRVL_APHY_U8)((regVal >> 24) & 0xFFU);
	salt[9] = (MRVL_APHY_U8)((regVal >> 16) & 0xFFU);
	salt[10] = (MRVL_APHY_U8)((regVal >> 8) & 0xFFU);
	salt[11] = (MRVL_APHY_U8)((regVal) & 0xFFU);
	q222x_readMACReg64(device, saltRegAddr + 4, &regVal);
	salt[0] = (MRVL_APHY_U8)((regVal >> 24) & 0xFFU);
	salt[1] = (MRVL_APHY_U8)((regVal >> 16) & 0xFFU);
	salt[2] = (MRVL_APHY_U8)((regVal >> 8) & 0xFFU);
	salt[3] = (MRVL_APHY_U8)((regVal) & 0xFFU);
	*ssci = (MRVL_APHY_U32)((regVal >> 32) & 0xFFFFFFFFU);
}

/**
 * @brief Read SecTag Association Number(AN)
 *
 * @param[in]	device   PHY pointer
 * @param[in]	baseAddr SA policy register base address
 * @param[out]	secTagAN SecTag Association Number pointer
 * @return void
 */
STATIC void readSecTagANValue(MRVL_DEV_PTR device, MRVL_APHY_U16 baseAddr, MRVL_APHY_U64 *secTagAN)
{
	MRVL_APHY_U16 sectagANRegAddr = baseAddr + 32U;  /* SecTag AN register address */

	/* read AN */
	q222x_readMACReg64(device, sectagANRegAddr, secTagAN);
}

/**
 * @brief Get Get the Rx SecY counters: common, controlled port and uncontrolled port counters
 *
 * @param[in]		device PHY pointer
 * @param[in]		index  SecY index
 * @param[in,out]	stats  MRVL_Q222X_MSEC_RX_SECY_COUNTER struct
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void getRxSecYStatsAllCounter(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_RX_SECY_COUNTER* stats)
{
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 regAddr = 0;
	/* read decrepted octets cnt */
	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_OCETS_SECY_DECRYPTED, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inOctetsSecYDecrypted = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	/* read validated octets cnt */
	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_OCETS_SECY_VALIDATE, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inOctetsSecYValidate = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	/* read SCI is unknown packets cnt */
	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_PKTS_SECY_NO_SA, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inPktsSecYNoSA = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	/* read unknown SA packets cnt */
	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_PKTS_SECY_NO_SA_ERROR, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inPktsSecYNoSAError = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	/* read invalid packets cnt */
	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_PKTS_SECY_BAD_TAG, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inPktsSecYBadTag = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	/* read without a SecTag packets cnt */
	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_PKTS_SECY_NO_TAG, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inPktsSecYNoTag = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	/* read without a SecTag packets cnt */
	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_PKTS_SECY_UNTAGGED, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inPktsSecYUntagged = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	/* read disabled packets cnt */
	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_PKTS_CTRL_PORT_DISABLE, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inPktsCtrlPortDisable = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;

	/* controlled port counters */
	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_CTRL_PORT_OCETS, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inCtrlPortOctets = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_CTRL_PORT_UC_PKTS, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inCtrlPortUCPkts = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_CTRL_PORT_MC_PKTS, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inCtrlPortMCPkts = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_CTRL_PORT_BC_PKTS, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inCtrlPortBCPkts = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;

	/* uncontrolled port counters */
	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_UNCTRL_PORT_OCETS, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inUnCtrlPortOctets = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_UNCTRL_PORT_UC_PKTS, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inUnCtrlPortUCPkts = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_UNCTRL_PORT_MC_PKTS, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inUnCtrlPortMCPkts = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_UNCTRL_PORT_BC_PKTS, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inUnCtrlPortBCPkts = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
}

/**
 * @brief Get the Tx SecY counters: common, controlled port and uncontrolled port counters
 *
 * @param[in]		device PHY pointer
 * @param[in]		index  SecY index
 * @param[in,out]	stats  MRVL_Q222X_MSEC_TX_SECY_COUNTER struct
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void getTxSecYStatsAllCounter(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_TX_SECY_COUNTER* stats)
{
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 regAddr = 0;
	/* The number of packets received on disabled SecY. */
	regAddr = GETADDR(MRVL_Q222X_MSEC_OUT_PKTS_CTRL_PORT_DISABLE, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->outPktsCtrlPortDisable = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	/* The number of packets without a SecTag */
	regAddr = GETADDR(MRVL_Q222X_MSEC_OUT_PKTS_SECY_UNTAGGED, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->outPktsSecYUntagged = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	/* The number of packets without matching SA */
	regAddr = GETADDR(MRVL_Q222X_MSEC_OUT_PKTS_SECY_NO_ACTIVE_SA, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->outPktsSecYNoActiveSA = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	/* The number of packets too long */
	regAddr = GETADDR(MRVL_Q222X_MSEC_OUT_PKTS_SECY_TOO_LONG, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->outPktSecYTooLong = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	/* The number of octets integrity protected but not encrypted */
	regAddr = GETADDR(MRVL_Q222X_MSEC_OUT_OCETS_SECY_PROTECTED, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->outOCTETSSecYProtected = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	/* The number of octets integrity protected and encrypted */
	regAddr = GETADDR(MRVL_Q222X_MSEC_OUT_OCETS_SECY_ENCRYPTED, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->outOCTETSSecYEncrypted = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;

	/* controlled port counters */
	regAddr = GETADDR(MRVL_Q222X_MSEC_OUT_CTRL_PORT_OCETS, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->outCtrlPortOctets = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	regAddr = GETADDR(MRVL_Q222X_MSEC_OUT_CTRL_PORT_UC_PKTS, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->outCtrlPortUCPkts = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	regAddr = GETADDR(MRVL_Q222X_MSEC_OUT_CTRL_PORT_MC_PKTS, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->outCtrlPortMCPkts = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	regAddr = GETADDR(MRVL_Q222X_MSEC_OUT_CTRL_PORT_BC_PKTS, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->outCtrlPortBCPkts = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;

	/* uncontrolled port counters */
	regAddr = GETADDR(MRVL_Q222X_MSEC_OUT_UNCTRL_PORT_OCETS, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->outUnCtrlPortOctets = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	regAddr = GETADDR(MRVL_Q222X_MSEC_OUT_UNCTRL_PORT_UC_PKTS, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->outUnCtrlPortUCPkts = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	regAddr = GETADDR(MRVL_Q222X_MSEC_OUT_UNCTRL_PORT_MC_PKTS, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->outUnCtrlPortMCPkts = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	regAddr = GETADDR(MRVL_Q222X_MSEC_OUT_UNCTRL_PORT_BC_PKTS, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->outUnCtrlPortBCPkts = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
}

/**
 * @brief Get SMC Rx Statistics: all mayor counters
 *
 * @param[in]		device PHY pointer
 * @param[in,out]	stats  SMC Rx Stats
 * @return MRVL_APHY_STATUS
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void getRxSMCStatsAllCounter(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_RX_SMC_STATS* stats)
{
	MRVL_APHY_U64 regVal;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_RX_STATS_GOODOCTETS, &regVal);
	stats->goodOctets = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_RX_STATS_ERROROCTETS, &regVal);
	stats->errorOctets = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_RX_STATS_JABBER, &regVal);
	stats->jabber = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_RX_STATS_FRAGMENT, &regVal);
	stats->fragment = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_RX_STATS_UNDERSIZE, &regVal);
	stats->undersize = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_RX_STATS_OVERSIZE, &regVal);
	stats->oversize = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_RX_STATS_RXERROR, &regVal);
	stats->rxError = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_RX_STATS_CRCERR_TXUNDERRUN, &regVal);
	stats->crcErrTxUnderrun = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_RX_STATS_RXOVERRUN_BADFC, &regVal);
	stats->rxOverrunBadFC = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_RX_STATS_GOODPKTS, &regVal);
	stats->goodPkts = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_RX_STATS_FCPKT, &regVal);
	stats->fcPkts = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_RX_STATS_BROADCAST, &regVal);
	stats->broadcast = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_RX_STATS_MULTICAST, &regVal);
	stats->multicast = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	/*  in-direction counters */
	q222x_readMACReg64(device, MRVL_Q222X_SMAC_RX_STATS_INPASSEMBLYERR, &regVal);
	stats->inPAssemblyErr = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_RX_STATS_INPFRAMES, &regVal);
	stats->inPFrames = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_RX_STATS_INPFRAGS, &regVal);
	stats->inPFrags = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_RX_STATS_INPBADFRAGS, &regVal);
	stats->inPBadFrags = regVal & MRVL_Q222X_COUNTERMASK_MMAC;
}

/**
 * @brief Get SMC Tx Statistics: all mayor counters
 *
 * @param[in]		device PHY pointer
 * @param[in,out]	stats  SMC Tx Stats
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void getTxSMCStatsAllCounter(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_TX_SMC_STATS* stats)
{
	MRVL_APHY_U64 regVal;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_TX_STATS_GOODOCTETS, &regVal);
	stats->goodOctets = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_TX_STATS_ERROROCTETS, &regVal);
	stats->errorOctets = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_TX_STATS_JABBER, &regVal);
	stats->jabber = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_TX_STATS_FRAGMENT, &regVal);
	stats->fragment = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_TX_STATS_UNDERSIZE, &regVal);
	stats->undersize = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_TX_STATS_OVERSIZE, &regVal);
	stats->oversize = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_TX_STATS_RXERROR, &regVal);
	stats->rxError = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_TX_STATS_CRCERR_TXUNDERRUN, &regVal);
	stats->crcErrTxUnderrun = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_TX_STATS_RXOVERRUN_BADFC, &regVal);
	stats->rxOverrunBadFC = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_TX_STATS_GOODPKTS, &regVal);
	stats->goodPkts = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_TX_STATS_FCPKT, &regVal);
	stats->fcPkts = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_TX_STATS_BROADCAST, &regVal);
	stats->broadcast = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_TX_STATS_MULTICAST, &regVal);
	stats->multicast = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	/*  out-direction counters */
	q222x_readMACReg64(device, MRVL_Q222X_SMAC_TX_STATS_OUTPFRAGS, &regVal);
	stats->outPFrags = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_SMAC_TX_STATS_OUTPFRAMES, &regVal);
	stats->outPFrames = regVal & MRVL_Q222X_COUNTERMASK_MMAC;
}

/**
 * @brief Get WMC Rx Statistics: all mayor counters
 *
 * @param[in]		device PHY pointer
 * @param[in,out]	stats  WMC Rx Stats
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void getRxWMCStatsAllCounter(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_RX_WMC_STATS* stats)
{
	MRVL_APHY_U64 regVal;
	q222x_readMACReg64(device, MRVL_Q222X_WMAC_RX_STATS_PKTS, &regVal);
	stats->pkts = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_RX_STATS_DROPPEDPKTS, &regVal);
	stats->droppedPkts = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_RX_STATS_OCTETS, &regVal);
	stats->octets = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_RX_STATS_JABBER, &regVal);
	stats->jabber = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_RX_STATS_FRAGMENT, &regVal);
	stats->fragment = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_RX_STATS_UNDERSIZE, &regVal);
	stats->undersize = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_RX_STATS_RXERROR, &regVal);
	stats->rxError = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_RX_STATS_CRCERROR, &regVal);
	stats->crcError = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_RX_STATS_FCPKTS, &regVal);
	stats->fcPkts = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_RX_STATS_BROADCASTPKTS, &regVal);
	stats->broadcast = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_RX_STATS_MULTICASTPKTS, &regVal);
	stats->multicast = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	/* in-direction counters */
	q222x_readMACReg64(device, MRVL_Q222X_WMAC_RX_STATS_INPASSEMBLYERR, &regVal);
	stats->inPAssemblyErr = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_RX_STATS_INPFRAMES, &regVal);
	stats->inPFrames = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_RX_STATS_INPFRAGS, &regVal);
	stats->inPFrags = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_RX_STATS_INPBADFRAGS, &regVal);
	stats->inPBadFrags = regVal & MRVL_Q222X_COUNTERMASK_MMAC;
}

/**
 * @brief Get WMC Tx Statistics: all mayor counters
 *
 * @param[in]		device PHY pointer
 * @param[in,out]	stats  WMC Tx Stats
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void getTxWMCStatsAllCounter(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_TX_WMC_STATS* stats)
{
	MRVL_APHY_U64 regVal;
	q222x_readMACReg64(device, MRVL_Q222X_WMAC_TX_STATS_PKTS, &regVal);
	stats->pkts = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_TX_STATS_DROPPEDPKTS, &regVal);
	stats->droppedPkts = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_TX_STATS_OCTETS, &regVal);
	stats->octets = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_TX_STATS_JABBER, &regVal);
	stats->jabber = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_TX_STATS_FRAGMENT, &regVal);
	stats->fragment = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_TX_STATS_UNDERSIZE, &regVal);
	stats->undersize = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_TX_STATS_RXERROR, &regVal);
	stats->rxError = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_TX_STATS_CRCERROR, &regVal);
	stats->crcError = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_TX_STATS_FCPKTS, &regVal);
	stats->fcPkts = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_TX_STATS_BROADCASTPKTS, &regVal);
	stats->broadcast = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_TX_STATS_MULTICASTPKTS, &regVal);
	stats->multicast = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	/* out-direction counters */
	q222x_readMACReg64(device, MRVL_Q222X_WMAC_TX_STATS_OUTPFRAGS, &regVal);
	stats->outPFrags = regVal & MRVL_Q222X_COUNTERMASK_MMAC;

	q222x_readMACReg64(device, MRVL_Q222X_WMAC_TX_STATS_OUTPFRAMES, &regVal);
	stats->outPFrames = regVal & MRVL_Q222X_COUNTERMASK_MMAC;
}

/**
 * @brief Get RX SC Statistics: all mayor counters
 *
 * @param[in]		device PHY pointer
 * @param[in]		index  SC index
 * @param[in,out]	stats  Rx SC Stats
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void getRxSCStatsAllCounter(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_RX_SC_COUNTER* stats)
{
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 regAddr = 0;
	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_PKTS_SC_CAM_HIT, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inPktsSCCamHit = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;

	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_PKTS_SC_LATE, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inPktsSCLate = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;

	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_PKTS_SC_NOT_VALID, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inPktsSCNotValid = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;

	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_PKTS_SC_INVALID, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inPktsSCInvalid = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;

	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_PKTS_SC_DELAYED, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inPktsSCDelayed = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;

	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_PKTS_SC_UNCHECKED, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inPktsSCUnchecked = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;

	regAddr = GETADDR(MRVL_Q222X_MSEC_IN_PKTS_SC_OK, index, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg64(device, regAddr, &regVal);
	stats->inPktsSCOK = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
}

/**
 * @brief read back 4 SA used in Rx SC
 *
 * @param[in]		device    PHY pointer
 * @param[in]		rxscIndex index
 * @param[in,out]	rxSC      MRVL_Q222X_MSEC_RX_SC struct
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void get4SAInRxSC(MRVL_DEV_PTR device, MRVL_APHY_U8 rxscIndex, MRVL_Q222X_MSEC_RX_SC* rxSC)
{
	MRVL_APHY_U32 regVal32 = 0;
	MRVL_APHY_U16 BaseAddr_rx_saMap = 0;
	BaseAddr_rx_saMap = GETADDR(MRVL_Q222X_MSEC_RX_SA_MAP_MEM, rxscIndex, MRVL_Q222X_MSEC_RANGE32);
	/* SA index value from index 0 */
	q222x_readMACReg32(device, BaseAddr_rx_saMap, &regVal32);
	rxSC->sa_index0 = (MRVL_APHY_U8)(regVal32 & 0x7U);
	rxSC->sa_index0_in_use = (0 == ((regVal32 >> 3) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
	/* SA index value from index 1 */
	q222x_readMACReg32(device, BaseAddr_rx_saMap + MRVL_Q222X_MSEC_REG_BUS_WIDTH, &regVal32);
	rxSC->sa_index1 = (MRVL_APHY_U8)(regVal32 & 0x7U);
	rxSC->sa_index1_in_use = (0 == ((regVal32 >> 3) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
	/* SA index value from index 2 */
	q222x_readMACReg32(device, BaseAddr_rx_saMap + MRVL_Q222X_MSEC_REG_BUS_WIDTH*2, &regVal32);
	rxSC->sa_index2 = (MRVL_APHY_U8)(regVal32 & 0x7U);
	rxSC->sa_index2_in_use = (0 == ((regVal32 >> 3) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
	/* SA index value from index 3 */
	q222x_readMACReg32(device, BaseAddr_rx_saMap + MRVL_Q222X_MSEC_REG_BUS_WIDTH*3, &regVal32);
	rxSC->sa_index3 = (MRVL_APHY_U8)(regVal32 & 0x7U);
	rxSC->sa_index3_in_use = (0 == ((regVal32 >> 3) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
}

/**
 * @brief set 4 SA settings per selected SC
 *
 * @param[in]	device    PHY pointer
 * @param[in]	rxSC      MRVL_Q222X_MSEC_RX_SC struct
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void set4SAInRxSC(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_RX_SC* rxSC)
{
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U16 BaseAddr_rx_saMap;
	BaseAddr_rx_saMap = GETADDR(MRVL_Q222X_MSEC_RX_SA_MAP_MEM, rxSC->index, MRVL_Q222X_MSEC_RANGE32);
	/* 4 SA per SC */
	/* SA index value for index 0 */
	regVal = (MRVL_APHY_U32)rxSC->sa_index0 & 0x7U;
	if (MRVL_APHY_TRUE == rxSC->sa_index0_in_use)
	{
		/* The SA is in use */
		regVal |= (MRVL_APHY_U32)1U << 3;
	}
	else
	{
		/* The SA is not in use */
		regVal &= ~((MRVL_APHY_U32)1U << 3);
	}
	q222x_writeMACReg32(device, BaseAddr_rx_saMap, regVal);

	/* SA index value for index 1 */
	regVal = (MRVL_APHY_U32)rxSC->sa_index1 & 0x7U;
	if (MRVL_APHY_TRUE == rxSC->sa_index1_in_use)
	{
		/* The SA is in use */
		regVal |= (MRVL_APHY_U32)1U << 3;
	}
	else
	{
		/* The SA is not in use */
		regVal &= ~((MRVL_APHY_U32)1U << 3);
	}
	q222x_writeMACReg32(device, BaseAddr_rx_saMap + MRVL_Q222X_MSEC_REG_BUS_WIDTH, regVal);

	/* SA index value for index 2 */
	regVal = (MRVL_APHY_U32)rxSC->sa_index2 & 0x7U;
	if (MRVL_APHY_TRUE == rxSC->sa_index2_in_use)
	{
		/* The SA is in use */
		regVal |= (MRVL_APHY_U32)1U << 3;
	}
	else
	{
		/* The SA is not in use */
		regVal &= ~((MRVL_APHY_U32)1U << 3);
	}
	q222x_writeMACReg32(device, BaseAddr_rx_saMap + MRVL_Q222X_MSEC_REG_BUS_WIDTH*2, regVal);

	/* SA index value for index 3 */
	regVal = (MRVL_APHY_U32)rxSC->sa_index3 & 0x7U;
	if (MRVL_APHY_TRUE == rxSC->sa_index3_in_use)
	{
		/* The SA is in use */
		regVal |= (MRVL_APHY_U32)1U << 3;
	}
	else
	{
		/* The SA is not in use */
		regVal &= ~((MRVL_APHY_U32)1U << 3);
	}
	q222x_writeMACReg32(device, BaseAddr_rx_saMap + MRVL_Q222X_MSEC_REG_BUS_WIDTH*3, regVal);
}

/**
 * @brief read back 2 SA used in Tx SC
 *
 * @param[in]		device    PHY pointer
 * @param[in]		txscIndex index
 * @param[in,out]	rxSC      MRVL_Q222X_MSEC_TX_SC struct
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void get2SAInTxSC(MRVL_DEV_PTR device, MRVL_APHY_U8 txscIndex, MRVL_Q222X_MSEC_TX_SC* txSC)
{
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U16 regAddr = 0;
	/* 2 SA per SC */
	regAddr = GETADDR(MRVL_Q222X_MSEC_TX_SA_MAP_MEM, txscIndex, MRVL_Q222X_MSEC_RANGE8);
	q222x_readMACReg32(device, regAddr, &regVal);
	txSC->sa_index0 = (MRVL_APHY_U8)(regVal & 0x7U);
	txSC->sa_index1 = (MRVL_APHY_U8)((regVal >> 3) & 0x7U);
	/* SA 0 is valid or not valid */
	regAddr = GETADDR(MRVL_Q222X_MSEC_TX_SA_INDEX0_VLD, txscIndex, MRVL_Q222X_MSEC_RANGE4);
	q222x_readMACReg32(device, regAddr, &regVal);
	txSC->sa_index0_vld = (0 == (regVal & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
	/* SA 1 is valid or not valid */
	regAddr = GETADDR(MRVL_Q222X_MSEC_TX_SA_INDEX1_VLD, txscIndex, MRVL_Q222X_MSEC_RANGE4);
	q222x_readMACReg32(device, regAddr, &regVal);
	txSC->sa_index1_vld = (0 == (regVal & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
	/* SA 0 or SA 1 is active */
	regAddr = GETADDR(MRVL_Q222X_MSEC_TX_SA_ACTIVE, txscIndex, MRVL_Q222X_MSEC_RANGE4);
	q222x_readMACReg32(device, regAddr, &regVal);
	txSC->isActiveSA1 = (0 == (regVal & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
}

/**
 * @brief write 2 SA settings in registers per selected Tx SC
 *
 * @param[in]	device PHY pointer
 * @param[in]	txSC   MRVL_Q222X_MSEC_TX_SC strcut
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void set2SAInTxSC(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_TX_SC* txSC)
{
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U16 regAddr = 0;
	/* 2 SA per SC */
	regAddr = GETADDR(MRVL_Q222X_MSEC_TX_SA_MAP_MEM, txSC->index, MRVL_Q222X_MSEC_RANGE8);
	regVal = (MRVL_APHY_U32)txSC->sa_index0 & 0x7U;
	regVal |=  ((MRVL_APHY_U32)txSC->sa_index1 & 0x7U) << 3;
	q222x_writeMACReg32(device, regAddr, regVal);
	/* SA 0 or SA 1 is active */
	regAddr =  GETADDR(MRVL_Q222X_MSEC_TX_SA_ACTIVE, txSC->index, MRVL_Q222X_MSEC_RANGE4);
	regVal = (MRVL_APHY_U32)((MRVL_APHY_TRUE == txSC->isActiveSA1) ? 1 : 0);
	q222x_writeMACReg32(device, regAddr, regVal);
	/* SA 0 is valid or not valid */
	regAddr =  GETADDR(MRVL_Q222X_MSEC_TX_SA_INDEX0_VLD, txSC->index, MRVL_Q222X_MSEC_RANGE4);
	regVal = (MRVL_APHY_U32)((MRVL_APHY_TRUE == txSC->sa_index0_vld) ? 1 : 0);
	q222x_writeMACReg32(device, regAddr, regVal);
	/* SA 1 is valid or not valid */
	regAddr =  GETADDR(MRVL_Q222X_MSEC_TX_SA_INDEX1_VLD, txSC->index, MRVL_Q222X_MSEC_RANGE4);
	regVal = (MRVL_APHY_U32)((MRVL_APHY_TRUE == txSC->sa_index1_vld) ? 1 : 0);
	q222x_writeMACReg32(device, regAddr, regVal);
}


/******************************************************************************
 *      MAC 32 and 64 bits register access
 ******************************************************************************/

/**
 * @brief Read out a 32b value from a register through XMDIO interface.
 *
 * @param[in]	device  PHY pointer
 * @param[in]	regAddr Register address within MAC secontion
 * @param[out]	data    Data pointer, function modifies this pointer to reflect readback 32b value
 * @return void
 *
 * @ingroup Utility_Lib
 */
/* polyspace +1 CODE-METRICS:CALLING [Justified] "Deviation ASH-926" */
void q222x_readMACReg32(MRVL_DEV_PTR device, MRVL_APHY_U16 regAddr, MRVL_APHY_U32* data)
{
	MRVL_APHY_U16 temp = 0;
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_MAC_DEV, regAddr, &temp);
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_MAC_DEV, MRVL_Q222X_MMAC_READ_LOW, &temp);
	*data = temp;
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_MAC_DEV, MRVL_Q222X_MMAC_READ_HIGH, &temp);
	*data |= (MRVL_APHY_U32) temp << 16;
}

/**
 * @brief Read out a 64b value from a register through XMDIO interface.
 *
 * @param[in]	device  PHY pointer
 * @param[in]	regAddr Register address within MAC secontion
 * @param[out]	data    Data pointer, function modifies this pointer to reflect readback 64b value
 * @return void
 *
 * @ingroup Utility_Lib
 */
/* polyspace +1 CODE-METRICS:CALLING [Justified] "Deviation ASH-926" */
void q222x_readMACReg64(MRVL_DEV_PTR device, MRVL_APHY_U16 regAddr, MRVL_APHY_U64* data)
{
	MRVL_APHY_U32 temp = 0;
	q222x_readMACReg32(device, regAddr, &temp);
	*data = temp;
	q222x_readMACReg32(device, regAddr + 2, &temp);
	*data |= (MRVL_APHY_U64) temp << 32;
}

/**
 * @brief Write a 32b value into a register through XMDIO interface.
 *
 * @param[in]	device  PHY pointer
 * @param[in]	regAddr Register address within MAC section
 * @param[in]	data    32b value to write into register
 * @return void
 *
 * @ingroup Utility_Lib
 */
/* polyspace +1 CODE-METRICS:CALLING [Justified] "Deviation ASH-926" */
void q222x_writeMACReg32(MRVL_DEV_PTR device, MRVL_APHY_U16 regAddr, MRVL_APHY_U32 data)
{
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_MAC_DEV, regAddr, (MRVL_APHY_U16)(data & 0xFFFFU));
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_MAC_DEV, regAddr + 1, (MRVL_APHY_U16)((data >> 16) & 0xFFFFU));
}

/**
 * @brief Write a 64b value into a register through XMDIO interface.
 *
 * @param[in]	device  PHY pointer
 * @param[in]	regAddr Register address within MAC section
 * @param[in]	data    64b value to write into register
 * @return void
 *
 * @ingroup Utility_Lib
 */
/* polyspace +1 CODE-METRICS:CALLING [Justified] "Deviation ASH-926" */
void q222x_writeMACReg64(MRVL_DEV_PTR device, MRVL_APHY_U16 regAddr, MRVL_APHY_U64 data)
{
	q222x_writeMACReg32(device, regAddr, (MRVL_APHY_U32)(data & 0xFFFFFFFFU));
	q222x_writeMACReg32(device, regAddr + 2, (MRVL_APHY_U32)((data >> 32) & 0xFFFFFFFFU));
}


/******************************************************************************
 *      General Control for MACsec operation
 ******************************************************************************/

/**
 * @brief Initialize MACsec
 *
 * @param[in]	device       PHY pointer
 * @param[in]	speed        MAC speed. MRVL_APHY_SPEED_1000 or MRVL_APHY_SPEED_100
 * @param[in]	powerMode    MAC power mode. MRVL_Q222X_MAC_LOW_LATENCY or MRVL_Q222X_MAC_LOW_POWER(low-power only affects 1000-speed, core clk to the macsec is reduced)
 * @param[in]	fwdMode      Forwarding mode. MRVL_Q222X_MAC_CUT_THROUGH: cut-through; MRVL_Q222X_MAC_STORE_FWD: store and forward
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_CTRL
 */
MRVL_APHY_STATUS q222x_initMACsec(MRVL_DEV_PTR device, MRVL_APHY_SPEED speed, MRVL_Q222X_MAC_POWER_MODE powerMode, MRVL_Q222X_MAC_FWD_MODE fwdMode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	/* enable, deploy MACsec */
	status |= q222x_configMMACPower(device, MRVL_APHY_TRUE);
	/* go through MMAC*/
	status |= q222x_setMMACInPath(device, MRVL_APHY_TRUE);
	/* set speed */
	status |= q222x_setMACSpeed(device, speed);
	/* low-power mode or low-latency mode */
	status |= q222x_setMACPowerMode(device, powerMode);
	/* store-forward mode or cut-through mode*/
	status |= q222x_setMACFwdMode(device, fwdMode);
	/* disable all MACsec entries */
	status |= q222x_disableAllMACsecEntry(device);

	return status;
}

/**
 * @brief Disable MACsec and remove MACsec from datapath
 *
 * @param[in]	device PHY pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_CTRL
 */
MRVL_APHY_STATUS q222x_disableMACsec(MRVL_DEV_PTR device)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	/* powerdown MAC */
	status |= q222x_configMMACPower(device, MRVL_APHY_FALSE);
	/* remove MAC from datapath */
	status |= q222x_setMMACInPath(device, MRVL_APHY_FALSE);
	return status;
}


/******************************************************************************
 *      MMAC Control
 ******************************************************************************/

/**
 * @brief Software reset MMAC and MACsec
 *
 * @param[in]	device PHY pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MAC_CNFG
 */
MRVL_APHY_STATUS q222x_softResetMMAC(MRVL_DEV_PTR device) {
	MRVL_APHY_U16 regVal16;
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_MAC_DEV, 0xA00AU, &regVal16);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_MAC_DEV, 0xA00AU, regVal16 & ~(0x200U));
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_MAC_DEV, 0xA00AU, regVal16 | 0x200U);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief config MMAC power
 *
 * @param device PHY pointer
 * @param isPowerup TRUE: powerup MMAC. FALSE powerdown MMAC
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MAC_CNFG
 */
MRVL_APHY_STATUS q222x_configMMACPower(MRVL_DEV_PTR device, MRVL_APHY_BOOL isPowerup)
{
	MRVL_APHY_U16 regVal16;

	if(MRVL_APHY_TRUE == isPowerup)
	{
		/* power up MAC */
		/* nt_core -> PTP_CONTROL_REGISTER_1 */
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, 4U, 0x87F0U, &regVal16);
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, 4U, 0x87F0U, regVal16 & ~(0x200U));
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_MAC_DEV, 0xA008U, &regVal16);
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_MAC_DEV, 0xA008U, (regVal16 & 0xC1BFU) | 0x8U);
		/* Set default settings */
		setMACsecDefaultSetting(device);
	}
	else
	{
		/* powerdown MAC */
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_MAC_DEV, 0xA008U, &regVal16);
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_MAC_DEV, 0xA008U, regVal16 | 0x60U);
	}
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Check if MMAC is powered up
 *
 * @param[in]	device    PHY pointer
 * @param[out]	isPowerup True: MMAC is powered up; False: MMAC is powered down
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MAC_CNFG
 */
MRVL_APHY_STATUS q222x_getIsMMACPowerup(MRVL_DEV_PTR device, MRVL_APHY_BOOL *isPowerup)
{
	MRVL_APHY_U32 regVal;
	/* Read value from register 0x0, MMAC is power-up if the value readback is not 0 */
	q222x_readMACReg32(device, 0x0, &regVal);
	if (0x0 == regVal)
	{
		*isPowerup = MRVL_APHY_FALSE;
	}
	else
	{
		*isPowerup = MRVL_APHY_TRUE;
	}
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Set datapath to go through MMAC or bypass MMAC.
 * Use this function to deploy/undeploy MACsec after initialization
 *
 * @param[in]	device       PHY pointer
 * @param[in]	isInDatapath True: go through MMAC; False: bypass MMAC
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MAC_CNFG
 */
MRVL_APHY_STATUS q222x_setMMACInPath(MRVL_DEV_PTR device, MRVL_APHY_BOOL isInDatapath)
{
	MRVL_APHY_U16 regVal, regVal2;
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_MAC_DEV, 0xA008U, &regVal);
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_MAC_DEV, 0xA00AU, &regVal2);
	if (MRVL_APHY_TRUE == isInDatapath)
	{
		/* set in datapath */
		regVal |= 0x2U;
		regVal2 |= 0x200U;
	}
	else
	{
		/* remove from datapath */
		regVal &= ~((MRVL_APHY_U16)0x2);
		regVal2 &= ~((MRVL_APHY_U16)0x200);
	}
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_MAC_DEV, 0xA008U, regVal);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_MAC_DEV, 0xA00AU, regVal2);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Check if MMAC is in datapath
 *
 * @param[in]	device       PHY pointer
 * @param[out]	isInDatapath True: go through MMAC; False: bypass MMAC
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MAC_CNFG
 */
MRVL_APHY_STATUS q222x_getIsMMACInPath(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isInDatapath)
{
	MRVL_APHY_U16 regVal;
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_MAC_DEV, 0xA008U, &regVal);
	if ((regVal & 0x2U) == 0x2)
	{
		*isInDatapath = MRVL_APHY_TRUE;
	}
	else
	{
		*isInDatapath = MRVL_APHY_FALSE;
	}
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Set MAC speed
 *
 * @param[in]	device PHY pointer
 * @param[in]	speed  MRVL_APHY_SPEED_1000 or MRVL_APHY_SPEED_100
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MAC_CNFG
 */
MRVL_APHY_STATUS q222x_setMACSpeed(MRVL_DEV_PTR device, MRVL_APHY_SPEED speed)
{
	MRVL_APHY_U32 regVal;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	q222x_readMACReg32(device, 0x800EU, &regVal);
	if (speed == MRVL_APHY_SPEED_1000)
	{
		/* set speed 1000 */
		regVal &= ~((MRVL_APHY_U32)0xF00);
		regVal |= ( (MRVL_APHY_U32)1U << 9);
	}
	else if (speed == MRVL_APHY_SPEED_100)
	{
		/* set speed 100 */
		regVal &= ~((MRVL_APHY_U32)0xF00);
		regVal |= ( (MRVL_APHY_U32)1U << 8);
	}
	else
	{
		/* unknown speed, return error */
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	q222x_writeMACReg32(device, 0x800EU, regVal);
	return status;
}

/**
 * @brief Get MAC speed
 *
 * @param[in]	device PHY pointer
 * @param[out]	speed   MRVL_APHY_SPEED_1000 or MRVL_APHY_SPEED_100
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MAC_CNFG
 */
MRVL_APHY_STATUS q222x_getMACSpeed(MRVL_DEV_PTR device, MRVL_APHY_SPEED* speed)
{
	MRVL_APHY_U32 regVal;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	q222x_readMACReg32(device, 0x800EU, &regVal);
	if ((regVal & 0xF00U) == 0x200)
	{
		*speed = MRVL_APHY_SPEED_1000;
	}
	else if ((regVal & 0xF00U) == 0x100)
	{
		*speed = MRVL_APHY_SPEED_100;
	}
	else
	{
		/* unknown speed, return error */
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	return status;
}

/**
 * @brief Set MAC power mode
 *
 * @param[in]	device       PHY pointer
 * @param[in]	powerMode    MAC power mode. MRVL_Q222X_MAC_LOW_LATENCY or MRVL_Q222X_MAC_LOW_POWER(low-power only affects 1000-speed, core clk to the macsec is reduced)
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MAC_CNFG
 */
MRVL_APHY_STATUS q222x_setMACPowerMode(MRVL_DEV_PTR device, MRVL_Q222X_MAC_POWER_MODE powerMode)
{
	MRVL_APHY_U16 regVal;

	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_MAC_DEV, 0xA008U, &regVal);
	if (MRVL_Q222X_MAC_LOW_LATENCY == powerMode)
	{
		/* low-latency mode */
		regVal |= 0x10U;
	}
	else
	{
		/* low-power mode */
		regVal &= ~((MRVL_APHY_U16)0x10);
	}
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_MAC_DEV, 0xA008U, regVal);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Check MAC power mode
 *
 * @param[in]	device       PHY pointer
 * @param[out]	powerMode    MAC power mode. MRVL_Q222X_MAC_LOW_LATENCY or MRVL_Q222X_MAC_LOW_POWER
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MAC_CNFG
 */
MRVL_APHY_STATUS q222x_getMACPowerMode(MRVL_DEV_PTR device, MRVL_Q222X_MAC_POWER_MODE* powerMode)
{
	MRVL_APHY_U16 regVal;
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_MAC_DEV, 0xA008U, &regVal);
	if ((regVal & 0x10U) == 0x10)
	{
		/* low-latency mode */
		*powerMode = MRVL_Q222X_MAC_LOW_LATENCY;
	}
	else
	{
		/* low-power mode */
		*powerMode = MRVL_Q222X_MAC_LOW_POWER;
	}
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Set MAC fowarding mode
 *
 * @param[in]	device PHY pointer
 * @param[in]	mode   MAC forwardind mode.  MRVL_Q222X_MAC_CUT_THROUGH: cut-through; MRVL_Q222X_MAC_STORE_FWD: store and forward
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MAC_CNFG
 */
MRVL_APHY_STATUS q222x_setMACFwdMode(MRVL_DEV_PTR device, MRVL_Q222X_MAC_FWD_MODE mode)
{
	MRVL_APHY_U32 regVal;
	q222x_readMACReg32(device, MRVL_Q222X_MSEC_SLC_CFG, &regVal);
	if (MRVL_Q222X_MAC_CUT_THROUGH == mode)
	{
		/* cut-through mode */
		regVal &= ~((MRVL_APHY_U32)0xC);
	}
	else
	{
		/* store-forware mode */
		regVal |= 0xCU;
	}
	q222x_writeMACReg32(device, MRVL_Q222X_MSEC_SLC_CFG, regVal);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get MAC fowarding mode
 *
 * @param[in]	device PHY pointer
 * @param[out]	mode   MAC forwardind mode.  MRVL_Q222X_MAC_CUT_THROUGH: cut-through; MRVL_Q222X_MAC_STORE_FWD: store and forward
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MAC_CNFG
 */
MRVL_APHY_STATUS q222x_getMACFwdMode(MRVL_DEV_PTR device, MRVL_Q222X_MAC_FWD_MODE* mode)
{
	MRVL_APHY_U32 regVal;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	q222x_readMACReg32(device, MRVL_Q222X_MSEC_SLC_CFG, &regVal);
	if ((regVal & 0xCU) == 0xC)
	{
		/* store-forware mode */
		*mode = MRVL_Q222X_MAC_STORE_FWD;
	}
	else if ((regVal & 0xCU) == 0x0)
	{
		/* cut-through mode */
		*mode = MRVL_Q222X_MAC_CUT_THROUGH;
	}
	else
	{
		/* unknown mode, return error */
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	return status;
}


/******************************************************************************
 *      MACsec Operation Control
 ******************************************************************************/

/**
 * @brief Disable all cam entry
 *
 * @param[in]	device PHY pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_OP_CNFG
 */
MRVL_APHY_STATUS q222x_disableAllMACsecEntry(MRVL_DEV_PTR device)
{
	/* disable TX cam rule entries */
	q222x_writeMACReg32(device, MRVL_Q222X_MSEC_TX_FLOWID_TCAM_ENABLE, 0);
	/* disable RX cam rule entries */
	q222x_writeMACReg32(device, MRVL_Q222X_MSEC_RX_FLOWID_TCAM_ENABLE, 0);

	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Set MACsec channel bypass
 *
 * @param[in]	device   PHY pointer
 * @param[in]	isEnable True: packets in the channel are parsed and extracted;
 *                       False: packets in the channel are NOT parsed and extracted.(Looks like MACsec is disabled)
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_OP_CNFG
 */
MRVL_APHY_STATUS q222x_setMACsecChannelEnable(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEnable)
{
	if (MRVL_APHY_TRUE == isEnable)
	{
		/* go through MMAC, packets in the channel are parsed and extracted */
		q222x_writeMACReg32(device, MRVL_Q222X_MSEC_CHANNEL_BYPASS, 0);
		q222x_writeMACReg32(device, MRVL_Q222X_MSEC_CHANNEL_BYPASS + 2, 0);
	}
	else
	{
		/* go through MMAC, packets in the channel are NOT parsed and extracted */
		q222x_writeMACReg32(device, MRVL_Q222X_MSEC_CHANNEL_BYPASS, 1);
		q222x_writeMACReg32(device, MRVL_Q222X_MSEC_CHANNEL_BYPASS + 2, 1);
	}
	/* parse depth */
	q222x_writeMACReg32(device, MRVL_Q222X_MSEC_PORT_CONFIG_PARSE, 0);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Check MACsec channel bypass
 *
 * @param[in]	device   PHY pointer
 * @param[out]	isEnable True: packets in the channel are parsed and extracted;
 *                       False: packets in the channel are NOT parsed and extracted.(Looks like MACsec is disabled)
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_OP_CNFG
 */
MRVL_APHY_STATUS q222x_getIsMACsecChannelEnable(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isEnable)
{
	MRVL_APHY_U32 regVal,regVal2;
	q222x_readMACReg32(device, MRVL_Q222X_MSEC_CHANNEL_BYPASS, &regVal);
	q222x_readMACReg32(device, MRVL_Q222X_MSEC_CHANNEL_BYPASS + 2, &regVal2);
	regVal |= regVal2;
	/* MRVL_APHY_TRUE : go through MMAC, packets in the channel are parsed and extracted */
	/* MRVL_APHY_FALSE : go through MMAC, packets in the channel are NOT parsed and extracted */
	*isEnable = ((regVal & 0x1U) == 0) ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
	return MRVL_APHY_STATUS_OK;
}


/******************************************************************************
 *      Rule
 ******************************************************************************/

/**
 * @brief Set MACsec rule(FLOWID_TCAM) which is used to match frame
 *
 * @param[in]	device   PHY pointer
 * @param[in]	rule     MACsec rule struct pointer
 * @param[in]	isEgress True: egress/Tx; False: ingress/Rx
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_RULE_CNFG
 */
MRVL_APHY_STATUS q222x_setMACsecRule(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_RULE* rule, MRVL_APHY_BOOL isEgress)
{
	MRVL_APHY_U16 BaseAddrData = 0;
	MRVL_APHY_U16 BaseAddrMask = 0;
	MRVL_APHY_U32 keyArray[7] = { 0 };
	MRVL_APHY_U32 maskArray[7] = { 0 };
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	if (rule->index >= MRVL_Q222X_MSEC_MAX_RULE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		if (isEgress == MRVL_APHY_TRUE)
		{
			/* egress/tx reg addr */
			BaseAddrData = GETADDR(MRVL_Q222X_MSEC_TX_FLOWID_TCAM_DATA, rule->index, MRVL_Q222X_MSEC_RANGE32);
			BaseAddrMask = GETADDR(MRVL_Q222X_MSEC_TX_FLOWID_TCAM_MASK, rule->index, MRVL_Q222X_MSEC_RANGE32);
		}
		else
		{
			/* ingress/rx reg addr */
			BaseAddrData = GETADDR(MRVL_Q222X_MSEC_RX_FLOWID_TCAM_DATA, rule->index, MRVL_Q222X_MSEC_RANGE32);
			BaseAddrMask = GETADDR(MRVL_Q222X_MSEC_RX_FLOWID_TCAM_MASK, rule->index, MRVL_Q222X_MSEC_RANGE32);
		}

		/* covert rule to array */
		convert2ArrayFromRule(rule, keyArray, maskArray);

		/* write data array into register */
		writeValFromRuleArray(device, BaseAddrData, keyArray, MRVL_APHY_FALSE);
		/* write mask array into register */
		writeValFromRuleArray(device, BaseAddrMask, maskArray, MRVL_APHY_TRUE);

		/* enable or disable */
		status = q222x_setMACsecRuleEnable(device, rule->index, isEgress, rule->isEnable);
	}

	return status;
}

/**
 * @brief Get MACsec rule(FLOWID_TCAM) which is used to match frame
 *
 * @param[in]	device    PHY pointer
 * @param[in]	ruleIndex MACsec rule index/ID
 * @param[out]	rule      MACsec rule struct pointer
 * @param[in]	isEgress  True: egress/Tx; False: ingress/Rx
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_RULE_CNFG
 */
MRVL_APHY_STATUS q222x_getMACsecRule(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_Q222X_MSEC_RULE* rule, MRVL_APHY_BOOL isEgress)
{
	MRVL_APHY_U16 BaseAddrData = 0;
	MRVL_APHY_U16 BaseAddrMask = 0;
	MRVL_APHY_U16 BaseAddrEnable = 0;
	MRVL_APHY_U32 keyArray[7] = { 0 };
	MRVL_APHY_U32 maskArray[7] = { 0 };
	MRVL_APHY_U32 regVal32 = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;

	if (ruleIndex >= MRVL_Q222X_MSEC_MAX_RULE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		if (isEgress == MRVL_APHY_TRUE)
		{
			/* egress/tx reg addr */
			BaseAddrData = GETADDR(MRVL_Q222X_MSEC_TX_FLOWID_TCAM_DATA, ruleIndex, MRVL_Q222X_MSEC_RANGE32);
			BaseAddrMask = GETADDR(MRVL_Q222X_MSEC_TX_FLOWID_TCAM_MASK, ruleIndex, MRVL_Q222X_MSEC_RANGE32);
			BaseAddrEnable = MRVL_Q222X_MSEC_TX_FLOWID_TCAM_ENABLE;
		}
		else
		{
			/* ingress/rx reg addr */
			BaseAddrData = GETADDR(MRVL_Q222X_MSEC_RX_FLOWID_TCAM_DATA, ruleIndex, MRVL_Q222X_MSEC_RANGE32);
			BaseAddrMask = GETADDR(MRVL_Q222X_MSEC_RX_FLOWID_TCAM_MASK, ruleIndex, MRVL_Q222X_MSEC_RANGE32);
			BaseAddrEnable = MRVL_Q222X_MSEC_RX_FLOWID_TCAM_ENABLE;
		}
		/* readback reg values and write to data array */
		readValConvert2RuleArray(device, BaseAddrData, keyArray);
		/* readback reg values and write to mask array */
		readValConvert2RuleArray(device, BaseAddrMask, maskArray);

		/* convert array to rule */
		convert2RuleFromArray(keyArray, maskArray, rule);

		/* assign rule index */
		rule->index = ruleIndex;

		/* check enabled or disabled */
		q222x_readMACReg32(device, BaseAddrEnable, &regVal32);
		rule->isEnable = (0 == ((regVal32 >> ruleIndex) & 0x1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
	}

	return status;
}

/**
 * @brief Enable or disable rule
 *
 * @param[in]	device    PHY pointer
 * @param[in]	ruleIndex MACsec rule index/ID
 * @param[in]	isEgress  True: egress/Tx; False: ingress/Rx
 * @param[in]	isEnable  True: enable MACsec rule. False: disable MACsec rule
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_RULE_CNFG
 */
MRVL_APHY_STATUS q222x_setMACsecRuleEnable(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_APHY_BOOL isEgress, MRVL_APHY_BOOL isEnable)
{
	MRVL_APHY_U16 BaseAddr_Enable = 0;
	MRVL_APHY_U32 regVal32 = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	if (ruleIndex >= MRVL_Q222X_MSEC_MAX_RULE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* get reg addr per direction */
		if (isEgress == MRVL_APHY_TRUE)
		{
			BaseAddr_Enable = MRVL_Q222X_MSEC_TX_FLOWID_TCAM_ENABLE;
		}
		else
		{
			BaseAddr_Enable = MRVL_Q222X_MSEC_RX_FLOWID_TCAM_ENABLE;
		}
		/* FLOWID_TCAM enable or disable */
		q222x_readMACReg32(device, BaseAddr_Enable, &regVal32);
		if (MRVL_APHY_TRUE == isEnable)
		{
			regVal32 |=  (MRVL_APHY_U32)1U << ruleIndex;
		}
		else
		{
			regVal32 &= ~( (MRVL_APHY_U32)1U << ruleIndex);
		}
		q222x_writeMACReg32(device, BaseAddr_Enable, regVal32);
	}

	return status;
}


/******************************************************************************
 *      SecY Map
 ******************************************************************************/

/**
 * @brief Set MACsec Rx SecY Map in memory. Rule mapping to secY
 *
 * @param[in]	device    PHY pointer
 * @param[in]	ruleIndex Rx rule index
 * @param[in]	secyMap   Rx SecY Map struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SECY_MAP_CNFG
 */
MRVL_APHY_STATUS q222x_setRxSecYMap(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_Q222X_MSEC_RX_SECY_MAP* secyMap)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 BaseAddr_SecY_Map = 0;
	MRVL_APHY_U32 val32 = 0;

	if (ruleIndex >= MRVL_Q222X_MSEC_MAX_RULE_NUM || secyMap->secYIndex >= MRVL_Q222X_MSEC_MAX_SECY_MAP_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* Get address of register indexed by ruleIndex  */
		BaseAddr_SecY_Map = GETADDR(MRVL_Q222X_MSEC_RX_SECY_MAP_MEM, ruleIndex, MRVL_Q222X_MSEC_RANGE8);
		/* support N:1 mapping */
		val32 = (MRVL_APHY_U32)secyMap->secYIndex & 0x3U;
		val32 +=  (MRVL_APHY_U32)((MRVL_APHY_TRUE == secyMap->isControlPacket) ? 1 : 0) << 2;
		q222x_writeMACReg32(device, BaseAddr_SecY_Map, val32);
	}

	return status;
}

/**
 * @brief Get MACsec Rx SecY Map from memory.  Rule mapping to secY
 *
 * @param[in]	device    PHY pointer
 * @param[in]	ruleIndex Rx rule index
 * @param[out]	secyMap   Rx SecY Map struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SECY_MAP_CNFG
 */
MRVL_APHY_STATUS q222x_getRxSecYMap(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_Q222X_MSEC_RX_SECY_MAP* secyMap)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 BaseAddr_SecY_Map = 0;
	MRVL_APHY_U32 regVal32 = 0;

	if (ruleIndex >= MRVL_Q222X_MSEC_MAX_RULE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* Get address of register indexed by ruleIndex  */
		BaseAddr_SecY_Map = GETADDR(MRVL_Q222X_MSEC_RX_SECY_MAP_MEM, ruleIndex, MRVL_Q222X_MSEC_RANGE8);
		q222x_readMACReg32(device, BaseAddr_SecY_Map, &regVal32);
		/* support N:1 mapping */
		secyMap->secYIndex = (MRVL_APHY_U8)(regVal32 & 0x3U);
		secyMap->isControlPacket = (0 == ((regVal32 >> 2) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
	}

	return status;
}

/**
 * @brief Set MACsec Tx SecY  Map in memory. Rule mapping to secY
 *
 * @param[in]	device    PHY pointer
 * @param[in]	ruleIndex Tx rule index
 * @param[in]	secyMap   Tx SecY Map struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SECY_MAP_CNFG
 */
MRVL_APHY_STATUS q222x_setTxSecYMap(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_Q222X_MSEC_TX_SECY_MAP* secyMap)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 BaseAddr_SecY_Map = 0;
	MRVL_APHY_U64 regVal = 0;

	if (ruleIndex >= MRVL_Q222X_MSEC_MAX_RULE_NUM || secyMap->secYIndex >= MRVL_Q222X_MSEC_MAX_SECY_MAP_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* Get address of register indexed by ruleIndex  */
		BaseAddr_SecY_Map = GETADDR(MRVL_Q222X_MSEC_TX_SECY_MAP_MEM, ruleIndex, MRVL_Q222X_MSEC_RANGE16);
		q222x_writeMACReg64(device, BaseAddr_SecY_Map, secyMap->sectag_sci);
		/* support N:1 mapping */
		regVal = (MRVL_APHY_U64)secyMap->secYIndex & 0x3U;
		regVal += ((MRVL_APHY_U64)(MRVL_APHY_TRUE == secyMap->isControlPacket ? 1 : 0)) << 2;
		regVal += (((MRVL_APHY_U64)secyMap->scIndex & 0x3U)) << 3;
		regVal += ((MRVL_APHY_U64)(MRVL_APHY_TRUE == secyMap->auxiliary_plcy ? 1 : 0)) << 5;
		q222x_writeMACReg64(device, BaseAddr_SecY_Map + MRVL_Q222X_MSEC_REG_BUS_WIDTH, regVal);
	}

	return status;
}

/**
 * @brief Get MACsec Tx SecY Map from memory. Rule mapping to secY
 *
 * @param[in]	device    PHY pointer
 * @param[in]	ruleIndex Tx rule index
 * @param[out]	secyMap   Tx SecY Map struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SECY_MAP_CNFG
 */
MRVL_APHY_STATUS q222x_getTxSecYMap(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_Q222X_MSEC_TX_SECY_MAP* secyMap)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 BaseAddr_SecY_Map = 0;
	MRVL_APHY_U64 regVal = 0;

	if (ruleIndex >= MRVL_Q222X_MSEC_MAX_RULE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* Get address of register indexed by ruleIndex  */
		BaseAddr_SecY_Map = GETADDR(MRVL_Q222X_MSEC_TX_SECY_MAP_MEM, ruleIndex, MRVL_Q222X_MSEC_RANGE16);
		q222x_readMACReg64(device, BaseAddr_SecY_Map, &regVal);
		secyMap->sectag_sci = regVal;
		q222x_readMACReg64(device, BaseAddr_SecY_Map + MRVL_Q222X_MSEC_REG_BUS_WIDTH, &regVal);
		/* support N:1 mapping */
		secyMap->secYIndex = (MRVL_APHY_U8)(regVal & 0x3U);
		secyMap->isControlPacket = (0 == ((regVal >> 2) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
		secyMap->scIndex =  (MRVL_APHY_U8)((regVal >> 3) & 0x3U);
		secyMap->auxiliary_plcy = (0 == ((regVal >> 5) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
	}

	return status;
}


/******************************************************************************
 *      SecY
 ******************************************************************************/

/**
 * @brief Set MACsec Rx SecY in memory
 *
 * @param[in]	device PHY pointer
 * @param[in]	secy   Rx SecY struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SECY_CNFG
 */
MRVL_APHY_STATUS q222x_setRxSecY(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_RX_SECY* secy)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 BaseAddr_SecY_Plcy = 0;
	MRVL_APHY_U64 regVal = 0;
	if (secy->index >= MRVL_Q222X_MSEC_MAX_SECY_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* Get address of register indexed by secy->index  */
		BaseAddr_SecY_Plcy = GETADDR(MRVL_Q222X_MSEC_RX_SECY_PLCY_MEM, secy->index, MRVL_Q222X_MSEC_RANGE8);

		regVal = (MRVL_APHY_U64)(MRVL_APHY_TRUE == secy->controlled_port_enabled ? 1 : 0);
		regVal += ((MRVL_APHY_U64)secy->validate_frames & 0x3U) << 4;
		regVal += ((MRVL_APHY_U64)secy->strip_sectag_icv & 0x3U) << 8;
		regVal += ((MRVL_APHY_U64)secy->cipher & 0xFU) << 12;
		regVal += ((MRVL_APHY_U64)secy->confidential_offset & 0x7FU) << 20;
		regVal += ((MRVL_APHY_U64)((MRVL_APHY_TRUE == secy->icv_includes_da_sa) ? 1 : 0)) << 28;
		regVal += ((MRVL_APHY_U64)((MRVL_APHY_TRUE == secy->replay_protect) ? 1 : 0)) << 30;
		regVal |= ((MRVL_APHY_U64)secy->replay_window & 0xFFFFFFFFU) << 32;

		q222x_writeMACReg64(device, BaseAddr_SecY_Plcy, regVal);
	}

	return status;
}

/**
 * @brief Get MACsec Rx SecY from memory
 *
 * @param[in]	device    PHY pointer
 * @param[in]	secyIndex Rx SecY index
 * @param[out]	secy      Rx SecY struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SECY_CNFG
 */
MRVL_APHY_STATUS q222x_getRxSecY(MRVL_DEV_PTR device, MRVL_APHY_U8 secyIndex, MRVL_Q222X_MSEC_RX_SECY* secy)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 BaseAddr_SecY_Plcy = 0;
	MRVL_APHY_U64 regVal64 = 0;
	MRVL_APHY_U64 validateFrameVal = 0;
	MRVL_APHY_U64 stripSectagIcvVal = 0;
	MRVL_APHY_U64 cipherSuiteVal = 0;
	if (secyIndex >= MRVL_Q222X_MSEC_MAX_SECY_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* Get address of register indexed by secyIndex  */
		BaseAddr_SecY_Plcy = GETADDR(MRVL_Q222X_MSEC_RX_SECY_PLCY_MEM, secyIndex, MRVL_Q222X_MSEC_RANGE8);
		q222x_readMACReg64(device, BaseAddr_SecY_Plcy, &regVal64);
		/* assign secy with reg value */
		secy->controlled_port_enabled = (0 == (regVal64 & 0x1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
		secy->confidential_offset = (MRVL_APHY_U8)((regVal64 >> 20) & 0x7FU);
		secy->icv_includes_da_sa = (0 == ((regVal64 >> 28) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
		secy->replay_protect = (0 == ((regVal64 >> 30) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
		secy->replay_window = (MRVL_APHY_U32)((regVal64 >> 32) & 0xFFFFFFFFU);

		/* validate frame Enum */
		validateFrameVal = (regVal64 >> 4) & 0x3U;
		convert2ValidateFrameEnum((MRVL_APHY_U16)validateFrameVal, &(secy->validate_frames));

		/* strip sectag icv Enum */
		stripSectagIcvVal = (regVal64 >> 8) & 0x3U;
		convert2StripSectagEnum((MRVL_APHY_U16)stripSectagIcvVal, &(secy->strip_sectag_icv));

		/* cipher suite Enum */
		cipherSuiteVal = (regVal64 >> 12) & 0xFU;
		status = convert2CipherSuiteEnum((MRVL_APHY_U16)cipherSuiteVal, &(secy->cipher));
	}

	return status;
}

/**
 * @brief Set MACsec Tx SecY in memory
 *
 * @param[in]	device PHY pointer
 * @param[in]	secy   Tx SecY struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SECY_CNFG
 */
MRVL_APHY_STATUS q222x_setTxSecY(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_TX_SECY* secy)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 BaseAddr_SecY_Plcy = 0;
	MRVL_APHY_U64 regVal = 0;
	if (secy->index >= MRVL_Q222X_MSEC_MAX_SECY_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* Get address of register indexed by secy->index  */
		BaseAddr_SecY_Plcy = GETADDR(MRVL_Q222X_MSEC_TX_SECY_PLCY_MEM, secy->index, MRVL_Q222X_MSEC_RANGE8);

		regVal = (MRVL_APHY_U64)secy->sectag_offset & 0x7FU;
		regVal += ((MRVL_APHY_U64)secy->sectag_tci & 0x3FU) << 8;
		regVal += ((MRVL_APHY_U64)secy->mtu & 0xFFFFU) << 16;
		regVal <<= 32;
		regVal += (MRVL_APHY_U64)((MRVL_APHY_TRUE == secy->controlled_port_enabled) ? 1 : 0);
		regVal += (MRVL_APHY_U64)(MRVL_APHY_TRUE == secy->protect_frames ? 1 : 0) << 4;
		regVal += ((MRVL_APHY_U64)secy->cipher & 0x7U) << 12;
		regVal += ((MRVL_APHY_U64)secy->confidential_offset & 0x7FU) << 20;
		regVal += (MRVL_APHY_U64)((MRVL_APHY_TRUE == secy->icv_includes_da_sa) ? 1 : 0) << 28;
		regVal += (MRVL_APHY_U64)1 << 30;
		q222x_writeMACReg64(device, BaseAddr_SecY_Plcy, regVal);
	}

	return status;
}

/**
 * @brief Get MACsec Tx SecY in memory
 *
 * @param[in]	device    PHY pointer
 * @param[in]	secyIndex Tx SecY index
 * @param[out]	secy      Tx SecY struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SECY_CNFG
 */
MRVL_APHY_STATUS q222x_getTxSecY(MRVL_DEV_PTR device, MRVL_APHY_U8 secyIndex, MRVL_Q222X_MSEC_TX_SECY* secy)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 BaseAddr_SecY_Plcy = 0;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U64 cipherSuiteVal = 0;
	if (secyIndex >= MRVL_Q222X_MSEC_MAX_SECY_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* Get address of register indexed by secyIndex  */
		BaseAddr_SecY_Plcy = GETADDR(MRVL_Q222X_MSEC_TX_SECY_PLCY_MEM, secyIndex, MRVL_Q222X_MSEC_RANGE8);

		q222x_readMACReg64(device, BaseAddr_SecY_Plcy, &regVal);
		secy->controlled_port_enabled = (0 == (regVal & 0x1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
		secy->protect_frames = (0 == ((regVal >> 4) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
		secy->confidential_offset = (MRVL_APHY_U8)((regVal >> 20) & 0x7FU);
		secy->icv_includes_da_sa = (0 == ((regVal >> 28) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
		secy->sectag_offset = (MRVL_APHY_U8)((regVal >> 32) & 0x7FU);
		secy->sectag_tci = (MRVL_APHY_U8)((regVal >> 40) & 0x3FU);
		secy->mtu = (MRVL_APHY_U16)((regVal >> 48) & 0xFFFFU);

		/* cipher suite Enum */
		cipherSuiteVal = (regVal >> 12) & 0xFU;;
		status = convert2CipherSuiteEnum((MRVL_APHY_U16)cipherSuiteVal, &(secy->cipher));
	}

	return status;
}


/******************************************************************************
 *      SC
 ******************************************************************************/

/**
 * @brief Set MACsec Rx SC in memory
 *
 * @param[in]	device PHY pointer
 * @param[in]	rxSC   Rx SC struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SC_CNFG
 */
MRVL_APHY_STATUS q222x_setRxSC(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_RX_SC* rxSC)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U16 BaseAddr_rxCAM;
	if (rxSC->index >= MRVL_Q222X_MSEC_MAX_SC_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_rxCAM = GETADDR(MRVL_Q222X_MSEC_RX_SC_CAM, rxSC->index, MRVL_Q222X_MSEC_RANGE16);
		/* RX CAM */
		q222x_writeMACReg64(device, BaseAddr_rxCAM, rxSC->sci);
		q222x_writeMACReg64(device, BaseAddr_rxCAM + MRVL_Q222X_MSEC_REG_BUS_WIDTH, (MRVL_APHY_U64)rxSC->secYIndex & 0x3U);

		/* CAM enable */
		q222x_readMACReg32(device, MRVL_Q222X_MSEC_RX_SC_CAM_ENABLE, &regVal);
		if (MRVL_APHY_TRUE == rxSC->enable)
		{
			regVal |= (MRVL_APHY_U32)1U << rxSC->index;
		}
		else
		{
			regVal &= ~((MRVL_APHY_U32)1U << rxSC->index);
		}
		q222x_writeMACReg32(device, MRVL_Q222X_MSEC_RX_SC_CAM_ENABLE, regVal);

		/* set 4 SA per SC */
		 set4SAInRxSC(device, rxSC);
	}

	return status;
}

/**
 * @brief Get MACsec Rx SC from memory
 *
 * @param[in]	device    PHY pointer
 * @param[in]	rxscIndex Rx SC index
 * @param[out]	rxSC      Rx SC struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SC_CNFG
 */
MRVL_APHY_STATUS q222x_getRxSC(MRVL_DEV_PTR device, MRVL_APHY_U8 rxscIndex, MRVL_Q222X_MSEC_RX_SC* rxSC)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal32 = 0;
	MRVL_APHY_U64 regVal64 = 0;
	MRVL_APHY_U16 BaseAddr_rxCAM = 0;
	if (rxscIndex >= MRVL_Q222X_MSEC_MAX_SC_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_rxCAM = GETADDR(MRVL_Q222X_MSEC_RX_SC_CAM, rxscIndex, MRVL_Q222X_MSEC_RANGE16);
		/* the index is not the value read from register */
		rxSC->index = rxscIndex;
		/* check enable or disable */
		q222x_readMACReg32(device, MRVL_Q222X_MSEC_RX_SC_CAM_ENABLE, &regVal32);
		rxSC->enable = (0 == ((regVal32 >> rxscIndex) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;
		/* RX CAM */
		q222x_readMACReg64(device, BaseAddr_rxCAM, &regVal64);
		rxSC->sci = regVal64;
		q222x_readMACReg64(device, BaseAddr_rxCAM + MRVL_Q222X_MSEC_REG_BUS_WIDTH, &regVal64);
		rxSC->secYIndex = (MRVL_APHY_U8)(regVal64 & 0x7U);

		/* 4 SA per SC */
		get4SAInRxSC(device, rxscIndex, rxSC);
	}

	return status;
}

/**
 * @brief Set MACsec Tx SC in memory
 *
 * @param[in]	device PHY pointer
 * @param[in]	txSC   Tx SC struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SC_CNFG
 */
MRVL_APHY_STATUS q222x_setTxSC(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_TX_SC* txSC)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	if (txSC->index >= MRVL_Q222X_MSEC_MAX_SC_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* set 2 SA per SC */
		set2SAInTxSC(device, txSC);
		/* set autorekey */
		q222x_readMACReg32(device, MRVL_Q222X_MSEC_TX_AUTO_REKEY, &regVal);
		if (MRVL_APHY_TRUE == txSC->enable_auto_rekey)
		{
			regVal |=  (MRVL_APHY_U32)1U << txSC->index;
		}
		else
		{
			regVal &= ~( (MRVL_APHY_U32)1U << txSC->index);
		}
		q222x_writeMACReg32(device, MRVL_Q222X_MSEC_TX_AUTO_REKEY, regVal);
	}

	return status;
}

/**
 * @brief Get MACsec Tx SC from memory
 *
 * @param[in]	device    PHY pointer
 * @param[in]	txscIndex Tx SC index
 * @param[out]	txSC      Tx SC struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SC_CNFG
 */
MRVL_APHY_STATUS q222x_getTxSC(MRVL_DEV_PTR device, MRVL_APHY_U8 txscIndex, MRVL_Q222X_MSEC_TX_SC* txSC)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	if (txscIndex >= MRVL_Q222X_MSEC_MAX_SC_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* the index is not the value read from register */
		txSC->index = txscIndex;
		/* 2 SA per SC */
		get2SAInTxSC(device, txscIndex, txSC);
		/* get autorekey setting*/
		q222x_readMACReg32(device, MRVL_Q222X_MSEC_TX_AUTO_REKEY, &regVal);
		txSC->enable_auto_rekey = (0 == ((regVal >> txSC->index) & 1U)) ? MRVL_APHY_FALSE : MRVL_APHY_TRUE;

	}

	return status;
}


/******************************************************************************
 *      SA and Key
 ******************************************************************************/

/**
 * @brief enable/disable all SAK/HashKey lockout. With lockout enabled, SAK/HashKey will return 0s on SW read
 *
 * @param[in]	device   PHY pointer
 * @param[in]	isEgress True: egress/tx; False: ingress/rx
 * @param[in]	isEnable True: enable SAK lockout; False: disable SAK lockout
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SA_CNFG
 */
MRVL_APHY_STATUS q222x_configSAKLockout(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_APHY_BOOL isEnable)
{
	MRVL_APHY_U16 regAddr;
	MRVL_APHY_U32 regVal;
	if (isEgress == MRVL_APHY_TRUE)
	{
		regAddr = MRVL_Q222X_MSEC_TX_SA_KEY_LOCKOUT;
	}
	else
	{
		regAddr = MRVL_Q222X_MSEC_RX_SA_KEY_LOCKOUT;
	}
	if (isEnable == MRVL_APHY_TRUE)
	{
		/* enable all SAK/HashKey entries lockout */
		regVal = 0xFFU;
	}
	else
	{
		/* disable all SAK/HashKey entries lockout */
		regVal = 0x0U;
	}
	/* write the lockout value to register */
	q222x_writeMACReg32(device, regAddr, regVal);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Set MACsec Rx SA in memory
 *
 * @param[in]	device PHY pointer
 * @param[in]	rxSA   Rx SA struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SA_CNFG
 */
MRVL_APHY_STATUS q222x_setRxSA(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_RX_SA* rxSA)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	if (rxSA->index >= MRVL_Q222X_MSEC_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* write SA policy values to memory */
		status = q222x_setRxSAPolicy(device, rxSA->index, &(rxSA->policy));
		/* write next PN to register */
		status |= q222x_setRxSANextPN(device, rxSA->index, rxSA->nextPN);
	}

	return status;
}

/**
 * @brief Get MACsec Rx SA from memory
 *
 * @param[in]	device     PHY pointer
 * @param[in]	rxsaIndex  Rx SA index
 * @param[out]	rxSA       Rx SA struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SA_CNFG
 */
MRVL_APHY_STATUS q222x_getRxSA(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_Q222X_MSEC_RX_SA* rxSA)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 BaseAddr_nextPN;
	if (rxsaIndex >= MRVL_Q222X_MSEC_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_nextPN = GETADDR(MRVL_Q222X_MSEC_RX_SA_PN_TABLE_MEM, rxsaIndex, MRVL_Q222X_MSEC_RANGE8);
		rxSA->index = rxsaIndex;
		/* readback SA policy values from memory */
		status = q222x_getRxSAPolicy(device, rxSA->index, &(rxSA->policy));
		/* read next PN value from register */
		q222x_readMACReg64(device, BaseAddr_nextPN, &regVal);
		rxSA->nextPN = regVal;
	}

	return status;
}

/**
 * @brief Set MACsec Tx SA in memory
 *
 * @param[in]	device PHY pointer
 * @param[in]	txSA   Tx SA struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SA_CNFG
 */
MRVL_APHY_STATUS q222x_setTxSA(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_TX_SA* txSA)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	if (txSA->index >= MRVL_Q222X_MSEC_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* write SA policy values to memory */
		status = q222x_setTxSAPolicy(device, txSA->index, &(txSA->policy));
		/* write next PN to register */
		status |= q222x_setTxSANextPN(device, txSA->index, txSA->nextPN);
	}

	return status;
}

/**
 * @brief Get MACsec Tx SA from memory
 *
 * @param[in]	device    PHY pointer
 * @param[in]	txsaIndex Tx SA index
 * @param[out]	txSA      Tx SA struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SA_CNFG
 */
MRVL_APHY_STATUS q222x_getTxSA(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_Q222X_MSEC_TX_SA* txSA)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 BaseAddr_nextPN;
	if (txsaIndex >= MRVL_Q222X_MSEC_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_nextPN = GETADDR(MRVL_Q222X_MSEC_TX_SA_PN_TABLE_MEM, txsaIndex, MRVL_Q222X_MSEC_RANGE8);
		txSA->index = txsaIndex;
		/* readback SA policy values from memory */
		status = q222x_getTxSAPolicy(device, txSA->index, &(txSA->policy));
		/* readback nextPN value from register */
		q222x_readMACReg64(device, BaseAddr_nextPN, &regVal);
		txSA->nextPN = regVal;
	}

	return status;
}

/**
 * @brief Set MACsec Rx SA policy in memory. Rx SA policy includes SAK, HASHKey, SALT and SSCI.
 *
 * @param[in]	device    PHY pointer
 * @param[in]	rxsaIndex Rx SA index
 * @param[in]	saPlcy    Rx SA policy struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SA_CNFG
 */
MRVL_APHY_STATUS q222x_setRxSAPolicy(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_Q222X_MSEC_RX_SA_PLCY* saPlcy)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 BaseAddr_rx_sa;
	if (rxsaIndex >= MRVL_Q222X_MSEC_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_rx_sa = GETADDR(MRVL_Q222X_MSEC_RX_SA_PLCY_MEM, rxsaIndex, MRVL_Q222X_MSEC_RANGE64);
		/* write SAK value to register */
		writeSAKValue(device, BaseAddr_rx_sa, saPlcy->sak);
		/* write Hash value to register */
		writeHashValue(device, BaseAddr_rx_sa, saPlcy->hashKey);
		/* write Salt and SSCI value to register */
		writeSaltAndSSCIValue(device, BaseAddr_rx_sa, saPlcy->ssci, saPlcy->salt);
	}
	return status;
}

/**
 * @brief Get MACsec Rx SA policy from memory. Rx SA policy includes SAK, HASHKey, SALT and SSCI.
 *
 * @param[in]	device    PHY pointer
 * @param[in]	rxsaIndex Rx SA index
 * @param[out]	saPlcy    Rx SA policy struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SA_CNFG
 */
MRVL_APHY_STATUS q222x_getRxSAPolicy(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_Q222X_MSEC_RX_SA_PLCY* saPlcy)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 BaseAddr_rx_sa;
	if (rxsaIndex >= MRVL_Q222X_MSEC_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_rx_sa = GETADDR(MRVL_Q222X_MSEC_RX_SA_PLCY_MEM, rxsaIndex, MRVL_Q222X_MSEC_RANGE64);
		/* read SAK value from register */
		readValConvert2SAK(device, BaseAddr_rx_sa, saPlcy->sak);
		/* read Hash value from register */
		readValConvert2Hash(device, BaseAddr_rx_sa, saPlcy->hashKey);
		/* read Salt and SSCI value from register */
		readValConvert2SaltSSCI(device, BaseAddr_rx_sa, &(saPlcy->ssci), saPlcy->salt);
	}
	return status;
}

/**
 * @brief Set MACsec Tx SA policy in memory. Tx SA policy includes SAK, HASHKey, SALT and SSCI. Plus sectag AN.
 *
 * @param[in]	device    PHY pointer
 * @param[in]	txsaIndex Tx SA index
 * @param[in]	saPlcy    Tx SA policy struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SA_CNFG
 */
MRVL_APHY_STATUS q222x_setTxSAPolicy(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_Q222X_MSEC_TX_SA_PLCY* saPlcy)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 BaseAddr_txSA;
	if (txsaIndex >= MRVL_Q222X_MSEC_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_txSA = GETADDR(MRVL_Q222X_MSEC_TX_SA_PLCY_MEM, txsaIndex, MRVL_Q222X_MSEC_RANGE128);

		/* write SAK value to register */
		writeSAKValue(device, BaseAddr_txSA, saPlcy->sak);
		/* write Hash value to register */
		writeHashValue(device, BaseAddr_txSA, saPlcy->hashKey);
		/* write Salt and SSCI value to register */
		writeSaltAndSSCIValue(device, BaseAddr_txSA, saPlcy->ssci, saPlcy->salt);
		/* write AN to register */
		writeSecTagANValue(device, BaseAddr_txSA, (MRVL_APHY_U64)saPlcy->AN);
	}
	return status;
}

/**
 * @brief Get MACsec Tx SA policy from memory. Tx SA policy includes SAK, HASHKey, SALT and SSCI. Plus sectag AN.
 *
 * @param[in]	device    PHY pointer
 * @param[in]	txsaIndex Tx SA index
 * @param[out]	saPlcy    Tx SA policy struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SA_CNFG
 */
MRVL_APHY_STATUS q222x_getTxSAPolicy(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_Q222X_MSEC_TX_SA_PLCY* saPlcy)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 BaseAddr_txSA;
	if (txsaIndex >= MRVL_Q222X_MSEC_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_txSA = GETADDR(MRVL_Q222X_MSEC_TX_SA_PLCY_MEM, txsaIndex, MRVL_Q222X_MSEC_RANGE128);
		/* readback SAK value from register */
		readValConvert2SAK(device, BaseAddr_txSA, saPlcy->sak);
		/* readback Hash value from register */
		readValConvert2Hash(device, BaseAddr_txSA, saPlcy->hashKey);
		/* readback Salt and SSCI value from register */
		readValConvert2SaltSSCI(device, BaseAddr_txSA, &(saPlcy->ssci), saPlcy->salt);
		/* readback AN value from register */
		readSecTagANValue(device, BaseAddr_txSA, &regVal);
		saPlcy->AN = (MRVL_APHY_U8)(regVal & 0x3U);
	}
	return status;
}

/******************************************************************************
 *      PN and PN Threshold
 ******************************************************************************/

/**
 * @brief Set MACsec Rx SA next packet number. To readback next PN, call q222x_getRxSA or q222x_getRxSACurrentPN + 1
 *
 * @param[in]	device    PHY pointer
 * @param[in]	rxsaIndex Rx SA index
 * @param[in]	pn Packet number
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS q222x_setRxSANextPN(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_APHY_U64 pn)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 BaseAddr_nextPN;
	if (rxsaIndex >= MRVL_Q222X_MSEC_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_nextPN = GETADDR(MRVL_Q222X_MSEC_RX_SA_PN_TABLE_MEM, rxsaIndex, MRVL_Q222X_MSEC_RANGE8);
		/* write next PN to register */
		q222x_writeMACReg64(device, BaseAddr_nextPN, pn);
	}

	return status;
}

/**
 * @brief Set MACsec Tx SA next packet number. To readback next PN, call q222x_getTxSA or q222x_getTxSACurrentPN + 1
 *
 * @param[in]	device    PHY pointer
 * @param[in]	txsaIndex Tx SA index
 * @param[in]	pn Packet number
 * @return MRVL_APHY_STATUS.
 *
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS q222x_setTxSANextPN(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_APHY_U64 pn)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 BaseAddr_nextPN;
	if (txsaIndex >= MRVL_Q222X_MSEC_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_nextPN = GETADDR(MRVL_Q222X_MSEC_TX_SA_PN_TABLE_MEM, txsaIndex, MRVL_Q222X_MSEC_RANGE8);
		/* write next PN to register */
		q222x_writeMACReg64(device, BaseAddr_nextPN, pn);
	}

	return status;
}

/**
 * @brief Get MACsec Rx SA current packet number. Support both PN and XPN.
 *
 * @param[in]	device    PHY pointer
 * @param[in]	rxsaIndex Rx SA index
 * @param[out]	pn Packet number
 * @return MRVL_APHY_STATUS. Only when return status is MRVL_APHY_STATUS_OK, the pn is valid.
 *
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS q222x_getRxSACurrentPN(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_APHY_U64* pn)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 BaseAddr_nextPN;
	if (rxsaIndex >= MRVL_Q222X_MSEC_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_nextPN = GETADDR(MRVL_Q222X_MSEC_RX_SA_PN_TABLE_MEM, rxsaIndex, MRVL_Q222X_MSEC_RANGE8);
		/* read next PN value from register */
		q222x_readMACReg64(device, BaseAddr_nextPN, &regVal);
		/* get current PN */
		if (regVal > 0)
		{
			regVal = regVal - 1;
		}
		else
		{
			status = MRVL_APHY_STATUS_ERROR_GENERAL;
		}
	}
	*pn = regVal;
	return status;
}

/**
 * @brief Get MACsec Tx SA current packet number. Support both PN and XPN.
 *
 * @param[in]	device    PHY pointer
 * @param[in]	txsaIndex Tx SA index
 * @param[out]	pn Packet number
 * @return MRVL_APHY_STATUS. Only when return status is MRVL_APHY_STATUS_OK, the pn is valid.
 *
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS q222x_getTxSACurrentPN(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_APHY_U64* pn)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 BaseAddr_nextPN;
	if (txsaIndex >= MRVL_Q222X_MSEC_MAX_SA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_nextPN = GETADDR(MRVL_Q222X_MSEC_TX_SA_PN_TABLE_MEM, txsaIndex, MRVL_Q222X_MSEC_RANGE8);
		/* readback nextPN value from register */
		q222x_readMACReg64(device, BaseAddr_nextPN, &regVal);
		/* get current PN */
		if (regVal > 0)
		{
			regVal = regVal - 1;
		}
		else
		{
			status = MRVL_APHY_STATUS_ERROR_GENERAL;
		}
	}
	*pn = regVal;
	return status;
}


/**
 * @brief Set Rx 32b PN Threshold
 *
 * @param[in]	device      PHY pointer
 * @param[in]	pnThreshold PN threshold
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS q222x_setRxPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U32 pnThreshold)
{
	q222x_writeMACReg32(device, MRVL_Q222X_MSEC_RX_PN_THRESHOLD, pnThreshold);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Set Rx 64b XPN Threshold
 *
 * @param[in]	device      PHY pointer
 * @param[in]	pnThreshold XPN threshold
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS q222x_setRxXPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U64 pnThreshold)
{
	q222x_writeMACReg64(device, MRVL_Q222X_MSEC_RX_XPN_THRESHOLD, pnThreshold);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get Rx 32b PN Threshold
 *
 * @param[in]	device      PHY pointer
 * @param[out]	pnThreshold PN threshold
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS q222x_getRxPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U32* pnThreshold)
{
	q222x_readMACReg32(device, MRVL_Q222X_MSEC_RX_PN_THRESHOLD, pnThreshold);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get Rx 64b XPN Threshold
 *
 * @param[in]	device      PHY pointer
 * @param[out]	pnThreshold PN threshold
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS q222x_getRxXPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U64* pnThreshold)
{
	q222x_readMACReg64(device, MRVL_Q222X_MSEC_RX_XPN_THRESHOLD, pnThreshold);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Set Tx 32b PN Threshold
 *
 * @param[in]	device      PHY pointer
 * @param[in]	pnThreshold PN threshold
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS q222x_setTxPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U32 pnThreshold)
{
	q222x_writeMACReg32(device, MRVL_Q222X_MSEC_TX_PN_THRESHOLD, pnThreshold);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Set Tx 64b XPN Threshold
 *
 * @param[in]	device      PHY pointer
 * @param[in]	pnThreshold PN threshold
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS q222x_setTxXPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U64 pnThreshold)
{
	q222x_writeMACReg64(device, MRVL_Q222X_MSEC_TX_XPN_THRESHOLD, pnThreshold);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get Tx 32b PN Threshold
 *
 * @param[in]	device      PHY pointer
 * @param[out]	pnThreshold PN threshold
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS q222x_getTxPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U32* pnThreshold)
{
	q222x_readMACReg32(device, MRVL_Q222X_MSEC_TX_PN_THRESHOLD, pnThreshold);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get Tx 64b PN Threshold
 *
 * @param[in]	device      PHY pointer
 * @param[out]	pnThreshold PN threshold
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_PN_TH_CNFG
 */
MRVL_APHY_STATUS q222x_getTxXPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U64* pnThreshold)
{
	q222x_readMACReg64(device, MRVL_Q222X_MSEC_TX_XPN_THRESHOLD, pnThreshold);
	return MRVL_APHY_STATUS_OK;
}


/******************************************************************************
 *      Default SCI
 ******************************************************************************/

/**
 * @brief Set Rx default SCI value
 *
 * @param[in]	device PHY pointer
 * @param[in]	sci    Default sci value
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SCI_CNFG
 */
MRVL_APHY_STATUS q222x_setDefaultSCI(MRVL_DEV_PTR device, MRVL_APHY_U64 sci)
{
	q222x_writeMACReg64(device, MRVL_Q222X_MSEC_RX_DEFAULT_SCI, sci);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get Rx default SCI value
 *
 * @param[in]	device PHY pointer
 * @param[out]	sci    Default sci value
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_SCI_CNFG
 */
MRVL_APHY_STATUS q222x_getDefaultSCI(MRVL_DEV_PTR device, MRVL_APHY_U64* sci)
{
	q222x_readMACReg64(device, MRVL_Q222X_MSEC_RX_DEFAULT_SCI, sci);
	return MRVL_APHY_STATUS_OK;
}


/******************************************************************************
 *      Statistics
 ******************************************************************************/

/**
 * @brief Get SMC Rx Statistics
 *
 * @param[in]	device PHY pointer
 * @param[out]	stats  SMC Rx Stats
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS q222x_getRxSMCStats(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_RX_SMC_STATS* stats)
{
	getRxSMCStatsAllCounter(device, stats);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get SMC Tx Statistics.
 *
 * @param[in]	device PHY pointer
 * @param[out]	stats  SMC Tx Stats
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS q222x_getTxSMCStats(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_TX_SMC_STATS* stats)
{
	getTxSMCStatsAllCounter(device, stats);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get WMC Rx Statistics.
 *
 * @param[in]	device PHY pointer
 * @param[out]	stats  WMC Rx Stats
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS q222x_getRxWMCStats(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_RX_WMC_STATS* stats)
{
	getRxWMCStatsAllCounter(device, stats);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get WMC Tx Statistics
 *
 * @param[in]	device PHY pointer
 * @param[out]	stats  WMC Tx Stats
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS q222x_getTxWMCStats(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_TX_WMC_STATS* stats)
{
	getTxWMCStatsAllCounter(device, stats);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Clear SMC and WMC stats.
 *
 * @param[in]	device PHY pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS q222x_clearMIBStats(MRVL_DEV_PTR device)
{
	MRVL_Q222X_MSEC_RX_SMC_STATS rxsmc;
	MRVL_Q222X_MSEC_TX_SMC_STATS txsmc;
	MRVL_Q222X_MSEC_RX_WMC_STATS rxwmc;
	MRVL_Q222X_MSEC_TX_WMC_STATS txwmc;
	MRVL_APHY_U32 regVal;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	q222x_readMACReg32(device, MRVL_Q222X_MSEC_SLC_CFG, &regVal);
	/* Enable SMC/WMC stat read-clear*/
	q222x_writeMACReg32(device, MRVL_Q222X_MSEC_SLC_CFG, regVal | 0x3C000000U);
	/* Read stat to clear*/
	status |= q222x_getRxSMCStats(device, &rxsmc);
	status |= q222x_getTxSMCStats(device, &txsmc);
	status |= q222x_getRxWMCStats(device, &rxwmc);
	status |= q222x_getTxWMCStats(device, &txwmc);
	/* Restore read-clear setting */
	q222x_writeMACReg32(device, MRVL_Q222X_MSEC_SLC_CFG, regVal);
	return status;
}

/**
 * @brief Get RX SecY Statistics
 *
 * @param[in]	device PHY pointer
 * @param[in]	index  SecY index
 * @param[out]	stats  Rx SecY Stats
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS q222x_getRxSecYStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_RX_SECY_COUNTER* stats)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;

	if (index >= MRVL_Q222X_MSEC_MAX_SECY_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* read back counters */
		getRxSecYStatsAllCounter(device, index, stats);
	}

	return status;
}

/**
 * @brief Get TX SecY Statistics
 *
 * @param[in]	device PHY pointer
 * @param[in]	index  SecY index
 * @param[out]	stats  Tx SecY Stats
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS q222x_getTxSecYStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_TX_SECY_COUNTER* stats)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;

	if (index >= MRVL_Q222X_MSEC_MAX_SECY_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* read back all counters */
		getTxSecYStatsAllCounter(device, index, stats);
	}

	return status;
}

/**
 * @brief Get RX SC Statistics.
 *
 * @param[in]	device PHY pointer
 * @param[in]	index  SC index
 * @param[out]	stats  Rx SC Stats
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS q222x_getRxSCStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_RX_SC_COUNTER* stats)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	if (index >= MRVL_Q222X_MSEC_MAX_SC_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		getRxSCStatsAllCounter(device, index, stats);
	}

	return status;
}

/**
 * @brief Get TX SC Statistics
 *
 * @param[in]	device PHY pointer
 * @param[in]	index  SC index
 * @param[out]	stats  Tx SC Stats
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS q222x_getTxSCStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_TX_SC_COUNTER* stats)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U64 regVal = 0;
	MRVL_APHY_U16 BaseAddr_OutPktsProtected, BaseAddr_OutPktsEncrypted;
	if (index >= MRVL_Q222X_MSEC_MAX_SC_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		BaseAddr_OutPktsProtected = GETADDR(MRVL_Q222X_MSEC_OUT_PKTS_PROTECTED, index, MRVL_Q222X_MSEC_RANGE8);
		BaseAddr_OutPktsEncrypted = GETADDR(MRVL_Q222X_MSEC_OUT_PKTS_ENCRYPTED, index, MRVL_Q222X_MSEC_RANGE8);

		q222x_readMACReg64(device, BaseAddr_OutPktsProtected, &regVal);
		stats->outPktsProtected = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;

		q222x_readMACReg64(device, BaseAddr_OutPktsEncrypted, &regVal);
		stats->outPktsEncrypted = regVal & MRVL_Q222X_COUNTERMASK_MACSEC;
	}

	return status;
}

/**
 * @brief Get RX General Statistics per Port
 *
 * @param[in]	device PHY pointer
 * @param[out]	stats  Rx port Stats
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS q222x_getRxMACsecPortStats(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_RX_PORT_COUNTER* stats)
{
	MRVL_APHY_U64 regVal = 0;
	q222x_readMACReg64(device, MRVL_Q222X_MSEC_IN_PKTS_PARSE_ERR, &regVal);
	stats->inPktsParseErr = regVal;
	q222x_readMACReg64(device, MRVL_Q222X_MSEC_IN_PKTS_FLOW_ID_TCAM_MISS, &regVal);
	stats->inPktsFlowIDTCAMMiss = regVal;
	q222x_readMACReg64(device, MRVL_Q222X_MSEC_IN_PKTS_EARLY_PREEMPT_ERR, &regVal);
	stats->inPktsEarlyPreemptErr = regVal;
	q222x_readMACReg64(device, MRVL_Q222X_MSEC_IN_PKTS_FLOW_ID_TCAM_HIT_0, &regVal);
	stats->inPktsFlowIDTCAMHit0 = regVal;
	q222x_readMACReg64(device, MRVL_Q222X_MSEC_IN_PKTS_FLOW_ID_TCAM_HIT_1, &regVal);
	stats->inPktsFlowIDTCAMHit1 = regVal;
	q222x_readMACReg64(device, MRVL_Q222X_MSEC_IN_PKTS_FLOW_ID_TCAM_HIT_2, &regVal);
	stats->inPktsFlowIDTCAMHit2 = regVal;
	q222x_readMACReg64(device, MRVL_Q222X_MSEC_IN_PKTS_FLOW_ID_TCAM_HIT_3, &regVal);
	stats->inPktsFlowIDTCAMHit3 = regVal;

	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get TX General Statistics per Port
 *
 * @param[in]	device PHY pointer
 * @param[out]	stats  Tx port Stats
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS q222x_getTxMACsecPortStats(MRVL_DEV_PTR device, MRVL_Q222X_MSEC_TX_PORT_COUNTER* stats)
{
	MRVL_APHY_U64 regVal = 0;
	q222x_readMACReg64(device, MRVL_Q222X_MSEC_OUT_PKTS_PARSE_ERR, &regVal);
	stats->outPktsParseErr = regVal;
	q222x_readMACReg64(device, MRVL_Q222X_MSEC_OUT_PKTS_FLOW_ID_TCAM_MISS, &regVal);
	stats->outPktsFlowIDTCAMMiss = regVal;
	q222x_readMACReg64(device, MRVL_Q222X_MSEC_OUT_PKTS_EARLY_PREEMPT_ERR, &regVal);
	stats->outPktsEarlyPreemptErr = regVal;
	q222x_readMACReg64(device, MRVL_Q222X_MSEC_OUT_PKTS_FLOW_ID_TCAM_HIT_0, &regVal);
	stats->outPktsFlowIDTCAMHit0 = regVal;
	q222x_readMACReg64(device, MRVL_Q222X_MSEC_OUT_PKTS_FLOW_ID_TCAM_HIT_1, &regVal);
	stats->outPktsFlowIDTCAMHit1 = regVal;
	q222x_readMACReg64(device, MRVL_Q222X_MSEC_OUT_PKTS_FLOW_ID_TCAM_HIT_2, &regVal);
	stats->outPktsFlowIDTCAMHit2 = regVal;
	q222x_readMACReg64(device, MRVL_Q222X_MSEC_OUT_PKTS_FLOW_ID_TCAM_HIT_3, &regVal);
	stats->outPktsFlowIDTCAMHit3 = regVal;

	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Clear all SecY, SC and port stats counter to 0.
 *
 * @param[in]	device PHY pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS q222x_resetAllMACsecStats(MRVL_DEV_PTR device)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 clearStatsValue = 0xF;
	q222x_writeMACReg32(device, MRVL_Q222X_MSEC_TX_STATS_CLEAR, clearStatsValue);
	q222x_writeMACReg32(device, MRVL_Q222X_MSEC_RX_STATS_CLEAR, clearStatsValue);
	return status;
}

/**
 * @brief Clear one RX SecY stats counter to 0.
 *
 * @param[in]	device PHY pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS q222x_clearRxSecYStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index)
{
	MRVL_APHY_U32 regValRx = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_Q222X_MSEC_RX_SECY_COUNTER rxsecy;
	if (index >= MRVL_Q222X_MSEC_MAX_SECY_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		q222x_readMACReg32(device, MRVL_Q222X_MSEC_CSE_CLR_ON_RD_RX, &regValRx);
		q222x_writeMACReg32(device, MRVL_Q222X_MSEC_CSE_CLR_ON_RD_RX, 1);
		status = q222x_getRxSecYStats(device, index, &rxsecy);
		q222x_writeMACReg32(device, MRVL_Q222X_MSEC_CSE_CLR_ON_RD_RX, regValRx);
	}
	return status;
}

/**
 * @brief Clear one TX SecY stats counter to 0.
 *
 * @param[in]	device PHY pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS q222x_clearTxSecYStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index)
{
	MRVL_APHY_U32 regValTx = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_Q222X_MSEC_TX_SECY_COUNTER txsecy;
	if (index >= MRVL_Q222X_MSEC_MAX_SECY_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		q222x_readMACReg32(device, MRVL_Q222X_MSEC_CSE_CLR_ON_RD_TX, &regValTx);
		q222x_writeMACReg32(device, MRVL_Q222X_MSEC_CSE_CLR_ON_RD_TX, 1);
		status = q222x_getTxSecYStats(device, index, &txsecy);
		q222x_writeMACReg32(device, MRVL_Q222X_MSEC_CSE_CLR_ON_RD_TX, regValTx);
	}
	return status;
}

/**
 * @brief Clear one RX SC stats counter to 0.
 *
 * @param[in]	device PHY pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS q222x_clearRxSCStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index)
{
	MRVL_APHY_U32 regValRx = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_Q222X_MSEC_RX_SC_COUNTER rxsc;
	if (index >= MRVL_Q222X_MSEC_MAX_SC_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		q222x_readMACReg32(device, MRVL_Q222X_MSEC_CSE_CLR_ON_RD_RX, &regValRx);
		q222x_writeMACReg32(device, MRVL_Q222X_MSEC_CSE_CLR_ON_RD_RX, 1);
		status = q222x_getRxSCStats(device, index, &rxsc);
		q222x_writeMACReg32(device, MRVL_Q222X_MSEC_CSE_CLR_ON_RD_RX, regValRx);
	}
	return status;
}

/**
 * @brief Clear one TX SC stats counter to 0.
 *
 * @param[in]	device PHY pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_STATS_CTRL
 */
MRVL_APHY_STATUS q222x_clearTxSCStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index)
{
	MRVL_APHY_U32 regValTx = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_Q222X_MSEC_TX_SC_COUNTER txsc;
	if (index >= MRVL_Q222X_MSEC_MAX_SC_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		q222x_readMACReg32(device, MRVL_Q222X_MSEC_CSE_CLR_ON_RD_TX, &regValTx);
		q222x_writeMACReg32(device, MRVL_Q222X_MSEC_CSE_CLR_ON_RD_TX, 1);
		status = q222x_getTxSCStats(device, index, &txsc);
		q222x_writeMACReg32(device, MRVL_Q222X_MSEC_CSE_CLR_ON_RD_TX, regValTx);
	}
	return status;
}

/******************************************************************************
 *      Custom/VLAN Tag
 ******************************************************************************/

/**
 * @brief Set custom/VLAN tag
 *
 * @param[in]	device   PHY pointer
 * @param[in]	isEgress True: egress/tx; False: ingress/rx
 * @param[in]	tag      MRVL_Q222X_MSEC_CUSTOM_TAG struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_TAG_CNFG
 */
MRVL_APHY_STATUS q222x_setCustomVLANTag(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_Q222X_MSEC_CUSTOM_TAG* tag)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U16 tagAddr = MRVL_Q222X_MSEC_VLAN_TAG_PARSER_OFFSET + (MRVL_APHY_U16)tag->index * 2U;
	MRVL_APHY_U16 enAddr = MRVL_Q222X_MSEC_ETYPE_ENABLE;;

	/* Tag size shall be 4 if VLAN tag */
	if (tag->index >= MRVL_Q222X_MSEC_MAX_CUSTOM_TAG_NUM || (tag->isVLANTag == MRVL_APHY_TRUE && tag->size != 4))
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		if (isEgress == MRVL_APHY_TRUE)
		{
			tagAddr += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
			enAddr += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
		}
		else
		{
			tagAddr += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
			enAddr += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
		}

		/* tag fields */
		regVal = ((MRVL_APHY_U32)tag->index << 22)
			| ((MRVL_APHY_U32)((tag->hasBonusData == MRVL_APHY_TRUE) ? 1:0) << 21)
			| ((MRVL_APHY_U32)((tag->isVLANTag == MRVL_APHY_TRUE) ? 1 : 0) << 20)
			| (((MRVL_APHY_U32)tag->size & 0xFU) << 16)
			| (MRVL_APHY_U32)tag->ethType;
		q222x_writeMACReg32(device, tagAddr, regVal);

		/* enable fields*/
		q222x_readMACReg32(device, enAddr, &regVal);
		if (tag->isEnabled == MRVL_APHY_TRUE)
		{
			regVal |= (MRVL_APHY_U32)1U << tag->index;
		}
		else
		{
			regVal &= ~((MRVL_APHY_U32)1U << tag->index);
		}
		q222x_writeMACReg32(device, enAddr, regVal);
	}

	return status;
}

/**
 * @brief Get custom/VLAN tag
 *
 * @param[in]	device   PHY pointer
 * @param[in]	isEgress True: egress/tx; False: ingress/rx
 * @param[in]	index    tag index
 * @param[out]  tag      MRVL_Q222X_MSEC_CUSTOM_TAG struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_TAG_CNFG
 */
MRVL_APHY_STATUS q222x_getCustomVLANTag(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_CUSTOM_TAG* tag)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U16 tagAddr = MRVL_Q222X_MSEC_VLAN_TAG_PARSER_OFFSET + (MRVL_APHY_U16)index * 2U;
	MRVL_APHY_U16 enAddr = MRVL_Q222X_MSEC_ETYPE_ENABLE;

	if (index >= MRVL_Q222X_MSEC_MAX_CUSTOM_TAG_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		if (isEgress == MRVL_APHY_TRUE)
		{
			tagAddr += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
			enAddr += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
		}
		else
		{
			tagAddr += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
			enAddr += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
		}

		/* tag fields */
		q222x_readMACReg32(device, tagAddr, &regVal);
		tag->index = (MRVL_APHY_U8)((regVal >> 22) & 0x7U);
		tag->hasBonusData = (0 != (regVal & 0x200000U)) ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
		tag->isVLANTag = (0 != (regVal & 0x100000U)) ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
		tag->size = (MRVL_APHY_U8) ((regVal & 0xF0000U) >> 16);
		tag->ethType = (MRVL_APHY_U16)(regVal & 0xFFFFU);

		/* enable fields */
		q222x_readMACReg32(device, enAddr, &regVal);
		regVal &=  (MRVL_APHY_U32)1U << index;
		tag->isEnabled = (0 != regVal) ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
	}

	return status;
}


/******************************************************************************
 *      Control Packet
 ******************************************************************************/

/**
 * @brief Set control packet classification with e-type
 *
 * @param[in]	device         PHY pointer
 * @param[in]	isEgress       True: egress/tx; False: ingress/rx
 * @param[in]	classification MRVL_Q222X_MSEC_CTRL_PCKT_ETYPE struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_CTRL_PCKT_CNFG
 */
MRVL_APHY_STATUS q222x_setCtrlPckt_EthType(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_Q222X_MSEC_CTRL_PCKT_ETYPE* classification)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U16 addr = MRVL_Q222X_MSEC_CTRL_PCKT_RULE_ETYPE + (MRVL_APHY_U16)classification->index * 2U;
	MRVL_APHY_U16 addrEnable = MRVL_Q222X_MSEC_CTRL_PCKT_RULE_ENABLE;

	if (classification->index >= MRVL_Q222X_MSEC_MAX_CTRL_PCKT_ETYPE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		if (isEgress == MRVL_APHY_TRUE)
		{
			addr += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
			addrEnable += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
		}
		else
		{
			addr += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
			addrEnable += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
		}

		q222x_writeMACReg32(device, addr, (MRVL_APHY_U32)classification->ethType);

		q222x_readMACReg32(device, addrEnable, &regVal);
		if (classification->isEnabled == MRVL_APHY_TRUE)
		{
			regVal |=  (MRVL_APHY_U32)1U << classification->index;
		}
		else
		{
			regVal &= ~( (MRVL_APHY_U32)1U << classification->index);
		}
		q222x_writeMACReg32(device, addrEnable, regVal);
	}

	return status;
}

/**
 * @brief Get control packet e-type classification information
 *
 * @param[in]	device         PHY pointer
 * @param[in]	isEgress       True: egress/tx; False: ingress/rx
 * @param[in]	index          e-type index
 * @param[out]	classification MRVL_Q222X_MSEC_CTRL_PCKT_ETYPE struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_CTRL_PCKT_CNFG
 */
MRVL_APHY_STATUS q222x_getCtrlPckt_EthType(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_CTRL_PCKT_ETYPE* classification)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U16 addr = MRVL_Q222X_MSEC_CTRL_PCKT_RULE_ETYPE + (MRVL_APHY_U16)index * 2U;
	MRVL_APHY_U16 addrEnable = MRVL_Q222X_MSEC_CTRL_PCKT_RULE_ENABLE;

	if (index >= MRVL_Q222X_MSEC_MAX_CTRL_PCKT_ETYPE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		if (isEgress == MRVL_APHY_TRUE)
		{
			addr += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
			addrEnable += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
		}
		else
		{
			addr += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
			addrEnable += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
		}

		classification->index = index;

		q222x_readMACReg32(device, addr, &regVal);
		classification->ethType = (MRVL_APHY_U16)(regVal & 0xFFFFU);

		q222x_readMACReg32(device, addrEnable, &regVal);
		if (0 == (regVal & ((MRVL_APHY_U32)1U << classification->index)))
		{
			classification->isEnabled = MRVL_APHY_FALSE;
		}
		else
		{
			classification->isEnabled = MRVL_APHY_TRUE;
		}
	}

	return status;
}

/**
 * @brief Set control packet classification with DA
 *
 * @param[in]	device         PHY pointer
 * @param[in]	isEgress       True: egress/tx; False: ingress/rx
 * @param[in]	classification MRVL_Q222X_MSEC_CTRL_PCKT_DA struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_CTRL_PCKT_CNFG
 */
MRVL_APHY_STATUS q222x_setCtrlPckt_DA(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_Q222X_MSEC_CTRL_PCKT_DA* classification)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U64 regVal64 = 0;
	MRVL_APHY_U16 addr = MRVL_Q222X_MSEC_CTRL_PCKT_RULE_DA + (MRVL_APHY_U16)classification->index * 4U;
	MRVL_APHY_U16 addrEnable = MRVL_Q222X_MSEC_CTRL_PCKT_RULE_ENABLE;
	MRVL_APHY_U8 i = 0;

	if (classification->index >= MRVL_Q222X_MSEC_MAX_CTRL_PCKT_DA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		if (isEgress == MRVL_APHY_TRUE)
		{
			addr += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
			addrEnable += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
		}
		else
		{
			addr += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
			addrEnable += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
		}

		for (i = 0; i < MRVL_Q222X_MAC_ADDR_LEN; i++)
		{
			regVal64 += ((MRVL_APHY_U64)classification->DA[5 - i]) << (i * 8);
		}
		q222x_writeMACReg64(device, addr, regVal64);

		q222x_readMACReg32(device, addrEnable, &regVal);
		if (classification->isEnabled == MRVL_APHY_TRUE)
		{
			regVal |= (MRVL_APHY_U32)0x100U << classification->index;
		}
		else
		{
			regVal &= ~((MRVL_APHY_U32)0x100U << classification->index);
		}
		q222x_writeMACReg32(device, addrEnable, regVal);
	}

	return status;
}

/**
 * @brief Get control packet DA classification information
 *
 * @param[in]	device         PHY pointer
 * @param[in]	isEgress       True: egress/tx; False: ingress/rx
 * @param[in]	index          DA index
 * @param[out]	classification MRVL_Q222X_MSEC_CTRL_PCKT_DA struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_CTRL_PCKT_CNFG
 */
MRVL_APHY_STATUS q222x_getCtrlPckt_DA(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_CTRL_PCKT_DA* classification)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U64 regVal64 = 0;
	MRVL_APHY_U16 addr = MRVL_Q222X_MSEC_CTRL_PCKT_RULE_DA + (MRVL_APHY_U16)index * 4U;
	MRVL_APHY_U16 addrEnable = MRVL_Q222X_MSEC_CTRL_PCKT_RULE_ENABLE;
	MRVL_APHY_U8 i = 0;

	if (index >= MRVL_Q222X_MSEC_MAX_CTRL_PCKT_DA_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		if (isEgress == MRVL_APHY_TRUE)
		{
			addr += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
			addrEnable += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
		}
		else
		{
			addr += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
			addrEnable += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
		}

		classification->index = index;

		q222x_readMACReg64(device, addr, &regVal64);

		for (i = 0; i < MRVL_Q222X_MAC_ADDR_LEN; i++)
		{
			classification->DA[5 - i] = (MRVL_APHY_U8)((regVal64 >> (i * 8)) & 0xFFU);
		}

		q222x_readMACReg32(device, addrEnable, &regVal);
		if (0 == (regVal & ((MRVL_APHY_U32)0x100U << classification->index)))
		{
			classification->isEnabled = MRVL_APHY_FALSE;
		}
		else
		{
			classification->isEnabled = MRVL_APHY_TRUE;
		}
	}

	return status;
}

/**
 * @brief Set control packet classification with DA MRVL_Q222X_MSEC_RANGE
 *
 * @param[in] device PHY pointer
 * @param[in] isEgress TRUE: egress/tx; FALSE: ingress/rx
 * @param[in] classification MRVL_Q222X_MSEC_CTRL_PCKT_DA_RANGE
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_CTRL_PCKT_CNFG
 */
MRVL_APHY_STATUS q222x_setCtrlPckt_DARange(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_Q222X_MSEC_CTRL_PCKT_DA_RANGE* classification)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U64 minDa = 0;
	MRVL_APHY_U64 maxDa = 0;
	MRVL_APHY_U16 addr = MRVL_Q222X_MSEC_CTRL_PCKT_RULE_DA_RANGE + (MRVL_APHY_U16)classification->index * 0x10U;
	MRVL_APHY_U16 addrEnable = MRVL_Q222X_MSEC_CTRL_PCKT_RULE_ENABLE;
	MRVL_APHY_U8 i = 0;

	if (classification->index >= MRVL_Q222X_MSEC_MAX_CTRL_PCKT_DA_RANGE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		if (isEgress == MRVL_APHY_TRUE)
		{
			addr += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
			addrEnable += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
		}
		else
		{
			addr += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
			addrEnable += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
		}

		for (i = 0; i < MRVL_Q222X_MAC_ADDR_LEN; i++)
		{
			minDa += ((MRVL_APHY_U64)classification->MIN_DA[5 - i]) << (i * 8);
			maxDa += ((MRVL_APHY_U64)classification->MAX_DA[5 - i]) << (i * 8);
		}
		q222x_writeMACReg64(device, addr, minDa);
		q222x_writeMACReg64(device, addr + MRVL_Q222X_MSEC_REG_BUS_WIDTH, maxDa);

		q222x_readMACReg32(device, addrEnable, &regVal);
		if (classification->isEnabled == MRVL_APHY_TRUE)
		{
			regVal |= 0x10000U << classification->index;
		}
		else
		{
			regVal &= ~(0x10000U << classification->index);
		}
		q222x_writeMACReg32(device, addrEnable, regVal);
	}

	return status;
}

/**
 * @brief Get control packet DA MRVL_Q222X_MSEC_RANGE classification information
 *
 * @param[in]	device         PHY pointer
 * @param[in]	isEgress       True: egress/tx; False: ingress/rx
 * @param[in]	index          DA MRVL_Q222X_MSEC_RANGE index
 * @param[out]	classification MRVL_Q222X_MSEC_CTRL_PCKT_DA_RANGE struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_CTRL_PCKT_CNFG
 */
MRVL_APHY_STATUS q222x_getCtrlPckt_DARange(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_CTRL_PCKT_DA_RANGE* classification)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U64 minDa = 0;
	MRVL_APHY_U64 maxDa = 0;
	MRVL_APHY_U16 addr = MRVL_Q222X_MSEC_CTRL_PCKT_RULE_DA_RANGE + (MRVL_APHY_U16)index * 0x10U;
	MRVL_APHY_U16 addrEnable = MRVL_Q222X_MSEC_CTRL_PCKT_RULE_ENABLE;
	MRVL_APHY_U8 i = 0;

	if (index >= MRVL_Q222X_MSEC_MAX_CTRL_PCKT_DA_RANGE_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		if (isEgress == MRVL_APHY_TRUE)
		{
			addr += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
			addrEnable += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
		}
		else
		{
			addr += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
			addrEnable += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
		}

		classification->index = index;

		q222x_readMACReg64(device, addr, &minDa);
		q222x_readMACReg64(device, addr + MRVL_Q222X_MSEC_REG_BUS_WIDTH, &maxDa);
		for (i = 0; i < MRVL_Q222X_MAC_ADDR_LEN; i++)
		{
			classification->MIN_DA[5 - i] = (MRVL_APHY_U8)((minDa >> (i * 8)) & 0xFFU);
			classification->MAX_DA[5 - i] = (MRVL_APHY_U8)((maxDa >> (i * 8)) & 0xFFU);
		}

		q222x_readMACReg32(device, addrEnable, &regVal);
		if (0 == (regVal & (0x10000U << classification->index)))
		{
			classification->isEnabled = MRVL_APHY_FALSE;
		}
		else
		{
			classification->isEnabled = MRVL_APHY_TRUE;
		}
	}

	return status;
}

/**
 * @brief Set control packet classification with combo settings
 *
 * @param[in]	device         PHY pointer
 * @param[in]	isEgress       True: egress/tx; False: ingress/rx
 * @param[in]	classification MRVL_Q222X_MSEC_CTRL_PCKT_COMBO struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_CTRL_PCKT_CNFG
 */
MRVL_APHY_STATUS q222x_setCtrlPckt_COMBO(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_Q222X_MSEC_CTRL_PCKT_COMBO* classification)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U64 regVal64MIN = 0, regVal64MAX = 0;
	MRVL_APHY_U16 addr = MRVL_Q222X_MSEC_CTRL_PCKT_RULE_COMBO + (MRVL_APHY_U16)classification->index * 0x14U;
	MRVL_APHY_U16 addrEnable = MRVL_Q222X_MSEC_CTRL_PCKT_RULE_ENABLE;
	MRVL_APHY_U8 i = 0;

	if (classification->index >= MRVL_Q222X_MSEC_MAX_CTRL_PCKT_COMBO_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		if (isEgress == MRVL_APHY_TRUE)
		{
			addr += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
			addrEnable += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
		}
		else
		{
			addr += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
			addrEnable += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
		}

		for (i = 0; i < MRVL_Q222X_MAC_ADDR_LEN; i++)
		{
			regVal64MIN += ((MRVL_APHY_U64)classification->MIN_DA[5 - i]) << (i * 8);
			regVal64MAX += ((MRVL_APHY_U64)classification->MAX_DA[5 - i]) << (i * 8);
		}
		q222x_writeMACReg64(device, addr, regVal64MIN);
		q222x_writeMACReg64(device, addr + MRVL_Q222X_MSEC_REG_BUS_WIDTH, regVal64MAX);
		q222x_writeMACReg64(device, addr+ MRVL_Q222X_MSEC_REG_BUS_WIDTH*2, (MRVL_APHY_U64)classification->ethType & 0xFFFFU);

		q222x_readMACReg32(device, addrEnable, &regVal);
		if (classification->isEnabled == MRVL_APHY_TRUE)
		{
			regVal |= 0x100000U << classification->index;
		}
		else
		{
			regVal &= ~(0x100000U << classification->index);
		}
		q222x_writeMACReg32(device, addrEnable, regVal);
	}

	return status;
}

/**
 * @brief Get control packet combo settings classification information
 *
 * @param[in]	device         PHY pointer
 * @param[in]	isEgress       True: egress/tx; False: ingress/rx
 * @param[in]	index          combo index
 * @param[out]	classification MRVL_Q222X_MSEC_CTRL_PCKT_COMBO struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup MSC_CTRL_PCKT_CNFG
 */
MRVL_APHY_STATUS q222x_getCtrlPckt_COMBO(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEgress, MRVL_APHY_U8 index, MRVL_Q222X_MSEC_CTRL_PCKT_COMBO* classification)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regVal = 0;
	MRVL_APHY_U64 regVal64MIN = 0, regVal64MAX = 0;
	MRVL_APHY_U16 addr = MRVL_Q222X_MSEC_CTRL_PCKT_RULE_COMBO + (MRVL_APHY_U16)index * 0x14U;
	MRVL_APHY_U16 addrEnable = MRVL_Q222X_MSEC_CTRL_PCKT_RULE_ENABLE;
	MRVL_APHY_U8 i = 0;

	if (index >= MRVL_Q222X_MSEC_MAX_CTRL_PCKT_COMBO_NUM)
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		if (isEgress == MRVL_APHY_TRUE)
		{
			addr += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
			addrEnable += MRVL_Q222X_MSEC_PEX_TX_SLAVE;
		}
		else
		{
			addr += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
			addrEnable += MRVL_Q222X_MSEC_PEX_RX_SLAVE;
		}

		classification->index = index;

		q222x_readMACReg64(device, addr, &regVal64MIN);
		q222x_readMACReg64(device, addr + MRVL_Q222X_MSEC_REG_BUS_WIDTH, &regVal64MAX);
		for (i = 0; i < MRVL_Q222X_MAC_ADDR_LEN; i++)
		{
			classification->MIN_DA[5 - i] = (MRVL_APHY_U8)((regVal64MIN >> (i * 8)) & 0xFFU);
			classification->MAX_DA[5 - i] = (MRVL_APHY_U8)((regVal64MAX >> (i * 8)) & 0xFFU);
		}
		q222x_readMACReg64(device, addr + MRVL_Q222X_MSEC_REG_BUS_WIDTH*2, &regVal64MIN);
		classification->ethType = (MRVL_APHY_U16)(regVal64MIN & 0xFFFFU);

		q222x_readMACReg32(device, addrEnable, &regVal);
		if (0 == (regVal & (0x100000U << classification->index)))
		{
			classification->isEnabled = MRVL_APHY_FALSE;
		}
		else
		{
			classification->isEnabled = MRVL_APHY_TRUE;
		}
	}

	return status;
}
