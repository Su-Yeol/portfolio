// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_nw_if.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    contains functions to register and create logical interfaces
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                     Include Files
 **********************************************************************/
#include <linux/etherdevice.h>

#include "fp_library.h"
#include "fp_netd.h"


/**********************************************************************
 *                              Extern Declarations                   *
 **********************************************************************/
uint32a fp_host_pkt_cnt;
static inline struct net_device_stats *nfp_dev_get_stats(struct net_device *dev);
static int32a nfp_dev_init(struct net_device *dev);

/****************************************************************************
 *    GLOBAL DECLARATIONS                                                   *
 ****************************************************************************/
/* fp_phy is never referenced except when being set, so could be removed
 * EXCEPT it is referenced by a header, and some other files.
 * thus making the 'static' declaration completely POINTLESS !
 */
static fp_dev_info_t fp_phy[FP_MAX_PORTS];

/* fp_logical_dev is only referenced in "fp_create_logical_interfaces"
 * so could be moved into the function it is used in,
 * EXCEPT it is referenced by a header, and some other files.
 */
fp_dev_info_t  *fp_logical_dev[FP_MAX_PORTS];


/* fp_priv[] is referenced in multiple files
 * thus making the 'static' declaration completely POINTLESS !
 */
static nfp_dev_info_t fp_priv[FP_MAX_PORTS];

#ifdef FP_SWITCH_MODE
fp_IfData_t gIfPorts[MAX_PHY_PORTS][MAX_LOGICAL_IFS];
fp_phyPort_t gPhyPorts[MAX_PHY_PORTS];
#endif

nfp_global_config_t fpathConfig;
struct net_device *fp_phy_addr[FP_MAX_PORTS] = {0};

/* nfp network devices have devices nesting below it, and are a special
 * "super class" of normal network devices; split their locks off into a
 * separate class since they always nest.
 */
#ifdef FP_SWITCH_MODE
int32a dump_packet(struct sk_buff *skb)
{
	int32a i = 0;
	FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO, "DATA Len: %d\n", skb->len);
	for (i = 0; i < skb->len; i++) {
		FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO, "%02x ",
						skb->data[i] & 0xff);
	}
	FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO, "\n");
} /*End of dump_packe() Function*/
#endif

/*****************************************************************************
 * Function name     : nfp_dev_get_stats()
 * Input Parameters  : struct net_device*
 * Output Parameters : -
 * Description       : This function returns device statistics
 * Return            : struct net_device_stats*
 * Changes           : -
 ****************************************************************************/

static inline struct net_device_stats *nfp_dev_get_stats(struct net_device *dev)
{
	return &(NFP_DEV_INFO(dev)->dev_stats);
}

static const struct net_device_ops nfp_netdev_ops = {
	.ndo_init		= nfp_dev_init,
	.ndo_start_xmit		= nfp_dev_hard_start_xmit,
	.ndo_open		= nfp_dev_open,
	.ndo_stop		= nfp_dev_stop,
	.ndo_do_ioctl		= nfp_dev_ioctl,
	.ndo_get_stats		= nfp_dev_get_stats,
	.ndo_change_rx_flags	= nfp_change_rx_flags,
	.ndo_change_mtu		= NULL
};
static int32a npu_get_link_ksettings(	struct net_device *netdev,
					struct ethtool_link_ksettings *cmd)
{
	cmd->base.duplex = DUPLEX_FULL;
	cmd->base.speed = SPEED_100;

	return 0;
}

static struct ethtool_ops nfp_ethtool_ops = {
	.begin			= NULL,
	.complete		= NULL, /* fp_ethtool_complete */
	//.get_settings		= NULL, /* fp_get_settings */
	//.set_settings		= NULL, /* fp_set_settings */
	.get_link_ksettings	= npu_get_link_ksettings,
};

/*****************************************************************************
 * Function name     : nfp_dev_init()
 * Input Parameters  : struct net_device*
 * Output Parameters : -
 * Description       : Function for device intialisation
 * Return            : int
 * Changes           : -
 ****************************************************************************/
static int32a nfp_dev_init(struct net_device *dev)
{
	struct net_device *real_dev = NFP_DEV_INFO(dev)->real_dev;
	/* IFF_BROADCAST|IFF_MULTICAST; ??? */
	dev->flags  = real_dev->flags & ~IFF_UP;
	/* dev->flags  |=IFF_BROADCAST; */
	/* dev->flags  |=IFF_MULTICAST; */
	//dev->iflink = real_dev->ifindex;
	dev->state  =	(real_dev->state & ((1<<__LINK_STATE_NOCARRIER)
					 |  (1<<__LINK_STATE_DORMANT)  )
			) |  (1<<__LINK_STATE_PRESENT);
	return 0;
} /*End of nfp_dev_init() Function*/

/*****************************************************************************
 * Function name     : nfp_dev_open()
 * Input Parameters  : struct net_device*
 * Output Parameters : -
 * Description       : Function for device open
 * Return            : int
 * Changes           : -
 ****************************************************************************/
int32a nfp_dev_open(struct net_device *dev)
{
	nfp_dev_info_t *nfp_priv = NFP_DEV_INFO(dev);
	struct net_device *real_dev = nfp_priv->real_dev;
	int32a err;
	if (!(real_dev->flags & IFF_UP))
		return -ENETDOWN;
	if (ether_addr_equal(dev->dev_addr, real_dev->dev_addr)) {
		err = dev_uc_add(real_dev, dev->dev_addr);
	if (err < 0)
		return err;
	}
	memcpy(nfp_priv->real_dev_addr, real_dev->dev_addr, ETH_ALEN);
	if (dev->flags & IFF_ALLMULTI)
		dev_set_allmulti(real_dev, 1);
	if (dev->flags & IFF_PROMISC)
		dev_set_promiscuity(real_dev, 1);
	return 0;
} /*End of nfp_dev_open() Function*/

/*****************************************************************************
 * Function name     : nfp_dev_stop()
 * Input Parameters  : struct net_device*
 * Output Parameters : -
 * Description       : Function for stop device operations
 * Return            : int
 * Changes           : -
 ****************************************************************************/
int32a nfp_dev_stop(struct net_device *dev)
{
	struct net_device *real_dev = NFP_DEV_INFO(dev)->real_dev;

	dev_mc_unsync(real_dev, dev);
	if (dev->flags & IFF_ALLMULTI)
		dev_set_allmulti(real_dev, -1);
	if (dev->flags & IFF_PROMISC)
		dev_set_promiscuity(real_dev, -1);
	if (ether_addr_equal(dev->dev_addr, real_dev->dev_addr))
		dev_uc_del(real_dev, dev->dev_addr);
	return 0;
} /*End of nfp_dev_stop() Function*/

/*****************************************************************************
 * Function name     : nfp_dev_ioctl()
 * Input Parameters  : struct net_device*,struct ifreq *,int
 * Output Parameters : -
 * Description       : Function for device ioctl  operations
 * Return            : int
 * Changes           : -
 ****************************************************************************/
int32a nfp_dev_ioctl(struct net_device *dev, struct ifreq *ifr, int32a cmd)
{
	struct net_device *real_dev = NFP_DEV_INFO(dev)->real_dev;
	struct ifreq ifrr;
	int32a err = -EOPNOTSUPP;
	strncpy(ifrr.ifr_name, real_dev->name, IFNAMSIZ);
	ifrr.ifr_ifru = ifr->ifr_ifru;
	switch (cmd) {
	case SIOCGMIIPHY:
	case SIOCGMIIREG:
	case SIOCSMIIREG:
		/*if (real_dev->do_ioctl && netif_device_present(real_dev))
		err = real_dev->do_ioctl(real_dev, &ifrr, cmd);*/
		if (real_dev->netdev_ops->ndo_do_ioctl
		&&  netif_device_present(real_dev))
			err = real_dev->netdev_ops->ndo_do_ioctl(real_dev, &ifrr, cmd);
	break;

	case SIOCSHWTSTAMP:
		/* TODO */
		return 0;
	break;
	}
	if (!err)
		ifr->ifr_ifru = ifrr.ifr_ifru;
	return err;
} /*End of nfp_dev_ioctl() Function*/

/*****************************************************************************
 * Function name     : nfp_change_rx_flags()
 * Input Parameters  : struct net_device*,int
 * Output Parameters : -
 * Description       : Function for device rx flags
 * Return            : void
 * Changes           : -
 ****************************************************************************/
void nfp_change_rx_flags(struct net_device *dev, int32a change)
{
	struct net_device *real_dev = NFP_DEV_INFO(dev)->real_dev;
	if (change & IFF_ALLMULTI)
		dev_set_allmulti(real_dev, dev->flags & IFF_ALLMULTI ? 1 : -1);
	if (change & IFF_PROMISC)
		dev_set_promiscuity(real_dev, dev->flags & IFF_PROMISC ? 1 : -1);
} /*End of nfp_change_rx_flags() Function*/

/*****************************************************************************
 * Function name     : nfp_dev_set_multicast_list()
 * Input Parameters  : struct net_device*
 * Output Parameters : -
 * Description       : Function to set device multicast list
 * Return            : void
 * Changes           : -
 ****************************************************************************/

void nfp_dev_set_multicast_list(struct net_device *dev)
{
	dev_mc_sync(NFP_DEV_INFO(dev)->real_dev, dev);
} /*End of nfp_dev_set_multicast_list() Function*/


/*****************************************************************************
 * Function name     : nfp_dev_hard_start_xmit()
 * Input Parameters  : struct sk_buff *,struct net_device *
 * Output Parameters : -
 * Description       : Function for xmit linux processing packet from nfp
 *                     device to fp0 device.
 * Return            : int
 * Changes           : -
 ****************************************************************************/
int32a nfp_dev_hard_start_xmit(struct sk_buff *skb, struct net_device *dev)
{
	struct net_device_stats *stats = nfp_dev_get_stats(dev);
	stats->tx_packets++; /* for statics only */
#ifdef DEBUG_HOST
	pr_debug("XMIT DUMP %s skb: %p\n", dev->name, skb);
#endif
	/* condition fast path flag checking */
	if (skb->fpNf2CacheFlow.fpProcessDone == 0) {
	if (fpathConfig.fastpath == 1)
		fp_flow_process(skb, skb->dev);
	else
		pr_info("fastpath disabled\n");
	}
#if 0
	if (NFP_DEV_INFO(skb->dev)->phyPortNo > 1) {
	dev_kfree_skb(skb);
	return 0;
    }
#endif
	if (NFP_DEV_INFO(skb->dev)->phyPortNo > FP_MAX_PORTS) {
		pr_err("%s: Invalid phyport no at %x\n",
		__func__, NFP_DEV_INFO(skb->dev)->phyPortNo);
		return 0;
	}
	/* xmit with this phyport number in net xmit routine */
	skb->fpNf2CacheFlow.phyno = NFP_DEV_INFO(skb->dev)->phyPortNo;
	/* xmit with this interface number in net xmit routine */
	skb->fpNf2CacheFlow.l2Hash = NFP_DEV_INFO(skb->dev)->ifnum;
#ifdef DEBUG_HOST
	pr_debug("Completed Printing Tx- Packet\n");
	pr_debug("xmit phyno %u %s\n",
	skb->fpNf2CacheFlow.phyno, skb->dev->name);
#endif
	skb->dev = NFP_DEV_INFO(dev)->real_dev;
#ifdef DEBUG_HOST
	pr_info("Transmited to Dev:%s - Packet\n", skb->dev->name);
#endif
	if (netif_queue_stopped(skb->dev))
		netif_wake_queue(skb->dev);
	dev_queue_xmit(skb);
	return 0;
}

/*****************************************************************************
 * Function name     : nfp_setup()
 * Input Parameters  : struct net_device *
 * Output Parameters : -
 * Description       : Function to set ethernet propertis to device.
 * Return            : int
 * Changes           : -
 ****************************************************************************/
void nfp_setup(struct net_device *new_dev)
{
	ether_setup(new_dev);
	new_dev->netdev_ops = &nfp_netdev_ops;
	new_dev->ethtool_ops = &nfp_ethtool_ops;
} /*End of nfp_setup() Function*/

/*****************************************************************************
 * Function name     : unregister_nfp_device()
 * Input Parameters  : struct net_device *
 * Output Parameters : -
 * Description       : Function for unregister nfp device
 * Return            : int
 * Changes           : -
 ****************************************************************************/
int32a unregister_nfp_device(struct net_device *dev)
{
	dev_put(NFP_DEV_INFO(dev)->real_dev);
	unregister_netdev(dev);
	free_netdev(dev);
	return 0;
} /*End of unregister_nfp_device() Function*/

/*****************************************************************************
 * Function name     : register_nfp_device()
 * Input Parameters  : struct net_device *
 * Output Parameters : -
 * Description       : Function for registration of nfp device
 * Return            : fp_dev_info_t*
 * Changes           : -
 ****************************************************************************/
fp_dev_info_t *register_nfp_device(	struct net_device *real_dev,
					uint8 phyPortNo)
{
	struct net_device *new_dev = NULL;
	int8 name[IFNAMSIZ];
	/*Set interface names*/
	strcpy(name, "fp_phy%d");
	new_dev = alloc_netdev(sizeof(nfp_dev_info_t), name,
				NET_NAME_UNKNOWN, nfp_setup);
	if (new_dev == NULL)
		return NULL; /* -ENOBUFS; */
	new_dev->mtu = 1500;/* real_dev->mtu; */
	new_dev->ml_priv = &fp_priv[phyPortNo];
	fp_phy_addr[phyPortNo] = new_dev;
	NFP_DEV_INFO(new_dev)->real_dev = real_dev;
	NFP_DEV_INFO(new_dev)->phyPortNo = phyPortNo;
	NFP_DEV_INFO(new_dev)->dent = NULL;
	/* new_dev->rtnl_link_ops = &vlan_link_ops; */
	register_netdevice(new_dev);
	fp_phy[phyPortNo].priv = new_dev;
	fp_phy[phyPortNo].phyPortNo = phyPortNo;
	fp_phy[phyPortNo].dent = NULL;
	dev_hold(real_dev);
	return &fp_phy[phyPortNo];
} /*End of register_nfp_device() Function*/

/*****************************************************************************
 * Function name     : fp_create_logical_interfaces
 * Input Parameters  : max num of logical ports
 * Output Parameters : -
 * Description       : create logical interfaces corresponding to each phyport
 * Return            :
 * Changes           : -
 ****************************************************************************/
int32a fp_create_logical_interfaces(struct net_device *dev, int32a max_logical_ports)
{
	int32a portno = 0;
	for (portno = 0; portno < max_logical_ports; portno++) {
		if ((EMAC_PORT_LIST_MASK >> portno) & 0x1) {
			fp_logical_dev[portno] = register_nfp_device(dev, portno);
			if (fp_logical_dev[portno] == NULL) {
				FP_DEBUG(DBGP_FEAT_ERR, FP_LOG_EMERG,
				"fp_nw_if: error while creating logical interface\n");
				return -1;
			}
			/* initialize mac address to each logical interface */
			memcpy(fp_logical_dev[portno]->priv->dev_addr,
						dev->dev_addr, ETH_ALEN);
			netif_start_queue(fp_logical_dev[portno]->priv);
			FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO,
					"CREATING LOGICAL INTERFACE at %d\n", portno);
		}
	}
	return 0;
}
/****************************** End of File ***********************************/

