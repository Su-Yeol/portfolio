/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          fp_macros.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    macros definitions
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifndef  _FP_MACROS_H_
#define  _FP_MACROS_H_

#include "global_base_address.h"

#define MAX_FRAME_SIZE (2 * 1024)
/************************************************************************
                             MACROS FOR SWAPPING
************************************************************************/
/* Macro definition changing byte order*/
/* enbale below macro for NGW & hw */
//#define DEBUG_HOST		1
#define DEBUG_PCI		1
#define HW_STATS_EN		1
#define BASE_ADDR		0x00000000

#if 0
#define WSP_SYS_GENERIC_CONTROL				(WSP_GLOBAL_BASE_ADDR + 0x20)
#define WSP_FAIL_STOP_MODE_EN				(WSP_GLOBAL_BASE_ADDR + 0x40)
#define WSP_SAFETY_INTERRUPT_SOURCE			(WSP_GLOBAL_BASE_ADDR + 0x70)
#define WSP_FAILSTOP_INTERRUPT_SOURCE			(WSP_GLOBAL_BASE_ADDR + 0x74)
#define WSP_FAIL_STOP_MODE_INT_SRC			(WSP_GLOBAL_BASE_ADDR + 0x4C)
#define WSP_FW_FAIL_STOP_MODE_INT_SRC			(WSP_GLOBAL_BASE_ADDR + 0x58)
#define WSP_HOST_FORCE_DEBUG_FAIL_STOP_MODE_INT_SRC	(WSP_GLOBAL_BASE_ADDR + 0x68)
#define WSP_ECC_ERR_INT_SRC				(WSP_GLOBAL_BASE_ADDR + 0x78)
#define WSP_NPU_INTERRUPT_SOURCE_REG0			(WSP_GLOBAL_BASE_ADDR + 0x94)
#else
//#define WSP_SYS_GENERIC_CONTROL			WSP_SYS_GENERIC_CONTROL_ADDR
#define WSP_FAIL_STOP_MODE_EN				WSP_FAIL_STOP_MODE_EN_ADDR
#define WSP_SAFETY_INTERRUPT_SOURCE			WSP_SAFETY_INTERRUPT_SOURCE_ADDR
#define WSP_FAILSTOP_INTERRUPT_SOURCE			WSP_FAILSTOP_INTERRUPT_SOURCE_ADDR
#define WSP_FAIL_STOP_MODE_INT_SRC			WSP_FAIL_STOP_MODE_INT_SRC_ADDR
#define WSP_FW_FAIL_STOP_MODE_INT_SRC			WSP_FW_FAIL_STOP_MODE_INT_SRC_ADDR
#define WSP_HOST_FORCE_DEBUG_FAIL_STOP_MODE_INT_SRC	WSP_HOST_FORCE_DEBUG_FAIL_STOP_MODE_INT_SRC_ADDR
#define WSP_ECC_ERR_INT_SRC				WSP_ECC_ERR_INT_SRC_ADDR
#define WSP_NPU_INTERRUPT_SOURCE_REG0			WSP_NPU_INTERRUPT_SOURCE_REG0_ADDR
#endif

#define P4_WSP_GLOBAL_BASE_ADDR			PART4_GLOBAL_BASE_ADDR
#define P4_SFT_WSP_SAFETY_INT_EN		(P4_WSP_GLOBAL_BASE_ADDR + 0xF4)
#define P4_WSP_PARITY_INT_SRC			(P4_WSP_GLOBAL_BASE_ADDR + 0x74)
#define P4_WSP_PARITY_INT_EN			(P4_WSP_GLOBAL_BASE_ADDR + 0x78)
#define P4_WSP_PARITY_REG2_INT_SRC		(P4_WSP_GLOBAL_BASE_ADDR + 0x7c)
#define P4_WSP_PARITY_REG2_INT_EN		(P4_WSP_GLOBAL_BASE_ADDR + 0x80)

#define P4_WDT_INT_SRC				(P4_WSP_GLOBAL_BASE_ADDR + 0x9c)
#define P4_WDT_INT_EN				(P4_WSP_GLOBAL_BASE_ADDR + 0xa0)
#define P4_WDT_REG2_INT_SRC			(P4_WSP_GLOBAL_BASE_ADDR + 0xa4)
#define P4_WDT_REG2_INT_EN			(P4_WSP_GLOBAL_BASE_ADDR + 0xa8)

#define P4_EMAC_1G_WDT_INT_EN			(P4_WSP_GLOBAL_BASE_ADDR + 0x88)
#define P4_EMAC_1G_WDT_INT_SRC			(P4_WSP_GLOBAL_BASE_ADDR + 0x84)
#define P4_EMAC_10G_WDT_INT_SRC			(P4_WSP_GLOBAL_BASE_ADDR + 0x8c)
#define P4_EMAC_25G_WDT_INT_SRC			(P4_WSP_GLOBAL_BASE_ADDR + 0x94)

#define P4_CLASSHW_INGRS_WDT_INT_SRC		(P4_WSP_GLOBAL_BASE_ADDR + 0xac)
#define P4_CLASSHW_INGRS_WDT_INT_EN		(P4_WSP_GLOBAL_BASE_ADDR + 0xb0)

#define P4_WSP_BUS_ERR_INT_SRC			(P4_WSP_GLOBAL_BASE_ADDR + 0x6c)
#define P4_WSP_BUS_ERR_INT_EN			(P4_WSP_GLOBAL_BASE_ADDR + 0x70)

#define P4_WSP_HOST_FORCE_DEBUG_FAIL_STOP_MODE_INT_SRC	(P4_WSP_GLOBAL_BASE_ADDR + 0x2c)
#define P4_WSP_HOST_FORCE_DEBUG_FAIL_STOP_MODE_INT_EN	(P4_WSP_GLOBAL_BASE_ADDR + 0x30)

#define P4_WSP_ECC_ERR_INT_SRC			(P4_WSP_GLOBAL_BASE_ADDR + 0x64)
#define P4_WSP_ECC_ERR_INT_EN			(P4_WSP_GLOBAL_BASE_ADDR + 0x68)

#define P4_EMAC_1G_IGQOS_WDT_INT_SRC		(P4_WSP_GLOBAL_BASE_ADDR + 0xB4)
#define P4_EMAC_1G_IGQOS_WDT_INT_EN		(P4_WSP_GLOBAL_BASE_ADDR + 0xB8)
#define P4_EMAC_10G_IGQOS_WDT_INT_SRC		(P4_WSP_GLOBAL_BASE_ADDR + 0xBC)
#define P4_EMAC_25G_IGQOS_WDT_INT_SRC		(P4_WSP_GLOBAL_BASE_ADDR + 0xC4)

#define P4_WSP_NPU_INTERRUPT_SOURCE_REG0	(P4_WSP_GLOBAL_BASE_ADDR + 0x94)
#define P4_WSP_SAFETY_INTERRUPT_SOURCE		(P4_WSP_GLOBAL_BASE_ADDR + 0x338)
#define P4_WSP_FAILSTOP_INTERRUPT_SOURCE	(P4_WSP_GLOBAL_BASE_ADDR + 0x33c)
#define P4_WSP_FAIL_STOP_MODE_INT_SRC		(P4_WSP_GLOBAL_BASE_ADDR + 0x10)

#define P4_WSP_HOST_FORCE_DEBUG_FAIL_STOP_MODE_INT_SRC	(P4_WSP_GLOBAL_BASE_ADDR + 0x2c)
#define P4_WSP_FW_FAIL_STOP_MODE_INT_SRC		(P4_WSP_GLOBAL_BASE_ADDR + 0x1c)

#define P2_WSP_GLOBAL_BASE_ADDR			PART2_GLOBAL_BASE_ADDR
#define P2_SFT_WSP_SAFETY_INT_EN		(P2_WSP_GLOBAL_BASE_ADDR + 0xF4)
#define P2_WSP_PARITY_INT_SRC			(P2_WSP_GLOBAL_BASE_ADDR + 0x74)
#define P2_WSP_PARITY_INT_EN			(P2_WSP_GLOBAL_BASE_ADDR + 0x78)
#define P2_WSP_PARITY_REG2_INT_SRC		(P2_WSP_GLOBAL_BASE_ADDR + 0x7c)
#define P2_WSP_PARITY_REG2_INT_EN		(P2_WSP_GLOBAL_BASE_ADDR + 0x80)

#define P2_WDT_INT_SRC				(P2_WSP_GLOBAL_BASE_ADDR + 0x9c)
#define P2_WDT_INT_EN				(P2_WSP_GLOBAL_BASE_ADDR + 0xa0)
#define P2_WDT_REG2_INT_SRC			(P2_WSP_GLOBAL_BASE_ADDR + 0xa4)
#define P2_WDT_REG2_INT_EN			(P2_WSP_GLOBAL_BASE_ADDR + 0xa8)

#define P2_EMAC_1G_WDT_INT_EN			(P2_WSP_GLOBAL_BASE_ADDR + 0x88)
#define P2_EMAC_1G_WDT_INT_SRC			(P2_WSP_GLOBAL_BASE_ADDR + 0x84)
#define P2_EMAC_10G_WDT_INT_SRC			(P2_WSP_GLOBAL_BASE_ADDR + 0x8c)
#define P2_EMAC_25G_WDT_INT_SRC			(P2_WSP_GLOBAL_BASE_ADDR + 0x94)

#define P2_CLASSHW_INGRS_WDT_INT_SRC		(P2_WSP_GLOBAL_BASE_ADDR + 0xac)
#define P2_CLASSHW_INGRS_WDT_INT_EN		(P2_WSP_GLOBAL_BASE_ADDR + 0xb0)

#define P2_WSP_BUS_ERR_INT_SRC			(P2_WSP_GLOBAL_BASE_ADDR + 0x6c)
#define P2_WSP_BUS_ERR_INT_EN			(P2_WSP_GLOBAL_BASE_ADDR + 0x70)

#define P2_WSP_HOST_FORCE_DEBUG_FAIL_STOP_MODE_INT_SRC	(P2_WSP_GLOBAL_BASE_ADDR + 0x2c)
#define P2_WSP_HOST_FORCE_DEBUG_FAIL_STOP_MODE_INT_EN	(P2_WSP_GLOBAL_BASE_ADDR + 0x30)

#define P2_WSP_ECC_ERR_INT_SRC			(P2_WSP_GLOBAL_BASE_ADDR + 0x64)
#define P2_WSP_ECC_ERR_INT_EN			(P2_WSP_GLOBAL_BASE_ADDR + 0x68)

#define P2_EMAC_1G_IGQOS_WDT_INT_SRC		(P2_WSP_GLOBAL_BASE_ADDR + 0xB4)
#define P2_EMAC_1G_IGQOS_WDT_INT_EN		(P2_WSP_GLOBAL_BASE_ADDR + 0xB8)
#define P2_EMAC_10G_IGQOS_WDT_INT_SRC		(P2_WSP_GLOBAL_BASE_ADDR + 0xBC)
#define P2_EMAC_25G_IGQOS_WDT_INT_SRC		(P2_WSP_GLOBAL_BASE_ADDR + 0xC4)

#define P2_WSP_NPU_INTERRUPT_SOURCE_REG0	(P2_WSP_GLOBAL_BASE_ADDR + 0x94)
#define P2_WSP_SAFETY_INTERRUPT_SOURCE		(P2_WSP_GLOBAL_BASE_ADDR + 0x338)
#define P2_WSP_FAILSTOP_INTERRUPT_SOURCE	(P2_WSP_GLOBAL_BASE_ADDR + 0x33c)
#define P2_WSP_FAIL_STOP_MODE_INT_SRC		(P2_WSP_GLOBAL_BASE_ADDR + 0x10)

#define P2_WSP_HOST_FORCE_DEBUG_FAIL_STOP_MODE_INT_SRC	(P2_WSP_GLOBAL_BASE_ADDR + 0x2c)
#define P2_WSP_FW_FAIL_STOP_MODE_INT_SRC		(P2_WSP_GLOBAL_BASE_ADDR + 0x1c)


#define P5_WSP_GLOBAL_BASE_ADDR			PART5_GLOBAL_BASE_ADDR
#define P5_SFT_WSP_SAFETY_INT_EN   		(P5_WSP_GLOBAL_BASE_ADDR + 0xF4)
#define P5_WSP_PARITY_INT_SRC 			(P5_WSP_GLOBAL_BASE_ADDR + 0x74)
#define P5_WSP_PARITY_INT_EN			(P5_WSP_GLOBAL_BASE_ADDR + 0x78)
#define P5_WSP_PARITY_REG2_INT_SRC			(P5_WSP_GLOBAL_BASE_ADDR + 0x7c)
#define P5_WSP_PARITY_REG2_INT_EN			(P5_WSP_GLOBAL_BASE_ADDR + 0x80)

#define P5_WDT_INT_SRC 	        		(P5_WSP_GLOBAL_BASE_ADDR + 0x9c)
#define P5_WDT_INT_EN  	        		(P5_WSP_GLOBAL_BASE_ADDR + 0xa0)
#define P5_WDT_REG2_INT_SRC 	        	(P5_WSP_GLOBAL_BASE_ADDR + 0xa4)
#define P5_WDT_REG2_INT_EN  	        	(P5_WSP_GLOBAL_BASE_ADDR + 0xa8)

#define P5_EMAC_1G_WDT_INT_EN			(P5_WSP_GLOBAL_BASE_ADDR + 0x88)
#define P5_EMAC_1G_WDT_INT_SRC			(P5_WSP_GLOBAL_BASE_ADDR + 0x84)
#define P5_EMAC_10G_WDT_INT_SRC			(P5_WSP_GLOBAL_BASE_ADDR + 0x8c)
#define P5_EMAC_25G_WDT_INT_SRC			(P5_WSP_GLOBAL_BASE_ADDR + 0x94)

#define P5_CLASSHW_INGRS_WDT_INT_SRC 		(P5_WSP_GLOBAL_BASE_ADDR + 0xac)
#define P5_CLASSHW_INGRS_WDT_INT_EN 		(P5_WSP_GLOBAL_BASE_ADDR + 0xb0)

#define P5_WSP_BUS_ERR_INT_SRC			(P5_WSP_GLOBAL_BASE_ADDR + 0x6c)
#define P5_WSP_BUS_ERR_INT_EN			(P5_WSP_GLOBAL_BASE_ADDR + 0x70)

#define P5_WSP_HOST_FORCE_DEBUG_FAIL_STOP_MODE_INT_SRC		(P5_WSP_GLOBAL_BASE_ADDR + 0x2c)
#define P5_WSP_HOST_FORCE_DEBUG_FAIL_STOP_MODE_INT_EN		(P5_WSP_GLOBAL_BASE_ADDR + 0x30)

#define P5_WSP_ECC_ERR_INT_SRC			(P5_WSP_GLOBAL_BASE_ADDR + 0x64)
#define P5_WSP_ECC_ERR_INT_EN			(P5_WSP_GLOBAL_BASE_ADDR + 0x68)

#define P5_EMAC_1G_IGQOS_WDT_INT_SRC 		(P5_WSP_GLOBAL_BASE_ADDR + 0xB4)
#define P5_EMAC_1G_IGQOS_WDT_INT_EN 		(P5_WSP_GLOBAL_BASE_ADDR + 0xB8)
#define P5_EMAC_10G_IGQOS_WDT_INT_SRC 		(P5_WSP_GLOBAL_BASE_ADDR + 0xBC)
#define P5_EMAC_25G_IGQOS_WDT_INT_SRC 		(P5_WSP_GLOBAL_BASE_ADDR + 0xC4)

#define P5_WSP_NPU_INTERRUPT_SOURCE_REG0		(P5_WSP_GLOBAL_BASE_ADDR + 0x94)
#define P5_WSP_SAFETY_INTERRUPT_SOURCE   		(P5_WSP_GLOBAL_BASE_ADDR + 0x338)
#define P5_WSP_FAILSTOP_INTERRUPT_SOURCE 		(P5_WSP_GLOBAL_BASE_ADDR + 0x33c)
#define P5_WSP_FAIL_STOP_MODE_INT_SRC    		(P5_WSP_GLOBAL_BASE_ADDR + 0x10)

#define P5_WSP_HOST_FORCE_DEBUG_FAIL_STOP_MODE_INT_SRC 		(P5_WSP_GLOBAL_BASE_ADDR + 0x2c)
#define P5_WSP_FW_FAIL_STOP_MODE_INT_SRC 		(P5_WSP_GLOBAL_BASE_ADDR + 0x1c)

//#define WSP_DEBUG_BUS1_ADDR			(WSP_GLOBAL_BASE_ADDR + 0x3C)

//#define BMU1_CURR_BUF_CNT			0x13803c
//#define BMU2_CURR_BUF_CNT			0x13c03c

/* VLAN (BD) Hash table action entry map:*
 *=======================================*
 * [19:00]         - forward port list
 * [39:20]         - untag list
 * [42:40]         - ucast_hit_action
 * [45:43]         - mcast_hit_action
 * [48:46]         - ucast_miss_action
 * [51:49]         - mcast_miss_action
 * [54:52]         - mstp
 *=======================================*/
#define BRENTRY_FWD_PORT_LIST_START_POS		0
#define BRENTRY_UNTAG_LIST_START_POS		20
#define BRENTRY_UCAST_HIT_ACT_START_POS		40
#define BRENTRY_MCAST_HIT_ACT_START_POS		43
#define BRENTRY_UCAST_MISS_ACT_START_POS	46
#define BRENTRY_MCAST_MISS_ACT_START_POS	49
#define BRENTRY_MSTP_HIT_ACT_START_POS		52

#define BRENTRY_FWD_PORT_LIST_MASK	FWD_PORT_LIST_MASK	/* 00 - 19 */
#define BRENTRY_UNTAG_LIST_MASK		0x000000FFFFF00000	/* 20 - 39 */
#define BRENTRY_UCAST_HIT_ACT_MASK	0x0000070000000000	/* 40 - 42 */
#define BRENTRY_MCAST_HIT_ACT_MASK	0x0000380000000000	/* 43 - 45 */
#define BRENTRY_UCAST_MISS_ACT_MASK	0x0001c00000000000	/* 46 - 48 */
#define BRENTRY_MCAST_MISS_ACT_MASK	0x000E000000000000	/* 49 - 51 */
#define BRENTRY_MSTP_HIT_ACT_MASK	0x0070000000000000	/* 52 - 54 */

#define BRENTRY_ACTION_ENTRY_MASK	0x007FFFFFFFFFFFFF	/* 00 - 54 */

#define STATUS_CMD_DONE			0x00000001
#define STATUS_ENTRY_NOT_FOUND		0x00000002
#define STATUS_INIT_DONE		0x00000004
#define STATUS_ENTRY_ADDED		0x00000008
#define STATUS_ENTRY_MATCH		0x00000010
#define CMD_ENTRY_PORTS_START_POS	16
#define CMD_ENTRY_FIELD_VALID_MASK	0x00001F00

/* !VLAN TABLE MACROS */

/* MAC 2F HASH TABLE MACROs */
/*         MAC Hash table action entry map            *
 * [19:00]           - forward port list              *
 * [23:20]           - TC                             *
 * [26:24]           - fwd_action (ACTION FIELD)      *
 * [27]              - cut through                    *
 * [28]           - reserved for feature block     *
 * [29]              - fresh                          *
 * [30]              - static                         */
#define MAC_2F_ENTRY_FWD_PORT_LIST_MASK		FWD_PORT_LIST_MASK
#define MAC_2F_ENTRY_TC_MASK			0x00F00000
#define MAC_2F_ENTRY_FWD_ACT_MASK		0x07000000
#define MAC_2F_ENTRY_CUT_THROUGH_MASK		0x08000000
#define MAC_2F_ENTRY_FRESH_MASK			0x20000000
#define MAC_2F_ENTRY_STATIC_MASK		0x40000000

# define MAC_2F_ACTION_ENTRY_MASK		0x7FFFFFFF

#define MAC_2F_ENTRY_FWD_PORT_LIST_START_POS	0
#define MAC_2F_ENTRY_TC_START_POS		20
#define MAC_2F_ENTRY_FWD_ACT_START_POS		24
#define MAC_2F_ENTRY_CUT_THROUGH_START_POS	27
#define MAC_2F_ENTRY_FRESH_BIT_POS		29
#define MAC_2F_ENTRY_STATIC_BIT_POS		30
/* !MAC 2F HASH TABLE MACROs */

/************************************************************************
                             MACROS FOR SPANNING STATE
************************************************************************/

// All byte swap "fp_*****" macros removed, now using correct system calls

/************************************************************************
                             HW INFO
************************************************************************/
#define FP_MAX_CLASS_BUFFERS		4
#define FP_CLASS_BUFFSIZE		0x100
#define FP_CLSBUF_HEADROOM		0x70
#define FP_CLASS_MASK			0xf
#ifdef HW_LMEM_ONLY
#define CSR_LMEM_SEC_BUF_OFFSET		0x10
#define FP_CLASS_DATASIZE		0x60
#else
#define FP_CLASS_DATASIZE		0x70
#endif
#define FP_DDR_PKTDATA_OFFSET		0x100
#define ERR_BIT_1			0x00010000
#define ERR_BIT_2			0xF0000000
#define ERR_BIT_3			0xf0000000

#define BRIDGE_HASH_SIZE		0x10
#define MAX_BRIDGE_ENTRIES		0xf
#define MAX_VLAN_ENTRIES		0xf
#define	BR_HASH_TABLE_POOL_SIZE		0x40
#define BR_ENTRIES_POOL_SIZE		0x200

#ifdef ESI32
#ifdef HW_LMEM_BRCM
#define PE_STRUCT_BTABLE_ADDR		0x00000400
#define PE_CONFIG_BRPOOL_HEAD		0x00000418
//#define PE_CONFIG_RTABLE_ADDR		0x00000640
//#define PE_CONFIG_L2TPTABLE_ADDR	0x00000650
//#define PE_CONFIG_PPTPTABLE_ADDR	0x00000660
#define PE_CONFIG_BTABLE_ADDR		0x00000440
#define PE_CONFIG_BENTRY_ADDR		0x00000480
#define PE_CONFIG_VTABLE_ADDR		0x00000680
#define PE_CONFIG_VENTRY_ADDR		0x000006C0
//#define PE_IFSTATS_ADDR		0x00000F8E
//#define PE_FP_STATS_ADDR		0x00000DA0
#define PE_CONFIG_SWITCH_PORT_ADDR	0x000009A0
#define PE_CONFIG_SWITCH_GLOBAL_ADDR	0x000009A0
//#define PE_CONFIG_SWITCH_STATS_ADDR	0x00000e80
#else /*Else of HW_LMEM_BRCM*/
#define PE_STRUCT_BTABLE_ADDR		0x00000600
#define PE_CONFIG_BRPOOL_HEAD		0x00000618
#define PE_CONFIG_RTABLE_ADDR		0x00000640
#define PE_CONFIG_L2TPTABLE_ADDR	0x00000650
#define PE_CONFIG_PPTPTABLE_ADDR	0x00000660
#define PE_CONFIG_BTABLE_ADDR		0x00000680
#define PE_CONFIG_BENTRY_ADDR		0x000006C0
#define PE_CONFIG_VTABLE_ADDR		0x000008C0
#define PE_CONFIG_VENTRY_ADDR		0x00000900
#define PE_IFSTATS_ADDR			0x00000F8E
#define PE_FP_STATS_ADDR		0x00000DA0
#define PE_CONFIG_SWITCH_PORT_ADDR	0x00000be0  /*each port 392bytes,totalports=3 :TOTAL_SIZE:1176bytes,0x498 */
#define PE_CONFIG_SWITCH_GLOBAL_ADDR	0x00000da0  /* TOTAL_SIZE:864bytes,0x360 */
#define PE_CONFIG_SWITCH_STATS_ADDR	0x00000e80  /* TOTAL_SIZE:450bytes,0x1c2 */
#endif /*End of HW_LMEM_BRCM*/
#else /*Else of ESI32*/
#define PE_CONFIG_IFDATA_ADDR		0x8f010480
#define PE_CONFIG_PHYPORT_ADDR		0x8f010400
#define PE_CONFIG_RTABLE_ADDR		0x8f0108e0
#define PE_CONFIG_BTABLE_ADDR		0x8f0108f0
#define PE_IFSTATS_ADDR			0x8f010840
#define PE_CONFIG_SWITCH_PORT_ADDR	0x84000ef0  /*each port 392bytes,totalports=3 :TOTAL_SIZE:1176bytes,0x498 */
#define PE_CONFIG_SWITCH_GLOBAL_ADDR	0x840013a8  /* TOTAL_SIZE:864bytes,0x360 --using 0x88 bytes(136B) */
#define PE_CONFIG_SWITCH_STATS_ADDR	0x840018c0  /* TOTAL_SIZE:450bytes,0x1c2 */
#endif /*End of ESI32*/


#define PCI2PE_ADDR_MASK		0x00ffffff
#define PE_CSR_DATA			0x00620104
#define PE_CSR_ADDR			0x00620100
#define PE_DMEM_ADDR_OFFSET		0x8f010000
#define PE_PMEM_ADDR_OFFSET		0x8f008000

#ifdef ESI32
//#define CLASS_BUS_ACCESS_ADDR		0x00320228
//#define CLASS_BUS_ACCESS_WDATA	0x0032022c
//#define CLASS_BUS_ACCESS_RDATA	0x00320230
//#define CLASS_BUS_ACCESS_BASE_ADDR	0x00320258
#define CLASS_BUS_WDATA_OFFSET		0x84000000
#define CLASS_BUS_RDATA_OFFSET		0x04000000
#endif /*End if ESI32*/


/**********************************************************************
			     PROTOCOL NUMBERS
**********************************************************************
*/
#define PROTOCOL_IP		0x0800
#define PROTOCOL_IPV6		0x86DD
#define PROTOCOL_ARP		0x0806
#define PROTOCOL_RARP		0x08035
#define PROTOCOL_PPPOE		0x8864
#define PROTOCOL_VLAN		0x8100
#define PROTOCOL_IPX		0x8137
#define PROTOCOL_PPP_IP		0x0021
#define FP_ICMP			0x1
#define FP_IGMP			0x2
#define FP_ESP			0x32
#define FP_AH			0x33
#define PROTOCOL_PPP_IPV4	0x0021
#define PROTOCOL_PPP_IPV6	0x0057
#define FP_IPV4			0x4
#define FP_IPV6			0x6
#define FP_TCP			0x6
#define FP_UDP			0x11
#define FP_V6ROUTING_HDR	0x2B
#define FP_ICMPV6		0x3A
#define FP_IPPROTO_IPV6		0x29
#define FP_IPPROTO_GRE		0x2f
#define FP_IPPROTO_IPIP		0x4
#define PPPOE_VER_TYPE_CODE	0x1100 /* ver=1, type=1, code=0 */
#define FP_MSRP_PROTOCOL	0x22ea
#define FP_MVRP_PROTOCOL	0x88f5
#define FP_IEE1722_PROTOCOL	0x22f0

/**********************************************************************
 *                              HDR SIZES
 **********************************************************************
 */
#define ETH_PROTO_SIZE		2
#define ETH_ADDR_SIZE		6
#define ETH_SMAC_DMAC_SIZE	12
#define ETH_HDR_SIZE		14
#define VLAN_HDR_SIZE		4
#define PPPOE_HDR_SIZE		8
#define IPV6_HDR_SIZE		40
#define IPV4_HDR_SIZE		20

#define PARSE_ETH_TYPE		0x1
#define PARSE_VLAN_TYPE		0x2
#define PARSE_PPPOE_TYPE	0x4
#define PARSE_ARP_TYPE		0x8
#define PARSE_MCAST_TYPE	0x10
#define PARSE_IP_TYPE		0x20
#define PARSE_IPV6_TYPE		0x40
#define PARSE_IPV4_TYPE		0x80
#define PARSE_DOS_TYPE		0x100
#define PARSE_IPX_TYPE		0x200
#define PARSE_BCAST_TYPE	0x400
#define PARSE_UDP_FLOW		0x800
#define PARSE_TCP_FLOW		0x1000
#define PARSE_ICMP_FLOW		0x2000
#define PARSE_IGMP_FLOW		0x4000
#define PARSE_FRAG_FLOW		0x8000
#define PARSE_ESP_FLOW		0x20000
#define PARSE_AH_FLOW		0x40000
#define PARSE_PPTP_FLOW		0x80000

#define PARSE_SNOOP_TYPE	0x200000
#define PARSE_L2_SPECIAL_TYPE	0x400000
/* this flag is for firmware purpose */
#define PARSE_ERROR_PKT		0x800000

#define PARSE_IPSEC_FLOW	(PARSE_ESP_FLOW | PARSE_AH_FLOW)
#define PARSE_L3_MISMATCH	0x20000000
#define PARSE_L2_MISMATCH	0x40000000
#define PARSE_INCOMPLETE	0x80000000
#define PARSE_HOFFSET		0xFFFFFF00
#define IF_PARSE_OFFSET		0x0000FFFF
/*Class parse flags */
#define CLASS_PARSE_4RD_PKT	0x1
#define CLASS_PARSE_6RD_PKT	0x2

#define VLAN_ID_OFFSET		0x0FFF
#define RTFET_WR_TIMER		0x10008
#define RTFET_WR_ENTRY		0x10080
#define RTFET_RD		0x80
#define TFLAG_OFF		48
#define END_1			0x3

#define IF_OFFSET		12
#define PHY_OFFSET		8
#define DMEM_MASK		0xFFFFFFF8
#define CHKSUM_UPPER_BYTE	0x100
#define MIN_PKT_SIZE		34
#define PKT_SIZE		1518
#define L2_INDEX		100
#define INTF_INIT_DONE		0x00020000
#define IF_OFF			0x0000FFFF
#define IF_VOFF			0x1
#define IF_SOFF			11
#define START_MEM		0x800000
#define ENDIAN_REG1		0x310050
#define ENDIAN_REG2		0x310054
//#define TX_PCI_DMA		0xa00000
//#define RX_PCI_DMA		0xa03001

/***********************************************************************
 *                              ROUTER
 ***********************************************************************
 */
/* Entry Route Flow Entry State Flags */
#define ENTRY_VALID		0x1
#define ENTRY_UPDATE		0x2
/* Macros For RouteFlow Match Flags */
#define MATCH_UDP_TUPLE		0x1
#define MATCH_TCP_TUPLE		0x2
#define MATCH_IPSEC_TUPLE	0x4
#define MATCH_FRAG_TUPLE	0x8
#define MATCH_GRE_TUPLE		0x10

#define HASH_SINGLE_LEVEL	0x1
#define HASH_TWO_LEVEL		0x2
#define SINGLE_HASH_BASE_ADDR	(CLASS_BASE_ADDR + 0x238)

/*Macros for Route Flow Action Flags */
#define ADD_ETH_HDR		0x1
#define ADD_VLAN_HDR		0x2
#define ADD_PPPOE_HDR		0x4
#define ADD_AH_HDR		0x8
#define ADD_ESP_HDR		0x10
#define ADD_IP_HDR		0x20
#define ADD_IPV6_HDR		0x40

#define SET_TTL_DECREMENT	0x80
#define UPDATE_STATS		0x100
#define UPDATE_TCP_WND		0x200
#define DROP_PKTS		0x400
#define ADD_VLAN1_HDR		0x800

#define CHANGE_TOS		0x10000
#define CHANGE_SIP_ADDR		0x20000
#define CHANGE_SPORT		0x40000
#define CHANGE_DIP_ADDR		0x80000
#define CHANGE_DPORT		0x100000
#define PFE_L2TP_ENCAP		0x200000
#define PFE_PPTP_ENCAP		0x400000
#define ADD_IPSEC_HDR		0x800000
#define DIFFSERV_TC_CONTROL	0x1000000
#define CHANGE_SNAT66_ADDR	0x2000000
#define CHANGE_DNAT66_ADDR	0x4000000
#define ADD_6RD_HEADER		0x8000000
#define ADD_4RD_HEADER		0x10000000

#define ROUTE_ENTRY_INACTIVE	0x4
#define ROUTE_ENTRY_ACTIVE	0x5

#define EXT_HDR_FRAG		0x2c
#define EXT_HDR_HOP		0x00
#define EXT_HDR_DEST		0x3c
#define EXT_HDR_ROUTE		0x2b
#define EXT_HDR_ESP		0x32
#define EXT_HDR_AH		0x33
#define EXT_HDR_MOBILITY	0x87

#define FP_DEFAULT_BLOCK	0x00
#define FP_IPSEC_BLOCK		0x01
#define FP_PTP_BLOCK		0x02
#define FP_NORMAL_EMAC_PKT	0x00

#define FP_IPSEC_EGRESS		1
#define FP_IPSEC_INGRESS	1
/*Using these macros to check incoming packet*/
#define FP_IPSEC_RX_EGRESS	2
#define FP_IPSEC_RX_INGRESS	3
#define NPU_SA_EGRESS_ADDR	0x00200000
#define NPU_SA_INGRESS_ADDR	0x00280000
#define PHYPORT_0		0x0
#define PHYPORT_1		0x1

#define LOGIF_0			0x0
#define LOGIF_1			0x1

//#define FP_IPSEC_PORT		4

#define MAX_POOLMEM_SIZE	0x1000
#define ROUTE_HASH_SIZE		0x400
#define RT_HASH_TABLE_POOL_SIZE	0x1000
#define MAX_RTFLOW_ENTRIES	0x400
#define RT_ENTRIES_POOL_SIZE	0x20000


// new defines
extern uint32 gpcimem_base;
//#define DSP_RAM		0x60000000
//#define DMEM_ADDR_PHY		0x00001D80
//#define DMEM_ADDR_IF		0x00001E10
//#define IPPROTO_TCP		0x6
//#define IPPROTO_UDP		0x11

#define PE_LMEM_ADDR		0x00308000

#define PCI_TO_PE(x) ((((uint32a *)x) != NULL) ? \
                (uint32)virt_to_phys((void *)x):(x))
#define PE_TO_PCI(x) ((((uint32a *)x) != NULL) ? \
                (uint32)phys_to_virt((phys_addr_t)x):(x))

#define ROUTE_PCI_TO_PEL(x) (((x) != 0) ? (x - gpcimem_base + 0xC0000000) : (x))
#define ROUTE_PEL_TO_PCI(x) (((x) != 0) ? (x - 0xC0000000 + gpcimem_base) : (x))

#define PCI_TO_PED(x) (((x) != 0) ? (PE2PEDMEM((x) & ~0x8f040000)) : (x))
#define PED_TO_PCI(x) (((x) != 0) ? (PEDMEM2PE((x))  | 0x8f040000) : (x))


/*LMEM -Address map with pcibase address*/
#define PCI_TO_PEL(x) (((x) != 0) ? (PE2PELMEM((x) - gpcimem_base)) : (x))
#define PEL_TO_PCI(x) (((x) != 0) ? (PELMEM2PE((x)) + gpcimem_base) : (x))


#define RT_ENTRIES_TABLE	0x1
#define RT_HASH_TABLE		0x2
#define BR_ENTRIES_TABLE	0x3
#define BR_HASH_TABLE		0x4
#define VLAN_ENTRIES_TABLE	0x5
#define VLAN_HASH_TABLE		0x6

#define ROUTE_ENTRY_VALID	0x1
#define ROUTE_ENTRY_IPV6_VALID	0x2


/**********************************************************************
                              BRIDGE
***********************************************************************/
#define BRENTRY_STATIC_BIT		0x80000000	// This bit represents bridge's MAC or dynamic MAC
							// bridge's MACs will have this bit set

#define BRENTRY_STATUS_BIT		0x00010000	//dynamic learnt MAC entry's status bit
//Macros For BridgeFlow Match Flags
#define MATCH_MAC_ADDR			0x1	//0
#define MATCH_MAC_VLAN			0x2	//1
//Entry Bridge Flow Entry State Flags
#define ENTRY_VALID			0x1	//0 Entry valid
#define ENTRY_INVALID			0x2	//1 Entry need update from slow path
//Macros for Bridge Flow Action Flags
#define INSERT_VLAN			0x1	//0
#define DELETE_VLAN			0x2	//1
#define DO_MCAST			0x4	//2
#define DO_ROUTING			0x8	//3
//Macros for Bridge Flow Class Notify Flags
#define BRIDGE_ENTRY_INACTIVE		0x1	//0 Not Recieving traffic
#define BRIDGE_ENTRY_ACTIVE		0x2	//1 Recieving traffic
#define STATIC_BRIDGE_ENTRY		0x1	//1 Recieving traffic
#define DYNAMIC_BRIDGE_ENTRY		0x2	//1 Recieving traffic

/* tpid defines */
#define VLAN_TAGGED_FRAME		0x8100
#define PROVIDER_BRIDGING_FRAME		0x88a8
#define QinQ_9100_FRAME			0x9100
#define QinQ_9200_FRAME			0x9200

#define STPID0				0x5500	/* Not Used by Anyone in IEEE page */
#define STPID1				0x5501	/* http://standards.ieee.org/develop/regauth/ethertype/eth.txt */
#define STPID2				0x5502
#define STPID1_START_POS		16

/*************************************************************************
                                CONFIG PARAMS
 *************************************************************************/

#endif /*End of  _FP_MACROS_H_ File*/
