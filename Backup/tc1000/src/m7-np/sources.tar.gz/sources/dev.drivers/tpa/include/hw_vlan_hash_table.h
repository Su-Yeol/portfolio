/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          hw_vlan_hash_table.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    API for vlan hash table
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifndef  _HW_VLAN_HASH_TABLE_H_
#define  _HW_VLAN_HASH_TABLE_H_

#include "fp_global_addr_map.h"

/* HW MAC TABLE CMDS */
#define CMD_INIT	1
#define CMD_ADD		2
#define CMD_DEL		3
#define CMD_UPDATE	4
#define CMD_SEARCH	5
#define CMD_MEM_READ	6
#define CMD_MEM_WRITE	7
#define CMD_FLUSH	8

#define CLR_STATUS_REG		0xFFFFFFFF

/* Vlan group table is common for all hash tables */
#define VLAN_INIT_HEAD_PTR	0x100UL
#define VLAN_INIT_TAIL_PTR	0x1ffUL
#define VLAN_FREE_LIST_ENTRIES	0x100UL

#define  VLAN_HASH_ENTRIES	0x100
#define  VLAN_COLL_HASH_ENTRIES	0x100

int32 wsp_vlan_entry_search(uint32a vlanid);

int32a wsp_vlan_entry_add(uint32a field_entries[5],
			uint32a portNo,
			uint64 action_entry,
			uint32a field_valids);

int32a wsp_vlan_entry_add_all_tables(uint32a field_entries[5],
					uint32a portNo,
					uint64 action_entry,
					uint32a field_valids);

int32a wsp_vlan_entry_delete(uint32a field_entries[5], uint32a field_valids);
int32a wsp_vlan_entry_update(uint32a field_entries[5], uint64 brentry, uint32a field_valids);
void wsp_vlan_hash_table_init(uint32a table_num);

#endif /*End of _HW_HASH_TABLE_H_*/


