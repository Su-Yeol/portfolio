/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          fp_switch.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    Structures for hw switch
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifndef  _FP_HW_SW_H_
#define  _FP_HW_SW_H_

#include <fp_macros.h>
#include <fp_port.h>
#include "tables_config.h"

/**********************************************************************
 *                                      #defines
 **********************************************************************/
#define STATIC_FLAG_SET		0x40000000
#define FRESH_FLAG_SET		0x00000000
#define FRESH_FLAG_MASK		0x20000000
#define HASH_CNT_PER_ITERATION	TWO_FIELD_HASH_ENTRIES
//#define CLASS_HW_GLOBAL_CUTTHRU_REG (CLASS_HW_BASE_ADDR + 0x000004b0)

/* Below macros are used when we serach with memread */
#define HASH_ENTRY_VLAN_SET_FLAG	0x02000000	/* MAC3: VLAN FIELDVALID BIT */
#define HASH_ENTRY_VALID_FLAG		0x08000000	/* MAC4: ENTRY VALID BIT */
#define HASH_ENTRY_COLL_FLAG		0x04000000	/* MAC4: HASH_ENTRY_COLL_FLAG*/
#define HASH_ENTRY_FRESH_FLAG		0x04000000	/* */
#define HASH_ENTRY_STATIC_FLAG		0x08000000	/* */

/* port related defines */
#define DEF_PORT_FALLBACK_BD_ID		0x1		/* iports fallback bd id */
#define GLOBAL_BRENTRY_FWD_ACTION	ACT_FLOOD
#define GLOBAL_BR_ENTRY_UNTAGLIST	0x00

#define GLOBAL_BR_ENTRY_PORTLIST	FWD_PORT_LIST_MASK
#define CUT_THRU_PORTLIST		0x40
#define GLOBAL_L2_SPL_PUNT_ACT		0x01

#define STP_CTRL_REG_VAL		0x000000C0	/*[7:6]-l2spl0/1 selection bits*/
#define STP_MAC_ADDR1_LSB		0xc2000000
#define STP_MAC_ADDR1_MSB		0x00000180
#define STP_MAC_MASK1_LSB		0xFFFFFFF0
#define STP_MAC_MASK1_MSB		0x0000FFFF

#define STP_MAC_ADDR2_LSB		0xc2000000	// 0x0180c200
#define STP_MAC_ADDR2_MSB		0x00000180
#define STP_MAC_MASK2_LSB		0xFFFFFFF0
#define STP_MAC_MASK2_MSB		0x0000FFFF


#define PORT_TPID_START_POS			0
#define PORT_FALLBACK_BDID_START_POS		16
#define PORT_SHUTDOWN_START_POS			0
#define PORT_AFT_START_POS			4
#define PORT_BLOCKSTATE_START_POS		8
#define PORT_DEF_CFI_START_POS			12
#define PORT_DEF_PRI_START_POS			13
#define PORT_DEF_TC_START_POS			16
#define PORT_TRUSTED_START_POS			19
#define PORT_VID_PREFIX_START_POS		20
#define PORT_UNTAG_FROM_BTABLE_START_POS	21

#define PORT_TPID_MASK			0x0000FFFF
#define PORT_FALLBACK_BDID_MASK		0x1FFF0000
#define PORT_SHUTDOWN_MASK		0x00000001
#define PORT_AFT_MASK			0x000000F0
#define PORT_BLOCKSTATE_MASK		0x00000F00
#define PORT_DEF_CFI_MASK		0x00001000
#define PORT_DEF_PRI_MASK		0x0000E000
#define PORT_DEF_TC_MASK		0x00070000
#define PORT_TRUSTED_MASK		0x00080000
#define PORT_VID_PREFIX_MASK		0x00100000
#define PORT_UNTAG_FROM_BTABLE_MASK	0x00200000


#define	PUNT_L2_SPECIAL		0x0001	/* L2 protocol frame (e.g. STP BPDU) */
#define	PUNT_SA_MISS		0x0002	/* SA miss in the MAC table, need to learn MAC */
#define	PUNT_SA_RELEARN		0x0004	/* SA found on different port, need to relearn MAC */
#define	PUNT_SA_IS_ACTIVE	0x0008	/* SA is active, need to set Fresh bit to zero */
#define	PUNT_SNOOP_UPPER	0x0010	/* upper layer protocol snoop */
#define	PUNT_REQUESTED		0x0020
#define	PUNT_MGMT		0x0040
#define	PUNT_IGMP		0x0080
#define	PUNT_FLOOD		0x0100
#define	PUNT_PARSE		0x0200


/*
 * ethernet frame structure
 */
struct frame_s {
	uint8	da[6];
	uint8	sa[6];
	uint16	etype;
	uint16	u16_after_etype;
	/* don't care about the rest of the frame here */
};


/*
 * TODO: mac address entry we are not using it right now
 */
struct mac_entry_s {
	uint16 forward_list;		/* forward_list has a bit flag corresponding
						 * to each port; bit 0 denotes the host
						 * itself
						 */
	uint32a static_flag;		/* static entries do not age out */
	uint32a fresh;			/* indicates address is active (0=active) */
	uint16 cutthru_rewrite;		/* indicates etype/tpid will be rewritten
						 * on some egress ports
						 */
	enum fwd_action_e hit_action;		/* forwarding action override
						 * to perform upon DA hit;
						 * default is ACT_DO_BD_ACT
						 */
	uint32a tc;			/* For Static Entries, priority (TC) of the
						 * packet can be given here
						 */
	/* TODO: need to add some control flags - stpstate, macflush*/
};

extern struct global_s fp_global;
extern struct port_s fp_port[FP_MAX_SWITCH_PORTS];
//int32a getFwdPortList(pktBuf_t *pkt_buff, uint32a vlanid);
#if 0
/*
 * L2 special/reserved addresses are in the range of
 * 01-80-c2-00-00-00 to 01-80-c2-00-00-0f
 */
uint32a is_l2_special_mac_address (uint8 *mac_addr)
{
	static uint8 l2_special_addr[6] = { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x00 };
	int32a i;
	for (i=0; i < 5; i++) {
		if (mac_addr[i] != l2_special_addr[i]) {
			return (FALSE);
		}
	}
	if ((mac_addr[5] & ~0x0f) != l2_special_addr[5]) {
		return (FALSE);
	}
	return (TRUE);
}

/*
 * determines whether this frame should be allowed (vs. discarded),
 * based on the AFT setting
 */
uint32a aft_allow (aft_e aft, uint32a is_frame_tagged)
{
	if (aft == ANY_TAGGING) {
		/* port is set to allow any frame to pass */
		return (TRUE);
	}
	else if (is_frame_tagged) {
		return (aft == TAGGED_ONLY);
	} else {
		return (aft == UNTAGGED_ONLY);
	}
}

void push_vlan (frame_s *frame, uint16 tpid, uint16 vid)
{
	/* TODO: need to handle the VLAN 0 case */
	/* TODO: need to handle L2 CoS priority */
	/* insert 4 bytes starting at frame offset 12 (location of etype) */
	insert_4_bytes(frame, offsetof(frame, etype));
	frame->etype = tpid;
	frame->u16_after_etype = vid;
}
#endif

typedef struct rc_stats_s {
	uint32a hw_hash_entry_count;
	uint32a hw_vlan_entry_count;
	uint32a l2_spl_cnt;
	uint32a sa_miss_cnt;
	uint32a sa_relearn_cnt;
	uint32a sa_is_active_cnt;
	uint32a snoop_upper_cnt;
	uint32a requested_cnt;
	uint32a mgmt_cnt;
	uint32a igmp_cnt;
	uint32a flood_cnt;
	uint32a parse_cnt;
	uint32a fwd_cnt;
	uint32a drop_cnt;
} rc_stats_t;

extern struct rc_stats_s fp_rc_stats;
extern uint8 *getPciBaseAddr(void *);
extern uint8 *fp_net_dev;
uint32a fp_update_mac_refresh_bit(uint32a action_entry);
void fp_get_port_addr(uint32a i, uint32a *addr1, uint32a *addr2);
#endif /*End of _FP_HW_SW_H_ */

