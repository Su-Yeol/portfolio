/*
 * Copyright Telechips Inc.
 *
 * TCC Version 1.0
 *
 * This source code contains confidential information of Telechips.
 *
 * Any unauthorized use without a written permission of Telechips including not
 * limited to re-distribution in source or binary form is strictly prohibited.
 *
 * This source code is provided "AS IS" and nothing contained in this source code
 * shall constitute any express or implied warranty of any kind, including without
 * limitation, any warranty of merchantability, fitness for a particular purpose
 * or non-infringement of any patent, copyright or other third party intellectual
 * property right.
 * No warranty is made, express or implied, regarding the information's accuracy,
 * completeness, or performance.
 *
 * In no event shall Telechips be liable for any claim, damages or other
 * liability arising from, out of or in connection with this source code or
 * the use in the source code.
 *
 * This source code is provided subject to the terms of a Mutual Non-Disclosure
 * Agreement between Telechips and Company.
 */

#ifndef TPA_API_H_
#define TPA_API_H_

/****************************************
 *				Include					*
 ****************************************/
#include <FreeRTOS.h>
#include <task.h>
#include <bsp.h>
#include <sal_com.h>

/****************************************
 *				Defines					*
 ****************************************/

/****************************************
 *				Enumeration				*
 ****************************************/
typedef enum {
	eTPA_RET_OK,
	eTPA_RET_UNKNOWN_ERROR,
	eTPA_RET_INVALID_PARAM,
	eTPA_RET_NOT_ENOUGH_BUFFER,
	eTPA_RET_NO_DATA,
	eTPA_RET_FAIL_TO_CREATE,
	eTPA_RET_ERROR_INT_REG_HANDLER,
	eTPA_RET_ERROR_INT_ENABLE
} eTPA_RET_t;

/****************************************
 *				Typedefs				*
 ****************************************/

/***************************************************
*			Function declaration				*
****************************************************/
extern eTPA_RET_t tpa_init(void);
extern eTPA_RET_t tpa_deinit(void);
extern eTPA_RET_t tpa_open(TaskHandle_t appRxTaskHandler);	// on processor task
extern eTPA_RET_t tpa_close(void);
extern eTPA_RET_t tpa_write(uint8 *buffer, uint16 size);
extern eTPA_RET_t tpa_read(uint8 *buffer, uint16 buffer_size, uint16 *read_size);
extern void tpa_reg_dump(void);
extern void tpa_reg_dump_xgmac(int id);
extern void tpa_serdes_reg_dump(void);
extern void tpa_phy_status(int num);

#endif // TPA_API_H_
