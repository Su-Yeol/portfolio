/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          nc_conf_api.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    his file contains prototypes to handle fpath config
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifndef _FP_CONF_API_H_
#define _FP_CONF_API_H_

#include "fp_types.h"
#include "nc_conf.h"

typedef enum {
	nc_ret_ok,
	nc_ret_fail,
	nc_ret_fail_no_mem,
	nc_ret_fail_tbl_type_invalid,
	nc_ret_fail_tbl_id_invalid,
	nc_ret_fail_tbl_refcnt_nonzero,
	nc_ret_fail_too_many_tbls,
	nc_ret_fail_tbl_not_found,
	nc_ret_fail_mtype_invalid,
	nc_ret_fail_pidx_invalid,
	nc_ret_fail_ifidx_invalid,
	nc_ret_fail_ifmode_invalid,
	nc_ret_fail_iftype_invalid,
} nc_ret_t;

/*
 * nc_create_table creates a table of specified type and given size and returns
 * the table id
 */
nc_ret_t nc_create_table(fp_table_type_t table_type, uint16 table_size, uint16 *table_id);

/*
 * nc_delete_table deletes a specific table given a table id and its type
 */
nc_ret_t nc_delete_table(fp_table_type_t table_type, uint16 table_id);

/*
 * nc_get_table_count retuns number of tables created of specificed type
 */
uint16 nc_get_table_count(fp_table_type_t table_type);

/*
 * nc_get_table_info() returns table info for a given table id and type
 */
nc_ret_t nc_get_table_info(fp_table_type_t table_type, uint16 table_id, nc_table_info_t *table_info);

/*
 * nc_get_router_tables_info() returns a summary of each of the router tables
 * in the system
 */
uint16 nc_get_router_tables_info(int32a num_tables, nc_table_info_t *table_info);

/*
 * nc_get_brige_tables_info() returns a summary of each of the bridge tables
 * in the system
 */
uint16 nc_get_brige_tables_info(int32a num_tables, nc_table_info_t *table_info);

/*
 *  for each table of given type, nc_get_tables_info() fills nc_table_info_t
 *  structure that contains a summarized information about that table and
 *  returns number of such tables it summarized.
 *
 *  Note that memory for nc_table_info_t for num_tables is allocated by
 *  the caller.
 */
int32a nc_get_tables_info(fp_table_type_t table_type, int32a num_tables, nc_table_info_t *table_info);

/*
 * nc_get_router_table_entries() returns route entries from a specific table
 */
int32a nc_get_router_table_entries(uint16 table_id, int32a num_entries, nc_router_entry_t *router_entries);

/*
 * nc_get_bridge_table_entries() returns bridge entries from a specific table
 */
int32a nc_get_bridge_table_entries(uint16 table_id, int32a num_entries, nc_bridge_entry_t *bridge_entries);

/*
 * nc_set_port_media_type() sets a given ports media type to one of
 * IF_MEDIA_ATM/IF_MEDIA_ETHERNET/IF_MEDIA_WLAN/IF_MEDIA_GPON
 */
nc_ret_t nc_set_port_media_type(uint32a pidx, uint32a mtype);

/*
 * nc_set_ifl_in_route_mode() sets a given interface to IF_ROUTE mode.
 *
 * NOTE: A given interface can be in multiple modes at the same time, but
 *       we don't support it currently.
 */
nc_ret_t nc_set_ifl_in_route_mode(uint32a pidx, uint32a ifidx);

/*
 * nc_del_ifl_from_route_mode() deletes a given interface from IF_ROUTE mode
 * and brings the ifl down.
 *
 * NOTE: In the current implementation, an ifl has to be either in route or
 *       bridge mode, otherwise it won't be up at all
 */
nc_ret_t nc_del_ifl_from_route_mode(uint32a pidx, uint32a ifidx);

/*
 * nc_set_intf_type() sets a given interface type to one of
 * IF_ETH/IF_VLAN/IF_PPPOE/IF_PPPOE_VLAN/IF_IPOA/IF_PPPOA/IF_PPPOE_ATM/
 * IF_PPPOE_VLAN_ATM/IF_ETHOA
 */
nc_ret_t nc_set_intf_type(uint32a pindx, uint32a ifidx, uint32a iftype);

#if 0
nc_ret_t nc_set_intf_name(uint32a pindx, uint32a ifidx, int8[] name);

nc_ret_t nc_set_intf_mac_addr(uint16 port_indx, uint16 intf_indx,
                              [] mac_adddr);
#endif

/*
 * nc_get_port_info() returns port information given a port index
 */
nc_ret_t nc_get_port_info(uint32a pidx, nc_port_info_t *pinfo);

/*
 * nc_get_ports_info() returns port information of first num_ports
 */
nc_ret_t nc_get_ports_info(uint32a *num_ports, nc_port_info_t *pinfo);

/*
 * given a port index and logical interface index, nc_get_portidx_ifidx_info()
 * returns interface information
 */
nc_ret_t nc_get_portidx_ifidx_info(uint32a pidx, uint32a ifidx, nc_ifl_info_t *ifinfo);

/*
 * given a port index, this API returns logical interface information of first
 * num_ifls on that port
 */
nc_ret_t nc_get_portidx_ifinfo(uint32a pidx, uint32a *num_ifls, nc_ifl_info_t *ifinfo);

/*
 * nc_get_port_ifinfo() returns logical interface information of first
 * num_ifls of all ports
 */
nc_ret_t nc_get_port_ifinfo(uint32a *num_ifls, nc_ifl_info_t *ifinfo);

/*
 * nc_set_trace_flags() enables or disables certain debug flags in fpath
 * module based on user issued debug commands
 */
void nc_set_trace_flags(uint32a trace_flags, uint8 enable);

/*
 * nc_set_trace_level() sets trace level of fpath module to user configured
 * trace level
 */
void nc_set_trace_level(uint32a trace_level);

/*
 * handler for "set port <port-id> <port-name>" command
 */
nc_ret_t nc_set_port_name(uint32a pidx, int8 *name);

#endif /*End of _FP_CONF_API_H_ File*/

