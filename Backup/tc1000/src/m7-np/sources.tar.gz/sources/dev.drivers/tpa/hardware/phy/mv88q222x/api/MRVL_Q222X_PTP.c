/**
 * @file MRVL_Q222X_PTP.c
 * @brief Q222X PTP API Source File
 * DUT PTP configuration and status checking
 *
 * @par Copyright and Version
 * See MRVL_Q222X_Copyright_and_Version.h
 */

#include "MRVL_Q222X_PTP.h"

/******************************************************************************
 *     PTP reg access and static function
 ******************************************************************************/

/**
 * @brief Read out a 16b value from a PTP port register through XMDIO interface.
 * @param [in]	device PHY pointer
 * @param [in]	offset PTP port register offset
 * @param [out]	data   Data pointer, function modifies this pointer to reflect readback value
 * @return void
 *
 */
/* polyspace +1 CODE-METRICS:CALLING [Justified] "Deviation ASH-926" */
STATIC void ptpPortRegRead(MRVL_DEV_PTR device, MRVL_APHY_U16 offset, MRVL_APHY_U16* data)
{
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_PTP_BASE_DEV, MRVL_Q222X_PTP_PORT_0_REG_ADDR + offset, data);
}

/**
 * @brief Write a 16b value into a PTP port register through XMDIO interface.
 * @param [in]	device PHY pointer
 * @param [in]	offset PTP port register offset
 * @param [out]	data   16b value to write into register
 * @return void
 *
 */
/* polyspace +1 CODE-METRICS:CALLING [Justified] "Deviation ASH-926" */
STATIC void ptpPortRegWrite(MRVL_DEV_PTR device, MRVL_APHY_U16 offset, MRVL_APHY_U16 data)
{
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_PTP_BASE_DEV, MRVL_Q222X_PTP_PORT_0_REG_ADDR + offset, data);
}

/**
 * @brief Read out a 16b value from a PTP global register through XMDIO interface.
 * @param [in]	device PHY pointer
 * @param [in]	offset PTP global register offset
 * @param [out]	data   Data pointer, function modifies this pointer to reflect readback value
 * @return void
 *
 */
STATIC void ptpGlobalRegRead(MRVL_DEV_PTR device, MRVL_APHY_U16 offset, MRVL_APHY_U16* data)
{
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_PTP_BASE_DEV, MRVL_Q222X_PTP_GLOBAL_REG_ADDR + offset, data);
}

/**
 * @brief Write a 16b value into a PTP global register through XMDIO interface.
 * @param [in]	device PHY pointer
 * @param [in]	offset PTP global register offset
 * @param [out]	data   16b value to write into register
 * @return void
 *
 */
/* polyspace +1 CODE-METRICS:CALLING [Justified] "Deviation ASH-926" */
STATIC void ptpGlobalRegWrite(MRVL_DEV_PTR device, MRVL_APHY_U16 offset, MRVL_APHY_U16 data)
{
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_PTP_BASE_DEV, MRVL_Q222X_PTP_GLOBAL_REG_ADDR + offset, data);
}

/**
 * @brief This function is used to read specific PTP/TAI registers by readplus(MANAGEMENT INTERFACE 2).
 *  Some PTP/TAI registers can only be read by readplus
 *  For example: PTP global register offset 0x10 to 0x1E, TAI global register offset 0xE & 0xF.
 * @param [in]	device PHY pointer
 * @param [in]	type   Module, TAI/PTP Global/PTP Port
 * @param [in]	offset Register offset
 * @param [in]	size   Data size, 16-bits/32-bits/64-bits
 * @param [out]	data   Data pointer, function modifies this pointer to reflect readback value
 * @return void
 *
 */
STATIC void regReadPlus(MRVL_DEV_PTR device, MRVL_Q222X_PTP_READ_PLUS_TYPE type, MRVL_APHY_U16 offset, MRVL_Q222X_PTP_READ_PLUS_SIZE size, MRVL_APHY_U64* data)
{
	MRVL_APHY_U16 regVal16 = 0;
	MRVL_APHY_U16 readPlusEnFormatRegData = 0;
	MRVL_APHY_U16 readPlusEnRegPtpPort = 0;
	MRVL_APHY_U8 i = 0;

	if (MRVL_Q222X_PTP_READ_PLUS_TYPE_TAI == type)
	{
		readPlusEnRegPtpPort = 0xEU;
	}
	else if (MRVL_Q222X_PTP_READ_PLUS_TYPE_GLOBAL == type)
	{
		readPlusEnRegPtpPort = 0xFU;
	}
	else
	{
		readPlusEnRegPtpPort = 0;
	}
	readPlusEnFormatRegData = (MRVL_APHY_U16)0x8000U | (readPlusEnRegPtpPort << 8) | (offset & (MRVL_APHY_U16)0x001FU);

	/* register to read */
	ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_RD_PLUS_CMD, readPlusEnFormatRegData);

	*data = 0;
	for (i = 0; i < (MRVL_APHY_U8)size; i++)
	{
		ptpGlobalRegRead(device, MRVL_Q222X_PTP_GLB_RD_PLUS_DATA, &regVal16);
		*data |= (MRVL_APHY_U64)regVal16 << (16 * i);
	}
}

/**
 * @brief This function is used to check and wait <ToDBusy> bit(PTP Global Register 0x12.15) to self-clear.
 * @param [in]	device PHY pointer
 * @return MRVL_APHY_STATUS
 */
STATIC MRVL_APHY_STATUS ptpWaitGlobalToD(MRVL_DEV_PTR device)
{
	MRVL_APHY_U16 regAddr = MRVL_Q222X_PTP_GLB_TOD_CTRL;
	MRVL_APHY_U16 waitCnt = 0;
	MRVL_APHY_U64 val = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	while (1)
	{
		regReadPlus(device, MRVL_Q222X_PTP_READ_PLUS_TYPE_GLOBAL, regAddr, MRVL_Q222X_PTP_READ_PLUS_SIZE_16, &val);
		if (((val >> 15) & 0x1U) == 1U)
		{
			mrvl_aphy_wait(device, 10U);
			waitCnt++;
		}
		else
		{
			break;
		}
		if (waitCnt >= MRVL_Q222X_PTP_WAIT_COUNT)
		{
			status = MRVL_APHY_STATUS_ERROR_TIMEOUT;
			break;
		}
	}
	return status;
}

/**
 * @brief This function is used to check and wait <Update> bit(PTP Global Register 0x07.15) to self-clear.
 * @param [in]	device PHY pointer
 * @return MRVL_APHY_STATUS
 */
STATIC MRVL_APHY_STATUS ptpWaitGlobalUpdate(MRVL_DEV_PTR device)
{
	MRVL_APHY_U16 regAddr = MRVL_Q222X_PTP_GLB_CFG_IDR_RW;
	MRVL_APHY_U16 waitCnt = 0;
	MRVL_APHY_U16 val = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	while (1)
	{
		ptpGlobalRegRead(device, regAddr, &val);
		if (((val >> 15) & 0x1U) == 1)
		{
			mrvl_aphy_wait(device, 10U);
			waitCnt++;
		}
		else
		{
			break;
		}
		if (waitCnt >= MRVL_Q222X_PTP_WAIT_COUNT)
		{
			status = MRVL_APHY_STATUS_ERROR_TIMEOUT;
			break;
		}
	}
	return status;
}

/**
 * @brief This function is used to read value from registers indirectly.
 *  The registers been read are under PTP Global Register offset 0x7
 * @param [in]	device        PHY pointer
 * @param [in]	featureIndex  Pointer to the desired octet of PTP Global Config
 * @param [out]	data          Data pointer, function modifies this pointer to reflect readback value
 * @return MRVL_APHY_STATUS
 */
STATIC MRVL_APHY_STATUS ptpGlobalConfigRead(MRVL_DEV_PTR device, MRVL_APHY_U16 featureIndex, MRVL_APHY_U16* data)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	/* Check no read/write is being performed before operation */
	status = ptpWaitGlobalUpdate(device);
	if (MRVL_APHY_STATUS_OK == status)
	{
		ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_CFG_IDR_RW, featureIndex << 8);
		ptpGlobalRegRead(device, MRVL_Q222X_PTP_GLB_CFG_IDR_RW, data);
		*data &= 0xFFU;
	}

	return status;
}

/**
 * @brief This function is used to write value to registers indirectly.
 *  The registers been write are under PTP Global Register offset 0x7
 * @param [in]	device        PHY pointer
 * @param [in]	featureIndex  Index of the desired octet of PTP Global Config
 * @param [out]	data          Value to write into register
 * @return MRVL_APHY_STATUS
 */
STATIC MRVL_APHY_STATUS ptpGlobalConfigWrite(MRVL_DEV_PTR device, MRVL_APHY_U16 featureIndex, MRVL_APHY_U16 data)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 regVal = (featureIndex << 8) | ((MRVL_APHY_U16)0x1 << 15) | (data & 0xFFU);
	/* Check no read/write is being performed before operation */
	status = ptpWaitGlobalUpdate(device);
	if (MRVL_APHY_STATUS_OK == status)
	{
		ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_CFG_IDR_RW, regVal);
		status = ptpWaitGlobalUpdate(device);
	}
	return status;
}


/* Power up/down PTP block */
STATIC void configPTPPower(MRVL_DEV_PTR device, MRVL_APHY_BOOL powerupPTP)
{
	MRVL_APHY_U16 regAddr = MRVL_Q222X_PM_TOP_MPTP_CFG;
	MRVL_APHY_U16 data = 0;

	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_PTP_BASE_DEV, regAddr, &data);
	/* PTP power, reg A008.3 */
	if (MRVL_APHY_TRUE == powerupPTP)
	{
		data = data | 0x8U;
	}
	else
	{
		data = data & 0xFFF7U;
	}
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_PTP_BASE_DEV, regAddr, data);
}

/* Bypass/go through PTP block */
STATIC void bypassPTP(MRVL_DEV_PTR device, MRVL_APHY_BOOL bypass)
{
	MRVL_APHY_U16 regAddr = MRVL_Q222X_PM_TOP_MPTP_CFG;
	MRVL_APHY_U16 data = 0;

	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_PTP_BASE_DEV, regAddr, &data);
	/* enable/bypass PTP, reg A008.0 */
	if (MRVL_APHY_TRUE == bypass)
	{
		data = data & 0xFFFEU;
	}
	else
	{
		data = data | 0x1U;
	}

	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_PTP_BASE_DEV, regAddr, data);
}

/* Enable/disable PTP logic by setting PTP port register */
STATIC void configPTPPortLogic(MRVL_DEV_PTR device, MRVL_APHY_BOOL isPTPPortEnabled)
{
	MRVL_APHY_U16 regOffset = MRVL_Q222X_PTP_PORT_CFG_REG_1;
	MRVL_APHY_U16 regVal;
	ptpPortRegRead(device, regOffset, &regVal);
	if (isPTPPortEnabled == MRVL_APHY_TRUE)
	{
		/* enable port ptp logic */
		regVal &= ~1U;
	}
	else
	{
		/* disable port ptp logic */
		regVal |= 1U;
	}
	ptpPortRegWrite(device, regOffset, regVal);
}

/* Set PTP Arrival Time Stamp Mode */
STATIC void setPTPArrTSMode(MRVL_DEV_PTR device, MRVL_APHY_U16 arrTSMode)
{
	MRVL_APHY_U16 regOffset = MRVL_Q222X_PTP_PORT_CFG_REG_3;
	MRVL_APHY_U16 regVal;
	ptpPortRegRead(device, regOffset, &regVal);
	regVal = (regVal & 0x00FFU) | ((arrTSMode & 0xFFU) << 8);
	ptpPortRegWrite(device, regOffset, regVal);
}

/* Set one step sync */
STATIC void configOneStepSync(MRVL_DEV_PTR device, MRVL_APHY_BOOL syncFrameOnly)
{
	MRVL_APHY_U16 regOffset = MRVL_Q222X_PTP_PORT_CFG_REG_1;
	MRVL_APHY_U16 regVal;
	ptpPortRegRead(device, regOffset, &regVal);
	if (MRVL_APHY_TRUE == syncFrameOnly)
	{
		/* Only Sync frame works at on-step */
		regVal |= 0x100U;
	}
	else
	{
		regVal &= ~0x100U;
	}
	ptpPortRegWrite(device, regOffset, regVal);
}

/* Set PTP hardware acceleration */
STATIC void configHWAccel(MRVL_DEV_PTR device, MRVL_APHY_BOOL enableHWA)
{
	MRVL_APHY_U16 regOffset = MRVL_Q222X_PTP_PORT_CFG_REG_3;
	MRVL_APHY_U16 regVal;
	ptpPortRegRead(device, regOffset, &regVal);
	if (MRVL_APHY_TRUE == enableHWA)
	{
		regVal |= 0x40U;
	}
	else
	{
		regVal &= ~0x40U;
	}
	ptpPortRegWrite(device, regOffset, regVal);
}

/* Set PTP spec */
STATIC void setPTPSpec(MRVL_DEV_PTR device, MRVL_Q222X_PTP_SPEC spec)
{
	MRVL_APHY_U16 regOffset = MRVL_Q222X_PTP_PORT_CFG_REG_1;
	MRVL_APHY_U16 regVal;
	ptpPortRegRead(device, regOffset, &regVal);
	/* set PTP spec */
	regVal &= ~0xF000U;
	regVal |= ((MRVL_APHY_U16)spec << 12);
	ptpPortRegWrite(device, regOffset, regVal);
}

/* Set PTP step */
STATIC void setPTPStep(MRVL_DEV_PTR device, MRVL_Q222X_PTP_STEP step)
{
	MRVL_APHY_U16 regOffset = MRVL_Q222X_PTP_PORT_CFG_REG_1;
	MRVL_APHY_U16 regVal;
	ptpPortRegRead(device, regOffset, &regVal);
	if (MRVL_Q222X_PTP_STEP_ONE_STEP == step)
	{
		/*Set both ingress and egress to one-step PTP */
		regVal |= 0xC0U;
	}
	else
	{
		/*Set both ingress and egress to two-step PTP */
		regVal &= ~0xC0U;
	}
	ptpPortRegWrite(device, regOffset, regVal);
}

/* Set PTP Message Type Time Stamp Enable*/
STATIC void setPTPMsgTypeEn(MRVL_DEV_PTR device, MRVL_APHY_U16 msgTypeEn)
{
	MRVL_APHY_U16 offset = MRVL_Q222X_PTP_GLB_MSG_TYPE_TS_EN;
	ptpGlobalRegWrite(device, offset, msgTypeEn);
}

/* Set PTP mode */
STATIC MRVL_APHY_STATUS setPTPMode(MRVL_DEV_PTR device, MRVL_Q222X_PTP_MODE mode, MRVL_Q222X_PTP_TIME_ARRAY_INDEX taIndex)
{
	MRVL_APHY_U16 index = 0;  /* timearray 0 PTP mode register address index */
	MRVL_APHY_U16 regVal = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	if (MRVL_Q222X_PTP_TIME_ARRAY_INDEX_1 == taIndex)
	{
		/* timearray 1 PTP mode register address index */
		index = 0x3U;
	}
	status = ptpGlobalConfigRead(device, index, &regVal);
	if (MRVL_APHY_STATUS_OK == status)
	{
		regVal &= ~0x3U;
		regVal |= (MRVL_APHY_U16)mode;
		status = ptpGlobalConfigWrite(device, index, regVal);
	}
	return status;
}

/* Set PTP relay mode */
STATIC MRVL_APHY_STATUS setPTPRelayMode(MRVL_DEV_PTR device, MRVL_Q222X_PTP_RELAY_MODE mode, MRVL_Q222X_PTP_TIME_ARRAY_INDEX taIndex)
{
	MRVL_APHY_U16 index = 0;  /* timearray 0 Relay mode register address index */
	MRVL_APHY_U16 shiftBit = 3U;
	MRVL_APHY_U16 regVal = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	if (MRVL_Q222X_PTP_TIME_ARRAY_INDEX_1 == taIndex)
	{
		/* timearray 1 Relay mode register address index */
		index = 0x3U;
		shiftBit = 2U;
	}
	status = ptpGlobalConfigRead(device, index, &regVal);
	if (MRVL_APHY_STATUS_OK == status)
	{
		if (MRVL_Q222X_PTP_RELAY_MODE_RELAY == mode)
		{
			regVal |= ((MRVL_APHY_U16)0x1 << shiftBit);
		}
		else
		{
			regVal &= ~((MRVL_APHY_U16)0x1 << shiftBit);
		}
		status = ptpGlobalConfigWrite(device, index, regVal);
	}
	return status;
}

/* Perform a TOD operation */
STATIC void todCtrlOperate(MRVL_DEV_PTR device, MRVL_APHY_U16 todOpcode, MRVL_APHY_U16 timeArrayIndex, MRVL_APHY_U16 domainNum, MRVL_APHY_U16 clkActive)
{
	MRVL_APHY_U16 regOffset = MRVL_Q222X_PTP_GLB_TOD_CTRL;
	MRVL_APHY_U16 val = 0x8000U |((todOpcode & 0x7U) << 12) | ((clkActive & 0x1U) << 8) | ((timeArrayIndex & 0x1U) << 9) | (domainNum & 0xFFU);
	ptpGlobalRegWrite(device, regOffset, val);
}

/**
 * @brief read back time array
 *
 * @param [in]	device  PHY pointer
 * @param [out]	ta      MRVL_Q222X_PTP_TIME_ARRAY struct pointer
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void readValConvert2TA(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIME_ARRAY* ta)
{
	MRVL_APHY_U16 regVal16 = 0;
	MRVL_APHY_U64 regVal64 = 0;

	/* read 4 PTP global registers 0x10, 0x11, 0x12, 0x13 */
	regReadPlus(device, MRVL_Q222X_PTP_READ_PLUS_TYPE_GLOBAL, MRVL_Q222X_PTP_GLB_TOD_LOAD_P_LSB, MRVL_Q222X_PTP_READ_PLUS_SIZE_64, &regVal64);
	ta->todLoadPoint = (MRVL_APHY_U32)regVal64;

	regVal16 = (MRVL_APHY_U16)((regVal64 >> 32) & 0xFFFFU);    /* register 0x12 value */
	ta->clkActive = (((regVal16 >> 8) & 0x1U) == 1U) ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
	ta->domainNumber = (MRVL_APHY_U8)(regVal16 & 0xFFU);
	ta->todNanoseconds = (MRVL_APHY_U32)((regVal64 >> 48) & 0xFFFFU);    /* register 0x13 value(TOD Nano second[15:0]) */

	/* read 4 PTP global registers 0x14, 0x15, 0x16, 0x17 */
	regReadPlus(device, MRVL_Q222X_PTP_READ_PLUS_TYPE_GLOBAL, MRVL_Q222X_PTP_GLB_TOD_NANO_MSB, MRVL_Q222X_PTP_READ_PLUS_SIZE_64, &regVal64);
	ta->todNanoseconds |= (MRVL_APHY_U32)((regVal64 & 0xFFFFU) << 16);  /* register 0x14 value(TOD Nano second[31:16]) */
	regVal64 >>= 16;    /* register 0x15, 0x16, 0x17 value(48 bits TOD second) */
	ta->todSecondsLow = (MRVL_APHY_U32)(regVal64 & 0xFFFFFFFFU);
	ta->todSecondsHigh = (MRVL_APHY_U16)((regVal64 >> 32) & 0xFFFFU);

	/* read 4 PTP global registers 0x18, 0x19, 0x1A, 0x1B. (64 bits 1722 Nano Second) */
	regReadPlus(device, MRVL_Q222X_PTP_READ_PLUS_TYPE_GLOBAL, MRVL_Q222X_PTP_GLB_1722_NANO_LSB1, MRVL_Q222X_PTP_READ_PLUS_SIZE_64, &regVal64);
	ta->nanoseconds1722Low = (MRVL_APHY_U32)(regVal64 & 0xFFFFFFFFU);
	ta->nanoseconds1722High = (MRVL_APHY_U32)((regVal64 >> 32) & 0xFFFFFFFFU);

	/* read 2 PTP global registers 0x1C, 0x1D. (32 bits Compensation) */
	regReadPlus(device, MRVL_Q222X_PTP_READ_PLUS_TYPE_GLOBAL, MRVL_Q222X_PTP_GLB_TOD_COMP_LSB, MRVL_Q222X_PTP_READ_PLUS_SIZE_32, &regVal64);
	ta->todCompensation = (MRVL_APHY_U32)(regVal64 & 0xFFFFFFFFU);
}

/**
 * @brief write time array information to registers
 *
 * @param [in]	device  PHY pointer
 * @param [in]	ta      MRVL_Q222X_PTP_TIME_ARRAY struct pointer
 * @return void
 *
 * @ingroup VOCF_High
 */
/* polyspace +1 CODE-METRICS:VOCF [Justified] "Deviation ASH-925" */
STATIC void writeValFromTA(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIME_ARRAY* ta)
{
	MRVL_APHY_U16 regVal = 0;
	/* TOD load point */
	regVal = (MRVL_APHY_U16)(ta->todLoadPoint & 0xFFFFU);
	ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_TOD_LOAD_P_LSB, regVal);
	regVal = (MRVL_APHY_U16)((ta->todLoadPoint >> 16) & 0xFFFFU);
	ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_TOD_LOAD_P_MSB, regVal);
	/* TOD Nano second */
	regVal = (MRVL_APHY_U16)(ta->todNanoseconds & 0xFFFFU);
	ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_TOD_NANO_LSB, regVal);
	regVal = (MRVL_APHY_U16)((ta->todNanoseconds >> 16) & 0xFFFFU);
	ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_TOD_NANO_MSB, regVal);
	/* TOD second */
	regVal = (MRVL_APHY_U16)(ta->todSecondsLow & 0xFFFFU);
	ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_TOD_SEC_LSB, regVal);
	regVal = (MRVL_APHY_U16)((ta->todSecondsLow >> 16) & 0xFFFFU);
	ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_TOD_SEC_MSB1, regVal);
	regVal = (MRVL_APHY_U16)(ta->todSecondsHigh & 0xFFFFU);
	ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_TOD_SEC_MSB2, regVal);
	/* 1722 Nano second */
	regVal = (MRVL_APHY_U16)(ta->nanoseconds1722Low & 0xFFFFU);
	ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_1722_NANO_LSB1, regVal);
	regVal = (MRVL_APHY_U16)((ta->nanoseconds1722Low >> 16) & 0xFFFFU);
	ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_1722_NANO_LSB2, regVal);
	regVal = (MRVL_APHY_U16)(ta->nanoseconds1722High & 0xFFFFU);
	ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_1722_NANO_MSB1, regVal);
	regVal = (MRVL_APHY_U16)((ta->nanoseconds1722High >> 16) & 0xFFFFU);
	ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_1722_NANO_MSB2, regVal);
	/* Compensation */
	regVal = (MRVL_APHY_U16)(ta->todCompensation & 0xFFFFU);
	ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_TOD_COMP_LSB, regVal);
	regVal = (MRVL_APHY_U16)((ta->todCompensation >> 16) & 0xFFFFU);
	ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_TOD_COMP_MSB, regVal);

}

/******************************************************************************
 *     PTP initialization
 ******************************************************************************/

/**
 * @brief Initialize PTP
 * @param [in]	device PHY pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PTP_INIT
 */
MRVL_APHY_STATUS q222x_initPTP(MRVL_DEV_PTR device)
{
	MRVL_APHY_U16 data = 0;
	/* Disable <PTP_POWERDOWN> in nt_core.PTP_CONTROL_REGISTER_1 */
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_NT_CORE_DEV, MRVL_Q222X_NT_CORE_PTP_CTRL_REG1, &data);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_NT_CORE_DEV, MRVL_Q222X_NT_CORE_PTP_CTRL_REG1, data & ~(0x200U));

	configPTPPower(device, MRVL_APHY_TRUE);
	bypassPTP(device, MRVL_APHY_FALSE);

    /* Enable PTP to support one-step. To make PTP works at one-step, PTP port one-step register also need be set */
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_PTP_BASE_DEV, MRVL_Q222X_PM_TOP_PTP_CTRL1, &data);
	data |= 0x1000U;
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_PTP_BASE_DEV, MRVL_Q222X_PM_TOP_PTP_CTRL1, data);

	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Disable PTP.(Only disable PTP port logic, still go through PTP block)
 * @param [in]	device PHY pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PTP_INIT
 */
MRVL_APHY_STATUS q222x_disablePTP(MRVL_DEV_PTR device)
{
	configPTPPortLogic(device, MRVL_APHY_FALSE);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Set PTP fixed latency to ensure frame's latency going through MMAC is constant
 * @param [in]	device     PHY pointer
 * @param [in]	fixLatency Fixed latency value. Recommand value 133, with MACsec enabled.
 * @param [in]	isPTPTx    True: PTP Tx direction; False: PTP Rx direction
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PTP_INIT
 */
MRVL_APHY_STATUS q222x_setPTPFixedLatency(MRVL_DEV_PTR device, MRVL_APHY_U32 fixLatency, MRVL_APHY_BOOL isPTPTx)
{
	MRVL_APHY_U16 fixedLatenyRegAddr = 0;
	MRVL_APHY_U32 regVal32 = 0;

	if(MRVL_APHY_TRUE == isPTPTx)
	{
		fixedLatenyRegAddr = 0x308U;
	}
	else
	{
		fixedLatenyRegAddr = 0x288U;
	}

    /* bit 28 is ENABLE_PREEMPT_FIXED_LATENCY */
	regVal32 = ((MRVL_APHY_U32)0x1 << 28) | (fixLatency & 0x3FFFFU);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_PTP_BASE_DEV, fixedLatenyRegAddr, (MRVL_APHY_U16)(regVal32 & 0xFFFFU));
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_PTP_BASE_DEV, fixedLatenyRegAddr+1,  (MRVL_APHY_U16)(regVal32 >> 16));

	return MRVL_APHY_STATUS_OK;
}

/******************************************************************************
 *     PTP Protocol Configuration
 ******************************************************************************/

/**
 * @brief Configure PTP for IEEE 1588v2
 * @param [in]	device  PHY pointer
 * @param [in]	taIndex Timearray index. MRVL_Q222X_PTP_TIME_ARRAY_INDEX_0 or MRVL_Q222X_PTP_TIME_ARRAY_INDEX_1
 * @param [in]	mode    PTP mode. MRVL_Q222X_PTP_MODE_BOUNDARY or MRVL_Q222X_PTP_MODE_PEER_TO_PEER or MRVL_Q222X_PTP_MODE_END_TO_END
 * @param [in]	step    PTP step. MRVL_Q222X_PTP_STEP_TWO_STEP or MRVL_Q222X_PTP_STEP_ONE_STEP
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PTP_PROTOCOL
 */
MRVL_APHY_STATUS q222x_configPTP1588v2(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIME_ARRAY_INDEX taIndex, MRVL_Q222X_PTP_MODE mode, MRVL_Q222X_PTP_STEP step)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	/* enable port ptp logic */
	configPTPPortLogic(device, MRVL_APHY_TRUE);
	/* set spec to 1588 */
	setPTPSpec(device, MRVL_Q222X_PTP_SPEC_IEEE_1588);
	/* set ptp step */
	setPTPStep(device, step);
	configOneStepSync(device, MRVL_APHY_FALSE);
	/* enable HWAccel */
	configHWAccel(device, MRVL_APHY_TRUE);
	/* set PTP mode */
	status = setPTPMode(device, mode, taIndex);
	return status;
}

/**
 * @brief Configure PTP for IEEE 802.1AS
 * @param [in]	device    PHY pointer
 * @param [in]	taIndex   Timearray index. MRVL_Q222X_PTP_TIME_ARRAY_INDEX_0 or MRVL_Q222X_PTP_TIME_ARRAY_INDEX_1
 * @param [in]	relayMode Relay mode. MRVL_Q222X_PTP_RELAY_MODE_END_STATION or MRVL_Q222X_PTP_RELAY_MODE_RELAY
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PTP_PROTOCOL
 */
MRVL_APHY_STATUS q222x_configPTP8021as(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIME_ARRAY_INDEX taIndex, MRVL_Q222X_PTP_RELAY_MODE relayMode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	/* enable port ptp logic */
	configPTPPortLogic(device, MRVL_APHY_TRUE);
	/* set spec to 802.1as */
	setPTPSpec(device, MRVL_Q222X_PTP_SPEC_IEEE_802_1AS);
	/* set ptp step to two-step */
	setPTPStep(device, MRVL_Q222X_PTP_STEP_TWO_STEP);
	configOneStepSync(device, MRVL_APHY_FALSE);
	/* enable HWAccel */
	configHWAccel(device, MRVL_APHY_TRUE);
	/* set ptp mode and relay mode */
	status = setPTPMode(device, MRVL_Q222X_PTP_MODE_BOUNDARY, taIndex);
	if (MRVL_APHY_STATUS_OK == status)
	{
		status = setPTPRelayMode(device, relayMode, taIndex);
	}
	return status;
}

/**
 * @brief Configure PTP for IEEE 802.1AS 2020. One-step for 802.1AS Sync frame only, and it's still two-step for other PTP frames.
 * @param [in]	device    PHY pointer
 * @param [in]	taIndex   Timearray index. MRVL_Q222X_PTP_TIME_ARRAY_INDEX_0 or MRVL_Q222X_PTP_TIME_ARRAY_INDEX_1
 * @param [in]	relayMode Relay mode. MRVL_Q222X_PTP_RELAY_MODE_END_STATION or MRVL_Q222X_PTP_RELAY_MODE_RELAY
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PTP_PROTOCOL
 */
MRVL_APHY_STATUS q222x_configPTP8021as2020(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIME_ARRAY_INDEX taIndex, MRVL_Q222X_PTP_RELAY_MODE relayMode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	/* enable port ptp logic */
	configPTPPortLogic(device, MRVL_APHY_TRUE);
	/* set spec to 802.1as */
	setPTPSpec(device, MRVL_Q222X_PTP_SPEC_IEEE_802_1AS);
	/* set ptp step to one-step */
	setPTPStep(device, MRVL_Q222X_PTP_STEP_ONE_STEP);
	/* enable one-step sync */
	configOneStepSync(device, MRVL_APHY_TRUE);
	/* enable HWAccel */
	configHWAccel(device, MRVL_APHY_TRUE);
	/* set ptp mode and relay mode */
	status = setPTPMode(device, MRVL_Q222X_PTP_MODE_BOUNDARY, taIndex);
	if (MRVL_APHY_STATUS_OK == status)
	{
	    status = setPTPRelayMode(device, relayMode, taIndex);
	}
	return status;
}

/**
 * @brief Configure PTP for IEEE 802.1AS. Overwrite the PTPArrTime associated with enabled PTP Event frames into the frame into the
 * four Reserved bytes. Departure timestamp still timestamp to register. If call this API, load TOD isn't needed.
 *
 * @param [in]	device    PHY pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PTP_PROTOCOL
 */
MRVL_APHY_STATUS q222x_configPTPIgrAdvTS8021as(MRVL_DEV_PTR device)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U16 arrTSMode = 0x10U;
	MRVL_APHY_U16 msgTypeEn = ((MRVL_APHY_U16)1U | ((MRVL_APHY_U16)1U << 2) | ((MRVL_APHY_U16)1U << 3));
	/* Set PTP Message Type Time Stamp Enable for Sync, Pdelay_Req and Pdelay_Resp */
	setPTPMsgTypeEn(device, msgTypeEn);
	/* enable port ptp logic */
	configPTPPortLogic(device, MRVL_APHY_TRUE);
	/* set spec to 802.1as */
	setPTPSpec(device, MRVL_Q222X_PTP_SPEC_IEEE_802_1AS);
	/* set PTP Arrival Time Stamp Mode */
	setPTPArrTSMode(device, arrTSMode);
	/* set ptp step to two-step */
	setPTPStep(device, MRVL_Q222X_PTP_STEP_TWO_STEP);
	/* disable HWAccel */
	configHWAccel(device, MRVL_APHY_FALSE);
	return status;
}

/******************************************************************************
 *     PTP TOD Operation
 ******************************************************************************/

/**
 * @brief This function is used to Capture(Opcode=0x4) timearray value from selected TimeArray.
 *
 * @param [in]	device  PHY pointer
 * @param [in]	taIndex Timearray index. MRVL_Q222X_PTP_TIME_ARRAY_INDEX_0 or MRVL_Q222X_PTP_TIME_ARRAY_INDEX_1
 * @param [out]	ta      MRVL_Q222X_PTP_TIME_ARRAY struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PTP_TOD_OP
 */
MRVL_APHY_STATUS q222x_capturePTPToD(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIME_ARRAY_INDEX taIndex, MRVL_Q222X_PTP_TIME_ARRAY* ta)
{
	MRVL_APHY_U16 todOpcode = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;

	/* wait TOD busy bit self-clear */
	status = ptpWaitGlobalToD(device);
	if (MRVL_APHY_STATUS_OK == status)
	{
		/* perform TOD capture operation */
		todOpcode = 0x4U;    /* Capture opcode */
		todCtrlOperate(device, todOpcode, (MRVL_APHY_U16)taIndex, 0, 1U);

		/* wait TOD busy bit self-clear */
		status = ptpWaitGlobalToD(device);
	}

	if(MRVL_APHY_STATUS_OK == status)
	{
		/* read back values*/
		readValConvert2TA(device, ta);
	}

	return status;
}

/**
 * @brief This function is used to Store(Opcode=0x3) all timearray registers to selected TimeArray @ ToDLoadPt(clean).
 *
 * @param [in]	device  PHY pointer
 * @param [in]	taIndex Timearray index. MRVL_Q222X_PTP_TIME_ARRAY_INDEX_0 or MRVL_Q222X_PTP_TIME_ARRAY_INDEX_1
 * @param [in]	ta      MRVL_Q222X_PTP_TIME_ARRAY struct pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PTP_TOD_OP
 */
MRVL_APHY_STATUS q222x_storePTPToDAll(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIME_ARRAY_INDEX taIndex, MRVL_Q222X_PTP_TIME_ARRAY* ta)
{
	MRVL_APHY_U16 todOpcode = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;

	/* wait TOD busy bit self-clear */
	status = ptpWaitGlobalToD(device);
	if(MRVL_APHY_STATUS_OK == status)
	{
		/* write ta info to registers */
		writeValFromTA(device, ta);
		/* perform TOD storeAll operation */
		todOpcode = (MRVL_APHY_U8)MRVL_Q222X_PTP_TOD_STORE_ALL;    /* Store opcode */
		todCtrlOperate(device, todOpcode, (MRVL_APHY_U16)taIndex, ta->domainNumber, (MRVL_APHY_U8)ta->clkActive);
	}
	return status;
}

/**
 * @brief This function is used to Store(Opcode=0x2) Compensation register only to selected TimeArray.
 * @param [in]	device          PHY pointer
 * @param [in]	taIndex         Timearray index
 * @param [in]	todCompensation TOD compensation value
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PTP_TOD_OP
 */
MRVL_APHY_STATUS q222x_storePTPToDCompensation(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIME_ARRAY_INDEX taIndex, MRVL_APHY_U32 todCompensation)
{
	MRVL_APHY_U16 regVal = 0;
	MRVL_APHY_U16 todOpcode = 0;
	MRVL_APHY_U16 clkActive = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;

	/* wait TOD busy bit self-clear */
	status = ptpWaitGlobalToD(device);
	if(MRVL_APHY_STATUS_OK == status)
	{
		/* Compensation */
		regVal = (MRVL_APHY_U16)(todCompensation & 0xFFFFU);
		ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_TOD_COMP_LSB, regVal);
		regVal = (MRVL_APHY_U16)((todCompensation >> 16) & 0xFFFFU);
		ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_TOD_COMP_MSB, regVal);

		/* perform TOD storeCompensation operation */
		todOpcode = (MRVL_APHY_U8)MRVL_Q222X_PTP_TOD_STORE_COMP;    /* Store opcode */
		clkActive = 1;
		todCtrlOperate(device, todOpcode, (MRVL_APHY_U16)taIndex, 0, clkActive);

		/* wait TOD busy bit self-clear */
		status = ptpWaitGlobalToD(device);
	}

	return status;
}

/**
 * @brief Get TOD busy bit to check if TOD operation is being performed.
 * @param [in]	device  PHY pointer
 * @param [out]	busyBit TOD busy bit. True: TOD operation is being performed; False: no TOD operation is being performed
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PTP_TOD_OP
 */
MRVL_APHY_STATUS q222x_getPTPToDBusyStatus(MRVL_DEV_PTR device, MRVL_APHY_BOOL* busyBit)
{
	MRVL_APHY_U64 regVal = 0;
	regReadPlus(device, MRVL_Q222X_PTP_READ_PLUS_TYPE_GLOBAL, MRVL_Q222X_PTP_GLB_TOD_CTRL, MRVL_Q222X_PTP_READ_PLUS_SIZE_16, &regVal);
	*busyBit = (((regVal >> 15) & 0x1U) == 1U) ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get PTP global time, it's a 32 bits free running time counter. This counter wraps around in hardware.
 * @param [in]	device     PHY pointer
 * @param [out]	globalTime Global time pointer. Global time is a 32 bits free running time counter.
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PTP_TOD_OP
 */
MRVL_APHY_STATUS q222x_getPTPGlobalTime(MRVL_DEV_PTR device, MRVL_APHY_U32* globalTime)
{
	MRVL_APHY_U64 regVal64 = 0;
	regReadPlus(device, MRVL_Q222X_PTP_READ_PLUS_TYPE_TAI, MRVL_Q222X_PTP_TAI_GLB_TIME_LSB, MRVL_Q222X_PTP_READ_PLUS_SIZE_32, &regVal64);
	*globalTime  = (MRVL_APHY_U32)regVal64;
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Get timestamp value and sequence id as well as timestamp status.
 * @param [in]	device     PHY pointer
 * @param [in]	tsSelect   Timestamp select. MRVL_Q222X_PTP_TIMESTAMP_ARR0_TIME or MRVL_Q222X_PTP_TIMESTAMP_ARR1_TIME or MRVL_Q222X_PTP_TIMESTAMP_DEP_TIME.
 * @param [out]	ts         PTP_TIMESTAMP struct pointer, the struct is composed of timestamp value and sequence id as well as timestamp status.
 * @return MRVL_APHY_STATUS
 *
 * @ingroup REG_TIME_STAMP
 */
MRVL_APHY_STATUS q222x_getPTPTimestamp(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIMESTAMP_SELECT tsSelect, MRVL_Q222X_PTP_TIMESTAMP* ts)
{
	MRVL_APHY_U16 regVal = 0;
	MRVL_APHY_U16 intStatusVal = 0;
	MRVL_APHY_U16 offset = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	switch (tsSelect)
	{
		case MRVL_Q222X_PTP_TIMESTAMP_ARR0_TIME:
		{
			offset = MRVL_Q222X_PTP_PORT_ARR0_TS_STATUS;
			break;
		}
		case MRVL_Q222X_PTP_TIMESTAMP_ARR1_TIME:
		{
			offset = MRVL_Q222X_PTP_PORT_ARR1_TS_STATUS;
			break;
		}
		case MRVL_Q222X_PTP_TIMESTAMP_DEP_TIME:
		{
			offset = MRVL_Q222X_PTP_PORT_DEP_TS_STATUS;
			break;
		}
		default:
		{
			status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
			break;
		}
	}

	if (MRVL_APHY_STATUS_OK == status)
	{
		ptpPortRegRead(device, offset, &regVal);
		ts->isValid = ((regVal & 0x1U) == 1U) ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
		intStatusVal = (regVal >> 1) & 0x3U;
		if (0 == intStatusVal)
		{
			ts->status = MRVL_Q222X_PTP_INT_STATUS_NORMAL;
		}
		else if (0x1U == intStatusVal)
		{
			ts->status = MRVL_Q222X_PTP_INT_STATUS_OVERWRITE;
		}
		else if (0x2U == intStatusVal)
		{
			ts->status = MRVL_Q222X_PTP_INT_STATUS_DROP;
		}
		else
		{
			status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
		}

		ptpPortRegRead(device, offset + 1U, &regVal);
		ts->timeStamped = (MRVL_APHY_U32)regVal;
		ptpPortRegRead(device, offset + 2U, &regVal);
		ts->timeStamped |= ((MRVL_APHY_U32)regVal << 16);

		ptpPortRegRead(device, offset + 3U, &regVal);
		ts->ptpSeqId = regVal;
	}

	return status;
}

/**
 * @brief Clear Arrival or Departure Time Valid bit to 0.
 * @param [in]	device     PHY pointer
 * @param [in]	tsSelect   Timestamp select. MRVL_Q222X_PTP_TIMESTAMP_ARR0_TIME or MRVL_Q222X_PTP_TIMESTAMP_ARR1_TIME or MRVL_Q222X_PTP_TIMESTAMP_DEP_TIME.
 * @return MRVL_APHY_STATUS
 *
 * @ingroup REG_TIME_STAMP
 */
MRVL_APHY_STATUS q222x_clearPTPTimestampValid(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIMESTAMP_SELECT tsSelect)
{
	MRVL_APHY_U16 regVal = 0;
	MRVL_APHY_U16 offset = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	switch (tsSelect)
	{
		case MRVL_Q222X_PTP_TIMESTAMP_ARR0_TIME:
		{
			offset = MRVL_Q222X_PTP_PORT_ARR0_TS_STATUS;
			break;
		}
		case MRVL_Q222X_PTP_TIMESTAMP_ARR1_TIME:
		{
			offset = MRVL_Q222X_PTP_PORT_ARR1_TS_STATUS;
			break;
		}
		case MRVL_Q222X_PTP_TIMESTAMP_DEP_TIME:
		{
			offset = MRVL_Q222X_PTP_PORT_DEP_TS_STATUS;
			break;
		}
		default:
		{
			status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
			break;
		}
	}

	if (MRVL_APHY_STATUS_OK == status)
	{
		ptpPortRegRead(device, offset, &regVal);
		regVal &= 0xFFFEU;
		ptpPortRegWrite(device, offset, regVal);
	}

	return status;
}

/******************************************************************************
 *    1PPS
 ******************************************************************************/

/**
 * @brief Get PTP 1PPS config
 * @param [in]	device PHY pointer
 * @param [out]	config 1PPS config pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PTP_1PPS
 */
MRVL_APHY_STATUS q222x_getPTP1PPSControl(MRVL_DEV_PTR device, MRVL_Q222X_PTP_1PPS_CONTROL* config)
{
	MRVL_APHY_U64 regVal;
	regReadPlus(device, MRVL_Q222X_PTP_READ_PLUS_TYPE_GLOBAL, MRVL_Q222X_PTP_GLB_1PPS_CTRL, MRVL_Q222X_PTP_READ_PLUS_SIZE_16, &regVal);
	config->ptpPulseWidth = (MRVL_APHY_U8)((regVal >> 12) & 0xFU);
	config->ptp1ppsWidthRange = (MRVL_APHY_U8)((regVal >> 8) & 0x7U);
	config->ptp1ppsPhase = (MRVL_APHY_U8)((regVal >> 3) & 0x1U);
	config->ptp1ppsSelect = (MRVL_APHY_U8)(regVal & 0x1U);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Set PTP 1PPS config to generate periodical pulse.
 * @param [in]	phyAddr PHY pointer
 * @param [in]	config  1PPS config pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PTP_1PPS
 */
MRVL_APHY_STATUS q222x_setPTP1PPSControl(MRVL_DEV_PTR device, MRVL_Q222X_PTP_1PPS_CONTROL* config)
{
	MRVL_APHY_U16 regVal = 0;
	MRVL_APHY_U16 select = 0;
	
	/* 0x1F.A013[9:8] */
	select = (config->ptp1ppsSelect == 1U) ? 2U : 1U;
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_PTP_BASE_DEV, MRVL_Q222X_PM_TOP_PTP_SPEED_OW, &regVal);
	regVal = (regVal & 0xFCFFU) | (select << 8);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_PTP_BASE_DEV, MRVL_Q222X_PM_TOP_PTP_SPEED_OW, regVal);

	/* 0x4.821B[0] = 0 */
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_NT_CORE_DEV, MRVL_Q222X_NT_CORE_WAKE_GPIO_EN, &regVal);
	regVal = regVal & 0xFFFEU;
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_NT_CORE_DEV, MRVL_Q222X_NT_CORE_WAKE_GPIO_EN, regVal);

	regVal = ((((MRVL_APHY_U16)config->ptpPulseWidth) & 0xfU) << 12) |
		((((MRVL_APHY_U16)config->ptp1ppsWidthRange) & 0x7U) << 8) |
		((((MRVL_APHY_U16)config->ptp1ppsPhase) & 0x1U) << 3) |
		((MRVL_APHY_U16)config->ptp1ppsSelect & 0x1U);
	ptpGlobalRegWrite(device, MRVL_Q222X_PTP_GLB_1PPS_CTRL, regVal);

	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Select GPIO pin for 1PPS output
 * @param [in]	phyAddr PHY pointer
 * @param [in]	config  1PPS config pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PTP_1PPS
 */
MRVL_APHY_STATUS q222x_setPTP1PPSGpioPin(MRVL_DEV_PTR device)
{
	MRVL_APHY_U16 regVal = 0;
	MRVL_APHY_U16 pinConfig = 2U;
	
	/* 0x4.87F0[5:4] = 2 */
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_NT_CORE_DEV, MRVL_Q222X_NT_CORE_PTP_CTRL_REG1, &regVal);
	regVal = (regVal & 0xFFCFU) | (pinConfig << 4);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_NT_CORE_DEV, MRVL_Q222X_NT_CORE_PTP_CTRL_REG1, regVal);

	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief Select LED pin for 1PPS output
 * @param [in]	phyAddr PHY pointer
 * @param [in]	config  1PPS config pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup PTP_1PPS
 */
MRVL_APHY_STATUS q222x_setPTP1PPSLedPin(MRVL_DEV_PTR device)
{
	MRVL_APHY_U16 regVal = 0;
	MRVL_APHY_U16 pinConfig = 2U;
	
	/* 0x4.87F0[7:6] = 2 */
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_NT_CORE_DEV, MRVL_Q222X_NT_CORE_PTP_CTRL_REG1, &regVal);
	regVal = (regVal & 0xFF3FU) | (pinConfig << 6);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_NT_CORE_DEV, MRVL_Q222X_NT_CORE_PTP_CTRL_REG1, regVal);

	return MRVL_APHY_STATUS_OK;
}
