/**
 * @file MRVL_AMG_Types.h
 * @brief Marvell Multi-gig Automotive Ethernet PHY General Types and Defines
 *
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */

#ifndef MRVL_AMG_TYPES_H
#define MRVL_AMG_TYPES_H

#include "MRVL_AMG_Copyright_and_Version.h"

#ifdef MRVL_AMG_TEST
#define STATIC
#else
#ifndef STATIC
#define STATIC static
#endif
#endif /* MRVL_AMG_TEST */

#ifdef MRVL_AMG_FUNC
#define EXPORT_FUNC __declspec(dllexport)
#else
#define EXPORT_FUNC
#endif

typedef unsigned char		MRVL_APHY_U8;
typedef signed char			MRVL_APHY_8;
typedef unsigned short		MRVL_APHY_U16;
typedef unsigned int		MRVL_APHY_U32;
typedef unsigned long long	MRVL_APHY_U64;
typedef double				MRVL_APHY_DOUBLE;

#define TDR_ARRAY_LENGTH 8

/** @defgroup MRVL_APHY_STATUS API Return Codes
 *  @{
 */
typedef MRVL_APHY_U32 		MRVL_APHY_STATUS;			/*!< Status code */
#define MRVL_APHY_STATUS_OK					0x0000U		/*!< Status code - Success */
#define MRVL_APHY_STATUS_ERROR_GENERAL		0x0001U		/*!< Status code - Error */
#define MRVL_APHY_STATUS_ERROR_TIMEOUT		0x0002U		/*!< Status code - Timeout error */
#define MRVL_APHY_STATUS_ERROR_MDIO			0x0004U		/*!< Status code - Reg access error */
#define MRVL_APHY_STATUS_ERROR_NOTSUPPORT	0x0010U		/*!< Status code - Non-support error */
#define MRVL_APHY_STATUS_UNKNOW				0x1000U		/*!< Status code - Other unknow error */
/** @} */

typedef enum {
	MRVL_APHY_FALSE = 0,
	MRVL_APHY_TRUE = 1
} MRVL_APHY_BOOL;

/**
 * @brief  Define polarity enum
 *
 */
typedef enum 
{
	MRVL_AMG_POLARITY_NORMAL,
	MRVL_AMG_POLARITY_REVERSED
}MRVL_AMG_Polarity;

/**
 * @brief  Define link status enum
 *
 */
typedef enum 
{
	MRVL_AMG_LINK_DOWN = 0,
	MRVL_AMG_LINK_UP = 1
}MRVL_AMG_LinkStatus;

/**
 * @brief  Define T1 speed enum
 *
 */
typedef enum {
	MRVL_APHY_SPEED_2P5G = 4,
	MRVL_APHY_SPEED_5G = 5,
	MRVL_APHY_SPEED_10G = 6,
	MRVL_APHY_SPEED_NA
} MRVL_APHY_SPEED;

/**
 * @brief  Define SerDes speed enum
 *
 */
typedef enum {
	MRVL_APHY_SERDES_SPEED_DISABLED = 0,
	MRVL_APHY_SERDES_2500_BASEX = 1,
	MRVL_APHY_SERDES_2P5G_BASEX = 2,
	MRVL_APHY_SERDES_5000_BASER = 3,
	MRVL_APHY_SERDES_5G_BASER = 4,
	MRVL_APHY_SERDES_10G_BASER = 5,
	MRVL_APHY_SERDES_5G_USXGMII = 6,
	MRVL_APHY_SERDES_10G_USXGMII = 7
} MRVL_APHY_SERDES_SPEED;


/**
 * @brief  Define operation mode enum
 *
 */
typedef enum {
	MRVL_APHY_OP_SLAVE = 0,
	MRVL_APHY_OP_MASTER = 1,
	MRVL_APHY_OP_NA
} MRVL_APHY_OPERATION_MODE;

/**
 * @brief  Define pattern enum in test mode 2
 *
 */
typedef enum
{
	MRVL_AMG_JITTER_PATTERN_SQUAREWAVE = 0,
	MRVL_AMG_JITTER_PATTERN_JP03A = 1,
	MRVL_AMG_JITTER_PATTERN_JP03B = 2,
	MRVL_AMG_JITTER_PATTERN_RESERVED = 3
} MRVL_AMG_JitterTestControl;

/**
 * @brief  Define IEEE compliance test mode enum
 *
 */
typedef enum 
{
	MRVL_AMG_TEST_MODE_NONE = 0, 	/*!<  Non-test mode/normal operation */
	MRVL_AMG_TEST_MODE_1 = 1, 		/*!<  Setting MASTER and SLAVE PHYs for transmit clock jitter test in linked mode */
	MRVL_AMG_TEST_MODE_2 = 2, 		/*!<  Transmit MDI jitter test in MASTER mode */
	MRVL_AMG_TEST_MODE_3 = 3, 		/*!<  Precoder test mode (not verified) */
	MRVL_AMG_TEST_MODE_4 = 4, 		/*!<  Transmitter linearity test */
	MRVL_AMG_TEST_MODE_5 = 5, 		/*!<  Normal operation in IDLE mode. this is for the PSD mask test  */
	MRVL_AMG_TEST_MODE_6 = 6, 		/*!<  Transmitter droop test mode */
	MRVL_AMG_TEST_MODE_7 = 7 		/*!<  Normal operation with zero data pattern. this is for BER monitoring(not verified) */
} MRVL_AMG_TestMode;

/**
 * @brief  Define Loopback mode enum
 *
 */
typedef enum 
{
	MRVL_AMG_LINE_LOOPBACK = 0, 		/*!<  Line Loopback */
	MRVL_AMG_SYSTEM_LOOPBACK = 1 		/*!<  System Loopback */
} MRVL_AMG_Loopback;

/**
 * @brief  Define chip revision enum
 *
 */
typedef enum 
{
	MRVL_AMG_REV_A0 = 0, /* A0 */
	MRVL_AMG_REV_A1 = 3, /* A1 */
	MRVL_AMG_REV_INVALID = 4
} MRVL_AMG_ChipRevision;

/**
 * @brief  Define Host Configuration Stage states enum
 *
 */
typedef enum 
{
	MRVL_AMG_HCS_INACTIVE = 0,
	MRVL_AMG_HCS_STARTED = 1, 
	MRVL_AMG_HCS_COMMENCED = 2,
	MRVL_AMG_HCS_FINALIZED = 3,
	MRVL_AMG_HCS_TIMEOUT = 4
} MRVL_AMG_HCS_State;

/**
 * @brief  Define packet generator/checker datapath enum
 *
 */
typedef enum 
{
	MRVL_AMG_SYS_INTF_LINE_TO_SYS = 0,
	MRVL_AMG_SYS_INTF_SYS_TO_LINE = 1, 
	MRVL_AMG_LINE_INTF_LINE_TO_SYS = 2,
	MRVL_AMG_LINE_INTF_SYS_LINE = 3,
} MRVL_AMG_DATAPATH;

/**
 * @brief  Define PGen Inter-Frame Gap (IFG) mode enum
 *
 */
typedef enum 
{
	MRVL_AMG_PACKETGEN_IFG_FIXED = 0,
	MRVL_AMG_PACKETGEN_IFG_RANDOM = 1, 
	MRVL_AMG_PACKETGEN_IFG_DIFICIT = 2,
	MRVL_AMG_PACKETGEN_IFG_INVALID
} MRVL_AMG_PACKETGEN_IFG;

/**
 * @brief  Define PGen packet length mode enum
 *
 */
typedef enum 
{
	MRVL_AMG_PACKETGEN_LENGHT_FIXED = 0,
	MRVL_AMG_PACKETGEN_LENGHT_RANDOM = 1,
	MRVL_AMG_PACKETGEN_LENGHT_INVALID
} MRVL_AMG_PACKETGEN_LENGHT;

/**
 * @brief  Define PGen payaload mode enum
 *
 */
typedef enum 
{
	MRVL_AMG_PAYLOAD_ALL_ZEROS = 0,
	MRVL_AMG_PAYLOAD_ALL_ONES = 1,
	MRVL_AMG_PAYLOAD_INC_WORD = 2,
	MRVL_AMG_PAYLOAD_INC_BYTE = 3,
	MRVL_AMG_PAYLOAD_ALTERNATE = 4,
	MRVL_AMG_PAYLOAD_WALKING_ZERO = 5,
	MRVL_AMG_PAYLOAD_WALKING_ONE = 6,
	MRVL_AMG_PAYLOAD_RANDOM = 7
} MRVL_AMG_PACKETGEN_PAYLOAD_MODE;

/**
 * @brief  Define PGen operation mode enum
 *
 */
typedef enum 
{
	MRVL_AMG_PACKETGEN_SINGLESHOT = 0,
	MRVL_AMG_PACKETGEN_CONTINOUS = 1,
	MRVL_AMG_PACKETGEN_INVALID
} MRVL_AMG_PACKETGEN_OPERATION_MODE;

/**
 * @brief  Define led link mode (T1, Sys) enum. Indicate both link status (solid LED) and activity (blinking LED).
 *
 */
typedef enum 
{
	MRVL_AMG_LED_OFF = 0,
	MRVL_AMG_LED_T1_LINK = 1,
	MRVL_AMG_LED_SYS_LINK = 2,
	MRVL_AMG_LED_T1_SYS_LINK = 3
} MRVL_AMG_LED_LINK_STATUS;

/**
 * @brief  Define led activity mode (egress, ingress) enum. Indicate activity (blinking LED). Activity is only indicated if the Link Status condition is satisfied
 *
 */
typedef enum 
{
	MRVL_AMG_LED_BLINK_OFF = 0,
	MRVL_AMG_LED_INGRESS_LINK = 1,
	MRVL_AMG_LED_EGRESS_LINK = 2,
	MRVL_AMG_LED_EGR_ING_LINKS = 3
} MRVL_AMG_LED_LINK_ACTIVITY;

/**
 * @brief Structure of 32-bit counters from pckt monitor
 *
 */
typedef struct
{
	MRVL_APHY_U64  goodTxEthernetFrames;
	MRVL_APHY_U64  goodRxEthernetFrames;
	MRVL_APHY_U64  badTxEthernetFrames;
	MRVL_APHY_U64  badRxEthernetFrames;
} MRVL_AMG_Counter;

/**
 * @brief Structure of SNR
 *
 */
typedef struct
{
	MRVL_APHY_DOUBLE  snrOperatingMargin;
	MRVL_APHY_DOUBLE  snrMinimumMargin;
} MRVL_AMG_SNR;

/**
 * @brief Structure of FW information
 *
 */
typedef struct
{
	MRVL_APHY_U8  streamRevision;
	MRVL_APHY_U16  majorRevision;
	MRVL_APHY_U8  minorRevision;
	MRVL_APHY_U8 candidateRevision;
	MRVL_APHY_U64  heartbeat;
	MRVL_APHY_U32  platformID;
	MRVL_APHY_U32  provisioningBaseRevision;
} MRVL_AMG_FirmwareInfo;

/**
 * @brief Structure of flash information and control code
 *
 */
typedef struct
{
	MRVL_APHY_U32 flash_size;					/*!< Size of the flash in bytes  */
	MRVL_APHY_U32 page_size;					/*!< Page Size (usually 256)  */
	MRVL_APHY_U32 sector_page_size;				/*!< Number of Pages in Sector (usually 16)  */
	MRVL_APHY_U32 max_flash_erase_size;
	MRVL_APHY_U32 erase_cycle;
	MRVL_APHY_U16 device_id;
	MRVL_APHY_U8 manufacturer_id;
	MRVL_APHY_U8 read_id_opcode;				/*!< Read Jedec ID (usually 0x9F)  */
	MRVL_APHY_U8 read_status_opcode;			/*!< Read Status Register (usually 0x05)  */
	MRVL_APHY_U8 write_status_opcode;			/*!< Write Status Register (usually 0x01)  */
	MRVL_APHY_U8 write_enable_opcode;			/*!< Write Enable (usually 0x06)  */
	MRVL_APHY_U8 chip_erase_opcode;				/*!< Chip Erase (usually 0xC7)  */
	MRVL_APHY_U8 sector_erase_opcode;			/*!< Sector Erase - smallest erase area (usually 0x20)  */
	MRVL_APHY_U8 read_opcode;					/*!< Read Data (usually 0x03)  */
	MRVL_APHY_U8 fast_read_opcode;				/*!< Fast Read Data (usually 0x0B)  */
	MRVL_APHY_U8 fast_read_dual_output_opcode;	/*!< Fast Read Data with Dual Output (usually 0x3B)  */
	MRVL_APHY_U8 fast_read_quad_output_opcode;	/*!< Fast Read Data with Quad Output (usually 0x6B)  */
	MRVL_APHY_U8 program_opcode;				/*!< Page Program (usually 0x02)  */
	MRVL_APHY_U8 erase_program_resume_opcode;	/*!< Erase/Programm resume (usually 0x7A)  */
	MRVL_APHY_U8 volatile_sr_write_en_opcode;	/*!< Enable writing volatile bits of statur register  */
	MRVL_APHY_U8 enable_reset_opcode;			/*!< Enable flash reset  */
	MRVL_APHY_U8 soft_reset_opcode;				/*!< Soft reset  */
	MRVL_APHY_U8 status_mask;					/*!< Mask for Status Register that isolates ready / busy bit (usually 0x01)  */
	MRVL_APHY_U8 status_value;					/*!< Masked value that indicates that flash is NOT busy (usually 0x00)  */
	MRVL_APHY_U8 chip_erase_addr_len;			/*!< Address length for Chip Erase command (usually 0)  */
	MRVL_APHY_U8 read_status_reg2_opcode;		/*!< Read status register address which contains quad enable bit  */
	MRVL_APHY_U8 write_status_reg2_opcode;		/*!< write status register address which contains quad enable bit  */
	MRVL_APHY_U8 status_reg_len;				/*!< Length of Status Register  */
	MRVL_APHY_U8 quad_enable_bit;				/*!< QE bit offset */
	MRVL_APHY_U8 cmp_bit;						/*!< Complement protect  */
	MRVL_APHY_U8 srl_bit;						/*!< Status register lock */
	MRVL_APHY_U8 max_erase_opcode;
	MRVL_APHY_BOOL erase_protection;			/*!< Protection which should be cleared before erase  */
	MRVL_APHY_BOOL write_enable_before_qe;		/*!< Need to enable writing to set QE bit */
	MRVL_APHY_BOOL is_quad_enable_supported;
	MRVL_APHY_BOOL is_SFDP_supported; 

}MRVL_AMG_FLASH;

/**
 * @brief Structure of flash control code and bits
 *
 */
typedef struct {
	union{
		struct {
			MRVL_APHY_U32 sector_erase_sizes : 2;
			MRVL_APHY_U32 write_granularity : 1;
			MRVL_APHY_U32 volatile_status_register_block_protect_bit : 1;
			MRVL_APHY_U32 write_enable_instruction_volatile_status_egister : 1;
			MRVL_APHY_U32 reserved_1 : 3;
			MRVL_APHY_U32 erase_instruction_4kb : 8;
			MRVL_APHY_U32 supports_1_1_2_fast_read : 1;
			MRVL_APHY_U32 address_bytes : 2;
			MRVL_APHY_U32 supports_DTR_clocking : 1;
			MRVL_APHY_U32 supports_1_2_2_fast_read : 1;
			MRVL_APHY_U32 supports_1_4_4_fast_read : 1;
			MRVL_APHY_U32 supports_1_1_4_fast_read : 1;
			MRVL_APHY_U32 reserved_2 : 9;
		}bits;
		MRVL_APHY_U32 whole;
	}DWORD_1;

	union 
	{
		struct {
			MRVL_APHY_U32 flash_memory_density;
		}bits;
		MRVL_APHY_U32 whole;
	}DWORD_2;

	union
	{
		struct {
			MRVL_APHY_U32 fast_read_wait_cycle_count_1_4_4 : 4;
			MRVL_APHY_U32 fast_read_mode_bit_cycle_count_1_4_4 : 4;
			MRVL_APHY_U32 fast_read_instruction_1_4_4 : 8;
			MRVL_APHY_U32 fast_read_wait_cycle_count_1_1_4 : 4;
			MRVL_APHY_U32 fast_read_mode_bit_cycle_count_1_1_4 : 4;
			MRVL_APHY_U32 fast_read_instruction_1_1_4 : 8;
		}bits;
		MRVL_APHY_U32 whole;
	}DWORD_3;

	union
	{
		struct {
			MRVL_APHY_U32 fast_read_wait_cycle_count_1_1_2 : 4;
			MRVL_APHY_U32 fast_read_mode_bit_cycle_count_1_1_2 : 4;
			MRVL_APHY_U32 fast_read_instruction_1_1_2 : 8;
			MRVL_APHY_U32 fast_read_wait_cycle_count_1_2_2 : 4;
			MRVL_APHY_U32 fast_read_mode_bit_cycle_count_1_2_2 : 4;
			MRVL_APHY_U32 fast_read_instruction_1_2_2 : 8;
		}bits;
		MRVL_APHY_U32 whole;
	}DWORD_4;

	union
	{
		struct {
			MRVL_APHY_U32 supports_2_2_2_fast_read : 1;
			MRVL_APHY_U32 reserved_1 : 3;
			MRVL_APHY_U32 supports_4_4_4_fast_read : 1;
			MRVL_APHY_U32 reserved_2 : 27;
		}bits;
		MRVL_APHY_U32 whole;
	}DWORD_5;

	union
	{
		struct {
			MRVL_APHY_U32 reserved_1 : 16;
			MRVL_APHY_U32 fast_read_wait_cycle_count_2_2_2 : 4;
			MRVL_APHY_U32 fast_read_mode_bit_cycle_count_2_2_2 : 4;
			MRVL_APHY_U32 fast_read_instruction_2_2_2 : 8;
		}bits;
		MRVL_APHY_U32 whole;
	}DWORD_6;

	union
	{
		struct {
			MRVL_APHY_U32 fast_read_wait_cycle_count_4_4_4 : 4;
			MRVL_APHY_U32 fast_read_mode_bit_cycle_count_4_4_4 : 4;
			MRVL_APHY_U32 fast_read_instruction_4_4_4 : 8;
		}bits;
		MRVL_APHY_U32 whole;
	}DWORD_7;

	union
	{
		struct {
			MRVL_APHY_U32 erase_type_1_size : 8;
			MRVL_APHY_U32 erase_type_1_instruction : 8;
			MRVL_APHY_U32 erase_type_2_size : 8;
			MRVL_APHY_U32 erase_type_2_instruction : 8;
		}bits;
		MRVL_APHY_U32 whole;
	}DWORD_8;

	union
	{
		struct {
			MRVL_APHY_U32 erase_type_3_size : 8;
			MRVL_APHY_U32 erase_type_3_instruction : 8;
			MRVL_APHY_U32 erase_type_4_size : 8;
			MRVL_APHY_U32 erase_type_4_instruction : 8;
		}bits;
		MRVL_APHY_U32 whole;
	}DWORD_9;

	union
	{
		struct {
			MRVL_APHY_U32 multiplier_typical_to_maximum_erase_time : 4;
			MRVL_APHY_U32 sector_type_1_ERASE_time : 7;
			MRVL_APHY_U32 sector_type_2_ERASE_time : 7;
			MRVL_APHY_U32 sector_type_3_ERASE_time : 7;
			MRVL_APHY_U32 sector_type_4_ERASE_time : 7;
		}bits;
		MRVL_APHY_U32 whole;
	}DWORD_10;

	union
	{
		struct {
			MRVL_APHY_U32 multiplier_typical_to_maximum_time_page_byte_PROGRAM : 4;
			MRVL_APHY_U32 page_size : 4;
			MRVL_APHY_U32 page_program_typical_time : 6;
			MRVL_APHY_U32 byte_program_typical_time_first_byte : 5;
			MRVL_APHY_U32 byte_Program_typical_time_additional_byte : 5;
			MRVL_APHY_U32 chip_erase_typical_time : 7;
			MRVL_APHY_U32 reserved_1 : 1;
		}bits;
		MRVL_APHY_U32 whole;
	}DWORD_11;

	union
	{
		struct {
			MRVL_APHY_U32 prohibited_operations_during_program_suspend : 4;
			MRVL_APHY_U32 prohibited_operations_during_erase_suspend : 4;
			MRVL_APHY_U32 reserved_1 : 1;
			MRVL_APHY_U32 program_resume_to_suspend_interval : 4;
			MRVL_APHY_U32 suspend_in_progress_program_max_latency : 7;
			MRVL_APHY_U32 erase_resume_to_suspend_interval : 4;
			MRVL_APHY_U32 suspend_in_progress_erase_max_latency : 7;
			MRVL_APHY_U32 suspend_resume_supported : 1;
		}bits;
		MRVL_APHY_U32 whole;
	}DWORD_12;

	union
	{
		struct {
			MRVL_APHY_U32 program_resume_instruction : 8;
			MRVL_APHY_U32 program_suspend_instruction : 8;
			MRVL_APHY_U32 resume_instruction : 8;
			MRVL_APHY_U32 suspend_instruction : 8;
		}bits;
		MRVL_APHY_U32 whole;
	}DWORD_13;

	union
	{
		struct {
			MRVL_APHY_U32 reserved_1 : 2;
			MRVL_APHY_U32 status_register_polling_device_busy : 6;
			MRVL_APHY_U32 exit_deep_power_down_to_next_operation_delay : 5;
			MRVL_APHY_U32 exit_deep_power_down_to_next_operation_delay_units : 2;
			MRVL_APHY_U32 exit_deep_power_down_instruction : 8;
			MRVL_APHY_U32 enter_deep_power_down_instruction : 8;
			MRVL_APHY_U32 deep_power_down_supported : 1;
		}bits;
		MRVL_APHY_U32 whole;
	}DWORD_14;

	union
	{
		struct {
			MRVL_APHY_U32 mode_disable_sequences_QPIDI_4_4_4 : 4;
			MRVL_APHY_U32 mode_enable_sequences_QPIEN_4_4_4 : 5;
			MRVL_APHY_U32 mode_dupported_0_4_4 : 1;
			MRVL_APHY_U32 mode_exit_method_0_4_4 : 6;
			MRVL_APHY_U32 mode_entry_method_0_4_4 : 4;
			MRVL_APHY_U32 quad_enable_requirements_QER : 3;
			MRVL_APHY_U32 hold_or_RESET_disable : 1;
			MRVL_APHY_U32 reserved_1 : 8;
		}bits;
		MRVL_APHY_U32 whole;
	}DWORD_15;

	union
	{
		struct {
			MRVL_APHY_U32 volatile_or_on_volatile_WREN_instruction_sr : 2;
			MRVL_APHY_U32 reserved_1 : 6;
			MRVL_APHY_U32 soft_resetand_rescue_sequence_support : 5;
			MRVL_APHY_U32 exit_4_byte_addressing : 2;
			MRVL_APHY_U32 enter_4_byte_addressing : 8;
		}bits;
		MRVL_APHY_U32 whole;
	}DWORD_16;

}SFDP_PARAMETER_TABLE_1;

/**
 * @brief Structure of 32-bit counters for RS-FEC frames
 *
 */
typedef struct
{
	MRVL_APHY_U64  correctedRSFrames;		/*!< number of RS frames have been corrected by RS FEC decoder */
	MRVL_APHY_U64  notCorrectedRSFrames;	/*!< number of RS frames could not be corrected by RS FEC decoder */
	MRVL_APHY_U64  goodRSFrames;			/*!< number of good RS frames decoded by Rx FEC Decoder */
} MRVL_AMG_RS_Frame_Counter;

/**
 * @brief Structure of cable status
 *
 */
typedef enum
{
	MRVL_AMG_CableDiagnostic_FaultType_None = 0,	/*!< good cable */
	MRVL_AMG_CableDiagnostic_FaultType_Open = 1,	/*!< one bus or both bus open */
	MRVL_AMG_CableDiagnostic_FaultType_Short = 2,	/*!< short of both conductors to GND or VBAT. Or short between both bus. */
	MRVL_AMG_CableDiagnostic_FaultType_Invalid = 3
}MRVL_AMG_CableDiagnostic_FaultType;

/**
 * @brief Structure of cable diagnostic result
 *
 */
typedef struct
{
	MRVL_AMG_CableDiagnostic_FaultType  faultType;	/*!< cable status, see MRVL_AMG_CableDiagnostic_FaultType */
	MRVL_APHY_U16 faultLength;						/*!< distance to fault in centimeters */
	MRVL_APHY_U8 discontinuityCount;				/*!< number (up to 5) of discontinuities/segments detected in a good cable (FaultType_None) */
	MRVL_APHY_U16 discontinuityLength[TDR_ARRAY_LENGTH];			/*!< discontinuity/segment lengths in cm. Array size is 5. */
} MRVL_AMG_CableDiagnostic;


#endif /* MRVL_AMG_TYPES_H */
