/**
 * @file MRVL_AMG_API.h
 * @brief Marvell Multi-gig Automotive Ethernet PHY Mode Ctrl API header file for device control and status checking
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */

#ifndef MRVL_AMG_API_H
#define MRVL_AMG_API_H

#include "MRVL_AMG_HwInterface.h"

/** @defgroup PHYCtrl_Top PHY Mode CTRL Top */


/******************************************************************************
 *      General Status
 ******************************************************************************/
/** @defgroup PHY_STATUS PHY Status Checking
 * @ingroup PHYCtrl_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_GetDeviceInfo(MRVL_DEV_PTR device);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_GetTemperature(MRVL_DEV_PTR device, MRVL_APHY_U16* temperature);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_GetChipRevision(MRVL_DEV_PTR device, MRVL_AMG_ChipRevision* chipRev);


/******************************************************************************
 *      T1 Mode Configuration and Status Checking
 ******************************************************************************/
/** @defgroup PHY_T1_MODE T1 Mode Configuration and Status Checking
 * @ingroup PHYCtrl_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_T1_GetLinkStatus(MRVL_DEV_PTR device, MRVL_AMG_LinkStatus* linkStatus);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_T1_GetPolarity(MRVL_DEV_PTR device, MRVL_AMG_Polarity* polarity);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_T1_GetMasterSlaveStatus(MRVL_DEV_PTR device, MRVL_APHY_OPERATION_MODE* mode);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_T1_SetMasterSlaveStatus(MRVL_DEV_PTR device, MRVL_APHY_OPERATION_MODE mode);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_T1_GetSpeed(MRVL_DEV_PTR device, MRVL_APHY_SPEED* speed);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_T1_SetSpeed(MRVL_DEV_PTR device, MRVL_APHY_SPEED speed);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_T1_GetCounter(MRVL_DEV_PTR device, MRVL_AMG_Counter* counters);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_T1_ClearCounter(MRVL_DEV_PTR device);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_T1_GetSNR(MRVL_DEV_PTR device, MRVL_AMG_SNR* snr);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_T1_ConfigLowPower(MRVL_DEV_PTR device, MRVL_APHY_BOOL isLowPower);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_T1_ConfigDisableTx(MRVL_DEV_PTR device, MRVL_APHY_BOOL isDisableTx);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_T1_GetRSFrameCounter(MRVL_DEV_PTR device, MRVL_AMG_RS_Frame_Counter* counters);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_T1_RestartLineLink(MRVL_DEV_PTR device);


/******************************************************************************
 *      SerDes Mode Configuration and Status Checking
 ******************************************************************************/
/** @defgroup PHY_SerDes_MODE SerDes Mode Configuration and Status Checking
 * @ingroup PHYCtrl_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_SerDes_GetLinkStatus(MRVL_DEV_PTR device, MRVL_AMG_LinkStatus* linkStatus);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_SerDes_GetSpeed(MRVL_DEV_PTR device, MRVL_APHY_SERDES_SPEED* speed);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_SerDes_SetSpeed(MRVL_DEV_PTR device, MRVL_APHY_SERDES_SPEED speed);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_SerDes_GetCounter(MRVL_DEV_PTR device, MRVL_AMG_Counter* counters);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_SerDes_ClearCounter(MRVL_DEV_PTR device);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_SerDes_RestartSysLink(MRVL_DEV_PTR device);


/******************************************************************************
 *      Host Initialization or Configuration
 ******************************************************************************/
/** @defgroup PHY_HOST Host Initialization Configuration
 * @ingroup PHYCtrl_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_ResetChip(MRVL_DEV_PTR device);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_HCS_GetTimeout(MRVL_DEV_PTR device, MRVL_APHY_U16* timeout);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_HCS_SetTimeout(MRVL_DEV_PTR device, MRVL_APHY_U16 timeout);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_HCS_DisableTimeout(MRVL_DEV_PTR device, MRVL_APHY_BOOL disable);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_HCS_Commence(MRVL_DEV_PTR device, MRVL_APHY_BOOL commence);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_HCS_Finalize(MRVL_DEV_PTR device, MRVL_APHY_BOOL finalize);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_HCS_GetState(MRVL_DEV_PTR device, MRVL_AMG_HCS_State* state);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_HCS_GetElapsedTime(MRVL_DEV_PTR device, MRVL_APHY_U16* time);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_HCS_GetHostReactionTime(MRVL_DEV_PTR device, MRVL_APHY_U16* time);


/******************************************************************************
 *      Packet Generator and Checker
 ******************************************************************************/
/** @defgroup PHY_PGEN PHY Packet Generator and Checker
 * @ingroup PHYCtrl_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_GetGeneratorDataPath(MRVL_DEV_PTR device, MRVL_AMG_DATAPATH* datapath);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_GetCheckerDataPath(MRVL_DEV_PTR device, MRVL_AMG_DATAPATH* datapath);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_SetGeneratorDataPath(MRVL_DEV_PTR device, MRVL_AMG_DATAPATH datapath);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_SetCheckerDataPath(MRVL_DEV_PTR device, MRVL_AMG_DATAPATH datapath);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_GetIFGMode(MRVL_DEV_PTR device, MRVL_AMG_PACKETGEN_IFG* mode);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_SetIFGMode(MRVL_DEV_PTR device, MRVL_AMG_PACKETGEN_IFG mode);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_GetLengthMode(MRVL_DEV_PTR device, MRVL_AMG_PACKETGEN_LENGHT* mode);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_SetLengthMode(MRVL_DEV_PTR device, MRVL_AMG_PACKETGEN_LENGHT mode);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_GetPayloadMode(MRVL_DEV_PTR device, MRVL_AMG_PACKETGEN_PAYLOAD_MODE* mode);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_SetPayloadMode(MRVL_DEV_PTR device, MRVL_AMG_PACKETGEN_PAYLOAD_MODE mode);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_GetOperationMode(MRVL_DEV_PTR device, MRVL_AMG_PACKETGEN_OPERATION_MODE* mode);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_SetOperationMode(MRVL_DEV_PTR device, MRVL_AMG_PACKETGEN_OPERATION_MODE mode);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_GetMaxCount(MRVL_DEV_PTR device, MRVL_APHY_U16* count);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_SetMaxCount(MRVL_DEV_PTR device, MRVL_APHY_U16 count);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_GetMinIFG(MRVL_DEV_PTR device, MRVL_APHY_U32* count);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_SetMinIFG(MRVL_DEV_PTR device, MRVL_APHY_U32 count);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_GetMaxIFG(MRVL_DEV_PTR device, MRVL_APHY_U32* count);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_SetMaxIFG(MRVL_DEV_PTR device, MRVL_APHY_U32 count);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_GetMinLength(MRVL_DEV_PTR device, MRVL_APHY_U16* count);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_SetMinLength(MRVL_DEV_PTR device, MRVL_APHY_U16 count);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_GetMaxLength(MRVL_DEV_PTR device, MRVL_APHY_U16* count);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_SetMaxLength(MRVL_DEV_PTR device, MRVL_APHY_U16 count);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_GetState(MRVL_DEV_PTR device, MRVL_APHY_BOOL* state);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_EnableGenerator(MRVL_DEV_PTR device, MRVL_APHY_BOOL enable);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_EnableChecker(MRVL_DEV_PTR device, MRVL_APHY_BOOL enable);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_PKT_EnableLatencyMeasure(MRVL_DEV_PTR device, MRVL_APHY_BOOL enable);

/******************************************************************************
 *      Test Mode
 ******************************************************************************/
/** @defgroup PHY_TEST PHY Test Mode Configuration
 * @ingroup PHYCtrl_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_SetTM2JitterTestControl(MRVL_DEV_PTR device, MRVL_AMG_JitterTestControl jitterPattern);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_GetTM2JitterTestControl(MRVL_DEV_PTR device, MRVL_AMG_JitterTestControl* jitterPattern);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_SetTestMode(MRVL_DEV_PTR device, MRVL_AMG_TestMode testControl);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_GetTestMode(MRVL_DEV_PTR device, MRVL_AMG_TestMode* testControl);

/******************************************************************************
 *      Loopback
 ******************************************************************************/
/** @defgroup PHY_LOOPBACK PHY Loopback Configuration
 * @ingroup PHYCtrl_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_SetLoopback(MRVL_DEV_PTR device, MRVL_AMG_Loopback loopback, MRVL_APHY_BOOL enable);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_GetLoopback(MRVL_DEV_PTR device, MRVL_AMG_Loopback loopback, MRVL_APHY_BOOL* enable);


/******************************************************************************
 *      LED
 ******************************************************************************/
/** @defgroup PHY_LED PHY LED Configuration
 * @ingroup PHYCtrl_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_LED_GetBlinkingLength(MRVL_DEV_PTR device, MRVL_APHY_U8* length);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_LED_SetBlinkingLength(MRVL_DEV_PTR device, MRVL_APHY_U8 length);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_LED_GetLinkStatus(MRVL_DEV_PTR device, MRVL_AMG_LED_LINK_STATUS* state);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_LED_SetLinkStatus(MRVL_DEV_PTR device, MRVL_AMG_LED_LINK_STATUS state);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_LED_GetLinkActivity(MRVL_DEV_PTR device, MRVL_AMG_LED_LINK_ACTIVITY* state);
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_LED_SetLinkActivity(MRVL_DEV_PTR device, MRVL_AMG_LED_LINK_ACTIVITY state);


/******************************************************************************
 *      DIAG
 ******************************************************************************/
/** @defgroup PHY_DIAG PHY Cable Diagnostics
 * @ingroup PHYCtrl_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_T1_GetCableDiagnostic(MRVL_DEV_PTR device, MRVL_AMG_CableDiagnostic* diagnostics);

#endif
