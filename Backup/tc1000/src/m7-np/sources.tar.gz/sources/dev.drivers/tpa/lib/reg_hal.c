// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          reg_hal.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    library functions for fast path module
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifdef __linux__
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                     Include Files
 **********************************************************************/
/* IMG portal Ticket: 136135
   Add below line to avoid build error */
#include <linux/pci.h>

#include <asm-generic/io.h>
#include <linux/delay.h>
#endif //ifdef __linux__

#include "reg_hal.h"
#include "fp_library.h"
#include "global_base_address.h"
#include "class_hw_csr.h"
#include "global_address_map_fpga.h"

#define EPP_TABLE_IND_ACCESS_ADDR_T1	(EPP_TABLE1_BASE_ADDR + CLASS_HW_CSR_CLASS_BUS_ACCESS_ADDR)
#define EPP_TABLE_IND_ACCESS_WDATA_T1	(EPP_TABLE1_BASE_ADDR + CLASS_HW_CSR_CLASS_BUS_ACCESS_WDATA)
#define EPP_TABLE_IND_ACCESS_RDATA_T1	(EPP_TABLE1_BASE_ADDR + CLASS_HW_CSR_CLASS_BUS_ACCESS_RDATA)

#define CLASS_INDIRECT_ACCESS_READ	CLASS_INDIRECT_ACCESS_READ_T3
#define CLASS_INDIRECT_ACCESS_WRITE 	CLASS_INDIRECT_ACCESS_WRITE_T3

#define EPP_TABLE_IND_ACCESS_ADDR_T2 	(EPP_TABLE2_BASE_ADDR + CLASS_HW_CSR_CLASS_BUS_ACCESS_ADDR)
#define EPP_TABLE_IND_ACCESS_WDATA_T2	(EPP_TABLE2_BASE_ADDR + CLASS_HW_CSR_CLASS_BUS_ACCESS_WDATA)
#define EPP_TABLE_IND_ACCESS_RDATA_T2	(EPP_TABLE2_BASE_ADDR + CLASS_HW_CSR_CLASS_BUS_ACCESS_RDATA)

#define EPP_TABLE_IND_ACCESS_ADDR_T3	(EPP_TABLE3_BASE_ADDR + CLASS_HW_CSR_CLASS_BUS_ACCESS_ADDR)
#define EPP_TABLE_IND_ACCESS_WDATA_T3	(EPP_TABLE3_BASE_ADDR + CLASS_HW_CSR_CLASS_BUS_ACCESS_WDATA)
#define EPP_TABLE_IND_ACCESS_RDATA_T3	(EPP_TABLE3_BASE_ADDR + CLASS_HW_CSR_CLASS_BUS_ACCESS_RDATA)

#define CLASS_BUS_ACCESS_ADDR		(HGPI_CLASS_BASE_ADDR + CLASS_HW_CSR_CLASS_BUS_ACCESS_ADDR)
#define CLASS_BUS_ACCESS_WDATA		(HGPI_CLASS_BASE_ADDR + CLASS_HW_CSR_CLASS_BUS_ACCESS_WDATA)
#define CLASS_BUS_ACCESS_RDATA		(HGPI_CLASS_BASE_ADDR + CLASS_HW_CSR_CLASS_BUS_ACCESS_RDATA)

#define WAIT_DELAY	(2)	/*	gives about 2uS delay.	*/
#define MAX_WAIT_TICKS	(100)	/*	maximum number of ticks of WAIT_DELAY	*/

#define LOCK	while (false) {;}
#define UNLOCK	while (false) {;}

/* enable this #define to log all reads/writes via printk */
//#define DEBUG_HAL

#ifdef DEBUG_HAL
//#define PRINT_READ(a,v)		printk("Read from: %px val = %08x", a, v);
//#define PRINT_WRITE(a,v)	printk("Write  to: %px val   %08x", a, v);
#define PRINT_READ(a,v)		printk("Read from: %lx val = %08x", a, v);
#define PRINT_WRITE(a,v)	printk("Write  to: %lx val   %08x", a, v);
#define PRINT_MEMBASE(m)	printk("membase set to %px -",m);
#else
#define PRINT_READ(a,v)		while (false) {;}
#define PRINT_WRITE(a,v)	while (false) {;}
#define PRINT_MEMBASE(m)	while (false) {;}
#endif

static void *membase = NULL;

#define MDIO_CHECK_DELAY (100)
static int MdioCheckBusy(unsigned long reg_addr, int *ptimeout_cnt);

/*****************************************************************
 * Function Name  : InitBaseAddr()
 * Description    : Set the memory base address of the EPP registers
 * Inputs
 *   Parameters   : void pointer
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 ****************************************************************/
/*inline*/
void InitBaseAddr(void *BaseAddr)
{
//	ENTER;
	if (NULL != membase)
	{
		TPA_E("Warning membase is %px - changing to %px",membase, BaseAddr);
	}
	membase = BaseAddr;
	TPA_D("membase set to %px -", membase);
//	LEAVE;
}

/*****************************************************************
 * Function Name  : GetBaseAddr()
 * Description    : Get the memory base address of the EPP registers
 * Inputs
 *   Parameters   : -
 * Outputs        :
 *   Parameters   : -
 *   Returns      : void pointer containing the memory base address
 * Changes        :
 ****************************************************************/
/*inline*/
void *GetBaseAddr()
{
	PRINT_MEMBASE(membase);
	return membase;
}

/* NOTE  --
 * ========
 * use of readl() and writel() is now deprecated in the kernel.
 * For PCI memory the ioreadX() and iowriteX() functions should be used
 * along with memory barrier functions rmb(), wmb() and mb() where
 * appropriate.
 * The above applies to both PC (x86 and x86_64) and ARM architectures
 */
/*****************************************************************
 * Function Name  : RegRead()
 * Description    : Hardware register read function return register
 *                  read value for given address.
 * Inputs
 *   Parameters   : uint32a
 * Outputs        :
 *   Parameters   : -
 *   Returns      : uint32a
 * Changes        :
 ****************************************************************/
/*inline*/
uint32a RegRead(uint32 Register)
{
	if (NULL == membase) {
		TPA_E("Cannot Read register -- membase NOT SET");
	} else {
		void *Address = (void*)(membase+Register);
		uint32a val = 0;

		#ifdef __linux__
		val = ioread32(Address);
		rmb();
		#else
		val = (uint32)SAL_ReadReg(Address);
		#endif
		#if 0
		{
			/* to supress huge logs for table setting */
			if( (Register != 0x20ca28) &
				(Register != 0x20ca2c) &
				(Register != 0x20ca30) &
				(Register != 0x60ca28) &
				(Register != 0x60ca2c) &
				(Register != 0x60ca30) &
				(Register != 0x208140) &
				(Register != 0x209140) &
				(Register != 0x20a140) &
				(Register != 0x608140) &
				(Register != 0x680040)
			)
			{
				PRINT_READ(Register,val);
			}
		}
		#else
		PRINT_READ(Register,val);
		#endif
		return val;
	}
	return 0;
}

/******************************************************************
 * Function Name  : RegWrite()
 * Description    : Hardware register write function Write given value
 *                  in given address.
 * Inputs
 *   Parameters   : uint32a, uint32a
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *****************************************************************/
/*inline*/
void RegWrite(uint32 Register, uint32a RegData)
{
	void *Address = (void*)(membase+Register);
	if (0 == membase) {
		TPA_E("Cannot Write register -- membase NOT SET");
	} else {
		#if 0
		{
			/* to supress huge logs for table setting */
			if( (Register != 0x20ca28) &
				(Register != 0x20ca2c) &
				(Register != 0x20ca30) &
				(Register != 0x60ca28) &
				(Register != 0x60ca2c) &
				(Register != 0x60ca30) &
				(Register != 0x208134) &
				(Register != 0x208138) &
				(Register != 0x20813c) &
				(Register != 0x208140) &
				(Register != 0x209134) &
				(Register != 0x209138) &
				(Register != 0x20913c) &
				(Register != 0x209140) &
				(Register != 0x20a134) &
				(Register != 0x20a138) &
				(Register != 0x20a13c) &
				(Register != 0x20a140) &
				(Register != 0x608134) &
				(Register != 0x608138) &
				(Register != 0x60813c) &
				(Register != 0x608140) &
				(Register != 0x680040)
			)
			{
				PRINT_WRITE(Register,RegData);
			}
		}
		#else
		PRINT_WRITE(Register,RegData);
		#endif

		#ifdef __linux__
		iowrite32(RegData,Address);
		wmb();
		#else
		SAL_WriteReg(RegData, Address);
		#endif

#if 0// wr, then read to verify
		{
			/* confirm written data */
			uint32a val = 0;
			#ifdef __linux__
			val = ioread32(Address);
			rmb();
			#else
			val = (uint32)SAL_ReadReg(Address);
			#endif

			if(val != RegData)
			{
				printk("Differ offset 0x%06lX wr 0x%04X rd 0x%04X\n", Register, RegData, val);
			}
		}
#endif
	}
}

/* read from absolute address */
uint32a RegAbsRead(uint32 Register)
{
	return (uint32a)SAL_ReadReg(Register);
}

/* write to absolute address */
void RegAbsWrite(uint32 Register, uint32a RegData)
{
	SAL_WriteReg(RegData, Register);
}

/*****************************************************************
 * Function Name  : RegReadOffset()
 * Description    : Hardware register read function return register
 *                  read value for given address.
 * Inputs
 *   Parameters   : uint32a
 * Outputs        :
 *   Parameters   : -
 *   Returns      : uint32a
 * Changes        :
 ****************************************************************/
inline uint32a RegReadOffset(uint32 Register, uint32a Offset)
{
	uint32 Address = Offset + Register;
	return RegRead(Address);
}

/******************************************************************
 * Function Name  : RegWriteOffset()
 * Description    : Hardware register write function Write given value
 *                  in given address.
 * Inputs
 *   Parameters   : uint32a, uint32a
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *****************************************************************/
inline void RegWriteOffset(uint32 Register, uint32 Offset, uint32a RegData)
{
	uint32 Address = Register + Offset;
	RegWrite(Address,RegData);
}


/*****************************************************************
 * Function Name  : TableRead()
 * Description    : Hardware register read function return register
 *                  read value for given address.
 * Inputs
 *   Parameters   : uint32a
 * Outputs        :
 *   Parameters   : -
 *   Returns      : uint32a
 * Changes        :
 ****************************************************************/
uint32a TableRead(uint32 offset, int32a table)
{
	/* CBUS_ADDR_BASE is ZERO for non EMU builds, so MACRO has no effect
	 * CBUS_ADDR_BASE is NON-ZERO for EMU builds, so MACRO has the desired effect
	 */
	uint32a ret = 0;
	uint32 addr;
	uint32 ofs;
	LOCK;
	offset |= CBUS_ADDR_BASE;
	switch ( table ){
	case 1:
		addr = EPP_TABLE_IND_ACCESS_ADDR_T1;
		ofs  = EPP_TABLE_IND_ACCESS_RDATA_T1;
		break;
	case 2:
		addr = EPP_TABLE_IND_ACCESS_ADDR_T2;
		ofs  = EPP_TABLE_IND_ACCESS_RDATA_T2;
		break;
	case 3:
		addr = EPP_TABLE_IND_ACCESS_ADDR_T3;
		ofs  = EPP_TABLE_IND_ACCESS_RDATA_T3;
		break;
	default:
		printk("TableWrite -- Invalid table %d\n",table);
		return 0;
	}
	RegWrite(addr,((offset & 0x00FFFFFF) | 0x04000000));
	ret = RegRead(ofs);
	UNLOCK
	return ret;
}

/******************************************************************
 * Function Name  : TableWrite()
 * Description    : Hardware register write function Write given value
 *                  in given address.
 * Inputs
 *   Parameters   : uint32a, uint32a
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *****************************************************************/
void TableWrite(uint32 offset, uint32a value, int32a table)
{
	/* CBUS_ADDR_BASE is ZERO for non EMU builds, so MACRO has no effect
	 * CBUS_ADDR_BASE is NON-ZERO for EMU builds, so MACRO has the desired effect
	 */
	uint32 addr;
	uint32 ofs;

//	LOCK;
	offset |= CBUS_ADDR_BASE;
	switch(table)
	{
		case 1:
			addr = EPP_TABLE_IND_ACCESS_ADDR_T1;
			ofs  = EPP_TABLE_IND_ACCESS_WDATA_T1;
			break;
		case 2:
			addr = EPP_TABLE_IND_ACCESS_ADDR_T2;
			ofs  = EPP_TABLE_IND_ACCESS_WDATA_T2;
			break;
		case 3:
			addr = EPP_TABLE_IND_ACCESS_ADDR_T3;
			ofs  = EPP_TABLE_IND_ACCESS_WDATA_T3;
			break;
		default:
			TPA_E("TableWrite -- Invalid table %d\n",table);
			return;
	}

	RegWrite(ofs, value);
	RegWrite(addr, ((offset & 0x00FFFFFF) | 0x84000000));
//	UNLOCK;
}
//==============================================================================

void ClearStatus(	uint32a status_reg,
			uint32a clear_value)
{
	TableWrite(status_reg, clear_value, DEFAULT_TABLE);
}

uint32a CommandWait(uint32a status_reg, uint32a wait_for)
{
	uint32a cmd_done = 0;
	int32a tickcount = 0;
	do {
		cmd_done = TableRead(status_reg, DEFAULT_TABLE);
		if (!(cmd_done & wait_for)) {
			udelay(WAIT_DELAY);
			tickcount++;
		}
	} while ((0 == (cmd_done & wait_for)) && (tickcount < MAX_WAIT_TICKS));
	return cmd_done;
}

void IssueCommand_nowait(uint32a cmd_reg, uint32a command)
{
	TableWrite(cmd_reg, command, DEFAULT_TABLE);
}

uint32a IssueCommand(uint32a cmd_reg,
				uint32a command,
				uint32a status_reg,
				uint32a wait_for)
{
	IssueCommand_nowait(cmd_reg, command);
	return CommandWait(status_reg, wait_for);
}

uint32a IssueCommand_CS(uint32a cmd_reg,
				uint32a command,
				uint32a status_reg,
				uint32a wait_for,
				uint32a clear_value)
{
	uint32a cmd_done = 0;
	cmd_done = IssueCommand(cmd_reg, command, status_reg, wait_for);
	ClearStatus(status_reg, clear_value);
	return cmd_done;
}
//==============================================================================
void ClearStatusTable(uint32a status_reg,
			uint32a clear_value,
			uint32a table_num)
{
	TableWrite(status_reg, clear_value, table_num);
}

uint32a CommandWaitTable(uint32a status_reg,
				uint32a wait_for,
				uint32a table_num)
{
	uint32a cmd_done = 0;
	int32a tickcount = 0;
	do {
		cmd_done = TableRead(status_reg, table_num);
		if (!(cmd_done & wait_for)) {
			udelay(WAIT_DELAY);
			tickcount++;
		}
	} while ((0 == (cmd_done & wait_for)) && (tickcount < MAX_WAIT_TICKS));
	return cmd_done;
}

void IssueCommandTable_nowait(uint32a cmd_reg,
				uint32a command,
				uint32a table_num)
{
	TableWrite(cmd_reg,command, table_num);
}

uint32a IssueCommandTable(uint32a cmd_reg,
				uint32a command,
				uint32a status_reg,
				uint32a wait_for,
				uint32a table_num)
{
	IssueCommandTable_nowait(cmd_reg, command, table_num);
	return CommandWaitTable(status_reg, wait_for, table_num);
}

uint32a IssueCommandTable_CS(uint32a cmd_reg,
					uint32a command,
					uint32a status_reg,
					uint32a wait_for,
					uint32a clear_value,
					uint32a table_num)
{
	uint32a cmd_done = 0;
	cmd_done = IssueCommandTable(	cmd_reg,
					command,
					status_reg,
					wait_for,
					table_num);
	ClearStatusTable(status_reg, clear_value, table_num);
	return cmd_done;
}

//#define MDIO_DEBUG
#define XMDIO_DEBUG
#ifdef printk
#undef printk
#define printk mcu_printf
#endif
//==============================================================================

/* ret =  1 : success
          0 : timeout
ptimeout_cnt = pointer to countdown value, value will be decreased 1 per 100us */
static int32a MdioCheckBusy(uint32 reg_addr, int32a *ptimeout_cnt)
{
	uint32a val;
	int32a timeout_cnt;

	timeout_cnt = *ptimeout_cnt;
	while((--timeout_cnt)>0)
	{
		/* check busy flag */
		val = RegRead(reg_addr);
		if( (val&0x1) == 0)
		{
			break;
		}
		udelay(1);//udelay(MDIO_CHECK_DELAY);
	}
	*ptimeout_cnt = timeout_cnt;

	if(timeout_cnt>0)
	{
		return 1;
	}

	/* timeout expire */
	printk("[%s] read addr[%08lx] busy flag timeout val[%08x]\n", __func__, reg_addr, val);
	return 0;
}

/* ret : read value
         or (-1) if busy_flag timeout */
int32a MdioRegRead(uint32a emac_idx, uint32a phy_addr, uint32a reg_addr)
{
	uint32 mdio_addr_reg;
	uint32 mdio_data_reg;
	uint32a addr_val;
	uint32a val;
	int32a timeout_cnt;
	int32a timeout_ret;

	addr_val = 0xD /* read op */
	| ((0x3)<<8 )           /* CR : 11:8 */
	| ((phy_addr&0x1F)<<21) /* PA : 25:21 */
	| ((reg_addr&0x1F)<<16) /* RDA : 20:16 */
	;

	switch(emac_idx)
	{
		case 0:
			mdio_addr_reg = EMAC1_MDIO_ADDR;
			mdio_data_reg = EMAC1_MDIO_DATA;
			break;
		case 1:
			mdio_addr_reg = EMAC2_MDIO_ADDR;
			mdio_data_reg = EMAC2_MDIO_DATA;
			break;
		case 2:
			mdio_addr_reg = EMAC3_MDIO_ADDR;
			mdio_data_reg = EMAC3_MDIO_DATA;
			break;
		case 3:
			mdio_addr_reg = EMAC4_MDIO_ADDR;
			mdio_data_reg = EMAC4_MDIO_DATA;
			break;
		default:
			mdio_addr_reg = EMAC1_MDIO_ADDR;
			mdio_data_reg = EMAC1_MDIO_DATA;
		break;
	}

	/* check busy_flag */
	timeout_cnt = 100;
	timeout_ret = MdioCheckBusy(mdio_addr_reg, &timeout_cnt);
	if( timeout_ret == 0 )
	{
		printk("read addr[%08lx] busy flag timeout\n", mdio_addr_reg);
		return (-1);
	}

	/* write 0 to mdio_data */
	val = 0;
	#ifdef MDIO_DEBUG
	printk("write addr[%08lx] val[%08x]\n", mdio_data_reg, val);
	#endif
	RegWrite(mdio_data_reg, 0);

	/* write addr to mdio_addr */
	val = addr_val;
	#ifdef MDIO_DEBUG
	printk("write addr[%08lx] val[%08x]\n", mdio_addr_reg, val);
	#endif
	RegWrite(mdio_addr_reg, val);

	/* check busy_flag before read */
	timeout_cnt = 100;
	timeout_ret = MdioCheckBusy(mdio_addr_reg, &timeout_cnt);
	if( timeout_ret == 0 )
	{
		printk("read addr[%08lx] busy flag timeout\n", mdio_addr_reg);
		return (-1);
	}

	/* read mdio_data */
	val = RegRead(mdio_data_reg);
	#ifdef MDIO_DEBUG
	#if 0
	//printk("read addr[%08lx] val[%08x]\n", mdio_data_reg, val);
	#else
	printk("read addr[%08lx] val[%08x] timeout_cnt[%d]\n", mdio_data_reg, val, timeout_cnt);
	#endif
	#endif

	return val;
}

/* ret : written value
         or (-1) if busy_flag timeout */
int32a MdioRegWrite(uint32a emac_idx, uint32a phy_addr, uint32a reg_addr, uint32a phy_data)
{
	uint32 mdio_addr_reg;
	uint32 mdio_data_reg;
	uint32a addr_val;
	uint32a val;
	int32a timeout_cnt;
	int32a timeout_ret;

	addr_val = 0x5 /* write op */
	| ((0x3)<<8 )           /* CR : 11:8 */
	| ((phy_addr&0x1F)<<21) /* PA : 25:21 */
	| ((reg_addr&0x1F)<<16) /* RDA : 20:16 */
	;

	switch(emac_idx)
	{
		case 0:
			mdio_addr_reg = EMAC1_MDIO_ADDR;
			mdio_data_reg = EMAC1_MDIO_DATA;
			break;
		case 1:
			mdio_addr_reg = EMAC2_MDIO_ADDR;
			mdio_data_reg = EMAC2_MDIO_DATA;
			break;
		case 2:
			mdio_addr_reg = EMAC3_MDIO_ADDR;
			mdio_data_reg = EMAC3_MDIO_DATA;
			break;
		case 3:
			mdio_addr_reg = EMAC4_MDIO_ADDR;
			mdio_data_reg = EMAC4_MDIO_DATA;
			break;
		default:
			mdio_addr_reg = EMAC1_MDIO_ADDR;
			mdio_data_reg = EMAC1_MDIO_DATA;
		break;
	}

	/* check busy_flag */
	timeout_cnt = 100;
	timeout_ret = MdioCheckBusy(mdio_addr_reg, &timeout_cnt);
	if( timeout_ret == 0 )
	{
		printk("read addr[%08lx] busy flag timeout\n", mdio_addr_reg);
		return (-1);
	}

	/* write val to mdio_data */
	val = phy_data;
	#ifdef MDIO_DEBUG
	printk("write addr[%08lx] val[%08x]\n", mdio_data_reg, val);
	#endif
	RegWrite(mdio_data_reg, val);

	/* write addr to mdio_addr */
	val = addr_val;
	#ifdef MDIO_DEBUG
	printk("write addr[%08lx] val[%08x]\n", mdio_addr_reg, val);
	#endif
	RegWrite(mdio_addr_reg, val);

	/* check busy_flag before finish */
	timeout_cnt = 100;
	timeout_ret = MdioCheckBusy(mdio_addr_reg, &timeout_cnt);
	if( timeout_ret == 0 )
	{
		printk("read addr[%08lx] busy flag timeout\n", mdio_addr_reg);
		return (-1);
	}

	return phy_data;
}

int32a XMdioRegRead(uint32a emac_idx, uint32a phy_addr, uint32a dev_addr, uint32a reg_addr)
{
	int32a ret;

	ret = MdioRegWrite(emac_idx, phy_addr, 0xD, dev_addr|0x0000); // operation : address
	if(ret < 0)
	{
		return -1;
	}
	ret = MdioRegWrite(emac_idx, phy_addr, 0xE, reg_addr);
	if(ret < 0)
	{
		return -2;
	}
	ret = MdioRegWrite(emac_idx, phy_addr, 0xD, dev_addr|0x4000); // operation : r/w
	if(ret < 0)
	{
		return -3;
	}
	ret = MdioRegRead(emac_idx, phy_addr, 0xE);
	if(ret < 0)
	{
		return -4;
	}

#ifdef XMDIO_DEBUG
	printk("mdio45 read emac%d, phyaddr %02x, device %d, reg 0x%04x, val=0x%04x\n", emac_idx, phy_addr, dev_addr, reg_addr, ret);
#endif
	return ret;
}

int32a XMdioRegWrite(uint32a emac_idx, uint32a phy_addr, uint32a dev_addr, uint32a reg_addr, uint32a phy_data)
{
	int32a ret;
	//device = 0x7;
	//reg_addr =0x0200;
	//val = 0x0000;
	ret = MdioRegWrite(emac_idx, phy_addr, 0xD, dev_addr|0x0000); // operation : address
	if(ret < 0)
	{
		return -1;
	}
	ret = MdioRegWrite(emac_idx, phy_addr, 0xE, reg_addr);
	if(ret < 0)
	{
		return -1;
	}
	ret = MdioRegWrite(emac_idx, phy_addr, 0xD, dev_addr|0x4000); // operation : r/w
	if(ret < 0)
	{
		return -1;
	}
	ret = MdioRegWrite(emac_idx, phy_addr, 0xE, phy_data);
	if(ret < 0)
	{
		return -1;
	}
	ret = phy_data;

#ifdef XMDIO_DEBUG
	printk("mdio45 write emac%d, phyaddr %02x, device %d, reg 0x%04x, val=0x%04x\n", emac_idx, phy_addr, dev_addr, reg_addr, phy_data);
#endif
	return ret;
}

