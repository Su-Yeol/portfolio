// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          switchApi_blocks_ctrlm.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    contains function to write various values to switch API functions.
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

#include "fp_library.h"
#include "fp_ioctl.h"
#include "fp_common_msg_header.h"
#include "fp_common_ctlm.h"
#include "switchApi_blocks_ctrlm.h"
#include "fp_switch.h"
#include "fp_switch_api.h"
#include "fp_acl_api.h"
#include "fp_cb_api.h"
#include "fp_net_driver.h"
/************************************************************************
			GLOBAL VARIABLES
*************************************************************************/

/*************************************************************************
 * Description    : Main function to set tlite config parameters
 *************************************************************************/
extern int32a fp_ingqos_write_config(int32a portno,int32a index, uint32a *data);
extern int32a fp_ingqos_read_config(int32a portno);
extern uint32a qos_data[64][8];
extern void fp_config_coalesceing(	struct fp_private *fp,
					uint32a enable_coalesce_timer,
					uint32a enable_coalesce_frame_cnt,
					uint32a timer_val,
					uint32a frame_cnt);

int32a pcm_switchApi_config_ioctl(struct net_device *dev, struct ifreq *rq, int32a cmd)
{
	uint8 *devv = NULL;
	int32a action_entry, ret;
	nc_ioctl_ops_t *pnc_ops;
	nc_ioctl_ops_t nc_ops;
	pcm_msg_header_t *pmsg;
	pcm_msg_header_t msg;
	ret = copy_from_user(	&nc_ops,
				(nc_ioctl_ops_t *)rq->ifr_ifru.ifru_data,
				sizeof(nc_ops));
	if (ret)
		return -1;
	pnc_ops = &nc_ops;
	ret = copy_from_user(	&msg,
				(pcm_msg_header_t *)nc_ops.io_data,
				sizeof(msg));
	if (ret)
		return -1;
	pmsg = &msg;
	switch (pmsg->pcmh_type) {
	case PCM_MSG_SWITCH_BR_ENTRY_ADD:
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"%s:PCM_MSG_SWITCH_BR_ENTRY_ADD\n", __func__);
#endif
	{
		switch_br_entry_add_params_t entry_add;
		ret = copy_from_user(	&entry_add,
					(switch_br_entry_add_params_t *)(((uint8 *)pnc_ops->io_data) + sizeof(pcm_msg_header_t)),
					sizeof(switch_br_entry_add_params_t));
		if (ret)
			return -1;
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
				"switch_br_entry_add vlanid = %x"
				"fwdportList = %x untagList = %x"
				"ucastHitAct = %x mcastHitAct = %x"
				"ucastMissAct = %x mcastMissAct = %x"
				"mstpAct = %d\n",
				entry_add.swbea_vlanId,
				entry_add.swbea_fwdPortList,
				entry_add.swbea_untagList,
				entry_add.swbea_ucastHitAct,
				entry_add.swbea_mcastHitAct,
				entry_add.swbea_ucastMissAct,
				entry_add.swbea_mcastMissAct,
				entry_add.swbea_mstpAct);
		/*bridge entry add*/
		ret =  fp_br_entry_add(	entry_add.swbea_vlanId,
					entry_add.swbea_fwdPortList,
					entry_add.swbea_untagList,
					entry_add.swbea_ucastHitAct,
					entry_add.swbea_mcastHitAct,
					entry_add.swbea_ucastMissAct,
					entry_add.swbea_mcastMissAct,
					entry_add.swbea_mstpAct);
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"ret = fp_br_entry_add = %d\n", ret);
		return ret;
	}
	break;

	case PCM_MSG_SWITCH_BR_ENTRY_SEARCH:
	{
		int64_t action;
		action = fp_br_entry_search(pmsg->pcmh_value);
		ret = copy_to_user(pnc_ops->io_data, &action, sizeof(int64_t));
		return 0;
	}
	break;

	case PCM_MSG_SWITCH_BR_ENTRY_ADD_PORTS:
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"%s:PCM_MSG_SWITCH_BR_ENTRY_ADD_PORTS\n", __func__);
#endif
	{
		switch_br_entry_add_ports_params_t entry_add;
		ret = copy_from_user(	&entry_add,
					(switch_br_entry_add_ports_params_t *)(((uint8 *)pnc_ops->io_data) + sizeof(pcm_msg_header_t)),
					sizeof(switch_br_entry_add_ports_params_t));
		if (ret)
			return -1;
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"switch_br_entry_add_ports vlanid = %d"
			"portList = %d untagList = %d\n",
			entry_add.swbeap_vlanId,
			entry_add.swbeap_portList,
			entry_add.swbeap_untagList);
		/*bridge entry add ports*/
		return fp_br_entry_add_ports(	entry_add.swbeap_vlanId,
						entry_add.swbeap_portList,
						entry_add.swbeap_untagList);
	}
	break;

	case PCM_MSG_SWITCH_BR_ENTRY_PORTLIST_GET:
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"%s:PCM_MSG_SWITCH_BR_ENTRY_PORTLIST_GET\n", __func__);
#endif
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"switch_br_entry_portlist_get vlanid = %d\n",
				pmsg->pcmh_value);
		action_entry = 0;
		/*get bridge entry port list */
		action_entry = fp_br_entry_portlist_get(pmsg->pcmh_value);
		ret = copy_to_user(pnc_ops->io_data, &action_entry, sizeof(int32a));
	break;

	case PCM_MSG_SWITCH_BR_ENTRY_UNTAGLIST_GET:
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"%s:PCM_MSG_SWITCH_BR_ENTRY_UNTAGLIST_GET\n", __func__);
#endif
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"switch_br_entry_untaglist_get vlanid = %d\n",
					pmsg->pcmh_value);
		action_entry = 0;
		/*bridge entry untag list */
		/* action_entry = fp_br_entry_portlist_get(
							pmsg->pcmh_value); */
		action_entry = fp_br_entry_untaglist_get(pmsg->pcmh_value);
		ret = copy_to_user(pnc_ops->io_data, &action_entry, sizeof(action_entry));
	break;

	case PCM_MSG_SWITCH_BR_ENTRY_PORT_TAG_CHG:
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"%s:PCM_MSG_SWITCH_BR_ENTRY_PORT_TAG_CHG\n", __func__);
#endif
	{
		switch_br_entry_port_tag_chg_params_t ptagchg;
		ret = copy_from_user(	&ptagchg,
					(switch_br_entry_port_tag_chg_params_t *)(((uint8 *)pnc_ops->io_data) + sizeof(pcm_msg_header_t)),
					sizeof(switch_br_entry_port_tag_chg_params_t));
		if (ret)
			return -1;
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"switch_br_entry_port_tag_chg vlanid = %d"
			"portNo = %d tagValue = %d\n",
			ptagchg.ptchg_vlanId, ptagchg.ptchg_portNo,
			ptagchg.ptchg_tagValue);
		/*bridge entry port tag change*/
		return fp_br_entry_port_tag_chg(
			ptagchg.ptchg_vlanId, ptagchg.ptchg_portNo,
			ptagchg.ptchg_tagValue);
	}
	break;

	case PCM_MSG_SWITCH_BR_ENTRY_FWD_ACTION_GET:
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"%s:PCM_MSG_SWITCH_BR_ENTRY_FWD_ACTION_GET\n",
					__func__);
#endif
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"switch_br_entry_fwd_action_get vlanid = %d\n",
					pmsg->pcmh_value);
		action_entry = 0;
		/*get bridge entry farward action */
		action_entry = fp_br_entry_fwd_action_get(pmsg->pcmh_value);
		ret = copy_to_user(pnc_ops->io_data, &action_entry, sizeof(action_entry));
	break;

	case PCM_MSG_SWITCH_PORT_CONFIG_GET:
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"%s:PCM_MSG_SWITCH_PORT_CONFIG_GET\n", __func__);
#endif
	{
		struct port_s PortInfo;
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"switch_port_config_get portNo = %d\n",
				pmsg->pcmh_value);
		/*get port config */
		fp_port_config_get(devv,
				pmsg->pcmh_value, &PortInfo);
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"shutdown = %x\ntpid = %x\n"
			"aft = %x\nfallback_bd_id = %x\n"
			"block_state = %x\ntrusted = %x\n"
			"tcsel_table = %x\npcp2tc_table = %x\n"
			"def_cfi = %x\ndef_pri = %x\ndef_tc = %x\n"
			"tc2cos_table = %x\npindex = %x\n"
			"csr_untag_from_btable = %x", PortInfo.shutdown,
			PortInfo.tpid, PortInfo.aft,
			PortInfo.fallback_bd_id,
			PortInfo.block_state, PortInfo.trusted,
			PortInfo.tcsel_table, PortInfo.pcp2tc_table,
			PortInfo.def_cfi, PortInfo.def_pri,
			PortInfo.def_tc, PortInfo.tc2cos_table,
			PortInfo.pindex,
			PortInfo.csr_untag_from_btable);
		ret = copy_to_user(	pnc_ops->io_data,
					&PortInfo,
					sizeof(struct port_s));
	}
	break;

	case PCM_MSG_SWITCH_GLOBAL_BR_ENTRY_CONFIG_GET:
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"%s:PCM_MSG_SWITCH_GLOBAL_BR_ENTRY_CONFIG_GET\n",
								__func__);
#endif
	{
		struct global_s Global_br_entry;
		memset(&Global_br_entry, 0, sizeof(Global_br_entry));
		/*get global bridge entry config */
		fp_global_br_entry_config_get(&Global_br_entry);
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
		 "In switch case switch_global_br_entry_config_get\n");
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"l2_splPunt_enable = %x, fwdPortList = %x,"
			"untagList = %x, ucastHitAct = %x,"
			"mcastHitAct = %x, ucastMissAct = %x"
			"mcastMissAct = %x, mstpAct = %x",
			Global_br_entry.l2_special_punt_enable,
			Global_br_entry.fallback_bd_entry.forward_list,
			Global_br_entry.fallback_bd_entry.untag_list,
			Global_br_entry.
				fallback_bd_entry.ucast_hit_action,
			Global_br_entry.
				fallback_bd_entry.mcast_hit_action,
			Global_br_entry.
				fallback_bd_entry.ucast_miss_action,
			Global_br_entry.
				fallback_bd_entry.mcast_miss_action,
			Global_br_entry.
				fallback_bd_entry.mstp_id);
		ret = copy_to_user(	pnc_ops->io_data,
					&Global_br_entry,
					sizeof(Global_br_entry));
	}
	break;

	case PCM_MSG_SWITCH_BR_ENTRY_FWD_ACTION_CHANGE:
#if SWITCHAPI_DEBUG
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
		"%s:PCM_MSG_SWITCH_BR_ENTRY_FWD_ACTION_CHANGE\n",
				__func__);
#endif
	{
		switch_br_entry_farward_action_chg_params_t pfachg;
		ret = copy_from_user(	&pfachg,
					(switch_br_entry_farward_action_chg_params_t *)(((uint8 *)pnc_ops->io_data) + sizeof(pcm_msg_header_t)),
					sizeof(switch_br_entry_farward_action_chg_params_t));
		if (ret)
			return -1;
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"switch_br_entry_fwd_action_change vlanid = %d"
			"field = %d Value = %d\n",
			pfachg.pfachg_vlanId, pfachg.pfachg_field,
			pfachg.pfachg_value);
		/*bridge entry farward action change*/
		return fp_br_entry_fwd_action_change(
			pfachg.pfachg_vlanId, pfachg.pfachg_field,
			pfachg.pfachg_value);
	}
	break;

	case PCM_MSG_SWITCH_PORT_CONFIG:
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
				"%s:PCM_MSG_SWITCH_PORT_CONFIG\n", __func__);
#endif
	{
		struct port_s Port;
		ret = copy_from_user(	&Port,
					(struct port_s *)(((uint8 *)pnc_ops->io_data) + sizeof(pcm_msg_header_t)),
					sizeof(struct port_s));
		if (ret)
			return -1;
		/*port config */
		fp_port_config(pmsg->pcmh_value, &Port);
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"switch_port_config portNo = %d\n",
			pmsg->pcmh_value);
	}
	break;

	case PCM_MSG_SWITCH_GLOBAL_BR_ENTRY_CONFIG:
#if SWITCHAPI_DEBUG
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
		"%s:PCM_MSG_SWITCH_GLOBAL_BR_ENTRY_CONFIG\n", __func__);
#endif
	{
		struct global_s Global_br_entry;
		ret = copy_from_user(	&Global_br_entry,
					(struct global_s *)(((uint8 *)pnc_ops->io_data) + sizeof(pcm_msg_header_t)),
					sizeof(struct global_s));
		if (ret)
			return -1;
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
				"switch_global_br_entry_config\n");
		/*global bridge entry config */
		fp_global_br_entry_config( &Global_br_entry);
	}
	break;

	case PCM_MSG_SWITCH_BR_ENTRY_DEL:
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"%s:PCM_MSG_SWITCH_BR_ENTRY_DEL\n", __func__);
#endif
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"switch_br_entry_del vlanId = %d\n",
				pmsg->pcmh_value);
		/*delete bridge entry */
		ret = fp_br_entry_del(pmsg->pcmh_value);
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"ret = fp_br_entry_del = %d\n", ret);
		return ret;
	break;

	case PCM_MSG_SWITCH_BR_ENTRY_DEL_PORTS:
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"%s:PCM_MSG_SWITCH_BR_ENTRY_DEL\n", __func__);
#endif
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"switch_br_entry_del_ports vlanId = %d portList = %d\n",
				pmsg->pcmh_value, pmsg->pcmh_flags);
		/*delete bridge entry ports */
		return fp_br_entry_del_ports(pmsg->pcmh_value,
				pmsg->pcmh_flags);
	break;

	case PCM_MSG_SWITCH_MAC_ENTRY_ADD:
	{
		switch_fp_mac_entry_params_t Pmac;
		ret = copy_from_user(	&Pmac,
					(switch_fp_mac_entry_params_t *)(((uint8 *)pnc_ops->io_data) + sizeof(pcm_msg_header_t)),
					sizeof(switch_fp_mac_entry_params_t));
		if (ret)
			return -1;
		/*mac entry add */
		action_entry = fp_static_mac_entry_add(	Pmac.addr,
							Pmac.swbea_vlanId,
							Pmac.swbea_fwdPortList,
							Pmac.swbea_hitAct,
							Pmac.swbea_tc);
		ret = copy_to_user(pnc_ops->io_data, &action_entry, sizeof(int32a));
	}
	break;

	case PCM_MSG_SWITCH_MAC_ENTRY_DEL:
	{
		switch_fp_mac_entry_params_t Pmac;
		ret = copy_from_user(	&Pmac,
					(switch_fp_mac_entry_params_t *)(((uint8 *)pnc_ops->io_data) + sizeof(pcm_msg_header_t)),
					sizeof(switch_fp_mac_entry_params_t));
		if (ret)
			return -1;
		/*mac entry delete */
		fp_mac_entry_del(Pmac.addr, pmsg->pcmh_value);
	}
	break;

	case PCM_MSG_SWITCH_MAC_ENTRY_SEARCH:
	{
		switch_fp_mac_entry_params_t Pmac;
		ret = copy_from_user(	&Pmac,
					(switch_fp_mac_entry_params_t *)(((uint8 *)pnc_ops->io_data) + sizeof(pcm_msg_header_t)),
					sizeof(switch_fp_mac_entry_params_t));
		if (ret)
			return -1;
		/*mac entry search */
		action_entry = fp_mac_entry_search(	Pmac.addr,
							pmsg->pcmh_value);
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"case PCM_MSG_SWITCH_MAC_ENTRY_SEARCH:"
			"action_entry = %x\n", action_entry);
		ret = copy_to_user(pnc_ops->io_data, &action_entry, sizeof(int32a));
	}
	break;

	case PCM_MSG_SWITCH_MAC_ENTRY_UPDATE:
	{
		switch_fp_mac_entry_params_t Pmac;
		ret = copy_from_user(	&Pmac,
					(switch_fp_mac_entry_params_t *)(((uint8 *)pnc_ops->io_data) + sizeof(pcm_msg_header_t)),
					sizeof(switch_fp_mac_entry_params_t));
		if (ret)
			return -1;
		/* mac entry update */
		action_entry = fp_mac_entry_update(pmsg->pcmh_flags,
						Pmac.addr,
						pmsg->pcmh_value);
		ret = copy_to_user(pnc_ops->io_data, &action_entry, sizeof(action_entry));
	}
	break;
	case PCM_MSG_INTERRUPT_COALESCE:
	{
		//fp_config_coalesceing(fpGlobal,pmsg->pcmh_value,pmsg->pcmh_flags,pmsg->pcmh_length,pmsg->pcmh_value);
	}
	break;

	case PCM_MSG_INGQOS_CONFIG:
	{
		ing_qos_data_t reg;
		ret = copy_from_user(	&reg,
					(ing_qos_data_t *)(((uint8 *)pnc_ops->io_data) + sizeof(pcm_msg_header_t)),
					sizeof(ing_qos_data_t));
		if (ret)
			return -1;
		/*printk("reg0:%08x 1:%08x 2:%08x 3:%08x 4:%08x 5:%08x 6:%08x 7:%08x\n",
		  reg->data[0],reg->data[1],reg->data[2],reg->data[3],
		  reg->data[4],reg->data[5],reg->data[6],reg->data[7]);
		printk("portno:%x index:%x\n",pmsg->pcmh_flags,pmsg->pcmh_value);*/
		fp_ingqos_write_config(pmsg->pcmh_flags,pmsg->pcmh_value,(uint32a*)&reg);
	}
	break;

	case PCM_MSG_INGQOS_CONFIG_GET:
	{
		fp_ingqos_read_config(pmsg->pcmh_value);
		ret = copy_to_user(pnc_ops->io_data, &qos_data, sizeof(qos_data));
	}
	break;

	case PCM_MSG_ACL_CONFIG_ADD:
	{
		struct acl_entry acl_entry;
		ret = copy_from_user(	&acl_entry,
					(int8 *)nc_ops.io_data + sizeof(pcm_msg_header_t),
					sizeof(acl_entry));
		if (ret)
			return -1;
		ret = fp_acl_add_entry(pmsg->pcmh_value, &acl_entry);
		return ret;
	}
	break;

	case PCM_MSG_ACL_CONFIG_DEL:
	{
		ret = fp_acl_del_entry(pmsg->pcmh_value);
		return ret;
	}
	break;

	case PCM_MSG_ACL_CONFIG_SHOW:
	{
		struct acl_entry acl_entry;
		if (pmsg->pcmh_flags == 0)
		{
			ret = fp_acl_get_entry(pmsg->pcmh_value, &acl_entry);
			ret = copy_to_user(	pnc_ops->io_data,
						&acl_entry,
						sizeof(acl_entry));
			return ret;
		}
		else if (pmsg->pcmh_flags == 1)
		{
			int32a i = 0;
			for (i = 0; i < ACL_TABLE_SIZE; i++)
			{
				ret = fp_acl_get_entry(i, &acl_entry);
				ret = copy_to_user(	pnc_ops->io_data,
							&acl_entry,
							sizeof(acl_entry));
				pnc_ops->io_data += sizeof(struct acl_entry);
			}
			return 0;
		}
		else {
			printk("Incorrect vlaue pmsg->pcmh_flags \n");
			return -1;
		}
	}
	break;
	case PCM_MSG_CB_CONFIG_ADD:
	{
		fp_cb_entry_t cb_entry;
		ret = copy_from_user(	&cb_entry,
					(int8 *)nc_ops.io_data + sizeof(pcm_msg_header_t),
					sizeof(cb_entry));
		if (ret)
			return -1;
		ret = fp_cb_add_entry(&cb_entry);
		return ret;
	}
	break;

	case PCM_MSG_CB_CONFIG_DEL:
	{
		fp_cb_entry_t cb_entry;
		ret = copy_from_user(	&cb_entry,
					(int8 *)nc_ops.io_data + sizeof(pcm_msg_header_t),
					sizeof(cb_entry));
		if (ret)
			return -1;
		ret = fp_cb_del_entry(&cb_entry.mac[0], cb_entry.vlan, cb_entry.id_type);
		return ret;
	}
	break;

	case PCM_MSG_CB_CONFIG_SHOW:
	{
		if (pmsg->pcmh_flags == 0)
		{
			fp_cb_entry_t cb_entry;
			ret = copy_from_user(	&cb_entry,
						(int8 *)nc_ops.io_data + sizeof(pcm_msg_header_t),
						sizeof(cb_entry));
			if (ret)
				return -1;
			ret = fp_cb_get_entry(	&cb_entry.mac[0],
						cb_entry.vlan,
						cb_entry.id_type,
						&cb_entry);
			if (!ret)
				ret = copy_to_user(	pnc_ops->io_data,
							&cb_entry,
							sizeof(cb_entry));
			else
				ret = copy_to_user(	pnc_ops->io_data,
							&ret,
							sizeof(ret));
			return ret;
		}
		else if (pmsg->pcmh_flags == 1)
		{
			int32a i = 0;
		 	fp_cb_entry_t entry;
			for (i = 0; i < CB_TABLE_SIZE; i++)
			{
				memset(&entry, 0, sizeof(fp_cb_entry_t));
				ret = fp_cb_get_entry_by_index(i, &entry);
				if (!ret) {
					ret = copy_to_user(	pnc_ops->io_data,
								&entry,
								sizeof(entry));
					pnc_ops->io_data += sizeof(entry);
				}
				else {
					ret = copy_to_user(	pnc_ops->io_data,
								&ret,
								sizeof(ret));
					return ret;
				}
			}
			return 0;
		}
		else {
			printk("Incorrect vlaue pmsg->pcmh_flags \n");
			return -1;
		}
	}
	break;

	case PCM_MSG_SMAC_VLAN_CONFIG_ADD:
	{
		 fp_smac_vlan_entry_t smac_entry;
		ret = copy_from_user(	&smac_entry,
					(int8 *)nc_ops.io_data + sizeof(pcm_msg_header_t),
					sizeof(smac_entry));
		if (ret)
			return -1;
		ret = fp_smac_vlan_add_entry(&smac_entry);
		return ret;
	}
	break;

	case PCM_MSG_SMAC_VLAN_CONFIG_DEL:
	{
		 fp_smac_vlan_entry_t smac_entry;
		ret = copy_from_user(	&smac_entry,
					(int8 *)nc_ops.io_data + sizeof(pcm_msg_header_t),
					sizeof(smac_entry));
		if (ret)
			return -1;
		ret = fp_smac_vlan_del_entry(&smac_entry.mac[0]);
		return ret;
	}
	break;

	case PCM_MSG_SMAC_VLAN_CONFIG_SHOW:
	{
		 fp_smac_vlan_entry_t smac_entry;
		ret = copy_from_user(	&smac_entry,
					(int8 *)nc_ops.io_data + sizeof(pcm_msg_header_t),
					sizeof(smac_entry));
		if (ret)
			return -1;
		if (pmsg->pcmh_flags == 0)
		{
			ret = fp_smac_vlan_get_entry(&smac_entry.mac[0]);
			ret = copy_to_user(pnc_ops->io_data, &ret, sizeof(ret));
			return ret;
		}
		else if (pmsg->pcmh_flags == 1)
		{
			#if 0
			int32a i = 0;
			for (i = 0; i < ACL_TABLE_SIZE; i++)
			{
				ret = fp_acl_get_entry(i, &acl_entry);
				ret = copy_to_user(	pnc_ops->io_data,
							&acl_entry,
							sizeof(acl_entry));
				pnc_ops->io_data += sizeof(acl_entry);
			}
			return 0;
			#endif
		}
		else {
			printk("Incorrect vlaue pmsg->pcmh_flags \n");
			return -1;
		}
	}
	break;
	default:
#ifdef SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
				"%s:Unknown message type\n", __func__);
#endif
		return PCM_ERR_MSG_TMU_UNKNOWN_TYPE;
	break;
	} /*End of message type switch*/
	return 0;
} /*End of pcm_switchApi_config_ioctl() Function*/

