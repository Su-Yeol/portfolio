/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          fp_common_ctlm.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    common data structures for tmu
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#define MAX_IOCTL_MSG_LEN 4096

#define PFF_DEVICE_NAME "phy"

/*
 * Management application uses following request numbers to Control and Monitor
 * various PFE features through IOCTL interface.
 */
#if 0
typedef enum pfe_ctlm_request {
	PCM_REQ_SET_ROUTE,
	PCM_REQ_GET_ROUTE,

	PCM_REQ_SET_BRIDGE,
	PCM_REQ_GET_BRIDGE,

	PCM_REQ_SET_RTP_RELAY,
	PCM_REQ_GET_RTP_RELAY,

	PCM_REQ_SET_MULTICAST,
	PCM_REQ_GET_MULTICAST,

	PCM_REQ_SET_FILTER,
	PCM_REQ_GET_FILTER,

	PCM_REQ_SET_TMU,
	PCM_REQ_GET_TMU,

	PCM_REQ_SET_DEBUG,
	PCM_REQ_GET_DEBUG,

	PCM_REQ_GET_STATS
} pfe_ctlm_request_t;
#endif


/*
 * Message types being exchanged between management application and PFE
 * Control and Monitor (PCM) API provided by the PFE driver.
 */


typedef enum pcm_msg_type_t {
	/* PCM_REQ_SET_RTP_RELAY */
	PCM_MSG_RTP_RELAY_SOCK_CREATE,
	PCM_MSG_RTP_RELAY_SOCK_DELETE,
	PCM_MSG_RTP_RELAY_SOCK_UPDATE,
	PCM_MSG_RTP_RELAY_CONN_CREATE,
	PCM_MSG_RTP_RELAY_CONN_UPDATE,
	PCM_MSG_RTP_RELAY_CONN_DELETE,
	PCM_MSG_RTP_RELAY_SPL_RTP_REQ,
	PCM_MSG_RTP_RELAY_SOCK_TABLE_CREATE,
	PCM_MSG_RTP_RELAY_SOCK_TABLE_DISPLAY,
	PCM_MSG_RTP_RELAY_CONN_TABLE_CREATE,
	PCM_MSG_RTP_RELAY_CONN_TABLE_DISPLAY,
	/* PCM_REQ_GET_RTP_RELAY */
	PCM_MSG_RTP_RELAY_RTCP_QUERY,
	PCM_MSG_RTP_RELAY_RTCP_REPORT,
	PCM_MSG_RTP_RELAY_CONN_LIST,

	/* PCM_REQ_SET_TMU */
	PCM_MSG_TMU_SCHD_CONFIG,
	PCM_MSG_TMU_SHPR_CONFIG,
	PCM_MSG_TMU_CLASSQ_ADD,
	PCM_MSG_TMU_CLASSQ_DELETE,
	PCM_MSG_TMU_INIT_DONE,
	PCM_MSG_TMU_SET_IFG,
	PCM_MSG_TMU_LLM_CONFIG,
	PCM_MSG_TMU_INJECT_PKT,
	PCM_MSG_TMU_RESET,
	PCM_ERR_MSG_TMU_UNKNOWN_TYPE,
	PCM_MSG_TMU_CLASSQ_CHECK,
	/* PCM_REQ_GET_TMU */
	PCM_MSG_TMU_LLM_INFO,
	PCM_MSG_TMU_QUE_STATS,
	PCM_MSG_TMU_PE_STATS,
	PCM_MSG_TMU_INQ_STATS,
	PCM_MSG_TMU_SCH_LIST,
	PCM_MSG_TMU_SHP_LIST,
	PCM_MSG_TMU_CLASSQ_LIST,
	PCM_MSG_TMU_CLASSQ_PER_SCH_LIST,
	/* PCM_MSG_TLITE */
	PCM_MSG_TLITE_DYNAMIC_CONFIG_ENABLE,
	PCM_MSG_TLITE_SET_IFG,
	PCM_MSG_TLITE_SCHD_CONFIG,
	PCM_MSG_TLITE_SHPR_CONFIG,
	PCM_MSG_TLITE_CLASSQ_CHECK,
	PCM_MSG_TLITE_CLASSQ_ADD,
	PCM_MSG_TLITE_CLASSQ_DELETE,
	PCM_MSG_TLITE_QUE_STATS,
	PCM_MSG_TLITE_INQ_STATS,
	PCM_MSG_TLITE_METER_CONFIG,
	PCM_MSG_TLITE_METER_GLOBAL_ENABLE,
	PCM_MSG_TLITE_DYNAMIC_CONFIG_DONE,
	PCM_MSG_TLITE_SCH_LIST,
	PCM_MSG_TLITE_SHP_LIST,
	PCM_MSG_TLITE_CLASSQ_LIST,
	PCM_MSG_TLITE_CLASSQ_PER_SCH_LIST,
	PCM_MSG_TLITE_RESET,
	PCM_MSG_TLITE_CREDITMODE_SHP_CONFIG,
	PCM_MSG_TLITE_SET_REGENERATE_PCP,
	PCM_MSG_TLITE_GET_REGENERATE_PCP,
	PCM_MSG_TLITE_TAILDROP_ENABLE,
	PCM_MSG_TLITE_TAILDROP_DISABLE,
	PCM_MSG_TLITE_GET_TAILDROP_VALUE,
	PCM_MSG_TLITE_SHAPER_SET_MODE,
	PCM_MSG_TLITE_ING_SHAPER_SET,
	PCM_MSG_TLITE_ING_SHAPER_SET_MODE,
	PCM_MSG_TLITE_ING_SHAPER_STATE_GET,
	PCM_MSG_TLITE_DSCP2TC_SET,
	PCM_MSG_TLITE_DSCP2TC_GET,
	PCM_MSG_TLITE_PCP2TC_SET,
	PCM_MSG_TLITE_PCP2TC_GET,
	PCM_MSG_TLITE_PID2TC_SET,
	PCM_MSG_TLITE_PID2TC_GET,
	PCM_MSG_TLITE_PORTTC_SET,
	PCM_MSG_TLITE_PORTTC_GET,

	/* BYTE_COUNTER */
	PCM_MSG_CREATE_BYTE_COUNTER,
	PCM_MSG_DISPLAY_BYTE_COUNTER,
	PCM_MSG_REMOVE_BYTE_COUNTER,
	PCM_MSG_CLEAR_BYTE_COUNTER,

	/* SWITCH API */
	PCM_MSG_SWITCH_BR_ENTRY_ADD,
	PCM_MSG_SWITCH_BR_ENTRY_SEARCH,
	PCM_MSG_SWITCH_BR_ENTRY_ADD_PORTS,
	PCM_MSG_SWITCH_BR_ENTRY_PORTLIST_GET,
	PCM_MSG_SWITCH_BR_ENTRY_UNTAGLIST_GET,
	PCM_MSG_SWITCH_BR_ENTRY_PORT_TAG_CHG,
	PCM_MSG_SWITCH_BR_ENTRY_FWD_ACTION_GET,
	PCM_MSG_SWITCH_PORT_CONFIG_GET,
	PCM_MSG_SWITCH_GLOBAL_BR_ENTRY_CONFIG_GET,
	PCM_MSG_SWITCH_BR_ENTRY_FWD_ACTION_CHANGE,
	PCM_MSG_SWITCH_PORT_CONFIG,
	PCM_MSG_SWITCH_GLOBAL_BR_ENTRY_CONFIG,
	PCM_MSG_SWITCH_BR_ENTRY_DEL,
	PCM_MSG_SWITCH_BR_ENTRY_DEL_PORTS,

	PCM_MSG_SWITCH_MAC_ENTRY_ADD,
	PCM_MSG_SWITCH_MAC_ENTRY_DEL,
	PCM_MSG_SWITCH_MAC_ENTRY_SEARCH,
	PCM_MSG_SWITCH_MAC_ENTRY_UPDATE,
	PCM_MSG_SWITCH_LTC_GET_TIMEDIFF,
	PCM_MSG_SWITCH_LTC_HIF_SECONDS,
	PCM_MSG_SWITCH_LTC_HIF_NANOSECONDS,

	PCM_MSG_INTERRUPT_COALESCE,
	PCM_MSG_INGQOS_CONFIG,
	PCM_MSG_INGQOS_CONFIG_GET,

	PCM_MSG_ACL_CONFIG_ADD,
	PCM_MSG_ACL_CONFIG_DEL,
	PCM_MSG_ACL_CONFIG_SHOW,

	PCM_MSG_CB_CONFIG_ADD,
	PCM_MSG_CB_CONFIG_DEL,
	PCM_MSG_CB_CONFIG_SHOW,

	PCM_MSG_SMAC_VLAN_CONFIG_ADD,
	PCM_MSG_SMAC_VLAN_CONFIG_DEL,
	PCM_MSG_SMAC_VLAN_CONFIG_SHOW,
} pcm_msg_type_t;

/*
 * Common flags describe message structuring and is used to intepret messages
 * being exchanged between application and PCM API.
 */
typedef enum pcm_msg_header_flags {
	PMH_FLAGS_MORE_MSGS    = 0x1, /* One more msg attached after this msg */
	PMH_FLAGS_MORE_STRUCTS = 0x2  /* Multiple structs attached to one msg */
} pcm_msg_header_flags_t;

/*
 * Every message contains a common header and message specific structure(s).
 * It is possible to have more than one message in one exchange. Also one
 * message may contain one header and multiple message specific structures
 * of same type in one exchange.
 */


/*
typedef struct _pcm_msg_header_t_ {
	uint32a pcmh_type;
	uint32a pcmh_flags;
	uint32a pcmh_length;
	uint32a pcmh_value;

} pcm_msg_header_t;
*/
