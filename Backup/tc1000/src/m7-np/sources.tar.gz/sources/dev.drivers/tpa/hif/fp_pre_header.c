// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_pre_header.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    handles rx-tx prepended headers
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                      Include Files
 **********************************************************************/
#include <linux/etherdevice.h>
#if 0
#ifdef FP_IPSEC
#include <linux/skbuff.h>
#include <linux/ip.h>
#include <linux/ipv6.h>
#include <linux/udp.h>
#endif
#endif
#include "fp_library.h"
#include "fp_interface.h"
#include "fp_pre_header.h"
#include "fp_os_shim.h"
#include "fp_netd.h"
#include "fp_switch.h"
#include "hw_vlan_hash_table.h"


//#ifdef FP_IPSEC
//#include <fp_ipsec_test_config.h>
//#endif

#define FP_IPSEC_DEST_PORT_CHECK (0)

extern void *GetBaseAddr(void);

extern uint32a switch_port_list_mask;
int32a fp_fill_tx_ptp_header(struct tx_header *txhdr, struct sk_buff *skb)
{
	return 0;
}

int32a is_ipsec_flow(struct sk_buff *skb)
{
#ifdef FP_IPSEC
	uint16 dest_port = 0;
	uint16 dest_ip = 0;
	if (skb->protocol == ntohs(ETH_P_IP)) {
		struct iphdr *ih = ip_hdr(skb);
		if (FP_IPSEC_DEST_PORT_CHECK) {
			if (ih->protocol == IPPROTO_UDP) {
				struct udphdr *th = (struct udphdr *)(ih + 1);
				dest_port = ntohs(th->dest);
			} else if (ih->protocol == IPPROTO_TCP) {
				struct tcphdr *th = (struct tcphdr *)(ih + 1);
				dest_port = ntohs(th->dest);
			}
		}
		if ( (ntohl(ih->daddr) & FP_IPSEC_DEST_MASK) ==
				(FP_IPSEC_DEST_ADDR & FP_IPSEC_DEST_MASK) )
			dest_ip = 1;
	} else if (skb->protocol == ntohs(ETH_P_IPV6)) {
		struct ipv6hdr *ih = (struct ipv6hdr *)ipv6_hdr(skb);
		uint32a *addr = (uint32a *)&ih->daddr;
		if (FP_IPSEC_DEST_PORT_CHECK) {
			if (ih->nexthdr == IPPROTO_UDP) {
				struct udphdr *th = (struct udphdr *)(ih + 1);
				dest_port = ntohs(th->dest);
			} else if (ih->nexthdr == IPPROTO_TCP) {
				struct tcphdr *th = (struct tcphdr *)(ih + 1);
				dest_port = ntohs(th->dest);
			}
		}
		if ( (ntohl(addr[3]) & FP_IPSEC_DEST6_MASK) ==
			(FP_IPSEC_DEST6_ADDR & FP_IPSEC_DEST6_MASK) )
				dest_ip = 1;
	}

	if ((dest_port >= FP_MIN_IPSEC_PORT) && (dest_port <= FP_MAX_IPSEC_PORT))
		return 1;

	if (dest_ip)
		return 1;

	return 0;
#else
	return 0;
#endif
}

/**********************************************************************
 * Function Name  : fp_add_prepend_tx_header
 * Description    :
 * Inputs         :
 * Parameters     : struct sk_buff *
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_add_prepend_tx_header(struct sk_buff *skb)
{
	struct tx_header *txhdr;
#ifdef  FLOOD_TO_EMAC_PORTS
	int32a trigger_ipsec = is_ipsec_flow(skb);
#endif
	if (skb_headroom(skb) < FP_TX_HDR_LEN) {
		FP_DEBUG(DBGP_FEAT_ERR, FP_LOG_EMERG,
			"%s: Not enough headroom for TX HDR\n", __func__);
		return -1;
	}
	skb_push(skb, FP_TX_HDR_LEN);
	txhdr = (struct tx_header *)skb->data;
	memset(txhdr, 0, FP_TX_HDR_LEN);
#ifdef  FLOOD_TO_EMAC_PORTS
	if(switch_port_list_mask) {
		if (skb->cb[CB_INJ_TX_FLAG] == CB_TX_SA_MISS) {
			uint32a port_no = skb->cb[CB_INJ_TX_PORT];
			txhdr->ctrl = FP_TX_PKT_INJECT_EN;
			if(port_no < (FP_MAX_PORTS-1))
			{
				txhdr->txport_map = 1 << skb->cb[CB_INJ_TX_PORT];
			} else {
				pr_err("Tx Inject Port Error = %x\n", port_no);
				return -1;
			}
			txhdr->rsvd1 = 0;
			FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO,
				"TX INJECT PORT %u\n", txhdr->txport_map);
		}
	} else {
		if (EMAC_PORT_LIST_MASK & (1 << skb->fpNf2CacheFlow.phyno)) {
			txhdr->ctrl = FP_TX_PKT_INJECT_EN;
			txhdr->txport_map = 1 << skb->fpNf2CacheFlow.phyno;
			if (trigger_ipsec) {
				txhdr->pbc = 1;
				txhdr->out_phy = skb->fpNf2CacheFlow.phyno;
			}
			txhdr->rsvd1 = skb->fpNf2CacheFlow.l2Hash;
		}
	}
#endif
	txhdr->ref_num = 0;
	return 0;
}

int32a fp_add_tx_frame_header(uint8 *data, uint32a port)
{
	struct tx_header *txhdr;
	txhdr = (struct tx_header *)data;
	memset(txhdr, 0, FP_TX_HDR_LEN);
	txhdr->ctrl = FP_TX_PKT_INJECT_EN;
	txhdr->txport_map = 1 << port;
	txhdr->ref_num = 0;
	txhdr->rsvd1 = 0;
	return 0;
}

#ifdef FP_CFM
void fp_handle_ccm_packet(uint8 *data);

int32a check_ccm_packet(uint8 *data)
{
	// TODO : check for vlan also.
	if((data[12] == 0x89) && (data[13] == 0x02)) {
		printk("received ccm packet\n");
		fp_handle_ccm_packet(data);
		return 1;
	}
	return 0;
}
#endif
int32a nfp_skb_recv(	struct sk_buff *skb,
			struct net_device *dev,
			struct packet_type *ptype,
			struct net_device *orig_dev)
{
	rcu_read_lock();
	skb->dev = dev;
	if (!skb->dev) {
		rcu_read_unlock();
		return 0;
	}
	/* skb->dev->last_rx = jiffies; */
	/* slow path pkt count */
	/*Sending packet to host*/
	if (skb) {
		skb->fpNf2CacheFlow.rxDev = skb->dev;
		skb->fpNf2CacheFlow.phyRxPort =
			&gPhyPorts[NFP_DEV_INFO(skb->dev)->phyPortNo];
		skb->fpNf2CacheFlow.pIfRxPort =
			&gIfPorts[NFP_DEV_INFO(skb->dev)->phyPortNo]
					[skb->fpNf2CacheFlow.l2Hash];
		skb->protocol = eth_type_trans(skb, skb->dev);
		netif_rx(skb);
	}
	rcu_read_unlock();
	return 0;
}

/**********************************************************************
 * Function Name  : fp_process_rx_header
 * Description    : check whether incoming packet is rx packet or egress
			time stamp report
 * Inputs         :
 * Parameters     : struct sk_buff *
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_process_rx_header(struct sk_buff *skb)
{
	struct rx_header *rxhdr;
	struct egress_report *egrhdr;
	uint8 rx_packet_valid = 0;
	uint8 *ctrl = skb->data + 3;
	struct net_device *dev;
	int32a l2_special = 0;
	/* check whether incoming data is rxpacket or egress time stamp report */
	if (*ctrl & FP_EGR_TSR_VALID) {
		/* update rx packet is not valid */
		rx_packet_valid = 0;
		/* incoming packet is egress time stamp report */
		egrhdr = (struct egress_report *)skb->data;
		dev_kfree_skb(skb);
	} else {
		/* update rx packet is valid */
		rx_packet_valid = 1;
		/* incoming packet is rx packet */
		rxhdr = (struct rx_header *)skb->data;
		if (PUNT_L2_SPECIAL == rxhdr->punt_reason)
			l2_special = rxhdr->punt_reason;
		if (rxhdr->rxport_num < FP_MAX_PORTS)
		dev = fp_phy_addr[rxhdr->rxport_num];
		else {
			dev_kfree_skb(skb);
			return -1;
		}
		skb_pull(skb, sizeof(struct rx_header));
#ifdef FP_CFM
		if(check_ccm_packet(skb->data)) {
			// analyze the packet
			dev_kfree_skb(skb);
			return 0;
		}
#endif
	}
	if (rx_packet_valid) {
		if (l2_special == PUNT_L2_SPECIAL) {
			if (dev != NULL)
				skb->dev = dev;
		}
		//if(gIfPorts[rxhdr->rxport_num][0].opFlags & IF_SWITCH) {
		if(switch_port_list_mask) {
#ifdef FP_PRIMARY_DRIVER
			fp_host_shim_entry(skb->data, skb->len, rxhdr);
#endif
#ifdef FLOOD_TO_EMAC_PORTS
			if (rxhdr->punt_reason == PUNT_SA_MISS) {
				fp_tx_inject_packet(skb, rxhdr->rxport_num);
			}
#endif
			skb->protocol = eth_type_trans(skb, skb->dev);
			netif_rx(skb);
		} else {
			if(rxhdr->ctrl & HIF_ICV_CHECK_IGNORED_BIT)
				pr_info("Ignored icv check\n");
			skb->fpNf2CacheFlow.phyno = rxhdr->rxport_num;
		        skb->fpNf2CacheFlow.l2Hash = (rxhdr->rsvd >> 24) & 0xF;
			nfp_skb_recv(skb, fp_phy_addr[rxhdr->rxport_num],
				          NULL, skb->dev);
		}
	}
	return 0;
}

#ifdef FLOOD_TO_EMAC_PORTS
/**********************************************************************
 * Function Name  : fp_tx_inject_packet
 * Description    : inject pkt to except incoming and host ports
 * Inputs         :
 * Parameters     : struct sk_buff *, int rx_port
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
void fp_tx_inject_packet(struct sk_buff *skb, int32a rx_port)
{
	struct sk_buff *new_skb = NULL;
	int32a port_num = 0, port_list = 0, vlanid; /*Fallback bd id*/
	int64 action_entry;
	uint16 eth_type;
	vlanEthhdr_t *vlanEthHdr;
	if (GetBaseAddr() == NULL) {
		FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_EMERG,
			"%s: pci_mem base is NULL\n", __func__);
		return;
	}
	eth_type = ntohs(((struct ethhdr *)skb->data)->h_proto);
	if (eth_type == PROTOCOL_VLAN) {
		vlanEthHdr = (vlanEthhdr_t *)(skb->data);
		vlanid = ntohs(vlanEthHdr->h_vlan_TCI) & 0xFFF;
	} else {
		vlanid = fp_port[rx_port].fallback_bd_id;
	}
	/*Getting vlan table entry port list*/
	action_entry = wsp_vlan_entry_search(vlanid);
	if (action_entry == -1) {
		port_list = (fp_global.fallback_bd_entry.forward_list &
						BRENTRY_FWD_PORT_LIST_MASK);
	}
	else {
		port_list = action_entry & FWD_PORT_LIST_MASK;
	}
	FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO,
		"vlanid is %d, port_list is %x\n", vlanid, port_list);
	/* this condition should not occur, flood to all ports except iport */
	for (port_num = 0; port_num < FP_MAX_SWITCH_PORTS; port_num++) {
		/* check for port bit set */
		if ((port_list >> port_num) & 0x1) {
			/* fwd port shldn't be input port */
			if ((rx_port != port_num) && (port_num != HIF_PORT_NUM)) {
				/* allocate memory for sk_buff */
				new_skb = netdev_alloc_skb(skb->dev, MAX_FRAME_SIZE);
				/* new_skb = skb_clone(skb, GFP_ATOMIC); */
				if (new_skb == NULL) {
					FP_DEBUG(DBGP_FEAT_ERR, FP_LOG_EMERG,
						"%s: Out of memory allocating"
						"skb TX buffer\n", __func__);
					continue;
				}
				memcpy(new_skb->data, skb->data, skb->len);
				skb_put(new_skb, skb->len);
				new_skb->dev = skb->dev;
				new_skb->protocol = htons(eth_type);
				new_skb->cb[CB_INJ_TX_FLAG] = CB_TX_SA_MISS;
				new_skb->cb[CB_INJ_TX_PORT] = port_num;
				dev_queue_xmit(new_skb);
			}
		}
	}
}
#endif
