# ---------------------------------------------------------------------
# build.sh - build script.
#
# Copyright (c) 2007-2009, Naksha Technologies, Inc.
# Copyright (c) 2010-2012, Posedge Technologies, Inc.
# Copyright (c) 2013-2020, Imagination Technologies Ltd.
#
# All rights reserved
# ---------------------------------------------------------------------

make clean;make HASHARR=on MAPTIV=on all
#make clean;make HASHARR=on IPSEC=on MAPTIV=on all
