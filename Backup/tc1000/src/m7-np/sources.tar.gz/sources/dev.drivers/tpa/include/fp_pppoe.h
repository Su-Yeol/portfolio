/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
 * @File
 * @Title        fp_pppoe.h
 * @Copyright    Copyright (c) 2007-2009, Naksha Technologies, Inc.
 * @Copyright    Copyright (c) 2010-2012, Posedge Technologies, Inc.
 * @Copyright    Copyright (c) 2013-2020, Imagination Technologies Ltd.
 * @Copyright    Copyright (c) Imagination Technologies Ltd. All Rights Reserved
 * @Description  This file contains the structures declaration for pppoe header
 * @License      Dual MIT/GPLv2
 *
 * The contents of this file are subject to the MIT license as set out below.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * the GNU General Public License Version 2 ("GPL") in which case the provisions
 * of GPL are applicable instead of those above.
 *
 * If you wish to allow use of your version of this file only under the terms of
 * GPL, and not to allow others to use your version of this file under the terms
 * of the MIT license, indicate your decision by deleting the provisions above
 * and replace them with the notice and other provisions required by GPL as set
 * out in the file called "GPL-COPYING" included in this distribution. If you do
 * not delete the provisions above,a recipient may use your version of this file
 * under the terms of either the MIT license or GPL.
 *
 * This License is also included in this distribution in the file called
 * "MIT-COPYING".
 *
 * EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 * PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */ /**************************************************************************/
#ifndef _FP_PPPOE_H_
#define _FP_PPPOE_H_


struct fp_pppoe_hdr {

	uint8     h_dest[ETH_ALEN];   /* destination eth addr */
	uint8     h_source[ETH_ALEN]; /* source ether addr */
	uint16    h_ppp_proto;        /* Should always be 0x8864 */
#ifdef __FP_OS__
	uint8     ver  : 4;
	uint8     type : 4;
#else
	uint8     type : 4;
	uint8     ver  : 4;
#endif
	uint8     code;
	uint16    sid;
	uint16    length;
	uint16    protocol;

};

struct fp_pppoe_vlan_hdr {

	uint8     h_dest[ETH_ALEN];    /* destination eth addr */
	uint8     h_source[ETH_ALEN];  /* source ether addr */
	uint16    h_vlan_proto;        /* Should always be 0x8100 */
	uint16    h_vlan_TCI;          /* Encapsulates priority and VLAN ID */
	uint16    h_vlan_encap_proto;  /* pkt type ID field (or len) */
#ifdef __FP_OS__
	uint8     ver :4;
	uint8     type:4;
#else
	uint8     type:4;
	uint8     ver :4;
#endif
	uint8     code;
	uint16    sid;
	uint16    length;
	uint16    protocol;

};
#endif /*End of _FP_PPPOE_H_ File*/

