/**
 * @file MRVL_Q222X_TC10.c
 * @brief Q222X TC10 API Source File
 * DUT TC10 configuration and status checking
 *
 * @par Copyright and Version
 * See MRVL_Q222X_Copyright_and_Version.h
 */

#include "MRVL_Q222X_TC10.h"

/******************************************************************************
 *     TC10 Configuration
 ******************************************************************************/

/**
 * @brief enable/disdable TC10 feature
 * @param [in]	device     PHY pointer
 * @param [in]	isEnable   MRVL_APHY_TRUE, enable TC10 block/operation;
 *                         MRVL_APHY_FALSE, disable TC10 block/operation
 * @return MRVL_APHY_STATUS
 *
 * @ingroup TC10_CNFG
 */
MRVL_APHY_STATUS q222x_configTC10(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEnable)
{
	MRVL_APHY_U16 regVal1, regVal2;
    MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
    if (device->revNum != MRVL_Q222X_B1)
    {
        status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
    }
    else
    {
        /* rev B1 supports TC10 feature */
        mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_TC10_CONTROL_DEVICE, MRVL_Q222X_TC10_ENABLE_REG_1000, &regVal1);
        mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_TC10_CONTROL_DEVICE, MRVL_Q222X_TC10_ENABLE_REG_100, &regVal2);
        if (isEnable == MRVL_APHY_TRUE)
        {
            /* enable TC10 for both speeds options */
            regVal1 |= 1U;
            regVal2 |= 1U;
        }
        else
        {
             /* disable TC10 for both speeds options */
            regVal1 &= 0xFFFEU;
            regVal2 &= 0xFFFEU;
        }
        mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_TC10_CONTROL_DEVICE, MRVL_Q222X_TC10_ENABLE_REG_1000, regVal1);
        mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_TC10_CONTROL_DEVICE, MRVL_Q222X_TC10_ENABLE_REG_100, regVal2);
    }
	return status;
}

/**
 * @brief configurate TC10 power removal (deep sleep)
 * @param [in]	device     PHY pointer
 * @param [in]	isEnable   MRVL_APHY_TRUE, enable TC10 power removal (deep sleep);
 *                         MRVL_APHY_FALSE, disable TC10 power removal (power-on sleep)
 * @return MRVL_APHY_STATUS
 *
 * @ingroup TC10_CNFG
 */
MRVL_APHY_STATUS q222x_configTC10PowerRemoval(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEnable)
{
	if (isEnable == MRVL_APHY_TRUE)
    {
        /* enable power-remove sleep */
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_TC10_POWER_DEVICE, MRVL_Q222X_TC10_POWER_REG, MRVL_Q222X_TC10_POWER_REMOVE_ENABLE);
	}
	else
    {
        /* disable power-remove sleep */
		mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_TC10_POWER_DEVICE, MRVL_Q222X_TC10_POWER_REG, MRVL_Q222X_TC10_POWER_REMOVE_DISABLE);
	}
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief configurate sleep request abort settings
 * @param [in]	device     PHY pointer
 * @param [in]	isAbort    MRVL_APHY_TRUE, abort the sleep request received from LP;
 *                         MRVL_APHY_FALSE, clear abortion
 * @return MRVL_APHY_STATUS
 *
 * @ingroup TC10_CNFG
 */
MRVL_APHY_STATUS q222x_configTC10SleepRequestAbort(MRVL_DEV_PTR device, MRVL_APHY_BOOL isAbort)
{
	MRVL_APHY_U16 regVal;
	if (isAbort == MRVL_APHY_TRUE)
    {
		regVal = MRVL_Q222X_TC10_CONTROL_ABORT;
	}
	else
    {
		regVal = MRVL_Q222X_TC10_CONTROL_CLEAR;
	}
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_TC10_CONTROL_DEVICE, MRVL_Q222X_TC10_CONTROL_REG_1000, regVal);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_TC10_CONTROL_DEVICE, MRVL_Q222X_TC10_CONTROL_REG_100, regVal);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief start TC10 sleep flow: initiate sleep handshake with LP
 * @param [in]	device     PHY pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup TC10_CNFG
 */
MRVL_APHY_STATUS q222x_startTC10SleepFlow(MRVL_DEV_PTR device)
{
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_TC10_CONTROL_DEVICE, MRVL_Q222X_TC10_CONTROL_REG_1000, MRVL_Q222X_TC10_CONTROL_SLEEP);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_TC10_CONTROL_DEVICE, MRVL_Q222X_TC10_CONTROL_REG_100, MRVL_Q222X_TC10_CONTROL_SLEEP);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief assert wake-up request: trigger WUR/WUP to LP
 * @param [in]	device     PHY pointer
 * @return MRVL_APHY_STATUS
 *
 * @ingroup TC10_CNFG
 */
MRVL_APHY_STATUS q222x_assertTC10WakeRequest(MRVL_DEV_PTR device)
{
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_TC10_CONTROL_DEVICE, MRVL_Q222X_TC10_CONTROL_REG_1000, MRVL_Q222X_TC10_CONTROL_WAKE);
	mrvl_aphy_hwXmdioWrite(device, device->phyAddr, MRVL_Q222X_TC10_CONTROL_DEVICE, MRVL_Q222X_TC10_CONTROL_REG_100, MRVL_Q222X_TC10_CONTROL_WAKE);
	return MRVL_APHY_STATUS_OK;
}

/**
 * @brief get TC10 sleep status
 * @param [in]	device     PHY pointer
 * @param [out]	status     see MRVL_Q222X_TC10_STATUS
 * @return MRVL_APHY_STATUS
 *
 * @ingroup TC10_CNFG
 */
MRVL_APHY_STATUS q222x_getTC10Status(MRVL_DEV_PTR device, MRVL_Q222X_TC10_STATUS* status)
{
	MRVL_APHY_U16 regVal1, regVal2;
	mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_ID_DEVICE, MRVL_ORGANIZATION_ID_REG, &regVal1);
	if (regVal1 != MRVL_ORGANIZATION_ID)
    {
        /* no reg access, therefore this is in power-remove sleep */
		*status = MRVL_Q222X_TC10_SLEEP;
	}
	else
    {
        /* have reg access, read the status from register */
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_TC10_CONTROL_DEVICE, MRVL_Q222X_TC10_STATUS_REG_1000, &regVal1);
		mrvl_aphy_hwXmdioRead(device, device->phyAddr, MRVL_Q222X_TC10_CONTROL_DEVICE, MRVL_Q222X_TC10_STATUS_REG_100, &regVal2);
		switch ((regVal1 | regVal2) & 0xFU)
		{
		case 0:
			*status = MRVL_Q222X_TC10_OPNORMAL;
			break;
		case 1:
			*status = MRVL_Q222X_TC10_SLEEP;
			break;
		case 2:
			*status = MRVL_Q222X_TC10_SLEEP_FAILED;
			break;
		case 4:
			*status = MRVL_Q222X_TC10_REQUEST_ABORTED;
			break;
		default:
			*status = MRVL_Q222X_TC10_UNKNOWN;
			break;
		}
	}
	return MRVL_APHY_STATUS_OK;
}
