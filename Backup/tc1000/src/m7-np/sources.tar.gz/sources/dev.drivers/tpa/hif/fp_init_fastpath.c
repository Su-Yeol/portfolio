// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_init_fastpath.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    fastpath initilization based on configuration
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

/**********************************************************************
 *                                      Include Files
 **********************************************************************/
#include "reg_hal.h"
#include "fp_library.h"
#include "hw_2field_hash_table.h"
#include "hw_vlan_hash_table.h"
#include "global_address_map_fpga.h"
#include "fp_net_driver.h"
#include "hwinits.h"
#include "fp_router.h"
#include "fp_app_init.h"

void fp_pci_ddr_tbl_init(uint8 *ptr);
void load_hwreg_table(hwinit_data_t *initdata);
void check_soc_version(void);

extern uint32a switch_port_list_mask;

//void init_macsec_driver(void);
/**********************************************************************
 * Function Name  : load_hwreg_table
 * Description    : loading hardware init data
 * Inputs
 * Parameters     : int8 *, wsp_hwreg_data_t *
 * Outputs        :
 * Parameters     : -
 * Returns        : -
 * Changes        :
 **********************************************************************/
void load_hwreg_table(hwinit_data_t *initdata)
{
	hwinit_data_t *hwdata;
	uint32a addr;

	hwdata = initdata;
	while (hwdata->addr != 0)
	{
		addr = (hwdata->addr + EPP_PLATFORM_BASE_ADDR);
		RegWrite(addr, hwdata->data);
		hwdata++;
	}
}

uint32 gpcimem_base;

#if 0
uint8 *getPciBaseAddr(struct net_device *dev);
/**********************************************************************
 * Function Name  : getPciBaseAddr
 * Description    : get the pci base address of pci device
 * Inputs
 *   Parameters   : struct net_device *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 ***********************************************************************
 */
uint8 *getPciBaseAddr(struct net_device *dev)
{
	struct fp_private *fp = netdev_priv((struct net_device *)dev);
	return (uint8 *)fp->pcimem_base;
}
#endif

#if 1
void check_soc_version(void)
{
	int32a start_addr;
	uint32a reg;
	int32a i=0;

	(void)reg;
	TPA_D("[WSP_VERSION]\n");
	start_addr = 0xA0D000;
	//printk("\nstart addr=0x%06X", start_addr);
	i=0;//for(i=0; i<0x10; i+=0x4)
	{
		reg = RegRead(start_addr+i);
		TPA_D("read offset[0x%6X] data[0x%08X]\n", start_addr+i, reg);
	}

	TPA_D("[gmac1 MAC_Version]\n");
	start_addr = 0x2D0000;
	//printk("\nstart addr=0x%06X", start_addr);
	i=0x110;//for(i=0; i<0x200; i+=0x4)
	{
		reg = RegRead(start_addr+i);
		TPA_D("read offset[0x%6X] data[0x%08X]\n", start_addr+i, reg);
	}

	TPA_D("[gmac0 MAC_Version]\n");
	start_addr = 0x2D4000;
	//printk("\nstart addr=0x%06X", start_addr);
	i=0x110;//for(i=0; i<0x200; i+=0x4)
	{
		reg = RegRead(start_addr+i);
		TPA_D("read offset[0x%6X] data[0x%08X]\n", start_addr+i, reg);
	}

	TPA_D("[xgmac_2.5G MAC_Version]\n");
	start_addr = 0x2D8000;
	//printk("\nstart addr=0x%06X", start_addr);
	i=0x110;//for(i=0; i<0x200; i+=0x4)
	{
		reg = RegRead(start_addr+i);
		TPA_D("read offset[0x%6X] data[0x%08X]\n", start_addr+i, reg);
	}

	return;
}
#endif

/**********************************************************************
 * Function Name  : fp_init_fastpath
 * Description    : initialize PE & non PE based routines based on config
 *                  This routine will called upon net driver init time
 * Inputs
 *   Parameters   : struct net_device *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : int
 * Changes        :
 *********************************************************************/
int32a fp_init_fastpath(void)
{
	//check_soc_version();
	TPA_D("\ninvoke load_hwreg_table()\n");
	load_hwreg_table(&sw_hwreg_data[0]);

	hw_hash_table_init(1);
	hw_hash_table_init(3);

	wsp_vlan_hash_table_init(1);
	wsp_vlan_hash_table_init(3);

	fp_hw_sw_init();
	fp_hw_vlantable_add();

//	fp_upd_pci_baseaddr(dev);

	fp_add_static_route_tables();
#ifdef ROUTE_PORT_CONFIG
#define ROUTE_MULTI_REG_VAL 0x368808
//#define ROUTE_MULTI_REG_VAL 0x68008
//#define ROUTE_MULTI_REG_VAL 0x28008
	RegWrite(EGPI5_CLASS_HW_ROUTE_HASH_ENTRY_SIZE_ADDR, 0x090A0080);
	RegWrite(EGPI5_CLASS_HW_ROUTE_MULTI_REG_ADDR, ROUTE_MULTI_REG_VAL);

	RegWrite(EGPI6_CLASS_HW_ROUTE_HASH_ENTRY_SIZE_ADDR, 0x090A0080);
	RegWrite(EGPI6_CLASS_HW_ROUTE_MULTI_REG_ADDR, ROUTE_MULTI_REG_VAL);

	RegWrite(EGPI7_CLASS_HW_ROUTE_HASH_ENTRY_SIZE_ADDR, 0x090A0080);
	RegWrite(EGPI7_CLASS_HW_ROUTE_MULTI_REG_ADDR, ROUTE_MULTI_REG_VAL);

	RegWrite(HGPI_CLASS_HW_ROUTE_HASH_ENTRY_SIZE_ADDR, 0x090A0080);
	RegWrite(HGPI_CLASS_HW_ROUTE_MULTI_REG_ADDR, ROUTE_MULTI_REG_VAL);


	RegWrite(0x800834, 0x090A0080);
	RegWrite(0x800838, 0xc0780000);
	RegWrite(0x80083c, 0x8008);


	RegWrite(WSP_EMAC_CLASS_CONFIG, 0x0);

	RegWrite(HGPI_HIF_BMU1_BUFCNT_THRESHOLD, 0x00010200);
	//RegWrite(0x8800ec, 0x6);
	RegWrite(0x8800ec, 0x7);
	RegWrite(0x80083c, 0x8008);
	RegWrite(0x800128, 0x2080);

	switch_port_list_mask = 0;
#else
	RegWrite(WSP_EMAC_CLASS_CONFIG, 0x3ff);
	switch_port_list_mask = 0x3ff;
#endif
	fp_route_init();

	return 0;
}

