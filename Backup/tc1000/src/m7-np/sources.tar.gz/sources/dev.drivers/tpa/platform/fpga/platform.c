// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          platform.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    Functions to handle different hardware platforms
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                      Include Files
 **********************************************************************/
#include <linux/pci.h>
#include <linux/netdevice.h>

#include "fp_net_driver.h"	/* brings in "struct fp_private" */
#include "fp_pci_driver.h"	/* brings in "DRV_NAME" */
#include "reg_hal.h"		/* brings in "InitBaseAddr()" */
#include "platform.h"
#include "global_base_address.h"
#include "global_address_map_fpga.h"

#include "gpi_csr.h"
#include "class_hw_csr.h"
#include "tlite_csr.h"
#include "fp_hif_reg.h"
#include "fp_bd_api.h"
#include "fp_pre_header.h"

#if (INT_MODE==1)
#define ENABLE_PCI_INTERRUPT
#endif

#define GMAC_SPD_100M
//#define GMAC_SPD_10M
//#define GMAC_LOOPBACK_MODE

struct net_device  *fp_netdev_init(uint8 *membase, uint32a irq);

static struct memconfig config[5];

#define USE_DB_BUFFER_FPGA_DRAM
#define FPGA_DRAM_START_ADDR (0x80000000)
#define BYTE_ALIGN_BIT_MASK (8) /*8 byte align */
static uint8 *fpga_dram_base = NULL;
#ifdef USE_DB_BUFFER_FPGA_DRAM
static int32a used_offset=0;
#endif

#define ZERO_BUFFER_SIZE (1024*1024)
static uint8 *zero_buffer = NULL;

#define COPY_SIZE_ALIGN (2)
#define COPY_BUFFER_SIZE (1024*4)
static uint8 *copy_buffer = NULL;

#ifdef ENABLE_PCI_INTERRUPT
/* Target internal components on XDMA control BAR */
#define XDMA_OFS_INT_CTRL	(0x2000UL)
#define PCI_INTERRUPT_MASK (0xFFFFFFFF)

void platform_pci_interrupt_enable(void);
void platform_pci_interrupt_disable(void);
#endif

#if 0
void test_read_versions(void)
{
	int32a i=0;
	int32a start_addr;
	uint32a reg;

	start_addr = 0xA0D000;
	printk("\nstart addr=0x%06X", start_addr);
	for(i=0; i<0x10; i+=0x4)
	{
		reg = RegRead(start_addr+i);
		printk("read offset[0x%6X] data[0x%08X]\n", start_addr+i, reg);
	}

#if 0
	start_addr = 0x2D0110;
	reg = RegRead(start_addr+i);
	printk("read offset[0x%6X] data[0x%08X]\n", start_addr, reg);

	start_addr = 0x2D4110;
	reg = RegRead(start_addr+i);
	printk("read offset[0x%6X] data[0x%08X]\n", start_addr, reg);
#endif
	printk("[gmac1]\n");
	start_addr = 0x2D0000;
	printk("\nstart addr=0x%06X", start_addr);
	i=0x110;//for(i=0; i<0x200; i+=0x4)
	{
		reg = RegRead(start_addr+i);
		printk("read offset[0x%6X] data[0x%08X]\n", start_addr+i, reg);
	}

	printk("[gmac0]\n");
	start_addr = 0x2D4000;
	printk("\nstart addr=0x%06X", start_addr);
	i=0x110;//for(i=0; i<0x200; i+=0x4)
	{
		reg = RegRead(start_addr+i);
		printk("read offset[0x%6X] data[0x%08X]\n", start_addr+i, reg);
	}

	printk("[xgmac_2.5G]\n");
	start_addr = 0x2D8000;
	printk("\nstart addr=0x%06X", start_addr);
	i=0x110;//for(i=0; i<0x200; i+=0x4)
	{
		reg = RegRead(start_addr+i);
		printk("read offset[0x%6X] data[0x%08X]\n", start_addr+i, reg);
	}
}
#endif

void test_reg_map(void)
{
	int32a i=0;
	int32a start_addr;
	uint32a reg;

#if 0
	start_addr = 0x002D2000;
	printk("\nEMAC1=0x%06X", start_addr);
	for(i=0; i<0x100; i+=0x4)
	{
		reg = RegRead(start_addr+i);
		printk("read offset[0x%6X] data[0x%08X]\n", start_addr+i, reg);
		udelay(10000);
	}
#endif
#if 0
	start_addr = 0x002D6000;
	printk("\nEMAC2=0x%06X", start_addr);
	for(i=0; i<0x100; i+=0x4)
	{
		reg = RegRead(start_addr+i);
		printk("read offset[0x%6X] data[0x%08X]\n", start_addr+i, reg);
		udelay(10000);
	}
#endif

#if 0
	start_addr = 0x00880300;
	printk("\nstart_addr=0x%06X", start_addr);
	for(i=0; i<0x200; i+=0x4)
	{
		reg = RegRead(start_addr+i);
		printk("read offset[0x%6X] data[0x%08X]\n", start_addr+i, reg);
		udelay(10000);
	}
#endif
#if 0
	start_addr = 0x002D2100;
	printk("\nstart_addr=0x%06X", start_addr);
	for(i=0; i<0x200; i+=0x4)
	{
		reg = RegRead(start_addr+i);
		printk("read offset[0x%6X] data[0x%08X]\n", start_addr+i, reg);
		udelay(10000);
	}
#endif

	start_addr = 0x002D7100;
	printk("\nstart_addr=0x%06X", start_addr);
	for(i=0; i<0x200; i+=0x4)
	{
		reg = RegRead(start_addr+i);
		printk("read offset[0x%6X] data[0x%08X]\n", start_addr+i, reg);
		udelay(10000);
	}


}

#if 0
void test_dma_alloc(struct device *pdev,int32a size)
{
	/* dma alloc test */
	dma_addr_t phys_addr;
	void *virt_addr;

	virt_addr = dma_alloc_coherent(pdev, size, &phys_addr, GFP_KERNEL);
	printk("[%s] dma alloc size=%d, addr=0x%p, 0x%lx\n", __func__, size, virt_addr, (uint32)phys_addr);
	if(virt_addr!=NULL)
	{
		printk("[%s] dma success.\n", __func__);
		dma_free_coherent(pdev, size, virt_addr, phys_addr);
	}
	else
	{
		printk("[%s] dma alloc failed.\n", __func__);
	}

	return;
}
#endif

#if 0
#define LOCAL_BUFFER_SIZE (0x100000) // 1Mbyte
void mem_test(void)
{
	int32a ret=0;
	int32a i;
	int32a j;
	int32a bar_mem_index = 4;
	uint8 *local_buffer;
	uint8 *dram_buffer;
	int32a base_offset;
//	int32a offset;

	config[bar_mem_index].membase = ioremap_nocache(config[bar_mem_index].start, config[bar_mem_index].len);
	printk("BAR%d at 0x%llx mapped at 0x%p, length=0x%llx\n", bar_mem_index,
		(u64)config[bar_mem_index].start, config[bar_mem_index].membase, (u64)config[bar_mem_index].len );

	dram_buffer = config[bar_mem_index].membase;
	local_buffer = kzalloc(LOCAL_BUFFER_SIZE, GFP_KERNEL);  // 1Mbyte

	#if 0
	base_offset = 0x0;
	printk("test memset 0x0 then cpmpare\n");
	memset(dram_buffer, 0x00, 0x100); // Unable to handle kernel paging request at virtual address ffffffc019000000
	#endif

	for(j=0x10;j<0x200;j++)
	{
		base_offset = j<<20;
		printk("\nbase addr 0x%08X\n", base_offset);

#if 1
		printk("copy 0x00 then compare\n");
		memset(local_buffer, 0x00, LOCAL_BUFFER_SIZE);
		memcpy(dram_buffer+base_offset, local_buffer, LOCAL_BUFFER_SIZE);
		#if 0
		ret = memcmp(dram_buffer+base_offset, local_buffer, LOCAL_BUFFER_SIZE);
		if(ret != 0)
		{
			printk("fail to memcmp = %d.\n", ret);
			return;
		}
		#else
		for(i=0; i<LOCAL_BUFFER_SIZE; i++)
		{
			if( dram_buffer[base_offset+i] != local_buffer[i])
			{
				printk("offset 0x%08X, expected 0x%02X, but read 0x%02X\n", base_offset+i, local_buffer[i], dram_buffer[base_offset+i]);
				return;
			}
		}
		#endif

		printk("copy 0xAA then compare\n");
		memset(local_buffer, 0xAA, LOCAL_BUFFER_SIZE);
		memcpy(dram_buffer+base_offset, local_buffer, LOCAL_BUFFER_SIZE);
		#if 1
		ret = memcmp(dram_buffer+base_offset, local_buffer, LOCAL_BUFFER_SIZE);
		if(ret != 0)
		{
			printk("fail to memcmp = %d.\n", ret);
			return;
		}
		#else
		for(i=0; i<LOCAL_BUFFER_SIZE; i++)
		{
			if( dram_buffer[base_offset+i] != local_buffer[i])
			{
				printk("offset 0x%08X, expected 0x%02X, but read 0x%02X\n", base_offset+i, local_buffer[i], dram_buffer[base_offset+i]);
				return;
			}
		}
		#endif
		printk("complete\n");

#endif
	}
}
#endif

#if 0
void test_memset(void)
{
	uint8 *dest = config[4].membase; /* FPGA DRAM base addr */
	size_t size = 0x1;
	int32a i;

	printk("[%s] start base va=%px, pa=%llx\n", __func__, config[4].membase, config[4].start);
#if 0
	for (i = 0; i < 20; ++i)
	{
		printk("[%s] memset size= 0x%lx\n", __func__, size);
		memset(dest, 0, size);
		size <<= 1;
	}
#else
	for (i = 0x8; i < 0x100; i+=8)
	{
		size=i;
		printk("[%s] memset size= 0x%lx\n", __func__, size);
		memset(dest, 0, size);
	}
#endif
}
#endif

#if 1
void test_memcpy(void)
{
	uint8 *src = zero_buffer;
	uint8 *dest = config[4].membase; /* FPGA DRAM base addr */
	size_t size;
	int32a i;
	printk("[%s] start base va=%px, pa=%llx\n", __func__, config[4].membase, config[4].start);
	printk("[%s] memcpy from local buffer %px to base va=%px\n", __func__, zero_buffer, config[4].membase);

#if 0
	size = 0x01;
	for(i=0;i<17;i++)
	{
		printk("[%s] size=0x%lx\n", __func__, size);
		memcpy(dest, src, size);

		size <<= 1;
	}
#elif 0
	for(i=0x2000;i>0;i--)
	//for(i=0x2000;i>0;i-=0x2)
	//for(i=0x2000;i>0;i-=0x4)
	//for(i=0x2000;i>0;i-=0x8)
	{
		size = i;
		printk("[%s] size=0x%lx\n", __func__, size);
		memcpy(dest, src, size);
	}
#elif 0
	{
		int32a j;
		int32a offset;
		//for(j=3;j>0;j--)
		for(j=8;j>0;j-=8)
		{
			offset = j;//(1<<j);
			for(i=0x2000;i>0x1E00;i-=0x2)
			{
				size = i;
				printk("[%s] src=%px, size=0x%lx\n", __func__, src+offset, size);
				memcpy(dest, src+offset, size);
			}
		}
	}
#elif 1
	{
		int32a offset;
		offset = 8;
		for(i=0x100;i<0x110;i+=2)
		{
			size = i;
			printk("[%s] src=%px, size=0x%lx\n", __func__, src+offset, size);
			memcpy(dest, src+offset, size);
		}
		offset = 4;
		for(i=0x100;i<0x110;i+=2)
		{
			size = i;
			printk("[%s] src=%px, size=0x%lx\n", __func__, src+offset, size);
			memcpy(dest, src+offset, size);
		}
	}
#endif
}
#endif

void plt_alloc_buffer(void)
{
	zero_buffer = (uint8 *)kzalloc(ZERO_BUFFER_SIZE, GFP_KERNEL);
	printk("[%s]zero_buffer %p, %px\n", __func__, zero_buffer, zero_buffer);
	copy_buffer = (uint8 *)kzalloc(COPY_BUFFER_SIZE, GFP_KERNEL);
	printk("[%s]copy_buffer %p, %px\n", __func__, copy_buffer, copy_buffer);
}

#define TPA_CFG_SWRESETN 0xD30004
#define GMAC0_CFG0       0xD31000
#define GMAC0_CFG1       0xD31004
#define GMAC0_DLY_CFG_0  0xD32000
#define GMAC0_DLY_CFG_1  0xD32004
#define GMAC0_DLY_CFG_2  0xD32008
#define GMAC0_DLY_CFG_3  0xD3200C
#define GMAC0_DLY_CFG_4  0xD32010
#define GMAC1_CFG0       0xD33000
#define GMAC1_CFG1       0xD33004
#define GMAC1_DLY_CFG_0  0xD34000
#define GMAC1_DLY_CFG_1  0xD34004
#define GMAC1_DLY_CFG_2  0xD34008
#define GMAC1_DLY_CFG_3  0xD3400C
#define GMAC1_DLY_CFG_4  0xD34010

void tpa_config(void)
{
	uint32 addr;
	uint32a val;


	printk("[%s]\n", __func__);

	/* set GMAC0 Configuration */
	printk("[%s] set GMAC0 Configuration\n", __func__);
	addr = GMAC0_CFG1; // GMAC0_CFG1 CLKEN to 1
	val = RegRead(addr);
	printk(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(1<<28); //28bit 1 mask
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	printk("\n");

	addr = GMAC0_CFG1; // GMAC0_CFG1 RGMII INFSEL
	val = RegRead(addr);
	printk(" read addr[%08lx] val[%08x]\n", addr, val);
	val = (val&(~(0x7<<24)))|(0x1<<24); //[26:24] 001b
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	printk("\n");

	addr = GMAC0_CFG0; // GMAC0_CFG1 TR,RR enable
	val = RegRead(addr);
	printk(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(1<<28)|(1<<12);
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	printk("\n");

	addr = GMAC0_CFG1; // GMAC0_CFG1 CLKEN to 0
	val = RegRead(addr);
	printk(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val&(~(1<<28)); //28bit 0 mask
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	printk("\n");

	addr = GMAC0_CFG0; // GMAC0_CFG0 TxDIV, RxDIV set
	val = RegRead(addr);
	printk(" read addr[%08lx] val[%08x]\n", addr, val);

	#ifdef GMAC_SPD_100M
	val = val&~((0x3F<<20)|(0x3F<<4));
	val = val|(1<<22); //22bit 1 mask (25:20) 0->4 //25MHz
	//val = val|(1<<6);  // (9:4) 0->4 //25MHz
	#elif defined(GMAC_SPD_10M)
	val = val&~((0x3F<<20)|(0x3F<<4));
	val = val|(0x31<<20); //22bit 1 mask (25:20) 49 = 0x31 //2.5MHz = 125/(49+1)
	val = val|(0x31<<4);  //               (9:4) 49 = 0x31 //2.5MHz = 125/(49+1)
	#else
	val = val&~((0x3F<<20)|(0x3F<<4)); //[25:20] 0, [9:4] 0 //125MHz
	#endif
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	printk("\n");

	addr = GMAC0_CFG1; // GMAC0_CFG1 CLKEN to 1
	val = RegRead(addr);
	printk(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(1<<28); //28bit 1 mask
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	printk("\n");

	addr = GMAC0_CFG1; // GMAC0_CFG1 TXCLKOEN to 1
	val = RegRead(addr);
	printk(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(1<<16); //16bit 1 mask
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	printk("\n");

	addr = TPA_CFG_SWRESETN; // TPA CFG GMAC0 swreset
	val = RegRead(addr);
	printk(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val&(~(1<<1)); //1bit 0 mask
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	udelay(100);
	val = val|(1<<1); //1bit 1 mask
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	/* set Delay control registers */
	addr = GMAC0_DLY_CFG_0; // Delay control register 0
	val = 0x10109010;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

#if 0
	addr = GMAC0_DLY_CFG_1; // Delay control register 1
	val = 0x00000000;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
#endif
	addr = GMAC0_DLY_CFG_2; // Delay control register 2
	val = 0x10100010; // cfg_rxclki_inv1 0
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
#if 0
	addr = GMAC0_DLY_CFG_3; // Delay control register 3
	val = 0x00000000;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = GMAC0_DLY_CFG_4; // Delay control register 4
	val = 0x00000000;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
#endif

	/* set GMAC1 Configuration */
	printk("[%s] set GMAC1 Configuration\n", __func__);
	addr = GMAC1_CFG1; // GMAC1_CFG1 CLKEN to 1
	val = RegRead(addr);
	printk(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(1<<28); //28bit 1 mask
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	printk("\n");

	addr = GMAC1_CFG1; // GMAC1_CFG1 RGMII INFSEL
	val = RegRead(addr);
	printk(" read addr[%08lx] val[%08x]\n", addr, val);
	val = (val&(~(0x7<<24)))|(0x1<<24); //[26:24] 001b
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	printk("\n");

	addr = GMAC1_CFG0; // GMAC1_CFG1 TR,RR enable
	val = RegRead(addr);
	printk(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(1<<28)|(1<<12);
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	printk("\n");

	addr = GMAC1_CFG1; // GMAC1_CFG1 CLKEN to 0
	val = RegRead(addr);
	printk(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val&(~(1<<28)); //28bit 0 mask
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	printk("\n");

	addr = GMAC1_CFG0; // GMAC1_CFG0 TxDIV, RxDIV set
	val = RegRead(addr);
	printk(" read addr[%08lx] val[%08x]\n", addr, val);
	#ifdef GMAC_SPD_100M
	val = val&~((0x3F<<20)|(0x3F<<4));
	val = val|(1<<22); //22bit 1 mask (25:20) 0->4 //25MHz
	//val = val|(1<<6);  // (9:4) 0->4 //25MHz
	#elif defined(GMAC_SPD_10M)
	val = val&~((0x3F<<20)|(0x3F<<4));
	val = val|(0x31<<20); //22bit 1 mask (25:20) 49 = 0x31 //2.5MHz = 125/(49+1)
	val = val|(0x31<<4);  //               (9:4) 49 = 0x31 //2.5MHz = 125/(49+1)
	#else
	val = val&~((0x3F<<20)|(0x3F<<4)); //[25:20] 0, [9:4] 0 //125MHz
	#endif
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	printk("\n");

	addr = GMAC1_CFG1; // GMAC1_CFG1 CLKEN to 1
	val = RegRead(addr);
	printk(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(1<<28); //28bit 1 mask
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	printk("\n");

	addr = GMAC1_CFG1; // GMAC1_CFG1 TXCLKOEN to 1
	val = RegRead(addr);
	printk(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(1<<16); //16bit 1 mask
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	printk("\n");

	addr = TPA_CFG_SWRESETN; // TPA CFG GMAC0 swreset
	val = RegRead(addr);
	printk(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val&(~(2<<1)); //2bit 0 mask
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	udelay(100);
	val = val|(2<<1); //2bit 1 mask
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	/* set Delay control registers */
	addr = GMAC1_DLY_CFG_0; // Delay control register 0
	val = 0x10109010;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
#if 0
	addr = GMAC1_DLY_CFG_1; // Delay control register 1
	val = 0x00000000;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
#endif
	addr = GMAC1_DLY_CFG_2; // Delay control register 2
	val = 0x10100010; // cfg_rxclki_inv1 0
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
#if 0
	addr = GMAC1_DLY_CFG_3; // Delay control register 3
	val = 0x00000000;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = GMAC1_DLY_CFG_4; // Delay control register 4
	val = 0x00000000;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
#endif

}

void display_safety_func_regs(void)
{
	uint32 addr;
	//uint32a val;

	/* check safty function disable */
#ifdef DISABLE_EPP_SAFETY
	printk("\n");
	printk("[%s] safety function disabled.\n", __func__);
#else
	printk("\n");
	printk("[%s] safety function enabled.\n", __func__);
#endif
	addr = WSP_FAIL_STOP_MODE_EN_ADDR;
	printk("read addr[%08lx] val[%08x] EPP_GLOBAL_CSR WSP_FAIL_STOP_MODE_EN_ADDR \n", addr, RegRead(addr));

	addr = PART2_GLOBAL_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x] PART2 WSP_FAIL_STOP_MODE_EN\n", addr, RegRead(addr));
	addr = PART2_GLOBAL_BASE_ADDR+0x8;
	printk("read addr[%08lx] val[%08x] PART2 WSP_EMAC_CONFIG_EN_FAIL_STOP_MODE\n", addr, RegRead(addr));
	addr = PART2_GLOBAL_BASE_ADDR+0xC;
	printk("read addr[%08lx] val[%08x] PART2 WSP_EMAC_REG2_CONFIG_EN_FAIL_STOP_MODE\n", addr, RegRead(addr));
	addr = PART2_GLOBAL_BASE_ADDR+0x78;
	printk("read addr[%08lx] val[%08x] PART2 WSP_PARITY_INT_EN\n", addr, RegRead(addr));
	addr = PART2_GLOBAL_BASE_ADDR+0x80;
	printk("read addr[%08lx] val[%08x] PART2 WSP_PARITY_REG2_INT_EN\n", addr, RegRead(addr));

#if 0
	addr = EGPI1_BASE_ADDR+0x0;
	printk("read addr[%08lx] val[%08x] P2 EGPI1 GPI_VERSION\n", addr, RegRead(addr));
	addr = EGPI1_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x] P2 EGPI1 GPI_CTRL\n", addr, RegRead(addr));
	addr = EGPI1_BASE_ADDR+0x8;
	printk("read addr[%08lx] val[%08x] P2 EGPI1 GPI_RX_CONFIG\n", addr, RegRead(addr));

	addr = EGPI4_BASE_ADDR+0x0;
	printk("read addr[%08lx] val[%08x] P3 EGPI4 GPI_VERSION\n", addr, RegRead(addr));
	addr = EGPI4_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x] P3 EGPI4 GPI_CTRL\n", addr, RegRead(addr));
	addr = EGPI4_BASE_ADDR+0x8;
	printk("read addr[%08lx] val[%08x] P3 EGPI4 GPI_RX_CONFIG\n", addr, RegRead(addr));
#endif

#if 0
	addr = PART3_GLOBAL_BASE_ADDR+0x4;
	val = 0;
	RegWrite(addr, val);
	printk("writeaddr[%08lx] val[%08x] PART3 WSP_FAIL_STOP_MODE_EN\n", addr, 0);
	printk("read addr[%08lx] val[%08x] PART3 WSP_FAIL_STOP_MODE_EN\n", addr, RegRead(addr));
	addr = PART3_GLOBAL_BASE_ADDR+0x78;
	val = 0;
	RegWrite(addr, val);
	printk("writeaddr[%08lx] val[%08x] PART3 WSP_PARITY_INT_EN\n", addr, 0);
	printk("read addr[%08lx] val[%08x] PART3 WSP_PARITY_INT_EN\n", addr, RegRead(addr));
	addr = PART3_GLOBAL_BASE_ADDR+0x80;
	val = 0;
	RegWrite(addr, val);
	printk("writeaddr[%08lx] val[%08x] PART3 WSP_PARITY_REG2_INT_EN\n", addr, 0);
	printk("read addr[%08lx] val[%08x] PART3 WSP_PARITY_REG2_INT_EN\n", addr, RegRead(addr));
#endif

	addr = PART4_GLOBAL_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x] PART4 WSP_FAIL_STOP_MODE_EN\n", addr, RegRead(addr));
	addr = PART4_GLOBAL_BASE_ADDR+0x8;
	printk("read addr[%08lx] val[%08x] PART4 WSP_EMAC_CONFIG_EN_FAIL_STOP_MODE\n", addr, RegRead(addr));
	addr = PART4_GLOBAL_BASE_ADDR+0xC;
	printk("read addr[%08lx] val[%08x] PART4 WSP_EMAC_REG2_CONFIG_EN_FAIL_STOP_MODE\n", addr, RegRead(addr));
	addr = PART4_GLOBAL_BASE_ADDR+0x78;
	printk("read addr[%08lx] val[%08x] PART4 WSP_PARITY_INT_EN\n", addr, RegRead(addr));
	addr = PART4_GLOBAL_BASE_ADDR+0x80;
	printk("read addr[%08lx] val[%08x] PART4 WSP_PARITY_REG2_INT_EN\n", addr, RegRead(addr));

	addr = PART5_GLOBAL_BASE_ADDR+0x4;
	RegWrite(addr, 0);
	printk("read addr[%08lx] val[%08x] PART5 WSP_FAIL_STOP_MODE_EN\n", addr, RegRead(addr));
	addr = PART5_GLOBAL_BASE_ADDR+0x8;
	RegWrite(addr, 0);
	printk("read addr[%08lx] val[%08x] PART5 WSP_EMAC_CONFIG_EN_FAIL_STOP_MODE\n", addr, RegRead(addr));
	addr = PART5_GLOBAL_BASE_ADDR+0xC;
	RegWrite(addr, 0);
	printk("read addr[%08lx] val[%08x] PART5 WSP_EMAC_REG2_CONFIG_EN_FAIL_STOP_MODE\n", addr, RegRead(addr));
	addr = PART5_GLOBAL_BASE_ADDR+0x78;
	RegWrite(addr, 0);
	printk("read addr[%08lx] val[%08x] PART5 WSP_PARITY_INT_EN\n", addr, RegRead(addr));
	addr = PART5_GLOBAL_BASE_ADDR+0x80;
	RegWrite(addr, 0);
	printk("read addr[%08lx] val[%08x] PART5 WSP_PARITY_REG2_INT_EN\n", addr, RegRead(addr));

}

void display_partition_3_5_regs(void)
{

#if 0
	uint32 addr;
	uint32a val;

	printk("\n");
	printk("[%s] partition 3 test.\n", __func__);
	addr = EGPI4_BASE_ADDR+0x0;
	printk("read addr[%08lx] val[%08x] P3 EGPI4 GPI_VERSION\n", addr, RegRead(addr));
	addr = EGPI4_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x] P3 EGPI4 GPI_CTRL\n", addr, RegRead(addr));
	addr = EGPI4_BASE_ADDR+0x8;
	printk("read addr[%08lx] val[%08x] P3 EGPI4 GPI_RX_CONFIG\n", addr, RegRead(addr));
#endif

#if 0
	printk("\n");
	printk("[%s] partition 5 R/W test.\n", __func__);
	addr = IPSEC_GPI_BASE_ADDR+0x0;
	printk("read addr[%08lx] val[%08x] P5 IPSEC_GPI GPI_VERSION\n", addr, RegRead(addr));
	addr = IPSEC_GPI_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x] P5 IPSEC_GPI GPI_CTRL\n", addr, RegRead(addr));
	addr = IPSEC_GPI_BASE_ADDR+0x8;
	printk("read addr[%08lx] val[%08x] P5 IPSEC_GPI GPI_RX_CONFIG\n", addr, RegRead(addr));

	addr = IPSEC_CSR_BASE_ADDR+0x0;
	printk("read addr[%08lx] val[%08x] P5 IPSEC IPSEC_VERSION\n", addr, RegRead(addr));
	addr = IPSEC_CSR_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x] P5 IPSEC IPSEC_INT_SRC\n", addr, RegRead(addr));
	addr = IPSEC_CSR_BASE_ADDR+0x14;
	val = 0xaa55aa55;
	RegWrite(addr, val);
	printk("writeaddr[%08lx] val[%08x] P5 IPSEC PSEC_EG_MTU_SIZE\n", addr, val);
	printk("read addr[%08lx] val[%08x] P5 IPSEC PSEC_EG_MTU_SIZE\n", addr, RegRead(addr));
#endif

}

void display_mac_phy_reg(void)
{
	uint32 addr;
	uint32a val;

	/* check GMAC1 Identification and mac address write */
	printk("\n");
	printk("[%s] check GMAC1.\n", __func__);

	addr = EMAC1_BASE_ADDR+0x0;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_BASE_ADDR+0x110;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_BASE_ADDR+0x11C;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_BASE_ADDR+0x120;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_BASE_ADDR+0x124;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_BASE_ADDR+0x128;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));

	addr = EMAC1_MAC_ADDR0_HIGH;
	RegWrite(addr, 0); /* clear reg */
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_MAC_ADDR0_LOW;
	RegWrite(addr, 0); /* clear reg */
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_MAC_ADDR0_HIGH;
	val = 0x00001234;
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	RegWrite(addr, val);
	addr = EMAC1_MAC_ADDR0_LOW;
	val = 0x567890AB;
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	RegWrite(addr, val);
	addr = EMAC1_MAC_ADDR0_HIGH;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_MAC_ADDR0_LOW;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));

	/* check GMAC0 Identification and mac address write */
	printk("\n");
	printk("[%s] check GMAC0.\n", __func__);

	addr = EMAC2_BASE_ADDR+0x0;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_BASE_ADDR+0x110;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_BASE_ADDR+0x11C;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_BASE_ADDR+0x120;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_BASE_ADDR+0x124;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_BASE_ADDR+0x128;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));

	addr = EMAC2_MAC_ADDR0_HIGH;
	RegWrite(addr, 0); /* clear reg */
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_MAC_ADDR0_LOW;
	RegWrite(addr, 0); /* clear reg */
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_MAC_ADDR0_HIGH;
	val = 0x00001234;
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	RegWrite(addr, val);
	addr = EMAC2_MAC_ADDR0_LOW;
	val = 0x567890CD;
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	RegWrite(addr, val);
	addr = EMAC2_MAC_ADDR0_HIGH;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_MAC_ADDR0_LOW;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));


	/* check GMAC 1 again */
	addr = EMAC1_MAC_ADDR0_HIGH;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_MAC_ADDR0_LOW;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));

	/* check phy r/w */
	{
		uint32a emac_idx;
		uint32a phy_addr;
		uint32a reg_addr;
		uint32a dev_addr;
		//uint32a val;

#if 1
		/* check PHY GMAC1 Identification and mac addresss write */
		printk("\n");
		printk("[%s] check GMA1 PHY RTL8211.\n", __func__);
		emac_idx = 0;
		phy_addr = 0;
		printk("[%s] mdio access emac_idx=%d, phy_addr=%d\n", __func__, emac_idx, phy_addr);
		reg_addr = 2;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);
		reg_addr = 3;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);
		reg_addr = 1;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);
		reg_addr = 0xF;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);

		emac_idx = 0;
		phy_addr = 1;
		printk("[%s] mdio access emac_idx=%d, phy_addr=%d\n", __func__, emac_idx, phy_addr);
		reg_addr = 2;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);
		reg_addr = 3;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);
		reg_addr = 1;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);
		reg_addr = 0xF;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);
#endif

		/* check PHY GMAC0 Identification and mac addresss write */
		printk("\n");
		printk("[%s] check GMAC0 PHY MARVELL 88Q2210.\n", __func__);

		emac_idx = 1;
		phy_addr = 5;
		printk("[%s] mdio access emac_idx=%d, phy_addr=%d\n", __func__, emac_idx, phy_addr);
		reg_addr = 2;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);
		reg_addr = 3;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);

		dev_addr = 1;
		reg_addr = 0x2;
		val = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);

		dev_addr = 1;
		reg_addr = 0x3;
		val = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
	}

}
/* this code from linux up stream driver */
void init_realtek_phy(void)
{
	int32a ret;
	uint32a emac_idx;
	uint32a phy_addr;
	uint32a reg_addr;
	uint32a phy_data;
	//uint32a old_page;

	printk("\n");
	printk("[%s] start\n", __func__);

	emac_idx = 0;
	phy_addr = 1;


//read phy 0x0, addr 0x1F, data 0x0
//write phy 0x0, addr 0x1F, data 0x07                             PageSel: 7:Extension page
//write phy 0x0, addr 0x1E, data 0xA4                             Extension Page Select : 0xA4
//read phy 0x0, addr 0x1C, data 0x8577                                ????    not indata sheet
//write phy 0x0, addr 0x1C, data 0x8571                               ????    not indata sheet
//write phy 0x0, addr 0x1F, data 0x0000                               PageSel: 0:Page 0 (restore page)

#if 0
	/* rtl8211e_config_init() */
	reg_addr = 0x1F; //RTL821x_PAGE_SELECT
	phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);
	old_page = phy_data;

	reg_addr = 0x1F; //RTL821x_PAGE_SELECT
	phy_data = 0x07;
	ret = MdioRegWrite(emac_idx, phy_addr, reg_addr, phy_data);

	reg_addr = 0x1E; // RTL821x_EXT_PAGE_SELECT
	phy_data = 0xA4;
	ret = MdioRegWrite(emac_idx, phy_addr, reg_addr, phy_data);

	reg_addr = 0x1C;
	phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);
#if 1
	phy_data &= ~(0x6); //clear RTL8211E_TX_DELAY | RTL8211E_RX_DELAY
#else
	phy_data |= 0x6; //set RTL8211E_TX_DELAY | RTL8211E_RX_DELAY
#endif
	ret = MdioRegWrite(emac_idx, phy_addr, reg_addr, phy_data);

	reg_addr = 0x1F; //RTL821x_PAGE_SELECT, restore page
	phy_data = old_page;
	ret = MdioRegWrite(emac_idx, phy_addr, reg_addr, phy_data);
#endif

	/* phy_start_aneg() */
	/* genphy_config_advert */
	reg_addr = 0x4; // MII_ADVERTISE
	phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);
	phy_data =  0x0DE1; //set ADVERTISE_ALL | ADVERTISE_100BASE4 | ADVERTISE_PAUSE_CAP | ADVERTISE_PAUSE_ASYM
	ret = MdioRegWrite(emac_idx, phy_addr, reg_addr, phy_data);

	reg_addr = 0x9;
	phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);
	phy_data = 0x0300;
	ret = MdioRegWrite(emac_idx, phy_addr, reg_addr, phy_data);

	reg_addr = 0x0;
	phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);
	phy_data = 0x1340;
	ret = MdioRegWrite(emac_idx, phy_addr, reg_addr, phy_data);
}

void display_realtek_phy_status(void)
{
	//int32a ret;
	uint32a emac_idx;
	uint32a phy_addr;
	uint32a reg_addr;
	uint32a phy_data;

	printk("\n");
	printk("[%s] start\n", __func__);

	emac_idx = 0;
	phy_addr = 1;

	/* phy_check_link_status() */
	reg_addr = 0x0;
	phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);

	//bit 2 : link status

	reg_addr = 0x1;
	phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);

//	bit14: 1: Local PHY configuration resolved to MASTER
//	bit13: 1: Local Receiver OK
//	bit12: 1: Remote Receiver OK
//	bit11: 1: Link Partner is capable of 1000Base-T full duplex

	reg_addr = 0xA;
	phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);

#if 0
	udelay(5000);
	init_realtek_phy();
	//udelay(5000);
	printk("\n");
	printk("wait for link up\n");
	{
		int32a i;
		uint32a emac_idx;
		uint32a phy_addr;
		uint32a reg_addr;
		uint32a phy_data;
		emac_idx = 0;
		phy_addr = 1;
		for(i=0;i<1000;i++)
		{
			display_realtek_phy_status();
			msleep(100);

			reg_addr = 0xA;
			phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);
			if( (phy_data&0x3000)==0x3000 )
			{
				printk("confirm link up\n");
				break;
			}
		}
	}
#endif

}

/* Marvell PHY
  1000Base-T1 Initialization Procedure
  from Maevell PHY API User Guide */
void init_marvell_phy_1G(uint32a isMaster)
{
	uint32a emac_idx;
	uint32a phy_addr;
	//uint32a isMaster = 1; // should be 1 or 0

	printk("\n");
	printk("[%s] start\n", __func__);

	emac_idx = 1;
	phy_addr = 5;

	//sleep 2 milliseconds
	//udelay(4000);

	//XRW P0 D3 R8033 H6801
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0x8033, 0x6801);
	//XRW P0 D7 R0200 H0000
	XMdioRegWrite( emac_idx, phy_addr, 0x7, 0x0200, 0x0000);
	//XRW P0 D1 R0000 H0840
	XMdioRegWrite( emac_idx, phy_addr, 0x1, 0x0000, 0x0840);
	//XRW P0 D3 RFE1B H0048
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0xFE1B, 0x0048);
	//XRW P0 D3 RFFE4 H6B6
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0xFFE4, 0x06B6);
	//XRW P0 D1 R0000 H0000
	XMdioRegWrite( emac_idx, phy_addr, 0x1, 0x0000, 0x0000);
	//XRW P0 D3 R0000 H0000
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0x0000, 0x0000);

	//sleep 4 milliseconds
	udelay(4000);
	//XRW P0 D7 R8032 H2020
	XMdioRegWrite( emac_idx, phy_addr, 0x7, 0x8032, 0x2020);
	//XRW P0 D7 R8031 HA28
	XMdioRegWrite( emac_idx, phy_addr, 0x7, 0x8031, 0x0A28);
	//XRW P0 D7 R8031 HC28
	XMdioRegWrite( emac_idx, phy_addr, 0x7, 0x8031, 0x0C28);
	//XRW P0 D3 R803A HDA44
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0x803A, 0xDA44);
	//XRW P0 D3 R8039 H2C0B
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0x8039, 0x2C0B);
	//XRW P0 D4 R80AB H0001
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AB, 0x0001);
	//XRW P0 D4 R80AD H0000
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AD, 0x0000);
	//XRW P0 D4 R80AC H0042
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AC, 0x0042);
	//XRW P0 D4 R80AE H144A
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AE, 0x144A);
	//XRW P0 D4 R80AC H0050
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AC, 0x0050);
	//XRW P0 D4 R80AE HF800
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AE, 0x0800);
	//XRW P0 D4 R80AC H0051
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AC, 0x0051);
	//XRW P0 D4 R80AE H0970
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AE, 0x0970);
	//XRW P0 D4 R80AC H0043
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AC, 0x0043);
	//XRW P0 D4 R80AE H56AD
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AE, 0x56AD);

	//XRW P0 D1 R0834 BXXXX XXXX XXX1 // Update bit 14 based on Master/Salve configuration.
	// For more details refer Device 1, Register 0x0834 in the datasheet.
	XMdioRegWrite( emac_idx, phy_addr, 0x1, 0x0834, (isMaster<<14)|0x1 );

	//XRW P0 D3 R900 H8000
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0x0900, 0x8000);
	//XRW P0 D3 RFFE4 H000C
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0xFFE4, 0x000C);

	printk("[%s] finish\n", __func__);

}

/* Marvell PHY
  100Base-T1 Initialization Procedure
  from Maevell PHY API User Guide document */
void init_marvell_phy_100M(uint32a isMaster)
{
	uint32a emac_idx;
	uint32a phy_addr;
	//uint32a isMaster = 0; // should be 1 or 0

	printk("\n");
	printk("[%s] start\n", __func__);

	emac_idx = 1;
	phy_addr = 5;

	//sleep 2 milliseconds
	//udelay(2000);

	//XRW P0 D3 R8033 H6801
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0x8033, 0x6801);
	//XRW P0 D7 R0200 H0000
	XMdioRegWrite( emac_idx, phy_addr, 0x7, 0x0200, 0x0000);
	//XRW P0 D1 R0000 H0840
	XMdioRegWrite( emac_idx, phy_addr, 0x1, 0x0000, 0x0840);
	//XRW P0 D3 RFE1B H0048
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0xFE1B, 0x0048);
	//XRW P0 D3 RFFE4 H06B6
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0xFFE4, 0x06B6);
	//XRW P0 D1 R0000 H0000
	XMdioRegWrite( emac_idx, phy_addr, 0x1, 0x0000, 0x0000);
	//XRW P0 D3 R0000 H0000
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0x0000, 0x0000);

	//sleep 4 milliseconds
	udelay(4000);
	//XRW P0 D3 RFBBA H0CB2
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0xFBBA, 0x0CB2);
	//XRW P0 D3 RFBBB H0C4A
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0xFBBB, 0x0C4A);
	//XRW P0 D4 R80AB H0001
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AB, 0x0001);
	//XRW P0 D4 R80AD H0000
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AD, 0x0000);
	//XRW P0 D4 R80AC H0042
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AC, 0x0042);
	//XRW P0 D4 R80AE H144A
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AE, 0x144A);
	//XRW P0 D4 R80AC H0050
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AC, 0x0050);
	//XRW P0 D4 R80AE HF800
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AE, 0x0800);
	//XRW P0 D4 R80AC H0051
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AC, 0x0051);
	//XRW P0 D4 R80AE H0970
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AE, 0x0970);
	//XRW P0 D4 R80AC H0043
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AC, 0x0043);
	//XRW P0 D4 R80AE H56AD
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AE, 0x56AD);

	//XRW P0 D1 R0834 BXXXX XXXX XXX0 // Update bit 14 based on Master/Salve configuration.
	// For more details refer Device 1, Register 0x0834 in the datasheet.
	XMdioRegWrite( emac_idx, phy_addr, 0x1, 0x0834, (isMaster<<14)|0x0 );

	//XRW P0 D3 R900 H8000
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0x0900, 0x8000);
	//XRW P0 D3 RFFE4 H000C
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0xFFE4, 0x000C);

	printk("[%s] finish\n", __func__);

}

void init_marvell_phy_1G__(uint32a isMaster)
{
	uint32a emac_idx;
	uint32a phy_addr;
	//uint32a isMaster = 0; // should be 1 or 0

	printk("\n");
	printk("[%s] start\n", __func__);

	emac_idx = 1;
	phy_addr = 5;

	XMdioRegWrite( emac_idx, phy_addr, 0x1, 0x0834, (isMaster<<14)|0x1 );

	printk("[%s] finish\n", __func__);

}

/* Marvell PHY
  100Base-T1 Initialization Procedure
  from Maevell PHY API User Guide */
void init_marvell_phy_100M__(uint32a isMaster)
{
	uint32a emac_idx;
	uint32a phy_addr;
	//uint32a isMaster = 0; // should be 1 or 0

	printk("\n");
	printk("[%s] start\n", __func__);

	emac_idx = 1;
	phy_addr = 5;

	XMdioRegWrite( emac_idx, phy_addr, 0x1, 0x0834, (isMaster<<14)|0x0 );

	printk("[%s] finish\n", __func__);

}

/* Marvell PHY
  Auto-Negotiation Initialization Procedure
  from Maevell PHY API User Guide */
void init_marvell_phy_an(uint32a isMaster)
{
	uint32a emac_idx;
	uint32a phy_addr;
	//uint32a dev_addr;
	//uint32a reg_addr;
	//uint32a phy_data;
	//uint32a isMaster = 0; // should be 1 or 0

	emac_idx = 0;
	phy_addr = 5;

	printk("\n");
	printk("[%s] start\n", __func__);
	//sleep 2 milliseconds
	//udelay(2000);

	//XRW P0 D3 R8033 H6801
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0x8033, 0x6801);
	//XRW P0 D1 R0000 H0840
	XMdioRegWrite( emac_idx, phy_addr, 0x1, 0x0000, 0x0840);
	//XRW P0 D3 RFE1B H0048
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0xFE1B, 0x0048);
	//XRW P0 D3 RFFE4 H06B6
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0xFFE4, 0x06B6);
	//XRW P0 D1 R0000 H0000
	XMdioRegWrite( emac_idx, phy_addr, 0x1, 0x0000, 0x0000);
	//XRW P0 D3 R0000 H0000
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0x0000, 0x0000);

	//sleep 4 milliseconds
	udelay(4000);

	//XRW P0 D3 RFBBA H0CB2
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0xFBBA, 0x0CB2);
	//XRW P0 D3 RFBBB H0C4A
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0xFBBB, 0x0C4A);
	//XRW P0 D7 R8032 H2020
	XMdioRegWrite( emac_idx, phy_addr, 0x7, 0x8032, 0x2020);
	//XRW P0 D7 R8031 H0A28
	XMdioRegWrite( emac_idx, phy_addr, 0x7, 0x8031, 0x0A28);
	//XRW P0 D7 R8031 H0C28
	XMdioRegWrite( emac_idx, phy_addr, 0x7, 0x8031, 0x0C28);
	//XRW P0 D3 R803A HDA44
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0x803A, 0xDA44);
	//XRW P0 D3 R8039 H2C0B
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0x8039, 0x2C0B);
	//XRW P0 D3 RFE5F H00E8
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0xFE5F, 0x00E8);
	//XRW P0 D3 RFE05 H755C
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0xFE05, 0x755C);
	//XRW P0 D4 R80AB H0001
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AB, 0x0001);
	//XRW P0 D4 R80AD H0000
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AD, 0x0000);
	//XRW P0 D4 R80AC H0042
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AC, 0x0042);
	//XRW P0 D4 R80AE H144A
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AE, 0x144A);
	//XRW P0 D4 R80AC H0050
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AC, 0x0050);
	//XRW P0 D4 R80AE HF800
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AE, 0xF800);
	//XRW P0 D4 R80AC H0051
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AC, 0x0051);
	//XRW P0 D4 R80AE H0970
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AE, 0x0970);
	//XRW P0 D4 R80AC H0043
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AC, 0x0043);
	//XRW P0 D4 R80AE H56AD
	XMdioRegWrite( emac_idx, phy_addr, 0x4, 0x80AE, 0x56AD);

	//XRW P0 D7 R0200 H1000
	XMdioRegWrite( emac_idx, phy_addr, 0x7, 0x0200, 0x1000);

	//XRW P0 D3 R0900 H8000
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0x0900, 0x8000);
	//XRW P0 D3 RFFE4 H000C
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0xFFE4, 0x000C);

	printk("[%s] finish\n", __func__);

}

#if 0
void marvell_phy_tc10_disable(void)
{
	uint32a emac_idx;
	uint32a phy_addr;
	uint32a isMaster = 1; // should be 1 or 0

	printk("[%s] start\n", __func__);

	emac_idx = 1;
	phy_addr = 5;

	//XRW P0 D3 R8033 H6801
	XMdioRegWrite( emac_idx, phy_addr, 0x3, 0x8033, 0x6801);

	dev_addr = 7;
	reg_addr = 0x0200;
	phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
	printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);

}
#endif

void display_marvell_phy_status(void)
{

		uint32a emac_idx;
		uint32a phy_addr;


		printk("\n");
		printk("[%s] start\n", __func__);

		emac_idx = 1;
		phy_addr = 5;

#if 0
		/* code from marvell phy sample code */
		/* 4) check status */
		checkLink(DUT, &isLinkup);
		checkIsMaster(DUT, &isMaster);
		getSpeed(DUT, &speed);
		printf(">> Link Status: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
		getLatchedLinkStatus(DUT, &isLinkup);
		printf(">> Latched Link Status 1: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
		getRealTimeLinkStatus(DUT, &isLinkup);
		printf(">> Real Time Link Status: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
		getLatchedLinkStatus(DUT, &isLinkup);
		printf(">> Latched Link Status 2: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
		printf(">> Master/Slave: %s\n", MRVL_APHY_TRUE == isMaster ? "Master" : "Slave");
		printf(">> Speed: %s\n", MRVL_APHY_SPEED_1000 == speed ? "GE/1000" : "FE/100");
#else
		{
			uint32a dev_addr;
			uint32a reg_addr;
			uint32a phy_data;
			uint32a regVal1;
			uint32a regVal2;
			uint32a regVal3;

			uint32a isMaster;
			uint32a isAnEnabled;
			uint32a isLinkup;
			uint32a currSpeed;

			/* get An enabled */
			dev_addr = 7;
			reg_addr = 0x0200;
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
			//printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);
			isAnEnabled = ((phy_data&0x1000) != 0x0) ? 1 : 0;

			printk(">> AN enabled : %d\n", isAnEnabled);

			if( isAnEnabled == 1 )
			{
				dev_addr = 7;
				reg_addr = 0x801a;
				phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
				//printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);
				if((phy_data&0x4000)!=0x0)
				{
					currSpeed = 1000;
				}
				else
				{
					currSpeed = 100;
				}
				printk(">> speed : %s\n", (currSpeed==1000) ? "1G" : "100M");
				dev_addr = 7;
				reg_addr = 0x8001;
				phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
				//printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);
				isMaster = ((phy_data&0x4000)!=0 ) ? 1:0;
				printk(">> M/S : %s\n", isMaster ? "Master" : "Slave");
			}
			else
			{
				dev_addr = 1;
				reg_addr = 0x0834;
				phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
				//printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);
				if( (phy_data&0x1)!=0x0 )
				{
					currSpeed = 1000;
				}
				else
				{
					currSpeed = 100;
				}
				printk(">> speed : %s\n", (currSpeed==1000) ? "1G" : "100M");

				isMaster = ((phy_data&0x4000)!=0) ? 1:0;
				printk(">> M/S : %s\n", isMaster ? "Master" : "Slave");
			}

			if(currSpeed == 1000)
			{
				printk(">> check link 1G\n");

				dev_addr = 3;
				reg_addr = 0x0901;
				phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
				phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr); /* Read twice: link latches low status */
				regVal1 = phy_data;
				//printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);

				dev_addr = 7;
				reg_addr = 0x8001;
				phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr); /* local and remote receiver status */
				regVal2 = phy_data;
				//printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);

				dev_addr = 3;
				reg_addr = 0xFD9D;
				phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr); /* local receiver status 2 */
				regVal3 = phy_data;
				//printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);

				isLinkup = ((0x0004U == (regVal1 & 0x0004U))
								&& (0x3000U == (regVal2 & 0x3000U))
								&& (0x0010U == (regVal3 & 0x0010U))) ? 1 : 0;
				printk(">> link up : %d (1G)\n", isLinkup);
			}
			else
			{
				printk(">> check link 100M\n");
				dev_addr = 3;
				reg_addr = 0x8109;
				phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
				regVal1 = phy_data;

				dev_addr = 3;
				reg_addr = 0x8108;
				phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
				regVal2 = phy_data;

				dev_addr = 3;
				reg_addr = 0x8230;
				phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
				regVal3 = phy_data;

				isLinkup = ((0x0004U == (regVal1 & 0x0004U))
								&& (0x3000U == (regVal2 & 0x3000U))
								&& (0x0001U == (regVal3 & 0x0001U))) ? 1 : 0;
				printk(">> link up : %d (100M)\n", isLinkup);
			}

			dev_addr = 7;
			reg_addr = 0x0201; //BASE-T1 Auto-Negotiation Status Register
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
			isLinkup = (0x0U != (phy_data & 0x0004U)) ? 1 : 0;
			printk(">> Latched Link Status 1: %s\n", isLinkup ? "Up" : "Down");

			if(currSpeed == 1000)
			{
				/* 1000 speed real time link is a latched link */
				dev_addr = 3;
				reg_addr = 0x0901; //PCS 1000BASE-T1 Status Register 1
				phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
				phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr); /* Read twice: link latches low status */
				//printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);
			}
			else
			{
				dev_addr = 3;
				reg_addr = 0x8109;
				phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);

			}
			isLinkup = (0x0U != (phy_data & 0x0004U)) ? 1 : 0;
			printk(">> Real Time Link Status: %s\n", isLinkup ? "Up" : "Down");

			dev_addr = 7;
			reg_addr = 0x0201; //BASE-T1 Auto-Negotiation Status Register
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
			isLinkup = (0x0U != (phy_data & 0x0004U)) ? 1 : 0;
			printk(">> Latched Link Status 2: %s\n", isLinkup ? "Up" : "Down");

			#if 0 /* disable TC10 function by register */
			dev_addr = 3;
			reg_addr = 0x8027; //Common Sleep/Wakeup Configuration
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
			printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);

			phy_data &= ~(0x1);
			XMdioRegWrite( emac_idx, phy_addr, dev_addr, reg_addr, phy_data);
			printk("XMdioRegWrite dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);

			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
			printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);
			#endif
		}
#endif

}

void init_gmac(uint32a gmac_idx)
{
	uint32 base_addr;
	uint32 addr;
	uint32a val;
	uint32a wrval;
	uint32a mac_high;
	uint32a mac_low;

	switch(gmac_idx)
	{
		case 0:
			base_addr = EMAC2_BASE_ADDR;
			mac_high = 0xDBA9;
			mac_low  = 0x87650000;
			break;

		case 1:
			base_addr = EMAC1_BASE_ADDR;
			mac_high = 0xDBA9;
			mac_low  = 0x87651111;
			break;

		default:
			break;
	}

	printk("\n");
	printk("[%s] initialize GMAC%d.\n", __func__, gmac_idx);

	addr = base_addr+0xC00; // MTL_Operation_Mode
	wrval = val = RegRead(addr);
	#if 0
	wrval &= ~(1<<2); //Receive Arbitration Algorithm; 0: Strict priority (SP).
	wrval |= (0x3<<5); //Tx Scheduling Algorithm; 0x3 (SP): Strict priority algorithm
	#else
	wrval = 0;
	#endif
	RegWrite(addr, wrval);
	printk("write addr[%08lx] val[%08x]->[%08x]\n", addr, val, wrval);

	addr = base_addr+0xC30; // MTL_RxQ_DMA_Map0
	wrval = val = RegRead(addr);
	#if 0
	wrval &= ~(0x7<<0); // Queue 0 Mapped to DMA Channel 0
	wrval |= (0x1<<4); // Queue 0 Enabled : 0x1 enabled
	wrval &= ~(0x7<<8); // Queue 1 Mapped to DMA Channel 0
	wrval |= (0x1<<12); // Queue 1 Enabled : 0x1 enabled
	#else
	wrval = 0; //static, DMA channel 0
	#endif
	RegWrite(addr, wrval);
	printk("write addr[%08lx] val[%08x]->[%08x]\n", addr, val, wrval);

	addr = base_addr+0xD00; // MTL_TxQ0_Operation_Mode
	wrval = val = RegRead(addr);
	#if 0
	wrval &= ~((0x7F<<16)|(1<<3)              );
	wrval |=  ((0x40<<16)       |(1<<2)|(1<<1));
	                         // TQS=0x40, maybe shloul 0x3F,
	                         //     size of Queue=(0x3F+1)*0x100 = 0x4000 = 16KB
	                         // TXQEN = 01b = Enable in AV mode
	                         // TSF = Enable Transmit Store and Forward
	#else
	wrval = 0x001F000A;
	#endif

	RegWrite(addr, wrval);
	printk("write addr[%08lx] val[%08x]->[%08x]\n", addr, val, wrval);

	addr = base_addr+0xD30; // MTL_RxQ0_Operation_Mode
	wrval = val = RegRead(addr);
	#if 0
	wrval &= ~((0x7F<<20)              );
	wrval |=   (0x40<<20)|(1<<7)|(1<<5);
	#else
	wrval = 0x01F18AF8;
	#endif
	RegWrite(addr, wrval);
	printk("write addr[%08lx] val[%08x]->[%08x]\n", addr, val, wrval);

	addr = base_addr+0xD40; // MTL_TxQ1_Operation_Mode
	wrval = val = RegRead(addr);
	#if 0
	wrval &= ~((0x7F<<16)|(1<<3)              );
	wrval |=  ((0x40<<16)       |(1<<2)|(1<<1));
	                         // TQS=0x40, maybe shloul 0x3F,
	                         //     size of Queue=(0x3F+1)*0x100 = 0x4000 = 16KB
	                         // TXQEN = 01b = Enable in AV mode
	                         // TSF = Enable Transmit Store and Forward
	#else
	wrval = 0;
	//wrval = 0x001F000A;
	#endif
	RegWrite(addr, wrval);
	printk("write addr[%08lx] val[%08x]->[%08x]\n", addr, val, wrval);

	addr = base_addr+0xD70; // MTL_RxQ1_Operation_Mode
	wrval = val = RegRead(addr);
	#if 0
	wrval &= ~((0x7F<<20)              );
	wrval |=   (0x40<<20)|(1<<7)|(1<<5);
	#else
	wrval = 0;
	//wrval = 0x01F18AF8;
	#endif
	RegWrite(addr, wrval);
	printk("write addr[%08lx] val[%08x]->[%08x]\n", addr, val, wrval);

	addr = base_addr + 0x300; // MAC_Address0_High
	val  = mac_high;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0x304; // MAC_Address0_Low
	val  = mac_low;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0x008; // MAC_Packet_Filter
	#if 0
	val = 0x80000400;
	#else
	val = 0x80000050;
	#endif
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0xA0; // MAC_RxQ_Ctrl0
	#if 0
	val  = 0x5;
	#else
	val = 0x00000002;
	//val = 0x00000006;
	#endif
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0xB4;; // MAC_Interrupt_Enable
	//val  = 0xFFFFFFFF;
	val  = 0x00067009;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0x0; // MAC_Configuration
#if 0
	#ifdef GMAC_SPD_100M
	val  = 0xE403; // 100Mbps  [15]:PS=1, [14]:FES=1
	#elif defined(GMAC_SPD_10M)
	val  = 0xA403; // 10Mbps   [15]:PS=1, [14]:FES=0
	#else
	val  = 0x2403; // 1Gbps    [15]:PS=0, [14]:FES=0
	#endif
	#ifdef GMAC_LOOPBACK_MODE
	val |= (1<<12);
	#endif
#else
	#ifdef GMAC_SPD_100M
	//val = 0x0000E203;
	val = 0x0030E203;
	#else
	val = 0x00302203;
	#endif
#endif
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

}

void init_gmac_alt(uint32a gmac_idx)
{
	uint32 base_addr;
	uint32 addr;
	uint32a val;
	//uint32a wrval;
	uint32a mac_high;
	uint32a mac_low;

	switch(gmac_idx)
	{
		case 0:
			base_addr = EMAC2_BASE_ADDR;
			mac_high = 0xDBA9;
			mac_low  = 0x87650000;
			break;

		case 1:
			base_addr = EMAC1_BASE_ADDR;
			mac_high = 0xDBA9;
			mac_low  = 0x87651111;
			break;

		default:
			break;
	}

	printk("\n");
	printk("[%s] initialize GMAC%d.\n", __func__, gmac_idx);

	addr = base_addr+0xC00; // MTL_Operation_Mode
	val = 0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0xC30; // MTL_RxQ_DMA_Map0
	val = 0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0xD00; // MTL_TxQ0_Operation_Mode
	val = 0x001F000A;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0xD30; // MTL_RxQ0_Operation_Mode
	val = 0x01F18AA0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0x300; // MAC_Address0_High
	val  = mac_high | (1<<31);
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0x304; // MAC_Address0_Low
	val  = mac_low;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0x008; // MAC_Packet_Filter
	val = 0x80000050;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0xA0; // MAC_RxQ_Ctrl0
	val = 0x00000002;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0xB4;; // MAC_Interrupt_Enable
	//val  = 0xFFFFFFFF;
	val  = 0x00067009;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0x0; // MAC_Configuration
	#ifdef GMAC_SPD_100M
	val  = 0x0837E203; // 100Mbps  [15]:PS=1, [14]:FES=1
	#elif defined(GMAC_SPD_10M)
	val  = 0x0837A203; // 10Mbps   [15]:PS=1, [14]:FES=0
	#else
	val  = 0x08372203; // 1Gbps    [15]:PS=0, [14]:FES=0
	#endif
	#ifdef GMAC_LOOPBACK_MODE
	val |= (1<<12);
	#endif
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

}

/* FPGA simulation setting */
void init_xgmac(uint32a gmac_idx)
{
	uint32 base_addr;
	uint32 addr;
	uint32a val;
	uint32a mac_high;
	uint32a mac_low;

	switch(gmac_idx)
	{
		case 0:
			base_addr = EMAC3_BASE_ADDR;
			mac_high = 0x8877;
			mac_low  = 0x665544F3;
			break;

		case 1:
			base_addr = EMAC4_BASE_ADDR;
			mac_high = 0x8877;
			mac_low  = 0x665544F4;
			break;

		default:
			break;
	}

	printk("\n");
	printk("[%s] initialize XGMAC%d.\n", __func__, gmac_idx);
	printk("[%s] SOC setting.\n", __func__);

#if 1
	addr = base_addr+0x158; // MAC_FSM_Control
	val = RegRead(addr);
	val |= 0x2;
	val &= ~(0x1);
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
#endif
	addr = base_addr+0x10e0; // MTL_DPP_Control
	val = 0x7;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x000; // MAC_Tx_Configuration
	val = 0x60000001; //1G GMII
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x0b4; // MAC_Interrupt_Enable
	val = 1;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x004; // MAC_Rx_Configuration
	val = 0x000002C7;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x008; // MAC_Packet_Filter
	val = 0x00000001;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x280; // MAC_FPE_CTRL_STS
	val = 0x0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x0a4; // MAC_RxQ_Ctrl1
	val = 0x0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x1090; // MAC_RxQ_Ctrl1
	val = 0x100;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x0b4; // MAC_Interrupt_Enable
	val = 0x8001;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x1000; // MTL_Operation_Mode
	val = 0x0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x0a0; // MAC_RxQ_Ctrl0
	val = 0x00000002;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x0a8; // MAC_RxQ_Ctrl2
	val = 0x08040201;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x0ac; // MAC_RxQ_Ctrl3
	val = 0x80402010;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x008; // MAC_Packet_Filter
	val = 0x80000000; //RA=1
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x050; // MAC_VLAN_Tag_Ctrl
	val = 0x81000000;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x1040; // MTL_TC_Prty_Map0
	val = 0x0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x1044; // MTL_TC_Prty_Map1
	val = 0x0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x090; // MAC_Rx_Flow_Ctrl
	val = 0x0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x300; // MAC_Address0_High
	val  = 0x0504 | (1<<31);
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x304; // MAC_Address0_Low
	val  = 0x03020100;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x1000; // MTL_Operation_Mode
	val = 0x2;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x11C0; // MTL_RxQ1_Operation_Mode
	val = 0x003f0000;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x1180; // MTL_TxQ11_Operation_Mode
	val = 0x003f0108;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x1140; // MTL_RxQ0_Operation_Mode
	val = 0x007f0010;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x1100; // MTL_TxQ0_Operation_Mode
	val = 0x007f0008;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);


}

/**********************************************************************
 * Function Name  : platform_init
 * Description    : platform specific network device initialisation
 * Inputs
 *   Parameters   : struct pci_dev *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
int32a platform_init(struct pci_dev *pdev)
{
	int32a rc = 0;
	int32a c;
	struct net_device *dev;
	struct fp_private *fppriv;
	int32a bar_io_index;
	int32a bar_mem_index;
	int32a bar_config_index;

	for (c=0; c<5; c++) {
		// clear the memory before we start
		memset(&config[c],0,sizeof(struct memconfig));
	}

	bar_io_index = 0;
	bar_config_index = 2;
	bar_mem_index = 4;

	// set up the arrays for this specific platform
	config[bar_io_index].start = pci_resource_start(pdev, bar_io_index);
	config[bar_io_index].end   = pci_resource_end(pdev, bar_io_index);
	config[bar_io_index].len   = pci_resource_len(pdev, bar_io_index);
	config[bar_io_index].valid = 1;
	config[bar_config_index].start = pci_resource_start(pdev, bar_config_index);
	config[bar_config_index].end   = pci_resource_end(pdev, bar_config_index);
	config[bar_config_index].len   = pci_resource_len(pdev, bar_config_index);
	config[bar_config_index].valid = 1;
	config[bar_mem_index].start = pci_resource_start(pdev, bar_mem_index);
	config[bar_mem_index].end   = pci_resource_end(pdev, bar_mem_index);
	config[bar_mem_index].len   = pci_resource_len(pdev, bar_mem_index);
	config[bar_mem_index].valid = 1;

	printk("[%s]config[%d].start=0x%llX\n", __func__, bar_io_index, config[bar_io_index].start);
	printk("[%s]config[%d].end  =0x%llX\n", __func__, bar_io_index, config[bar_io_index].end);
	printk("[%s]config[%d].len  =0x%llX\n", __func__, bar_io_index, config[bar_io_index].len);
	printk("[%s]config[%d].start=0x%llX\n", __func__, bar_config_index, config[bar_config_index].start);
	printk("[%s]config[%d].end  =0x%llX\n", __func__, bar_config_index, config[bar_config_index].end);
	printk("[%s]config[%d].len  =0x%llX\n", __func__, bar_config_index, config[bar_config_index].len);
	printk("[%s]config[%d].start=0x%llX\n", __func__, bar_mem_index, config[bar_mem_index].start);
	printk("[%s]config[%d].end  =0x%llX\n", __func__, bar_mem_index, config[bar_mem_index].end);
	printk("[%s]config[%d].len  =0x%llX\n", __func__, bar_mem_index, config[bar_mem_index].len);

	rc = pci_request_regions(pdev, DRV_NAME);
	if (rc) {
		printk("\n Can't obtain PCI resources");
		pci_disable_device(pdev);
		pci_set_drvdata(pdev, NULL);
		return 0;
	}

	rc = pci_set_dma_mask(pdev, DMA_BIT_MASK(32));
	if (rc) {
		printk("No usable DMA configuration");
		pci_release_regions(pdev);
		return 0;
	}
	rc = pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(32));
	if (rc) {
		printk("Consistent DMA not available\n");
		pci_release_regions(pdev);
		return 0;
	}
	pci_set_master(pdev);
	pci_enable_msi(pdev);
	config[bar_io_index].membase = ioremap_nocache(config[bar_io_index].start, config[bar_io_index].len);
	config[bar_mem_index].membase = ioremap_nocache(config[bar_mem_index].start, config[bar_mem_index].len);
	config[bar_config_index].membase = ioremap_nocache(config[bar_config_index].start, config[bar_config_index].len);

	printk("[%s] BAR0 membase=0x%p\n", __func__, config[bar_io_index].membase);
	printk("[%s] BAR2 membase=0x%p\n", __func__, config[bar_config_index].membase);
	printk("[%s] BAR4 membase=0x%p\n", __func__, config[bar_mem_index].membase);

	#if 1
	/* Workround for FPGA DRAM memset/memcpy error */
	plt_alloc_buffer();
	fpga_dram_base = config[bar_mem_index].membase;
	//test_memcpy();
	#endif

#if 0
	printk("\n[%s] invoke test_reg_map()\n", __func__);
	test_reg_map();
#endif

	InitBaseAddr(config[bar_io_index].membase);

	printk("[%s] invoke fp_netdev_init(), membase=0x%p, pdev->irq=%d\n", __func__, config[bar_io_index].membase, pdev->irq);

#ifdef ENABLE_PCI_INTERRUPT
	platform_pci_interrupt_enable();
#endif

	tpa_config();

	dev = fp_netdev_init(config[bar_io_index].membase, pdev->irq);
	if (dev != NULL)
	{
		pci_set_drvdata(pdev, dev);
		fppriv = netdev_priv(dev);
		fppriv->pci_dev = pdev;
		printk("[%s] fp_netdev_init() success\n", __func__);
		return 1;	// return success
	}
	pci_set_drvdata(pdev, NULL);

	printk("[%s] fp_netdev_init() failed\n", __func__);

	return 0;	// return fail;
}

/**********************************************************************
 * Function Name  : platform_dma_alloc
 * Description    : get dma allocation done for this specific platform
 * Inputs
 *   Parameters   : - offset
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void *platform_dma_alloc(uint32a ch_id,
            uint32a  total_ring_size,
            struct device *pdev,
            dma_addr_t    *pdev_addr,
            gfp_t         gfp)
{
	#ifdef USE_DB_BUFFER_FPGA_DRAM

		dma_addr_t phy_addr;
		uint8 *vir_addr;
		uint32a aligned_ring_size;

		*pdev_addr = phy_addr = FPGA_DRAM_START_ADDR + used_offset;
		vir_addr = config[4].membase + used_offset;


		/* 8byte align */
		aligned_ring_size = (total_ring_size+BYTE_ALIGN_BIT_MASK-1)&(~(BYTE_ALIGN_BIT_MASK-1));
		used_offset += aligned_ring_size;

		printk("[%s] pdev_addr = %llx, cpu_addr=%px, size=[%d=>%d]\n", __func__, phy_addr, vir_addr, total_ring_size, aligned_ring_size);
		return vir_addr;

	#else

	    size_t size = total_ring_size;

		#if 0
		printk("pdev->dma_ops: %p", pdev->dma_ops);
		if (pdev->dma_ops)
		{
			printk("dma_ops->alloc: %pF\n", pdev->dma_ops->alloc);
		}
		printk("dma_mem: 0x%016llx\n", (phys_addr_t)pdev->dma_mem);
		printk("pdev->cma_area: %p", pdev->cma_area);
		#endif

	    printk("%s -- ch_id = %i, pdev = %px, size = %li, pdev_addr = %px\n",
	        __FUNCTION__, ch_id, pdev, size, pdev_addr);
	    return dma_alloc_coherent(pdev, size, pdev_addr, GFP_ATOMIC);

	#endif
}

/**********************************************************************
 * Function Name  : platform_start
 * Description    : write non-EPP registers in memory space to start or
 *                  configure the specific platform
 * Inputs
 *   Parameters   : -
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void platform_start()
{
	display_safety_func_regs();

	display_partition_3_5_regs();

	display_mac_phy_reg();

	init_gmac_alt(1);
	init_gmac_alt(0);
	init_xgmac(0);

	udelay(1000);
#if 1
	init_realtek_phy();
#endif
	display_realtek_phy_status();

#if 1
	//init_marvell_phy_100M(0);
	//init_marvell_phy_100M(1);
	init_marvell_phy_100M__(1);
	//init_marvell_phy_an(1);
	//init_marvell_phy_1G__(1);
#endif
	udelay(10000);

	display_marvell_phy_status();

	//display_realtek_phy_status();

	printk("[%s] finish\n", __func__);
	printk("\n");
}

/**********************************************************************
 * Function Name  : platform_clear_interrupt
 * Description    : clear platform interrupts ( if needed )
 * Inputs
 *   Parameters   : -
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void platform_clear_interrupt()
{
	;	//
}

#ifdef ENABLE_PCI_INTERRUPT
void platform_pci_interrupt_enable(void)
{
	volatile void *user_int_enable_w1s;

	user_int_enable_w1s = (volatile void*)(config[2].membase + XDMA_OFS_INT_CTRL + 0x8);

	iowrite32(PCI_INTERRUPT_MASK, user_int_enable_w1s);
}

void platform_pci_interrupt_disable(void)
{
	volatile void *user_int_enable_w1c;

	user_int_enable_w1c  = (volatile void*)(config[2].membase + XDMA_OFS_INT_CTRL + 0xc);

	iowrite32(PCI_INTERRUPT_MASK, user_int_enable_w1c);
}
#endif

#if 1
void *platform_memset(void *s, int32a c, size_t n)
{
	if(c==0)
	{
		if(n<=ZERO_BUFFER_SIZE)
		{
			//printk("[%s] memset size %ld, addr %px\n", __func__, n, s);
			memcpy(s,zero_buffer, n);
		}
		else
		{
			printk("[%s] memset size over %ld\n", __func__, n);
		}
	}
	else
	{
		printk("[%s] memset value=0x%02X\n", __func__, c);
	}

	return s;
}

void *platform_memcpy(void *d, void *s, size_t n)
{
	size_t aligned_len = (n+(COPY_SIZE_ALIGN-1))&(~(COPY_SIZE_ALIGN-1));

	//printk("[%s] from %px to %px, %ld=>%ld\n",__func__, s, d, n,aligned_len);
	if(n>COPY_BUFFER_SIZE)
	{
		printk("[%s]copy size to big %ld\n",__func__, n);
		return NULL;
	}
	memcpy(copy_buffer, s, n);
	if(aligned_len != n)
	{
		memset(copy_buffer+n, 0, aligned_len-n);
	}
	memcpy(d, copy_buffer, aligned_len);

	return d;
}

void *platform_memcpy_sw(void *d, void *s, size_t n)
{
	int8 *src=(int8*)s;
	int8 *dst=(int8*)d;

	//printk("[%s] from %px to %px, %ld\n",__func__, s, d, n);
	if(n>0)	{
		do {
			*dst++=*src++;
			n--;
		}while(n>0);
	}
	//printk("[%s] done\n",__func__);
	return d;
}

#endif

void dump_hif_regs(void)
{
#if 1
	uint32a value[4];
	uint32 base_addr, addr;
	uint32 offset;

	printk("[%s]\n", __func__);

	base_addr = 0x00680000; //HIF_BASE_ADDR;
	for(offset=0x0; offset<0x100; offset +=0x10)
	{
		addr = base_addr + offset;
		value[0] = RegRead(addr);
		value[1] = RegRead(addr+0x4);
		value[2] = RegRead(addr+0x8);
		value[3] = RegRead(addr+0xC);
		printk("addr %08lx value %08X %08X %08X %08X\n", addr, value[0], value[1], value[2], value[3]);
	}

	for(offset=0x1000; offset<0x1100; offset +=0x10)
	{
		addr = base_addr + offset;
		value[0] = RegRead(addr);
		value[1] = RegRead(addr+0x4);
		value[2] = RegRead(addr+0x8);
		value[3] = RegRead(addr+0xC);
		printk("addr %08lx value %08X %08X %08X %08X\n", addr, value[0], value[1], value[2], value[3]);
	}
#endif
}


uint32a egpi_reg_value_before[4][320] = {0, };

void diff_egpi_reg(int8 egpi_no, int8 ino)
{
	uint32a value[320];
	uint32 base_addr, addr;
	uint32 offset;
	uint32a i, j, index;

	switch(egpi_no)
	{
		case 1: //EGPI1
			base_addr = 0x00200000;
			index = 0;
			break;

		case 2: //EGPI2
			base_addr = 0x00201000;
			index = 1;
			break;

		case 3: //EGPI3
			base_addr = 0x00202000;
			index = 2;
			break;

		default:
			printk("WRONG number!!!\n");
			return;
//			break;
	}

	/* 200~24C, 260~2B4, 300 ~ 30C, 800 */

	i = 0;
#if 0
	for(offset=0x0; offset<0x500; offset += 0x10)
	{
		if(i > 320)
			break;

		addr = base_addr + offset;
		value[i++] = RegRead(addr);
		value[i++] = RegRead(addr+0x4);
		value[i++] = RegRead(addr+0x8);
		value[i++] = RegRead(addr+0xC);
//		printk("addr %08lx value %08X %08X %08X %08X\n", addr, value[0], value[1], value[2], value[3]);
	}
//	printk("=========================================================================================");

	if(i > 320)
		i = 320;

	if(ino == 0)
	{
		platform_memset(&egpi_reg_value_before[index], 0x00, 320);
		memcpy(egpi_reg_value_before[index], value, i);
	}
	else
	{
		printk("================== different addr & value [EGPI %d] ==================\n", egpi_no);
		for(j=0;j<i;j++)
		{
			if(egpi_reg_value_before[index][j] != value[j])
			{
				printk("addr %08lx value BEF:%08X AFT:%08X\n", base_addr + (4*j), egpi_reg_value_before[index][j], value[j]);
			}
		}
	}
#else
	for(offset=0x0; offset<0x500; offset += 0x10)
	{
		if(i > 320)
			break;

		addr = base_addr + offset;

		if(ino == 0)
		{
			egpi_reg_value_before[index][i++] = RegRead(addr);
			egpi_reg_value_before[index][i++] = RegRead(addr+0x4);
			egpi_reg_value_before[index][i++] = RegRead(addr+0x8);
			egpi_reg_value_before[index][i++] = RegRead(addr+0xc);
		}
		else
		{
			value[i++] = RegRead(addr);
			value[i++] = RegRead(addr+0x4);
			value[i++] = RegRead(addr+0x8);
			value[i++] = RegRead(addr+0xC);
		}
	}

	if(i > 320)
		i = 320;

	if(ino != 0)
	{
		printk("================== different addr & value [EGPI %d] ==================\n", egpi_no);
		for(j=0;j<i;j++)
		{
			if(egpi_reg_value_before[index][j] != value[j])
			{
				printk("addr %08lx value BEF:%08X AFT:%08X\n", base_addr + (4*j), egpi_reg_value_before[index][j], value[j]);
			}
		}
	}

#endif
}


/*
HIF CSR : 0x00680000
HIF_TX_PKT_CNT1: 0x9c
HIF_TX_PKT_CNT2: 0xa0

GPI CSR : 0x00600000
GPI_RX0_IN_PKT_CNT: 0x470
GPI_RX0_OUT_PKT_CNT: 0x474
GPI_TX0_IN_PKT_CNT: 0x490
GPI_TX0_OUT_PKT_CNT: 0x494

Ingress Classifier Base address = EGPIX or HGPI base address + 0x600H
HGPI : 0x00600000
Ingress Classifier HW CSR : 0x00600600
CLASS_PHY1_RX_PKTS: 0x11c

TMU CSR
TLITE1 : 0X00208000
TLITE2 : 0X00209000
TLITE3 : 0X0020A000
TLITE5 : 0X00608000
TLITE6 : 0X00808000
TMU_PHY_INQ_INPKT_CNT: 0x304
TMU_PHY_OUTPKT_CNT: 0x308
*/

#define HGPI_BASE 0x00600000
#define TLITE2_BASE 0X00209000
#define TLITE3_BASE 0X0020A000
#define TLITE5_BASE 0X00608000
#define TLITE6_BASE 0X00808000
#define EGPI1_BASE 0x00200000
#define EGPI2_BASE 0x00201000
#define EGPI3_BASE 0x00202000



uint32 g_reg[66] = {
HIF_TX_PKT_CNT1, HIF_TX_PKT_CNT2,
HGPI_BASE + GPI_CSR_GPI_RX0_IN_PKT_CNT,
HGPI_BASE + GPI_CSR_GPI_RX0_OUT_PKT_CNT,
HGPI_BASE + GPI_CSR_GPI_TX0_IN_PKT_CNT,
HGPI_BASE + GPI_CSR_GPI_TX0_OUT_PKT_CNT,
CLASS_PHY1_RX_PKTS_ADDR,
HGPI_BASE + 0x600 + CLASS_HW_CSR_CLASS_PHY1_RX_PKTS,
TMU_PHY_INQ_INPKT_CNT_ADDR,
TLITE2_BASE + TLITE_CSR_TMU_PHY_INQ_INPKT_CNT,
TLITE3_BASE + TLITE_CSR_TMU_PHY_INQ_INPKT_CNT,
TLITE5_BASE + TLITE_CSR_TMU_PHY_INQ_INPKT_CNT,
TLITE6_BASE + TLITE_CSR_TMU_PHY_INQ_INPKT_CNT,
TMU_PHY_OUTPKT_CNT_ADDR,
TLITE2_BASE + TLITE_CSR_TMU_PHY_OUTPKT_CNT,
TLITE3_BASE + TLITE_CSR_TMU_PHY_OUTPKT_CNT,
TLITE5_BASE + TLITE_CSR_TMU_PHY_OUTPKT_CNT,
TLITE6_BASE + TLITE_CSR_TMU_PHY_OUTPKT_CNT,
EGPI1_BASE + GPI_CSR_GPI_RX0_IN_PKT_CNT,
EGPI1_BASE + GPI_CSR_GPI_RX0_OUT_PKT_CNT,

EGPI1_BASE + GPI_CSR_GPI_TX0_IN_PKT_CNT,		// check

EGPI1_BASE + GPI_CSR_GPI_TX0_OUT_PKT_CNT,
EGPI1_BASE + GPI_CSR_GPI_RX1_IN_PKT_CNT,
EGPI1_BASE + GPI_CSR_GPI_RX1_OUT_PKT_CNT,
EGPI1_BASE + GPI_CSR_GPI_TX1_IN_PKT_CNT,
EGPI1_BASE + GPI_CSR_GPI_TX1_OUT_PKT_CNT,
EGPI1_BASE + GPI_CSR_GPI_RX2_IN_PKT_CNT,
EGPI1_BASE + GPI_CSR_GPI_RX2_OUT_PKT_CNT,
EGPI1_BASE + GPI_CSR_GPI_TX2_IN_PKT_CNT,
EGPI1_BASE + GPI_CSR_GPI_TX2_OUT_PKT_CNT,
EGPI1_BASE + GPI_CSR_GPI_RX3_IN_PKT_CNT,
EGPI1_BASE + GPI_CSR_GPI_RX3_OUT_PKT_CNT,
EGPI1_BASE + GPI_CSR_GPI_TX3_IN_PKT_CNT,
EGPI1_BASE + GPI_CSR_GPI_TX3_OUT_PKT_CNT,

EGPI2_BASE + GPI_CSR_GPI_RX0_IN_PKT_CNT,
EGPI2_BASE + GPI_CSR_GPI_RX0_OUT_PKT_CNT,
EGPI2_BASE + GPI_CSR_GPI_TX0_IN_PKT_CNT,
EGPI2_BASE + GPI_CSR_GPI_TX0_OUT_PKT_CNT,
EGPI2_BASE + GPI_CSR_GPI_RX1_IN_PKT_CNT,
EGPI2_BASE + GPI_CSR_GPI_RX1_OUT_PKT_CNT,
EGPI2_BASE + GPI_CSR_GPI_TX1_IN_PKT_CNT,
EGPI2_BASE + GPI_CSR_GPI_TX1_OUT_PKT_CNT,
EGPI2_BASE + GPI_CSR_GPI_RX2_IN_PKT_CNT,
EGPI2_BASE + GPI_CSR_GPI_RX2_OUT_PKT_CNT,
EGPI2_BASE + GPI_CSR_GPI_TX2_IN_PKT_CNT,
EGPI2_BASE + GPI_CSR_GPI_TX2_OUT_PKT_CNT,
EGPI2_BASE + GPI_CSR_GPI_RX3_IN_PKT_CNT,
EGPI2_BASE + GPI_CSR_GPI_RX3_OUT_PKT_CNT,
EGPI2_BASE + GPI_CSR_GPI_TX3_IN_PKT_CNT,
EGPI2_BASE + GPI_CSR_GPI_TX3_OUT_PKT_CNT,

EGPI3_BASE + GPI_CSR_GPI_RX0_IN_PKT_CNT,
EGPI3_BASE + GPI_CSR_GPI_RX0_OUT_PKT_CNT,
EGPI3_BASE + GPI_CSR_GPI_TX0_IN_PKT_CNT,
EGPI3_BASE + GPI_CSR_GPI_TX0_OUT_PKT_CNT,
EGPI3_BASE + GPI_CSR_GPI_RX1_IN_PKT_CNT,
EGPI3_BASE + GPI_CSR_GPI_RX1_OUT_PKT_CNT,
EGPI3_BASE + GPI_CSR_GPI_TX1_IN_PKT_CNT,
EGPI3_BASE + GPI_CSR_GPI_TX1_OUT_PKT_CNT,
EGPI3_BASE + GPI_CSR_GPI_RX2_IN_PKT_CNT,
EGPI3_BASE + GPI_CSR_GPI_RX2_OUT_PKT_CNT,
EGPI3_BASE + GPI_CSR_GPI_TX2_IN_PKT_CNT,
EGPI3_BASE + GPI_CSR_GPI_TX2_OUT_PKT_CNT,
EGPI3_BASE + GPI_CSR_GPI_RX3_IN_PKT_CNT,
EGPI3_BASE + GPI_CSR_GPI_RX3_OUT_PKT_CNT,
EGPI3_BASE + GPI_CSR_GPI_TX3_IN_PKT_CNT,
EGPI3_BASE + GPI_CSR_GPI_TX3_OUT_PKT_CNT
};

uint32a cnt_reg_value[66] = {0, };
void diff_cnt_reg(int8 ino)
{
	uint32a value[66];
	uint32a i;

	if(ino == 0)
	{
		cnt_reg_value[0] = RegRead(HIF_TX_PKT_CNT1);
		cnt_reg_value[1] = RegRead(HIF_TX_PKT_CNT2);

		cnt_reg_value[2] = RegRead(HGPI_BASE + GPI_CSR_GPI_RX0_IN_PKT_CNT);
		cnt_reg_value[3] = RegRead(HGPI_BASE + GPI_CSR_GPI_RX0_OUT_PKT_CNT);
		cnt_reg_value[4] = RegRead(HGPI_BASE + GPI_CSR_GPI_TX0_IN_PKT_CNT);
		cnt_reg_value[5] = RegRead(HGPI_BASE + GPI_CSR_GPI_TX0_OUT_PKT_CNT);

		cnt_reg_value[6] = RegRead(CLASS_PHY1_RX_PKTS_ADDR);
		cnt_reg_value[7] = RegRead(HGPI_BASE + 0x600 + CLASS_HW_CSR_CLASS_PHY1_RX_PKTS);

		cnt_reg_value[8] = RegRead(TMU_PHY_INQ_INPKT_CNT_ADDR);						// TLITE1
		cnt_reg_value[9] = RegRead(TLITE2_BASE + TLITE_CSR_TMU_PHY_INQ_INPKT_CNT);	// TLITE2
		cnt_reg_value[10] = RegRead(TLITE3_BASE + TLITE_CSR_TMU_PHY_INQ_INPKT_CNT);	// TLITE3
		cnt_reg_value[11] = RegRead(TLITE5_BASE + TLITE_CSR_TMU_PHY_INQ_INPKT_CNT);	// TLITE5
		cnt_reg_value[12] = RegRead(TLITE6_BASE + TLITE_CSR_TMU_PHY_INQ_INPKT_CNT);	// TLITE6

		cnt_reg_value[13] = RegRead(TMU_PHY_OUTPKT_CNT_ADDR);						// TLITE1
		cnt_reg_value[14] = RegRead(TLITE2_BASE + TLITE_CSR_TMU_PHY_OUTPKT_CNT);		// TLITE2
		cnt_reg_value[15] = RegRead(TLITE3_BASE + TLITE_CSR_TMU_PHY_OUTPKT_CNT);		// TLITE3
		cnt_reg_value[16] = RegRead(TLITE5_BASE + TLITE_CSR_TMU_PHY_OUTPKT_CNT);		// TLITE5
		cnt_reg_value[17] = RegRead(TLITE6_BASE + TLITE_CSR_TMU_PHY_OUTPKT_CNT);		// TLITE6

		cnt_reg_value[18] = RegRead(EGPI1_BASE + GPI_CSR_GPI_RX0_IN_PKT_CNT);		// EGPI1
		cnt_reg_value[19] = RegRead(EGPI1_BASE + GPI_CSR_GPI_RX0_OUT_PKT_CNT);
		cnt_reg_value[20] = RegRead(EGPI1_BASE + GPI_CSR_GPI_TX0_IN_PKT_CNT);
		cnt_reg_value[21] = RegRead(EGPI1_BASE + GPI_CSR_GPI_TX0_OUT_PKT_CNT);

		cnt_reg_value[22] = RegRead(EGPI1_BASE + GPI_CSR_GPI_RX1_IN_PKT_CNT);
		cnt_reg_value[23] = RegRead(EGPI1_BASE + GPI_CSR_GPI_RX1_OUT_PKT_CNT);
		cnt_reg_value[24] = RegRead(EGPI1_BASE + GPI_CSR_GPI_TX1_IN_PKT_CNT);
		cnt_reg_value[25] = RegRead(EGPI1_BASE + GPI_CSR_GPI_TX1_OUT_PKT_CNT);

		cnt_reg_value[26] = RegRead(EGPI1_BASE + GPI_CSR_GPI_RX2_IN_PKT_CNT);
		cnt_reg_value[27] = RegRead(EGPI1_BASE + GPI_CSR_GPI_RX2_OUT_PKT_CNT);
		cnt_reg_value[28] = RegRead(EGPI1_BASE + GPI_CSR_GPI_TX2_IN_PKT_CNT);
		cnt_reg_value[29] = RegRead(EGPI1_BASE + GPI_CSR_GPI_TX2_OUT_PKT_CNT);

		cnt_reg_value[30] = RegRead(EGPI1_BASE + GPI_CSR_GPI_RX3_IN_PKT_CNT);
		cnt_reg_value[31] = RegRead(EGPI1_BASE + GPI_CSR_GPI_RX3_OUT_PKT_CNT);
		cnt_reg_value[32] = RegRead(EGPI1_BASE + GPI_CSR_GPI_TX3_IN_PKT_CNT);
		cnt_reg_value[33] = RegRead(EGPI1_BASE + GPI_CSR_GPI_TX3_OUT_PKT_CNT);


		cnt_reg_value[34] = RegRead(EGPI2_BASE + GPI_CSR_GPI_RX0_IN_PKT_CNT);		// EGPI2
		cnt_reg_value[35] = RegRead(EGPI2_BASE + GPI_CSR_GPI_RX0_OUT_PKT_CNT);
		cnt_reg_value[36] = RegRead(EGPI2_BASE + GPI_CSR_GPI_TX0_IN_PKT_CNT);
		cnt_reg_value[37] = RegRead(EGPI2_BASE + GPI_CSR_GPI_TX0_OUT_PKT_CNT);

		cnt_reg_value[38] = RegRead(EGPI2_BASE + GPI_CSR_GPI_RX1_IN_PKT_CNT);
		cnt_reg_value[39] = RegRead(EGPI2_BASE + GPI_CSR_GPI_RX1_OUT_PKT_CNT);
		cnt_reg_value[40] = RegRead(EGPI2_BASE + GPI_CSR_GPI_TX1_IN_PKT_CNT);
		cnt_reg_value[41] = RegRead(EGPI2_BASE + GPI_CSR_GPI_TX1_OUT_PKT_CNT);

		cnt_reg_value[42] = RegRead(EGPI2_BASE + GPI_CSR_GPI_RX2_IN_PKT_CNT);
		cnt_reg_value[43] = RegRead(EGPI2_BASE + GPI_CSR_GPI_RX2_OUT_PKT_CNT);
		cnt_reg_value[44] = RegRead(EGPI2_BASE + GPI_CSR_GPI_TX2_IN_PKT_CNT);
		cnt_reg_value[45] = RegRead(EGPI2_BASE + GPI_CSR_GPI_TX2_OUT_PKT_CNT);

		cnt_reg_value[46] = RegRead(EGPI2_BASE + GPI_CSR_GPI_RX3_IN_PKT_CNT);
		cnt_reg_value[47] = RegRead(EGPI2_BASE + GPI_CSR_GPI_RX3_OUT_PKT_CNT);
		cnt_reg_value[48] = RegRead(EGPI2_BASE + GPI_CSR_GPI_TX3_IN_PKT_CNT);
		cnt_reg_value[49] = RegRead(EGPI2_BASE + GPI_CSR_GPI_TX3_OUT_PKT_CNT);


		cnt_reg_value[50] = RegRead(EGPI3_BASE + GPI_CSR_GPI_RX0_IN_PKT_CNT);		// EGPI3
		cnt_reg_value[51] = RegRead(EGPI3_BASE + GPI_CSR_GPI_RX0_OUT_PKT_CNT);
		cnt_reg_value[52] = RegRead(EGPI3_BASE + GPI_CSR_GPI_TX0_IN_PKT_CNT);
		cnt_reg_value[53] = RegRead(EGPI3_BASE + GPI_CSR_GPI_TX0_OUT_PKT_CNT);

		cnt_reg_value[54] = RegRead(EGPI3_BASE + GPI_CSR_GPI_RX1_IN_PKT_CNT);
		cnt_reg_value[55] = RegRead(EGPI3_BASE + GPI_CSR_GPI_RX1_OUT_PKT_CNT);
		cnt_reg_value[56] = RegRead(EGPI3_BASE + GPI_CSR_GPI_TX1_IN_PKT_CNT);
		cnt_reg_value[57] = RegRead(EGPI3_BASE + GPI_CSR_GPI_TX1_OUT_PKT_CNT);

		cnt_reg_value[58] = RegRead(EGPI3_BASE + GPI_CSR_GPI_RX2_IN_PKT_CNT);
		cnt_reg_value[59] = RegRead(EGPI3_BASE + GPI_CSR_GPI_RX2_OUT_PKT_CNT);
		cnt_reg_value[60] = RegRead(EGPI3_BASE + GPI_CSR_GPI_TX2_IN_PKT_CNT);
		cnt_reg_value[61] = RegRead(EGPI3_BASE + GPI_CSR_GPI_TX2_OUT_PKT_CNT);

		cnt_reg_value[62] = RegRead(EGPI3_BASE + GPI_CSR_GPI_RX3_IN_PKT_CNT);
		cnt_reg_value[63] = RegRead(EGPI3_BASE + GPI_CSR_GPI_RX3_OUT_PKT_CNT);
		cnt_reg_value[64] = RegRead(EGPI3_BASE + GPI_CSR_GPI_TX3_IN_PKT_CNT);
		cnt_reg_value[65] = RegRead(EGPI3_BASE + GPI_CSR_GPI_TX3_OUT_PKT_CNT);
	}
	else
	{
		value[0] = RegRead(HIF_TX_PKT_CNT1);
		value[1] = RegRead(HIF_TX_PKT_CNT2);

		value[2] = RegRead(HGPI_BASE + GPI_CSR_GPI_RX0_IN_PKT_CNT);
		value[3] = RegRead(HGPI_BASE + GPI_CSR_GPI_RX0_OUT_PKT_CNT);
		value[4] = RegRead(HGPI_BASE + GPI_CSR_GPI_TX0_IN_PKT_CNT);
		value[5] = RegRead(HGPI_BASE + GPI_CSR_GPI_TX0_OUT_PKT_CNT);

		value[6] = RegRead(CLASS_PHY1_RX_PKTS_ADDR);
		value[7] = RegRead(0x00600600 + CLASS_HW_CSR_CLASS_PHY1_RX_PKTS);

		value[8] = RegRead(TMU_PHY_INQ_INPKT_CNT_ADDR);						// TLITE1
		value[9] = RegRead(TLITE2_BASE + TLITE_CSR_TMU_PHY_INQ_INPKT_CNT);	// TLITE2
		value[10] = RegRead(TLITE3_BASE + TLITE_CSR_TMU_PHY_INQ_INPKT_CNT);	// TLITE3
		value[11] = RegRead(TLITE5_BASE + TLITE_CSR_TMU_PHY_INQ_INPKT_CNT);	// TLITE5
		value[12] = RegRead(TLITE6_BASE + TLITE_CSR_TMU_PHY_INQ_INPKT_CNT);	// TLITE6

		value[13] = RegRead(TMU_PHY_OUTPKT_CNT_ADDR);						// TLITE1
		value[14] = RegRead(TLITE2_BASE + TLITE_CSR_TMU_PHY_OUTPKT_CNT);		// TLITE2
		value[15] = RegRead(TLITE3_BASE + TLITE_CSR_TMU_PHY_OUTPKT_CNT);		// TLITE3
		value[16] = RegRead(TLITE5_BASE + TLITE_CSR_TMU_PHY_OUTPKT_CNT);		// TLITE5
		value[17] = RegRead(TLITE6_BASE + TLITE_CSR_TMU_PHY_OUTPKT_CNT);		// TLITE6


		value[18] = RegRead(EGPI1_BASE + GPI_CSR_GPI_RX0_IN_PKT_CNT);		// EGPI1
		value[19] = RegRead(EGPI1_BASE + GPI_CSR_GPI_RX0_OUT_PKT_CNT);
		value[20] = RegRead(EGPI1_BASE + GPI_CSR_GPI_TX0_IN_PKT_CNT);
		value[21] = RegRead(EGPI1_BASE + GPI_CSR_GPI_TX0_OUT_PKT_CNT);

		value[22] = RegRead(EGPI1_BASE + GPI_CSR_GPI_RX1_IN_PKT_CNT);
		value[23] = RegRead(EGPI1_BASE + GPI_CSR_GPI_RX1_OUT_PKT_CNT);
		value[24] = RegRead(EGPI1_BASE + GPI_CSR_GPI_TX1_IN_PKT_CNT);
		value[25] = RegRead(EGPI1_BASE + GPI_CSR_GPI_TX1_OUT_PKT_CNT);

		value[26] = RegRead(EGPI1_BASE + GPI_CSR_GPI_RX2_IN_PKT_CNT);
		value[27] = RegRead(EGPI1_BASE + GPI_CSR_GPI_RX2_OUT_PKT_CNT);
		value[28] = RegRead(EGPI1_BASE + GPI_CSR_GPI_TX2_IN_PKT_CNT);
		value[29] = RegRead(EGPI1_BASE + GPI_CSR_GPI_TX2_OUT_PKT_CNT);

		value[30] = RegRead(EGPI1_BASE + GPI_CSR_GPI_RX3_IN_PKT_CNT);
		value[31] = RegRead(EGPI1_BASE + GPI_CSR_GPI_RX3_OUT_PKT_CNT);
		value[32] = RegRead(EGPI1_BASE + GPI_CSR_GPI_TX3_IN_PKT_CNT);
		value[33] = RegRead(EGPI1_BASE + GPI_CSR_GPI_TX3_OUT_PKT_CNT);


		value[34] = RegRead(EGPI2_BASE + GPI_CSR_GPI_RX0_IN_PKT_CNT);		// EGPI2
		value[35] = RegRead(EGPI2_BASE + GPI_CSR_GPI_RX0_OUT_PKT_CNT);
		value[36] = RegRead(EGPI2_BASE + GPI_CSR_GPI_TX0_IN_PKT_CNT);
		value[37] = RegRead(EGPI2_BASE + GPI_CSR_GPI_TX0_OUT_PKT_CNT);

		value[38] = RegRead(EGPI2_BASE + GPI_CSR_GPI_RX1_IN_PKT_CNT);
		value[39] = RegRead(EGPI2_BASE + GPI_CSR_GPI_RX1_OUT_PKT_CNT);
		value[40] = RegRead(EGPI2_BASE + GPI_CSR_GPI_TX1_IN_PKT_CNT);
		value[41] = RegRead(EGPI2_BASE + GPI_CSR_GPI_TX1_OUT_PKT_CNT);

		value[42] = RegRead(EGPI2_BASE + GPI_CSR_GPI_RX2_IN_PKT_CNT);
		value[43] = RegRead(EGPI2_BASE + GPI_CSR_GPI_RX2_OUT_PKT_CNT);
		value[44] = RegRead(EGPI2_BASE + GPI_CSR_GPI_TX2_IN_PKT_CNT);
		value[45] = RegRead(EGPI2_BASE + GPI_CSR_GPI_TX2_OUT_PKT_CNT);

		value[46] = RegRead(EGPI2_BASE + GPI_CSR_GPI_RX3_IN_PKT_CNT);
		value[47] = RegRead(EGPI2_BASE + GPI_CSR_GPI_RX3_OUT_PKT_CNT);
		value[48] = RegRead(EGPI2_BASE + GPI_CSR_GPI_TX3_IN_PKT_CNT);
		value[49] = RegRead(EGPI2_BASE + GPI_CSR_GPI_TX3_OUT_PKT_CNT);


		value[50] = RegRead(EGPI3_BASE + GPI_CSR_GPI_RX0_IN_PKT_CNT);		// EGPI3
		value[51] = RegRead(EGPI3_BASE + GPI_CSR_GPI_RX0_OUT_PKT_CNT);
		value[52] = RegRead(EGPI3_BASE + GPI_CSR_GPI_TX0_IN_PKT_CNT);
		value[53] = RegRead(EGPI3_BASE + GPI_CSR_GPI_TX0_OUT_PKT_CNT);

		value[54] = RegRead(EGPI3_BASE + GPI_CSR_GPI_RX1_IN_PKT_CNT);
		value[55] = RegRead(EGPI3_BASE + GPI_CSR_GPI_RX1_OUT_PKT_CNT);
		value[56] = RegRead(EGPI3_BASE + GPI_CSR_GPI_TX1_IN_PKT_CNT);
		value[57] = RegRead(EGPI3_BASE + GPI_CSR_GPI_TX1_OUT_PKT_CNT);

		value[58] = RegRead(EGPI3_BASE + GPI_CSR_GPI_RX2_IN_PKT_CNT);
		value[59] = RegRead(EGPI3_BASE + GPI_CSR_GPI_RX2_OUT_PKT_CNT);
		value[60] = RegRead(EGPI3_BASE + GPI_CSR_GPI_TX2_IN_PKT_CNT);
		value[61] = RegRead(EGPI3_BASE + GPI_CSR_GPI_TX2_OUT_PKT_CNT);

		value[62] = RegRead(EGPI3_BASE + GPI_CSR_GPI_RX3_IN_PKT_CNT);
		value[63] = RegRead(EGPI3_BASE + GPI_CSR_GPI_RX3_OUT_PKT_CNT);
		value[64] = RegRead(EGPI3_BASE + GPI_CSR_GPI_TX3_IN_PKT_CNT);
		value[65] = RegRead(EGPI3_BASE + GPI_CSR_GPI_TX3_OUT_PKT_CNT);

		printk("================== different count register ==================\n");
		for(i=0;i<66;i++)
		{
			if(cnt_reg_value[i] != value[i])
			{
				printk("addr[%08lx] value BEF[%08X] / AFT[%08X]\n", g_reg[i], cnt_reg_value[i], value[i]);
			}
		}
	}
}

void dump_mem(uint8* addr, uint32a size)
{
	uint32a align_size;
	uint32 offset;
	uint32a *uiaddr = (uint32a*)addr + 0x00;

	addr = (uint8*)((uint64)addr & (~0xF));
	align_size = (size>>4)<<4;

	for(offset=0; offset<align_size; offset+=0x10)
	{
		uiaddr = (uint32a*)(addr + offset);
 		printk("addr %px value %08x %08x %08x %08x\n", uiaddr, uiaddr[0], uiaddr[1], uiaddr[2], uiaddr[3]);
	}
}

void dump_byte(uint8* addr, uint32a size)
{
	uint32 offset;
	uint8 *ucaddr;

	for(offset=0; offset<size; offset+=0x10)
	{
		ucaddr = addr + offset;
 		printk("addr %px byte %02x%02x%02x%02x %02x%02x%02x%02x %02x%02x%02x%02x %02x%02x%02x%02x\n", ucaddr, ucaddr[0], ucaddr[1], ucaddr[2], ucaddr[3]
 		, ucaddr[4], ucaddr[5], ucaddr[6], ucaddr[7]
 		, ucaddr[8], ucaddr[9], ucaddr[10], ucaddr[11]
 		, ucaddr[12], ucaddr[13], ucaddr[14], ucaddr[15]);
	}
}

#if 1 /* Interrupt polling with org hif handler */
struct task_struct *k_thread = NULL;

int32a fp_interrupt_polling(void *data)
{
	struct fp_private *fp = (struct fp_private *)data;
	struct hif_base *hif = &fp->hif[0];
	volatile struct hif_regs *regs = hif->regs;
	uint32a hif_index = 0;
	uint32a hif_int_src = RegRead((uint32)&regs->hif_int_src);

	printk("[%s] start\n", __func__);

	while(!kthread_should_stop())
	{
		hif_int_src = RegRead((uint32)&regs->hif_int_src);
		if(hif_int_src)
		{
			/* Handle hif interrupt, if interrupt source is set */
			for (hif_index = 0; hif_index < NUM_TOTAL_HIF; hif_index++)
			{
				handle_hif(&fp->hif[hif_index]);
			}
		}

		if (signal_pending(k_thread))
		{
			break;
		}
		msleep_interruptible(50);
	}
	return 0;
}

int32a create_thread(void *data)
{

	k_thread = kthread_create(fp_interrupt_polling, data, "fp_tx_polling");
	if(IS_ERR(k_thread))
	{
		printk("!!!!!!!!!!error create thread\n");
		kfree(k_thread);
		k_thread = NULL;

		return -ENOMEM;
	}
	else
	{
		printk("!!!!!!!!!!success create thread\n");

		wake_up_process(k_thread);
	}

	return 0;
}
#else
int32a fp_tx_polling(void *data)
{
	struct fp_private *fp = (struct fp_private *)data;
	struct bd_ring *txring;
	struct bd *txbd;
	uint32a wb_buflen = 0;
	uint32a hif_index = 0;
	uint32a ch_index = 0;
	uint32a ireg;
	int32a iflag = 0;
	uint32a fpga_int_src = 0;
	struct netdev_queue *queue = netdev_get_tx_queue(fp->dev, ch_index);

	printk("********************************** fp_tx_polling: hif_index %u ch_index %d\n", hif_index, ch_index);

	/* hif_index = 0; ch_index = 0; */
	txring = fp->hif[hif_index].ch[ch_index].txring;
	if (txring == NULL) {
		printk("%s: null txring ptr\n", __func__);
		return -1;
	}

	while (1) {
		spin_lock_bh(&fp->lock);

		ireg = RegRead(HIF_INT_SRC);
		if(ireg & 0x01)
		{
			ireg = RegRead(HIF_CH0_INT_SRC);
			if(ireg & 0x10)
			{
				printk("@");

				fpga_int_src = RegRead(0xE00004);
				printk("===== [%s] FPGA INT status A[0x%x]\n", __func__, fpga_int_src);


				/* Process tx write back bds upon tx interrupt */
				txbd = fp_deque_bd(txring, &wb_buflen);

#if 0
				if (txbd == NULL) {
					printk("TX wb bd not ready\n");
				}

				RegWrite(HIF_CH0_INT_SRC, HIF_CH_INT_EN | HIF_CH_RXPKT_INT_EN | HIF_CH_TXPKT_INT_EN);
				RegWrite(HIF_CH0_INT_EN, HIF_CH_INT_EN | HIF_CH_RXPKT_INT_EN | HIF_CH_TXPKT_INT_EN);
#else
				if (txbd == NULL) {
					printk("TX wb bd not ready\n");

//					iflag = 1;

	//				RegWrite(HIF_CH0_INT_SRC, HIF_CH_INT_EN | HIF_CH_RXPKT_INT_EN | HIF_CH_TXPKT_INT_EN);
	//				RegWrite(HIF_CH0_INT_EN, HIF_CH_INT_EN | HIF_CH_RXPKT_INT_EN | HIF_CH_TXPKT_INT_EN);
				}
				else
				{
					printk("+");
					if(netif_tx_queue_stopped(queue))
					{
						netif_tx_wake_queue(queue);
						printk("~");
					}
				}
#endif

				iflag = 1;

				printk("#");
			}
		}

		if(iflag == 1)
		{
			RegWrite(HIF_CH0_INT_SRC, HIF_CH_INT_EN | HIF_CH_RXPKT_INT_EN | HIF_CH_TXPKT_INT_EN);
			printk("!");
			RegWrite(HIF_CH0_INT_EN, HIF_CH_INT_EN | HIF_CH_RXPKT_INT_EN | HIF_CH_TXPKT_INT_EN);

			iflag = 0;
		}

		if(fpga_int_src)
		{
			RegWrite(0xE00004, 0x000fffff);

			fpga_int_src = RegRead(0xE00004);
			printk("===== [%s] FPGA INT status B[0x%x]\n", __func__, fpga_int_src);

			fpga_int_src = 0;
		}

		spin_unlock_bh(&fp->lock);

		msleep(10);
	}

	return 0;
}

int32a fp_rx_polling(void *data)
{
	struct fp_private *fp = (struct fp_private *)data;
	struct bd_ring *rxring;
	struct bd *rxbd;
	struct sk_buff *skb;
	uint8 *ptr;
	uint32a len = 0;
	uint32a curr_bd_index = 0;
	uint32a rx_ctrl = 0;
	uint32a wb_buflen = 0;
	uint32a hif_index = 0;
	uint32a ch_index = 0;
	int32a ret = 0;
	int32a iflag = 0;
	static uint32a rx_count;
	volatile struct hif_regs *regs = fp->hif[hif_index].regs;
	uint32a ireg;


	printk("********************************** fp_rx_polling: hif_index %u ch_index %d\n", hif_index, ch_index);

	rxring = fp->hif[hif_index].ch[ch_index].rxring;
	if (rxring == NULL) {
		FP_DEBUG(DBGP_FEAT_ERR, FP_LOG_EMERG, "%s: null rxring ptr\n", __func__);
		return -1;
	}

	while (1) {
		spin_lock_bh(&fp->rx_lock);

		ireg = RegRead(HIF_INT_SRC);

		if(ireg & 0x01)
		{
			ireg = RegRead(HIF_CH0_INT_SRC);
			if(ireg & 0x04)
			{
				printk("Z1");
				rxbd = fp_deque_bd(rxring, &wb_buflen);
				if (rxbd == NULL) {
		//			FP_DEBUG(DBGP_FEAT_ERR, FP_LOG_EMERG, "RX wb bd not ready\n");
		//			break;
//					iflag = 1;
				}
				else
				{
					FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO, "RX Count: %u\n", ++rx_count);
					/* allocate memory for sk_buff */
					skb = netdev_alloc_skb(fp->dev, MAX_FRAME_SIZE);
					if (skb == NULL) {
						FP_DEBUG(DBGP_FEAT_ERR, FP_LOG_EMERG, "Out of memory allocating skb TX buffer\n");
		//				break;
//						iflag = 1;
					}
					else
					{
						/* Get the curr rx bd buf length */
						len = wb_buflen;
						wb_buflen = 0;
						/* Get the curr rx bd index */
						curr_bd_index = fp_get_curr_bd_index(rxring, rxbd);
						/* Get the virtual address of the frame */
						ptr = (uint8 *)((uint32)rxring->bd_buff_va + (curr_bd_index * MAX_FRAME_SIZE));
						FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO, "LEN: %u index %d rxbd %p rx_buf_ptr %p\n",
								len, curr_bd_index, rxbd, ptr);
						/* Fetching more will not hurt */
						memcpy(skb->data, ptr, len);
						skb_put(skb, len);
						skb->dev = fp->dev;
						fp->netstats.rx_bytes += skb->len;


						fp_process_rx_header(skb);


						fp->netstats.rx_packets++;
						/* Enable per packet receive interrupt */
						rxbd->bd_ctrl = 0;
						rxbd->bd_buflen = MAX_FRAME_SIZE;
						rxbd->bd_ctrl = BD_CTRL_PKT_INT_EN | BD_CTRL_CBD_INT_EN | BD_CTRL_DIR;
						/* enqueue the above rx free bd to hardware freebd list*/
						ret = fp_enque_bd(rxring, rxbd);
						if (ret < 0) {
							FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_EMERG, "rx bd not avail this should never happen\n");
		//					break;
//							iflag = 1;
						}
					}
				}

				iflag = 1;
			}
		}

		if(iflag == 1)
		{
			/* init the DMA */
			rx_ctrl = RegRead((uint32)&regs->ch[ch_index].hif_ctrl_ch);
			rx_ctrl |= HIF_CH_RX_CTRL_DMA_EN;
			RegWrite((uint32)&regs->ch[ch_index].hif_ctrl_ch, rx_ctrl);
			rx_ctrl = RegRead((uint32)&regs->ch[ch_index].hif_rx_ch_start);
			rx_ctrl |= HIF_CH_RX_START;
			RegWrite((uint32)&regs->ch[ch_index].hif_rx_ch_start, rx_ctrl);
			/* Re-Enable interrupts */
//			RegWrite((uint32)&regs->ch[ch_index].hif_ch_int_en, HIF_CH_INT_EN | HIF_CH_RXPKT_INT_EN | HIF_CH_TXPKT_INT_EN);

			RegWrite(HIF_CH0_INT_SRC, HIF_CH_INT_EN | HIF_CH_RXPKT_INT_EN | HIF_CH_TXPKT_INT_EN);
			printk("=");
			RegWrite(HIF_CH0_INT_EN, HIF_CH_INT_EN | HIF_CH_RXPKT_INT_EN | HIF_CH_TXPKT_INT_EN);

			iflag = 0;
		}

		spin_unlock_bh(&fp->rx_lock);

		msleep(10);
	} /* End of while */

	return 0;
}

int32a create_thread(struct fp_private *fp)
{
	struct task_struct *txk_thread = NULL;
	struct task_struct *rxk_thread = NULL;

	txk_thread = kthread_create(fp_tx_polling, fp, "fp_tx_polling");
	if(IS_ERR(txk_thread))
	{
		printk("!!!!!!!!!!error create TX thread\n");
		kfree(txk_thread);
		txk_thread = NULL;

		return -ENOMEM;
	}
	else
	{
		printk("!!!!!!!!!!success create TX thread\n");

		wake_up_process(txk_thread);
	}

#if 1
	rxk_thread = kthread_create(fp_rx_polling, fp, "fp_rx_polling");
	if(IS_ERR(rxk_thread))
	{
		printk("!!!!!!!!!!error create RX thread\n");
		kfree(rxk_thread);
		rxk_thread = NULL;

		return -ENOMEM;
	}
	else
	{
		printk("!!!!!!!!!!success create RX thread\n");

		wake_up_process(rxk_thread);
	}
#endif

	return 0;
}
#endif
