// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_host_shim_entry.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    entry point for shim layer functionalites
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                      Include Files
 **********************************************************************/
#include "fp_library.h"		// brings in  "linux/kernel.h" --
#include "fp_ether.h"
#include "hw_2field_hash_table.h"
#include "fp_pre_header.h"
#include "fp_os_shim.h"

/**********************************************************************
 *                              Extern Declarations
**********************************************************************/

/*********************************************************************
 * Function Name  : fp_do_packet_parsing
 * Description    : update layer2, layer3 header pointers
 * Inputs         :
 * Parameters     : uint8 *, pktHdrs_t *
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_do_packet_parsing(uint8 *data, pktHdrs_t *pktHdr)
{
	uint16 eth_type = 0, length = ETH_SMAC_DMAC_SIZE;
	struct ethhdr *eth_hdr = NULL;
	vlanEthhdr_t *vlanEthHdr;

	/* initilize starting layer of data pointer to packet header data */
	pktHdr->data = data;
	/* do packet parsing & initilize corresponig header pointer fields */
	pktHdr->pLayer2Hdr = data;
	eth_hdr = (struct ethhdr *)pktHdr->pLayer2Hdr;
	eth_type = ntohs(eth_hdr->h_proto);
	/*Update layer-3 header pointers by looping the ether type*/
	while (1) {
		FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO, "IN WHILE LOOP\n");
		/*Ether net type ipv4*/
		if (eth_type == PROTOCOL_IP) {
			/*
			* set packet type as IP in the pktHdr and get the next
			* protocol and return
			*/
			/* adjust length for IP header */
			length = length + ETH_PROTO_SIZE;
			/* extract the layer-3 header pointer
						from pktbuf for ipv4 */
			pktHdr->pLayer3Hdr = pktHdr->pLayer2Hdr + length;
			return 0;
		} else if (eth_type == PROTOCOL_IPV6) {
			/*
			* set packet type as IPV6 in the pktbuf and get the next
			* protocol and return
			*/
			/* adjust length for IP header */
			length = length + ETH_PROTO_SIZE;
			/* extract the layer-3 header pointer
						from pktbuf for ipv6 */
			pktHdr->pLayer3Hdr = pktHdr->pLayer2Hdr + length;
			return 0;
		} else if (eth_type == PROTOCOL_ARP) {
			/*
			* set packet type as ARP in the pktbuf and get the next
			* protocol and return
			*/
			return 0;
		} else if (eth_type == PROTOCOL_VLAN) {
			/*set packet type as VLAN in the pktbuf and get the next
			* protocol and continue*/
			vlanEthHdr = (vlanEthhdr_t *)(pktHdr->pLayer2Hdr);
			pktHdr->vlanid =
				ntohs(vlanEthHdr->h_vlan_TCI) & 0xFFF;
			/* adjust VLAN header length */
			length = length + VLAN_HDR_SIZE;
			eth_type = *(uint16 *)(pktHdr->pLayer2Hdr + length);
			eth_type = ntohs(eth_type);
		} else {
			/* need to handle remaining protocols like PPPoE, PTP, etc */
			break;
		}
	}
	return -1;
}

/******************************************************************
 * Function Name  : wsp_switch_learn
 * Description    : lookup on Dest Mac, search fails
 *                  learn dest mac into Hash Mac Table
 * Inputs         :
 * Parameters     : pktBuf_t *
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_host_shim_entry(uint8 *data, uint32a data_len, struct rx_header *rxhdr)
{
	pktHdrs_t pktHdr;
	int32a ret = 0;

	memset(&pktHdr, 0, sizeof(pktHdrs_t));
	/* update rx port num */
	pktHdr.phyno = rxhdr->rxport_num;
	pktHdr.punt_reason = rxhdr->punt_reason;
	if (rxhdr->ctrl & FP_PUNT_VALID) {
		FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO,
			 "%s: rxport num %u\n", __func__, pktHdr.phyno);
		FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO,
			 "BEFORE: punt reason: %x\n", rxhdr->punt_reason);
	}
	/* do packet parsing */
	ret = fp_do_packet_parsing(data, &pktHdr);
	if (rxhdr->ctrl & FP_PUNT_VALID) {
		FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO,
			"AFTER: punt reason: %x\n", rxhdr->punt_reason);
	}
	/* do reason code handling based on punt reason code */
#ifdef ENABLE_LEARNING
	fp_switch_host_rchandler(&pktHdr);
#endif
	return 0;
}

