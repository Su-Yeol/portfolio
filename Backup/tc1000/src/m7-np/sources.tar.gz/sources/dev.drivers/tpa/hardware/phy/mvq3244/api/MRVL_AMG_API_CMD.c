/**
 * @file MRVL_AMG_API_CMD.c
 * @brief Marvell Multi-gig Automotive Ethernet PHY internal source for command and memory accessing
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */

#include "MRVL_AMG_API_CMD.h"
#include "MRVL_AMG_REG_MAIN.h"
#include <string.h>
#include <stddef.h>


/* **************** Command related **************** */

MRVL_APHY_STATUS MRVL_AMG_CMD_IssueCommand(MRVL_DEV_PTR device, void* apCmdDesc, MRVL_APHY_U16 aNumWords)
{
	MRVL_APHY_U32* vpCmdDesc;
	MRVL_APHY_U32 tmp = 0;
	MRVL_APHY_U32 vRegAddr, vData;
	MRVL_APHY_U32 vI;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 start , timed;

	vpCmdDesc = (MRVL_APHY_U32*)apCmdDesc;
	/* Store non-cmd words: */
	for (vI = 1; vI < aNumWords; vI++)
	{
		vRegAddr = MRVL_AMG_CMD_MB_CTRL + vI * (MRVL_APHY_U32)sizeof(MRVL_APHY_U32);
		vData = vpCmdDesc[vI];
		MRVL_AMG_DBG_CMD("MRVL_AMG_FW_issueCommand: Store non-cmd words 0x%x into 0x%x\n", vData, vRegAddr);
		status |= MRVL_AMG_WriteReg32(device, vRegAddr, vData);
	}

	/* Store the Cmd word: */
	MRVL_AMG_DBG_CMD("MRVL_AMG_FW_issueCommand: Store cmd words 0x%x into 0x%x\n", vpCmdDesc[0], MRVL_AMG_CMD_MB_CTRL);
	status |= MRVL_AMG_WriteReg32(device, MRVL_AMG_CMD_MB_CTRL, vpCmdDesc[0]);

	/* Must wait for Mbox to be idle. */
	MRVL_AMG_Clock(&start);

	while (1)
	{
		/* MRVL_AMG_DBG_ALL("waitForMboxIdle...\n"); */
		status |= MRVL_AMG_ReadReg32(device, MRVL_AMG_CMD_MB_CTRL, &tmp);

		if ((tmp & 0x10U) == 0)
		{
			if ((tmp & 0x20U) != 0)
			{
				status |= MRVL_APHY_STATUS_ERROR_GENERAL;
			}
			break;
		}

		MRVL_AMG_Clock(&timed);
		
		if ((timed - start) >= MRVL_AMG_RW_TIMEOUT_MS)
		{
			status |= MRVL_APHY_STATUS_ERROR_TIMEOUT;
			break;
		}
	}

	MRVL_AMG_DBG_CMD("MRVL_AMG_FW_issueCommand: status=%d, aNumWords=%d\n", status, aNumWords);
	return status;
}

MRVL_APHY_STATUS MRVL_AMG_CMD_ExtractFromRegs(MRVL_DEV_PTR device, void* apDestAsWords, MRVL_APHY_U16 aNumRegs, MRVL_APHY_U16 aStartRegSlotNdx, MRVL_APHY_U16 aStartRegSlotNdxForDataPacking) {
	MRVL_APHY_U32* vpDestAsWords;
	MRVL_APHY_U32 vFirstHalfWordWhenPacking;
	MRVL_APHY_U32 vData, vRegAddr;
	MRVL_APHY_U16 vI, vWordNdx, vRegNdx;
	MRVL_APHY_BOOL vThisIsSecondHalfWordWhenPacking = MRVL_APHY_FALSE;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;

	vpDestAsWords = (MRVL_APHY_U32*)(apDestAsWords);
	vWordNdx = 0;

	for (vI = 0; vI < aNumRegs; vI++) 
	{
		/* Get data from the register slot: */
		vRegNdx = aStartRegSlotNdx + vI;
		vRegAddr = MRVL_AMG_CMD_MB_CTRL + (MRVL_APHY_U32)(sizeof(MRVL_APHY_U32) * vRegNdx);
		MRVL_AMG_DBG_CMD("MRVL_AMG_FW_extractFromRegs: vRegNdx=%d vWordNdx=%d vRegAddr=0x%x aStartRegSlotNdx=%d aStartRegSlotNdxForDataPacking=%d\n",
			vRegNdx,
			vWordNdx,
			vRegAddr,
			aStartRegSlotNdx,
			aStartRegSlotNdxForDataPacking
		);

		status |= MRVL_AMG_ReadReg32(device, vRegAddr, &vData);
		if (status != MRVL_APHY_STATUS_OK) 
			break;
		vData &= 0xFFFFU;
		if (vRegNdx < aStartRegSlotNdxForDataPacking) {
			/* Not packing. */
			MRVL_AMG_DBG_CMD("MRVL_AMG_FW_extractFromRegs: Store full 32 0x%x into ndx %d of user buffer\n", vData, vWordNdx);
			vpDestAsWords[vWordNdx] = vData;
			vWordNdx++;
		}
		else {
			/* Packing. */
			if (vThisIsSecondHalfWordWhenPacking == MRVL_APHY_FALSE) 
			{
				vFirstHalfWordWhenPacking = vData;
				vThisIsSecondHalfWordWhenPacking = MRVL_APHY_TRUE;
			}
			else 
			{
				/* Merge the two halves: */
				vData = (vData << 16) | vFirstHalfWordWhenPacking;
				/* Store: */
				vpDestAsWords[vWordNdx] = vData;
				vWordNdx++;
				/* Prep for next iteration: */
				vThisIsSecondHalfWordWhenPacking = MRVL_APHY_FALSE;
			}
		}

	}
	return status;
}

MRVL_APHY_STATUS MRVL_AMG_CMD_ExtractRdWrCmdDataWordsFromRegs(MRVL_DEV_PTR device, MRVL_APHY_U32 apDestAsWords[], MRVL_APHY_U16 aNumFullDataWords) 
{
	MRVL_APHY_U16 vActualNumRegsNeeded;
	MRVL_APHY_U16 vRegOffset;
	MRVL_APHY_U32 vRegAddr;
	MRVL_APHY_U32 vFullWord = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;

	vActualNumRegsNeeded = (aNumFullDataWords * 2);
	vRegOffset = (MRVL_APHY_U16)offsetof(MRVL_AMG_CMD_SetRdAddrAndRdWords, mData);
	vRegAddr = MRVL_AMG_CMD_MB_CTRL + (MRVL_APHY_U32)vRegOffset;

	for (unsigned vI = 0; vI < vActualNumRegsNeeded; vI++)
	{
		MRVL_APHY_U32 vHalfWordOrOneHalf;
		status |= MRVL_AMG_ReadReg32(device, vRegAddr, &vHalfWordOrOneHalf);
		if (status != MRVL_APHY_STATUS_OK)
		{
			break;
		} 
			
		vRegAddr += sizeof(MRVL_APHY_U32);

		vHalfWordOrOneHalf &= 0xFFFFU;

		if ((vI & 1U) == 0)
		{
			vFullWord = vHalfWordOrOneHalf & 0xFFFFU;
		}
		else
		{
			vFullWord = ((vHalfWordOrOneHalf & 0xFFFFU) << 16) | vFullWord;
			apDestAsWords[vI / 2] = vFullWord;
			MRVL_AMG_DBG_CMD("MRVL_AMG_FW_extractRdWrCmdDataWordsFromRegs: apDestAsWords=%p value=0x%x\n", &(apDestAsWords[vI / 2]), vFullWord);
		}
	}
	return status;
}

MRVL_APHY_STATUS MRVL_AMG_CMD_ReadWords(MRVL_DEV_PTR device, MRVL_APHY_U32 aCpuAddr, MRVL_APHY_U16 aNumWords, MRVL_APHY_U32 apDest[]) {
	MRVL_APHY_U32 vAddrLo;
	/* MRVL_APHY_U32 vAddrHi; */
	MRVL_APHY_U32* vpDestAsWords = (MRVL_APHY_U32*)apDest;
	MRVL_APHY_U32 vCurrAddr;
	MRVL_APHY_U16 vNumRemainingWords = aNumWords;
	MRVL_APHY_U16 vTotalWordsRead = 0;
	const MRVL_APHY_U16 vMaxDataWordsPerChunk = (MRVL_AMG_CMD_MaxNumDataWords / 2);
	MRVL_APHY_U16 vNumWordsInChunk;
	MRVL_AMG_CMD_SetRdAddrAndRdWords vCmdCtrlStruct;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_ERROR_GENERAL;
	MRVL_APHY_U32 vExpectedNextAddr;
	MRVL_APHY_U32 vActualNextAddr;
	MRVL_APHY_U16 vSizeInWords;

	MRVL_APHY_U16 vSizeOfNeededPortion;
	MRVL_APHY_U16 vNumRegs;
	MRVL_APHY_U16 vStartRegSlotNdx;
	MRVL_APHY_U16 vStartRegSlotNdxForDataPacking; 

	/* It is a 16-bit scratch area. Since this function operates on */
	/* full words, can only use an even number of slots. */

	vAddrLo = aCpuAddr;
	/* vAddrHi = aCpuAddr + aNumWords * 4 - 1; */
	vCurrAddr = vAddrLo;

	memset(&vCmdCtrlStruct, 0, sizeof(vCmdCtrlStruct));

	MRVL_AMG_DBG_CMD("MRVL_AMG_FW_readWords: apDest=%p aCpuAddr=0x%x  aNumWords=%u\n", apDest, aCpuAddr, aNumWords);

	vCmdCtrlStruct.mAddrLo = (vCurrAddr >> 0) & 0xFFFFU;
	vCmdCtrlStruct.mAddrHi = (vCurrAddr >> 16) & 0xFFFFU;
	vCmdCtrlStruct.mSetRdAddrAndRdWordsCmd.mResetCrc = 1;
	vCmdCtrlStruct.mSetRdAddrAndRdWordsCmd.mIncInHash = 0;
	vCmdCtrlStruct.mSetRdAddrAndRdWordsCmd.mPostInc = 1;
	vCmdCtrlStruct.mSetRdAddrAndRdWordsCmd.mCmd = MRVL_AMG_CMD_CODE_SetRdAddrAndRdWords;
	vCmdCtrlStruct.mSetRdAddrAndRdWordsCmd.mExecute = 1;
	vCmdCtrlStruct.mSetRdAddrAndRdWordsCmd.mStatus = 0;


	while (vNumRemainingWords != 0)
	{
		/* How many words to read in this chunk? */
		vNumWordsInChunk = (vNumRemainingWords > vMaxDataWordsPerChunk) ? (vMaxDataWordsPerChunk) : (vNumRemainingWords);
		vCmdCtrlStruct.mSetRdAddrAndRdWordsCmd.mNumWordsMinus1 = vNumWordsInChunk - 1;

		/* Wait for Mbox idle, then issue the command, then wait for completion: */
		/* const unsigned vMboxBusyTimeout_ms = MRVL_AMG_RW_WaitForIdle_MS; */
		/* const unsigned vCommandCompleteTimeout_ms = MRVL_AMG_RW_TIMEOUT_MS; */
		vSizeInWords = (vCmdCtrlStruct.mSetRdAddrAndRdWordsCmd.mCmd == (MRVL_APHY_U32)MRVL_AMG_CMD_CODE_SetRdAddrAndRdWords)
			? (MRVL_APHY_U16)(offsetof(MRVL_AMG_CMD_SetRdAddrAndRdWords, mAddrHi) / sizeof(MRVL_APHY_U32) + 1)                 /* Needs to set address */
			: (MRVL_APHY_U16)(offsetof(MRVL_AMG_CMD_SetRdAddrAndRdWords, mSetRdAddrAndRdWordsCmd) / sizeof(MRVL_APHY_U32) + 1); /* Only needs the command part */
		status = MRVL_AMG_CMD_IssueCommand(device, &vCmdCtrlStruct, vSizeInWords);

		/* Copy the content: */
		status |= MRVL_AMG_CMD_ExtractRdWrCmdDataWordsFromRegs(device, vpDestAsWords, vNumWordsInChunk);
		if (status != MRVL_APHY_STATUS_OK) {
			break;
		}
		/* Accumulate CRC: */
		/* MRVL_APHY_U8* vpBuf = (MRVL_APHY_U8*)vpDestAsWords; */
		/* vCrc16 = calculateCRC16(vpBuf, vNumWordsInChunk * 4); */

		/* Update destination buffer pointer: */
		vpDestAsWords += vNumWordsInChunk;

		/* Prep for next round. */

		/* Update the counts: */
		vNumRemainingWords -= vNumWordsInChunk;
		vTotalWordsRead += vNumWordsInChunk;

		/* In subsequent passes, have these cleared: */
		vCmdCtrlStruct.mSetRdAddrAndRdWordsCmd.mCmd = (MRVL_APHY_U32)MRVL_AMG_CMD_CODE_RdWords;
		vCmdCtrlStruct.mSetRdAddrAndRdWordsCmd.mExecute = 1;
		vCmdCtrlStruct.mSetRdAddrAndRdWordsCmd.mStatus = 0;
		vCmdCtrlStruct.mSetRdAddrAndRdWordsCmd.mResetCrc = 0;
		vCmdCtrlStruct.mSetRdAddrAndRdWordsCmd.mResetSha = 0;
	}

	if (status == MRVL_APHY_STATUS_OK) {
		MRVL_AMG_CMD_SetRdAddrAndRdWords vCmdResponse;
		memset(&vCmdResponse, 0, sizeof(vCmdResponse));
		vSizeOfNeededPortion = (MRVL_APHY_U16)offsetof(MRVL_AMG_CMD_SetRdAddrAndRdWords, mData);
		vNumRegs = vSizeOfNeededPortion / (MRVL_APHY_U16)sizeof(MRVL_APHY_U32);
		vStartRegSlotNdx = 0;
		vStartRegSlotNdxForDataPacking = vStartRegSlotNdx + vNumRegs; /* i.e. no Part 2 (packed) */
		status |= MRVL_AMG_CMD_ExtractFromRegs(device, &vCmdResponse, vNumRegs, vStartRegSlotNdx, vStartRegSlotNdxForDataPacking);
		MRVL_AMG_DBG_CMD("MRVL_AMG_FW_readWords: extractFromRegs() returned %d. ", vCmdResponse);

		if (status == MRVL_APHY_STATUS_OK)
		{
			vExpectedNextAddr = aCpuAddr + aNumWords * sizeof(MRVL_APHY_U32);
			vActualNextAddr = (vCmdResponse.mAddrHi << 16) | vCmdResponse.mAddrLo;

			if (vCmdResponse.mSetRdAddrAndRdWordsCmd.mStatus != 0 || vExpectedNextAddr != vActualNextAddr)
			{
				MRVL_AMG_DBG_ERROR("MRVL_AMG_FW_readWords: Session Integrity error. mStatus=%d NextAddr: Expected=0x%x  Actual=0x%x\n",
					vCmdResponse.mSetRdAddrAndRdWordsCmd.mStatus,
					vExpectedNextAddr,
					vActualNextAddr
				);
				status |= MRVL_APHY_STATUS_ERROR_GENERAL;
			}
		}

	}

	MRVL_AMG_DBG_CMD("MRVL_AMG_FW_resourceReadWords: status=%d vTotalWordsRead=%d\n", status, vTotalWordsRead);
	return status;
}




/* **************** Virture reg access via command mailbox **************** */

MRVL_APHY_STATUS MRVL_AMG_setCommandAndExecute(MRVL_DEV_PTR device, MRVL_APHY_U8 command)
{
	MRVL_APHY_U32 val;
	MRVL_APHY_STATUS status;

	status = MRVL_AMG_ReadReg32(device, HostManagementCtrlScratchpad, &val);
    val = (val & 0xfff0U) | command;
    val = val | 0x10U;
    status |= MRVL_AMG_WriteReg32(device, HostManagementCtrlScratchpad, val);
    return status;
}

MRVL_APHY_BOOL MRVL_AMG_CmdMboxBusy(MRVL_DEV_PTR device)
{
	MRVL_APHY_U32 val;
	MRVL_APHY_BOOL ret;

	if (MRVL_AMG_ReadReg32(device, HostManagementCtrlScratchpad, &val) != MRVL_APHY_STATUS_OK)
	{
		ret = MRVL_APHY_TRUE;
	}
	else
	{
		if (((val >> 4) & 1U) == 1U)
		{
			ret = MRVL_APHY_TRUE;
		}
		else
		{
			ret = MRVL_APHY_FALSE;
		}
	}

    return ret;
}

MRVL_APHY_STATUS MRVL_AMG_waitForServiceModeEnable(MRVL_DEV_PTR device)
{
    MRVL_APHY_STATUS ret = MRVL_APHY_STATUS_OK;
    MRVL_APHY_U32 start, timeout, timed;
    MRVL_APHY_U32 diffTime = 0;
    MRVL_APHY_U32 val;

    ret |= MRVL_AMG_ReadReg32(device, IdStatEnvId, &val);

    if (val == 1)
    {
    	timeout = sWaitTime;
    }
    else
    {
    	timeout = sWaitTime * 10;
    }

    MRVL_AMG_Clock(&start);

	while (diffTime < timeout)
    {
    	if (MRVL_AMG_ReadReg32(device, FwSet0RblProgressBarCurr, &val) != MRVL_APHY_STATUS_OK)
    	{
			ret |= MRVL_APHY_STATUS_ERROR_MDIO;
			break;
    	}

	    if (val & (1U << 19))
        {
            ret |= MRVL_APHY_STATUS_OK;
            break;
        }

        MRVL_AMG_Wait(device, 50);

        MRVL_AMG_Clock(&timed);

        diffTime = timed - start;
    }  

    if (ret != MRVL_APHY_STATUS_OK)
    {
    	MRVL_AMG_DBG_ERROR("Could not enter Service mode.\n");
        ret |= MRVL_APHY_STATUS_ERROR_GENERAL;
    }

    return ret;
}

MRVL_APHY_STATUS MRVL_AMG_enterServiceMode(MRVL_DEV_PTR device)
{
    MRVL_APHY_STATUS ret = MRVL_APHY_STATUS_ERROR_GENERAL;
    MRVL_APHY_STATUS localRet;
    /* MRVL_APHY_U32 rblServiceMode = 1 << 19; */
    MRVL_APHY_U32 val;
    const MRVL_APHY_U32 bootIfMask = 0x3B;
    MRVL_APHY_U32 start, timeout, timed;
    MRVL_APHY_U32 diffTime = 0;

    MRVL_AMG_Clock(&start);
    timeout = 5000;

	while (diffTime < timeout)
    { 
		ret |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0StatusStat1, &val);
		if (val != 0xFFFFFFFF)
		{
			ret = MRVL_APHY_STATUS_OK;
            break;
		}
        ret |= MRVL_AMG_Wait(device, 10);

        MRVL_AMG_Clock(&timed);

        diffTime = timed - start;
    }
    
    
    if (ret != MRVL_APHY_STATUS_OK)
    {
    	MRVL_AMG_DBG_ERROR("Could not initialize device.\n");
    }
    else
    {
	    ret |= MRVL_AMG_WriteReg32(device, HostManagementCtrlScratchpad, 0);
	    ret |= MRVL_AMG_WriteReg32(device, HostManagementCtrlScratchpad + 4, 0);
	    ret |= MRVL_AMG_WriteReg32(device, HostManagementCtrlScratchpad + 8, 0);
	    ret |= MRVL_AMG_WriteReg32(device, HostManagementCtrlScratchpad + 12, 0);
	    ret |= MRVL_AMG_ReadReg32(device, HostManagementCtrlScratchpad, &val);
	    val |= (1U << ServiceModeReqOffset);
	    val |= ((bootIfMask & 0x3FU) << BootIfMaskOffset);
	    ret |= MRVL_AMG_WriteReg32(device, HostManagementCtrlScratchpad, val);

	    ret |= MRVL_AMG_setCommandAndExecute(device, CMD_MB_REBOOT);


	    MRVL_AMG_Clock(&start);
	    diffTime = 0;

	    if (ret == MRVL_APHY_STATUS_OK)
	    {
	    	localRet = MRVL_APHY_STATUS_ERROR_GENERAL;

	    	while (diffTime < timeout)
		    { 
			    if (MRVL_AMG_CmdMboxBusy(device) == MRVL_APHY_FALSE)
		        {
		            localRet = MRVL_APHY_STATUS_OK;
		            break;
		        }
		        MRVL_AMG_Wait(device, 10);
		        MRVL_AMG_Clock(&timed);

		        diffTime = timed - start;
		    }

		    if (localRet != MRVL_APHY_STATUS_OK)
		    {
		    	MRVL_AMG_DBG_ERROR("Command mailbox busy timeout.\n");
		        ret |= MRVL_APHY_STATUS_ERROR_GENERAL;
		    }

		    if (MRVL_AMG_waitForServiceModeEnable(device) != MRVL_APHY_STATUS_OK)
		    {
		    	MRVL_AMG_DBG_ERROR("Could not enable service mode.\n");
		    	ret |= MRVL_APHY_STATUS_ERROR_GENERAL;
		    }
	    }   
	}
    return ret;
}

MRVL_APHY_BOOL MRVL_AMG_isVirtualReg(MRVL_APHY_U32 regaddr)
{
	MRVL_APHY_BOOL ret;

	if (regaddr >= MRVL_AMG_FW_Reg_First && regaddr <= MRVL_AMG_FW_Reg_Last) 
	{
		ret = MRVL_APHY_TRUE;
	}
	else 
	{
		ret = MRVL_APHY_FALSE;
	}

	return ret;
}

MRVL_APHY_STATUS MRVL_AMG_Virtual_getStatus(MRVL_DEV_PTR device) 
{
	MRVL_APHY_U32 regData = 0;
	MRVL_APHY_U8 i = 0;
	const MRVL_APHY_U16 count = 100;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;

	while (i < count)
	{
		status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0CmdMailboxCmdAndStatus, &regData);
		if ((((regData >> cmdmbStatus) & 0x1U) == 0) && (((regData >> cmdmbExecute) & 0x1U) == 0))
		{
			break;
		}

		i++;
		if (MRVL_AMG_Wait(device, 1) != MRVL_APHY_STATUS_OK)
		{
			status |= MRVL_APHY_STATUS_ERROR_GENERAL;
			break;
		}
	}

	if (status != MRVL_APHY_STATUS_OK)
	{
		MRVL_AMG_DBG_ERROR("MRVL_AMG_Virtual_getStatus error: transection timeout\n");
	}
	return status;
}

MRVL_APHY_STATUS MRVL_AMG_Virtual_clearStatus(MRVL_DEV_PTR device) 
{
	MRVL_APHY_U32 regData = 0;
	MRVL_APHY_STATUS status;

	status = MRVL_AMG_ReadReg32(device, FwMmd1eSet0CmdMailboxCmdAndStatus, &regData);
	regData &= ~(1U << cmdmbStatus);
	status |= MRVL_AMG_WriteReg32(device, FwMmd1eSet0CmdMailboxCmdAndStatus, regData);

	return status;
}

MRVL_APHY_STATUS MRVL_AMG_Virtual_readReg32(MRVL_DEV_PTR device, MRVL_APHY_U32 regaddr, MRVL_APHY_U32* regVal) 
{
	MRVL_APHY_U32 regData = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;

	if (MRVL_AMG_isVirtualReg(regaddr) == MRVL_APHY_FALSE) 
	{
		MRVL_AMG_DBG_ERROR("MRVL_AMG_Virtual_readReg32 error: not a virtual reg\n");
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* read reg */
		status |= MRVL_AMG_WriteReg32(device, FwMmd1eSet0CmdMailboxData, regaddr & 0xffffU);
		status |= MRVL_AMG_WriteReg32(device, FwMmd1eSet0CmdMailboxData + 4, (regaddr >> 16) & 0xffffU);

		/* execute */
		/* MRVL_AMG_ReadReg32(device, MRVL_AMG_CMD_MB_CTRL, &regData); */
		/* regData &= 0xfff0; */
		regData = MRVL_AMG_CMD_MB_READ | (1U << cmdmbExecute);
		status |= MRVL_AMG_WriteReg32(device, FwMmd1eSet0CmdMailboxCmdAndStatus, regData);

		status |= MRVL_AMG_Virtual_getStatus(device);
		
		if (status != MRVL_APHY_STATUS_OK) 
		{
			MRVL_AMG_DBG_ERROR("MRVL_AMG_Virtual_readReg32 error: reg 0x%x \n", regaddr);
		}
		else
		{
			/* read back */
			status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0CmdMailboxData + 12, &regData);
			*regVal = regData & 0xffffU;
			status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0CmdMailboxData + 16, &regData);
			*regVal += (regData & 0xffffU) << 16;
		}
		
	}
	

	MRVL_AMG_DBG_ALL("MRVL_AMG_Virtual_readReg32: reg 0x%x = 0x%x\n", regaddr, regVal);
	return status;
}

MRVL_APHY_STATUS MRVL_AMG_Virtual_writeReg32(MRVL_DEV_PTR device, MRVL_APHY_U32 regaddr, MRVL_APHY_U32 regVal)
{
	MRVL_APHY_U32 regData = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;

	if (MRVL_AMG_isVirtualReg(regaddr) == MRVL_APHY_FALSE) 
	{
		MRVL_AMG_DBG_ERROR("MRVL_AMG_Virtual_writeReg32 error: not a virtual reg\n");
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	else
	{
		/* write reg */
		status |= MRVL_AMG_WriteReg32(device, FwMmd1eSet0CmdMailboxData, regaddr & 0xffffU);
		status |= MRVL_AMG_WriteReg32(device, FwMmd1eSet0CmdMailboxData + 4, (regaddr >> 16) & 0xffffU);
		status |= MRVL_AMG_WriteReg32(device, FwMmd1eSet0CmdMailboxData + 8, 0); 
		status |= MRVL_AMG_WriteReg32(device, FwMmd1eSet0CmdMailboxData + 12, regVal & 0xffffU);
		status |= MRVL_AMG_WriteReg32(device, FwMmd1eSet0CmdMailboxData + 16, (regVal >> 16) & 0xffffU);

		/* execute */
		status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0CmdMailboxCmdAndStatus, &regData);
		regData = MRVL_AMG_CMD_MB_WRITE | (1U << cmdmbExecute);
		status |= MRVL_AMG_WriteReg32(device, FwMmd1eSet0CmdMailboxCmdAndStatus, regData);

		status |= MRVL_AMG_Virtual_getStatus(device);
	}


	if (status != MRVL_APHY_STATUS_OK)
	{
		MRVL_AMG_DBG_ERROR("MRVL_AMG_Virtual_writeReg32 error: reg 0x%x \n", regaddr);
	}
	else
	{
		MRVL_AMG_DBG_ALL("MRVL_AMG_Virtual_writeReg32: reg 0x%x = 0x%x\n", regaddr, regVal);
	}
	
	return status;
}


