#include "tpa_drv.h"
#include "reg_hal.h"
#include "xpcs_define.h"
#include "debug.h"



//#define HwTPA_CSR			0x46D30000
#define HwTPA_CSR			0xD30000
#define HwSW_RST_CTRL       (HwTPA_CSR + 0x0004)
#define HwTPA_CLK_DIV_CSR   (HwTPA_CSR + 0x900c)

//#define AN_EN_2P5G
//#define AN_EN_5P0G
//#define LOOPBACK_U
//#define LOOPBACK_L


static XS_PMA_MMD       uPCS0_PMA_MMD;
static XS_PCS_MMD       uPCS0_PCS_MMD;
static XS_PMA_MMD       uPCS1_PMA_MMD;
static XS_PCS_MMD       uPCS1_PCS_MMD;
static SR_MII_MMD       uPCS0_SR_MII_MMD;
static VR_MII_MMD       uPCS0_VR_MII_MMD;
static SR_MII_MMD       uPCS1_SR_MII_MMD;
static VR_MII_MMD       uPCS1_VR_MII_MMD;



void Serdes_init_2p5G(void)
{
	unsigned long addr;
	unsigned int val;

	mcu_printf("\n[%s] START\n", __func__);

	//----------------------------------------------------------------------------------------------------------------------------
	// TPA_CSR.TPA_CLK_DIV_CSR : Divider-2/4 enable and request
	//----------------------------------------------------------------------------------------------------------------------------
	// [15:10] : DIV4_DIV = 3
	// [	9] : DIV4_REQ = 1
	// [	8] : DIV4_EN  = 1
	// [ 7: 2] : DIV2_DIV = 1
	// [	1] : DIV2_REQ = 1
	// [	0] : DIV2_EN  = 1
	//----------------------------------------------------------------------------------------------------------------------------
	RegWrite(HwTPA_CLK_DIV_CSR, ((3<<10) | (1<<9) | (1<<8) | (1<<2) | (1<<1) | (1<<0)));

	//----------------------------------------------------------------------------------------------------------------------------
	// TPA_CSR.SW_RST_CTRL : TPA 5.0/2.5 Gbps XPCS(XPCS-0/1) software reset
	//----------------------------------------------------------------------------------------------------------------------------
	// [0] : Reseved
	// [1] : TPA GMAC-0 			software reset
	// [2] : TPA GMAC-1 			software reset
	// [3] : TPA XGMAC-0(5.0 Gbps)	software reset
	// [4] : TPA XGMAC-1(2.5 Gbps)	software reset
	// [5] : TPA XPCS-0 (5.0 Gbps)	software reset
	// [6] : TPA XPCS-1 (2.5 Gbps)	software reset
	//----------------------------------------------------------------------------------------------------------------------------
	addr = HwSW_RST_CTRL;
	val = RegRead(addr);													// Read SW_RST_CTRL
	val = val & (0xffffffff - ((1<<6) | (1<<5)));							// SW_RST_CTRL[6] = 0 XPCS-1 software reset assertion
																			// SW_RST_CTRL[5] = 0 XPCS-0 software reset assertion
	RegWrite(addr, val);

	SAL_TaskSleep(100); 													// Wait 10us
	RegWrite(HwSW_RST_CTRL, 0xffffffff);									// SW_RST_CTRL[6] = 1 XPCS-1 software reset release
																			// SW_RST_CTRL[5] = 1 XPCS-0 software reset release

	//----------------------------------------------------------------------------------------------------------------------------
	// Wating for PHY RAM initialization
	//----------------------------------------------------------------------------------------------------------------------------
	mcu_printf("Wait for PHY SRAM initialization\n");

	// Wait for PHY SRAM initialization
	do{
		addr = &HwXPCS0_XS_PMA_MMD->uSRAM.nReg;
		uPCS0_PMA_MMD.uSRAM.nReg = RegRead(addr);
		mcu_printf("[%d]SRAM value :: 0x%x\n", __LINE__, uPCS0_PMA_MMD.uSRAM.nReg);
		SAL_TaskSleep(100);
	}while((uPCS0_PMA_MMD.uSRAM.nReg & (0x1<<0)) == (0x0<<0));

	// SRAM External Loading Done = 1
	addr = &HwXPCS0_XS_PMA_MMD->uSRAM.nReg;
	uPCS0_PMA_MMD.uSRAM.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uSRAM.nReg = uPCS0_PMA_MMD.uSRAM.nReg | (1 << 1); 		// 1 bit(EXT_LD_DONE) 1 mask
	RegWrite(&HwXPCS0_XS_PMA_MMD->uSRAM.nReg, uPCS0_PMA_MMD.uSRAM.nReg);

	mcu_printf("Complete PHY SRAM initialization\n");

	// Wait XPCS-0 Soft reset wait done
	do{
		addr = &HwXPCS0_XS_PCS_MMD->uCTRL1.nReg;
		uPCS0_PCS_MMD.uCTRL1.nReg = RegRead(addr);
	}while((uPCS0_PCS_MMD.uCTRL1.nReg & (0x1<<15)) != (0x0<<15));

	// Wait XPCS-1 Soft reset wait done
	do{
		addr = &HwXPCS1_XS_PCS_MMD->uCTRL1.nReg;
		uPCS1_PCS_MMD.uCTRL1.nReg = RegRead(addr);
	}while((uPCS1_PCS_MMD.uCTRL1.nReg & (0x1<<15)) != (0x0<<15));


	mcu_printf("Wait for PHY power-up\n");

	// XPCS-0 initialize PHY wait Power-up
	do{
		addr = &HwXPCS0_XS_PCS_MMD->uDIG_STS.nReg;
		uPCS0_PCS_MMD.uDIG_STS.nReg = RegRead(addr);
	}while((uPCS0_PCS_MMD.uDIG_STS.nReg & (0x7<<2)) != (0x4<<2));

	// XPCS-1 initialize PHY wait Power-up
	do{
		addr = &HwXPCS1_XS_PCS_MMD->uDIG_STS.nReg;
		uPCS1_PCS_MMD.uDIG_STS.nReg = RegRead(addr);
	}while((uPCS1_PCS_MMD.uDIG_STS.nReg & (0x7<<2)) != (0x4<<2));

	mcu_printf("Complete PHY power-up\n");

#ifdef LOOPBACK_U
    //----------------------------------------------------------------------------------------------------------------------------
    // PHY lane-1(2.5Gbps) Serial Loopback enable
    //----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);

    uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<14));        // LBE masking
    uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<14);        // LBE = 1
    RegWrite(&HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg, uPCS1_SR_MII_MMD.uMII_CTRL.nReg);
#endif

	//----------------------------------------------------------------------------------------------------------------------------
	// Programming Sequece for SGMII Mode
	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3-1 : SR_XS_PCS_CTRL2[3:0] register to 4'b0001 (10GBASE-X PCS Type)
	addr = &HwXPCS1_XS_PCS_MMD->uCTRL2.nReg;
	uPCS1_PCS_MMD.uCTRL2.nReg = RegRead(addr);
	uPCS1_PCS_MMD.uCTRL2.nReg = uPCS1_PCS_MMD.uCTRL2.nReg & (~(0xf<<0));			// PCS_TYPE_SEL[3:0] masking
	uPCS1_PCS_MMD.uCTRL2.nReg = uPCS1_PCS_MMD.uCTRL2.nReg |   (  1<<0); 			// PCS_TYPE_SEL[3:0] = 1
	RegWrite(&HwXPCS1_XS_PCS_MMD->uCTRL2.nReg, uPCS1_PCS_MMD.uCTRL2.nReg);

	// 5.3-3 : SR_MII_CTRL{[13], [6], [5]} register to {0, 1, 0} (Speed Selection : 1000 Mbps)
	addr = &HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<5 ));	// SS5 masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  0<<5 );	// SS5 = 0
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<6 ));	// SS6 masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<6 );	// SS6 = 1
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<13));	// SS13 masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  0<<13);	// SS13 = 0
	RegWrite(&HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg, uPCS1_SR_MII_MMD.uMII_CTRL.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-4-a, 5.3-4-a : PHY Common setting for 156.25MHz reference clock, Table5-1
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_XS_PMA_MMD->uREF_CLK_CTRL.nReg;
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg & (~(0x7<<3));	// REF_RANGE[2:0] masking
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg |	(  6<<3);	// REF_RANGE[2:0]	= 6
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg & (~(0x1<<2));	// REF_CLK_DIV2 masking
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg |	(  0<<2);	// REF_CLK_DIV2 	= 0
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg & (~(0x1<<0));	// REF_CLK_EN masking
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg |	(  1<<0);	// REF_CLK_EN		= 1
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg & (~(0x1<<6));	// REF_MPLLA_DIV2 masking
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg |	(  1<<6);	// REF_MPLLA_DIV2	= 1
	RegWrite(&HwXPCS0_XS_PMA_MMD->uREF_CLK_CTRL.nReg, uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uREF_CLK_CTRL.nReg;
	uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg & (~(0x1<<7));	// REF_MPLLB_DIV2 masking
	uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg |	(  1<<7);	// REF_MPLLB_DIV2	= 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uREF_CLK_CTRL.nReg, uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL0.nReg;
	uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg & (~(0xff<<0 ));	// MPLL_MULTIPLIER masking
	uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg |   (  33<<0 );	// MPLL_MULTIPLIER = 33
	uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg & (~( 0x1<<15));	// MPLL_CAL_DISABLE masking
	uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg |   (   0<<15);	// MPLL_CAL_DISABLE = 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL0.nReg, uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL0.nReg;
	uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg & (~(0xff<<0 ));	// MPLL_MULTIPLIER masking
	uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg |   (  50<<0 );	// MPLL_MULTIPLIER = 50
	uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg & (~( 0x1<<15));	// MPLL_CAL_DISABLE masking
	uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg |   (   0<<15);	// MPLL_CAL_DISABLE = 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL0.nReg, uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL1.nReg;
	uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg & (~(0x7ff<<5));	// MPLL_FRACN_CTRL masking
	uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg |   (    0<<5);	// MPLL_FRACN_CTRL = 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL1.nReg, uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL1.nReg;
	uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg & (~(0x7ff<<5));	// MPLL_FRACN_CTRL masking
	uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg |   (    0<<5);	// MPLL_FRACN_CTRL = 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL1.nReg, uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg);


	addr = &HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL2.nReg;
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~( 0x1<<8 ));	// MPLL_DIV8_CLK_EN masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   0<<8 );	// MPLL_DIV8_CLK_EN 	= 0
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~( 0x1<<9 ));	// MPLL_DIV10_CLK_EN masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   1<<9 );	// MPLL_DIV10_CLK_EN	= 1
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~( 0x1<<10));	// MPLL_DIV16P5_CLK_EN masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   1<<10);	// MPLL_DIV16P5_CLK_EN	= 1
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~( 0x3<<11));	// MPLL_TX_CLK_DIV[1:0] masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   0<<11);	// MPLL_TX_CLK_DIV[1:0] = 0
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~( 0x1<<7 ));	// MPLL_DIV_CLK_EN masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   0<<7 );	// MPLL_DIV_CLK_EN		= 0
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~(0x7f<<0 ));	// MPLL_DIV_MULT[6:0] masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   0<<0 );	// MPLL_DIV_MULT[6:0]	= 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL2.nReg, uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL2.nReg;
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg & (~( 0x1<<8 ));	// MPLL_DIV8_CLK_EN masking
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg |   (   0<<8 );	// MPLL_DIV8_CLK_EN 	= 0
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg & (~( 0x1<<9 ));	// MPLL_DIV10_CLK_EN masking
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg |   (   1<<9 );	// MPLL_DIV10_CLK_EN	= 1
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg & (~( 0x3<<11));	// MPLL_TX_CLK_DIV masking
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg |   (   0<<11);	// MPLL_TX_CLK_DIV		= 0
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg & (~( 0x1<<7 ));	// MPLL_DIV_CLK_EN masking
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg |   (   1<<7 );	// MPLL_DIV_CLK_EN		= 1
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg & (~(0x7f<<0 ));	// MPLL_DIV_MULT masking
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg |   (  12<<0 );	// MPLL_DIV_MULT		= 12
	RegWrite(&HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL2.nReg, uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg);

	uPCS0_PMA_MMD.uMPLLA_CTRL3.nReg = 61970;
	RegWrite(&HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL3.nReg, uPCS0_PMA_MMD.uMPLLA_CTRL3.nReg);	// MPLL_BANDWIDTH = 61970

	uPCS1_PMA_MMD.uMPLLB_CTRL3.nReg = 40967;
	RegWrite(&HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL3.nReg, uPCS1_PMA_MMD.uMPLLB_CTRL3.nReg);	// MPLL_BANDWIDTH = 40967

	addr = &HwXPCS0_XS_PMA_MMD->uTX_GENCTRL1.nReg;
	uPCS0_PMA_MMD.uTX_GENCTRL1.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uTX_GENCTRL1.nReg = uPCS0_PMA_MMD.uTX_GENCTRL1.nReg & (~(0x7<<8));	// VBOOST_LVL masking
	uPCS0_PMA_MMD.uTX_GENCTRL1.nReg = uPCS0_PMA_MMD.uTX_GENCTRL1.nReg |   (  5<<8); 	// VBOOST_LVL = 5
	RegWrite(&HwXPCS0_XS_PMA_MMD->uTX_GENCTRL1.nReg, uPCS0_PMA_MMD.uTX_GENCTRL1.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uMISC_CTRL0.nReg;
	uPCS0_PMA_MMD.uMISC_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uMISC_CTRL0.nReg = uPCS0_PMA_MMD.uMISC_CTRL0.nReg & (~(0x1f<<8)); 	// RX_VREF_CTRL masking
	uPCS0_PMA_MMD.uMISC_CTRL0.nReg = uPCS0_PMA_MMD.uMISC_CTRL0.nReg |	(  17<<8);		// RX_VREF_CTRL = 17
	RegWrite(&HwXPCS0_XS_PMA_MMD->uMISC_CTRL0.nReg, uPCS0_PMA_MMD.uMISC_CTRL0.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3-4-b : PHY Lane-1 Tx/Rx setting by XPCS-1 for SGMII
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS1_XS_PMA_MMD->uMPLL_CMN_CTRL.nReg;
	uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg = uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg & (~(0x1<<4));	// MPLLB_SEL_0 masking
	uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg = uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg |   (  1<<4); 	// MPLLB_SEL_0			= 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uMPLL_CMN_CTRL.nReg, uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_MISC_CTRL0.nReg;
	uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg = uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg & (~(0xff<<0));	// TX0_MISC masking
	uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg = uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg |   (   0<<0);	// TX0_MISC 			= 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_MISC_CTRL0.nReg, uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_RATE_CTRL.nReg;
	uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg = uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg & (~(0x7<<0));		// TX0_RATE masking
	uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg = uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg |	(  5<<0);		// TX0_RATE 			= 5
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_RATE_CTRL.nReg, uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_GENCTRL2.nReg;
	uPCS1_PMA_MMD.uTX_GENCTRL2.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_GENCTRL2.nReg = uPCS1_PMA_MMD.uTX_GENCTRL2.nReg & (~(0x3<<8));		// TX0_WIDTH masking
	uPCS1_PMA_MMD.uTX_GENCTRL2.nReg = uPCS1_PMA_MMD.uTX_GENCTRL2.nReg |   (  1<<8); 		// TX0_WIDTH			= 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_GENCTRL2.nReg, uPCS1_PMA_MMD.uTX_GENCTRL2.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_GENCTRL1.nReg;
	uPCS1_PMA_MMD.uTX_GENCTRL1.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_GENCTRL1.nReg = uPCS1_PMA_MMD.uTX_GENCTRL1.nReg & (~(0x1<<4));		// VBOOST_EN_0 masking
	uPCS1_PMA_MMD.uTX_GENCTRL1.nReg = uPCS1_PMA_MMD.uTX_GENCTRL1.nReg |   (  1<<4); 		// VBOOST_EN_0			= 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_GENCTRL1.nReg, uPCS1_PMA_MMD.uTX_GENCTRL1.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_BOOST_CTRL.nReg;
	uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg = uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg & (~(0xf<<0));	// TX0_IBOOST masking
	uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg = uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg |   ( 15<<0); 	// TX0_IBOOST			= 15
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_BOOST_CTRL.nReg, uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uVCO_CAL_LD0.nReg;
	uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg = uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg & (~(0x1fff<<0)); 	// VCO_LD_VAL_0 masking
	uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg = uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg |   (  1360<<0);		// VCO_LD_VAL_0 		= 1360
	RegWrite(&HwXPCS1_XS_PMA_MMD->uVCO_CAL_LD0.nReg, uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uVCO_CAL_REF0.nReg;
	uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg = uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg & (~(0x7f<<0)); 	// VCO_REF_LD_0 masking
	uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg = uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg |	(  34<<0);		// VCO_REF_LD_0 		= 34
	RegWrite(&HwXPCS1_XS_PMA_MMD->uVCO_CAL_REF0.nReg, uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_RATE_CTRL.nReg;
	uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg = uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg & (~(0x3<<0));		// RX0_RATE masking
	uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg = uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg |	(  2<<0);		// RX0_RATE 			= 2
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_RATE_CTRL.nReg, uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_GENCTRL1.nReg;
	uPCS1_PMA_MMD.uRX_GENCTRL1.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_GENCTRL1.nReg = uPCS1_PMA_MMD.uRX_GENCTRL1.nReg & (~(0x1<<12));		// RX_DIV16P5_CLK_EN_0 masking
	uPCS1_PMA_MMD.uRX_GENCTRL1.nReg = uPCS1_PMA_MMD.uRX_GENCTRL1.nReg |   (  0<<12);		// RX_DIV16P5_CLK_EN_0	= 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_GENCTRL1.nReg, uPCS1_PMA_MMD.uRX_GENCTRL1.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_GENCTRL2.nReg;
	uPCS1_PMA_MMD.uRX_GENCTRL2.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_GENCTRL2.nReg = uPCS1_PMA_MMD.uRX_GENCTRL2.nReg & (~(0x3<<8));		// RX0_WIDTH masking
	uPCS1_PMA_MMD.uRX_GENCTRL2.nReg = uPCS1_PMA_MMD.uRX_GENCTRL2.nReg |   (  1<<8); 		// RX0_WIDTH			= 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_GENCTRL2.nReg, uPCS1_PMA_MMD.uRX_GENCTRL2.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_GENCTRL3.nReg;
	uPCS1_PMA_MMD.uRX_GENCTRL3.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_GENCTRL3.nReg = uPCS1_PMA_MMD.uRX_GENCTRL3.nReg & (~(0x7<<0));		// RX_THSHLD_0 masking
	uPCS1_PMA_MMD.uRX_GENCTRL3.nReg = uPCS1_PMA_MMD.uRX_GENCTRL3.nReg |   (  1<<0); 		// RX_THSHLD_0			= 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_GENCTRL3.nReg, uPCS1_PMA_MMD.uRX_GENCTRL3.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_GENCTRL4.nReg;
	uPCS1_PMA_MMD.uRX_GENCTRL4.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_GENCTRL4.nReg = uPCS1_PMA_MMD.uRX_GENCTRL4.nReg & (~(0x1<<8));		// RX_DFE_BYP_0 masking
	uPCS1_PMA_MMD.uRX_GENCTRL4.nReg = uPCS1_PMA_MMD.uRX_GENCTRL4.nReg |   (  1<<8); 		// RX_DFE_BYP_0 		= 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_GENCTRL4.nReg, uPCS1_PMA_MMD.uRX_GENCTRL4.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_EQ_CTRL0.nReg;
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg & (~( 0x7<<12));		// VGA1_GAIN_0 masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   4<<12);		// VGA1_GAIN_0			= 4
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg & (~( 0x7<<8 ));		// VGA2_GAIN_0 masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   4<<8 );		// VGA2_GAIN_0			= 4
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg & (~(0x1f<<0 ));		// CTLE_BOOST_0 masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   6<<0 );		// CTLE_BOOST_0 		= 6
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg & (~( 0x3<<5 ));		// CTLE_POLE_0 masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   0<<5 );		// CTLE_POLE_0			= 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_EQ_CTRL0.nReg, uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_EQ_CTRL5.nReg;
	uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg & (~(0x3<<4));		// RX0_ADPT_MODE masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg |   (  0<<4); 		// RX0_ADPT_MODE		= 0
	uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg & (~(0x1<<0));		// RX_ADPT_SEL_0 masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg |   (  0<<0); 		// RX_ADPT_SEL_0		= 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_EQ_CTRL5.nReg, uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_CDR_CTRL1.nReg;
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg & (~(0x1<<4));		// VCO_STEP_CTRL_0 masking
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg |	(  1<<4);		// VCO_STEP_CTRL_0		= 1
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg & (~(0x1<<0));		// VCO_TEMP_COMP_EN_0 masking
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg |	(  0<<0);		// VCO_TEMP_COMP_EN_0	= 0
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg & (~(0x3<<8));		// VCO_FRQBAND_0 masking
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg |	(  2<<8);		// VCO_FRQBAND_0		= 2
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_CDR_CTRL1.nReg, uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_MISC_CTRL0.nReg;
	uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg = uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg & (~(0xff<<0));	// RX0_MISC masking
	uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg = uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg |   (   7<<0);	// RX0_MISS 			= 7
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_MISC_CTRL0.nReg, uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_IQ_CTRL0.nReg;
	uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg & (~(0xf<<8));		// RX0_DELTA_IQ masking
	uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg |   (  0<<8); 		// RX0_DELTA_IQ 		= 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_IQ_CTRL0.nReg, uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_ATTN_CTRL.nReg;
	uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg = uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg & (~(0x7<<0));		// RX0_EQ_ATT_LVL masking
	uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg = uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg |	(  0<<0);		// RX0_EQ_ATT_LVL		= 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_ATTN_CTRL.nReg, uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uDFE_TAP_CTRL0.nReg;
	uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg = uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg & (~(0xff<<0));	// DFE_TAP1_0 masking
	uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg = uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg |   (   0<<0);	// DFE_TAP1_0			= 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uDFE_TAP_CTRL0.nReg, uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_PPM_CTRL0.nReg;
	uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg = uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg & (~(0x1f<<0)); 	// RX0_CDR_PPM_MAX masking
	uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg = uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg |	(  18<<0);		// RX0_CDR_PPM_MAX		= 18
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_PPM_CTRL0.nReg, uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg);

#ifdef LOOPBACK_L
    //----------------------------------------------------------------------------------------------------------------------------
    // PHY lane-1(2.5Gbps) Serial Loopback enable
    //----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);

    uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<14));        // LBE masking
    uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<14);        // LBE = 1
    RegWrite(&HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg, uPCS1_SR_MII_MMD.uMII_CTRL.nReg);

#if 0
	addr = &HwXPCS1_XS_PMA_MMD->uMISC_CTRL0.nReg;
	uPCS1_PMA_MMD.uMISC_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uMISC_CTRL0.nReg = uPCS1_PMA_MMD.uMISC_CTRL0.nReg & (~(0x1<<0)); 		// TX2RX_LB_EN_0 masking
	uPCS1_PMA_MMD.uMISC_CTRL0.nReg = uPCS1_PMA_MMD.uMISC_CTRL0.nReg |	(  1<<0);		// TX2RX_LB_EN_0 = 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uMISC_CTRL0.nReg, uPCS1_PMA_MMD.uMISC_CTRL0.nReg);
#endif
#endif

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-5 ~ 5.2-6 : PHY Reset assertion and readback check
	// 5.3-5 ~ 5.3-6 : PHY Reset assertion and readback check
	//----------------------------------------------------------------------------------------------------------------------------
	mcu_printf("PHY reset asserted 0\n");
	addr = &HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg;
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = RegRead(addr);
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg & (~(0x1<<15));			// VR_RST masking
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg |   (  1<<15);			// VR_RST = 1
	RegWrite(&HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg, uPCS0_PCS_MMD.uDIG_CTRL1.nReg);			// PHY reset only is controlled by XPCS-0

	mcu_printf("Wait for PHY reset done\n");
	do{
		addr = &HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg;
		uPCS0_PCS_MMD.uDIG_CTRL1.nReg = RegRead(addr);
	}while((uPCS0_PCS_MMD.uDIG_CTRL1.nReg & (0x1<<15)) != (0x0<<15));
	mcu_printf("Complete PHY reset\n");

	//----------------------------------------------------------------------------------------------------------------------------
	// Tx. Equalization control register setting
	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3-7 : uTX_EQ_CTRL0.TX_EQ_PRE	= 0,	Tx Pre-Emphasis level adjustment Control
	// 5.3-8 : uTX_EQ_CTRL0.TX_EQ_MAIN	= 32,	Control for setting Tx driver output amplitude
	// 5.3-9 : uTX_EQ_CTRL1.TX_EQ_POST	= 32,	Tx Post-Emphasis level adjustment Control
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS1_XS_PMA_MMD->uTX_EQ_CTRL0.nReg;
	uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg & (~(0x3f<<0));		// RX_EQ_PRE masking
	uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg |   (   0<<0);		// RX_EQ_PRE	= 0
	uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg & (~(0x3f<<8));		// RX_EQ_MAIN masking
	uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg |   (  32<<8);		// RX_EQ_MAIN	= 32
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_EQ_CTRL0.nReg, uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_EQ_CTRL1.nReg;
	uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg & (~(0x3f<<0));		// RX_EQ_POST masking
	uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg |   (  32<<0);		// RX_EQ_POST	= 32
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_EQ_CTRL1.nReg, uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg);

#ifdef AN_EN_2P5G
	//============================================================================================================================
	// SGMII Auto-negotiation
	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	mcu_printf("2.5Gbps SGMII Auto-negotiation setting start\n");

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3.1 Auto-negotiation disable
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);	 // load XPCS1_SR_MII_MMD.uMMI_CTRL

	if((uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (0x1<<12)) == (1<<12)) {					// Auto negotiation enable check
		uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<12));	// AN_ENABLE masking
		uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  0<<12);	// AN_ENABLE = 0
		RegWrite(&HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg, uPCS1_SR_MII_MMD.uMII_CTRL.nReg);
	}

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3.1-2 : Auto-negotiation control register setting
	//----------------------------------------------------------------------------------------------------------------------------
	// PCS mode 											= SGMII mode (Clause 47 auto-negotiation is as per SGMII)
	// Transmission Configuration							= Configures the DWC_xpcs as the PHY side SGMII
	// Clause 37 Auto-negotiation complete interrupt enable = Enable
	// SGMII Link Status									= Link-up
	// MII Control											= 8-bit MII
	// Full duplex											= Enable
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS1_VR_MII_MMD->uAN_CTRL.nReg;
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = RegRead(addr);
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg & (~(0x3<<1));			// PCS_MODE masking
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg |	(  2<<1);			// PCS_MODE 		= 2
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg & (~(0x1<<3));			// TX_CONFIG masking
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg |	(  1<<3);			// TX_CONFIG		= 1
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg & (~(0x1<<0));			// MII_AN_INTR_EN masking
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg |	(  1<<0);			// MII_AN_INTR_EN	= 1
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg & (~(0x1<<4));			// SGMII_LINK_STS masking
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg |	(  1<<4);			// SGMII_LINK_STS	= 1
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg & (~(0x1<<8));			// MII_CTRL masking
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg |	(  1<<8);			// MII_CTRL 		= 1
	RegWrite(&HwXPCS1_VR_MII_MMD->uAN_CTRL.nReg, uPCS1_VR_MII_MMD.uAN_CTRL.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3.1-3 : Speed selection and Full duplex mode setting
	//----------------------------------------------------------------------------------------------------------------------------
	// SS6, SS13											= {1,0}, 1000Mbps
	//----------------------------------------------------------------------------------------------------------------------------
	// FD													= 1, Full duplex
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<6 ));		// SS6 masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<6 );		// SS6	= 1
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<13));		// SS13 masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  0<<13);		// SS13 = 0
	RegWrite(&HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg, uPCS1_SR_MII_MMD.uMII_CTRL.nReg);

	addr = &HwXPCS1_SR_MII_MMD->uMII_AN_ADV.nReg;
	uPCS1_SR_MII_MMD.uMII_AN_ADV.nReg = RegRead(addr);
	uPCS1_SR_MII_MMD.uMII_AN_ADV.nReg = uPCS1_SR_MII_MMD.uMII_AN_ADV.nReg & (~(0x1<<5));	  // FD masking
	uPCS1_SR_MII_MMD.uMII_AN_ADV.nReg = uPCS1_SR_MII_MMD.uMII_AN_ADV.nReg |   (1<<5);		// FD	= 1
	RegWrite(&HwXPCS1_SR_MII_MMD->uMII_AN_ADV.nReg, uPCS1_SR_MII_MMD.uMII_AN_ADV.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3.1-4 : Skip
	//----------------------------------------------------------------------------------------------------------------------------

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3.1-5 : Speed selection and Link timer setting
	//----------------------------------------------------------------------------------------------------------------------------
	// Link timer											= 16ms
	//----------------------------------------------------------------------------------------------------------------------------
	uPCS1_VR_MII_MMD.uLINK_TIMER_CTRL.nReg = 0x07a1;
	RegWrite(&HwXPCS1_VR_MII_MMD->uLINK_TIMER_CTRL.nReg, uPCS1_VR_MII_MMD.uLINK_TIMER_CTRL.nReg);	// CL37_LINK_TIME = 0x07a1

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3.1-6 : Speed selection and Link timer setting
	//----------------------------------------------------------------------------------------------------------------------------
	// Link timer override enable							= 1
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS1_VR_MII_MMD->uMII_DIG_CTRL1.nReg;
	uPCS1_VR_MII_MMD.uMII_DIG_CTRL1.nReg = RegRead(addr);
	uPCS1_VR_MII_MMD.uMII_DIG_CTRL1.nReg = uPCS1_VR_MII_MMD.uMII_DIG_CTRL1.nReg & (~(0x1<<3));		// CL37_TMR_OVR_RIDE masking
	uPCS1_VR_MII_MMD.uMII_DIG_CTRL1.nReg = uPCS1_VR_MII_MMD.uMII_DIG_CTRL1.nReg |	(  1<<3);		// CL37_TMR_OVR_RIDE	= 1
	RegWrite(&HwXPCS1_VR_MII_MMD->uMII_DIG_CTRL1.nReg, uPCS1_VR_MII_MMD.uMII_DIG_CTRL1.nReg);

#if 1
	mcu_printf("Wait for PHY Link-up 2.5G\n");

	do{
		addr = &HwXPCS1_XS_PCS_MMD->uPCS_STS.nReg;
		uPCS1_PCS_MMD.uPCS_STS.nReg = RegRead(addr);
	}while((uPCS1_PCS_MMD.uPCS_STS.nReg & (0x1<<2)) != (0x1<<2));

	mcu_printf("Complete PHY Link-up 2.5G\n");
#endif

#if 0
	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3.1-7 : Auto-negotiation enble
	//----------------------------------------------------------------------------------------------------------------------------
	mcu_printf("2.5Gbps SGMII Auto-negotiation enabled.\n");
	addr = &HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<12));				// AN_ENABLE making
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<12);				// AN_ENABLE = 1
	RegWrite(&HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg, uPCS1_SR_MII_MMD.uMII_CTRL.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3.1-8 : Wait for Auto-negotiation interrupt
	//----------------------------------------------------------------------------------------------------------------------------
#if 0
	do{
		addr = &HwXPCS1_VR_MII_MMD->uAN_INTR_STS.nReg;
		uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg = RegRead(addr);
	}while((uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg & 0x1) != 1);
	mcu_printf("2.5Gbps SGMII Auto-negotiation done.\n");
#endif
#endif

	// Clause 37 AN SGMII port status
	if((uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg & (0x1<<1)) == (1<<1)) {
		mcu_printf("2.5G PHY Lane-1 AN result : Full duplex\n");
	} else {
		mcu_printf("2.5G PHY Lane-1 AN result : Half duplex\n");
	}

	if((uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg & (0x3<<2)) == (0<<2)) {
		mcu_printf("2.5G PHY Lane-1 AN result : 10 Mbps speed link\n");
	}
	else if((uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg & (0x3<<2)) == (1<<2)) {
		mcu_printf("2.5G PHY Lane-1 AN result : 100 Mbps speed link\n");
	}
	else if((uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg & (0x3<<2)) == (2<<2)) {
		mcu_printf("2.5G PHY Lane-1 AN result : 1000 Mbps speed link\n");
	}
	else {
		mcu_printf("2.5G PHY Lane-1 AN result : Error, Link speed not supported.\n");
	}

	if((uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg & (0x1<<4)) == (1<<4)) {
		mcu_printf("2.5G PHY Lane-1 AN result : Link up\n");
	} else {
		mcu_printf("2.5G PHY Lane-1 AN result : Link down\n");
	}

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-9 : Clear to Auto-negotiation interrupt
	//----------------------------------------------------------------------------------------------------------------------------
	mcu_printf("2.5Gbps SGMII Auto-negotiation interrupt clear.\n");

	addr = &HwXPCS1_VR_MII_MMD->uAN_INTR_STS.nReg;
	uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg = RegRead(addr); 	// load XPCS0_SR_MII_MMD.uMMI_CTRL
	uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg = uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg & (~(0x1<<0));
	uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg = uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg |	(  0<<0);
	RegWrite(&HwXPCS1_VR_MII_MMD->uAN_INTR_STS.nReg, uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg);
#else
	// Auto-negotiation disable
	addr = &HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<12));		// AN_ENABLE masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  0<<12);		// AN_ENABLE	= 0
	RegWrite(&HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg, uPCS1_SR_MII_MMD.uMII_CTRL.nReg);

	addr = &HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<6 ));		// SS6 masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<6 );		// SS6	= 1
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<13));		// SS13 masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  0<<13);		// SS13 = 0
	RegWrite(&HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg, uPCS1_SR_MII_MMD.uMII_CTRL.nReg);
#endif  // AN_EN_2P5G

}

void Serdes_init_5p0G(void)
{
	unsigned long addr;
	unsigned int val;

	mcu_printf("\n[%s] START\n", __func__);

	//----------------------------------------------------------------------------------------------------------------------------
	// TPA_CSR.TPA_CLK_DIV_CSR : Divider-2/4 enable and request
	//----------------------------------------------------------------------------------------------------------------------------
	// [15:10] : DIV4_DIV = 3
	// [	9] : DIV4_REQ = 1
	// [	8] : DIV4_EN  = 1
	// [ 7: 2] : DIV2_DIV = 1
	// [	1] : DIV2_REQ = 1
	// [	0] : DIV2_EN  = 1
	//----------------------------------------------------------------------------------------------------------------------------
	RegWrite(HwTPA_CLK_DIV_CSR, ((3<<10) | (1<<9) | (1<<8) | (1<<2) | (1<<1) | (1<<0)));

	//----------------------------------------------------------------------------------------------------------------------------
	// TPA_CSR.SW_RST_CTRL : TPA 5.0/2.5 Gbps XPCS(XPCS-0/1) software reset
	//----------------------------------------------------------------------------------------------------------------------------
	// [0] : Reseved
	// [1] : TPA GMAC-0 			software reset
	// [2] : TPA GMAC-1 			software reset
	// [3] : TPA XGMAC-0(5.0 Gbps)	software reset
	// [4] : TPA XGMAC-1(2.5 Gbps)	software reset
	// [5] : TPA XPCS-0 (5.0 Gbps)	software reset
	// [6] : TPA XPCS-1 (2.5 Gbps)	software reset
	//----------------------------------------------------------------------------------------------------------------------------
	addr = HwSW_RST_CTRL;
	val = RegRead(addr);													// Read SW_RST_CTRL
	val = val & (0xffffffff - ((1<<6) | (1<<5)));							// SW_RST_CTRL[6] = 0 XPCS-1 software reset assertion
																			// SW_RST_CTRL[5] = 0 XPCS-0 software reset assertion
	RegWrite(addr, val);

	SAL_TaskSleep(100); 													// Wait 10us
	RegWrite(HwSW_RST_CTRL, 0xffffffff);									// SW_RST_CTRL[6] = 1 XPCS-1 software reset release
																			// SW_RST_CTRL[5] = 1 XPCS-0 software reset release

	//----------------------------------------------------------------------------------------------------------------------------
	// Wating for PHY RAM initialization
	//----------------------------------------------------------------------------------------------------------------------------
	mcu_printf("Wait for PHY SRAM initialization\n");

	// Wait for PHY SRAM initialization
	do{
		addr = &HwXPCS0_XS_PMA_MMD->uSRAM.nReg;
		uPCS0_PMA_MMD.uSRAM.nReg = RegRead(addr);
		mcu_printf("[%d]SRAM value :: 0x%x\n", __LINE__, uPCS0_PMA_MMD.uSRAM.nReg);
		SAL_TaskSleep(100);
	}while((uPCS0_PMA_MMD.uSRAM.nReg & (0x1<<0)) == (0x0<<0));

	// SRAM External Loading Done = 1
	addr = &HwXPCS0_XS_PMA_MMD->uSRAM.nReg;
	uPCS0_PMA_MMD.uSRAM.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uSRAM.nReg = uPCS0_PMA_MMD.uSRAM.nReg | (1 << 1); 		// 1 bit(EXT_LD_DONE) 1 mask
	RegWrite(&HwXPCS0_XS_PMA_MMD->uSRAM.nReg, uPCS0_PMA_MMD.uSRAM.nReg);

	mcu_printf("Complete PHY SRAM initialization\n");

	// Wait XPCS-0 Soft reset wait done
	do{
		addr = &HwXPCS0_XS_PCS_MMD->uCTRL1.nReg;
		uPCS0_PCS_MMD.uCTRL1.nReg = RegRead(addr);
	}while((uPCS0_PCS_MMD.uCTRL1.nReg & (0x1<<15)) != (0x0<<15));

	// Wait XPCS-1 Soft reset wait done
	do{
		addr = &HwXPCS1_XS_PCS_MMD->uCTRL1.nReg;
		uPCS1_PCS_MMD.uCTRL1.nReg = RegRead(addr);
	}while((uPCS1_PCS_MMD.uCTRL1.nReg & (0x1<<15)) != (0x0<<15));


	mcu_printf("Wait for PHY power-up\n");

	// XPCS-0 initialize PHY wait Power-up
	do{
		addr = &HwXPCS0_XS_PCS_MMD->uDIG_STS.nReg;
		uPCS0_PCS_MMD.uDIG_STS.nReg = RegRead(addr);
	}while((uPCS0_PCS_MMD.uDIG_STS.nReg & (0x7<<2)) != (0x4<<2));

	// XPCS-1 initialize PHY wait Power-up
	do{
		addr = &HwXPCS1_XS_PCS_MMD->uDIG_STS.nReg;
		uPCS1_PCS_MMD.uDIG_STS.nReg = RegRead(addr);
	}while((uPCS1_PCS_MMD.uDIG_STS.nReg & (0x7<<2)) != (0x4<<2));

	mcu_printf("Complete PHY power-up\n");

#ifdef LOOPBACK_U
	//----------------------------------------------------------------------------------------------------------------------------
	// PHY lane-0(5.0Gbps) Serial Loopback enable
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);

	uPCS0_SR_MII_MMD.uMII_CTRL.nReg = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<14));		 // LBE masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<14);		// LBE = 1
	RegWrite(&HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg, uPCS0_SR_MII_MMD.uMII_CTRL.nReg);
#endif

	//----------------------------------------------------------------------------------------------------------------------------
	// Programming Sequence for USXGMII Mode
	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-1 : SR_XS_PCS_CTRL2[3:0] register to 4'b0000 (10GBASE-R PCS Type)
	addr = &HwXPCS0_XS_PCS_MMD->uCTRL2.nReg;
	uPCS0_PCS_MMD.uCTRL2.nReg = RegRead(addr);
	uPCS0_PCS_MMD.uCTRL2.nReg = uPCS0_PCS_MMD.uCTRL2.nReg & (~(0xf<<0));			// PCS_TYPE_SEL[3:0] masking
	uPCS0_PCS_MMD.uCTRL2.nReg = uPCS0_PCS_MMD.uCTRL2.nReg |   (  0<<0); 			// PCS_TYPE_SEL[3:0] = 0
	RegWrite(&HwXPCS0_XS_PCS_MMD->uCTRL2.nReg, uPCS0_PCS_MMD.uCTRL2.nReg);

	// 5.2-2 : VR_XS_PCS_DIG_CTRL1[9](USXG_EN) register to 1
	addr = &HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg;
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = RegRead(addr);
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg & (~(0x1<<9));	// USXG_EN masking
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg |   (  1<<9); 	// USXG_EN = 1
	RegWrite(&HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg, uPCS0_PCS_MMD.uDIG_CTRL1.nReg);

	// 5.2-3 : VR_XS_PCS_KR_CTRL(USXG_MODE field) register to 3'b001
	addr = &HwXPCS0_XS_PCS_MMD->uKR_CTRL.nReg;
	uPCS0_PCS_MMD.uKR_CTRL.nReg = RegRead(addr);
	uPCS0_PCS_MMD.uKR_CTRL.nReg = uPCS0_PCS_MMD.uKR_CTRL.nReg & (~(0x7<<10));		// USXG_MODE[2:0] masking
	uPCS0_PCS_MMD.uKR_CTRL.nReg = uPCS0_PCS_MMD.uKR_CTRL.nReg |   (  1<<10);		// USXG_MODE = 1
	RegWrite(&HwXPCS0_XS_PCS_MMD->uKR_CTRL.nReg, uPCS0_PCS_MMD.uKR_CTRL.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-4-a, 5.3-4-a : PHY Common setting for 156.25MHz reference clock, Table5-1
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_XS_PMA_MMD->uREF_CLK_CTRL.nReg;
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg & (~(0x7<<3));	// REF_RANGE[2:0] masking
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg |	(  6<<3);	// REF_RANGE[2:0]	= 6
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg & (~(0x1<<2));	// REF_CLK_DIV2 masking
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg |	(  0<<2);	// REF_CLK_DIV2 	= 0
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg & (~(0x1<<0));	// REF_CLK_EN masking
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg |	(  1<<0);	// REF_CLK_EN		= 1
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg & (~(0x1<<6));	// REF_MPLLA_DIV2 masking
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg |	(  1<<6);	// REF_MPLLA_DIV2	= 1
	RegWrite(&HwXPCS0_XS_PMA_MMD->uREF_CLK_CTRL.nReg, uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uREF_CLK_CTRL.nReg;
	uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg & (~(0x1<<7));	// REF_MPLLB_DIV2 masking
	uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg |	(  1<<7);	// REF_MPLLB_DIV2	= 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uREF_CLK_CTRL.nReg, uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL0.nReg;
	uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg & (~(0xff<<0 ));	// MPLL_MULTIPLIER masking
	uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg |   (  33<<0 );	// MPLL_MULTIPLIER = 33
	uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg & (~( 0x1<<15));	// MPLL_CAL_DISABLE masking
	uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg |   (   0<<15);	// MPLL_CAL_DISABLE = 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL0.nReg, uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL0.nReg;
	uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg & (~(0xff<<0 ));	// MPLL_MULTIPLIER masking
	uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg |   (  50<<0 );	// MPLL_MULTIPLIER = 50
	uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg & (~( 0x1<<15));	// MPLL_CAL_DISABLE masking
	uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg |   (   0<<15);	// MPLL_CAL_DISABLE = 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL0.nReg, uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL1.nReg;
	uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg & (~(0x7ff<<5));	// MPLL_FRACN_CTRL masking
	uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg |   (    0<<5);	// MPLL_FRACN_CTRL = 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL1.nReg, uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL1.nReg;
	uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg & (~(0x7ff<<5));	// MPLL_FRACN_CTRL masking
	uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg |   (    0<<5);	// MPLL_FRACN_CTRL = 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL1.nReg, uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg);


	addr = &HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL2.nReg;
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~( 0x1<<8 ));	// MPLL_DIV8_CLK_EN masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   0<<8 );	// MPLL_DIV8_CLK_EN 	= 0
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~( 0x1<<9 ));	// MPLL_DIV10_CLK_EN masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   1<<9 );	// MPLL_DIV10_CLK_EN	= 1
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~( 0x1<<10));	// MPLL_DIV16P5_CLK_EN masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   1<<10);	// MPLL_DIV16P5_CLK_EN	= 1
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~( 0x3<<11));	// MPLL_TX_CLK_DIV[1:0] masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   0<<11);	// MPLL_TX_CLK_DIV[1:0] = 0
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~( 0x1<<7 ));	// MPLL_DIV_CLK_EN masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   0<<7 );	// MPLL_DIV_CLK_EN		= 0
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~(0x7f<<0 ));	// MPLL_DIV_MULT[6:0] masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   0<<0 );	// MPLL_DIV_MULT[6:0]	= 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL2.nReg, uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL2.nReg;
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg & (~( 0x1<<8 ));	// MPLL_DIV8_CLK_EN masking
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg |   (   0<<8 );	// MPLL_DIV8_CLK_EN 	= 0
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg & (~( 0x1<<9 ));	// MPLL_DIV10_CLK_EN masking
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg |   (   1<<9 );	// MPLL_DIV10_CLK_EN	= 1
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg & (~( 0x3<<11));	// MPLL_TX_CLK_DIV masking
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg |   (   0<<11);	// MPLL_TX_CLK_DIV		= 0
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg & (~( 0x1<<7 ));	// MPLL_DIV_CLK_EN masking
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg |   (   1<<7 );	// MPLL_DIV_CLK_EN		= 1
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg & (~(0x7f<<0 ));	// MPLL_DIV_MULT masking
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg |   (  12<<0 );	// MPLL_DIV_MULT		= 12
	RegWrite(&HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL2.nReg, uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg);

	uPCS0_PMA_MMD.uMPLLA_CTRL3.nReg = 61970;
	RegWrite(&HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL3.nReg, uPCS0_PMA_MMD.uMPLLA_CTRL3.nReg);	// MPLL_BANDWIDTH = 61970

	uPCS1_PMA_MMD.uMPLLB_CTRL3.nReg = 40967;
	RegWrite(&HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL3.nReg, uPCS1_PMA_MMD.uMPLLB_CTRL3.nReg);	// MPLL_BANDWIDTH = 40967

	addr = &HwXPCS0_XS_PMA_MMD->uTX_GENCTRL1.nReg;
	uPCS0_PMA_MMD.uTX_GENCTRL1.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uTX_GENCTRL1.nReg = uPCS0_PMA_MMD.uTX_GENCTRL1.nReg & (~(0x7<<8));	// VBOOST_LVL masking
	uPCS0_PMA_MMD.uTX_GENCTRL1.nReg = uPCS0_PMA_MMD.uTX_GENCTRL1.nReg |   (  5<<8); 	// VBOOST_LVL = 5
	RegWrite(&HwXPCS0_XS_PMA_MMD->uTX_GENCTRL1.nReg, uPCS0_PMA_MMD.uTX_GENCTRL1.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uMISC_CTRL0.nReg;
	uPCS0_PMA_MMD.uMISC_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uMISC_CTRL0.nReg = uPCS0_PMA_MMD.uMISC_CTRL0.nReg & (~(0x1f<<8)); 	// RX_VREF_CTRL masking
	uPCS0_PMA_MMD.uMISC_CTRL0.nReg = uPCS0_PMA_MMD.uMISC_CTRL0.nReg |	(  17<<8);		// RX_VREF_CTRL = 17
	RegWrite(&HwXPCS0_XS_PMA_MMD->uMISC_CTRL0.nReg, uPCS0_PMA_MMD.uMISC_CTRL0.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-4-b : PHY Lane-0 Tx/Rx setting by XPCS-0 for USXGMII
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_XS_PMA_MMD->uMPLL_CMN_CTRL.nReg;
	uPCS0_PMA_MMD.uMPLL_CMN_CTRL.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uMPLL_CMN_CTRL.nReg = uPCS0_PMA_MMD.uMPLL_CMN_CTRL.nReg & (~(0x1<<4));	// MPLLB_SEL_0 masking
	uPCS0_PMA_MMD.uMPLL_CMN_CTRL.nReg = uPCS0_PMA_MMD.uMPLL_CMN_CTRL.nReg |   (  0<<4); 	// MPLLB_SEL_0			= 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uMPLL_CMN_CTRL.nReg, uPCS0_PMA_MMD.uMPLL_CMN_CTRL.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uTX_MISC_CTRL0.nReg;
	uPCS0_PMA_MMD.uTX_MISC_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uTX_MISC_CTRL0.nReg = uPCS0_PMA_MMD.uTX_MISC_CTRL0.nReg & (~(0xff<<0));	// TX0_MISC masking
	uPCS0_PMA_MMD.uTX_MISC_CTRL0.nReg = uPCS0_PMA_MMD.uTX_MISC_CTRL0.nReg |   (   0<<0);	// TX0_MISC 			= 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uTX_MISC_CTRL0.nReg, uPCS0_PMA_MMD.uTX_MISC_CTRL0.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uTX_RATE_CTRL.nReg;
	uPCS0_PMA_MMD.uTX_RATE_CTRL.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uTX_RATE_CTRL.nReg = uPCS0_PMA_MMD.uTX_RATE_CTRL.nReg & (~(0x7<<0));		// TX0_RATE masking
	uPCS0_PMA_MMD.uTX_RATE_CTRL.nReg = uPCS0_PMA_MMD.uTX_RATE_CTRL.nReg |	(  1<<0);		// TX0_RATE 			= 1
	RegWrite(&HwXPCS0_XS_PMA_MMD->uTX_RATE_CTRL.nReg, uPCS0_PMA_MMD.uTX_RATE_CTRL.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uTX_GENCTRL2.nReg;
	uPCS0_PMA_MMD.uTX_GENCTRL2.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uTX_GENCTRL2.nReg = uPCS0_PMA_MMD.uTX_GENCTRL2.nReg & (~(0x3<<8));		// TX0_WIDTH masking
	uPCS0_PMA_MMD.uTX_GENCTRL2.nReg = uPCS0_PMA_MMD.uTX_GENCTRL2.nReg |   (  3<<8); 		// TX0_WIDTH			= 3
	RegWrite(&HwXPCS0_XS_PMA_MMD->uTX_GENCTRL2.nReg, uPCS0_PMA_MMD.uTX_GENCTRL2.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uTX_GENCTRL1.nReg;
	uPCS0_PMA_MMD.uTX_GENCTRL1.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uTX_GENCTRL1.nReg = uPCS0_PMA_MMD.uTX_GENCTRL1.nReg & (~(0x1<<4));		// VBOOST_EN_0 masking
	uPCS0_PMA_MMD.uTX_GENCTRL1.nReg = uPCS0_PMA_MMD.uTX_GENCTRL1.nReg |   (  1<<4); 		// VBOOST_EN_0			= 1
	RegWrite(&HwXPCS0_XS_PMA_MMD->uTX_GENCTRL1.nReg, uPCS0_PMA_MMD.uTX_GENCTRL1.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uTX_BOOST_CTRL.nReg;
	uPCS0_PMA_MMD.uTX_BOOST_CTRL.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uTX_BOOST_CTRL.nReg = uPCS0_PMA_MMD.uTX_BOOST_CTRL.nReg & (~(0xf<<0));	// TX0_IBOOST masking
	uPCS0_PMA_MMD.uTX_BOOST_CTRL.nReg = uPCS0_PMA_MMD.uTX_BOOST_CTRL.nReg |   ( 15<<0); 	// TX0_IBOOST			= 15
	RegWrite(&HwXPCS0_XS_PMA_MMD->uTX_BOOST_CTRL.nReg, uPCS0_PMA_MMD.uTX_BOOST_CTRL.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uVCO_CAL_LD0.nReg;
	uPCS0_PMA_MMD.uVCO_CAL_LD0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uVCO_CAL_LD0.nReg = uPCS0_PMA_MMD.uVCO_CAL_LD0.nReg & (~(0x1fff<<0)); 	// VCO_LD_VAL_0 masking
	uPCS0_PMA_MMD.uVCO_CAL_LD0.nReg = uPCS0_PMA_MMD.uVCO_CAL_LD0.nReg |   (  1353<<0);		// VCO_LD_VAL_0 		= 1353
	RegWrite(&HwXPCS0_XS_PMA_MMD->uVCO_CAL_LD0.nReg, uPCS0_PMA_MMD.uVCO_CAL_LD0.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uVCO_CAL_REF0.nReg;
	uPCS0_PMA_MMD.uVCO_CAL_REF0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uVCO_CAL_REF0.nReg = uPCS0_PMA_MMD.uVCO_CAL_REF0.nReg & (~(0x7f<<0)); 	// VCO_REF_LD_0 masking
	uPCS0_PMA_MMD.uVCO_CAL_REF0.nReg = uPCS0_PMA_MMD.uVCO_CAL_REF0.nReg |	(  41<<0);		// VCO_REF_LD_0 		= 41
	RegWrite(&HwXPCS0_XS_PMA_MMD->uVCO_CAL_REF0.nReg, uPCS0_PMA_MMD.uVCO_CAL_REF0.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_RATE_CTRL.nReg;
	uPCS0_PMA_MMD.uRX_RATE_CTRL.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_RATE_CTRL.nReg = uPCS0_PMA_MMD.uRX_RATE_CTRL.nReg & (~(0x3<<0));		// RX0_RATE masking
	uPCS0_PMA_MMD.uRX_RATE_CTRL.nReg = uPCS0_PMA_MMD.uRX_RATE_CTRL.nReg |	(  1<<0);		// RX0_RATE 			= 1
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_RATE_CTRL.nReg, uPCS0_PMA_MMD.uRX_RATE_CTRL.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_GENCTRL1.nReg;
	uPCS0_PMA_MMD.uRX_GENCTRL1.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_GENCTRL1.nReg = uPCS0_PMA_MMD.uRX_GENCTRL1.nReg & (~(0x1<<12));		// RX_DIV16P5_CLK_EN_0 masking
	uPCS0_PMA_MMD.uRX_GENCTRL1.nReg = uPCS0_PMA_MMD.uRX_GENCTRL1.nReg |   (  1<<12);		// RX_DIV16P5_CLK_EN_0	= 1
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_GENCTRL1.nReg, uPCS0_PMA_MMD.uRX_GENCTRL1.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_GENCTRL2.nReg;
	uPCS0_PMA_MMD.uRX_GENCTRL2.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_GENCTRL2.nReg = uPCS0_PMA_MMD.uRX_GENCTRL2.nReg & (~(0x3<<8));		// RX0_WIDTH masking
	uPCS0_PMA_MMD.uRX_GENCTRL2.nReg = uPCS0_PMA_MMD.uRX_GENCTRL2.nReg |   (  3<<8); 		// RX0_WIDTH			= 3
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_GENCTRL2.nReg, uPCS0_PMA_MMD.uRX_GENCTRL2.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_GENCTRL3.nReg;
	uPCS0_PMA_MMD.uRX_GENCTRL3.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_GENCTRL3.nReg = uPCS0_PMA_MMD.uRX_GENCTRL3.nReg & (~(0x7<<0));		// RX_THSHLD_0 masking
	uPCS0_PMA_MMD.uRX_GENCTRL3.nReg = uPCS0_PMA_MMD.uRX_GENCTRL3.nReg |   (  1<<0); 		// RX_THSHLD_0			= 1
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_GENCTRL3.nReg, uPCS0_PMA_MMD.uRX_GENCTRL3.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_GENCTRL4.nReg;
	uPCS0_PMA_MMD.uRX_GENCTRL4.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_GENCTRL4.nReg = uPCS0_PMA_MMD.uRX_GENCTRL4.nReg & (~(0x1<<8));		// RX_DFE_BYP_0 masking
	uPCS0_PMA_MMD.uRX_GENCTRL4.nReg = uPCS0_PMA_MMD.uRX_GENCTRL4.nReg |   (  0<<8); 		// RX_DFE_BYP_0 		= 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_GENCTRL4.nReg, uPCS0_PMA_MMD.uRX_GENCTRL4.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_EQ_CTRL0.nReg;
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg & (~( 0x7<<12));		// VGA1_GAIN_0 masking
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   5<<12);		// VGA1_GAIN_0			= 5
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg & (~( 0x7<<8 ));		// VGA2_GAIN_0 masking
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   5<<8 );		// VGA2_GAIN_0			= 5
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg & (~(0x1f<<0 ));		// CTLE_BOOST_0 masking
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg |   (  14<<0 );		// CTLE_BOOST_0 		= 14
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg & (~( 0x3<<5 ));		// CTLE_POLE_0 masking
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   0<<5 );		// CTLE_POLE_0			= 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_EQ_CTRL0.nReg, uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_EQ_CTRL5.nReg;
	uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg & (~(0x3<<4));		// RX0_ADPT_MODE masking
	uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg |   (  3<<4); 		// RX0_ADPT_MODE		= 3
	uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg & (~(0x1<<0));		// RX_ADPT_SEL_0 masking
	uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg |   (  0<<0); 		// RX_ADPT_SEL_0		= 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_EQ_CTRL5.nReg, uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_CDR_CTRL1.nReg;
	uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg & (~(0x1<<4));		// VCO_STEP_CTRL_0 masking
	uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg |	(  1<<4);		// VCO_STEP_CTRL_0		= 1
	uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg & (~(0x1<<0));		// VCO_TEMP_COMP_EN_0 masking
	uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg |	(  1<<0);		// VCO_TEMP_COMP_EN_0	= 1
	uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg & (~(0x3<<8));		// VCO_FRQBAND_0 masking
	uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg |	(  1<<8);		// VCO_FRQBAND_0		= 1
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_CDR_CTRL1.nReg, uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_MISC_CTRL0.nReg;
	uPCS0_PMA_MMD.uRX_MISC_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_MISC_CTRL0.nReg = uPCS0_PMA_MMD.uRX_MISC_CTRL0.nReg & (~(0xff<<0));	// RX0_MISC masking
	uPCS0_PMA_MMD.uRX_MISC_CTRL0.nReg = uPCS0_PMA_MMD.uRX_MISC_CTRL0.nReg |   (   4<<0);	// RX0_MISS 			= 4
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_MISC_CTRL0.nReg, uPCS0_PMA_MMD.uRX_MISC_CTRL0.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_IQ_CTRL0.nReg;
	uPCS0_PMA_MMD.uRX_IQ_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_IQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_IQ_CTRL0.nReg & (~(0xf<<8));		// RX0_DELTA_IQ masking
	uPCS0_PMA_MMD.uRX_IQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_IQ_CTRL0.nReg |   (  0<<8); 		// RX0_DELTA_IQ 		= 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_IQ_CTRL0.nReg, uPCS0_PMA_MMD.uRX_IQ_CTRL0.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_ATTN_CTRL.nReg;
	uPCS0_PMA_MMD.uRX_ATTN_CTRL.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_ATTN_CTRL.nReg = uPCS0_PMA_MMD.uRX_ATTN_CTRL.nReg & (~(0x7<<0));		// RX0_EQ_ATT_LVL masking
	uPCS0_PMA_MMD.uRX_ATTN_CTRL.nReg = uPCS0_PMA_MMD.uRX_ATTN_CTRL.nReg |	(  0<<0);		// RX0_EQ_ATT_LVL		= 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_ATTN_CTRL.nReg, uPCS0_PMA_MMD.uRX_ATTN_CTRL.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uDFE_TAP_CTRL0.nReg;
	uPCS0_PMA_MMD.uDFE_TAP_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uDFE_TAP_CTRL0.nReg = uPCS0_PMA_MMD.uDFE_TAP_CTRL0.nReg & (~(0xff<<0));	// DFE_TAP1_0 masking
	uPCS0_PMA_MMD.uDFE_TAP_CTRL0.nReg = uPCS0_PMA_MMD.uDFE_TAP_CTRL0.nReg |   (   0<<0);	// DFE_TAP1_0			= 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uDFE_TAP_CTRL0.nReg, uPCS0_PMA_MMD.uDFE_TAP_CTRL0.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_PPM_CTRL0.nReg;
	uPCS0_PMA_MMD.uRX_PPM_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_PPM_CTRL0.nReg = uPCS0_PMA_MMD.uRX_PPM_CTRL0.nReg & (~(0x1f<<0)); 	// RX0_CDR_PPM_MAX masking
	uPCS0_PMA_MMD.uRX_PPM_CTRL0.nReg = uPCS0_PMA_MMD.uRX_PPM_CTRL0.nReg |	(  18<<0);		// RX0_CDR_PPM_MAX		= 18
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_PPM_CTRL0.nReg, uPCS0_PMA_MMD.uRX_PPM_CTRL0.nReg);


#ifdef LOOPBACK_L
	//----------------------------------------------------------------------------------------------------------------------------
	// PHY lane-0(5.0Gbps) Serial Loopback enable
	//----------------------------------------------------------------------------------------------------------------------------
	mcu_printf("LOOPBACK enable\n");
	addr = &HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);

	uPCS0_SR_MII_MMD.uMII_CTRL.nReg = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<14));		 // LBE masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<14);		// LBE = 1
	RegWrite(&HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg, uPCS0_SR_MII_MMD.uMII_CTRL.nReg);
#endif




	//----------------------------------------------------------------------------------------------------------------------------
	// Programming Sequece for SGMII Mode
	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3-1 : SR_XS_PCS_CTRL2[3:0] register to 4'b0001 (10GBASE-X PCS Type)
	addr = &HwXPCS1_XS_PCS_MMD->uCTRL2.nReg;
	uPCS1_PCS_MMD.uCTRL2.nReg = RegRead(addr);
	uPCS1_PCS_MMD.uCTRL2.nReg = uPCS1_PCS_MMD.uCTRL2.nReg & (~(0xf<<0));			// PCS_TYPE_SEL[3:0] masking
	uPCS1_PCS_MMD.uCTRL2.nReg = uPCS1_PCS_MMD.uCTRL2.nReg |   (  1<<0); 			// PCS_TYPE_SEL[3:0] = 1
	RegWrite(&HwXPCS1_XS_PCS_MMD->uCTRL2.nReg, uPCS1_PCS_MMD.uCTRL2.nReg);

	// 5.3-2 : SR_MII_CTRL{[13], [6], [5]} register to {0, 1, 0} (Speed Selection : 1000 Mbps)
	addr = &HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<5 ));	// SS5 masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  0<<5 );	// SS5 = 0
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<6 ));	// SS6 masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<6 );	// SS6 = 1
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<13));	// SS13 masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  0<<13);	// SS13 = 0
	RegWrite(&HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg, uPCS1_SR_MII_MMD.uMII_CTRL.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3-3-b : PHY Lane-1 Tx/Rx setting by XPCS-1 for SGMII
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS1_XS_PMA_MMD->uMPLL_CMN_CTRL.nReg;
	uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg = uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg & (~(0x1<<4));	// MPLLB_SEL_0 masking
	uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg = uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg |   (  1<<4); 	// MPLLB_SEL_0			= 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uMPLL_CMN_CTRL.nReg, uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_MISC_CTRL0.nReg;
	uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg = uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg & (~(0xff<<0));	// TX0_MISC masking
	uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg = uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg |   (   0<<0);	// TX0_MISC 			= 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_MISC_CTRL0.nReg, uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_RATE_CTRL.nReg;
	uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg = uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg & (~(0x7<<0));		// TX0_RATE masking
	uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg = uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg |	(  5<<0);		// TX0_RATE 			= 5
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_RATE_CTRL.nReg, uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_GENCTRL2.nReg;
	uPCS1_PMA_MMD.uTX_GENCTRL2.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_GENCTRL2.nReg = uPCS1_PMA_MMD.uTX_GENCTRL2.nReg & (~(0x3<<8));		// TX0_WIDTH masking
	uPCS1_PMA_MMD.uTX_GENCTRL2.nReg = uPCS1_PMA_MMD.uTX_GENCTRL2.nReg |   (  1<<8); 		// TX0_WIDTH			= 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_GENCTRL2.nReg, uPCS1_PMA_MMD.uTX_GENCTRL2.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_GENCTRL1.nReg;
	uPCS1_PMA_MMD.uTX_GENCTRL1.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_GENCTRL1.nReg = uPCS1_PMA_MMD.uTX_GENCTRL1.nReg & (~(0x1<<4));		// VBOOST_EN_0 masking
	uPCS1_PMA_MMD.uTX_GENCTRL1.nReg = uPCS1_PMA_MMD.uTX_GENCTRL1.nReg |   (  1<<4); 		// VBOOST_EN_0			= 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_GENCTRL1.nReg, uPCS1_PMA_MMD.uTX_GENCTRL1.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_BOOST_CTRL.nReg;
	uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg = uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg & (~(0xf<<0));	// TX0_IBOOST masking
	uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg = uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg |   ( 15<<0); 	// TX0_IBOOST			= 15
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_BOOST_CTRL.nReg, uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uVCO_CAL_LD0.nReg;
	uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg = uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg & (~(0x1fff<<0)); 	// VCO_LD_VAL_0 masking
	uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg = uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg |   (  1360<<0);		// VCO_LD_VAL_0 		= 1360
	RegWrite(&HwXPCS1_XS_PMA_MMD->uVCO_CAL_LD0.nReg, uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uVCO_CAL_REF0.nReg;
	uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg = uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg & (~(0x7f<<0)); 	// VCO_REF_LD_0 masking
	uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg = uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg |	(  34<<0);		// VCO_REF_LD_0 		= 34
	RegWrite(&HwXPCS1_XS_PMA_MMD->uVCO_CAL_REF0.nReg, uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_RATE_CTRL.nReg;
	uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg = uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg & (~(0x3<<0));		// RX0_RATE masking
	uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg = uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg |	(  2<<0);		// RX0_RATE 			= 2
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_RATE_CTRL.nReg, uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_GENCTRL1.nReg;
	uPCS1_PMA_MMD.uRX_GENCTRL1.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_GENCTRL1.nReg = uPCS1_PMA_MMD.uRX_GENCTRL1.nReg & (~(0x1<<12));		// RX_DIV16P5_CLK_EN_0 masking
	uPCS1_PMA_MMD.uRX_GENCTRL1.nReg = uPCS1_PMA_MMD.uRX_GENCTRL1.nReg |   (  0<<12);		// RX_DIV16P5_CLK_EN_0	= 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_GENCTRL1.nReg, uPCS1_PMA_MMD.uRX_GENCTRL1.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_GENCTRL2.nReg;
	uPCS1_PMA_MMD.uRX_GENCTRL2.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_GENCTRL2.nReg = uPCS1_PMA_MMD.uRX_GENCTRL2.nReg & (~(0x3<<8));		// RX0_WIDTH masking
	uPCS1_PMA_MMD.uRX_GENCTRL2.nReg = uPCS1_PMA_MMD.uRX_GENCTRL2.nReg |   (  1<<8); 		// RX0_WIDTH			= 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_GENCTRL2.nReg, uPCS1_PMA_MMD.uRX_GENCTRL2.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_GENCTRL3.nReg;
	uPCS1_PMA_MMD.uRX_GENCTRL3.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_GENCTRL3.nReg = uPCS1_PMA_MMD.uRX_GENCTRL3.nReg & (~(0x7<<0));		// RX_THSHLD_0 masking
	uPCS1_PMA_MMD.uRX_GENCTRL3.nReg = uPCS1_PMA_MMD.uRX_GENCTRL3.nReg |   (  1<<0); 		// RX_THSHLD_0			= 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_GENCTRL3.nReg, uPCS1_PMA_MMD.uRX_GENCTRL3.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_GENCTRL4.nReg;
	uPCS1_PMA_MMD.uRX_GENCTRL4.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_GENCTRL4.nReg = uPCS1_PMA_MMD.uRX_GENCTRL4.nReg & (~(0x1<<8));		// RX_DFE_BYP_0 masking
	uPCS1_PMA_MMD.uRX_GENCTRL4.nReg = uPCS1_PMA_MMD.uRX_GENCTRL4.nReg |   (  1<<8); 		// RX_DFE_BYP_0 		= 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_GENCTRL4.nReg, uPCS1_PMA_MMD.uRX_GENCTRL4.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_EQ_CTRL0.nReg;
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg & (~( 0x7<<12));		// VGA1_GAIN_0 masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   4<<12);		// VGA1_GAIN_0			= 4
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg & (~( 0x7<<8 ));		// VGA2_GAIN_0 masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   4<<8 );		// VGA2_GAIN_0			= 4
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg & (~(0x1f<<0 ));		// CTLE_BOOST_0 masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   6<<0 );		// CTLE_BOOST_0 		= 6
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg & (~( 0x3<<5 ));		// CTLE_POLE_0 masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   0<<5 );		// CTLE_POLE_0			= 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_EQ_CTRL0.nReg, uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_EQ_CTRL5.nReg;
	uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg & (~(0x3<<4));		// RX0_ADPT_MODE masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg |   (  0<<4); 		// RX0_ADPT_MODE		= 0
	uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg & (~(0x1<<0));		// RX_ADPT_SEL_0 masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg |   (  0<<0); 		// RX_ADPT_SEL_0		= 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_EQ_CTRL5.nReg, uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_CDR_CTRL1.nReg;
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg & (~(0x1<<4));		// VCO_STEP_CTRL_0 masking
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg |	(  1<<4);		// VCO_STEP_CTRL_0		= 1
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg & (~(0x1<<0));		// VCO_TEMP_COMP_EN_0 masking
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg |	(  0<<0);		// VCO_TEMP_COMP_EN_0	= 0
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg & (~(0x3<<8));		// VCO_FRQBAND_0 masking
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg |	(  2<<8);		// VCO_FRQBAND_0		= 2
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_CDR_CTRL1.nReg, uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_MISC_CTRL0.nReg;
	uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg = uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg & (~(0xff<<0));	// RX0_MISC masking
	uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg = uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg |   (   7<<0);	// RX0_MISS 			= 7
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_MISC_CTRL0.nReg, uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_IQ_CTRL0.nReg;
	uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg & (~(0xf<<8));		// RX0_DELTA_IQ masking
	uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg |   (  0<<8); 		// RX0_DELTA_IQ 		= 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_IQ_CTRL0.nReg, uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_ATTN_CTRL.nReg;
	uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg = uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg & (~(0x7<<0));		// RX0_EQ_ATT_LVL masking
	uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg = uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg |	(  0<<0);		// RX0_EQ_ATT_LVL		= 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_ATTN_CTRL.nReg, uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uDFE_TAP_CTRL0.nReg;
	uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg = uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg & (~(0xff<<0));	// DFE_TAP1_0 masking
	uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg = uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg |   (   0<<0);	// DFE_TAP1_0			= 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uDFE_TAP_CTRL0.nReg, uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_PPM_CTRL0.nReg;
	uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg = uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg & (~(0x1f<<0)); 	// RX0_CDR_PPM_MAX masking
	uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg = uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg |	(  18<<0);		// RX0_CDR_PPM_MAX		= 18
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_PPM_CTRL0.nReg, uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg);






	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-5 ~ 5.2-6 : PHY Reset assertion and readback check
	// 5.3-5 ~ 5.3-6 : PHY Reset assertion and readback check
	//----------------------------------------------------------------------------------------------------------------------------
	mcu_printf("PHY reset asserted\n");
	addr = &HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg;
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = RegRead(addr);
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg & (~(0x1<<15));			// VR_RST masking
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg |   (  1<<15);			// VR_RST = 1
	RegWrite(&HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg, uPCS0_PCS_MMD.uDIG_CTRL1.nReg);			// PHY reset only is controlled by XPCS-0

	mcu_printf("Wait for PHY reset done\n");
	do{
		addr = &HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg;
		uPCS0_PCS_MMD.uDIG_CTRL1.nReg = RegRead(addr);
	}while((uPCS0_PCS_MMD.uDIG_CTRL1.nReg & (0x1<<15)) != (0x0<<15));
	mcu_printf("Complete PHY reset\n");

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-7 : SUPRESS_LOS_DET(Suppress Loss of Signal Detection) = 1, This bit controls the behavior of xpcs_rx_data_en_o(lane) output from DWC_xpcs.
	//		   RX_SYNC_CTL (Receive Synchronization Control)
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_XS_PCS_MMD->uDEBUG_CTRL.nReg;
	uPCS0_PCS_MMD.uDEBUG_CTRL.nReg = RegRead(addr);
//	uPCS0_PCS_MMD.uDEBUG_CTRL.nReg = uPCS0_PCS_MMD.uDEBUG_CTRL.nReg & (~(0x1<<7));			// RX_SYNC_CTL maksing
//	uPCS0_PCS_MMD.uDEBUG_CTRL.nReg = uPCS0_PCS_MMD.uDEBUG_CTRL.nReg |	(  1<<7);			// RX_SYNC_CTL		= 1
	uPCS0_PCS_MMD.uDEBUG_CTRL.nReg = uPCS0_PCS_MMD.uDEBUG_CTRL.nReg & (~(0x1<<6));			// RX_DT_EN_CTL maksing
	uPCS0_PCS_MMD.uDEBUG_CTRL.nReg = uPCS0_PCS_MMD.uDEBUG_CTRL.nReg |	(  1<<6);			// RX_DT_EN_CTL		= 1
	uPCS0_PCS_MMD.uDEBUG_CTRL.nReg = uPCS0_PCS_MMD.uDEBUG_CTRL.nReg & (~(0x1<<4));			// SUPRESS_LOS_DET masking
	uPCS0_PCS_MMD.uDEBUG_CTRL.nReg = uPCS0_PCS_MMD.uDEBUG_CTRL.nReg |	(  1<<4);			// SUPRESS_LOS_DET	= 1
	RegWrite(&HwXPCS0_XS_PCS_MMD->uDEBUG_CTRL.nReg, uPCS0_PCS_MMD.uDEBUG_CTRL.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-8 : Wait for PHY DPLL Lock Status for Lane-0(RX_VALID_0)
	//----------------------------------------------------------------------------------------------------------------------------
	mcu_printf("Wait for PHY DPLL Lock Status for Lane-0(RX_LSTS.RX_VALID_0) done\n");
#if 1
	do{
		addr = &HwXPCS0_XS_PMA_MMD->uRX_LSTS.nReg;
		uPCS0_PMA_MMD.uRX_LSTS.nReg = RegRead(addr);
	}while((uPCS0_PMA_MMD.uRX_LSTS.nReg & (0x1<<12)) != (0x1<<12));
#else
	addr = &HwXPCS0_XS_PMA_MMD->uRX_LSTS.nReg;
	uPCS0_PMA_MMD.uRX_LSTS.nReg = RegRead(addr);

	mcu_printf("[%s][%d] :: 0x%x\n", __func__, __LINE__, uPCS0_PMA_MMD.uRX_LSTS.nReg );
#endif

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-9 : Receive Adaptation Request(RX_EQ_CTRL4.RX_AD_REQ) set
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_XS_PMA_MMD->uRX_EQ_CTRL4.nReg;
	uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg & (~(0x1<<12));		// RX_AD_REQ masking
	uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg |   (  1<<12);		// RX_AD_REQ = 1
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_EQ_CTRL4.nReg, uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-10 : Wait for Receive Adaptation Acknowledgement from PHY
	//----------------------------------------------------------------------------------------------------------------------------
	mcu_printf("Wait for PHY Receive Adaptation Acknowledgement(MISC_STS.RX_ADPT_ACK) done\n");
	do{
		addr = &HwXPCS0_XS_PMA_MMD->uMISC_STS.nReg;
		uPCS0_PMA_MMD.uMISC_STS.nReg = RegRead(addr);
	}while((uPCS0_PMA_MMD.uMISC_STS.nReg & (0x1<<12)) != (0x1<<12));

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-11 : Receive Adaptation Request(RX_EQ_CTRL4.RX_AD_REQ) clear
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_XS_PMA_MMD->uRX_EQ_CTRL4.nReg;
	uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg & (~(0x1<<12));		// RX_AD_REQ masking
	uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg |   (  0<<12);		// RX_AD_REQ = 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_EQ_CTRL4.nReg, uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg);






	//----------------------------------------------------------------------------------------------------------------------------
	// Tx. Equalization control register setting
	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3-7 : uTX_EQ_CTRL0.TX_EQ_PRE	= 0,	Tx Pre-Emphasis level adjustment Control
	// 5.3-8 : uTX_EQ_CTRL0.TX_EQ_MAIN	= 32,	Control for setting Tx driver output amplitude
	// 5.3-9 : uTX_EQ_CTRL1.TX_EQ_POST	= 32,	Tx Post-Emphasis level adjustment Control
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS1_XS_PMA_MMD->uTX_EQ_CTRL0.nReg;
	uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg & (~(0x3f<<0));		// RX_EQ_PRE masking
	uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg |   (   0<<0);		// RX_EQ_PRE	= 0
	uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg & (~(0x3f<<8));		// RX_EQ_MAIN masking
	uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg |   (  32<<8);		// RX_EQ_MAIN	= 32
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_EQ_CTRL0.nReg, uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_EQ_CTRL1.nReg;
	uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg & (~(0x3f<<0));		// RX_EQ_POST masking
	uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg |   (  32<<0);		// RX_EQ_POST	= 32
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_EQ_CTRL1.nReg, uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg);







#ifdef AN_EN_5P0G
	//============================================================================================================================
	// USXGMII Auto-negotiation
	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	mcu_printf("5Gbps USXGMII Auto-negotiation setting start\n");

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-1 : Auto-negotiation control register setting
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_VR_MII_MMD->uAN_CTRL.nReg;
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = RegRead(addr);
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = uPCS0_VR_MII_MMD.uAN_CTRL.nReg & (~(0x1<<0));			// MII_AN_INTR_EN masking
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = uPCS0_VR_MII_MMD.uAN_CTRL.nReg |	(  1<<0);			// MII_AN_INTR_EN	= 1,	Clause 37 Auto-negotiation complete interrupt enable = Enable
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = uPCS0_VR_MII_MMD.uAN_CTRL.nReg & (~(0x1<<8));			// MII_CTRL masking
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = uPCS0_VR_MII_MMD.uAN_CTRL.nReg |	(  1<<8);			// MII_CTRL 		= 1,	MII Control					= 8-bit MII
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = uPCS0_VR_MII_MMD.uAN_CTRL.nReg & (~(0x1<<3));			// TX_CONFIG masking
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = uPCS0_VR_MII_MMD.uAN_CTRL.nReg |	(  1<<3);			// TX_CONFIG		= 1,	Transmission Configuration	= Configures the DWC_xpcs as the PHY side USXGMII
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = uPCS0_VR_MII_MMD.uAN_CTRL.nReg & (~(0x1<<4));			// SGMII_LINK_STS masking
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = uPCS0_VR_MII_MMD.uAN_CTRL.nReg |	(  1<<4);			// SGMII_LINK_STS	= 1,	USXGMII Link Status 		= Link-up
	RegWrite(&HwXPCS0_VR_MII_MMD->uAN_CTRL.nReg, uPCS0_VR_MII_MMD.uAN_CTRL.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-2 : (Optional) Link timer setting
	//----------------------------------------------------------------------------------------------------------------------------
	// TODO VR_MII_LINK_TIMER_CTRL
	// TODO VR_MII_DIG_CTRL1.CL47_TMR_OVR_RIDE (Over-Ride control for CL37 Link Timer)

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-3 : Speed selection,		  SR_MII_CTRL.SS5/SS6/SS13
	// 5.2.1-4 : Auto-negotiation enable, SR_MII_CTRL.AN_ENABLE
	//----------------------------------------------------------------------------------------------------------------------------
	// Speed selection {SS5, SS6, SS13} = {1, 0, 1} = Speed is 5Gbps
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<< 5));		// SS5 masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  1<< 5);		// SS5			= 1
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<< 6));		// SS6 masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  0<< 6);		// SS6			= 0
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<13));		// SS13 masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<13);		// SS13 		= 1
	RegWrite(&HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg, uPCS0_SR_MII_MMD.uMII_CTRL.nReg);

	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<12));		// AN_ENABLE masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<12);		// AN_ENABLE	= 1
	RegWrite(&HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg, uPCS0_SR_MII_MMD.uMII_CTRL.nReg);

#if 1
	mcu_printf("Wait for PHY Link-up\n");
	do{
		addr = &HwXPCS0_XS_PCS_MMD->uPCS_STS.nReg;
		uPCS0_PCS_MMD.uPCS_STS.nReg = RegRead(addr);
	}while((uPCS0_PCS_MMD.uPCS_STS.nReg & (0x1<<2)) != (0x1<<2));
	mcu_printf("Complete PHY Link-up\n");
#endif


	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-5,6 : Wait for Auto-negotiation interrupt
	//----------------------------------------------------------------------------------------------------------------------------
#if 0
	mcu_printf("Wait for Auto-negotiation interrupt\n");
	do{
		addr = &HwXPCS0_VR_MII_MMD->uAN_INTR_STS.nReg;
		uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg = RegRead(addr);
	}while((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x1<<0)) != (0x1<<0));
	mcu_printf("Complete Auto-negotiation interrupt\n");
#else
	addr = &HwXPCS0_VR_MII_MMD->uAN_INTR_STS.nReg;
	uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg = RegRead(addr);
	mcu_printf("Auto-negotiation interrupt status :: 0x%x\n", uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg);
#endif

	// Clause 37 AN USXGMII port status
	if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x1<<8)) == (1<<8)) {
		mcu_printf("5.0G PHY Lane-0 AN result : EEE clock-stop supported.\n");
	} else {
		mcu_printf("5.0G PHY Lane-0 AN result : EEE clock-stop not supported.\n");
	}

	if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x1<<9)) == (1<<9)) {
		mcu_printf("5.0G PHY Lane-0 AN result : EEE supported.\n");
	} else {
		mcu_printf("5.0G PHY Lane-0 AN result : EEE not supported.\n");
	}

	if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x7<<10)) == (0<<10)) {
		mcu_printf("5.0G PHY Lane-1 AN result : 10 Mbps speed link\n");
	}else if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x7<<10)) == (1<<10)) {
		mcu_printf("5.0G PHY Lane-0 AN result : 100 Mbps speed link\n");
	}else if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x7<<10)) == (2<<10)) {
		mcu_printf("5.0G PHY Lane-0 AN result : 1000 Mbps speed link\n");
	}else if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x7<<10)) == (3<<10)) {
		mcu_printf("5.0G PHY Lane-0 AN result : 10 Gbps speed link\n");
	}else if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x7<<10)) == (4<<10)) {
		mcu_printf("5.0G PHY Lane-0 AN result : 2.5 Gbps speed link\n");
	}else if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x7<<10)) == (5<<10)) {
		mcu_printf("5.0G PHY Lane-0 AN result : 5 Gbps speed link\n");
	}else{
		mcu_printf("5.0G PHY Lane-0 AN result : Error, Link speed not supported.\n");
	}

	if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x1<<13)) == (1<<13)) {
		mcu_printf("5.0G PHY Lane-0 AN result : Full duplex\n");
	} else {
		mcu_printf("5.0G PHY Lane-0 AN result : Half duplex\n");
	}

	if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x1<<14)) == (1<<14)) {
		mcu_printf("5.0G PHY Lane-0 AN result : Link up\n");
	} else {
		mcu_printf("5.0G PHY Lane-0 AN result : Link down\n");
	}

	SAL_TaskSleep(100);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-7 : Clear to Auto-negotiation interrupt
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_VR_MII_MMD->uAN_INTR_STS.nReg;
	uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg = RegRead(addr);
	uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg = uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg &  (~(0x1<<0)); 	// CL37_ANCMPLT_INTR masking
	uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg = uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg |	 (	0<<0);		// CL37_ANCMPLT_INTR = 0
	RegWrite(&HwXPCS0_VR_MII_MMD->uAN_INTR_STS.nReg, uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-8 : Skip, This step is required only if DWC_xpcs is configured as MAC-side USXGMII
	//----------------------------------------------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-9 : Wait for 1us st that XGMII clocks(clk_xgmii_tx_i/clk_xgmii_rx_i) get stabilized at the desired frequencies
	//----------------------------------------------------------------------------------------------------------------------------
	SAL_TaskSleep(100);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-10 : PCS_DIG_CTRL1.USRA_RST(USXGMII Rate Adapter Reset), This bit can be set to 1 to reset/initialize the USXGMII Rate Adaption(Port 0) indide DWC_xpcs.
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg;
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = RegRead(addr);
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg & (~(0x1<<10));				// USRA_RST masking
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg |   (  1<<10);				// USRA_RST = 1
	RegWrite(&HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg, uPCS0_PCS_MMD.uDIG_CTRL1.nReg);
#if 1
	do{
		addr = &HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg;
		uPCS0_PCS_MMD.uDIG_CTRL1.nReg = RegRead(addr);
	}while((uPCS0_PCS_MMD.uDIG_CTRL1.nReg & (0x1<<10)) != (0<<10));
#endif
	SAL_TaskSleep(100);

	mcu_printf("5Gbps USXGMII Auto-negotiation enable setting done\n");
#else
	// Auto-negotiation disable
	addr = &HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<12));		// AN_ENABLE masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  0<<12);		// AN_ENABLE	= 0
	RegWrite(&HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg, uPCS0_SR_MII_MMD.uMII_CTRL.nReg);

	addr = &HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<< 5));		// SS5 masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  1<< 5);		// SS5			= 1
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<< 6));		// SS6 masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  0<< 6);		// SS6			= 0
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<13));		// SS13 masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<13);		// SS13 		= 1
	RegWrite(&HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg, uPCS0_SR_MII_MMD.uMII_CTRL.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-9 : Wait for 1us st that XGMII clocks(clk_xgmii_tx_i/clk_xgmii_rx_i) get stabilized at the desired frequencies
	//----------------------------------------------------------------------------------------------------------------------------
	SAL_TaskSleep(100);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-10 : PCS_DIG_CTRL1.USRA_RST(USXGMII Rate Adapter Reset), This bit can be set to 1 to reset/initialize the USXGMII Rate Adaption(Port 0) indide DWC_xpcs.
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg;
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = RegRead(addr);
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg & (~(0x1<<10));				// USRA_RST masking
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg |   (  1<<10);				// USRA_RST = 1
	RegWrite(&HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg, uPCS0_PCS_MMD.uDIG_CTRL1.nReg);

#if 1
	do{
		addr = &HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg;
		uPCS0_PCS_MMD.uDIG_CTRL1.nReg = RegRead(addr);
	}while((uPCS0_PCS_MMD.uDIG_CTRL1.nReg & (0x1<<10)) != (0<<10));
#endif

	SAL_TaskSleep(100);

	mcu_printf("5Gbps USXGMII Auto-negotiation disable setting done\n");
#endif	// AN_EN_5P0G
}

void Serdes_init_XpXG(void)
{
	unsigned long addr;
	unsigned int val;

	mcu_printf("\n[%s] START\n", __func__);

	//----------------------------------------------------------------------------------------------------------------------------
	// TPA_CSR.TPA_CLK_DIV_CSR : Divider-2/4 enable and request
	//----------------------------------------------------------------------------------------------------------------------------
	// [15:10] : DIV4_DIV = 3
	// [	9] : DIV4_REQ = 1
	// [	8] : DIV4_EN  = 1
	// [ 7: 2] : DIV2_DIV = 1
	// [	1] : DIV2_REQ = 1
	// [	0] : DIV2_EN  = 1
	//----------------------------------------------------------------------------------------------------------------------------
	RegWrite(HwTPA_CLK_DIV_CSR, ((3<<10) | (1<<9) | (1<<8) | (1<<2) | (1<<1) | (1<<0)));

	//----------------------------------------------------------------------------------------------------------------------------
	// TPA_CSR.SW_RST_CTRL : TPA 5.0/2.5 Gbps XPCS(XPCS-0/1) software reset
	//----------------------------------------------------------------------------------------------------------------------------
	// [0] : Reseved
	// [1] : TPA GMAC-0 			software reset
	// [2] : TPA GMAC-1 			software reset
	// [3] : TPA XGMAC-0(5.0 Gbps)	software reset
	// [4] : TPA XGMAC-1(2.5 Gbps)	software reset
	// [5] : TPA XPCS-0 (5.0 Gbps)	software reset
	// [6] : TPA XPCS-1 (2.5 Gbps)	software reset
	//----------------------------------------------------------------------------------------------------------------------------
	addr = HwSW_RST_CTRL;
	val = RegRead(addr);							                        // Read SW_RST_CTRL
	val = val & (0xffffffff - ((1<<6) | (1<<5)));	                        // SW_RST_CTRL[6] = 0 XPCS-1 software reset assertion
													                        // SW_RST_CTRL[5] = 0 XPCS-0 software reset assertion
	RegWrite(addr, val);

	SAL_TaskSleep(100); 													// Wait 10us
	RegWrite(HwSW_RST_CTRL, 0xffffffff);									// SW_RST_CTRL[6] = 1 XPCS-1 software reset release
																			// SW_RST_CTRL[5] = 1 XPCS-0 software reset release

	//----------------------------------------------------------------------------------------------------------------------------
	// Wating for PHY RAM initialization
	//----------------------------------------------------------------------------------------------------------------------------
	mcu_printf("Wait for PHY SRAM initialization\n");

    // Wait for PHY SRAM initialization
	do{
		addr = &HwXPCS0_XS_PMA_MMD->uSRAM.nReg;
		uPCS0_PMA_MMD.uSRAM.nReg = RegRead(addr);
		mcu_printf("[%d]SRAM value :: 0x%x\n", __LINE__, uPCS0_PMA_MMD.uSRAM.nReg);
		SAL_TaskSleep(100);
	}while((uPCS0_PMA_MMD.uSRAM.nReg & (0x1<<0)) == (0x0<<0));

    // SRAM External Loading Done = 1
	addr = &HwXPCS0_XS_PMA_MMD->uSRAM.nReg;
	uPCS0_PMA_MMD.uSRAM.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uSRAM.nReg = uPCS0_PMA_MMD.uSRAM.nReg | (1 << 1); 		// 1 bit(EXT_LD_DONE) 1 mask
	RegWrite(&HwXPCS0_XS_PMA_MMD->uSRAM.nReg, uPCS0_PMA_MMD.uSRAM.nReg);

	mcu_printf("Complete PHY SRAM initialization\n");

	// Wait XPCS-0 Soft reset wait done
	do{
		addr = &HwXPCS0_XS_PCS_MMD->uCTRL1.nReg;
		uPCS0_PCS_MMD.uCTRL1.nReg = RegRead(addr);
	}while((uPCS0_PCS_MMD.uCTRL1.nReg & (0x1<<15)) != (0x0<<15));

	// Wait XPCS-1 Soft reset wait done
	do{
		addr = &HwXPCS1_XS_PCS_MMD->uCTRL1.nReg;
		uPCS1_PCS_MMD.uCTRL1.nReg = RegRead(addr);
	}while((uPCS1_PCS_MMD.uCTRL1.nReg & (0x1<<15)) != (0x0<<15));


	mcu_printf("Wait for PHY power-up\n");

	// XPCS-0 initialize PHY wait Power-up
	do{
		addr = &HwXPCS0_XS_PCS_MMD->uDIG_STS.nReg;
		uPCS0_PCS_MMD.uDIG_STS.nReg = RegRead(addr);
	}while((uPCS0_PCS_MMD.uDIG_STS.nReg & (0x7<<2)) != (0x4<<2));

	// XPCS-1 initialize PHY wait Power-up
	do{
		addr = &HwXPCS1_XS_PCS_MMD->uDIG_STS.nReg;
		uPCS1_PCS_MMD.uDIG_STS.nReg = RegRead(addr);
	}while((uPCS1_PCS_MMD.uDIG_STS.nReg & (0x7<<2)) != (0x4<<2));

	mcu_printf("Complete PHY power-up\n");

	//----------------------------------------------------------------------------------------------------------------------------
	// Programming Sequence for USXGMII Mode
	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-1 : SR_XS_PCS_CTRL2[3:0] register to 4'b0000 (10GBASE-R PCS Type)
	addr = &HwXPCS0_XS_PCS_MMD->uCTRL2.nReg;
	uPCS0_PCS_MMD.uCTRL2.nReg = RegRead(addr);
	uPCS0_PCS_MMD.uCTRL2.nReg = uPCS0_PCS_MMD.uCTRL2.nReg & (~(0xf<<0));            // PCS_TYPE_SEL[3:0] masking
	uPCS0_PCS_MMD.uCTRL2.nReg = uPCS0_PCS_MMD.uCTRL2.nReg |   (  0<<0);             // PCS_TYPE_SEL[3:0] = 0
	RegWrite(&HwXPCS0_XS_PCS_MMD->uCTRL2.nReg, uPCS0_PCS_MMD.uCTRL2.nReg);

	// 5.2-2 : VR_XS_PCS_DIG_CTRL1[9](USXG_EN) register to 1
	addr = &HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg;
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = RegRead(addr);
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg & (~(0x1<<9));    // USXG_EN masking
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg |   (  1<<9);     // USXG_EN = 1
	RegWrite(&HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg, uPCS0_PCS_MMD.uDIG_CTRL1.nReg);

	// 5.2-3 : VR_XS_PCS_KR_CTRL(USXG_MODE field) register to 3'b001
	addr = &HwXPCS0_XS_PCS_MMD->uKR_CTRL.nReg;
	uPCS0_PCS_MMD.uKR_CTRL.nReg = RegRead(addr);
	uPCS0_PCS_MMD.uKR_CTRL.nReg = uPCS0_PCS_MMD.uKR_CTRL.nReg & (~(0x7<<10));       // USXG_MODE[2:0] masking
	uPCS0_PCS_MMD.uKR_CTRL.nReg = uPCS0_PCS_MMD.uKR_CTRL.nReg |   (  1<<10);        // USXG_MODE = 1
	RegWrite(&HwXPCS0_XS_PCS_MMD->uKR_CTRL.nReg, uPCS0_PCS_MMD.uKR_CTRL.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// Programming Sequece for SGMII Mode
	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3-1 : SR_XS_PCS_CTRL2[3:0] register to 4'b0001 (10GBASE-X PCS Type)
	addr = &HwXPCS1_XS_PCS_MMD->uCTRL2.nReg;
	uPCS1_PCS_MMD.uCTRL2.nReg = RegRead(addr);
	uPCS1_PCS_MMD.uCTRL2.nReg = uPCS1_PCS_MMD.uCTRL2.nReg & (~(0xf<<0));            // PCS_TYPE_SEL[3:0] masking
	uPCS1_PCS_MMD.uCTRL2.nReg = uPCS1_PCS_MMD.uCTRL2.nReg |   (  1<<0);             // PCS_TYPE_SEL[3:0] = 1
	RegWrite(&HwXPCS1_XS_PCS_MMD->uCTRL2.nReg, uPCS1_PCS_MMD.uCTRL2.nReg);

	// 5.3-3 : SR_MII_CTRL{[13], [6], [5]} register to {0, 1, 0} (Speed Selection : 1000 Mbps)
	addr = &HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<5 ));   // SS5 masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  0<<5 );    // SS5 = 0
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<6 ));   // SS6 masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<6 );    // SS6 = 1
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<13));   // SS13 masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  0<<13);    // SS13 = 0
	RegWrite(&HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg, uPCS1_SR_MII_MMD.uMII_CTRL.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-4-a, 5.3-4-a : PHY Common setting for 156.25MHz reference clock, Table5-1
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_XS_PMA_MMD->uREF_CLK_CTRL.nReg;
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg & (~(0x7<<3));  // REF_RANGE[2:0] masking
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg |   (  6<<3);   // REF_RANGE[2:0]   = 6
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg & (~(0x1<<2));  // REF_CLK_DIV2 masking
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg |   (  0<<2);   // REF_CLK_DIV2     = 0
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg & (~(0x1<<0));  // REF_CLK_EN masking
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg |   (  1<<0);   // REF_CLK_EN       = 1
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg & (~(0x1<<6));  // REF_MPLLA_DIV2 masking
	uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg |   (  1<<6);   // REF_MPLLA_DIV2   = 1
	RegWrite(&HwXPCS0_XS_PMA_MMD->uREF_CLK_CTRL.nReg, uPCS0_PMA_MMD.uREF_CLK_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uREF_CLK_CTRL.nReg;
	uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg & (~(0x1<<7));  // REF_MPLLB_DIV2 masking
	uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg = uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg |   (  1<<7);   // REF_MPLLB_DIV2   = 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uREF_CLK_CTRL.nReg, uPCS1_PMA_MMD.uREF_CLK_CTRL.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL0.nReg;
	uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg & (~(0xff<<0 ));  // MPLL_MULTIPLIER masking
	uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg |   (  33<<0 );   // MPLL_MULTIPLIER = 33
	uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg & (~( 0x1<<15));  // MPLL_CAL_DISABLE masking
	uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg |   (   0<<15);   // MPLL_CAL_DISABLE = 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL0.nReg, uPCS0_PMA_MMD.uMPLLA_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL0.nReg;
	uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg & (~(0xff<<0 ));  // MPLL_MULTIPLIER masking
	uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg |   (  50<<0 );   // MPLL_MULTIPLIER = 50
	uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg & (~( 0x1<<15));  // MPLL_CAL_DISABLE masking
	uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg |   (   0<<15);   // MPLL_CAL_DISABLE = 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL0.nReg, uPCS1_PMA_MMD.uMPLLB_CTRL0.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL1.nReg;
	uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg & (~(0x7ff<<5));  // MPLL_FRACN_CTRL masking
	uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg |   (    0<<5);   // MPLL_FRACN_CTRL = 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL1.nReg, uPCS0_PMA_MMD.uMPLLA_CTRL1.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL1.nReg;
	uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg & (~(0x7ff<<5));  // MPLL_FRACN_CTRL masking
	uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg |   (    0<<5);   // MPLL_FRACN_CTRL = 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL1.nReg, uPCS1_PMA_MMD.uMPLLB_CTRL1.nReg);


	addr = &HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL2.nReg;
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~( 0x1<<8 ));  // MPLL_DIV8_CLK_EN masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   0<<8 );   // MPLL_DIV8_CLK_EN     = 0
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~( 0x1<<9 ));  // MPLL_DIV10_CLK_EN masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   1<<9 );   // MPLL_DIV10_CLK_EN    = 1
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~( 0x1<<10));  // MPLL_DIV16P5_CLK_EN masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   1<<10);   // MPLL_DIV16P5_CLK_EN  = 1
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~( 0x3<<11));  // MPLL_TX_CLK_DIV[1:0] masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   0<<11);   // MPLL_TX_CLK_DIV[1:0] = 0
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~( 0x1<<7 ));  // MPLL_DIV_CLK_EN masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   0<<7 );   // MPLL_DIV_CLK_EN      = 0
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg & (~(0x7f<<0 ));  // MPLL_DIV_MULT[6:0] masking
	uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg = uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg |   (   0<<0 );   // MPLL_DIV_MULT[6:0]   = 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL2.nReg, uPCS0_PMA_MMD.uMPLLA_CTRL2.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL2.nReg;
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg & (~( 0x1<<8 ));  // MPLL_DIV8_CLK_EN masking
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg |   (   0<<8 );   // MPLL_DIV8_CLK_EN     = 0
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg & (~( 0x1<<9 ));  // MPLL_DIV10_CLK_EN masking
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg |   (   1<<9 );   // MPLL_DIV10_CLK_EN    = 1
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg & (~( 0x3<<11));  // MPLL_TX_CLK_DIV masking
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg |   (   0<<11);   // MPLL_TX_CLK_DIV      = 0
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg & (~( 0x1<<7 ));  // MPLL_DIV_CLK_EN masking
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg |   (   1<<7 );   // MPLL_DIV_CLK_EN      = 1
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg & (~(0x7f<<0 ));  // MPLL_DIV_MULT masking
	uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg = uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg |   (  12<<0 );   // MPLL_DIV_MULT        = 12
	RegWrite(&HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL2.nReg, uPCS1_PMA_MMD.uMPLLB_CTRL2.nReg);

	uPCS0_PMA_MMD.uMPLLA_CTRL3.nReg = 61970;
	RegWrite(&HwXPCS0_XS_PMA_MMD->uMPLLA_CTRL3.nReg, uPCS0_PMA_MMD.uMPLLA_CTRL3.nReg);  // MPLL_BANDWIDTH = 61970

	uPCS1_PMA_MMD.uMPLLB_CTRL3.nReg = 40967;
	RegWrite(&HwXPCS1_XS_PMA_MMD->uMPLLB_CTRL3.nReg, uPCS1_PMA_MMD.uMPLLB_CTRL3.nReg);  // MPLL_BANDWIDTH = 40967

	addr = &HwXPCS0_XS_PMA_MMD->uTX_GENCTRL1.nReg;
	uPCS0_PMA_MMD.uTX_GENCTRL1.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uTX_GENCTRL1.nReg = uPCS0_PMA_MMD.uTX_GENCTRL1.nReg & (~(0x7<<8));    // VBOOST_LVL masking
	uPCS0_PMA_MMD.uTX_GENCTRL1.nReg = uPCS0_PMA_MMD.uTX_GENCTRL1.nReg |   (  5<<8);     // VBOOST_LVL = 5
	RegWrite(&HwXPCS0_XS_PMA_MMD->uTX_GENCTRL1.nReg, uPCS0_PMA_MMD.uTX_GENCTRL1.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uMISC_CTRL0.nReg;
	uPCS0_PMA_MMD.uMISC_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uMISC_CTRL0.nReg = uPCS0_PMA_MMD.uMISC_CTRL0.nReg & (~(0x1f<<8));     // RX_VREF_CTRL masking
	uPCS0_PMA_MMD.uMISC_CTRL0.nReg = uPCS0_PMA_MMD.uMISC_CTRL0.nReg |   (  17<<8);      // RX_VREF_CTRL = 17
	RegWrite(&HwXPCS0_XS_PMA_MMD->uMISC_CTRL0.nReg, uPCS0_PMA_MMD.uMISC_CTRL0.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-4-b : PHY Lane-0 Tx/Rx setting by XPCS-0 for USXGMII
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_XS_PMA_MMD->uMPLL_CMN_CTRL.nReg;
	uPCS0_PMA_MMD.uMPLL_CMN_CTRL.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uMPLL_CMN_CTRL.nReg = uPCS0_PMA_MMD.uMPLL_CMN_CTRL.nReg & (~(0x1<<4));    // MPLLB_SEL_0 masking
	uPCS0_PMA_MMD.uMPLL_CMN_CTRL.nReg = uPCS0_PMA_MMD.uMPLL_CMN_CTRL.nReg |   (  0<<4);     // MPLLB_SEL_0          = 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uMPLL_CMN_CTRL.nReg, uPCS0_PMA_MMD.uMPLL_CMN_CTRL.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uTX_MISC_CTRL0.nReg;
	uPCS0_PMA_MMD.uTX_MISC_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uTX_MISC_CTRL0.nReg = uPCS0_PMA_MMD.uTX_MISC_CTRL0.nReg & (~(0xff<<0));   // TX0_MISC masking
	uPCS0_PMA_MMD.uTX_MISC_CTRL0.nReg = uPCS0_PMA_MMD.uTX_MISC_CTRL0.nReg |   (   0<<0);    // TX0_MISC             = 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uTX_MISC_CTRL0.nReg, uPCS0_PMA_MMD.uTX_MISC_CTRL0.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uTX_RATE_CTRL.nReg;
	uPCS0_PMA_MMD.uTX_RATE_CTRL.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uTX_RATE_CTRL.nReg = uPCS0_PMA_MMD.uTX_RATE_CTRL.nReg & (~(0x7<<0));      // TX0_RATE masking
	uPCS0_PMA_MMD.uTX_RATE_CTRL.nReg = uPCS0_PMA_MMD.uTX_RATE_CTRL.nReg |   (  1<<0);       // TX0_RATE             = 1
	RegWrite(&HwXPCS0_XS_PMA_MMD->uTX_RATE_CTRL.nReg, uPCS0_PMA_MMD.uTX_RATE_CTRL.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uTX_GENCTRL2.nReg;
	uPCS0_PMA_MMD.uTX_GENCTRL2.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uTX_GENCTRL2.nReg = uPCS0_PMA_MMD.uTX_GENCTRL2.nReg & (~(0x3<<8));        // TX0_WIDTH masking
	uPCS0_PMA_MMD.uTX_GENCTRL2.nReg = uPCS0_PMA_MMD.uTX_GENCTRL2.nReg |   (  3<<8);         // TX0_WIDTH            = 3
	RegWrite(&HwXPCS0_XS_PMA_MMD->uTX_GENCTRL2.nReg, uPCS0_PMA_MMD.uTX_GENCTRL2.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uTX_GENCTRL1.nReg;
	uPCS0_PMA_MMD.uTX_GENCTRL1.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uTX_GENCTRL1.nReg = uPCS0_PMA_MMD.uTX_GENCTRL1.nReg & (~(0x1<<4));        // VBOOST_EN_0 masking
	uPCS0_PMA_MMD.uTX_GENCTRL1.nReg = uPCS0_PMA_MMD.uTX_GENCTRL1.nReg |   (  1<<4);         // VBOOST_EN_0          = 1
	RegWrite(&HwXPCS0_XS_PMA_MMD->uTX_GENCTRL1.nReg, uPCS0_PMA_MMD.uTX_GENCTRL1.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uTX_BOOST_CTRL.nReg;
	uPCS0_PMA_MMD.uTX_BOOST_CTRL.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uTX_BOOST_CTRL.nReg = uPCS0_PMA_MMD.uTX_BOOST_CTRL.nReg & (~(0xf<<0));    // TX0_IBOOST masking
	uPCS0_PMA_MMD.uTX_BOOST_CTRL.nReg = uPCS0_PMA_MMD.uTX_BOOST_CTRL.nReg |   ( 15<<0);     // TX0_IBOOST           = 15
	RegWrite(&HwXPCS0_XS_PMA_MMD->uTX_BOOST_CTRL.nReg, uPCS0_PMA_MMD.uTX_BOOST_CTRL.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uVCO_CAL_LD0.nReg;
	uPCS0_PMA_MMD.uVCO_CAL_LD0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uVCO_CAL_LD0.nReg = uPCS0_PMA_MMD.uVCO_CAL_LD0.nReg & (~(0x1fff<<0));     // VCO_LD_VAL_0 masking
	uPCS0_PMA_MMD.uVCO_CAL_LD0.nReg = uPCS0_PMA_MMD.uVCO_CAL_LD0.nReg |   (  1353<<0);      // VCO_LD_VAL_0         = 1353
	RegWrite(&HwXPCS0_XS_PMA_MMD->uVCO_CAL_LD0.nReg, uPCS0_PMA_MMD.uVCO_CAL_LD0.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uVCO_CAL_REF0.nReg;
	uPCS0_PMA_MMD.uVCO_CAL_REF0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uVCO_CAL_REF0.nReg = uPCS0_PMA_MMD.uVCO_CAL_REF0.nReg & (~(0x7f<<0));     // VCO_REF_LD_0 masking
	uPCS0_PMA_MMD.uVCO_CAL_REF0.nReg = uPCS0_PMA_MMD.uVCO_CAL_REF0.nReg |   (  41<<0);      // VCO_REF_LD_0         = 41
	RegWrite(&HwXPCS0_XS_PMA_MMD->uVCO_CAL_REF0.nReg, uPCS0_PMA_MMD.uVCO_CAL_REF0.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_RATE_CTRL.nReg;
	uPCS0_PMA_MMD.uRX_RATE_CTRL.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_RATE_CTRL.nReg = uPCS0_PMA_MMD.uRX_RATE_CTRL.nReg & (~(0x3<<0));      // RX0_RATE masking
	uPCS0_PMA_MMD.uRX_RATE_CTRL.nReg = uPCS0_PMA_MMD.uRX_RATE_CTRL.nReg |   (  1<<0);       // RX0_RATE             = 1
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_RATE_CTRL.nReg, uPCS0_PMA_MMD.uRX_RATE_CTRL.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_GENCTRL1.nReg;
	uPCS0_PMA_MMD.uRX_GENCTRL1.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_GENCTRL1.nReg = uPCS0_PMA_MMD.uRX_GENCTRL1.nReg & (~(0x1<<12));       // RX_DIV16P5_CLK_EN_0 masking
	uPCS0_PMA_MMD.uRX_GENCTRL1.nReg = uPCS0_PMA_MMD.uRX_GENCTRL1.nReg |   (  1<<12);        // RX_DIV16P5_CLK_EN_0  = 1
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_GENCTRL1.nReg, uPCS0_PMA_MMD.uRX_GENCTRL1.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_GENCTRL2.nReg;
	uPCS0_PMA_MMD.uRX_GENCTRL2.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_GENCTRL2.nReg = uPCS0_PMA_MMD.uRX_GENCTRL2.nReg & (~(0x3<<8));        // RX0_WIDTH masking
	uPCS0_PMA_MMD.uRX_GENCTRL2.nReg = uPCS0_PMA_MMD.uRX_GENCTRL2.nReg |   (  3<<8);         // RX0_WIDTH            = 3
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_GENCTRL2.nReg, uPCS0_PMA_MMD.uRX_GENCTRL2.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_GENCTRL3.nReg;
	uPCS0_PMA_MMD.uRX_GENCTRL3.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_GENCTRL3.nReg = uPCS0_PMA_MMD.uRX_GENCTRL3.nReg & (~(0x7<<0));        // RX_THSHLD_0 masking
	uPCS0_PMA_MMD.uRX_GENCTRL3.nReg = uPCS0_PMA_MMD.uRX_GENCTRL3.nReg |   (  1<<0);         // RX_THSHLD_0          = 1
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_GENCTRL3.nReg, uPCS0_PMA_MMD.uRX_GENCTRL3.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_GENCTRL4.nReg;
	uPCS0_PMA_MMD.uRX_GENCTRL4.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_GENCTRL4.nReg = uPCS0_PMA_MMD.uRX_GENCTRL4.nReg & (~(0x1<<8));        // RX_DFE_BYP_0 masking
	uPCS0_PMA_MMD.uRX_GENCTRL4.nReg = uPCS0_PMA_MMD.uRX_GENCTRL4.nReg |   (  0<<8);         // RX_DFE_BYP_0         = 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_GENCTRL4.nReg, uPCS0_PMA_MMD.uRX_GENCTRL4.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_EQ_CTRL0.nReg;
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg & (~( 0x7<<12));      // VGA1_GAIN_0 masking
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   5<<12);       // VGA1_GAIN_0          = 5
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg & (~( 0x7<<8 ));      // VGA2_GAIN_0 masking
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   5<<8 );       // VGA2_GAIN_0          = 5
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg & (~(0x1f<<0 ));      // CTLE_BOOST_0 masking
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg |   (  14<<0 );       // CTLE_BOOST_0         = 14
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg & (~( 0x3<<5 ));      // CTLE_POLE_0 masking
	uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   0<<5 );       // CTLE_POLE_0          = 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_EQ_CTRL0.nReg, uPCS0_PMA_MMD.uRX_EQ_CTRL0.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_EQ_CTRL5.nReg;
	uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg & (~(0x3<<4));        // RX0_ADPT_MODE masking
	uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg |   (  3<<4);         // RX0_ADPT_MODE        = 3
	uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg & (~(0x1<<0));        // RX_ADPT_SEL_0 masking
	uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg |   (  0<<0);         // RX_ADPT_SEL_0        = 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_EQ_CTRL5.nReg, uPCS0_PMA_MMD.uRX_EQ_CTRL5.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_CDR_CTRL1.nReg;
	uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg & (~(0x1<<4));      // VCO_STEP_CTRL_0 masking
	uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg |   (  1<<4);       // VCO_STEP_CTRL_0      = 1
	uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg & (~(0x1<<0));      // VCO_TEMP_COMP_EN_0 masking
	uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg |   (  1<<0);       // VCO_TEMP_COMP_EN_0   = 1
	uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg & (~(0x3<<8));      // VCO_FRQBAND_0 masking
	uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg |   (  1<<8);       // VCO_FRQBAND_0        = 1
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_CDR_CTRL1.nReg, uPCS0_PMA_MMD.uRX_CDR_CTRL1.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_MISC_CTRL0.nReg;
	uPCS0_PMA_MMD.uRX_MISC_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_MISC_CTRL0.nReg = uPCS0_PMA_MMD.uRX_MISC_CTRL0.nReg & (~(0xff<<0));   // RX0_MISC masking
	uPCS0_PMA_MMD.uRX_MISC_CTRL0.nReg = uPCS0_PMA_MMD.uRX_MISC_CTRL0.nReg |   (   4<<0);    // RX0_MISS             = 4
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_MISC_CTRL0.nReg, uPCS0_PMA_MMD.uRX_MISC_CTRL0.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_IQ_CTRL0.nReg;
	uPCS0_PMA_MMD.uRX_IQ_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_IQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_IQ_CTRL0.nReg & (~(0xf<<8));        // RX0_DELTA_IQ masking
	uPCS0_PMA_MMD.uRX_IQ_CTRL0.nReg = uPCS0_PMA_MMD.uRX_IQ_CTRL0.nReg |   (  0<<8);         // RX0_DELTA_IQ         = 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_IQ_CTRL0.nReg, uPCS0_PMA_MMD.uRX_IQ_CTRL0.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_ATTN_CTRL.nReg;
	uPCS0_PMA_MMD.uRX_ATTN_CTRL.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_ATTN_CTRL.nReg = uPCS0_PMA_MMD.uRX_ATTN_CTRL.nReg & (~(0x7<<0));      // RX0_EQ_ATT_LVL masking
	uPCS0_PMA_MMD.uRX_ATTN_CTRL.nReg = uPCS0_PMA_MMD.uRX_ATTN_CTRL.nReg |   (  0<<0);       // RX0_EQ_ATT_LVL       = 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_ATTN_CTRL.nReg, uPCS0_PMA_MMD.uRX_ATTN_CTRL.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uDFE_TAP_CTRL0.nReg;
	uPCS0_PMA_MMD.uDFE_TAP_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uDFE_TAP_CTRL0.nReg = uPCS0_PMA_MMD.uDFE_TAP_CTRL0.nReg & (~(0xff<<0));   // DFE_TAP1_0 masking
	uPCS0_PMA_MMD.uDFE_TAP_CTRL0.nReg = uPCS0_PMA_MMD.uDFE_TAP_CTRL0.nReg |   (   0<<0);    // DFE_TAP1_0           = 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uDFE_TAP_CTRL0.nReg, uPCS0_PMA_MMD.uDFE_TAP_CTRL0.nReg);

	addr = &HwXPCS0_XS_PMA_MMD->uRX_PPM_CTRL0.nReg;
	uPCS0_PMA_MMD.uRX_PPM_CTRL0.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_PPM_CTRL0.nReg = uPCS0_PMA_MMD.uRX_PPM_CTRL0.nReg & (~(0x1f<<0));     // RX0_CDR_PPM_MAX masking
	uPCS0_PMA_MMD.uRX_PPM_CTRL0.nReg = uPCS0_PMA_MMD.uRX_PPM_CTRL0.nReg |   (  18<<0);      // RX0_CDR_PPM_MAX      = 18
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_PPM_CTRL0.nReg, uPCS0_PMA_MMD.uRX_PPM_CTRL0.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3-4-b : PHY Lane-1 Tx/Rx setting by XPCS-1 for SGMII
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS1_XS_PMA_MMD->uMPLL_CMN_CTRL.nReg;
	uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg = uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg & (~(0x1<<4));    // MPLLB_SEL_0 masking
	uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg = uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg |   (  1<<4);     // MPLLB_SEL_0          = 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uMPLL_CMN_CTRL.nReg, uPCS1_PMA_MMD.uMPLL_CMN_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_MISC_CTRL0.nReg;
	uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg = uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg & (~(0xff<<0));   // TX0_MISC masking
	uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg = uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg |   (   0<<0);    // TX0_MISC             = 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_MISC_CTRL0.nReg, uPCS1_PMA_MMD.uTX_MISC_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_RATE_CTRL.nReg;
	uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg = uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg & (~(0x7<<0));      // TX0_RATE masking
	uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg = uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg |   (  5<<0);       // TX0_RATE             = 5
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_RATE_CTRL.nReg, uPCS1_PMA_MMD.uTX_RATE_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_GENCTRL2.nReg;
	uPCS1_PMA_MMD.uTX_GENCTRL2.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_GENCTRL2.nReg = uPCS1_PMA_MMD.uTX_GENCTRL2.nReg & (~(0x3<<8));        // TX0_WIDTH masking
	uPCS1_PMA_MMD.uTX_GENCTRL2.nReg = uPCS1_PMA_MMD.uTX_GENCTRL2.nReg |   (  1<<8);         // TX0_WIDTH            = 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_GENCTRL2.nReg, uPCS1_PMA_MMD.uTX_GENCTRL2.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_GENCTRL1.nReg;
	uPCS1_PMA_MMD.uTX_GENCTRL1.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_GENCTRL1.nReg = uPCS1_PMA_MMD.uTX_GENCTRL1.nReg & (~(0x1<<4));        // VBOOST_EN_0 masking
	uPCS1_PMA_MMD.uTX_GENCTRL1.nReg = uPCS1_PMA_MMD.uTX_GENCTRL1.nReg |   (  1<<4);         // VBOOST_EN_0          = 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_GENCTRL1.nReg, uPCS1_PMA_MMD.uTX_GENCTRL1.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_BOOST_CTRL.nReg;
	uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg = uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg & (~(0xf<<0));    // TX0_IBOOST masking
	uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg = uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg |   ( 15<<0);     // TX0_IBOOST           = 15
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_BOOST_CTRL.nReg, uPCS1_PMA_MMD.uTX_BOOST_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uVCO_CAL_LD0.nReg;
	uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg = uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg & (~(0x1fff<<0));     // VCO_LD_VAL_0 masking
	uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg = uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg |   (  1360<<0);      // VCO_LD_VAL_0         = 1360
	RegWrite(&HwXPCS1_XS_PMA_MMD->uVCO_CAL_LD0.nReg, uPCS1_PMA_MMD.uVCO_CAL_LD0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uVCO_CAL_REF0.nReg;
	uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg = uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg & (~(0x7f<<0));     // VCO_REF_LD_0 masking
	uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg = uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg |   (  34<<0);      // VCO_REF_LD_0         = 34
	RegWrite(&HwXPCS1_XS_PMA_MMD->uVCO_CAL_REF0.nReg, uPCS1_PMA_MMD.uVCO_CAL_REF0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_RATE_CTRL.nReg;
	uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg = uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg & (~(0x3<<0));      // RX0_RATE masking
	uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg = uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg |   (  2<<0);       // RX0_RATE             = 2
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_RATE_CTRL.nReg, uPCS1_PMA_MMD.uRX_RATE_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_GENCTRL1.nReg;
	uPCS1_PMA_MMD.uRX_GENCTRL1.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_GENCTRL1.nReg = uPCS1_PMA_MMD.uRX_GENCTRL1.nReg & (~(0x1<<12));       // RX_DIV16P5_CLK_EN_0 masking
	uPCS1_PMA_MMD.uRX_GENCTRL1.nReg = uPCS1_PMA_MMD.uRX_GENCTRL1.nReg |   (  0<<12);        // RX_DIV16P5_CLK_EN_0  = 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_GENCTRL1.nReg, uPCS1_PMA_MMD.uRX_GENCTRL1.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_GENCTRL2.nReg;
	uPCS1_PMA_MMD.uRX_GENCTRL2.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_GENCTRL2.nReg = uPCS1_PMA_MMD.uRX_GENCTRL2.nReg & (~(0x3<<8));        // RX0_WIDTH masking
	uPCS1_PMA_MMD.uRX_GENCTRL2.nReg = uPCS1_PMA_MMD.uRX_GENCTRL2.nReg |   (  1<<8);         // RX0_WIDTH            = 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_GENCTRL2.nReg, uPCS1_PMA_MMD.uRX_GENCTRL2.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_GENCTRL3.nReg;
	uPCS1_PMA_MMD.uRX_GENCTRL3.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_GENCTRL3.nReg = uPCS1_PMA_MMD.uRX_GENCTRL3.nReg & (~(0x7<<0));        // RX_THSHLD_0 masking
	uPCS1_PMA_MMD.uRX_GENCTRL3.nReg = uPCS1_PMA_MMD.uRX_GENCTRL3.nReg |   (  1<<0);         // RX_THSHLD_0          = 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_GENCTRL3.nReg, uPCS1_PMA_MMD.uRX_GENCTRL3.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_GENCTRL4.nReg;
	uPCS1_PMA_MMD.uRX_GENCTRL4.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_GENCTRL4.nReg = uPCS1_PMA_MMD.uRX_GENCTRL4.nReg & (~(0x1<<8));        // RX_DFE_BYP_0 masking
	uPCS1_PMA_MMD.uRX_GENCTRL4.nReg = uPCS1_PMA_MMD.uRX_GENCTRL4.nReg |   (  1<<8);         // RX_DFE_BYP_0         = 1
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_GENCTRL4.nReg, uPCS1_PMA_MMD.uRX_GENCTRL4.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_EQ_CTRL0.nReg;
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg & (~( 0x7<<12));      // VGA1_GAIN_0 masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   4<<12);       // VGA1_GAIN_0          = 4
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg & (~( 0x7<<8 ));      // VGA2_GAIN_0 masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   4<<8 );       // VGA2_GAIN_0          = 4
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg & (~(0x1f<<0 ));      // CTLE_BOOST_0 masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   6<<0 );       // CTLE_BOOST_0         = 6
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg & (~( 0x3<<5 ));      // CTLE_POLE_0 masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg |   (   0<<5 );       // CTLE_POLE_0          = 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_EQ_CTRL0.nReg, uPCS1_PMA_MMD.uRX_EQ_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_EQ_CTRL5.nReg;
	uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg & (~(0x3<<4));        // RX0_ADPT_MODE masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg |   (  0<<4);         // RX0_ADPT_MODE        = 0
	uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg & (~(0x1<<0));        // RX_ADPT_SEL_0 masking
	uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg = uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg |   (  0<<0);         // RX_ADPT_SEL_0        = 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_EQ_CTRL5.nReg, uPCS1_PMA_MMD.uRX_EQ_CTRL5.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_CDR_CTRL1.nReg;
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg & (~(0x1<<4));      // VCO_STEP_CTRL_0 masking
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg |   (  1<<4);       // VCO_STEP_CTRL_0      = 1
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg & (~(0x1<<0));      // VCO_TEMP_COMP_EN_0 masking
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg |   (  0<<0);       // VCO_TEMP_COMP_EN_0   = 0
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg & (~(0x3<<8));      // VCO_FRQBAND_0 masking
	uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg = uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg |   (  2<<8);       // VCO_FRQBAND_0        = 2
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_CDR_CTRL1.nReg, uPCS1_PMA_MMD.uRX_CDR_CTRL1.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_MISC_CTRL0.nReg;
	uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg = uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg & (~(0xff<<0));   // RX0_MISC masking
	uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg = uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg |   (   7<<0);    // RX0_MISS             = 7
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_MISC_CTRL0.nReg, uPCS1_PMA_MMD.uRX_MISC_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_IQ_CTRL0.nReg;
	uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg & (~(0xf<<8));        // RX0_DELTA_IQ masking
	uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg = uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg |   (  0<<8);         // RX0_DELTA_IQ         = 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_IQ_CTRL0.nReg, uPCS1_PMA_MMD.uRX_IQ_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_ATTN_CTRL.nReg;
	uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg = uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg & (~(0x7<<0));      // RX0_EQ_ATT_LVL masking
	uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg = uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg |   (  0<<0);       // RX0_EQ_ATT_LVL       = 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_ATTN_CTRL.nReg, uPCS1_PMA_MMD.uRX_ATTN_CTRL.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uDFE_TAP_CTRL0.nReg;
	uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg = uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg & (~(0xff<<0));   // DFE_TAP1_0 masking
	uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg = uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg |   (   0<<0);    // DFE_TAP1_0           = 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uDFE_TAP_CTRL0.nReg, uPCS1_PMA_MMD.uDFE_TAP_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uRX_PPM_CTRL0.nReg;
	uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg = uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg & (~(0x1f<<0));     // RX0_CDR_PPM_MAX masking
	uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg = uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg |   (  18<<0);      // RX0_CDR_PPM_MAX      = 18
	RegWrite(&HwXPCS1_XS_PMA_MMD->uRX_PPM_CTRL0.nReg, uPCS1_PMA_MMD.uRX_PPM_CTRL0.nReg);

#ifdef LOOPBACK_L
	//----------------------------------------------------------------------------------------------------------------------------
	// PHY lane-0(5.0Gbps) Serial Loopback enable
	//----------------------------------------------------------------------------------------------------------------------------
	mcu_printf("LOOPBACK enable\n");
	addr = &HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);

	uPCS0_SR_MII_MMD.uMII_CTRL.nReg = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<14));		 // LBE masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<14);		// LBE = 1
	RegWrite(&HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg, uPCS0_SR_MII_MMD.uMII_CTRL.nReg);

    //----------------------------------------------------------------------------------------------------------------------------
    // PHY lane-1(2.5Gbps) Serial Loopback enable
    //----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);

    uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<14));        // LBE masking
    uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<14);        // LBE = 1
    RegWrite(&HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg, uPCS1_SR_MII_MMD.uMII_CTRL.nReg);
#endif



	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-5 ~ 5.2-6 : PHY Reset assertion and readback check
	// 5.3-5 ~ 5.3-6 : PHY Reset assertion and readback check
	//----------------------------------------------------------------------------------------------------------------------------
	mcu_printf("PHY reset asserted\n");
	addr = &HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg;
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = RegRead(addr);
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg & (~(0x1<<15));           // VR_RST masking
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg |   (  1<<15);            // VR_RST = 1
	RegWrite(&HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg, uPCS0_PCS_MMD.uDIG_CTRL1.nReg);	        // PHY reset only is controlled by XPCS-0

	mcu_printf("Wait for PHY reset done\n");
	do{
		addr = &HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg;
		uPCS0_PCS_MMD.uDIG_CTRL1.nReg = RegRead(addr);
	}while((uPCS0_PCS_MMD.uDIG_CTRL1.nReg & (0x1<<15)) != (0x0<<15));
	mcu_printf("Complete PHY reset\n");

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-7 : SUPRESS_LOS_DET(Suppress Loss of Signal Detection) = 1, This bit controls the behavior of xpcs_rx_data_en_o(lane) output from DWC_xpcs.
	//         RX_SYNC_CTL (Receive Synchronization Control)
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_XS_PCS_MMD->uDEBUG_CTRL.nReg;
	uPCS0_PCS_MMD.uDEBUG_CTRL.nReg = RegRead(addr);
//	uPCS0_PCS_MMD.uDEBUG_CTRL.nReg = uPCS0_PCS_MMD.uDEBUG_CTRL.nReg & (~(0x1<<7));			// RX_SYNC_CTL maksing
//	uPCS0_PCS_MMD.uDEBUG_CTRL.nReg = uPCS0_PCS_MMD.uDEBUG_CTRL.nReg |	(  1<<7);			// RX_SYNC_CTL		= 1
	uPCS0_PCS_MMD.uDEBUG_CTRL.nReg = uPCS0_PCS_MMD.uDEBUG_CTRL.nReg & (~(0x1<<6));			// RX_DT_EN_CTL maksing
	uPCS0_PCS_MMD.uDEBUG_CTRL.nReg = uPCS0_PCS_MMD.uDEBUG_CTRL.nReg |	(  1<<6);			// RX_DT_EN_CTL 	= 1
	uPCS0_PCS_MMD.uDEBUG_CTRL.nReg = uPCS0_PCS_MMD.uDEBUG_CTRL.nReg & (~(0x1<<4));          // SUPRESS_LOS_DET masking
	uPCS0_PCS_MMD.uDEBUG_CTRL.nReg = uPCS0_PCS_MMD.uDEBUG_CTRL.nReg |   (  1<<4);           // SUPRESS_LOS_DET  = 1
	RegWrite(&HwXPCS0_XS_PCS_MMD->uDEBUG_CTRL.nReg, uPCS0_PCS_MMD.uDEBUG_CTRL.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-8 : Wait for PHY DPLL Lock Status for Lane-0(RX_VALID_0)
	//----------------------------------------------------------------------------------------------------------------------------
	mcu_printf("Wait for PHY DPLL Lock Status for Lane-0(RX_LSTS.RX_VALID_0) done\n");
#if 1
	do{
		addr = &HwXPCS0_XS_PMA_MMD->uRX_LSTS.nReg;
		uPCS0_PMA_MMD.uRX_LSTS.nReg = RegRead(addr);
	}while((uPCS0_PMA_MMD.uRX_LSTS.nReg & (0x1<<12)) != (0x1<<12));
#else
	addr = &HwXPCS0_XS_PMA_MMD->uRX_LSTS.nReg;
	uPCS0_PMA_MMD.uRX_LSTS.nReg = RegRead(addr);

	mcu_printf("[%s][%d] :: 0x%x\n", __func__, __LINE__, uPCS0_PMA_MMD.uRX_LSTS.nReg );
#endif

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-9 : Receive Adaptation Request(RX_EQ_CTRL4.RX_AD_REQ) set
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_XS_PMA_MMD->uRX_EQ_CTRL4.nReg;
	uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg & (~(0x1<<12));       // RX_AD_REQ masking
	uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg |   (  1<<12);        // RX_AD_REQ = 1
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_EQ_CTRL4.nReg, uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg);

    //----------------------------------------------------------------------------------------------------------------------------
    // 5.2-10 : Wait for Receive Adaptation Acknowledgement from PHY
    //----------------------------------------------------------------------------------------------------------------------------
    mcu_printf("Wait for PHY Receive Adaptation Acknowledgement(MISC_STS.RX_ADPT_ACK) done\n");
    do{
		addr = &HwXPCS0_XS_PMA_MMD->uMISC_STS.nReg;
        uPCS0_PMA_MMD.uMISC_STS.nReg = RegRead(addr);
    }while((uPCS0_PMA_MMD.uMISC_STS.nReg & (0x1<<12)) != (0x1<<12));

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2-11 : Receive Adaptation Request(RX_EQ_CTRL4.RX_AD_REQ) clear
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_XS_PMA_MMD->uRX_EQ_CTRL4.nReg;
	uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg = RegRead(addr);
	uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg & (~(0x1<<12));       // RX_AD_REQ masking
	uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg = uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg |   (  0<<12);        // RX_AD_REQ = 0
	RegWrite(&HwXPCS0_XS_PMA_MMD->uRX_EQ_CTRL4.nReg, uPCS0_PMA_MMD.uRX_EQ_CTRL4.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// Tx. Equalization control register setting
	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3-7 : uTX_EQ_CTRL0.TX_EQ_PRE   = 0,    Tx Pre-Emphasis level adjustment Control
	// 5.3-8 : uTX_EQ_CTRL0.TX_EQ_MAIN  = 32,   Control for setting Tx driver output amplitude
	// 5.3-9 : uTX_EQ_CTRL1.TX_EQ_POST  = 32,   Tx Post-Emphasis level adjustment Control
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS1_XS_PMA_MMD->uTX_EQ_CTRL0.nReg;
	uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg & (~(0x3f<<0));		// RX_EQ_PRE masking
	uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg |   (  0<<0); 	   // RX_EQ_PRE    = 32
	uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg & (~(0x3f<<8));       // RX_EQ_MAIN masking
	uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg |   (   32<<8);        // RX_EQ_MAIN   = 0
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_EQ_CTRL0.nReg, uPCS1_PMA_MMD.uTX_EQ_CTRL0.nReg);

	addr = &HwXPCS1_XS_PMA_MMD->uTX_EQ_CTRL1.nReg;
	uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg = RegRead(addr);
	uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg & (~(0x3f<<0));       // RX_EQ_POST masking
	uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg = uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg |   (  32<<0);        // RX_EQ_POST   = 32
	RegWrite(&HwXPCS1_XS_PMA_MMD->uTX_EQ_CTRL1.nReg, uPCS1_PMA_MMD.uTX_EQ_CTRL1.nReg);

#ifdef AN_EN_5P0G
	//============================================================================================================================
	// USXGMII Auto-negotiation
	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	mcu_printf("5Gbps USXGMII Auto-negotiation setting start[5G 001]\n");

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-1 : Auto-negotiation control register setting
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_VR_MII_MMD->uAN_CTRL.nReg;
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = RegRead(addr);
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = uPCS0_VR_MII_MMD.uAN_CTRL.nReg & (~(0x1<<0));          // MII_AN_INTR_EN masking
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = uPCS0_VR_MII_MMD.uAN_CTRL.nReg |   (  1<<0);           // MII_AN_INTR_EN   = 1,    Clause 37 Auto-negotiation complete interrupt enable = Enable
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = uPCS0_VR_MII_MMD.uAN_CTRL.nReg & (~(0x1<<8));          // MII_CTRL masking
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = uPCS0_VR_MII_MMD.uAN_CTRL.nReg |   (  1<<8);           // MII_CTRL         = 1,    MII Control											= 8-bit MII
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = uPCS0_VR_MII_MMD.uAN_CTRL.nReg & (~(0x1<<3));          // TX_CONFIG masking
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = uPCS0_VR_MII_MMD.uAN_CTRL.nReg |   (  1<<3);           // TX_CONFIG        = 1,    Transmission Configuration							= Configures the DWC_xpcs as the PHY side USXGMII
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = uPCS0_VR_MII_MMD.uAN_CTRL.nReg & (~(0x1<<4));          // SGMII_LINK_STS masking
	uPCS0_VR_MII_MMD.uAN_CTRL.nReg = uPCS0_VR_MII_MMD.uAN_CTRL.nReg |   (  1<<4);           // SGMII_LINK_STS   = 1,    USXGMII Link Status									= Link-up
	RegWrite(&HwXPCS0_VR_MII_MMD->uAN_CTRL.nReg, uPCS0_VR_MII_MMD.uAN_CTRL.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-2 : (Optional) Link timer setting
	//----------------------------------------------------------------------------------------------------------------------------
	// TODO VR_MII_LINK_TIMER_CTRL
	// TODO VR_MII_DIG_CTRL1.CL47_TMR_OVR_RIDE (Over-Ride control for CL37 Link Timer)

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-3 : Speed selection,		  SR_MII_CTRL.SS5/SS6/SS13
	// 5.2.1-4 : Auto-negotiation enable, SR_MII_CTRL.AN_ENABLE
	//----------------------------------------------------------------------------------------------------------------------------
	// Speed selection {SS5, SS6, SS13} = {1, 0, 1} = Speed is 5Gbps
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<< 5));      // SS5 masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  1<< 5);       // SS5          = 1
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<< 6));      // SS5 masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  0<< 6);       // SS5          = 0
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<13));      // SS13 masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<13);       // SS13         = 1
	RegWrite(&HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg, uPCS0_SR_MII_MMD.uMII_CTRL.nReg);

	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<12));      // AN_ENABLE masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<12);       // AN_ENABLE    = 1
	RegWrite(&HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg, uPCS0_SR_MII_MMD.uMII_CTRL.nReg);

	mcu_printf("Wait for PHY Link-up\n");
#if 1
	do{
		addr = &HwXPCS0_XS_PCS_MMD->uPCS_STS.nReg;
		uPCS0_PCS_MMD.uPCS_STS.nReg = RegRead(addr);
	}while((uPCS0_PCS_MMD.uPCS_STS.nReg & (0x1<<2)) != (0x1<<2));
#endif
	mcu_printf("Complete PHY Link-up\n");

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-5,6 : Wait for Auto-negotiation interrupt
	//----------------------------------------------------------------------------------------------------------------------------
#if 1
	mcu_printf("Wait for Auto-negotiation interrupt\n");
	do{
		addr = &HwXPCS0_VR_MII_MMD->uAN_INTR_STS.nReg;
		uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg = RegRead(addr);
	}while((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x1<<0)) != (0x1<<0));
	mcu_printf("Complete Auto-negotiation interrupt\n");
#endif

	// Clause 37 AN USXGMII port status
	if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x1<<8)) == (1<<8)) {
		mcu_printf("5.0G PHY Lane-0 AN result : EEE clock-stop supported.\n");
	} else {
		mcu_printf("5.0G PHY Lane-0 AN result : EEE clock-stop not supported.\n");
	}

	if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x1<<9)) == (1<<9)) {
		mcu_printf("5.0G PHY Lane-0 AN result : EEE supported.\n");
	} else {
		mcu_printf("5.0G PHY Lane-0 AN result : EEE not supported.\n");
	}

	if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x7<<10)) == (0<<10)) {
		mcu_printf("5.0G PHY Lane-1 AN result : 10 Mbps speed link\n");
	}else if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x7<<10)) == (1<<10)) {
		mcu_printf("5.0G PHY Lane-0 AN result : 100 Mbps speed link\n");
	}else if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x7<<10)) == (2<<10)) {
		mcu_printf("5.0G PHY Lane-0 AN result : 1000 Mbps speed link\n");
	}else if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x7<<10)) == (3<<10)) {
		mcu_printf("5.0G PHY Lane-0 AN result : 10 Gbps speed link\n");
	}else if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x7<<10)) == (4<<10)) {
		mcu_printf("5.0G PHY Lane-0 AN result : 2.5 Gbps speed link\n");
	}else if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x7<<10)) == (5<<10)) {
		mcu_printf("5.0G PHY Lane-0 AN result : 5 Gbps speed link\n");
	}else{
		mcu_printf("5.0G PHY Lane-0 AN result : Error, Link speed not supported.\n");
	}

	if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x1<<13)) == (1<<13)) {
		mcu_printf("5.0G PHY Lane-0 AN result : Full duplex\n");
	} else {
		mcu_printf("5.0G PHY Lane-0 AN result : Half duplex\n");
	}

	if((uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg & (0x1<<14)) == (1<<14)) {
		mcu_printf("5.0G PHY Lane-0 AN result : Link up\n");
	} else {
		mcu_printf("5.0G PHY Lane-0 AN result : Link down\n");
	}

	SAL_TaskSleep(100);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-7 : Clear to Auto-negotiation interrupt
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_VR_MII_MMD->uAN_INTR_STS.nReg;
	uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg = RegRead(addr);
	uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg = uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg &  (~(0x1<<0));     // CL37_ANCMPLT_INTR masking
	uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg = uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg |    (  0<<0);      // CL37_ANCMPLT_INTR = 0
	RegWrite(&HwXPCS0_VR_MII_MMD->uAN_INTR_STS.nReg, uPCS0_VR_MII_MMD.uAN_INTR_STS.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-8 : Skip, This step is required only if DWC_xpcs is configured as MAC-side USXGMII
	//----------------------------------------------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-9 : Wait for 1us st that XGMII clocks(clk_xgmii_tx_i/clk_xgmii_rx_i) get stabilized at the desired frequencies
	//----------------------------------------------------------------------------------------------------------------------------
	SAL_TaskSleep(100);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-10 : PCS_DIG_CTRL1.USRA_RST(USXGMII Rate Adapter Reset), This bit can be set to 1 to reset/initialize the USXGMII Rate Adaption(Port 0) indide DWC_xpcs.
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg;
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = RegRead(addr);
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg & (~(0x1<<10));               // USRA_RST masking
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg |   (  1<<10);                // USRA_RST = 1
	RegWrite(&HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg, uPCS0_PCS_MMD.uDIG_CTRL1.nReg);

#if 1
	do{
		addr = &HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg;
		uPCS0_PCS_MMD.uDIG_CTRL1.nReg = RegRead(addr);
	}while((uPCS0_PCS_MMD.uDIG_CTRL1.nReg & (0x1<<10)) != (0<<10));
#endif

	SAL_TaskSleep(100);

	mcu_printf("5Gbps USXGMII Auto-negotiation enable setting done\n");
#else
    // Auto-negotiation disable
	addr = &HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<12));      // AN_ENABLE masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  0<<12);       // AN_ENABLE    = 0
	RegWrite(&HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg, uPCS0_SR_MII_MMD.uMII_CTRL.nReg);

	addr = &HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<< 5));      // SS5 masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  1<< 5);       // SS5          = 1
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<< 6));      // SS5 masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  0<< 6);       // SS5          = 0
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<13));      // SS13 masking
	uPCS0_SR_MII_MMD.uMII_CTRL.nReg  = uPCS0_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<13);       // SS13         = 1
	RegWrite(&HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg, uPCS0_SR_MII_MMD.uMII_CTRL.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-9 : Wait for 1us st that XGMII clocks(clk_xgmii_tx_i/clk_xgmii_rx_i) get stabilized at the desired frequencies
	//----------------------------------------------------------------------------------------------------------------------------
	SAL_TaskSleep(100);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-10 : PCS_DIG_CTRL1.USRA_RST(USXGMII Rate Adapter Reset), This bit can be set to 1 to reset/initialize the USXGMII Rate Adaption(Port 0) indide DWC_xpcs.
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg;
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = RegRead(addr);
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg & (~(0x1<<10));				// USRA_RST masking
	uPCS0_PCS_MMD.uDIG_CTRL1.nReg = uPCS0_PCS_MMD.uDIG_CTRL1.nReg |   (  1<<10);				// USRA_RST = 1
	RegWrite(&HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg, uPCS0_PCS_MMD.uDIG_CTRL1.nReg);

#if 1
	do{
		addr = &HwXPCS0_XS_PCS_MMD->uDIG_CTRL1.nReg;
		uPCS0_PCS_MMD.uDIG_CTRL1.nReg = RegRead(addr);
	}while((uPCS0_PCS_MMD.uDIG_CTRL1.nReg & (0x1<<10)) != (0<<10));
#endif

	SAL_TaskSleep(100);

	mcu_printf("5Gbps USXGMII Auto-negotiation disable setting done\n");
#endif	// AN_EN_5P0G

#ifdef AN_EN_2P5G
	//============================================================================================================================
	// SGMII Auto-negotiation
	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	mcu_printf("2.5Gbps SGMII Auto-negotiation setting start\n");

    //----------------------------------------------------------------------------------------------------------------------------
    // 5.3.1 Auto-negotiation disable
    //----------------------------------------------------------------------------------------------------------------------------
    addr = &HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);     // load XPCS1_SR_MII_MMD.uMMI_CTRL

	if((uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (0x1<<12)) == (1<<12)) {					// Auto negotiation enable check
		uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<12));   // AN_ENABLE masking
		uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  0<<12);    // AN_ENABLE = 0
		RegWrite(&HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg, uPCS1_SR_MII_MMD.uMII_CTRL.nReg);
	}

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3.1-2 : Auto-negotiation control register setting
	//----------------------------------------------------------------------------------------------------------------------------
	// PCS mode 											= SGMII mode (Clause 47 auto-negotiation is as per SGMII)
	// Transmission Configuration							= Configures the DWC_xpcs as the PHY side SGMII
	// Clause 37 Auto-negotiation complete interrupt enable = Enable
	// SGMII Link Status									= Link-up
	// MII Control											= 8-bit MII
	// Full duplex											= Enable
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS1_VR_MII_MMD->uAN_CTRL.nReg;
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = RegRead(addr);
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg & (~(0x3<<1));          // PCS_MODE masking
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg |   (  2<<1);           // PCS_MODE         = 2
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg & (~(0x1<<3));          // TX_CONFIG masking
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg |   (  1<<3);           // TX_CONFIG        = 1
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg & (~(0x1<<0));          // MII_AN_INTR_EN masking
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg |   (  1<<0);           // MII_AN_INTR_EN   = 1
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg & (~(0x1<<4));          // SGMII_LINK_STS masking
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg |   (  1<<4);           // SGMII_LINK_STS   = 1
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg & (~(0x1<<8));          // MII_CTRL masking
	uPCS1_VR_MII_MMD.uAN_CTRL.nReg = uPCS1_VR_MII_MMD.uAN_CTRL.nReg |   (  1<<8);           // MII_CTRL         = 1
	RegWrite(&HwXPCS1_VR_MII_MMD->uAN_CTRL.nReg, uPCS1_VR_MII_MMD.uAN_CTRL.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3.1-3 : Speed selection and Full duplex mode setting
	//----------------------------------------------------------------------------------------------------------------------------
	// SS6, SS13											= {1,0}, 1000Mbps
	//----------------------------------------------------------------------------------------------------------------------------
	// FD													= 1, Full duplex
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<6 ));       // SS6 masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<6 );        // SS6  = 1
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<13));       // SS13 masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  0<<13);        // SS13 = 0
	RegWrite(&HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg, uPCS1_SR_MII_MMD.uMII_CTRL.nReg);

	addr = &HwXPCS1_SR_MII_MMD->uMII_AN_ADV.nReg;
	uPCS1_SR_MII_MMD.uMII_AN_ADV.nReg = RegRead(addr);
	uPCS1_SR_MII_MMD.uMII_AN_ADV.nReg = uPCS1_SR_MII_MMD.uMII_AN_ADV.nReg & (~(0x1<<5));      // FD masking
	uPCS1_SR_MII_MMD.uMII_AN_ADV.nReg = uPCS1_SR_MII_MMD.uMII_AN_ADV.nReg |   (1<<5);       // FD   = 1
	RegWrite(&HwXPCS1_SR_MII_MMD->uMII_AN_ADV.nReg, uPCS1_SR_MII_MMD.uMII_AN_ADV.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3.1-4 : Skip
	//----------------------------------------------------------------------------------------------------------------------------

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3.1-5 : Speed selection and Link timer setting
	//----------------------------------------------------------------------------------------------------------------------------
	// Link timer											= 16ms
	//----------------------------------------------------------------------------------------------------------------------------
	uPCS1_VR_MII_MMD.uLINK_TIMER_CTRL.nReg = 0x07a1;
	RegWrite(&HwXPCS1_VR_MII_MMD->uLINK_TIMER_CTRL.nReg, uPCS1_VR_MII_MMD.uLINK_TIMER_CTRL.nReg);   // CL37_LINK_TIME = 0x07a1

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3.1-6 : Speed selection and Link timer setting
	//----------------------------------------------------------------------------------------------------------------------------
	// Link timer override enable							= 1
	//----------------------------------------------------------------------------------------------------------------------------
	addr = &HwXPCS1_VR_MII_MMD->uMII_DIG_CTRL1.nReg;
	uPCS1_VR_MII_MMD.uMII_DIG_CTRL1.nReg = RegRead(addr);
	uPCS1_VR_MII_MMD.uMII_DIG_CTRL1.nReg = uPCS1_VR_MII_MMD.uMII_DIG_CTRL1.nReg & (~(0x1<<3));      // CL37_TMR_OVR_RIDE masking
	uPCS1_VR_MII_MMD.uMII_DIG_CTRL1.nReg = uPCS1_VR_MII_MMD.uMII_DIG_CTRL1.nReg |   (  1<<3);       // CL37_TMR_OVR_RIDE    = 1
	RegWrite(&HwXPCS1_VR_MII_MMD->uMII_DIG_CTRL1.nReg, uPCS1_VR_MII_MMD.uMII_DIG_CTRL1.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3.1-7 : Auto-negotiation enble
	//----------------------------------------------------------------------------------------------------------------------------
	mcu_printf("2.5Gbps SGMII Auto-negotiation enabled.\n");
	addr = &HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<12));               // AN_ENABLE making
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<12);                // AN_ENABLE = 1
	RegWrite(&HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg, uPCS1_SR_MII_MMD.uMII_CTRL.nReg);

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.3.1-8 : Wait for Auto-negotiation interrupt
	//----------------------------------------------------------------------------------------------------------------------------
#if 0
	do{
		addr = &HwXPCS1_VR_MII_MMD->uAN_INTR_STS.nReg;
		uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg = RegRead(addr);
	}while((uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg & 0x1) != 1);
	mcu_printf("2.5Gbps SGMII Auto-negotiation done.\n");
#endif

	// Clause 37 AN SGMII port status
	if((uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg & (0x1<<1)) == (1<<1)) {
		mcu_printf("2.5G PHY Lane-1 AN result : Full duplex\n");
	} else {
		mcu_printf("2.5G PHY Lane-1 AN result : Half duplex\n");
	}

	if((uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg & (0x3<<2)) == (0<<2)) {
		mcu_printf("2.5G PHY Lane-1 AN result : 10 Mbps speed link\n");
	}
	else if((uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg & (0x3<<2)) == (1<<2)) {
		mcu_printf("2.5G PHY Lane-1 AN result : 100 Mbps speed link\n");
	}
	else if((uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg & (0x3<<2)) == (2<<2)) {
		mcu_printf("2.5G PHY Lane-1 AN result : 1000 Mbps speed link\n");
	}
	else {
		mcu_printf("2.5G PHY Lane-1 AN result : Error, Link speed not supported.\n");
    }

	if((uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg & (0x1<<4)) == (1<<4)) {
		mcu_printf("2.5G PHY Lane-1 AN result : Link up\n");
	} else {
		mcu_printf("2.5G PHY Lane-1 AN result : Link down\n");
	}

	//----------------------------------------------------------------------------------------------------------------------------
	// 5.2.1-9 : Clear to Auto-negotiation interrupt
	//----------------------------------------------------------------------------------------------------------------------------
	mcu_printf("2.5Gbps SGMII Auto-negotiation interrupt clear.\n");

	addr = &HwXPCS1_VR_MII_MMD->uAN_INTR_STS.nReg;
	uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg = RegRead(addr);     // load XPCS0_SR_MII_MMD.uMMI_CTRL
	uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg = uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg & (~(0x1<<0));
	uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg = uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg |   (  0<<0);
	RegWrite(&HwXPCS1_VR_MII_MMD->uAN_INTR_STS.nReg, uPCS1_VR_MII_MMD.uAN_INTR_STS.nReg);
#else
    // Auto-negotiation disable
	addr = &HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<12));       // AN_ENABLE masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  0<<12);        // AN_ENABLE    = 0
	RegWrite(&HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg, uPCS1_SR_MII_MMD.uMII_CTRL.nReg);

	addr = &HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg;
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = RegRead(addr);
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<6 ));       // SS6 masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  1<<6 );        // SS6  = 1
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg & (~(0x1<<13));       // SS13 masking
	uPCS1_SR_MII_MMD.uMII_CTRL.nReg = uPCS1_SR_MII_MMD.uMII_CTRL.nReg |   (  0<<13);        // SS13 = 0
	RegWrite(&HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg, uPCS1_SR_MII_MMD.uMII_CTRL.nReg);
#endif  // AN_EN_2P5G
}

void SerDes_register_dump(void)
{
	unsigned long addr;
	unsigned int val;

	mcu_printf("============ [%s] ============\n", __func__);
#if 0
	addr = &HwXPCS0_XS_PMA_MMD->uPMA_CTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PMA_MMD.uPMA_CTRL1\t: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PMA_MMD->uPMA_CTRL2.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PMA_MMD.uPMA_CTRL2\t: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PMA_MMD->uPMA_KX_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PMA_MMD.uPMA_KX_CTRL\t: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PMA_MMD->uPMA_KX_STS.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PMA_MMD.uPMA_KX_STS		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PMA_MMD->uPMA_DIG_CTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PMA_MMD.uPMA_DIG_CTRL1		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PMA_MMD->uPMA_DIG_STS.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PMA_MMD.uPMA_DIG_STS		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_LSTS.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_LSTS			: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uTX_GENCTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uTX_GENCTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uTX_GENCTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uTX_GENCTRL1		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uTX_GENCTRL2.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uTX_GENCTRL2		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uTX_BOOST_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uTX_BOOST_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uTX_RATE_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uTX_RATE_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uTX_PWR_STS_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uTX_PWR_STS_CTRL	: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uTX_EQ_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uTX_EQ_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uTX_EQ_CTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uTX_EQ_CTRL1		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uTX_GENCTRL3.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uTX_GENCTRL3		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uTX_GENCTRL4.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uTX_GENCTRL4		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uTX_MISC_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uTX_MISC_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uTX_STS.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uTX_STS			: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_GENCTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_GENCTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_GENCTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_GENCTRL1		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_GENCTRL2.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_GENCTRL2		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_GENCTRL3.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_GENCTRL3		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_RATE_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_RATE_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_PWR_STS_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_PWR_STS_CTRL	: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_CDR_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_CDR_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_ATTN_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_ATTN_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_EQ_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_EQ_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_EQ_CTRL4.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_EQ_CTRL4		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_EQ_CTRL5.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_EQ_CTRL5		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uDFE_TAP_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uDFE_TAP_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_STS.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_STS			: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_PPM_STS0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_PPM_STS0		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_CDR_CTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_CDR_CTRL1		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_PPM_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_PPM_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_GENCTRL4.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_GENCTRL4		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_MISC_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_MISC_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uRX_IQ_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uRX_IQ_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uMPLL_CMN_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uMPLL_CMN_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uMPLLA_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uMPLLA_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uMPLLA_CTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uMPLLA_CTRL1		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uMPLLA_CTRL2.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uMPLLA_CTRL2		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uMPLLB_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uMPLLB_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uMPLLB_CTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uMPLLB_CTRL1		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uMPLLB_CTRL2.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uMPLLB_CTRL2		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uMPLLA_CTRL3.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uMPLLA_CTRL3		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uMPLLB_CTRL3.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uMPLLB_CTRL3		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uMPLLA_CTRL4.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uMPLLA_CTRL4		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uMPLLA_CTRL5.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uMPLLA_CTRL5		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uMPLLB_CTRL4.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uMPLLB_CTRL4		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uMPLLB_CTRL5.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uMPLLB_CTRL5		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uMISC_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uMISC_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uREF_CLK_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uREF_CLK_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uVCO_CAL_LD0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uVCO_CAL_LD0		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uVCO_CAL_REF0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uVCO_CAL_REF0		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uMISC_STS.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uMISC_STS			: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uMISC_CTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uMISC_CTRL1		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uSRAM.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uSRAM				: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uMISC_CTRL2.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uMISC_CTRL2		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uSNPS_CR_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uSNPS_CR_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uSNPS_CR_ADDR.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uSNPS_CR_ADDR		: 0x%x\n", addr, val);

	addr = &HwXPCS0_XS_PCS_MMD->uSNPS_CR_DATA.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_PCS_MMD.uSNPS_CR_DATA		: 0x%x\n", addr, val);

	addr = &HwXPCS0_SR_MII_MMD->uMII_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_MII_MMD.uMII_CTRL			: 0x%x\n", addr, val);

	addr = &HwXPCS0_SR_MII_MMD->uMII_AN_ADV.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_MII_MMD.uMII_AN_ADV		: 0x%x\n", addr, val);

	addr = &HwXPCS0_VR_MII_MMD->uMII_DIG_CTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_VR_MII_MMD.uMII_DIG_CTRL1	: 0x%x\n", addr, val);

	addr = &HwXPCS0_VR_MII_MMD->uAN_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_VR_MII_MMD.uAN_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS0_VR_MII_MMD->uAN_INTR_STS.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_VR_MII_MMD.uAN_INTR_STS	: 0x%x\n", addr, val);

	addr = &HwXPCS0_VR_MII_MMD->uMII_DIG_CTRL3.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_VR_MII_MMD.uMII_DIG_CTRL3	: 0x%x\n", addr, val);

	addr = &HwXPCS0_VR_MII_MMD->uLINK_TIMER_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS0_VR_MII_MMD.uLINK_TIMER_CTRL	: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PMA_MMD->uPMA_CTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PMA_MMD.uPMA_CTRL1			: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PMA_MMD->uPMA_CTRL2.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PMA_MMD.uPMA_CTRL2			: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PMA_MMD->uPMA_KX_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PMA_MMD.uPMA_KX_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PMA_MMD->uPMA_KX_STS.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PMA_MMD.uPMA_KX_STS		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PMA_MMD->uPMA_DIG_CTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PMA_MMD.uPMA_DIG_CTRL1		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PMA_MMD->uPMA_DIG_STS.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PMA_MMD.uPMA_DIG_STS		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_LSTS.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_LSTS			: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uTX_GENCTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uTX_GENCTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uTX_GENCTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uTX_GENCTRL1		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uTX_GENCTRL2.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uTX_GENCTRL2		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uTX_BOOST_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uTX_BOOST_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uTX_RATE_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uTX_RATE_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uTX_PWR_STS_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uTX_PWR_STS_CTRL	: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uTX_EQ_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uTX_EQ_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uTX_EQ_CTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uTX_EQ_CTRL1		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uTX_GENCTRL3.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uTX_GENCTRL3		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uTX_GENCTRL4.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uTX_GENCTRL4		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uTX_MISC_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uTX_MISC_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uTX_STS.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uTX_STS			: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_GENCTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_GENCTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_GENCTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_GENCTRL1		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_GENCTRL2.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_GENCTRL2		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_GENCTRL3.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_GENCTRL3		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_RATE_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_RATE_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_PWR_STS_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_PWR_STS_CTRL	: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_CDR_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_CDR_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_ATTN_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_ATTN_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_EQ_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_EQ_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_EQ_CTRL4.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_EQ_CTRL4		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_EQ_CTRL5.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_EQ_CTRL5		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uDFE_TAP_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uDFE_TAP_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_STS.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_STS			: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_PPM_STS0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_PPM_STS0		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_CDR_CTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_CDR_CTRL1		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_PPM_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_PPM_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_GENCTRL4.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_GENCTRL4		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_MISC_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_MISC_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uRX_IQ_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uRX_IQ_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uMPLL_CMN_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uMPLL_CMN_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uMPLLA_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uMPLLA_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uMPLLA_CTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uMPLLA_CTRL1		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uMPLLA_CTRL2.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uMPLLA_CTRL2		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uMPLLB_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uMPLLB_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uMPLLB_CTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uMPLLB_CTRL1		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uMPLLB_CTRL2.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uMPLLB_CTRL2		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uMPLLA_CTRL3.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uMPLLA_CTRL3		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uMPLLB_CTRL3.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uMPLLB_CTRL3		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uMPLLA_CTRL4.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uMPLLA_CTRL4		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uMPLLA_CTRL5.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uMPLLA_CTRL5		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uMPLLB_CTRL4.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uMPLLB_CTRL4		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uMPLLB_CTRL5.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uMPLLB_CTRL5		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uMISC_CTRL0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uMISC_CTRL0		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uREF_CLK_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uREF_CLK_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uVCO_CAL_LD0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uVCO_CAL_LD0		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uVCO_CAL_REF0.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uVCO_CAL_REF0		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uMISC_STS.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uMISC_STS			: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uMISC_CTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uMISC_CTRL1		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uSRAM.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uSRAM				: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uMISC_CTRL2.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uMISC_CTRL2		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uSNPS_CR_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uSNPS_CR_CTRL		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uSNPS_CR_ADDR.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uSNPS_CR_ADDR		: 0x%x\n", addr, val);

	addr = &HwXPCS1_XS_PCS_MMD->uSNPS_CR_DATA.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_PCS_MMD.uSNPS_CR_DATA		: 0x%x\n", addr, val);

	addr = &HwXPCS1_SR_MII_MMD->uMII_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_MII_MMD.uMII_CTRL\t\t: 0x%x\n", addr, val);

	addr = &HwXPCS1_SR_MII_MMD->uMII_AN_ADV.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_MII_MMD.uMII_AN_ADV\t\t: 0x%x\n", addr, val);

	addr = &HwXPCS1_VR_MII_MMD->uMII_DIG_CTRL1.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_VR_MII_MMD.uMII_DIG_CTRL1\t: 0x%x\n", addr, val);

	addr = &HwXPCS1_VR_MII_MMD->uAN_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_VR_MII_MMD.uAN_CTRL\t\t: 0x%x\n", addr, val);

	addr = &HwXPCS1_VR_MII_MMD->uAN_INTR_STS.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_VR_MII_MMD.uAN_INTR_STS\t\t: 0x%x\n", addr, val);

	addr = &HwXPCS1_VR_MII_MMD->uMII_DIG_CTRL3.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_VR_MII_MMD.uMII_DIG_CTRL3\t: 0x%x\n", addr, val);

	addr = &HwXPCS1_VR_MII_MMD->uLINK_TIMER_CTRL.nReg;
	val = RegRead(addr);
	mcu_printf("[0x%x] uPCS1_VR_MII_MMD.uLINK_TIMER_CTRL\t: 0x%x\n", addr, val);
#else
	//----------------------------------------------------------------------------------------------------------------------------
	// XPCS-0
	//----------------------------------------------------------------------------------------------------------------------------
    mcu_printf("==================================================================\n");
    mcu_printf(" XPCS0.PMA_MMD Registers\n");
    mcu_printf("vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\n");
    mcu_printf(" XPCS0.SR_PMA_CTRL1                                 : 0x%x\n", RegRead(0xB00000));
    mcu_printf(" XPCS0.SR_PMA_STATUS1                               : 0x%x\n", RegRead(0xB00004));
    mcu_printf(" XPCS0.SR_PMA_DEV_ID_1                              : 0x%x\n", RegRead(0xB00008));
    mcu_printf(" XPCS0.SR_PMA_DEV_ID_2                              : 0x%x\n", RegRead(0xB0000C));
    mcu_printf(" XPCS0.SR_PMA_SPD_ABL                               : 0x%x\n", RegRead(0xB00010));
    mcu_printf(" XPCS0.SR_PMA_DEV_PKG1                              : 0x%x\n", RegRead(0xB00014));
    mcu_printf(" XPCS0.SR_PMA_DEV_PKG2                              : 0x%x\n", RegRead(0xB00018));
    mcu_printf(" XPCS0.SR_PMA_CTRL2                                 : 0x%x\n", RegRead(0xB0001C));
    mcu_printf(" XPCS0.SR_PMA_STATUS2                               : 0x%x\n", RegRead(0xB00020));
    mcu_printf(" XPCS0.SR_PMA_TX_DIS                                : 0x%x\n", RegRead(0xB00024));
    mcu_printf(" XPCS0.SR_PMA_RX_SIG_DET                            : 0x%x\n", RegRead(0xB00028));
    mcu_printf(" XPCS0.SR_PMA_EXT_ABL                               : 0x%x\n", RegRead(0xB0002C));
    mcu_printf(" XPCS0.SR_PMA_PKG1                                  : 0x%x\n", RegRead(0xB00038));
    mcu_printf(" XPCS0.SR_PMA_PKG2                                  : 0x%x\n", RegRead(0xB0003C));
    mcu_printf(" XPCS0.SR_PMA_2PT5G_5G_EXT_ABL                      : 0x%x\n", RegRead(0xB00054));
    mcu_printf(" XPCS0.SR_PMA_KX_CTRL                               : 0x%x\n", RegRead(0xB00280));
    mcu_printf(" XPCS0.SR_PMA_KX_STS                                : 0x%x\n", RegRead(0xB00284));
    mcu_printf(" XPCS0.SR_PMA_TIME_SYNC_PMA_ABL                     : 0x%x\n", RegRead(0xB01C20));
    mcu_printf(" XPCS0.SR_PMA_TIME_SYNC_TX_MAX_DLY_LWR              : 0x%x\n", RegRead(0xB01C24));
    mcu_printf(" XPCS0.SR_PMA_TIME_SYNC_TX_MAX_DLY_UPR              : 0x%x\n", RegRead(0xB01C28));
    mcu_printf(" XPCS0.SR_PMA_TIME_SYNC_TX_MIN_DLY_LWR              : 0x%x\n", RegRead(0xB01C2C));
    mcu_printf(" XPCS0.SR_PMA_TIME_SYNC_TX_MIN_DLY_UPR              : 0x%x\n", RegRead(0xB01C30));
    mcu_printf(" XPCS0.SR_PMA_TIME_SYNC_RX_MAX_DLY_LWR              : 0x%x\n", RegRead(0xB01C34));
    mcu_printf(" XPCS0.SR_PMA_TIME_SYNC_RX_MAX_DLY_UPR              : 0x%x\n", RegRead(0xB01C38));
    mcu_printf(" XPCS0.SR_PMA_TIME_SYNC_RX_MIN_DLY_LWR              : 0x%x\n", RegRead(0xB01C3C));
    mcu_printf(" XPCS0.SR_PMA_TIME_SYNC_RX_MIN_DLY_UPR              : 0x%x\n", RegRead(0xB01C40));
    mcu_printf(" XPCS0.VR_PMA_DIG_CTRL1                             : 0x%x\n", RegRead(0xB20000));
    mcu_printf(" XPCS0.VR_PMA_DIG_STS                               : 0x%x\n", RegRead(0xB20040));

    mcu_printf("==================================================================\n");
    mcu_printf(" XPCS0.XS_PMA_MMD Registers\n");
    mcu_printf("vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\n");
    mcu_printf(" XPCS0.VR_XS_PMA_RX_LSTS                            : 0x%x\n", RegRead(0xB20080));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_TX_GENCTRL0         : 0x%x\n", RegRead(0xB200C0));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_TX_GENCTRL1         : 0x%x\n", RegRead(0xB200C4));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_TX_GENCTRL2             : 0x%x\n", RegRead(0xB200C8));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_TX_BOOST_CTRL       : 0x%x\n", RegRead(0xB200CC));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_TX_RATE_CTRL        : 0x%x\n", RegRead(0xB200D0));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_TX_POWER_STATE_CTRL : 0x%x\n", RegRead(0xB200D4));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_TX_EQ_CTRL0         : 0x%x\n", RegRead(0xB200D8));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_TX_EQ_CTRL1         : 0x%x\n", RegRead(0xB200DC));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_25G_TX_GENCTRL3             : 0x%x\n", RegRead(0xB200F0));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_25G_TX_GENCTRL4             : 0x%x\n", RegRead(0xB200F4));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_25G_TX_MISC_CTRL0           : 0x%x\n", RegRead(0xB200F8));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_TX_STS              : 0x%x\n", RegRead(0xB20100));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_RX_GENCTRL0         : 0x%x\n", RegRead(0xB20140));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_RX_GENCTRL1         : 0x%x\n", RegRead(0xB20144));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_RX_GENCTRL2             : 0x%x\n", RegRead(0xB20148));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_RX_GENCTRL3             : 0x%x\n", RegRead(0xB2014C));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_RX_RATE_CTRL        : 0x%x\n", RegRead(0xB20150));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_RX_POWER_STATE_CTRL : 0x%x\n", RegRead(0xB20154));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_RX_CDR_CTRL         : 0x%x\n", RegRead(0xB20158));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_RX_ATTN_CTRL        : 0x%x\n", RegRead(0xB2015C));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_25G_RX_EQ_CTRL0             : 0x%x\n", RegRead(0xB20160));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_RX_EQ_CTRL4         : 0x%x\n", RegRead(0xB20170));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_25G_RX_EQ_CTRL5             : 0x%x\n", RegRead(0xB20174));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_DFE_TAP_CTRL0       : 0x%x\n", RegRead(0xB20178));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_RX_STS              : 0x%x\n", RegRead(0xB20180));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_25G_RX_PPM_STS0             : 0x%x\n", RegRead(0xB20184));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_RX_CDR_CTRL1                : 0x%x\n", RegRead(0xB20190));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_25G_RX_PPM_CTRL0            : 0x%x\n", RegRead(0xB20194));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_25G_RX_GENCTRL4             : 0x%x\n", RegRead(0xB201A0));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_25G_RX_MISC_CTRL0           : 0x%x\n", RegRead(0xB201A4));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_25G_RX_IQ_CTRL0             : 0x%x\n", RegRead(0xB201AC));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_MPLL_CMN_CTRL       : 0x%x\n", RegRead(0xB201C0));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_MPLLA_CTRL0             : 0x%x\n", RegRead(0xB201C4));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_MPLLA_CTRL1                 : 0x%x\n", RegRead(0xB201C8));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_MPLLA_CTRL2             : 0x%x\n", RegRead(0xB201CC));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_MPLLB_CTRL0             : 0x%x\n", RegRead(0xB201D0));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_MPLLB_CTRL1                 : 0x%x\n", RegRead(0xB201D4));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_MPLLB_CTRL2             : 0x%x\n", RegRead(0xB201D8));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_MPLLA_CTRL3                 : 0x%x\n", RegRead(0xB201DC));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_MPLLB_CTRL3                 : 0x%x\n", RegRead(0xB201E0));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_MPLLA_CTRL4                 : 0x%x\n", RegRead(0xB201E4));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_MPLLA_CTRL5                 : 0x%x\n", RegRead(0xB201E8));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_MPLLB_CTRL4                 : 0x%x\n", RegRead(0xB201EC));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_MPLLB_CTRL5                 : 0x%x\n", RegRead(0xB201F0));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_MISC_CTRL0          : 0x%x\n", RegRead(0xB20240));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_REF_CLK_CTRL        : 0x%x\n", RegRead(0xB20244));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_VCO_CAL_LD0         : 0x%x\n", RegRead(0xB20248));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_25G_VCO_CAL_REF0            : 0x%x\n", RegRead(0xB20258));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_MISC_STS            : 0x%x\n", RegRead(0xB20260));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_MISC_CTRL1          : 0x%x\n", RegRead(0xB20264));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_12G_16G_25G_SRAM                : 0x%x\n", RegRead(0xB2026C));
    mcu_printf(" XPCS0.VR_XS_PMA_MP_16G_25G_MISC_CTRL2              : 0x%x\n", RegRead(0xB20270));
    mcu_printf(" XPCS0.VR_XS_PMA_SNPS_CR_CTRL                       : 0x%x\n", RegRead(0xB20280));
    mcu_printf(" XPCS0.VR_XS_PMA_SNPS_CR_ADDR                       : 0x%x\n", RegRead(0xB20284));
    mcu_printf(" XPCS0.VR_XS_PMA_SNPS_CR_DATA                       : 0x%x\n", RegRead(0xB20288));

    mcu_printf("==================================================================\n");
    mcu_printf(" XPCS0.XS_PCS_MMD Registers\n");
    mcu_printf("vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\n");
    mcu_printf(" XPCS0.SR_XS_PCS_CTRL1                              : 0x%x\n", RegRead(0xB40000));
    mcu_printf(" XPCS0.SR_XS_PCS_STS1                               : 0x%x\n", RegRead(0xB40004));
    mcu_printf(" XPCS0.SR_XS_PCS_DEV_ID1                            : 0x%x\n", RegRead(0xB40008));
    mcu_printf(" XPCS0.SR_XS_PCS_DEV_ID2                            : 0x%x\n", RegRead(0xB4000C));
    mcu_printf(" XPCS0.SR_XS_PCS_SPD_ABL                            : 0x%x\n", RegRead(0xB40010));
    mcu_printf(" XPCS0.SR_XS_PCS_DEV_PKG1                           : 0x%x\n", RegRead(0xB40014));
    mcu_printf(" XPCS0.SR_XS_PCS_DEV_PKG2                           : 0x%x\n", RegRead(0xB40018));
    mcu_printf(" XPCS0.SR_XS_PCS_CTRL2                              : 0x%x\n", RegRead(0xB4001C));
    mcu_printf(" XPCS0.SR_XS_PCS_STS2                               : 0x%x\n", RegRead(0xB40020));
    mcu_printf(" XPCS0.SR_XS_PCS_STS3                               : 0x%x\n", RegRead(0xB40024));
    mcu_printf(" XPCS0.SR_XS_PCS_PKG1                               : 0x%x\n", RegRead(0xB40038));
    mcu_printf(" XPCS0.SR_XS_PCS_PKG2                               : 0x%x\n", RegRead(0xB4003C));
    mcu_printf(" XPCS0.SR_XS_PCS_LSTS                               : 0x%x\n", RegRead(0xB40060));
    mcu_printf(" XPCS0.SR_XS_PCS_TCTRL                              : 0x%x\n", RegRead(0xB40064));
    mcu_printf(" XPCS0.SR_XS_PCS_KR_STS1                            : 0x%x\n", RegRead(0xB40080));
    mcu_printf(" XPCS0.SR_XS_PCS_KR_STS2                            : 0x%x\n", RegRead(0xB40084));
    mcu_printf(" XPCS0.SR_XS_PCS_TP_A0                              : 0x%x\n", RegRead(0xB40088));
    mcu_printf(" XPCS0.SR_XS_PCS_TP_A1                              : 0x%x\n", RegRead(0xB4008C));
    mcu_printf(" XPCS0.SR_XS_PCS_TP_A2                              : 0x%x\n", RegRead(0xB40090));
    mcu_printf(" XPCS0.SR_XS_PCS_TP_A3                              : 0x%x\n", RegRead(0xB40094));
    mcu_printf(" XPCS0.SR_XS_PCS_TP_B0                              : 0x%x\n", RegRead(0xB40098));
    mcu_printf(" XPCS0.SR_XS_PCS_TP_B1                              : 0x%x\n", RegRead(0xB4009C));
    mcu_printf(" XPCS0.SR_XS_PCS_TP_B2                              : 0x%x\n", RegRead(0xB400A0));
    mcu_printf(" XPCS0.SR_XS_PCS_TP_B3                              : 0x%x\n", RegRead(0xB400A4));
    mcu_printf(" XPCS0.SR_XS_PCS_TP_CTRL                            : 0x%x\n", RegRead(0xB400A8));
    mcu_printf(" XPCS0.SR_XS_PCS_TP_ERRCTR                          : 0x%x\n", RegRead(0xB400AC));
    mcu_printf(" XPCS0.SR_PCS_TIME_SYNC_PCS_ABL                     : 0x%x\n", RegRead(0xB41C20));
    mcu_printf(" XPCS0.SR_PCS_TIME_SYNC_TX_MAX_DLY_LWR              : 0x%x\n", RegRead(0xB41C24));
    mcu_printf(" XPCS0.SR_PCS_TIME_SYNC_TX_MAX_DLY_UPR              : 0x%x\n", RegRead(0xB41C28));
    mcu_printf(" XPCS0.SR_PCS_TIME_SYNC_TX_MIN_DLY_LWR              : 0x%x\n", RegRead(0xB41C2C));
    mcu_printf(" XPCS0.SR_PCS_TIME_SYNC_TX_MIN_DLY_UPR              : 0x%x\n", RegRead(0xB41C30));
    mcu_printf(" XPCS0.SR_PCS_TIME_SYNC_RX_MAX_DLY_LWR              : 0x%x\n", RegRead(0xB41C34));
    mcu_printf(" XPCS0.SR_PCS_TIME_SYNC_RX_MAX_DLY_UPR              : 0x%x\n", RegRead(0xB41C38));
    mcu_printf(" XPCS0.SR_PCS_TIME_SYNC_RX_MIN_DLY_LWR              : 0x%x\n", RegRead(0xB41C3C));
    mcu_printf(" XPCS0.SR_PCS_TIME_SYNC_RX_MIN_DLY_UPR              : 0x%x\n", RegRead(0xB41C40));
    mcu_printf(" XPCS0.VR_XS_PCS_DIG_CTRL1                          : 0x%x\n", RegRead(0xB60000));
    mcu_printf(" XPCS0.VR_XS_PCS_DIG_CTRL2                          : 0x%x\n", RegRead(0xB60004));
    mcu_printf(" XPCS0.VR_XS_PCS_DIG_ERRCNT_SEL                     : 0x%x\n", RegRead(0xB60008));
    mcu_printf(" XPCS0.VR_XS_PCS_XAUI_CTRL                          : 0x%x\n", RegRead(0xB60010));
    mcu_printf(" XPCS0.VR_XS_PCS_DEBUG_CTRL                         : 0x%x\n", RegRead(0xB60014));
    mcu_printf(" XPCS0.VR_XS_PCS_KR_CTRL                            : 0x%x\n", RegRead(0xB6001C));
    mcu_printf(" XPCS0.VR_XS_PCS_DIG_STS                            : 0x%x\n", RegRead(0xB60040));
    mcu_printf(" XPCS0.VR_XS_PCS_ICG_ERRCNT1                        : 0x%x\n", RegRead(0xB60044));
    mcu_printf(" XPCS0.VR_XS_PCS_CDT_STS                            : 0x%x\n", RegRead(0xB60060));
    mcu_printf(" XPCS0.VR_XS_PCS_MISC_STS                           : 0x%x\n", RegRead(0xB60064));
    mcu_printf(" XPCS0.VR_XS_PCS_SFTY_UE_INTR0                      : 0x%x\n", RegRead(0xB603C0));
    mcu_printf(" XPCS0.VR_XS_PCS_SFTY_ERR_INJ                       : 0x%x\n", RegRead(0xB603C4));
    mcu_printf(" XPCS0.VR_XS_PCS_SFTY_CE_INTR                       : 0x%x\n", RegRead(0xB603C8));
    mcu_printf(" XPCS0.VR_XS_PCS_SFTY_DBG_CTRL                      : 0x%x\n", RegRead(0xB603CC));
    mcu_printf(" XPCS0.VR_XS_PCS_SFTY_DISABLE                       : 0x%x\n", RegRead(0xB603D0));
    mcu_printf(" XPCS0.VR_XS_PCS_SFTY_TMR_CTRL                      : 0x%x\n", RegRead(0xB603D4));
    mcu_printf(" XPCS0.VR_XS_PCS_SFTY_UE_INTR1                      : 0x%x\n", RegRead(0xB603E0));

    mcu_printf("==================================================================\n");
    mcu_printf(" XPCS0.VS_MMD1 Registers\n");
    mcu_printf("vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\n");
    mcu_printf(" XPCS0.SR_VSMMD_PMA_ID1                             : 0x%x\n", RegRead(0xB80000));
    mcu_printf(" XPCS0.SR_VSMMD_PMA_ID2                             : 0x%x\n", RegRead(0xB80004));
    mcu_printf(" XPCS0.SR_VSMMD_DEV_ID1                             : 0x%x\n", RegRead(0xB80008));
    mcu_printf(" XPCS0.SR_VSMMD_DEV_ID2                             : 0x%x\n", RegRead(0xB8000C));
    mcu_printf(" XPCS0.SR_VSMMD_PCS_ID1                             : 0x%x\n", RegRead(0xB80010));
    mcu_printf(" XPCS0.SR_VSMMD_PCS_ID2                             : 0x%x\n", RegRead(0xB80014));
    mcu_printf(" XPCS0.SR_VSMMD_AN_ID1                              : 0x%x\n", RegRead(0xB80018));
    mcu_printf(" XPCS0.SR_VSMMD_AN_ID2                              : 0x%x\n", RegRead(0xB8001C));
    mcu_printf(" XPCS0.SR_VSMMD_STS                                 : 0x%x\n", RegRead(0xB80020));
    mcu_printf(" XPCS0.SR_VSMMD_CTRL                                : 0x%x\n", RegRead(0xB80024));
    mcu_printf(" XPCS0.SR_VSMMD_PKGID1                              : 0x%x\n", RegRead(0xB80038));
    mcu_printf(" XPCS0.SR_VSMMD_PKGID2                              : 0x%x\n", RegRead(0xB8003C));

    mcu_printf("==================================================================\n");
    mcu_printf(" XPCS0.VS_MII_MMD Registers\n");
    mcu_printf("vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\n");
    mcu_printf(" XPCS0.SR_MII_CTRL                                  : 0x%x\n", RegRead(0xBC0000));
    mcu_printf(" XPCS0.SR_MII_STS                                   : 0x%x\n", RegRead(0xBC0004));
    mcu_printf(" XPCS0.SR_MII_DEV_ID1                               : 0x%x\n", RegRead(0xBC0008));
    mcu_printf(" XPCS0.SR_MII_DEV_ID2                               : 0x%x\n", RegRead(0xBC000C));
    mcu_printf(" XPCS0.SR_MII_AN_ADV                                : 0x%x\n", RegRead(0xBC0010));
    mcu_printf(" XPCS0.SR_MII_LP_BABL                               : 0x%x\n", RegRead(0xBC0014));
    mcu_printf(" XPCS0.SR_MII_AN_EXPN                               : 0x%x\n", RegRead(0xBC0018));
    mcu_printf(" XPCS0.SR_MII_EXT_STS                               : 0x%x\n", RegRead(0xBC003C));
    mcu_printf(" XPCS0.VR_MII_DIG_CTRL1                             : 0x%x\n", RegRead(0xBE0000));
    mcu_printf(" XPCS0.VR_MII_AN_CTRL                               : 0x%x\n", RegRead(0xBE0004));
    mcu_printf(" XPCS0.VR_MII_AN_INTR_STS                           : 0x%x\n", RegRead(0xBE0008));
    mcu_printf(" XPCS0.VR_MII_DIG_CTRL3                             : 0x%x\n", RegRead(0xBE0010));
    mcu_printf(" XPCS0.VR_MII_LINK_TIMER_CTRL                       : 0x%x\n", RegRead(0xBE0028));

    //----------------------------------------------------------------------------------------------------------------------------
    // XPCS-1
    //----------------------------------------------------------------------------------------------------------------------------
    mcu_printf("==================================================================\n");
    mcu_printf(" XPCS1.PMA_MMD Registers\n");
    mcu_printf("vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\n");
    mcu_printf(" XPCS1.SR_PMA_CTRL1                                 : 0x%x\n", RegRead(0x000000));
    mcu_printf(" XPCS1.SR_PMA_STATUS1                               : 0x%x\n", RegRead(0x000004));
    mcu_printf(" XPCS1.SR_PMA_DEV_ID_1                              : 0x%x\n", RegRead(0x000008));
    mcu_printf(" XPCS1.SR_PMA_DEV_ID_2                              : 0x%x\n", RegRead(0x00000C));
    mcu_printf(" XPCS1.SR_PMA_SPD_ABL                               : 0x%x\n", RegRead(0x000010));
    mcu_printf(" XPCS1.SR_PMA_DEV_PKG1                              : 0x%x\n", RegRead(0x000014));
    mcu_printf(" XPCS1.SR_PMA_DEV_PKG2                              : 0x%x\n", RegRead(0x000018));
    mcu_printf(" XPCS1.SR_PMA_CTRL2                                 : 0x%x\n", RegRead(0x00001C));
    mcu_printf(" XPCS1.SR_PMA_STATUS2                               : 0x%x\n", RegRead(0x000020));
    mcu_printf(" XPCS1.SR_PMA_TX_DIS                                : 0x%x\n", RegRead(0x000024));
    mcu_printf(" XPCS1.SR_PMA_RX_SIG_DET                            : 0x%x\n", RegRead(0x000028));
    mcu_printf(" XPCS1.SR_PMA_EXT_ABL                               : 0x%x\n", RegRead(0x00002C));
    mcu_printf(" XPCS1.SR_PMA_PKG1                                  : 0x%x\n", RegRead(0x000038));
    mcu_printf(" XPCS1.SR_PMA_PKG2                                  : 0x%x\n", RegRead(0x00003C));
    mcu_printf(" XPCS1.SR_PMA_2PT5G_5G_EXT_ABL                      : 0x%x\n", RegRead(0x000054));
    mcu_printf(" XPCS1.SR_PMA_KX_CTRL                               : 0x%x\n", RegRead(0x000280));
    mcu_printf(" XPCS1.SR_PMA_KX_STS                                : 0x%x\n", RegRead(0x000284));
    mcu_printf(" XPCS1.SR_PMA_TIME_SYNC_PMA_ABL                     : 0x%x\n", RegRead(0x001C20));
    mcu_printf(" XPCS1.SR_PMA_TIME_SYNC_TX_MAX_DLY_LWR              : 0x%x\n", RegRead(0x001C24));
    mcu_printf(" XPCS1.SR_PMA_TIME_SYNC_TX_MAX_DLY_UPR              : 0x%x\n", RegRead(0x001C28));
    mcu_printf(" XPCS1.SR_PMA_TIME_SYNC_TX_MIN_DLY_LWR              : 0x%x\n", RegRead(0x001C2C));
    mcu_printf(" XPCS1.SR_PMA_TIME_SYNC_TX_MIN_DLY_UPR              : 0x%x\n", RegRead(0x001C30));
    mcu_printf(" XPCS1.SR_PMA_TIME_SYNC_RX_MAX_DLY_LWR              : 0x%x\n", RegRead(0x001C34));
    mcu_printf(" XPCS1.SR_PMA_TIME_SYNC_RX_MAX_DLY_UPR              : 0x%x\n", RegRead(0x001C38));
    mcu_printf(" XPCS1.SR_PMA_TIME_SYNC_RX_MIN_DLY_LWR              : 0x%x\n", RegRead(0x001C3C));
    mcu_printf(" XPCS1.SR_PMA_TIME_SYNC_RX_MIN_DLY_UPR              : 0x%x\n", RegRead(0x001C40));
    mcu_printf(" XPCS1.VR_PMA_DIG_CTRL1                             : 0x%x\n", RegRead(0x020000));
    mcu_printf(" XPCS1.VR_PMA_DIG_STS                               : 0x%x\n", RegRead(0x020040));

    mcu_printf("==================================================================\n");
    mcu_printf(" XPCS1.XS_PMA_MMD Registers\n");
    mcu_printf("vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\n");
    mcu_printf(" XPCS1.VR_XS_PMA_RX_LSTS                            : 0x%x\n", RegRead(0x020080));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_TX_GENCTRL0         : 0x%x\n", RegRead(0x0200C0));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_TX_GENCTRL1         : 0x%x\n", RegRead(0x0200C4));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_TX_GENCTRL2             : 0x%x\n", RegRead(0x0200C8));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_TX_BOOST_CTRL       : 0x%x\n", RegRead(0x0200CC));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_TX_RATE_CTRL        : 0x%x\n", RegRead(0x0200D0));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_TX_POWER_STATE_CTRL : 0x%x\n", RegRead(0x0200D4));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_TX_EQ_CTRL0         : 0x%x\n", RegRead(0x0200D8));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_TX_EQ_CTRL1         : 0x%x\n", RegRead(0x0200DC));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_25G_TX_GENCTRL3             : 0x%x\n", RegRead(0x0200F0));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_25G_TX_GENCTRL4             : 0x%x\n", RegRead(0x0200F4));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_25G_TX_MISC_CTRL0           : 0x%x\n", RegRead(0x0200F8));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_TX_STS              : 0x%x\n", RegRead(0x020100));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_RX_GENCTRL0         : 0x%x\n", RegRead(0x020140));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_RX_GENCTRL1         : 0x%x\n", RegRead(0x020144));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_RX_GENCTRL2             : 0x%x\n", RegRead(0x020148));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_RX_GENCTRL3             : 0x%x\n", RegRead(0x02014C));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_RX_RATE_CTRL        : 0x%x\n", RegRead(0x020150));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_RX_POWER_STATE_CTRL : 0x%x\n", RegRead(0x020154));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_RX_CDR_CTRL         : 0x%x\n", RegRead(0x020158));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_RX_ATTN_CTRL        : 0x%x\n", RegRead(0x02015C));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_25G_RX_EQ_CTRL0             : 0x%x\n", RegRead(0x020160));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_RX_EQ_CTRL4         : 0x%x\n", RegRead(0x020170));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_25G_RX_EQ_CTRL5             : 0x%x\n", RegRead(0x020174));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_DFE_TAP_CTRL0       : 0x%x\n", RegRead(0x020178));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_RX_STS              : 0x%x\n", RegRead(0x020180));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_25G_RX_PPM_STS0             : 0x%x\n", RegRead(0x020184));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_RX_CDR_CTRL1                : 0x%x\n", RegRead(0x020190));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_25G_RX_PPM_CTRL0            : 0x%x\n", RegRead(0x020194));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_25G_RX_GENCTRL4             : 0x%x\n", RegRead(0x0201A0));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_25G_RX_MISC_CTRL0           : 0x%x\n", RegRead(0x0201A4));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_25G_RX_IQ_CTRL0             : 0x%x\n", RegRead(0x0201AC));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_MPLL_CMN_CTRL       : 0x%x\n", RegRead(0x0201C0));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_MPLLA_CTRL0             : 0x%x\n", RegRead(0x0201C4));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_MPLLA_CTRL1                 : 0x%x\n", RegRead(0x0201C8));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_MPLLA_CTRL2             : 0x%x\n", RegRead(0x0201CC));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_MPLLB_CTRL0             : 0x%x\n", RegRead(0x0201D0));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_MPLLB_CTRL1                 : 0x%x\n", RegRead(0x0201D4));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_MPLLB_CTRL2             : 0x%x\n", RegRead(0x0201D8));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_MPLLA_CTRL3                 : 0x%x\n", RegRead(0x0201DC));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_MPLLB_CTRL3                 : 0x%x\n", RegRead(0x0201E0));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_MPLLA_CTRL4                 : 0x%x\n", RegRead(0x0201E4));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_MPLLA_CTRL5                 : 0x%x\n", RegRead(0x0201E8));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_MPLLB_CTRL4                 : 0x%x\n", RegRead(0x0201EC));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_MPLLB_CTRL5                 : 0x%x\n", RegRead(0x0201F0));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_MISC_CTRL0          : 0x%x\n", RegRead(0x020240));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_REF_CLK_CTRL        : 0x%x\n", RegRead(0x020244));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_VCO_CAL_LD0         : 0x%x\n", RegRead(0x020248));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_25G_VCO_CAL_REF0            : 0x%x\n", RegRead(0x020258));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_MISC_STS            : 0x%x\n", RegRead(0x020260));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_MISC_CTRL1          : 0x%x\n", RegRead(0x020264));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_12G_16G_25G_SRAM                : 0x%x\n", RegRead(0x02026C));
    mcu_printf(" XPCS1.VR_XS_PMA_MP_16G_25G_MISC_CTRL2              : 0x%x\n", RegRead(0x020270));
    mcu_printf(" XPCS1.VR_XS_PMA_SNPS_CR_CTRL                       : 0x%x\n", RegRead(0x020280));
    mcu_printf(" XPCS1.VR_XS_PMA_SNPS_CR_ADDR                       : 0x%x\n", RegRead(0x020284));
    mcu_printf(" XPCS1.VR_XS_PMA_SNPS_CR_DATA                       : 0x%x\n", RegRead(0x020288));

    mcu_printf("==================================================================\n");
    mcu_printf(" XPCS1.XS_PCS_MMD Registers\n");
    mcu_printf("vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\n");
    mcu_printf(" XPCS1.SR_XS_PCS_CTRL1                              : 0x%x\n", RegRead(0x040000));
    mcu_printf(" XPCS1.SR_XS_PCS_STS1                               : 0x%x\n", RegRead(0x040004));
    mcu_printf(" XPCS1.SR_XS_PCS_DEV_ID1                            : 0x%x\n", RegRead(0x040008));
    mcu_printf(" XPCS1.SR_XS_PCS_DEV_ID2                            : 0x%x\n", RegRead(0x04000C));
    mcu_printf(" XPCS1.SR_XS_PCS_SPD_ABL                            : 0x%x\n", RegRead(0x040010));
    mcu_printf(" XPCS1.SR_XS_PCS_DEV_PKG1                           : 0x%x\n", RegRead(0x040014));
    mcu_printf(" XPCS1.SR_XS_PCS_DEV_PKG2                           : 0x%x\n", RegRead(0x040018));
    mcu_printf(" XPCS1.SR_XS_PCS_CTRL2                              : 0x%x\n", RegRead(0x04001C));
    mcu_printf(" XPCS1.SR_XS_PCS_STS2                               : 0x%x\n", RegRead(0x040020));
    mcu_printf(" XPCS1.SR_XS_PCS_STS3                               : 0x%x\n", RegRead(0x040024));
    mcu_printf(" XPCS1.SR_XS_PCS_PKG1                               : 0x%x\n", RegRead(0x040038));
    mcu_printf(" XPCS1.SR_XS_PCS_PKG2                               : 0x%x\n", RegRead(0x04003C));
    mcu_printf(" XPCS1.SR_XS_PCS_LSTS                               : 0x%x\n", RegRead(0x040060));
    mcu_printf(" XPCS1.SR_XS_PCS_TCTRL                              : 0x%x\n", RegRead(0x040064));
    mcu_printf(" XPCS1.SR_XS_PCS_KR_STS1                            : 0x%x\n", RegRead(0x040080));
    mcu_printf(" XPCS1.SR_XS_PCS_KR_STS2                            : 0x%x\n", RegRead(0x040084));
    mcu_printf(" XPCS1.SR_XS_PCS_TP_A0                              : 0x%x\n", RegRead(0x040088));
    mcu_printf(" XPCS1.SR_XS_PCS_TP_A1                              : 0x%x\n", RegRead(0x04008C));
    mcu_printf(" XPCS1.SR_XS_PCS_TP_A2                              : 0x%x\n", RegRead(0x040090));
    mcu_printf(" XPCS1.SR_XS_PCS_TP_A3                              : 0x%x\n", RegRead(0x040094));
    mcu_printf(" XPCS1.SR_XS_PCS_TP_B0                              : 0x%x\n", RegRead(0x040098));
    mcu_printf(" XPCS1.SR_XS_PCS_TP_B1                              : 0x%x\n", RegRead(0x04009C));
    mcu_printf(" XPCS1.SR_XS_PCS_TP_B2                              : 0x%x\n", RegRead(0x0400A0));
    mcu_printf(" XPCS1.SR_XS_PCS_TP_B3                              : 0x%x\n", RegRead(0x0400A4));
    mcu_printf(" XPCS1.SR_XS_PCS_TP_CTRL                            : 0x%x\n", RegRead(0x0400A8));
    mcu_printf(" XPCS1.SR_XS_PCS_TP_ERRCTR                          : 0x%x\n", RegRead(0x0400AC));
    mcu_printf(" XPCS1.SR_PCS_TIME_SYNC_PCS_ABL                     : 0x%x\n", RegRead(0x041C20));
    mcu_printf(" XPCS1.SR_PCS_TIME_SYNC_TX_MAX_DLY_LWR              : 0x%x\n", RegRead(0x041C24));
    mcu_printf(" XPCS1.SR_PCS_TIME_SYNC_TX_MAX_DLY_UPR              : 0x%x\n", RegRead(0x041C28));
    mcu_printf(" XPCS1.SR_PCS_TIME_SYNC_TX_MIN_DLY_LWR              : 0x%x\n", RegRead(0x041C2C));
    mcu_printf(" XPCS1.SR_PCS_TIME_SYNC_TX_MIN_DLY_UPR              : 0x%x\n", RegRead(0x041C30));
    mcu_printf(" XPCS1.SR_PCS_TIME_SYNC_RX_MAX_DLY_LWR              : 0x%x\n", RegRead(0x041C34));
    mcu_printf(" XPCS1.SR_PCS_TIME_SYNC_RX_MAX_DLY_UPR              : 0x%x\n", RegRead(0x041C38));
    mcu_printf(" XPCS1.SR_PCS_TIME_SYNC_RX_MIN_DLY_LWR              : 0x%x\n", RegRead(0x041C3C));
    mcu_printf(" XPCS1.SR_PCS_TIME_SYNC_RX_MIN_DLY_UPR              : 0x%x\n", RegRead(0x041C40));
    mcu_printf(" XPCS1.VR_XS_PCS_DIG_CTRL1                          : 0x%x\n", RegRead(0x060000));
    mcu_printf(" XPCS1.VR_XS_PCS_DIG_CTRL2                          : 0x%x\n", RegRead(0x060004));
    mcu_printf(" XPCS1.VR_XS_PCS_DIG_ERRCNT_SEL                     : 0x%x\n", RegRead(0x060008));
    mcu_printf(" XPCS1.VR_XS_PCS_XAUI_CTRL                          : 0x%x\n", RegRead(0x060010));
    mcu_printf(" XPCS1.VR_XS_PCS_DEBUG_CTRL                         : 0x%x\n", RegRead(0x060014));
    mcu_printf(" XPCS1.VR_XS_PCS_KR_CTRL                            : 0x%x\n", RegRead(0x06001C));
    mcu_printf(" XPCS1.VR_XS_PCS_DIG_STS                            : 0x%x\n", RegRead(0x060040));
    mcu_printf(" XPCS1.VR_XS_PCS_ICG_ERRCNT1                        : 0x%x\n", RegRead(0x060044));
    mcu_printf(" XPCS1.VR_XS_PCS_CDT_STS                            : 0x%x\n", RegRead(0x060060));
    mcu_printf(" XPCS1.VR_XS_PCS_MISC_STS                           : 0x%x\n", RegRead(0x060064));
    mcu_printf(" XPCS1.VR_XS_PCS_SFTY_UE_INTR0                      : 0x%x\n", RegRead(0x0603C0));
    mcu_printf(" XPCS1.VR_XS_PCS_SFTY_ERR_INJ                       : 0x%x\n", RegRead(0x0603C4));
    mcu_printf(" XPCS1.VR_XS_PCS_SFTY_CE_INTR                       : 0x%x\n", RegRead(0x0603C8));
    mcu_printf(" XPCS1.VR_XS_PCS_SFTY_DBG_CTRL                      : 0x%x\n", RegRead(0x0603CC));
    mcu_printf(" XPCS1.VR_XS_PCS_SFTY_DISABLE                       : 0x%x\n", RegRead(0x0603D0));
    mcu_printf(" XPCS1.VR_XS_PCS_SFTY_TMR_CTRL                      : 0x%x\n", RegRead(0x0603D4));
    mcu_printf(" XPCS1.VR_XS_PCS_SFTY_UE_INTR1                      : 0x%x\n", RegRead(0x0603E0));

    mcu_printf("==================================================================\n");
    mcu_printf(" XPCS1.VS_MMD1 Registers\n");
    mcu_printf("vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\n");
    mcu_printf(" XPCS1.SR_VSMMD_PMA_ID1                             : 0x%x\n", RegRead(0x080000));
    mcu_printf(" XPCS1.SR_VSMMD_PMA_ID2                             : 0x%x\n", RegRead(0x080004));
    mcu_printf(" XPCS1.SR_VSMMD_DEV_ID1                             : 0x%x\n", RegRead(0x080008));
    mcu_printf(" XPCS1.SR_VSMMD_DEV_ID2                             : 0x%x\n", RegRead(0x08000C));
    mcu_printf(" XPCS1.SR_VSMMD_PCS_ID1                             : 0x%x\n", RegRead(0x080010));
    mcu_printf(" XPCS1.SR_VSMMD_PCS_ID2                             : 0x%x\n", RegRead(0x080014));
    mcu_printf(" XPCS1.SR_VSMMD_AN_ID1                              : 0x%x\n", RegRead(0x080018));
    mcu_printf(" XPCS1.SR_VSMMD_AN_ID2                              : 0x%x\n", RegRead(0x08001C));
    mcu_printf(" XPCS1.SR_VSMMD_STS                                 : 0x%x\n", RegRead(0x080020));
    mcu_printf(" XPCS1.SR_VSMMD_CTRL                                : 0x%x\n", RegRead(0x080024));
    mcu_printf(" XPCS1.SR_VSMMD_PKGID1                              : 0x%x\n", RegRead(0x080038));
    mcu_printf(" XPCS1.SR_VSMMD_PKGID2                              : 0x%x\n", RegRead(0x08003C));

    mcu_printf("==================================================================\n");
    mcu_printf(" XPCS1.VS_MII_MMD Registers\n");
    mcu_printf("vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\n");
    mcu_printf(" XPCS1.SR_MII_CTRL                                  : 0x%x\n", RegRead(0x0C0000));
    mcu_printf(" XPCS1.SR_MII_STS                                   : 0x%x\n", RegRead(0x0C0004));
    mcu_printf(" XPCS1.SR_MII_DEV_ID1                               : 0x%x\n", RegRead(0x0C0008));
    mcu_printf(" XPCS1.SR_MII_DEV_ID2                               : 0x%x\n", RegRead(0x0C000C));
    mcu_printf(" XPCS1.SR_MII_AN_ADV                                : 0x%x\n", RegRead(0x0C0010));
    mcu_printf(" XPCS1.SR_MII_LP_BABL                               : 0x%x\n", RegRead(0x0C0014));
    mcu_printf(" XPCS1.SR_MII_AN_EXPN                               : 0x%x\n", RegRead(0x0C0018));
    mcu_printf(" XPCS1.SR_MII_EXT_STS                               : 0x%x\n", RegRead(0x0C003C));
    mcu_printf(" XPCS1.VR_MII_DIG_CTRL1                             : 0x%x\n", RegRead(0x0E0000));
    mcu_printf(" XPCS1.VR_MII_AN_CTRL                               : 0x%x\n", RegRead(0x0E0004));
    mcu_printf(" XPCS1.VR_MII_AN_INTR_STS                           : 0x%x\n", RegRead(0x0E0008));
    mcu_printf(" XPCS1.VR_MII_DIG_CTRL3                             : 0x%x\n", RegRead(0x0E0010));
    mcu_printf(" XPCS1.VR_MII_LINK_TIMER_CTRL                       : 0x%x\n", RegRead(0x0E0028));


    mcu_printf("==================================================================\n");
    mcu_printf(" ETC Registers\n");
    mcu_printf("vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\n");
    mcu_printf(" XPCS0.SR_PMA_KR_PMD_CTRL                           : 0x%x\n", RegRead(0xB00058));
    mcu_printf(" XPCS1.SR_PMA_KR_PMD_CTRL                           : 0x%x\n", RegRead(0x000058));

#endif
}

void check_Link_sts(void)
{
	unsigned long addr;
	unsigned int val;
	unsigned int i;

#if 0
	addr = &HwXPCS1_XS_PCS_MMD->uPCS_STS.nReg;
	uPCS1_PCS_MMD.uPCS_STS.nReg = RegRead(addr);
	val = uPCS1_PCS_MMD.uPCS_STS.nReg & 0x4;

	mcu_printf("2.5G PHY Link status [0x%x]\n", uPCS1_PCS_MMD.uPCS_STS.nReg);
#else

#if 0
	addr = &HwXPCS0_XS_PCS_MMD->uPCS_STS.nReg;
	uPCS0_PCS_MMD.uPCS_STS.nReg = RegRead(addr);
	val = uPCS0_PCS_MMD.uPCS_STS.nReg & 0x4;
#endif

	for(i=0;i<3;i++)
	{
		mcu_printf("XPCS0.SR_XS_PCS_STS1    : 0x%x\n", RegRead(0xB40004));
		mcu_printf("XPCS0.SR_XS_PCS_KR_STS2 : 0x%x\n\n", RegRead(0xB40084));
		SAL_TaskSleep(1000);	// 1 second
	}
#endif
}

void tpa_csr_dump(void)
{
	mcu_printf("==================================================================\n");
	mcu_printf(" TPA CSR Registers\n");
	mcu_printf("vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\n");
	mcu_printf(" TPA_CSR.CLK_MASK_CTRL		: 0x%x\n", RegRead(0xd30000));
	mcu_printf(" TPA_CSR.SW_RST_CTRL		: 0x%x\n", RegRead(0xd30004));
	mcu_printf(" TPA_CSR.GMAC0_CLK_CTRL0	: 0x%x\n", RegRead(0xd31000));
	mcu_printf(" TPA_CSR.GMAC0_CLK_CTRL1	: 0x%x\n", RegRead(0xd31004));
	mcu_printf(" TPA_CSR.GMAC0_IO_DLY_CTRL0 : 0x%x\n", RegRead(0xd32000));
	mcu_printf(" TPA_CSR.GMAC0_IO_DLY_CTRL1 : 0x%x\n", RegRead(0xd32004));
	mcu_printf(" TPA_CSR.GMAC0_IO_DLY_CTRL2 : 0x%x\n", RegRead(0xd32008));
	mcu_printf(" TPA_CSR.GMAC0_IO_DLY_CTRL3 : 0x%x\n", RegRead(0xd3200c));
	mcu_printf(" TPA_CSR.GMAC0_IO_DLY_CTRL4 : 0x%x\n", RegRead(0xd32010));
	mcu_printf(" TPA_CSR.GMAC1_CLK_CTRL0	: 0x%x\n", RegRead(0xd33000));
	mcu_printf(" TPA_CSR.GMAC1_CLK_CTRL1	: 0x%x\n", RegRead(0xd33004));
	mcu_printf(" TPA_CSR.GMAC1_IO_DLY_CTRL0 : 0x%x\n", RegRead(0xd34000));
	mcu_printf(" TPA_CSR.GMAC1_IO_DLY_CTRL1 : 0x%x\n", RegRead(0xd34004));
	mcu_printf(" TPA_CSR.GMAC1_IO_DLY_CTRL2 : 0x%x\n", RegRead(0xd34008));
	mcu_printf(" TPA_CSR.GMAC1_IO_DLY_CTRL3 : 0x%x\n", RegRead(0xd3400c));
	mcu_printf(" TPA_CSR.GMAC1_IO_DLY_CTRL4 : 0x%x\n", RegRead(0xd34010));
	mcu_printf(" TPA_CSR.XGMAC0_PCS0_STS	: 0x%x\n", RegRead(0xd37000));
	mcu_printf(" TPA_CSR.XPCS0_ADDR_REMAP0	: 0x%x\n", RegRead(0xd37004));
	mcu_printf(" TPA_CSR.XPCS0_ADDR_REMAP1	: 0x%x\n", RegRead(0xd37008));
	mcu_printf(" TPA_CSR.XGMAC1_PCS1_STS	: 0x%x\n", RegRead(0xd38000));
	mcu_printf(" TPA_CSR.XPCS1_ADDR_REMAP0	: 0x%x\n", RegRead(0xd38004));
	mcu_printf(" TPA_CSR.XPCS1_ADDR_REMAP1	: 0x%x\n", RegRead(0xd38008));
	mcu_printf(" TPA_CSR.SERDES_CSR0		: 0x%x\n", RegRead(0xd39000));
	mcu_printf(" TPA_CSR.SERDES_CSR1		: 0x%x\n", RegRead(0xd39004));
	mcu_printf(" TPA_CSR.SERDES_CSR2		: 0x%x\n", RegRead(0xd39008));
	mcu_printf(" TPA_CSR.TPA_CLK_DIV_CSR	: 0x%x\n", RegRead(0xd3900c));
	mcu_printf(" TPA_CSR.SERDES_PLL_CSR0	: 0x%x\n", RegRead(0xd3a000));
	mcu_printf(" TPA_CSR.SERDES_PLL_CSR1	: 0x%x\n", RegRead(0xd3a004));
	mcu_printf(" TPA_CSR.SERDES_PLL_CSR2	: 0x%x\n", RegRead(0xd3a008));
	mcu_printf(" TPA_CSR.SERDES_PLL_CSR3	: 0x%x\n", RegRead(0xd3a00c));
	mcu_printf(" TPA_CSR.SERDES_PLL_CSR4	: 0x%x\n", RegRead(0xd3a010));
	mcu_printf(" TPA_CSR.SERDES_PLL_CSR5	: 0x%x\n", RegRead(0xd3a014));
	mcu_printf(" TPA_CSR.REF_CLK_BUF_CSR0	: 0x%x\n", RegRead(0xd3a018));
	mcu_printf(" TPA_CSR.REF_CLK_BUF_CSR1	: 0x%x\n", RegRead(0xd3a01c));
}

#if 1
unsigned int phy_read(unsigned int phy_addr)
{
	unsigned int ser_addr;
	unsigned int val;

	// step 1
	do{
		ser_addr = &HwXPCS1_XS_PMA_MMD->uSNPS_CR_CTRL.nReg;
		val = RegRead(ser_addr);
//		mcu_printf("[%s] A01 :: 0x%x\n", __func__, val);
	}while((val & 0x1) != (0x0));

	// step 2
	RegWrite(&HwXPCS1_XS_PMA_MMD->uSNPS_CR_ADDR.nReg, phy_addr);

	// step 3
	ser_addr = &HwXPCS1_XS_PMA_MMD->uSNPS_CR_CTRL.nReg;
	uPCS1_PMA_MMD.uSNPS_CR_CTRL.nReg = RegRead(ser_addr);
	uPCS1_PMA_MMD.uSNPS_CR_CTRL.nReg = uPCS1_PMA_MMD.uSNPS_CR_CTRL.nReg & (~(0x1<<1));	// WR_RND masking
	uPCS1_PMA_MMD.uSNPS_CR_CTRL.nReg = uPCS1_PMA_MMD.uSNPS_CR_CTRL.nReg |	(  0<<1);	// WR_RND = 0 (read)
	RegWrite(&HwXPCS1_XS_PMA_MMD->uSNPS_CR_CTRL.nReg, uPCS1_PMA_MMD.uSNPS_CR_CTRL.nReg);

	// step 4
	ser_addr = &HwXPCS1_XS_PMA_MMD->uSNPS_CR_CTRL.nReg;
	uPCS1_PMA_MMD.uSNPS_CR_CTRL.nReg = RegRead(ser_addr);
	uPCS1_PMA_MMD.uSNPS_CR_CTRL.nReg = uPCS1_PMA_MMD.uSNPS_CR_CTRL.nReg & (~(0x1<<0));	// START_BUSY masking
	uPCS1_PMA_MMD.uSNPS_CR_CTRL.nReg = uPCS1_PMA_MMD.uSNPS_CR_CTRL.nReg |	(  1<<0);	// START_BUSY = 1 (busy)
	RegWrite(&HwXPCS1_XS_PMA_MMD->uSNPS_CR_CTRL.nReg, uPCS1_PMA_MMD.uSNPS_CR_CTRL.nReg);

	// step 5
	do{
		ser_addr = &HwXPCS1_XS_PMA_MMD->uSNPS_CR_CTRL.nReg;
		val = RegRead(ser_addr);
//		mcu_printf("[%s] A03 :: 0x%x\n", __func__, val);
	}while((val & 0x1) != (0x0));

	// step 6
	ser_addr = &HwXPCS1_XS_PMA_MMD->uSNPS_CR_DATA.nReg;
	val = RegRead(ser_addr);
//	mcu_printf("[%s] A04 :: 0x%x\n", __func__, val);

	return val;
}
#else
unsigned int phy_read(unsigned int phy_addr)
{
	unsigned long ser_addr;
	unsigned int val;

	// step 1
	do{
		ser_addr = &HwXPCS0_XS_PMA_MMD->uSNPS_CR_CTRL.nReg;
		val = RegRead(ser_addr);
		mcu_printf("[%s] A01 :: 0x%x\n", __func__, val);
	}while((val & 0x1) != (0x0));

	// step 2
	RegWrite(&HwXPCS0_XS_PMA_MMD->uSNPS_CR_ADDR.nReg, phy_addr);
	mcu_printf("[%s] A02 :: 0x%x\n", __func__, phy_addr);

	// step 3
	ser_addr = &HwXPCS0_XS_PMA_MMD->uSNPS_CR_CTRL.nReg;
	uPCS0_PMA_MMD.uSNPS_CR_CTRL.nReg = RegRead(ser_addr);
	uPCS0_PMA_MMD.uSNPS_CR_CTRL.nReg = uPCS0_PMA_MMD.uSNPS_CR_CTRL.nReg & (~(0x1<<1));	// WR_RND masking
	uPCS0_PMA_MMD.uSNPS_CR_CTRL.nReg = uPCS0_PMA_MMD.uSNPS_CR_CTRL.nReg |	(  0<<1);	// WR_RND = 0 (read)

	// step 4
	ser_addr = &HwXPCS0_XS_PMA_MMD->uSNPS_CR_CTRL.nReg;
	uPCS0_PMA_MMD.uSNPS_CR_CTRL.nReg = RegRead(ser_addr);
	uPCS0_PMA_MMD.uSNPS_CR_CTRL.nReg = uPCS0_PMA_MMD.uSNPS_CR_CTRL.nReg & (~(0x1<<0));	// START_BUSY masking
	uPCS0_PMA_MMD.uSNPS_CR_CTRL.nReg = uPCS0_PMA_MMD.uSNPS_CR_CTRL.nReg |	(  1<<0);	// START_BUSY = 1 (busy)

	// step 5
	do{
		ser_addr = &HwXPCS0_XS_PMA_MMD->uSNPS_CR_CTRL.nReg;
		val = RegRead(ser_addr);
		mcu_printf("[%s] A03 :: 0x%x\n", __func__, val);
	}while((val & 0x1) != (0x0));

	// step 6
	ser_addr = &HwXPCS0_XS_PMA_MMD->uSNPS_CR_DATA.nReg;
	val = RegRead(ser_addr);
	mcu_printf("[%s] A04 :: 0x%x\n", __func__, val);

	return val;
}
#endif

void phy_register_dump(void)
{
	unsigned int i;
	unsigned int data;

	mcu_printf("\nPHY register dump\n");

#if 0
	for(i=0;i<0x10;i++)
	{
		data = phy_read(i);
		mcu_printf("[%s] ADDR[0x%x] :: 0x%x\n", __func__, i, data);
	}
#else
	for(i=0;i<0x3c;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x40;i<0x4e;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x60;i<0x69;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x80;i<0x88;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0xa0;i<0xa4;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x1000;i<0x101c;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x1020;i<0x102e;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x1040;i<0x105c;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x1060;i<0x1095;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x10a0;i<0x10bc;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	i = 0x10bd;
	data = phy_read(i);
	mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);

	i = 0x10be;
	data = phy_read(i);
	mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);

	for(i=0x10c0;i<0x10da;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x1100;i<0x111c;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x1120;i<0x112e;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x1140;i<0x115c;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x1160;i<0x1195;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x11a0;i<0x11bc;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	i = 0x11bd;
	data = phy_read(i);
	mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);

	i = 0x11be;
	data = phy_read(i);
	mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);

	for(i=0x11c0;i<0x11da;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x2000;i<0x2019;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x2020;i<0x203f;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x2040;i<0x2044;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x3000;i<0x3024;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x3025;i<0x3092;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x30a0;i<0x30ab;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x30c0;i<0x30d5;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x30e0;i<0x3100;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x3100;i<0x3124;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x3125;i<0x3192;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x31a0;i<0x31ab;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x31c0;i<0x31d5;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	for(i=0x31e0;i<0x3200;i++)
	{
		data = phy_read(i);
		mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
	}

	i = 0x4000;
	data = phy_read(i);
	mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);

	i = 0x7fff;
	data = phy_read(i);
	mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);

	i = 0xc000;
	data = phy_read(i);
	mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);

	i = 0xffff;
	data = phy_read(i);
	mcu_printf("ADDR[0x%x] :: 0x%x\n", i, data);
#endif
}

