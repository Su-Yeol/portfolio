/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
 * @File
 * @Title        fp_ip.h
 * @Copyright    Copyright (c) 2007-2009, Naksha Technologies, Inc.
 * @Copyright    Copyright (c) 2010-2012, Posedge Technologies, Inc.
 * @Copyright    Copyright (c) 2013-2020, Imagination Technologies Ltd.
 * @Copyright    Copyright (c) Imagination Technologies Ltd. All Rights Reserved
 * @Description  This file contains the structures declaration for
 *           IP header and some function prototypes
 * @License      Dual MIT/GPLv2
 *
 * The contents of this file are subject to the MIT license as set out below.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * the GNU General Public License Version 2 ("GPL") in which case the provisions
 * of GPL are applicable instead of those above.
 *
 * If you wish to allow use of your version of this file only under the terms of
 * GPL, and not to allow others to use your version of this file under the terms
 * of the MIT license, indicate your decision by deleting the provisions above
 * and replace them with the notice and other provisions required by GPL as set
 * out in the file called "GPL-COPYING" included in this distribution. If you do
 * not delete the provisions above,a recipient may use your version of this file
 * under the terms of either the MIT license or GPL.
 *
 * This License is also included in this distribution in the file called
 * "MIT-COPYING".
 *
 * EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 * PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */ /**************************************************************************/
#ifndef _FP_IP_H_
#define _FP_IP_H_


/* Internet address */
struct in_addr_t {
	uint32a s_addr;
};

/*
 * Structure of an internet header, naked of options.
 *
 * Stolen from tcpdump source (thanks tcpdump people)
 *
 * We declare ip_len and ip_off to be short, rather than u_short
 * pragmatically since otherwise unsigned comparisons can result
 * against negative integers quite easily, and fail in subtle ways.
 */
struct my_ip {

	uint8	ip_vhl;      /* header length, version */
	uint8	ip_tos;      /* type of service */
	uint16	ip_len;      /* total length */
	uint16	ip_id;       /* identification */
	uint16	ip_off;      /* fragment offset field */
	uint8	ip_ttl;      /* time to live */
	uint8	ip_p;        /* protocol */
	uint16	ip_sum;      /* checksum */
	struct	in_addr_t ip_src, ip_dst;	/* source and dest address */
#define IP_V(ip)	(((ip)->ip_vhl & 0xf0) >> 4)
#define IP_HL(ip)	((ip)->ip_vhl & 0x0f)
#define	IP_DF 0x4000	   /* dont fragment flag */
#define	IP_MF 0x2000	   /* more fragments flag */
#define	IP_OFFMASK 0x1fff  /* mask for fragmenting bits */

};

/*
 * IPv6 address structure
 */
struct in6_addr_t {
	union {
		uint8	u6_addr8[16];
		uint16	u6_addr16[8];
		uint32a	u6_addr32[4];
	} in6_u;
#define s6_addr   in6_u.u6_addr8
#define s6_addr16 in6_u.u6_addr16
#define s6_addr32 in6_u.u6_addr32
};

/*
 *      IPv6  header
 */
struct fp_ipv6_hdr_t {

#ifndef _FP_NGW_
	/* Little endian */
	uint8		priority:4, version:4;
#else
	/* Big endian */
	uint8		version:4, priority:4;
#endif
	uint8		flow_label[3];
	uint16		payload_length;
	uint8		next_hdr;
	uint8		hop_limit;
	struct in6_addr_t	saddr;
	struct in6_addr_t	daddr;
};

/*IPV6 Routing Extension Header*/
struct fp_ipv6_exthdr_t {
	uint8	nexthdr;
	uint8	hdr_len;
	uint8	type;
	uint8	seg_left;
	uint32a	res;
};

struct ah_hdr_t {
	uint8	next_hdr;
	uint8	hlen;
	uint16	reserved;
	uint32a	spi;
	uint32a	seq;
	uint8	icv[0];
};

struct esp_hdr_t {
	uint32a	spi;
	uint32a	seq;
	uint8	data[0];
};

#define IS_EXT_HEADER(p) (((p) == EXT_HDR_FRAG) || ((p) == EXT_HDR_HOP) || \
		((p) == EXT_HDR_DEST) || ((p) == EXT_HDR_ROUTE) || \
		((p) == EXT_HDR_ESP) || ((p) == EXT_HDR_AH) || \
				((p) == EXT_HDR_MOBILITY))

#endif
