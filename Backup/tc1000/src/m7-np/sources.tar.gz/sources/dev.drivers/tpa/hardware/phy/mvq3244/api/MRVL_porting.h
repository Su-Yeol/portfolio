// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * Copyright (C) Telechips Inc.
 */

#ifndef MRVL_PORTING_H_
#define MRVL_PORTING_H_

#include "debug.h"
//#include <linux/kernel.h>

//#ifdef printk
//#undef printk
#define printk mcu_printf
///#endif

#if 1
	#define MRVL_PRINT_DEBUG(fmt, args...) printk("[MRVL] " fmt, ## args)
#else
	#define MRVL_PRINT_DEBUG(...)
#endif

#define MRVL_PRINT_ERROR(fmt, args...) printk("[MRVL] " fmt, ## args)

#if 0
#define FP_DEBUG(feat, level, msg, args...) if(feat & fp_dbgp_flags){ \
	int count = 0; \
	for (; count < 32; count++) { \
		if ((1 << count) & feat) { \
			break; \
		} \
	} \
	if (level <= fp_trace_level) \
	printk("%s: " msg,fp_dbgp_arr[count], ## args); \
};
#endif

extern void tpa_udelay_busy(uint32 usec);
#define udelay(x) tpa_udelay_busy(x);

#endif //ifdef MRVL_PORTING_H_
