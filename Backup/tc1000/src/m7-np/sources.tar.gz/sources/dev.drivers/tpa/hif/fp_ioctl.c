// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_ioctl.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    ioctl API's for wsp module
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                     Include Files
 **********************************************************************/
#include <linux/inetdevice.h>

#include "fp_global_addr_map.h"
#include "global_address_map_fpga.h"
#include "reg_hal.h"
#include "fp_library.h"
#include "fp_types.h"
#include "fp_ioctl.h"
#include "fp_stats.h"
#include "fp_net_driver.h"
#include "fp_netd.h"
#include "bmu1_csr.h"
#include "gpi_csr.h"
#include "hif_npu_csr.h"

#ifndef IPPROTO_TCP
#define IPPROTO_TCP 6
#endif

#ifndef IPPROTO_UDP
#define IPPROTO_UDP 17
#endif

struct net_device *fp_pci_dev = NULL;

int32a fp_switch_ioctl_entries_ops(	struct net_device *dev,
					struct ifreq *rq, int32a cmd);

int32a ioctl_get_stats(struct net_device *dev, struct ifreq *rq, int32a cmd)
{
	//nc_ioctl_ops_t *pnc_ops = (nc_ioctl_ops_t *) rq->ifr_ifru.ifru_data;

	nc_ioctl_ops_t pnc_ops;
	uint8 *buff;
	uint32a i;
	uint8 *pci;
	int32a ret;
	fp_stats_t *stats;

	struct fp_private *fp = netdev_priv((struct net_device *)dev);
	//pnc_ops = (nc_ioctl_ops_t *) rq->ifr_ifru.ifru_data;
	buff = kmalloc(sizeof(fp_stats), __GFP_DMA|GFP_ATOMIC);
	memset(buff, 0, sizeof(fp_stats));
	if (buff == NULL) {
		FP_DEBUG(DBGP_FEAT_IOCTL, FP_LOG_INFO,
			"ioctl_entries_ops: buff is null\n");
		return -1;
	}
	ret = copy_from_user(	&pnc_ops,
				(nc_ioctl_ops_t *)rq->ifr_ifru.ifru_data,
				sizeof(nc_ioctl_ops_t));
	if (ret)
		return -1;
	/* changed according to integration code */
	//fp_read_hw_data(buff, (BASE_ADDR + PE_FP_STATS_ADDR), sizeof(fp_stats));
#ifdef HW_STATS_EN
	stats = (fp_stats_t *)buff;
	pci = getPciBaseAddr(fp_pci_dev);

	/* EPP_SW_BRINGUP temp : replace code for Telechips */
	stats->rx_pkt_cnt = *(uint32a *)(pci + EGPI1_CLASS_HW_PHY1_RX_PKTS_ADDR) +
	                    *(uint32a *)(pci + EGPI2_CLASS_HW_PHY1_RX_PKTS_ADDR) +
	                    *(uint32a *)(pci + EGPI3_CLASS_HW_PHY1_RX_PKTS_ADDR);
	stats->tx_pkt_cnt = *(uint32a *)(pci + EGPI1_CLASS_HW_PHY1_TX_PKTS_ADDR) +
	                    *(uint32a *)(pci + EGPI2_CLASS_HW_PHY1_TX_PKTS_ADDR) +
	                    *(uint32a *)(pci + EGPI3_CLASS_HW_PHY1_TX_PKTS_ADDR);
	stats->intf_mismatch_cnt = *(uint32a *)(pci + EGPI1_CLASS_HW_PHY1_INTF_FAIL_PKTS_ADDR) +
	                           *(uint32a *)(pci + EGPI2_CLASS_HW_PHY1_INTF_FAIL_PKTS_ADDR) +
	                           *(uint32a *)(pci + EGPI3_CLASS_HW_PHY1_INTF_FAIL_PKTS_ADDR);
	stats->intf_match_cnt = *(uint32a *)(pci + EGPI1_CLASS_HW_PHY1_INTF_MATCH_PKTS_ADDR) +
	                        *(uint32a *)(pci + EGPI2_CLASS_HW_PHY1_INTF_MATCH_PKTS_ADDR) +
	                        *(uint32a *)(pci + EGPI3_CLASS_HW_PHY1_INTF_MATCH_PKTS_ADDR);
	stats->ip_chksum_err_cnt = *(uint32a *)(pci + EGPI1_CLASS_HW_PHY1_CHKSUM_ERR_PKTS_ADDR) +
	                           *(uint32a *)(pci + EGPI2_CLASS_HW_PHY1_CHKSUM_ERR_PKTS_ADDR) +
	                           *(uint32a *)(pci + EGPI3_CLASS_HW_PHY1_CHKSUM_ERR_PKTS_ADDR);
	stats->ip4_pkt_cnt = *(uint32a *)(pci + EGPI1_CLASS_HW_PHY1_V4_PKTS_ADDR) +
	                     *(uint32a *)(pci + EGPI2_CLASS_HW_PHY1_V4_PKTS_ADDR) +
	                     *(uint32a *)(pci + EGPI3_CLASS_HW_PHY1_V4_PKTS_ADDR);
	stats->ip6_pkt_cnt = *(uint32a *)(pci + EGPI1_CLASS_HW_PHY1_V6_PKTS_ADDR) +
	                     *(uint32a *)(pci + EGPI2_CLASS_HW_PHY1_V6_PKTS_ADDR) +
	                     *(uint32a *)(pci + EGPI3_CLASS_HW_PHY1_V6_PKTS_ADDR);
	stats->ip_hdr_len_err_cnt = *(uint32a *)(pci + EGPI1_CLASS_HW_PHY1_L3_FAIL_PKTS_ADDR) +
	                            *(uint32a *)(pci + EGPI2_CLASS_HW_PHY1_L3_FAIL_PKTS_ADDR) +
	                            *(uint32a *)(pci + EGPI3_CLASS_HW_PHY1_L3_FAIL_PKTS_ADDR);
	stats->udp_pkt_cnt = *(uint32a *)(pci + EGPI1_CLASS_HW_PHY1_UDP_PKTS_ADDR) +
	                     *(uint32a *)(pci + EGPI2_CLASS_HW_PHY1_UDP_PKTS_ADDR) +
	                     *(uint32a *)(pci + EGPI3_CLASS_HW_PHY1_UDP_PKTS_ADDR);
	stats->tcp_pkt_cnt = *(uint32a *)(pci + EGPI1_CLASS_HW_PHY1_TCP_PKTS_ADDR) +
	                     *(uint32a *)(pci + EGPI2_CLASS_HW_PHY1_TCP_PKTS_ADDR) +
	                     *(uint32a *)(pci + EGPI3_CLASS_HW_PHY1_TCP_PKTS_ADDR);
	stats->icmp_pkt_cnt = *(uint32a *)(pci + EGPI1_CLASS_HW_PHY1_ICMP_PKTS_ADDR) +
	                      *(uint32a *)(pci + EGPI2_CLASS_HW_PHY1_ICMP_PKTS_ADDR) +
	                      *(uint32a *)(pci + EGPI3_CLASS_HW_PHY1_ICMP_PKTS_ADDR);
	stats->igmp_pkt_cnt = *(uint32a *)(pci + EGPI1_CLASS_HW_PHY1_IGMP_PKTS_ADDR) +
	                      *(uint32a *)(pci + EGPI2_CLASS_HW_PHY1_IGMP_PKTS_ADDR) +
	                      *(uint32a *)(pci + EGPI3_CLASS_HW_PHY1_IGMP_PKTS_ADDR);
	for (i = 0; i < FP_MAX_PORTS; i++) {
		if ((EMAC_PORT_LIST_MASK >> i) & 0x1) {
			stats->ingqos_info[i].ingq_class_drop_cnt =  *(uint32a *)(pci +
				     (egpi_base_addr[i] + GPI_CSR_CSR_IGQOS_STAT_CLASS_DROP_CNT));
			stats->ingqos_info[i].ingq_lmemq_drop_cnt =  *(uint32a *)(pci +
				     (egpi_base_addr[i] + GPI_CSR_CSR_IGQOS_STAT_LMEM_QUEUE_DROP_CNT));
			stats->ingqos_info[i].ingq_dmemq_drop_cnt =  *(uint32a *)(pci +
				     (egpi_base_addr[i] + GPI_CSR_CSR_IGQOS_STAT_DMEM_QUEUE_DROP_CNT));
			stats->ingqos_info[i].ingq_rxfq_drop_cnt =   *(uint32a *)(pci +
				     (egpi_base_addr[i] + GPI_CSR_CSR_IGQOS_STAT_RXF_QUEUE_DROP_CNT));
			stats->ingqos_info[i].ingq_shp0_drop_cnt =   *(uint32a *)(pci +
				     (egpi_base_addr[i] + GPI_CSR_CSR_IGQOS_STAT_SHAPER0_DROP_CNT));
			stats->ingqos_info[i].ingq_shp1_drop_cnt =   *(uint32a *)(pci +
				     (egpi_base_addr[i] + GPI_CSR_CSR_IGQOS_STAT_SHAPER1_DROP_CNT));
			stats->ingqos_info[i].ingq_managed_cnt =     *(uint32a *)(pci +
				     (egpi_base_addr[i] + GPI_CSR_CSR_IGQOS_STAT_MANAGED_PACKET_CNT));
			stats->ingqos_info[i].ingq_unmanaged_cnt =   *(uint32a *)(pci +
				     (egpi_base_addr[i] + GPI_CSR_CSR_IGQOS_STAT_UNMANAGED_PACKET_CNT));
			stats->ingqos_info[i].ingq_reserved_cnt =    *(uint32a *)(pci +
				     (egpi_base_addr[i] + GPI_CSR_CSR_IGQOS_STAT_RESERVED_PACKET_CNT));
			stats->ingqos_info[i].ingq_total_drop_cnt =  *(uint32a *)(pci +
				     (egpi_base_addr[i] + GPI_CSR_CSR_IGQOS_STAT_TOTAL_DROP_CNT));
			stats->ingqos_info[i].ingq_csrshp_drop_cnt = *(uint32a *)(pci +
					(egpi_base_addr[i] + GPI_CSR_CSR_IGQOS_CSR_SHP_DROPCNT));
		}
	}
#endif /* HW_STATS_EN */

	stats->num_hif_rx_interrupts = fp->num_hif_rx_interrupts;
	stats->num_hif_tx_interrupts = fp->num_hif_tx_interrupts;

	stats->safety_reset_with_failstop = fp->safety_reset_with_failstop;
	stats->safety_reset_without_failstop = fp->safety_reset_without_failstop;
	/* stats->dst_be_found = stats->rx_pkt_cnt - fp_host_pkt_cnt;
	 * stats->dst_be_not_found = fp_host_pkt_cnt;
	 */
	//stats->tx_pkt_cnt = stats->tx_pkt_cnt - stats->pe_host_pkt_cnt;
	if (copy_to_user(pnc_ops.io_data, buff, sizeof(fp_stats)))
		return -EFAULT;
	kfree(buff);
	return 0;
}

int32a ioctl_get_debug_stats(struct net_device *dev, struct ifreq *rq, int32a cmd)
{
	//nc_ioctl_ops_t *pnc_ops = (nc_ioctl_ops_t *) rq->ifr_ifru.ifru_data;
	int32a ret;
	uint32a i;
	uint8 *buff;
	fp_debugstats_t *stats;
	//pnc_ops = (nc_ioctl_ops_t *) rq->ifr_ifru.ifru_data;
	nc_ioctl_ops_t pnc_ops;
	ret = copy_from_user(	&pnc_ops,
				(nc_ioctl_ops_t *)rq->ifr_ifru.ifru_data,
				sizeof(nc_ioctl_ops_t));
	if (ret)
		return -1;
	buff = kmalloc(sizeof(fp_debugstats_t), __GFP_DMA|GFP_ATOMIC);
	memset(buff, 0, sizeof(fp_debugstats_t));
	stats = (fp_debugstats_t *)buff;
#if 0 //TODO_TOOLKIT
	stats->emac_tx_counters0 = RegRead((EMAC0_BASE_ADDR + 0x108)); //TODO_TOOLKIT
	stats->emac_tx_counters1 = RegRead((EMAC1_BASE_ADDR + 0x108)); //TODO_TOOLKIT
	stats->emac_rx_counters0 = RegRead((EMAC0_BASE_ADDR + 0x158)); //TODO_TOOLKIT
	stats->emac_rx_counters1 = RegRead((EMAC1_BASE_ADDR + 0x158)); //TODO_TOOLKIT
	for (i = 0; i < 13; i++) {
		stats->emac_errors0[i] = RegRead((EMAC0_BASE_ADDR + 0x184 + (i * 4)));
		stats->emac_errors1[i] = RegRead((EMAC1_BASE_ADDR + 0x184 + (i * 4)));
	}
	stats->gpi_fifo_count0 = RegRead(EGPI0_BASE_ADDR + GPI_CSR_GPI_FIFO_DEBUG);
	stats->gpi_fifo_count1 = RegRead(EGPI1_BASE_ADDR + GPI_CSR_GPI_FIFO_DEBUG);
	stats->gpi_fifo_count2 = RegRead(HGPI_BASE_ADDR  + GPI_CSR_GPI_FIFO_DEBUG); //TODO_TOOLKIT
	stats->gpi_fifo_count3 = 0;
	stats->gpi_drop_count0 = RegRead(EGPI0_BASE_ADDR + GPI_CSR_GPI_CSR_OVERRUN_DROPCNT);
	stats->gpi_drop_count1 = RegRead(EGPI1_BASE_ADDR + GPI_CSR_GPI_CSR_OVERRUN_DROPCNT);
#endif
	for (i = 0; i < 10; i++) {
		//stats->class_phy1_count[i] = RegRead((CLASS_BASE_ADDR + 0x11C + (i * 4)));
		//stats->class_phy2_count[i] = RegRead((CLASS_BASE_ADDR + 0x144 + (i * 4)));
	}
	stats->bmu_buffer_count = RegRead((BMU1_BASE_ADDR + BMU1_CSR_BMU_BUF_CNT));
	stats->bmu_rem_count = RegRead((BMU1_BASE_ADDR + BMU1_CSR_BMU_REM_BUF_CNT));
	stats->bmu_cur_count = RegRead((BMU1_BASE_ADDR + BMU1_CSR_BMU_CURR_BUF_CNT));
	for (i = 0; i < 9; i++)
		stats->bmu_master_based_buffer_counts[i] =
			RegRead(BMU1_BASE_ADDR + BMU1_CSR_BMU_MAS0_BUF_CNT + (i * 4));
	stats->hif1_tx_counters0 = RegRead(HIF1_BASE_ADDR + HIF_NPU_CSR_HIF_TX_PKT_CNT1);
	stats->hif1_tx_counters1 = RegRead(HIF1_BASE_ADDR + HIF_NPU_CSR_HIF_TX_PKT_CNT2);
	stats->hif1_rx_counters0 = RegRead(HIF1_BASE_ADDR + HIF_NPU_CSR_HIF_RX_PKT_CNT1);
	stats->hif1_rx_counters1 = RegRead(HIF1_BASE_ADDR + HIF_NPU_CSR_HIF_RX_PKT_CNT2);
	stats->hif2_tx_counters0 = 0;
	stats->hif2_tx_counters1 = 0;
	stats->hif2_rx_counters0 = 0;
	stats->hif2_rx_counters1 = 0;
	stats->hgpi1_state0 = RegRead((HGPI_BASE_ADDR + GPI_CSR_GPI_RX_DBUG_REG1));
	stats->hgpi1_state1 = RegRead((HGPI_BASE_ADDR + GPI_CSR_GPI_RX_DBUG_REG2));
	stats->hgpi2_state0 = 0;
	stats->hgpi2_state1 = 0;
#if 0 //TODO_TOOLKIT
	stats->egpi1_state0 = RegRead((EGPI0_BASE_ADDR + GPI_CSR_GPI_RX_DBUG_REG1));
	stats->egpi1_state1 = RegRead((EGPI0_BASE_ADDR + GPI_CSR_GPI_RX_DBUG_REG2));
	stats->egpi2_state0 = RegRead((EGPI1_BASE_ADDR + GPI_CSR_GPI_RX_DBUG_REG1));
	stats->egpi2_state1 = RegRead((EGPI1_BASE_ADDR + GPI_CSR_GPI_RX_DBUG_REG2));
#endif
	if (buff == NULL) {
		FP_DEBUG(DBGP_FEAT_IOCTL, FP_LOG_INFO,
			"ioctl_entries_ops: buff is null\n");
		return -1;
	}
/* changed according to integration code */
	if (copy_to_user(pnc_ops.io_data, buff, sizeof(fp_debugstats_t)))
		return -EFAULT;
	kfree(buff);
	return 0;
}

/*
 * Function fp_config_ioctl
 */
int32a fp_config_ioctl(struct net_device *dev, struct ifreq  *rq,  int32a  cmd)
{
	FPATH_TRACE(FP_TRACE_CONFIG, FP_LOG_DEBUG,
		("(%s) Received IOCTL CMD = %d\n ", __func__, cmd));
	/* Global dev initialization */
	fp_pci_dev = dev;
	/* FP_DEBUG(DBGP_FEAT_ERR, FP_LOG_INFO, "IOCTL: dev pointr %x\n",
						(uint32a)fp_pci_dev); */
	switch (cmd) {
	case NC_STATS_GET:
#ifdef MACSEC_EN
//# warning MACSEC_EN not compatible with NC_STATS_GET
		return -EPERM;
#else
		return ioctl_get_stats(dev, rq, cmd);
#endif
	break;

	case NC_DEBUGSTATS_GET:
		return ioctl_get_debug_stats(dev, rq, cmd);
	break;

	case NC_DEBUGPRINTS_ENABLE:
		fp_dbgp_flags = 0x1FFF;
		fp_trace_level = 7;
	break;

	case NC_DEBUGPRINTS_DISABLE:
		fp_dbgp_flags = 0x1;
		fp_trace_level = 1;
	break;

	case NC_SWITCH_ENTRIES_GET:
		return fp_switch_ioctl_entries_ops(dev, rq, cmd);
	break;

	case NC_SET_FASTPATH:
		//ioctl_set_fastpath(dev, rq, cmd);
	break;

	default:
		FP_DEBUG(DBGP_FEAT_ERR, FP_LOG_INFO,
				"Received unknown ioctl option :%d\n", cmd);
	break;
	}
	return 0;
}

