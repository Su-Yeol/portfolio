// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_switch_init.c
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    Initializes port, global & hwmac table parameters
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

/**********************************************************************
 *                                      Include Files
 **********************************************************************/
#include "reg_hal.h"
#include "fp_library.h"		// brings in linux/string.h
#include "fp_macros.h"
#include "fp_switch.h"
#include "hw_vlan_hash_table.h"
#include "fp_global_addr_map.h"
#include "global_address_map_fpga.h"
#include "fp_net_driver.h"

/**********************************************************************
 *                                      #defines
 **********************************************************************/


/**********************************************************************
 *                              Global Declarations
***********************************************************************/
struct port_s fp_port[FP_MAX_SWITCH_PORTS];
struct global_s fp_global;
struct rc_stats_s fp_rc_stats;
/**********************************************************************
 *                              Extern Declarations
***********************************************************************/

uint32a egpi_base_addr[FP_MAX_PORTS] = {
	EGPI1_BASE_ADDR, EGPI2_BASE_ADDR, EGPI3_BASE_ADDR, EGPI4_BASE_ADDR,
	EGPI5_BASE_ADDR, EGPI6_BASE_ADDR, EGPI7_BASE_ADDR,
	EGPI8_BASE_ADDR, EGPI9_BASE_ADDR, EGPI10_BASE_ADDR,
	HGPI_BASE_ADDR
	};

/******************************************************************n
 * Function Name  : fp_hw_sw_init
 * Description    : initializes switch hw & mac table elements
 * Inputs         :
 * Parameters     :
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_hw_sw_init(void)
{
	uint32a i;
	uint32a val1 = 0;
	uint32a val2 = 0;
	uint64 gBrEntry = 0;
	uint32a offset;

	/* init port data structure */
	for(i = 0; i < FP_MAX_SWITCH_PORTS; i++)
	{
		if((FWD_PORT_LIST_MASK >> i) & 0x1)
		{
			fp_port[i].shutdown = 0;
			fp_port[i].tpid     = VLAN_TAGGED_FRAME;
			fp_port[i].aft      = ANY_TAGGING;
			fp_port[i].fallback_bd_id = DEF_PORT_FALLBACK_BD_ID;
			fp_port[i].block_state = FORWARDING;
			fp_port[i].csr_untag_from_btable = 0;
			//fp_get_port_addr(i, &addr1, &addr2);
			val1 = 	(((fp_port[i].fallback_bd_id <<	PORT_FALLBACK_BDID_START_POS) &	PORT_FALLBACK_BDID_MASK) |
					((fp_port[i].tpid << PORT_TPID_START_POS) & PORT_TPID_MASK));
			val2 =  (((fp_port[i].csr_untag_from_btable << PORT_UNTAG_FROM_BTABLE_START_POS) & PORT_UNTAG_FROM_BTABLE_MASK) |
					((fp_port[i].block_state << PORT_BLOCKSTATE_START_POS) & PORT_BLOCKSTATE_MASK) |
					((fp_port[i].aft << PORT_AFT_START_POS) & PORT_AFT_MASK) |
					((fp_port[i].shutdown << PORT_SHUTDOWN_START_POS) & PORT_SHUTDOWN_MASK));
			/* class hw port csr reg:
			*======================================================*
			*res |block_state |aft |shutdown |fallback_bd_id |tpid *
			*======================================================*
			*20-bit| 4-bit   |4-bit| 1-bit   | 16-bit      |16-bit *
			*=====================================================*/
#if 0
			if (addr1 && addr2) {
				CSR_REG_WRITE(fp_baseAddr, (uint32)addr1,
					((fp_port[i].fallback_bd_id <<
					PORT_FALLBACK_BDID_START_POS) &
					PORT_FALLBACK_BDID_MASK) |
					((fp_port[i].tpid <<
					PORT_TPID_START_POS) &
					PORT_TPID_MASK));

				CSR_REG_WRITE(fp_baseAddr, (uint32)addr2,
					((fp_port[i].csr_untag_from_btable <<
					PORT_UNTAG_FROM_BTABLE_START_POS) &
					PORT_UNTAG_FROM_BTABLE_MASK) |
					((fp_port[i].block_state <<
					PORT_BLOCKSTATE_START_POS) &
					PORT_BLOCKSTATE_MASK) |
					((fp_port[i].aft <<
					PORT_AFT_START_POS) &
					PORT_AFT_MASK) |
					((fp_port[i].shutdown <<
					PORT_SHUTDOWN_START_POS) &
					PORT_SHUTDOWN_MASK));
			}
#endif
		}
	}

#if 1
	for(i=0; i<FP_MAX_PORTS; i++)
	{
		offset = ((egpi_base_addr[i] + INGRESS_CLASSIFIER_BASE_ADDR));
#if 0
		if((i>= 3) && (i<=6))
			continue;
		if((i>= 7) && (i<=9))
			continue;
#endif
		if ((FWD_PORT_LIST_MASK >> i) & 0x1)
		{
			RegWrite((offset + 0x46c), val1);
			RegWrite((offset + 0x470), val2);
			RegWrite((offset + 0x474), val1);
			RegWrite((offset + 0x478), val2);
			RegWrite((offset + 0x47c), val1);
			RegWrite((offset + 0x480), val2);
			RegWrite((offset + 0x484), val1);
			RegWrite((offset + 0x488), val2);
			RegWrite((offset + 0x48c), val1);
			RegWrite((offset + 0x490), val2);
			RegWrite((offset + 0x494), val1);
			RegWrite((offset + 0x498), val2);
			RegWrite((offset + 0x49c), val1);
			RegWrite((offset + 0x4a0), val2);
			RegWrite((offset + 0x558), val1);
			RegWrite((offset + 0x55c), val2);
		}
	}
#endif

#if 0
	/* init fp_global fallback bd entry  */
	fp_global.fallback_bd_entry.ucast_hit_action = ACT_FORWARD;
	fp_global.fallback_bd_entry.ucast_miss_action = ACT_FLOOD;
	fp_global.fallback_bd_entry.mcast_hit_action = ACT_FORWARD;
	fp_global.fallback_bd_entry.mcast_miss_action = ACT_FLOOD;
	fp_global.fallback_bd_entry.forward_list = GLOBAL_BR_ENTRY_PORTLIST;
	fp_global.fallback_bd_entry.untag_list = GLOBAL_BR_ENTRY_UNTAGLIST;
	fp_global.fallback_bd_entry.mstp_id = ACT_FORWARD;
	fp_global.l2_special_punt_enable = 1;
#else
	SAL_MemSet(&fp_global.fallback_bd_entry, 0, sizeof(fp_global.fallback_bd_entry));
	fp_global.l2_special_punt_enable = 1;
#endif

/* GLOBAL ENTRY:
*========================================================================*
* fallback_bd_entry                            |  l2_special_punt_enable *
*========================================================================*
* 31-bit                                       |  1-bit                  *
*========================================================================*/
	gBrEntry = ((((uint64)fp_global.fallback_bd_entry.ucast_hit_action << BRENTRY_UCAST_HIT_ACT_START_POS) & BRENTRY_UCAST_HIT_ACT_MASK) |
		(((uint64)fp_global.fallback_bd_entry.ucast_miss_action << BRENTRY_UCAST_MISS_ACT_START_POS) & BRENTRY_UCAST_MISS_ACT_MASK) |
		(((uint64)fp_global.fallback_bd_entry.mcast_hit_action << BRENTRY_MCAST_HIT_ACT_START_POS) & BRENTRY_MCAST_HIT_ACT_MASK) |
		(((uint64)fp_global.fallback_bd_entry.mcast_miss_action << BRENTRY_MCAST_MISS_ACT_START_POS) & BRENTRY_MCAST_MISS_ACT_MASK)  |
		(((uint64)fp_global.fallback_bd_entry.untag_list << 	BRENTRY_UNTAG_LIST_START_POS) & BRENTRY_UNTAG_LIST_MASK) |
		((fp_global.fallback_bd_entry.forward_list) & BRENTRY_FWD_PORT_LIST_MASK));

	gBrEntry = ((gBrEntry << 1) | (fp_global.l2_special_punt_enable & 0x1));
	/*  RegWrite(CLASS_HW_GLOBAL_CFG, ((gBrEntry << 1) | GLOBAL_L2_SPL_PUNT_ACT)); */
	/* CSR_REG_WRITE(fp_baseAddr, (uint32)CLASS_HW_GLOBAL_CFG, gBrEntry); */
#if 0
	gBrEntry1 = gBrEntry & 0xFFFFFFFF;
	gBrEntry2 = (gBrEntry >> 32) & 0xFFFFFFFF;
	CSR_REG_WRITE(fp_baseAddr, (0x170000 + INGRESS_CLASSIFIER_BASE_ADDR +  0x4ac), gBrEntry1);
	CSR_REG_WRITE(fp_baseAddr, (0x174000 + INGRESS_CLASSIFIER_BASE_ADDR +  0x4ac), gBrEntry1);
	CSR_REG_WRITE(fp_baseAddr, (0x178000 + INGRESS_CLASSIFIER_BASE_ADDR +  0x4ac), gBrEntry1);
	CSR_REG_WRITE(fp_baseAddr, (0x17c000 + INGRESS_CLASSIFIER_BASE_ADDR +  0x4ac), gBrEntry1);
	CSR_REG_WRITE(fp_baseAddr, (0x330000 + INGRESS_CLASSIFIER_BASE_ADDR +  0x4ac), gBrEntry1);
	CSR_REG_WRITE(fp_baseAddr, (0x170000 + INGRESS_CLASSIFIER_BASE_ADDR +  0x7e8), gBrEntry2);
	CSR_REG_WRITE(fp_baseAddr, (0x174000 + INGRESS_CLASSIFIER_BASE_ADDR +  0x7e8), gBrEntry2);
	CSR_REG_WRITE(fp_baseAddr, (0x178000 + INGRESS_CLASSIFIER_BASE_ADDR +  0x7e8), gBrEntry2);
	CSR_REG_WRITE(fp_baseAddr, (0x17c000 + INGRESS_CLASSIFIER_BASE_ADDR +  0x7e8), gBrEntry2);
	CSR_REG_WRITE(fp_baseAddr, (0x330000 + INGRESS_CLASSIFIER_BASE_ADDR +  0x7e8), gBrEntry2);
#endif
	//CSR_REG_WRITE(fp_baseAddr, (uint32)CLASS_HW_BCAST_PORTMAP, FWD_PORT_LIST_MASK);

	for(i=0; i<FP_MAX_PORTS; i++)
	{
		if((EMAC_PORT_LIST_MASK >> i) & 0x1)
		{
			offset = (egpi_base_addr[i] + INGRESS_CLASSIFIER_BASE_ADDR);
			RegWrite((offset +  0x38c), FWD_PORT_LIST_MASK);
		}
	}

#if 1
	for(i=0; i<FP_MAX_PORTS; i++)
	{
		if((EMAC_PORT_LIST_MASK >> i) & 0x1)
		{
			offset = (egpi_base_addr[i] + INGRESS_CLASSIFIER_BASE_ADDR);
			RegWrite((offset +  0x90),  STP_CTRL_REG_VAL);
			RegWrite((offset +  0x368), STP_MAC_ADDR1_LSB);
			RegWrite((offset +  0x36c), STP_MAC_ADDR1_MSB);
			RegWrite((offset +  0x370), STP_MAC_ADDR2_LSB);
			RegWrite((offset +  0x374), STP_MAC_ADDR1_MSB);
			RegWrite((offset +  0x378), STP_MAC_MASK1_LSB);
			RegWrite((offset +  0x37c), STP_MAC_MASK1_MSB);
			RegWrite((offset +  0x380), STP_MAC_MASK2_LSB);
			RegWrite((offset +  0x384), STP_MAC_MASK2_MSB);
		}
	}

	offset = (HGPI_BASE_ADDR + INGRESS_CLASSIFIER_BASE_ADDR);
	RegWrite((offset +  0x90),  STP_CTRL_REG_VAL);
	RegWrite((offset +  0x368), STP_MAC_ADDR1_LSB);
	RegWrite((offset +  0x36c), STP_MAC_ADDR1_MSB);
	RegWrite((offset +  0x370), STP_MAC_ADDR2_LSB);
	RegWrite((offset +  0x374), STP_MAC_ADDR1_MSB);
	RegWrite((offset +  0x378), STP_MAC_MASK1_LSB);
	RegWrite((offset +  0x37c), STP_MAC_MASK1_MSB);
	RegWrite((offset +  0x380), STP_MAC_MASK2_LSB);
	RegWrite((offset +  0x384), STP_MAC_MASK2_MSB);

	for(i=0; i<FP_MAX_PORTS; i++)
	{
		if((EMAC_PORT_LIST_MASK >> i) & 0x1)
		{
			RegWrite((egpi_base_addr[i] + INGRESS_CLASSIFIER_BASE_ADDR +  0x4ac), 1);
		}
	}
#endif
//TODO
#if 0
	/* Configure STP MAC details */
	RegWrite(CLASS_SNOOP_CTRL, STP_CTRL_REG_VAL);
	RegWrite(CLASS_SNOOP_SPL_MCAST_ADDR1_LSB, STP_MAC_ADDR1_LSB);
	RegWrite(CLASS_SNOOP_SPL_MCAST_ADDR1_MSB, STP_MAC_ADDR1_MSB);
	RegWrite(CLASS_SNOOP_SPL_MCAST_ADDR2_LSB, STP_MAC_ADDR2_LSB);
	RegWrite(CLASS_SNOOP_SPL_MCAST_ADDR2_MSB, STP_MAC_ADDR1_MSB);
	RegWrite(CLASS_SNOOP_SPL_MCAST_MASK1_LSB, STP_MAC_MASK1_LSB);
	RegWrite(CLASS_SNOOP_SPL_MCAST_MASK1_MSB, STP_MAC_MASK1_MSB);
	RegWrite(CLASS_SNOOP_SPL_MCAST_MASK2_LSB, STP_MAC_MASK2_LSB);
	RegWrite(CLASS_SNOOP_SPL_MCAST_MASK2_MSB, STP_MAC_MASK2_MSB);
#endif
	/* reset rc codes stats for cli */
	fp_rc_stats.hw_hash_entry_count = 0;
	fp_rc_stats.l2_spl_cnt = 0;
	fp_rc_stats.sa_miss_cnt = 0;
	fp_rc_stats.sa_relearn_cnt = 0;
	fp_rc_stats.sa_is_active_cnt = 0;
	fp_rc_stats.snoop_upper_cnt = 0;
	fp_rc_stats.requested_cnt = 0;
	fp_rc_stats.mgmt_cnt = 0;
	fp_rc_stats.igmp_cnt = 0;
	fp_rc_stats.flood_cnt = 0;
	fp_rc_stats.parse_cnt = 0;
	fp_rc_stats.fwd_cnt = 0;
	fp_rc_stats.drop_cnt = 0;
	//CSR_REG_WRITE(fp_baseAddr, (uint32)CLASS_HW_GLOBAL_CUTTHRU_REG,
	//		CUT_THRU_PORTLIST | (STPID1 << STPID1_START_POS));
	for(i=0; i<FP_MAX_PORTS; i++)
	{
		if((EMAC_PORT_LIST_MASK >> i) & 0x1)
		{
			RegWrite((egpi_base_addr[i] + INGRESS_CLASSIFIER_BASE_ADDR + 0x4b0), CUT_THRU_PORTLIST | (STPID1 << STPID1_START_POS));
		}
	}
	RegWrite((HGPI_BASE_ADDR + INGRESS_CLASSIFIER_BASE_ADDR + 0x4b0), CUT_THRU_PORTLIST | (STPID1 << STPID1_START_POS));

	return 0;
}

/******************************************************************
 * Function Name  : fp_hw_vlantable_add
 * Description    : Add default vlan table entry
 * Inputs         :
 * Parameters     :
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_hw_vlantable_add(void)
{
	uint32a field_entries[5];
	int64 action_entry = 0;
	int32a vlanId = 1;

	field_entries[0] = vlanId;
	/*Adding vlan id 1, port list*/
	action_entry = FWD_PORT_LIST_MASK;
	return wsp_vlan_entry_add(field_entries, 0, action_entry, BIT_SET_VLAN_1F_VLANTBL);
}

void fp_get_port_addr(uint32a i, uint32a *addr1, uint32a *addr2)
{
	switch (i) {
	case 0:
		*addr1 = CLASS_HW_PORT0_STRUC1;
		*addr2 = CLASS_HW_PORT0_STRUC2;
	break;
	case 1:
		*addr1 = CLASS_HW_PORT1_STRUC1;
		*addr2 = CLASS_HW_PORT1_STRUC2;
	break;
	case 2:
		*addr1 = CLASS_HW_PORT2_STRUC1;
		*addr2 = CLASS_HW_PORT2_STRUC2;
	break;
	case 3:
		*addr1 = CLASS_HW_PORT3_STRUC1;
		*addr2 = CLASS_HW_PORT3_STRUC2;
	break;
	case 4:
		*addr1 = CLASS_HW_PORT4_STRUC1;
		*addr2 = CLASS_HW_PORT4_STRUC2;
	break;
	case 5:
		*addr1 = CLASS_HW_PORT5_STRUC1;
		*addr2 = CLASS_HW_PORT5_STRUC2;
	break;
	case 6:
		*addr1 = CLASS_HW_PORT6_STRUC1;
		*addr2 = CLASS_HW_PORT6_STRUC2;
	break;
	case 7:
		*addr1 = CLASS_HW_PORT7_STRUC1;
		*addr2 = CLASS_HW_PORT7_STRUC2;
	break;
	case 8:
		*addr1 = CLASS_HW_PORT8_STRUC1;
		*addr2 = CLASS_HW_PORT8_STRUC2;
	break;
	case 9:
		*addr1 = CLASS_HW_PORT9_STRUC1;
		*addr2 = CLASS_HW_PORT9_STRUC2;
	break;
	default:
		*addr1 = 0;
		*addr2 = 0;
	}
}

