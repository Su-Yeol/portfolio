/*
 * fp_global_addr_map.h - hardware block base addresses
 *
 * Copyright (c) 2007-2009, Naksha Technologies, Inc.
 * Copyright (c) 2010-2012, Posedge Technologies, Inc.
 * Copyright (c) 2013-2020, Imagination Technologies Ltd.
 * All rights reserved.
 */

#ifndef  _FP_GLOBAL_ADDR_MAP_H_
#define  _FP_GLOBAL_ADDR_MAP_H_

#include "global_base_address.h"

/* Firmware needs CBUS base addr */

#define HIF1_BASE_ADDR                       (CBUS_ADDR_BASE + 0x680000)

#define TLITE_BASE_ADDR                      (CBUS_ADDR_BASE + 0x8000) // tlite0

#define MAC_TABLE_ADDR			0x30000UL
#define VLAN_TABLE_ADDR			0x50000UL

#define  SHP_BPS_MODE                 0x00
#define  SHP_PPS_MODE                 0x01
#define  ING_SHP_MIN_RATE             1
#define  ING_SHP_MAX_RATE             1000000
#define  ING_SHP0_UNIT_MASK             0x01
#define  ING_SHP0_TYPE_MASK             0x0C
#define  ING_SHP1_UNIT_MASK             0x02
#define  ING_SHP1_TYPE_MASK             0x70
#define  ING_SHP_CLKDIV_MASK            0x1E
#define  ING_SHP_MAX_CREDIT_MASK        0x3FFFFF00
#define  ING_SHP0_UNIT_POS              0
#define  ING_SHP1_UNIT_POS              1
#define  ING_SHP0_TYPE_POS              2
#define  ING_SHP1_TYPE_POS              4
#define  ING_SHP_ALL                    0
#define  ING_SHP_BCAST                  1
#define  ING_SHP_MCAST                  2
#define  ING_SHP_MAX_WT                 0x7FF
#define  ING_SHP_MAX_CLKDIV             0xF
#define  ING_SHP_MAX_CLKDIV_VAL         (1 << ING_SHP_MAX_CLKDIV)
#define  ING_SHP_CLKDIV_POS             1
#define  ING_SHP_MAX_CREDIT_POS         8

#define  EMAC_RX_BIT_MASK               0x4
#define  EMAC_TX_BIT_MASK               0x8
#define  MAX_ING_SHAPERS                2

#define INGRESS_CLASSIFIER_BASE_ADDR 0x600

#define CLASS_QOS_PORT01_TC_SEL                (CLASS_BASE_ADDR + 0x18)
#define CLASS_QOS_PORT23_TC_SEL                (CLASS_BASE_ADDR + 0x1c)
#define CLASS_QOS_PORT45_TC_SEL                (CLASS_BASE_ADDR + 0x20)
#define CLASS_QOS_PORT67_TC_SEL                (CLASS_BASE_ADDR + 0x24)
#define CLASS_QOS_GLOBAL_DSCP2TC_MAP0          (CLASS_BASE_ADDR + 0x28)
#define CLASS_QOS_GLOBAL_DSCP2TC_MAP1          (CLASS_BASE_ADDR + 0x2c)
#define CLASS_QOS_GLOBAL_DSCP2TC_MAP2          (CLASS_BASE_ADDR + 0x30)
#define CLASS_QOS_GLOBAL_DSCP2TC_MAP3          (CLASS_BASE_ADDR + 0x34)
#define CLASS_QOS_GLOBAL_DSCP2TC_MAP4          (CLASS_BASE_ADDR + 0x38)
#define CLASS_QOS_GLOBAL_DSCP2TC_MAP5          (CLASS_BASE_ADDR + 0x3c)
#define CLASS_QOS_GLOBAL_DSCP2TC_MAP6          (CLASS_BASE_ADDR + 0x40)
#define CLASS_QOS_PORT0_PCP2TC_MAP             (CLASS_BASE_ADDR + 0x44)
#define CLASS_QOS_PORT1_PCP2TC_MAP             (CLASS_BASE_ADDR + 0x48)
#define CLASS_QOS_PORT2_PCP2TC_MAP             (CLASS_BASE_ADDR + 0x4c)
#define CLASS_QOS_PORT3_PCP2TC_MAP             (CLASS_BASE_ADDR + 0x50)
#define CLASS_QOS_PORT4_PCP2TC_MAP             (CLASS_BASE_ADDR + 0x54)
#define CLASS_QOS_PORT5_PCP2TC_MAP             (CLASS_BASE_ADDR + 0x58)
#define CLASS_QOS_PORT6_PCP2TC_MAP             (CLASS_BASE_ADDR + 0x5c)
#define CLASS_QOS_PORT7_PCP2TC_MAP             (CLASS_BASE_ADDR + 0x60)
#define CLASS_QOS_PORT_PID2TC_MAP              (CLASS_BASE_ADDR + 0x64)
#define CLASS_QOS_PORT0_TC2COS_MAP             (CLASS_BASE_ADDR + 0x68)
#define CLASS_QOS_PORT1_TC2COS_MAP             (CLASS_BASE_ADDR + 0x6c)
#define CLASS_QOS_PORT2_TC2COS_MAP             (CLASS_BASE_ADDR + 0x70)
#define CLASS_QOS_PORT3_TC2COS_MAP             (CLASS_BASE_ADDR + 0x74)
#define CLASS_QOS_PORT4_TC2COS_MAP             (CLASS_BASE_ADDR + 0x78)
#define CLASS_QOS_PORT5_TC2COS_MAP             (CLASS_BASE_ADDR + 0x7c)
#define CLASS_QOS_PORT6_TC2COS_MAP             (CLASS_BASE_ADDR + 0x80)
#define CLASS_QOS_PORT7_TC2COS_MAP             (CLASS_BASE_ADDR + 0x84)

#endif

