// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_switch_host_ageing.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    implements switch ageing functionality
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");


/**********************************************************************
 *                                      Include Files
 **********************************************************************/
#include "linux/spinlock.h"

#include "reg_hal.h"
#include "fp_library.h"
#include "fp_switch.h"
#include "global_address_map_fpga.h"
#include "hw_2field_hash_table.h"

extern spinlock_t tbl_lock;

/**********************************************************************
 *                              Extern Declarations
***********************************************************************/

/********************************************************************
 * Function Name  : fp_switch_host_ageing
 * Description    : handles hw mac table update for ageing.
 *                  read each entry from hash table,
 *                  delete hash entry if fresh bit is set(1)
 *                  change fresh bit to set(1) if it is unset(0)
 * Inputs         :
 * Parameters     : void
 * Outputs        :
 * Parameters     : -
 * Returns        : void
 ********************************************************************/
void fp_switch_host_ageing(void)
{
	uint32a hashidx = 0;
	uint32a vlan_valid = 0;
	uint32a coll_ptr = 0;
	uint32a mac3 = 0;
	uint32a mac4 = 0;
	uint32a mac1 = 0;
	uint32a mac2 = 0;
	static uint32a hashBase;

	if (GetBaseAddr() == NULL) {
		printk("pci base address null");
		return;
	}

/* 2-field Mac table format: Table Depth - 1024(hash 512 + collison 512)
*============================================================================*
* valid bits | col_ptr | portNO | field_valids | action entry | vlanid|  MAC *
*============================================================================*
* 4-bit      | 16-bit  | 4-bit  | 8-bit(mac4)  | 31-bit (mac3)| 13-bit|48-bit*
*============================================================================*/

/*=============================================================================*
* MAC1:MAC[31:0]                                                               *
*==============================================================================*
* MAC2:ACT_ENTRY[31:29] + VLANID[28:16] + MAC[15:0]                            *
*==============================================================================*
* MAC3:FIELD_VALIDS[31:28] + ACT_ENTRY[27:0]                                   *
*==============================================================================*
*MAC4:RSVD[31:28]+VALIDBITS[27:24]+COLPTR[23:8]+ PORTNO[7:4] + FIELDVALIDS[3:0]*
*=============================================================================*/

	FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_DEBUG, "HASH UPDATE is Called\r\n");
	for (hashidx = 0; hashidx <  HASH_CNT_PER_ITERATION; hashidx++) {
		uint32a cmd;
start:
		spin_lock_bh(&tbl_lock);
		coll_ptr = 0;
		mac3 = 0;
		mac4 = 0;
		vlan_valid = 0;
		TableWrite(MAC_HASH_HOST_MAC1_ADDR_REG, 0, DEFAULT_TABLE);
		TableWrite(MAC_HASH_HOST_MAC2_ADDR_REG, 0, DEFAULT_TABLE);
		TableWrite(MAC_HASH_HOST_MAC3_ADDR_REG, 0, DEFAULT_TABLE);
		TableWrite(MAC_HASH_HOST_MAC4_ADDR_REG, 0, DEFAULT_TABLE);
		TableWrite(MAC_HASH_HOST_MAC5_ADDR_REG, 0, DEFAULT_TABLE);
		TableWrite(MAC_HASH_HOST_ENTRY_REG,     0, DEFAULT_TABLE);
		TableWrite(MAC_HASH_HOST_DIRECT_REG,    0, DEFAULT_TABLE);
		/* Read hash index entry */
		cmd = ((hashBase + hashidx)<<16) | CMD_MEM_READ;
		IssueCommand(	MAC_HASH_HOST_CMD_REG,
				cmd,
				MAC_HASH_HOST_STATUS_REG,
				STATUS_CMD_DONE);
		/* read field_entries */
		mac4 = TableRead(MAC_HASH_HOST_ENTRY_REG, DEFAULT_TABLE);
		if (mac4)
			FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO,
						"mac4:%x\r\n", mac4);
		if (HASH_ENTRY_VALID_FLAG & mac4) {
			FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO,
				"HASH idx:%x\r\n", hashBase + hashidx);
			if (mac4 & HASH_ENTRY_COLL_FLAG)
				coll_ptr = (mac4 >> 8) & 0xFFFF;
			mac3 = TableRead(MAC_HASH_HOST_MAC3_ADDR_REG, DEFAULT_TABLE);
			mac2 = TableRead(MAC_HASH_HOST_MAC2_ADDR_REG, DEFAULT_TABLE);
			mac1 = TableRead(MAC_HASH_HOST_MAC1_ADDR_REG, DEFAULT_TABLE);
			FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO,
						"mac3:%x\r\n", mac3);
			if (HASH_ENTRY_FRESH_FLAG & mac3) { /* delete */
				/*  vlan_valid =
					(mac3 & HASH_ENTRY_VLAN_SET_FLAG) ?
					BIT_SET_VLAN_2F_MACTBL : 0; */
				IssueCommand_nowait(
					MAC_HASH_HOST_CMD_REG,
					( CMD_DEL
					| BIT_SET_MAC_2F_MACTBL
					| BIT_SET_VLAN_2F_MACTBL));
				fp_rc_stats.hw_hash_entry_count--;
				FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO,
					"HASH Del:%x\r\n", hashBase + hashidx);
				if (coll_ptr) {
					CommandWait(	MAC_HASH_HOST_STATUS_REG,
							STATUS_CMD_DONE);
					spin_unlock_bh(&tbl_lock);
					goto start;
				}
			} else {
				/* update */
				if (!(mac3 & HASH_ENTRY_STATIC_FLAG)) {
					mac3 |= HASH_ENTRY_FRESH_FLAG;
					TableWrite(MAC_HASH_HOST_MAC3_ADDR_REG,
						mac3,
						DEFAULT_TABLE);
					TableWrite(MAC_HASH_HOST_CMD_REG,
						CMD_MEM_WRITE |
						((hashBase + hashidx) << 16),
						DEFAULT_TABLE);
					FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO,
						"HASH Update:%x\r\n",
						hashBase + hashidx);
				} else {
					spin_unlock_bh(&tbl_lock);
					continue;
				}
			}
			CommandWait(	MAC_HASH_HOST_STATUS_REG,
					STATUS_CMD_DONE);
		} /* End if - HASH_ENTRY_VALID_FLAG */
		spin_unlock_bh(&tbl_lock);
		/* collision space entries */
		while (coll_ptr) {
			spin_lock_bh(&tbl_lock);
			TableWrite(MAC_HASH_HOST_MAC1_ADDR_REG, 0, DEFAULT_TABLE);
			TableWrite(MAC_HASH_HOST_MAC2_ADDR_REG, 0, DEFAULT_TABLE);
			TableWrite(MAC_HASH_HOST_MAC3_ADDR_REG, 0, DEFAULT_TABLE);
			TableWrite(MAC_HASH_HOST_MAC4_ADDR_REG, 0, DEFAULT_TABLE);
			/* Read hash index entry */
			IssueCommand(	MAC_HASH_HOST_CMD_REG,
					((coll_ptr<<16) | CMD_MEM_READ),
					MAC_HASH_HOST_STATUS_REG,
					STATUS_CMD_DONE);
			/* read field_entries */
			mac3 = mac4 = vlan_valid = 0;
			mac4 = TableRead(MAC_HASH_HOST_MAC4_ADDR_REG,
					DEFAULT_TABLE);
			/* check entry's validity */
			if (HASH_ENTRY_VALID_FLAG & mac4) {
				mac3 = TableRead(MAC_HASH_HOST_MAC3_ADDR_REG,
						DEFAULT_TABLE);
				if (HASH_ENTRY_FRESH_FLAG & mac3) { /* delete */
					/* vlan_valid = (mac3 &
						HASH_ENTRY_VLAN_SET_FLAG) ?
						BIT_SET_VLAN_2F_MACTBL : 0;*/
					IssueCommand_nowait(
						MAC_HASH_HOST_CMD_REG,
						( CMD_DEL
						| BIT_SET_MAC_2F_MACTBL
						| BIT_SET_VLAN_2F_MACTBL));
					fp_rc_stats.hw_hash_entry_count--;
					FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO,
						"Coll HASH Del:%x\r\n",
						coll_ptr);
				} else {
					/* update */
					if (!(mac3 & HASH_ENTRY_STATIC_FLAG)) {
					mac3 |= HASH_ENTRY_FRESH_FLAG;
					TableWrite(MAC_HASH_HOST_MAC3_ADDR_REG,
						mac3, DEFAULT_TABLE);
					/* Issue the MEM write cmd */
					IssueCommand_nowait(
						MAC_HASH_HOST_CMD_REG,
						CMD_MEM_WRITE | (coll_ptr << 16));
					FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO,
						"COLL HASH UPDATE:%x\r\n",
						coll_ptr);
					} else {
						coll_ptr = 0;
						if (mac4 & HASH_ENTRY_COLL_FLAG)
							coll_ptr = (mac4 >> 8) & 0xFFFF;
						spin_unlock_bh(&tbl_lock);
						continue;
					}
				}
				coll_ptr = 0;
				if (mac4 & HASH_ENTRY_COLL_FLAG)
					coll_ptr = (mac4 >> 8) & 0xFFFF;
				CommandWait(	MAC_HASH_HOST_STATUS_REG,
						STATUS_CMD_DONE);
			} /* End if - HASH_ENTRY_VALID_FLAG */
		spin_unlock_bh(&tbl_lock);
		} /* End While - coll_ptr */
	} /* end of for loop- hashidx */
	/*update hashBase */
	hashBase += hashidx;
	/* updating entries in blocks */
	if (hashBase >= (TWO_FIELD_HASH_ENTRIES-1))
		hashBase = 0;
}
