/* SPDX-License-Identifier: (GPL-2.0 WITH Linux-syscall-note) AND MIT */

/*************************************************************************/ /*!
@File
@Title          fp_cb_api.h
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    API to configure CB entries
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#ifndef  _FP_CB_API_H_
#define  _FP_CB_API_H_

#include "global_base_address.h"
#include "tables_config.h"

/* CB Registers */

/* ----------------------------------------------------*/
//* moved to config/N4900R22p*/include/tables_config.h */
//#define CB_TABLE_HASH_ENTRIES		64
//#define CB_TABLE_COLL_ENTRIES 	64
//#define CB_TABLE_SIZE			(CB_TABLE_HASH_ENTRIES+CB_TABLE_COLL_ENTRIES)
/* ----------------------------------------------------*/

#define CB_TABLE_INIT_HEAD_PTR		0x40
#define CB_TABLE_INIT_TAIL_PTR		0x7F

#define CB_SEQ_RESET_TIMEOUT_REG	(CB_ENTRY_BASE_ADDR + 0x38)
#define CB_SEQ_HISTORY_LEN_REG  	(CB_ENTRY_BASE_ADDR + 0x38)

/* ----------------------------------------------------*/
//* moved to config/N4900R22p*/include/tables_config.h */
//#define CB_SMAC_HASH_ENTRIES		64
//#define CB_SMAC_COLL_ENTRIES 		64
/* ----------------------------------------------------*/
#define SMAC_VLAN_TABLE_SIZE		(CB_SMAC_HASH_ENTRIES+CB_SMAC_COLL_ENTRIES)

#define CB_SMAC_INIT_HEAD_PTR	 	0x40
#define CB_SMAC_INIT_TAIL_PTR		0x7F


/* HW MAC TABLE CMDS */
#define CMD_INIT	1
#define CMD_ADD		2
#define CMD_DEL		3
#define CMD_UPDATE	4
#define CMD_SEARCH	5
#define CMD_MEM_READ	6
#define CMD_MEM_WRITE	7
#define CMD_FLUSH	8

#define STATUS_ENTRY_MATCH	0x00000010
#define BIT_SET_MAC_2F_MACTBL	0x00000300
#define BIT_SET_SMAC_TBL	0x00000100
#define CLR_STATUS_REG		0xFFFFFFFF


/* CB Status bits */
#define CB_ENTRY_STATUS_CMD_DONE	0x1

#define CB_ENTRY_STATUS_CLR	0xFFFFFFFF

#define CB_RECOVERY_BASE_ADDR 		0x70000
#define CB_RECOVERY_ENTRY_SIZE 		0x480
/* TODO: need to set exact num_entries based on memory */
#define CB_NUM_PORTS 6
#define NUM_CB_SEQ_RECOVERY_ENTRIES	104

#define NUM_RECOVERY_ENTRIES		12

#define CB_IND_RECOVERY_START_ADDR CB_RECOVERY_BASE_ADDR

//#define CB_SEQ_RECOVERY_START_ADDR CB_RECOVERY_BASE_ADDR + (CB_NUM_PORTS * CB_RECOVERY_ENTRY_SIZE)

#define CB_FIELD_VALID_MAC	0x1
#define CB_FIELD_VALID_VLAN	0x2
#define CB_FIELD_VALID_SRC_MAC	0x4

typedef struct
{
	uint8 mac[6];
	uint16 vlan;

	/* forward port list
        Each bit corresponds to one port.
        If a bit is set, then HW will forward the packet to particular port(s).
        bit0 - port0 ; bit1 – port1;..;bit5 – port5;
        bit6 – Host;
        bitn - resevred
	*/
	uint64 fwd_port_list:20;
	/* 0 - NULL stream, 1 - source mac+vlan strea, 2,3 - reserved */
	uint64 id_type:2;
	/* Fields used for hash calculation
	   bit0 (mac)
	   bit1 (vlan)
	   bit2 (id_type)
	 */
	//uint32a field_valids:8;
	/* instance functionality is configured as,
	   enable_seq_gen - talker
	   enable_recovery - relay/listener
	   enable_rtag_removal - listner
	 */
    	/* Enables vlan tag removal */
	uint64 enable_vtag_removal:1;
    	/* Enables the rtag removal */
	uint64 enable_rtag_removal:1;

    	/* Enables recovery */
	uint64 enable_recovery:1;
	/* enable seq generation */
	uint64 enable_seq_gen:1;
	/* enable mapped vlan */
	uint64 enable_mapped_vlan:1;
	/* enable vlan insertion */
	uint64 enable_vlan_insertion:1;
	uint64 reserved:2;
	/* Each Bit corresponds to individual recovery enables for each port
	   and sequence recovery.
	   bit0 - individual recovery on port0
	   bit1 - individual recovery on port1
	   ..
	   bit5 - individual recovery on port19
	   bit6 - sequence recovery
	   bitn - reserved for future
	 */
	uint64 recovery_enable_bits:20;
	uint64 dummy:14;
	/* Each bit corresponds to a port for which vlan tag removal is required */
	uint64 vtag_removal_port_list:20;
	/* Each bit corresponds to a port for which rtag removal is required */
	uint64 rtag_removal_port_list:20;
	/* Each bit corresponds to a port for which rtag removal is required */
	uint64 port_drop_list:20;
	uint64 dummy2:4;
    	/* vlan id to be added in the untagged packet */
	uint64 mapped_vlan:12;
	uint64 pcp:4;
	uint64 reserved1:2;

	/* address of the sequence recovery entry */
	uint64 seq_gen_recovery_ptr:16;
	uint64 reserved2:8;
	uint64 recovery_algo_type:8;
	uint64 dummy3:14;

	uint32a seq_history_len:14;
	uint32a seq_rec_reset_msec:16;
	//uint32a dummy4:2;
	uint32a valid:2;

	uint32a recovery_data[168];

	uint16 start_seq_num;

} fp_cb_entry_t;


struct recovery_entry {
	union {
		struct {
			uint32a valid:1;
			uint32a initial_pkt_recvd:1;
			uint32a reserved:2;
			uint32a seq_history_len:11;
			uint32a recovery_algo_type:1;
			uint32a sequence_history1:16;
		};
		uint32a Reg0;
	};
	union {
		struct {
			uint16 sequence_history2;
			uint16 rem_ticks;
		};
		uint32a Reg1;
	};
	union {
		struct {
			uint16 seq_rec_reset_msec;
			uint16 reserved2;
		};
		uint32a Reg2;
	};
	union {
		struct {
			uint16 seq_num;
			uint16 rogue_pkt_cnt;
		};
		uint32a Reg3;
	};
	union {
		struct {
			uint16 lost_pkt_cnt;
			uint16 tag_less_pkt;
		};
		uint32a Reg4;
	};
	union {
		uint32a passed_count;
		uint32a Reg5;
	};
	union {
		struct {
			uint16 reset_Count;
			uint16 out_of_order_count;
		};
		uint32a Reg6;
	};
	union {
		struct {
			uint32a discarded_Count;
			uint32a seq_history1;
			uint32a seq_history2;
			uint32a seq_history3;
			uint32a seq_history4;
		};
		struct {
			uint32a Reg7;
			uint32a Reg8;
			uint32a Reg9;
			uint32a Reg10;
			uint32a Reg11;
		};
	};
};

typedef struct {
	uint8 mac[6];
	uint16 vlan;
} fp_smac_vlan_entry_t;

/*!
 Add CB entry

 @param wsp_base_addr  Base address of the EPP registers
 @param            cb  cb entry to be added
 @return status code   0=success, -1=failure
 **/
int32a fp_cb_add_entry(fp_cb_entry_t *cb);

/*!
 Delete CB entry

 @param wsp_base_addr  Base address of the EPP registers
 @param           mac  mac address of the entry
 @param       vlan_id  vlan id of the entry
 @param   id_type      identification type
 @return status code   0=success, -1=failure
 **/
int32a fp_cb_del_entry (	uint8 mac[],
			uint32a vlan_id,
			uint8 id_type);

/*!
 Get CB entry

 @param   wsp_base_addr   Base address of the WSP registers
 @param           mac     mac address of the entry
 @param       vlan_id     vlan id of the entry
 @param   id_type      identification type
 @param             cb    cb entry to be read
 @return  status code:    0=success, -1=failure
 */

int32a fp_cb_get_entry(	uint8 mac[],
			uint32a vlan_id,
			uint8 id_type,
			fp_cb_entry_t *cb);

/*!
 Sets Sequence Reset timeout value for all streams.
 Sets the value globally to be used by all streams

 @param wsp_base_addr  Base address of the EPP registers
 @param       timeout  timeout value in msec
 @return status code   0=success, -1=failure
 **/
int32a fp_cb_set_seq_reset_timeout_val (uint32a timeout);

/*!
 Sets Sequence History Length for all streams.
 Sets the value globally to be used by all streams

 @param wsp_base_addr  Base address of the EPP registers
 @param           len  Sequence History Length (default 1024)
 @return status code   0=success, -1=failure
 **/
int32a fp_set_seq_history_len(uint32a len);

/*****************************************************************
*
*  Recovery Entry allocation APIs
*  TODO: need to maintain alloc and free list for following APIs
*
******************************************************************/

/*!
 Allocates Sequence Recovery Entry.
 Need to allocate this recovery entry before adding the CB entry, if required.

 @param wsp_base_addr  Base address of the EPP
 @return status code   0=success, -1=failure
 **/
uint32a fp_alloc_seq_recovery_entry(void);

/*!
 Free Sequence Recovery Entry
 This entry needs to be freed after deletion of CB entry.

 @param wsp_base_addr  Base address of the EPP
 @param rec            seq recovery entry to be freed
 @return status code   0=success, -1=failure
 **/
int32a fp_cb_get_entry_by_index(		uint32a index,
					fp_cb_entry_t *cb);
uint32a fp_free_seq_recovery_entry(uint32a seq_gen_recovery_ptr);
uint32a fp_fill_seq_recovery_entry(fp_cb_entry_t *cb);
uint32a fp_get_seq_recovery_entry(	uint32a seq_gen_recovery_ptr,
					uint32a *data);
int32a fp_smac_vlan_table_init(void);
int32a fp_smac_vlan_add_entry(		fp_smac_vlan_entry_t *smac);
int32a fp_smac_vlan_del_entry (		uint8 mac[]);
int32a fp_smac_vlan_get_entry(		uint8 mac[]);
int32a fp_cb_table_init(void);
#endif
