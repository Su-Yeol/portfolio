/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          tlite_blocks_ctrlm.h
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    tlite defines
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

#ifndef _TLITE_BLOCKS_CTRLM_H_
#define _TLITE_BLOCKS_CTRLM_H_

#include "fp_macros.h"
#include "fp_global_addr_map.h"
#include "tlite_blocks_ctrl_api.h"
#include "tables_config.h"

/***********************************************************
                    DEFINES
***********************************************************/
#define TLITE_EN			1
#define TLITE_DEBUG			1
#define TLITE_DEFAULT_CONFIG		1
#define HW_SWITCH_EN			1

/*
#define TLITE_VERSION_ADDR		(TLITE_BASE_ADDR + 0x00)
#define TLITE_INQ_WATERMARK		(TLITE_BASE_ADDR + 0x04)
#define TLITE_PHY_INQ_PKTPTR_ADDR	(TLITE_BASE_ADDR + 0x08)
#define TLITE_PHY_INQ_PKTINFO_ADDR	(TLITE_BASE_ADDR + 0x0C)
#define TLITE_PHY_INQ_STAT_ADDR		(TLITE_BASE_ADDR + 0x10)
#define TLITE_PHY_QUEUE_SEL_ADDR	(TLITE_BASE_ADDR + 0x14)
#define TLITE_CURQ_PTR_ADDR		(TLITE_BASE_ADDR + 0x18)
#define TLITE_CURQ_PKT_CNT_ADDR		(TLITE_BASE_ADDR + 0x1C)
#define TLITE_CURQ_DROP_CNT_ADDR	(TLITE_BASE_ADDR + 0x20)
#define TLITE_CURQ_TRANS_CNT_ADDR	(TLITE_BASE_ADDR + 0x24)
#define TLITE_CURQ_QSTAT_ADDR		(TLITE_BASE_ADDR + 0x28)
#define TLITE_HW_PROB_CFG_TBL0_ADDR	(TLITE_BASE_ADDR + 0x2C)
#define TLITE_HW_PROB_CFG_TBL1_ADDR	(TLITE_BASE_ADDR + 0x30)
//#define TLITE_HW_PROB_CFG_TBL0_ADDR	(TLITE_BASE_ADDR + 0x4C)
#define TLITE_CURQ_DEBUG_ADDR		(TLITE_BASE_ADDR + 0x34)
#define TLITE_CTRL_ADDR			(TLITE_BASE_ADDR + 0x38)
#define TLITE_BMU_INQ_ADDR		(TLITE_BASE_ADDR + 0x3c)
#define TLITE_AFULL_THRES_ADDR		(TLITE_BASE_ADDR + 0x40)
#define TLITE_BMU_BUFF_SIZE_ADDR	(TLITE_BASE_ADDR + 0x44)
#define TLITE_MAX_BUF_CNT_ADDR		(TLITE_BASE_ADDR + 0x48)
#define TLITE_TEQ_CTRL_ADDR		(TLITE_BASE_ADDR + 0x4C)
#define TLITE_DDR_DATA_OFFSET_ADDR	(TLITE_BASE_ADDR + 0x54)
#define TLITE_LMEM_BUF_SIZE_ADDR	(TLITE_BASE_ADDR + 0x58)
#define TLITE_LMEM_DATA_OFFSET_ADDR	(TLITE_BASE_ADDR + 0x5c)
#define TLITE_LMEM_BASE_ADDR_ADDR	(TLITE_BASE_ADDR + 0x60)
#define TLITE_PHY0_INQ_ADDR		(TLITE_BASE_ADDR + 0x64)
#define TLITE_PHY1_INQ_ADDR		(TLITE_BASE_ADDR + 0x68)
#define TLITE_PHY2_INQ_ADDR		(TLITE_BASE_ADDR + 0x6c)
#define TLITE_PHY3_INQ_ADDR		(TLITE_BASE_ADDR + 0x70)
#define TLITE_PHY4_INQ_ADDR		(TLITE_BASE_ADDR + 0x74)
#define TLITE_PHY5_INQ_ADDR		(TLITE_BASE_ADDR + 0x78)
#define TLITE_PHY6_INQ_ADDR		(TLITE_BASE_ADDR + 0x7c)
#define TLITE_PHY7_INQ_ADDR		(TLITE_BASE_ADDR + 0x80)
#define TLITE_PHY8_INQ_ADDR		(TLITE_BASE_ADDR + 0x84)
#define TLITE_PHY9_INQ_ADDR		(TLITE_BASE_ADDR + 0x88)
#define TLITE_PHY10_INQ_ADDR		(TLITE_BASE_ADDR + 0x8c)
#define TLITE_PHY11_INQ_ADDR		(TLITE_BASE_ADDR + 0x90)
#define TLITE_PHY12_INQ_ADDR		(TLITE_BASE_ADDR + 0x94)
#define TLITE_PHY13_INQ_ADDR		(TLITE_BASE_ADDR + 0x98)
#define TLITE_PHY14_INQ_ADDR		(TLITE_BASE_ADDR + 0x9c)
#define TLITE_PHY15_INQ_ADDR		(TLITE_BASE_ADDR + 0xa0)
#define TLITE_PHY16_INQ_ADDR		(TLITE_BASE_ADDR + 0xa4)
#define TLITE_PHY0_TDQ_IIFG_ADDR	(TLITE_BASE_ADDR + 0xac)
#define TLITE_PHY1_TDQ_IIFG_ADDR	(TLITE_BASE_ADDR + 0xb0)
#define TLITE_PHY2_TDQ_IIFG_ADDR	(TLITE_BASE_ADDR + 0xb4)
#define TLITE_PHY3_TDQ_IIFG_ADDR	(TLITE_BASE_ADDR + 0xb8)
#define TLITE_PHY4_TDQ_IIFG_ADDR	(TLITE_BASE_ADDR + 0xbc)
#define TLITE_PHY5_TDQ_IIFG_ADDR	(TLITE_BASE_ADDR + 0xc0)
#define TLITE_PHY6_TDQ_IIFG_ADDR	(TLITE_BASE_ADDR + 0xc4)
#define TLITE_PHY7_TDQ_IIFG_ADDR	(TLITE_BASE_ADDR + 0xc8)
#define TLITE_PHY8_TDQ_IIFG_ADDR	(TLITE_BASE_ADDR + 0xcc)
#define TLITE_PHY9_TDQ_IIFG_ADDR	(TLITE_BASE_ADDR + 0xd0)
#define TLITE_PHY10_TDQ_IIFG_ADDR	(TLITE_BASE_ADDR + 0xd4)
#define TLITE_PHY11_TDQ_IIFG_ADDR	(TLITE_BASE_ADDR + 0xd8)
#define TLITE_PHY12_TDQ_IIFG_ADDR	(TLITE_BASE_ADDR + 0xdc)
#define TLITE_PHY13_TDQ_IIFG_ADDR	(TLITE_BASE_ADDR + 0xe0)
#define TLITE_PHY14_TDQ_IIFG_ADDR	(TLITE_BASE_ADDR + 0xe4)
#define TLITE_PHY15_TDQ_IIFG_ADDR	(TLITE_BASE_ADDR + 0xe8)
#define TLITE_PHY16_TDQ_IIFG_ADDR	(TLITE_BASE_ADDR + 0xec)

#define TLITE_PHY0_TDQ_CTRL_ADDR	(TLITE_BASE_ADDR + 0xf0)
#define TLITE_PHY1_TDQ_CTRL_ADDR	(TLITE_BASE_ADDR + 0xf4)
#define TLITE_PHY2_TDQ_CTRL_ADDR	(TLITE_BASE_ADDR + 0xf8)
#define TLITE_PHY3_TDQ_CTRL_ADDR	(TLITE_BASE_ADDR + 0xfc)
#define TLITE_PHY4_TDQ_CTRL_ADDR	(TLITE_BASE_ADDR + 0x100)
#define TLITE_PHY5_TDQ_CTRL_ADDR	(TLITE_BASE_ADDR + 0x104)
#define TLITE_PHY6_TDQ_CTRL_ADDR	(TLITE_BASE_ADDR + 0x108)
#define TLITE_PHY7_TDQ_CTRL_ADDR	(TLITE_BASE_ADDR + 0x10c)
#define TLITE_PHY8_TDQ_CTRL_ADDR	(TLITE_BASE_ADDR + 0x110)
#define TLITE_PHY9_TDQ_CTRL_ADDR	(TLITE_BASE_ADDR + 0x114)
#define TLITE_PHY10_TDQ_CTRL_ADDR	(TLITE_BASE_ADDR + 0x118)
#define TLITE_PHY11_TDQ_CTRL_ADDR	(TLITE_BASE_ADDR + 0x11c)
#define TLITE_PHY12_TDQ_CTRL_ADDR	(TLITE_BASE_ADDR + 0x120)
#define TLITE_PHY13_TDQ_CTRL_ADDR	(TLITE_BASE_ADDR + 0x124)
#define TLITE_PHY14_TDQ_CTRL_ADDR	(TLITE_BASE_ADDR + 0x128)
#define TLITE_PHY15_TDQ_CTRL_ADDR	(TLITE_BASE_ADDR + 0x12c)
#define TLITE_PHY16_TDQ_CTRL_ADDR	(TLITE_BASE_ADDR + 0x130)

#define TLITE_CNTX_ACCESS_CTRL_ADDR	(TLITE_BASE_ADDR + 0x134)
#define TLITE_CNTX_ADDR			(TLITE_BASE_ADDR + 0x138)
#define TLITE_CNTX_DATA_ADDR		(TLITE_BASE_ADDR + 0x13c)
#define TLITE_CNTX_CMD_ADDR		(TLITE_BASE_ADDR + 0x140)

#define TLITE_DBG_BUS_TOP_ADDR		(TLITE_BASE_ADDR + 0x144)
#define TLITE_DBG_BUS_PP0_ADDR		(TLITE_BASE_ADDR + 0x148)
#define TLITE_DBG_BUS_PP1_ADDR		(TLITE_BASE_ADDR + 0x14c)
#define TLITE_DBG_BUS_PP2_ADDR		(TLITE_BASE_ADDR + 0x150)
#define TLITE_DBG_BUS_PP3_ADDR		(TLITE_BASE_ADDR + 0x154)
#define TLITE_DBG_BUS_PP4_ADDR		(TLITE_BASE_ADDR + 0x158)
#define TLITE_DBG_BUS_PP5_ADDR		(TLITE_BASE_ADDR + 0x15c)
#define TLITE_DBG_BUS_PP6_ADDR		(TLITE_BASE_ADDR + 0x160)
#define TLITE_DBG_BUS_PP7_ADDR		(TLITE_BASE_ADDR + 0x164)
#define TLITE_DBG_BUS_PP8_ADDR		(TLITE_BASE_ADDR + 0x168)
#define TLITE_DBG_BUS_PP9_ADDR		(TLITE_BASE_ADDR + 0x16c)
#define TLITE_DBG_BUS_PP10_ADDR		(TLITE_BASE_ADDR + 0x170)
#define TLITE_DBG_BUS_PP11_ADDR		(TLITE_BASE_ADDR + 0x174)
#define TLITE_DBG_BUS_PP12_ADDR		(TLITE_BASE_ADDR + 0x178)
#define TLITE_DBG_BUS_PP13_ADDR		(TLITE_BASE_ADDR + 0x17c)
#define TLITE_DBG_BUS_PP14_ADDR		(TLITE_BASE_ADDR + 0x180)
#define TLITE_DBG_BUS_PP15_ADDR		(TLITE_BASE_ADDR + 0x184)
#define TLITE_DBG_BUS_PP16_ADDR		(TLITE_BASE_ADDR + 0x188)

#define TLITE_METER_ADDR		(TLITE_BASE_ADDR + 0x190)
#define TLITE_METER_CFG0_ADDR		(TLITE_BASE_ADDR + 0x194)
#define TLITE_METER_CFG1_ADDR		(TLITE_BASE_ADDR + 0x198)
#define TLITE_METER_CMD_ADDR		(TLITE_BASE_ADDR + 0x19c)
//#define TLITE_SCH_SHP_RANGE_ADDR	(TLITE_BASE_ADDR + 0x1000)


#define TLITE_TDQ_PHY0_CSR_BASE_ADDR   (TLITE_BASE_ADDR + 0x1000)


#define TLITE_SCH0_CTRL_ADDR		 TLITE_TDQ_PHY0_CSR_BASE_ADDR
#define TLITE_SCH0_Q0_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x20)
#define TLITE_SCH0_Q1_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x24)
#define TLITE_SCH0_Q2_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x28)
#define TLITE_SCH0_Q3_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x2C)
#define TLITE_SCH0_Q4_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x30)
#define TLITE_SCH0_Q5_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x34)
#define TLITE_SCH0_Q6_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x38)
#define TLITE_SCH0_Q7_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x3C)
#define TLITE_SCH0_Q_ALLOC0_ADDR	(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x40)
#define TLITE_SCH0_Q_ALLOC1_ADDR	(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x44)
#define TLITE_SCH0_BIT_RATE_ADDR	(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x48)
#define TLITE_SCH0_POS_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x54)

#define TLITE_SCH1_CTRL_ADDR           (TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x100)
#define TLITE_SCH1_Q0_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x120)
#define TLITE_SCH1_Q1_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x124)
#define TLITE_SCH1_Q2_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x128)
#define TLITE_SCH1_Q3_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x12C)
#define TLITE_SCH1_Q4_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x130)
#define TLITE_SCH1_Q5_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x134)
#define TLITE_SCH1_Q6_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x138)
#define TLITE_SCH1_Q7_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x13C)
#define TLITE_SCH1_Q_ALLOC0_ADDR	(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x140)
#define TLITE_SCH1_Q_ALLOC1_ADDR	(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x144)
#define TLITE_SCH1_BIT_RATE_ADDR	(TLITE_TDQ_PHY0_CSR_BASE_ADDR + 0x148)

#define TLITE_SHP0_CTRL_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x200)
#define TLITE_SHP0_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x204)
#define TLITE_SHP0_MAX_CREDIT_ADDR	(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x208)
#define TLITE_SHP0_CTRL2_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x20C)
#define TLITE_SHP0_MIN_CREDIT		(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x210)
#define TLITE_SHP1_CTRL_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x300)
#define TLITE_SHP1_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x304)
#define TLITE_SHP1_MAX_CREDIT_ADDR	(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x308)
#define TLITE_SHP1_CTRL2_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x30C)
#define TLITE_SHP1_MIN_CREDIT		(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x310)
#define TLITE_SHP2_CTRL_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x400)
#define TLITE_SHP2_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x404)
#define TLITE_SHP2_MAX_CREDIT_ADDR	(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x408)
#define TLITE_SHP2_CTRL2_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x40C)
#define TLITE_SHP2_MIN_CREDIT		(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x410)
#define TLITE_SHP3_CTRL_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x500)
#define TLITE_SHP3_WGHT_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x504)
#define TLITE_SHP3_MAX_CREDIT_ADDR	(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x508)
#define TLITE_SHP3_CTRL2_ADDR		(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x50C)
#define TLITE_SHP3_MIN_CREDIT		(TLITE_TDQ_PHY0_CSR_BASE_ADDR+ 0x510)
*/

//#define CLASS_PORT0_STRUC3		(CLASS_BASE_ADDR + 0x504)

/*INIT PARAMS*/
#define TLITE_HW_EN			0x0000000F
#define CLK_RATIO			0x00000001
#define LLM_BASE_ADDR			0x00100000
#define LLM_QLENGTH			0x00000080
#define QMAX				0x7c
#define TEQ_DISABLE_DROP		0x00000005
#define INQ_WMARK			0x000002ee

#define MAX_FREQUENCY			0x251
#define MAX_CLKDIV			16384
#define MAX_WT				0xFFFFF  //0x3FF
#define TMU_SHP_RATE_PACKETS		0x1
#define REG_LEN				0x4
#define BIT1_ZERO			0xFFFFFFFD
#define BIT1_ONE			0x00000002
#define BIT4_ONE			0x00000010
#define SHED_ADDRESS_MASK		0x100
#define DEV_ADDRESS_MASK		0x1000
#define SHPR_ADDRESS_MASK		0x100
#define SHPR_EN_BIT			0x00000001
#define BIT0				0x000001
#define BIT8				0x000100
#define BIT_0TO7			0x000000FF
#define BIT_0TO6			0x0000007F
#define BIT_0TO15			0x0000FFFF
#define BIT_0TO11			0x00000FFF
#define BIT_0TO21			0x003FFFFF
#define BIT_0TO2			0x0007
#define NIBBLE0_ZERO			0xFFFFFFF0
#define NIBBLE0_ONE			0x0000000F
#define NIBBLE2_ZERO			0xFFFFF0FF
#define NIBBLE4_ZERO			0xFFF0FFFF
#define NIBBLE6_ZERO			0xF0FFFFFF
#define SHIFT_BY1			1
#define SHIFT_BY2			2
#define SHIFT_BY5			5
#define SHIFT_BY6			6
#define SHIFT_BY7			7
#define SHIFT_BY8			8
#define SHIFT_BY9			9
#define SHIFT_BY10			10
#define SHIFT_BY11			11
#define SHIFT_BY12			12
#define SHIFT_BY15			15
#define SHIFT_BY16			16
#define SHIFT_BY20			20
#define SHIFT_BY24			24
#define SHIFT_BY25			25
#define SHIFT_BY29			29
#define SHIFT_BY30			30
#define SHIFT_BY31			31


/*scheduler defines*/
#define TLITE_MIN_SCHED_NUM		0x01
#define TLITE_MAX_SCHED_NUM		0x02
#define TLITE_MIN_ALGO_NUM		0x01
#define TLITE_MAX_ALGO_NUM		0x05
#define TLITE_MIN_DEV_NUM		0x01

#define TLITE_SWITCH_MAX_DEV_NUM	FP_MAX_PORTS

#define TLITE_FA_MAX_DEV_NUM		0x03
#define TLITE_MIN_SCHED_POSITION	0x01
#define TLITE_MAX_SCHED_POSITION	0x10
#define TLITE_MIN_SHPR_NUM		0x01
#define TLITE_MAX_SHPR_NUM		0x04
#define TLITE_MIN_RATE_UNITS		0x01
#define TLITE_MAX_RATE_UNITS		0x02
#define TLITE_MIN_RATE			1
#define TLITE_MAX_RATE			2000000
#define TLITE_MIN_CLOCK_FREQ		0x001
#define TLITE_MAX_CLOCK_FREQ		267
#define TLITE_MIN_SHP_POSITON		0x01
#define TLITE_MAX_SHP_POSITON		0x21
#define TLITE_MIN_QUE_NO		0x01
//#define TLITE_MAX_QUE_NO		0x08
#define TLITE_MAX_QUE_NO		0x10
#define TLITE_MIN_IFG			0x001
#define TLITE_MAX_IFG			0x100
#define TLITE_MAX_WEIGHT		0x3FF
#define TLITE_MAX_PROB_CFG		0x100
#define TLITE_MIN_MODE			0x00
#define TLITE_MAX_MODE			0x01
#define TLITE_MIN_PCP_VALUE		0x01
#define TLITE_MAX_PCP_VALUE		0xFFFFFF
#define TLITE_MIN_TAILDROP_VALUE	0x01
#define TLITE_MAX_TAILDROP_VALUE	0x100



/*Meter defines*/
#define MIN_METER_NUMBER		0x01
#define MAX_METER_NUMBER		0x100
#define MIN_CLOCK_FREQ			0x001
#define MAX_CLOCK_FREQ			256000
#define MIN_MAX_CREDIT			0x00
#define MAX_MAX_CREDIT			0x3FFFFF
#define TLITE_METER_MIN_RATE		1
#define TLITE_METER_MAX_RATE		1000000
#define METER_WRITE_CMD			0x01
#define METER_READ_CMD			0x00
#define METER_START_BIT			0x02
#define METER_DONE_BIT			0x04

/*Queue defines*/
#define NO_MGMT				0x0
#define TLITE_QUE_TAIL_DROP		0x1
#define TLITE_QUE_WRED			0x2
#define TMU_QUE_WRED_SET		0x2
#define TLITE_SWITCH			0x01
#define TLITE_FA			0x02
#define INVALID_QUEUES			0x08080808
#define INVALID_QUEUE0			0x08
#define INVALID_QUEUE1			0x0800
#define INVALID_QUEUE2			0x080000
#define INVALID_QUEUE3			0x08000000
#define INVALID_QUEUE4			0x08
#define INVALID_QUEUE5			0x0800
#define INVALID_QUEUE6			0x080000
#define INVALID_QUEUE7			0x08000000

/*Priority numbers*/
#define SCH_SLOT_ZERO			0x0
#define SCH_SLOT_ONE			0x1
#define SCH_SLOT_TWO			0x2
#define SCH_SLOT_THREE			0x3
#define SCH_SLOT_FOUR			0x4
#define SCH_SLOT_FIVE			0x5
#define SCH_SLOT_SIX			0x6
#define SCH_SLOT_SEVEN			0x7


#define CLASSQ_CONNECTED		0x10
#define CLASSQ_NOTCONNECTED		0x20

/* Context memory registers */
#define CURQ_HEAD_TAIL_PTR		0x0
#define CURQ_PKT_CNT			0x1
#define CURQ_DROP_CNT			0x2
#define CURQ_TRANS_CNT			0x3
#define CURQ_QMAX_QMIN_CFG		0x4
#define CURQ_HW_PROB_CFG_TBL0		0x5
#define CURQ_HW_PROB_CFG_TBL1		0x6
#define CURQ_DBG			0x7
#define READ_CMD			0x00
#define WRITE_CMD			0x01
#define START_CMD			0x02
#define DONE_BIT			0x04
#define TOTAL_CONTEXT_REGS		0x08

/* device list structure */
typedef struct _tlite_dev_list_t_ {
	uint32a sched_list[TLITE_MAX_SCHED_NUM];
	uint32a shaper_list[TLITE_MAX_SHPR_NUM];
	uint32a classq_list[TLITE_MAX_QUE_NO];
} tlite_dev_list_t;

// TLITE conditional DBEUG
#ifdef TLITE_DEBUG
#define TL_DEBUG FP_DEBUG
#else
#define TL_DEBUG(type, debug_level, msg, args...) while (0) {;}
#endif


extern tlite_dev_list_t fp_tdev_list[TLITE_SWITCH_MAX_DEV_NUM];

/**********************************************************************
 * Function Name  : write_fasw_context_memory()
 * Description    : Context memory register write function Writes given value
 *                  in given address.
 * Inputs
 *   Parameters   : int , int , int , int
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void write_fasw_context_memory(uint32a data,
				uint32a que_no,
				uint32a phy_no,
				uint32a reg_no);

/**********************************************************************
 * Function Name  : read_fasw_context_memory()
 * Description    : Hardware register read function read value
 *                  from given address.
 * Inputs
 *   Parameters   : int, int, int
 * Outputs        :
 *   Parameters   : int
 *   Returns      : -
 * Changes        :
 *********************************************************************/
int32a read_fasw_context_memory(uint32a que_no,
				uint32a phy_no,
				uint32a reg_no);

/*************************************************************************
 * Function Name  : tlite_shaper_config_parameters()
 * Description    : To get shaper config parameters calculated based on
 *                : rate and frequency
 *                :
 * Inputs         :
 *   Parameters   : uint,uint,uint,uint*,uint* uint*
 * Outputs        :
 *   Parameters   : -
 *   Returns      : int
 * Changes        :
 *************************************************************************/
int32a tlite_shaper_config_parameters(uint32a rate_units,
					uint32a rate,
					uint32a clk_frequency,
					uint32a *intwt,
					uint32a *frcwt,
					uint32a *clkd);

/*************************************************************************
 * Function Name  : tlite_add_queue2scheduler()
 * Description    : Helper function for pcm_classq_add() Function
 *                :
 * Inputs         :
 *   Parameters   : tlite_classq_params_t*
 * Outputs        :
 *   Parameters   : -
 *   Returns      : int
 * Changes        :
 *************************************************************************/
int32a tlite_add_queue2scheduler(tlite_classq_params_t *que);

struct net_device;
struct ifreq;

/*************************************************************************
 * Function Name  : pfe_tlite_init()
 * Description    : Main function to intialize all parameters in tlite
 *                :
 * Inputs         :
 *   Parameters   : void
 * Outputs        :
 *   Parameters   : -
 *   Returns      : int
 * Changes        :
 *************************************************************************/

int32a pfe_tlite_init(void);

/*************************************************************************
 * Function Name  : pfe_tlite_default_config()
 * Description    : This function intialize schedulers, shapers and queues
 *                : with default configuration
 *                :
 * Inputs         :
 *   Parameters   : void
 * Outputs        :
 *   Parameters   : -
 *   Returns      : int
 * Changes        :
 *************************************************************************/
int32a pfe_tlite_default_config(void);

/*************************************************************************
 * Function Name  : pcm_tlite_config_ioctl()
 * Description    : Main function to set tlite config parameters
 *                :
 * Inputs         :
 *   Parameters   : pcm_msg_header_t
 * Outputs        :
 *   Parameters   : -
 *   Returns      : int
 * Changes        :
 *************************************************************************/
int32a pcm_tlite_config_ioctl(struct net_device *dev,struct ifreq *rq, int32a cmd);

#endif /*End of _TLITE_BLOCKS_CTRLM_H_*/
