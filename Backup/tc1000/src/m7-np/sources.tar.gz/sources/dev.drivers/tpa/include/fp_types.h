/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          fp_types.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    type defs for basic data types
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifndef _FP_TYPES_H_
#define _FP_TYPES_H_

#if 0		// NOT TO EVER BE SET TO ANYTHING OTHER THAN ZERO or FALSE

#error THESE TYPE MUST NEVER BE USED
typedef unsigned int    UINT;
typedef int             INT;
typedef unsigned int    UINT32;
typedef unsigned short  USHORT;
typedef short           SHORT;
typedef unsigned char   UCHAR;
typedef char            CHAR;
typedef unsigned long   ULONG;
typedef unsigned long long   UINT64;
typedef long long   INT64;


typedef int             int32;
typedef unsigned int    uint32;
typedef short           int16;
typedef unsigned short  uint16;
typedef signed char     int8;
typedef unsigned char   uint8;
typedef unsigned char   uchar;

#endif

typedef enum {
    TABLE_TYPE_ROUTE,
    TABLE_TYPE_BRIDGE,
    TABLE_TYPE_ANY,
} fp_table_type_t;

#endif /*End of _FP_TYPES_H_ File*/

