###################################################################################################
#
#   FileName : ruls.mk
#
#   Copyright (c) Telechips Inc.
#
#   Description :
#
#
###################################################################################################
#
#   TCC Version 1.0
#
#   This source code contains confidential information of Telechips.
#
#   Any unauthorized use without a written permission of Telechips including not limited to
#   re-distribution in source or binary form is strictly prohibited.
#
#   This source code is provided "AS IS" and nothing contained in this source code shall constitute
#   any express or implied warranty of any kind, including without limitation, any warranty of
#   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
#   or other third party intellectual property right. No warranty is made, express or implied,
#   regarding the information's accuracy,completeness, or performance.
#
#   In no event shall Telechips be liable for any claim, damages or other liability arising from,
#   out of or in connection with this source code or the use in the source code.
#
#   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
#   Telechips and Company.
#   This source code is provided "AS IS" and nothing contained in this source code shall constitute
#   any express or implied warranty of any kind, including without limitation, any warranty
#   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
#   copyright or other third party intellectual property right. No warranty is made, express or
#   implied, regarding the information's accuracy, completeness, or performance.
#   In no event shall Telechips be liable for any claim, damages or other liability arising from,
#   out of or in connection with this source code or the use in the source code.
#   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
#   between Telechips and Company.
#
###################################################################################################

SIC_BSP_DEV_DRIVERS_TPA_PATH  := $(SIC_BSP_BUILD_CURDIR)

# Flags
#(ex) COMMON_FLAGS += -D__MPU_ENABLED__
#COMMON_FLAGS += -DPLATFORM_FPGA_CM7
COMMON_FLAGS += -DPLATFORM_TCN1000_CM7
COMMON_FLAGS += -DSYNOPSYS_MAC
COMMON_FLAGS += -DTLITE
COMMON_FLAGS += -DFP_PRIMARY_DRIVER
COMMON_FLAGS += -DDISABLE_EPP_SAFETY
#COMMON_FLAGS += -DROUTE_PORT_CONFIG

# Paths
VPATH += $(SIC_BSP_DEV_DRIVERS_TPA_PATH)
VPATH += $(SIC_BSP_DEV_DRIVERS_TPA_PATH)platform/fpga_cm7
VPATH += $(SIC_BSP_DEV_DRIVERS_TPA_PATH)lib
VPATH += $(SIC_BSP_DEV_DRIVERS_TPA_PATH)hif
VPATH += $(SIC_BSP_DEV_DRIVERS_TPA_PATH)l2api
VPATH += $(SIC_BSP_DEV_DRIVERS_TPA_PATH)bridge
VPATH += $(SIC_BSP_DEV_DRIVERS_TPA_PATH)route
VPATH += $(SIC_BSP_DEV_DRIVERS_TPA_PATH)acl
VPATH += $(SIC_BSP_DEV_DRIVERS_TPA_PATH)tlite
VPATH += $(SIC_BSP_DEV_DRIVERS_TPA_PATH)cb
VPATH += $(SIC_BSP_DEV_DRIVERS_TPA_PATH)serdes
#VPATH += $(SIC_BSP_DEV_DRIVERS_TPA_PATH)$(SIC_BSP_DEV_DRIVERS_TPA_PATH)

#(ex)include $(SIC_BSP_DEV_DRIVERS_TPA_PATH )/subdir/rules.mk
include $(SIC_BSP_DEV_DRIVERS_TPA_PATH)/hardware/phy/mv88q222x/rules.mk
include $(SIC_BSP_DEV_DRIVERS_TPA_PATH)/hardware/phy/mvq3244/rules.mk

# Includes
INCLUDES += -I$(SIC_BSP_DEV_DRIVERS_TPA_PATH)
INCLUDES += -I$(SIC_BSP_DEV_DRIVERS_TPA_PATH)/config/N4900_R22P6/include
INCLUDES += -I$(SIC_BSP_DEV_DRIVERS_TPA_PATH)/config/N4900_R22P6/csr
INCLUDES += -I$(SIC_BSP_DEV_DRIVERS_TPA_PATH)/include
INCLUDES += -I$(SIC_BSP_DEV_DRIVERS_TPA_PATH)/platform/include
INCLUDES += -I$(SIC_BSP_DEV_DRIVERS_TPA_PATH)/hif
INCLUDES += -I$(SIC_BSP_DEV_DRIVERS_TPA_PATH)/acl
INCLUDES += -I$(SIC_BSP_DEV_DRIVERS_TPA_PATH)/cb
INCLUDES += -I$(SIC_BSP_DEV_DRIVERS_TPA_PATH)/route
INCLUDES += -I$(SIC_BSP_DEV_DRIVERS_TPA_PATH)/serdes
#INCLUDES += -I$(SIC_BSP_DEV_DRIVERS_TPA_PATH)$(SIC_BSP_DEV_DRIVERS_TPA_PATH)

# Sources
SRCS += fp_library.c
SRCS += platform.c
SRCS += reg_hal.c
SRCS += fp_hif_reg.c
SRCS += fp_bd_api.c
SRCS += fp_pci_bm.c
SRCS += fp_net_driver.c
SRCS += tpa_drv.c
SRCS += fp_init_fastpath.c
SRCS += hw_2field_hash_table.c
SRCS += hw_vlan_hash_table.c
SRCS += fp_switch_init.c
SRCS += fp_static_cfg.c
SRCS += fp_router_table.c
SRCS += fp_app_init.c
SRCS += fp_acl_api.c
SRCS += tlite_blocks_ctrlm.c
SRCS += fp_cb_api.c
SRCS += tpautil.c
SRCS += serdes.c
SRCS += asic.c
SRCS += tpa_csr.c

