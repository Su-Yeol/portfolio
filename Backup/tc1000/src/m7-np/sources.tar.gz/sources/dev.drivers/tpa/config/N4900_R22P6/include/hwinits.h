/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          hwinits.h
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

#ifndef _HWINITS_H_
#define _HWINITS_H_

#include "platform.h"

typedef struct hwinit_data {
   uint32a addr;
   uint32a data;
} hwinit_data_t;
hwinit_data_t sw_hwreg_data[] = {


#ifdef DISABLE_EPP_SAFETY
/* partiion 6 */
/* EPP Global CSR*/  /* TODO.Q  are these Enable?  Reset-> 0xffff -> i.e. non-zero */
{ 0xA0D000 + 0x40, 0x0 },  /* WSP_FAIL_STOP_MODE_EN:=0x0  */

/* EPP Global CSR: Emac configuration enable for fail stop mode */
{ 0xA0D000 + 0x44, 0x0 },  /* WSP_EMAC_CONFIG_EN_FAIL_STOP_MODE: = 0 */
{ 0xA0D000 + 0x48, 0x0 },  /* WSP_EMAC_REG2_CONFIG_EN_FAIL_STOP_MODE = 0 */

{ 0xA0D000 + 0x50, 0x0 },  /* WSP_FAIL_STOP_MODE_INT_EN=0 failstop ITR Enable = 0*/
{ 0xA0D000 + 0x5c, 0x0 },  /* WSP_FW_FAIL_STOP_MODE_INT_EN:= 0 */
{ 0xA0D000 + 0x60, 0x0 },  /* WSP_FAILSTOP_PEX_EN = 0 */
{ 0xA0D000 + 0x6c, 0x0 },  /* SP_HOST_FORCE_DEBUG_FAIL_STOP_MODE_INT_EN= 0 */
{ 0xA0D000 + 0x7c, 0x0 },  /* SP_ECC_ERR_INT_EN = 0*/
/* partiion 2 */
/* Partition Global CSR */
{ 0x20d004 , 0x0 },   /* WSP_FAIL_STOP_MODE_EN */
{ 0x20d008 , 0x0 },   /* WSP_EMAC_CONFIG_EN_FAIL_STOP_MODE */
{ 0x20d00c , 0x0 },   /* WSP_EMAC_REG2_CONFIG_EN_FAIL_STOP_MODE */
{ 0x20d014 , 0x0 },   /* WSP_FAIL_STOP_MODE_INT_EN */
{ 0x20d020 , 0x0 },   /* WSP_FW_FAIL_STOP_MODE_INT_EN */
{ 0x20d024 , 0x0 },   /* WSP_FAILSTOP_PEX_EN */
{ 0x20d030 , 0x0 },   /* WSP_HOST_FORCE_DEBUG_FAIL_STOP_MODE_INT_EN */
{ 0x20d068 , 0x0 },   /* WSP_ECC_ERR_INT_EN */
{ 0x20d070 , 0x0 },   /* WSP_BUS_ERR_INT_EN */
{ 0x20d078 , 0x0 },   /* WSP_PARITY_INT_EN */
{ 0x20d080 , 0x0 },   /* WSP_PARITY_REG2_INT_EN */
{ 0x20d088 , 0x0 },   /* EMAC_1G_WDT_INT_EN */
{ 0x20d090 , 0x0 },   /* EMAC_10G_WDT_INT_EN **********/
{ 0x20d098 , 0x0 },   /* EMAC_25G_WDT_INT_EN **********/
{ 0x20d0a0 , 0x0 },   /* WDT_INT_EN */
{ 0x20d0a8 , 0x0 },   /* WDT_REG2_INT_EN */
{ 0x20d0b0 , 0x0 },   /* CLASSHW_INGRS_WDT_INT_EN */
{ 0x20d0b8 , 0x0 },   /* EMAC_1G_IGQOS_WDT_INT_EN */
{ 0x20d0c0 , 0x0 },   /* EMAC_10G_IGQOS_WDT_INT_EN ***********/
{ 0x20d0c8 , 0x0 },   /* EMAC_25G_IGQOS_WDT_INT_EN  **********/
{ 0x20d0cc , 0x0 },   /* CLASSHW_E0_1G_WDT_INT_EN */
{ 0x20d0d0 , 0x0 },   /* CLASSHW_E1_1G_WDT_INT_EN ************/
{ 0x20d0d4 , 0x0 },   /* CLASSHW_E2_1G_WDT_INT_EN */
{ 0x20d0d8 , 0x0 },   /* CLASSHW_E3_1G_WDT_INT_EN */
{ 0x20d0e0 , 0x0 },   /* CLASSHW_E5_1G_WDT_INT_EN *** NB no E4 ****/
{ 0x20d0e4 , 0x0 },   /* CLASSHW_E6_1G_WDT_INT_EN */
{ 0x20d0e8 , 0x0 },   /* CLASSHW_E0_10G_WDT_INT_EN ***********/
{ 0x20d0ec , 0x0 },   /* CLASSHW_E1_10G_WDT_INT_EN ***********/
{ 0x20d0f0 , 0x0 },   /* CLASSHW_E2_10G_WDT_INT_EN ***********/
{ 0x20d0f4 , 0x0 },   /* CLASSHW_E3_10G_WDT_INT_EN ***********/
{ 0x20d0f8 , 0x0 },   /* CLASSHW_E0_25G_WDT_INT_EN ***********/
{ 0x20d0fc , 0x0 },   /* CLASSHW_E1_25G_WDT_INT_EN ***********/
{ 0x20d100 , 0x0 },   /* CLASSHW_HIF_WDT_INT_EN */
{ 0x20d104 , 0x0 },   /* CLASSHW_IPSEC_WDT_INT_EN */
{ 0x20d108 , 0x0 },   /* HGPI_WDT_INT_EN */
{ 0x20d10c , 0x0 },   /* IF_WDT_INT_EN */
{ 0x20d110 , 0x0 },   /* TLITE_REG1_WDT_INT_EN */
{ 0x20d114 , 0x0 },   /* TLITE_REG2_WDT_INT_EN */
{ 0x20d118 , 0x0 },   /* TLITE_REG3_WDT_INT_EN */
{ 0x20d11c , 0x0 },   /* TLITE_REG4_WDT_INT_EN */
{ 0x20d120 , 0x0 },   /* BMU_REG1_WDT_INT_EN */
{ 0x20d124 , 0x0 },   /* EMAC0_WDT_INT_EN ****************/
{ 0x20d128 , 0x0 },   /* EMAC1_WDT_INT_EN */
{ 0x20d12c , 0x0 },   /* EMAC2_WDT_INT_EN */
{ 0x20d130 , 0x0 },   /* EMAC3_WDT_INT_EN */
{ 0x20d134 , 0x0 },   /* EMAC4_WDT_INT_EN */
{ 0x20d138 , 0x0 },   /* EMAC5_WDT_INT_EN */
{ 0x20d13c , 0x0 },   /* EMAC6_WDT_INT_EN */
{ 0x20d140 , 0x0 },   /* EMAC0_10G_WDT_INT_EN ************/
{ 0x20d144 , 0x0 },   /* EMAC1_10G_WDT_INT_EN ***********/
{ 0x20d148 , 0x0 },   /* EMAC2_10G_WDT_INT_EN ***********/
{ 0x20d14c , 0x0 },   /* EMAC3_10G_WDT_INT_EN ***********/
{ 0x20d150 , 0x0 },   /* EMAC0_25G_WDT_INT_EN ***********/
{ 0x20d154 , 0x0 },   /* EMAC1_25G_WDT_INT_EN ***********/
{ 0x20d158 , 0x0 },   /* LMEM_WDT_INT_EN */
{ 0x20d15c , 0x0 },   /* EXT_GPT_WDT_INT_EN */
{ 0x20d34c , 0x0 },   /* IPSEC_WDT_INT_EN_REG1 */
{ 0x20d350 , 0x0 },   /* IPSEC_WDT_INT_EN_REG2 */
{ 0x20d354 , 0x0 },   /* MACSEC_WDT_INT_EN_REG1 */

#ifdef ENABLE_PARITION3
/* partiion 2 */
/* Partition Global CSR */
/* 0x40d000~40FFF */
{ 0x40d004 , 0x0 },
{ 0x40d008 , 0x0 },
{ 0x40d00c , 0x0 },
{ 0x40d014 , 0x0 },
{ 0x40d020 , 0x0 },
{ 0x40d024 , 0x0 },
{ 0x40d030 , 0x0 },
{ 0x40d068 , 0x0 },
{ 0x40d070 , 0x0 },
{ 0x40d078 , 0x0 },
{ 0x40d080 , 0x0 },
{ 0x40d088 , 0x0 },
{ 0x40d090 , 0x0 },
{ 0x40d098 , 0x0 },
{ 0x40d0a0 , 0x0 },
{ 0x40d0a8 , 0x0 },
{ 0x40d0b0 , 0x0 },
{ 0x40d0b8 , 0x0 },
{ 0x40d0c0 , 0x0 },
{ 0x40d0c8 , 0x0 },
{ 0x40d0cc , 0x0 },
{ 0x40d0d0 , 0x0 },
{ 0x40d0d4 , 0x0 },
{ 0x40d0d8 , 0x0 },
{ 0x40d0e0 , 0x0 },
{ 0x40d0e4 , 0x0 },
{ 0x40d0e8 , 0x0 },
{ 0x40d0ec , 0x0 },
{ 0x40d0f0 , 0x0 },
{ 0x40d0f4 , 0x0 },
{ 0x40d0f8 , 0x0 },
{ 0x40d0fc , 0x0 },

{ 0x40d100 , 0x0 },
{ 0x40d104 , 0x0 },
{ 0x40d108 , 0x0 },
{ 0x40d10c , 0x0 },
{ 0x40d110 , 0x0 },
{ 0x40d114 , 0x0 },
{ 0x40d118 , 0x0 },
{ 0x40d11c , 0x0 },
{ 0x40d120 , 0x0 },
{ 0x40d124 , 0x0 },
{ 0x40d128 , 0x0 },
{ 0x40d12c , 0x0 },
{ 0x40d130 , 0x0 },
{ 0x40d134 , 0x0 },
{ 0x40d138 , 0x0 },
{ 0x40d13c , 0x0 },
{ 0x40d140 , 0x0 },
{ 0x40d144 , 0x0 },
{ 0x40d148 , 0x0 },
{ 0x40d14c , 0x0 },
{ 0x40d150 , 0x0 },
{ 0x40d154 , 0x0 },
{ 0x40d158 , 0x0 },
{ 0x40d15c , 0x0 },

{ 0x40d34c , 0x0 },
{ 0x40d350 , 0x0 },
{ 0x40d354 , 0x0 },

#endif

/* partiion 4 */
{ 0x60d004 , 0x0 },
{ 0x60d008 , 0x0 },
{ 0x60d00c , 0x0 },
{ 0x60d014 , 0x0 },
{ 0x60d020 , 0x0 },
{ 0x60d024 , 0x0 },
{ 0x60d030 , 0x0 },
{ 0x60d068 , 0x0 },
{ 0x60d070 , 0x0 },
{ 0x60d078 , 0x0 },
{ 0x60d080 , 0x0 },
{ 0x60d088 , 0x0 },
{ 0x60d090 , 0x0 },
{ 0x60d098 , 0x0 },
{ 0x60d0a0 , 0x0 },
{ 0x60d0a8 , 0x0 },
{ 0x60d0b0 , 0x0 },
{ 0x60d0b8 , 0x0 },
{ 0x60d0c0 , 0x0 },
{ 0x60d0c8 , 0x0 },
{ 0x60d0cc , 0x0 },
{ 0x60d0d0 , 0x0 },
{ 0x60d0d4 , 0x0 },
{ 0x60d0d8 , 0x0 },
{ 0x60d0e0 , 0x0 },
{ 0x60d0e4 , 0x0 },
{ 0x60d0e8 , 0x0 },
{ 0x60d0ec , 0x0 },
{ 0x60d0f0 , 0x0 },
{ 0x60d0f4 , 0x0 },
{ 0x60d0f8 , 0x0 },
{ 0x60d0fc , 0x0 },
{ 0x60d100 , 0x0 },
{ 0x60d104 , 0x0 },
{ 0x60d108 , 0x0 },
{ 0x60d10c , 0x0 },
{ 0x60d110 , 0x0 },
{ 0x60d114 , 0x0 },
{ 0x60d118 , 0x0 },
{ 0x60d11c , 0x0 },
{ 0x60d120 , 0x0 },
{ 0x60d124 , 0x0 },
{ 0x60d128 , 0x0 },
{ 0x60d12c , 0x0 },
{ 0x60d130 , 0x0 },
{ 0x60d134 , 0x0 },
{ 0x60d138 , 0x0 },
{ 0x60d13c , 0x0 },
{ 0x60d140 , 0x0 },
{ 0x60d144 , 0x0 },
{ 0x60d148 , 0x0 },
{ 0x60d14c , 0x0 },
{ 0x60d150 , 0x0 },
{ 0x60d154 , 0x0 },
{ 0x60d158 , 0x0 },
{ 0x60d15c , 0x0 },
{ 0x60d34c , 0x0 },
{ 0x60d350 , 0x0 },
#endif //#def DISABLE_EPP_SAFETY



/************  Provided by EPP HW Team **************/
#if 1 //start.of EPP HWTeam HWinits
/* Partition2 */
/* BMU1 */
{ 0x0020c004, 0x3 },   /* BMU_CTRL: B0=1 (BMU Enable), B2=1 (BMU Reset--initiate soft reset of the BMU) */
{ 0x0020c020, 0x1ff }, /* BMU_INT_SRC */

/* Partition3 */
#ifdef ENABLE_PARITION3
/* BMU1 */
{ 0x0040c004, 0x3 },
{ 0x0040c020, 0x1ff },
#endif

/* Partition 4 */
/* BMU1 */
{ 0x0060c004, 0x3 },    /* BMU_CTRL */
{ 0x0060c020, 0x1ff },  /* BMU_INT_SRC */
/* BMU2  */
{ 0x0060c204, 0x3 },    /* BMU_CTRL */
{ 0x0060c220, 0x1ff },  /* BMU_INT_SRC */

/* Partition5 */
/* BMU1  */
{ 0x0080c004, 0x3 },
{ 0x0080c020, 0x1ff },
/* BMU2 */
{ 0x0080c204, 0x3 },
{ 0x0080c220, 0x1ff },


/* Partition4 */
/* HIF */
{ 0x00680004, 0x46b069e },  /* HIF_TX_POLL_CTRL */
{ 0x00680008, 0x590054 },   /* HIF_RX_POLL_CTRL */
{ 0x0068000c, 0xb4f2001f }, /* HIF_MISC */
{ 0x00680010, 0xe746a459 }, /* HIF_TIMEOUT_REG */
{ 0x006800cc, 0x3020100 },  /* HIF_RX_QUEUE_MAP_CH_NO */
{ 0x006800d4, 0x7060504 },  /* HIF_RX_QUEUE_MAP_CH_NO_REG2 */
{ 0x006800d8, 0xb0a0908 },  /* HIF_RX_QUEUE_MAP_CH_NO_REG3 */
{ 0x006800dc, 0xf0e0d0c },  /* HIF_RX_QUEUE_MAP_CH_NO_REG4 */

/*Partition 2 */
{ 0x00200aac, 0x1 },     /* EGPI1:: offset addr 0xaac not in reg doc - iscussions on going */
{ 0x00200968, 0xc200000e },
{ 0x0020096c, 0x180 },
{ 0x00200970, 0x19000000 },
{ 0x00200974, 0x11b },
{ 0x00200978, 0xffffffff },
{ 0x0020097c, 0xffff },
{ 0x00200980, 0xffffffff },
{ 0x00200984, 0xffff },
{ 0x00201aac, 0x1 },       /* EGPI2 */
{ 0x00201968, 0xc200000e },
{ 0x0020196c, 0x180 },
{ 0x00201970, 0x19000000 },
{ 0x00201974, 0x11b },
{ 0x00201978, 0xffffffff },
{ 0x0020197c, 0xffff },
{ 0x00201980, 0xffffffff },
{ 0x00201984, 0xffff },
{ 0x00202aac, 0x1 },        /* EGPI3 */
{ 0x00202968, 0xc200000e },
{ 0x0020296c, 0x180 },
{ 0x00202970, 0x19000000 },
{ 0x00202974, 0x11b },
{ 0x00202978, 0xffffffff },
{ 0x0020297c, 0xffff },
{ 0x00202980, 0xffffffff },
{ 0x00202984, 0xffff },

/* Partition 3 */
#ifdef ENABLE_PARITION3
{ 0x00400aac, 0x1 },
{ 0x00400968, 0xc200000e },
{ 0x0040096c, 0x180 },
{ 0x00400970, 0x19000000 },
{ 0x00400974, 0x11b },
{ 0x00400978, 0xffffffff },
{ 0x0040097c, 0xffff },
{ 0x00400980, 0xffffffff },
{ 0x00400984, 0xffff },
#endif


/* Partition 4 */
/* HGPI */
{ 0x00600aac, 0x1 },
{ 0x00600978, 0xffffffff },
{ 0x0060097c, 0xffff },
{ 0x00600968, 0xc200000e },
{ 0x0060096c, 0x180 },
{ 0x00600afc, 0x00011010 },

/* Partition 5 */
/* IPSEC_GPI */

#endif //end.of EPP HWTeam HWinits

#if 1
{ 0x20083c, 0x600030 },    /* EGPI1 */
{ 0x20183c, 0x600030 },    /* EGPI2 */
{ 0x20283c, 0x600030 },    /* EGPI3 */
#ifdef ENABLE_PARITION3
{ 0x40083c, 0x600030 },    /* EGPI4 */
#endif
{ 0x60083c, 0x600030 },     /* HGPI::- Ingress Classifier HW CSR?   */
                            /* 0x83c-0x400):  0x43C offset addr = GPI_INQ_PKTPTR_EXPRESS */


{ 0x200abc, 0x100},
{ 0x201abc, 0x100},
{ 0x202abc, 0x100},
#ifdef ENABLE_PARITION3
{ 0x400abc, 0x100},    /* EGPI4 */
#endif
{ 0x600abc, 0x100},   /* HGPI:: 0xabc-0x400 = 0x6bc: CLASS_PHY14_TX_PKTS: - is READ ONLY************  */
#endif



#if 0  // macsec enable
{ 0x20013c, 0x10000701},
{ 0x20113c, 0x10000701},
{ 0x20213c, 0x10000701},
#else
{ 0x20013c, 0x701},   /* EGPI1:: GPI_EMAC_1588_TIMESTAMP_EN (Reset = 0x711) */
                      /*    Bit 0: csr_emac_1588_timestamp_en   */
                      /*  (0x700: bits8,9,10) csr_emac_tx_pbl : transmit pbl  */
{ 0x20113c, 0x701},   /* EGPI2:: GPI_EMAC_1588_TIMESTAMP_EN */
{ 0x20213c, 0x701},   /* EGPI3:: GPI_EMAC_1588_TIMESTAMP_EN */
#ifdef ENABLE_PARITION3
{ 0x40013c, 0x701 },  /* EGPI4:: GPI_EMAC_1588_TIMESTAMP_EN */
#endif
#endif

{ 0x60025c, 0x0},     /* HGPI::   GPI_CSR_HIF_BMU1_BUFCNT_THRESHOLD  */


{  0 , 0 } };


#endif //#def _HWINITS_H_
