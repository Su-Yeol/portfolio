/*
 * tlite_blocks_ctrlm.c - Tlite block configuration.
 *
 * Copyright (c) 2007-2009, Naksha Technologies, Inc.
 * Copyright (c) 2010-2012, Posedge Technologies, Inc.
 * Copyright (c) 2013-2020, Imagination Technologies Ltd.
 * All rights reserved.
 */

/************************************************************************
                    Include Files
*************************************************************************/
#include "reg_hal.h"
#include "fp_library.h"
#include "fp_switch.h"
#include "fp_ioctl.h"
#include "fp_common_msg_header.h"
#include "fp_common_ctlm.h"
#include "tlite_blocks_ctrl_api.h"
#include "tlite_blocks_ctrlm.h"
//#include <wsp_vlan_hash_table_L.h>
#include "global_address_map_fpga.h"

/************************************************************************
                    GLOBAL VARIABLES
*************************************************************************/
//static uint8 *baseaddr;
static pcm_msg_header_t gpmsg;
/* added for tlite stats */
static uint32a Qposition[TLITE_SWITCH_MAX_DEV_NUM][TLITE_MAX_SCHED_NUM][TLITE_MAX_QUE_NO];

tlite_dev_list_t fp_tdev_list[TLITE_SWITCH_MAX_DEV_NUM];/* added for tlite */


static uint32a tlite_get_phy_addr(int8 phy_no)
{
	uint32a phy_addr = 0;

	switch (phy_no)
	{
		case 0:
			phy_addr = TLITE1_BASE_ADDR;
			break;
		case 1:
			phy_addr = TLITE2_BASE_ADDR;
			break;
		case 2:
			phy_addr = TLITE3_BASE_ADDR;
			break;
		case 3:
			phy_addr = TLITE4_BASE_ADDR;
			break;
		case 4:
			phy_addr = TLITE5_BASE_ADDR;
			break;
		case 5:
			phy_addr = TLITE6_BASE_ADDR;
			break;
		case 6:
			phy_addr = TLITE7_BASE_ADDR;
			break;
		case 7:
			phy_addr = TLITE8_BASE_ADDR;
			break;
		case 8:
			phy_addr = TLITE9_BASE_ADDR;
			break;
		case 9:
			phy_addr = TLITE10_BASE_ADDR;
			break;
		case 10:
			phy_addr = TLITE11_BASE_ADDR;
			break;
		default:
			break;
	}
	return phy_addr;
}


uint32a tlite_base_addr[] = {
        TLITE1_BASE_ADDR, TLITE2_BASE_ADDR, TLITE3_BASE_ADDR, TLITE4_BASE_ADDR,
        TLITE5_BASE_ADDR, TLITE6_BASE_ADDR, TLITE7_BASE_ADDR,
        TLITE8_BASE_ADDR, TLITE9_BASE_ADDR, TLITE10_BASE_ADDR,
        TLITE11_BASE_ADDR
	};

uint32a tlite_cntx_data_addr[] = {
	TMU_CNTX_DATA_ADDR, TMU2_CNTX_DATA_ADDR, TMU3_CNTX_DATA_ADDR, TMU4_CNTX_DATA_ADDR,
       	TMU5_CNTX_DATA_ADDR, TMU6_CNTX_DATA_ADDR, TMU7_CNTX_DATA_ADDR,
	TMU8_CNTX_DATA_ADDR, TMU9_CNTX_DATA_ADDR, TMU10_CNTX_DATA_ADDR,
	TMU11_CNTX_DATA_ADDR
	};

uint32a tlite_cntx_access_ctrl_addr[] = {
	TMU_CNTX_ACCESS_CTRL_ADDR, TMU2_CNTX_ACCESS_CTRL_ADDR, TMU3_CNTX_ACCESS_CTRL_ADDR,
	TMU4_CNTX_ACCESS_CTRL_ADDR, TMU5_CNTX_ACCESS_CTRL_ADDR, TMU6_CNTX_ACCESS_CTRL_ADDR,
	TMU7_CNTX_ACCESS_CTRL_ADDR, TMU8_CNTX_ACCESS_CTRL_ADDR, TMU9_CNTX_ACCESS_CTRL_ADDR,
	TMU10_CNTX_ACCESS_CTRL_ADDR,  TMU11_CNTX_ACCESS_CTRL_ADDR
	};

uint32a tlite_cntx_addr[] = {
	TMU_CNTX_ADDR_ADDR, TMU2_CNTX_ADDR_ADDR, TMU3_CNTX_ADDR_ADDR, TMU4_CNTX_ADDR_ADDR,
	TMU5_CNTX_ADDR_ADDR, TMU6_CNTX_ADDR_ADDR, TMU7_CNTX_ADDR_ADDR,
	TMU8_CNTX_ADDR_ADDR, TMU9_CNTX_ADDR_ADDR, TMU10_CNTX_ADDR_ADDR,
	TMU11_CNTX_ADDR_ADDR
	};

uint32a tlite_cntx_cmd_addr[] = {
	TMU_CNTX_CMD_ADDR, TMU2_CNTX_CMD_ADDR, TMU3_CNTX_CMD_ADDR, TMU4_CNTX_CMD_ADDR,
	TMU5_CNTX_CMD_ADDR, TMU6_CNTX_CMD_ADDR, TMU7_CNTX_CMD_ADDR,
	TMU8_CNTX_CMD_ADDR, TMU9_CNTX_CMD_ADDR, TMU10_CNTX_CMD_ADDR,
	TMU11_CNTX_CMD_ADDR
	};

uint32a tlite_tdq_ctrl_addr[] = {
	TMU_PHY0_TDQ_CTRL_ADDR, TMU2_PHY0_TDQ_CTRL_ADDR, TMU3_PHY0_TDQ_CTRL_ADDR,
	TMU4_PHY0_TDQ_CTRL_ADDR, TMU5_PHY0_TDQ_CTRL_ADDR, TMU6_PHY0_TDQ_CTRL_ADDR,
	TMU7_PHY0_TDQ_CTRL_ADDR, TMU8_PHY0_TDQ_CTRL_ADDR, TMU9_PHY0_TDQ_CTRL_ADDR,
	TMU10_PHY0_TDQ_CTRL_ADDR, TMU11_PHY0_TDQ_CTRL_ADDR
	};

uint32a tlite_tdq_iifg_cfg_addr[] = {
	TMU_PHY0_TDQ_IIFG_CFG_ADDR, TMU2_PHY0_TDQ_IIFG_CFG_ADDR, TMU_PHY3_TDQ_IIFG_CFG_ADDR,
	TMU_PHY4_TDQ_IIFG_CFG_ADDR, TMU5_PHY0_TDQ_IIFG_CFG_ADDR, TMU_PHY6_TDQ_IIFG_CFG_ADDR,
	TMU_PHY7_TDQ_IIFG_CFG_ADDR, TMU2_PHY8_TDQ_IIFG_CFG_ADDR, TMU_PHY9_TDQ_IIFG_CFG_ADDR,
	TMU_PHY10_TDQ_IIFG_CFG_ADDR
	};

static uint32a tlite_get_sched_addr(uint32a schd_addr, uint32a schd_id, uint32a phy_no)
{
	return((schd_addr & 0xFFF) + (SHED_ADDRESS_MASK * schd_id) + tlite_get_phy_addr(phy_no));
}

static uint32a tlite_get_shp_addr(uint32a shp_addr, uint32a shp_id, uint32a phy_no)
{
	return((shp_addr & 0xFFF) + (SHPR_ADDRESS_MASK * shp_id) + tlite_get_phy_addr(phy_no));
}

static uint32a tlite_get_wt_addr(int32a queue_no)
{
	switch (queue_no)
	{
		case 0:
			return TMU_SCH0_Q0_WGHT_ADDR;
		case 1:
			return TMU_SCH0_Q1_WGHT_ADDR;
		case 2:
			return TMU_SCH0_Q2_WGHT_ADDR;
		case 3:
			return TMU_SCH0_Q3_WGHT_ADDR;
		case 4:
			return TMU_SCH0_Q4_WGHT_ADDR;
		case 5:
			return TMU_SCH0_Q5_WGHT_ADDR;
		case 6:
			return TMU_SCH0_Q6_WGHT_ADDR;
		case 7:
			return TMU_SCH0_Q7_WGHT_ADDR;
		case 8:
			return TMU_SCH0_Q8_WGHT_ADDR;
		case 9:
			return TMU_SCH0_Q9_WGHT_ADDR;
		case 10:
			return TMU_SCH0_Q10_WGHT_ADDR;
		case 11:
			return TMU_SCH0_Q11_WGHT_ADDR;
		case 12:
			return TMU_SCH0_Q12_WGHT_ADDR;
		case 13:
			return TMU_SCH0_Q13_WGHT_ADDR;
		case 14:
			return TMU_SCH0_Q14_WGHT_ADDR;
		case 15:
			return TMU_SCH0_Q15_WGHT_ADDR;
		default:
			return 0;
	}
}

/**********************************************************************
 * Description	:Context memory register write function Writes given value
 *				in given address.
 *********************************************************************/
void write_fasw_context_memory(uint32a data, uint32a que_no, uint32a phy_no, uint32a reg_no)
{
	RegWrite(tlite_cntx_access_ctrl_addr[phy_no], 0);

	/* selecting register */
	RegWrite(tlite_cntx_addr[phy_no], (reg_no + que_no * TOTAL_CONTEXT_REGS));

	/* initialising the register with 0 */
	RegWrite(tlite_cntx_data_addr[phy_no], data);

	/* csr_cntx_ind_cmd -> 1 and csr_cntx_ind_start->1 */
	RegWrite(tlite_cntx_cmd_addr[phy_no], WRITE_CMD);

	RegWrite(tlite_cntx_cmd_addr[phy_no], WRITE_CMD + START_CMD);

	/* poll for csr_cntx_ind_done bit */
	while (!(RegRead(tlite_cntx_cmd_addr[phy_no]) & DONE_BIT))
		;
	/* End of while loop */
} /*End of write_fasw_context_memory() Function*/

/**********************************************************************
 * Description    : Hardware register read function read value
 *                  from given address.
 *********************************************************************/
int32a read_fasw_context_memory(uint32a que_no, uint32a phy_no, uint32a reg_no)
{
	uint32a data = 0;

	/* selecting register */
	RegWrite(tlite_cntx_addr[phy_no], (reg_no + que_no * TOTAL_CONTEXT_REGS) + (phy_no << SHIFT_BY16));
	/* csr_cntx_ind_cmd -> 0 and csr_cntx_ind_start->1 */
	RegWrite(tlite_cntx_cmd_addr[phy_no], READ_CMD);
	RegWrite(tlite_cntx_cmd_addr[phy_no], READ_CMD + START_CMD);
	/* poll for csr_cntx_ind_done bit */
	while (!(RegRead(tlite_cntx_cmd_addr[phy_no]) & DONE_BIT))
					;
	/* initialising the register with 0 */
	data = RegRead(tlite_cntx_data_addr[phy_no]);

	return data;
} /*End of read_fasw_context_memory() Function*/

static void init_tlite_context_memory(void)
{
	uint32a i;
	uint32a que_no = 0;
	uint32a reg_no = 0;

	/* context memory initialization for the phy1 of tlite */
	for (i = 0; i < FP_MAX_PORTS; i++) {
		if ((FWD_PORT_LIST_MASK >> i) & 0x1) {
			for (que_no = 0; que_no < TLITE_MAX_QUE_NO; que_no++) {
				for (reg_no = 0; reg_no < 8; reg_no++) {
					write_fasw_context_memory(0, que_no, i, reg_no);
				}
			}
		}
	}
}

/*************************************************************************
 * Description    : This function enables the dynamic configuration
 *************************************************************************/
int32a pfe_tlite_dynamic_config_enable(uint32a hw_type)
{
	uint32a i;
	uint32a phy_tdq_ctrl_addr = 0;
	uint32a read_val = 0;
	uint32a write_val = 0;

	FP_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO, "%s:\n", __func__);
	if (hw_type == TLITE_SWITCH) {
		for (i = 0; i < FP_MAX_PORTS; i++) {
			if ((FWD_PORT_LIST_MASK >> i) & 0x1) {
				phy_tdq_ctrl_addr = tlite_tdq_ctrl_addr[i];
				/*making the hw_en -> 0 */
				read_val = RegRead(phy_tdq_ctrl_addr);
				write_val = read_val & BIT1_ZERO;
				RegWrite(phy_tdq_ctrl_addr, write_val);
			}
		}
	}
	return 0;
}

/*************************************************************************
 * Description    : This function configures given scheduler in tlite module
 *************************************************************************/
int32a pcm_tlite_scheduler_config(tlite_schd_params_t *psch, uint32a hw_type)
{
	uint32a read_val = 0;

	/*Scheduler number validation*/
	if (psch->tlsd_schd_id < TLITE_MIN_SCHED_NUM || psch->tlsd_schd_id > TLITE_MAX_SCHED_NUM)
	{
		TPA_E("%s:TLITE_ERR_MSG_SCH_NUMBER %d\n", __func__, psch->tlsd_schd_id);
		return TLITE_ERR_MSG_SCH_NUMBER;
	}

	/*Scheduler Algo type validation*/
	if (psch->tlsd_algo < TLITE_MIN_ALGO_NUM || psch->tlsd_algo > TLITE_MAX_ALGO_NUM)
	{
		TPA_E("%s:TLITE_ERR_MSG_SCH_ALGO %d\n", __func__, psch->tlsd_algo);
		return TLITE_ERR_MSG_SCH_ALGO;
	}

	/*Scheduler device id validation*/
	if (hw_type == TLITE_SWITCH)
	{
		if (psch->tlsd_dev_id < TLITE_MIN_DEV_NUM || psch->tlsd_dev_id > TLITE_SWITCH_MAX_DEV_NUM)
		{
			TPA_E("%s:TLITE_ERR_MSG_SCH_DEV switch\n", __func__);
			return TLITE_ERR_MSG_SCH_DEV;
		}
	}
	else if (hw_type == TLITE_FA)
	{
		if (psch->tlsd_dev_id < TLITE_MIN_DEV_NUM || psch->tlsd_dev_id > TLITE_FA_MAX_DEV_NUM)
		{
			TPA_E("%s:TLITE_ERR_MSG_SCH_DEV fa\n", __func__);
			return TLITE_ERR_MSG_SCH_DEV;
		}
	}

	/*Set original values*/
	psch->tlsd_algo--;
	psch->tlsd_schd_id--;
	psch->tlsd_dev_id--;
	psch->tlsd_position--;
	/*checking for allw_tdq_prog-> bit 4 in PHY0_TDQ_CTRL register */
	read_val = RegRead(tlite_tdq_ctrl_addr[psch->tlsd_dev_id]);

	TPA_D("\n\n\n %s:\n", __func__);
	TPA_D("phy%d_ctrl_register:\t%x\n", psch->tlsd_dev_id, read_val);

	/* checking  for allw_tdq_prog-> 1 and hw_en -> 0 */
	if(!(((read_val & BIT4_ONE) == BIT4_ONE) && ((read_val & BIT1_ONE) == 0)))
	{
		return TLITE_ERR_HW;
	}

	/* writing algorithm type */
	RegWrite(tlite_get_sched_addr(TMU_SCH0_CTRL_ADDR, psch->tlsd_schd_id, psch->tlsd_dev_id),  psch->tlsd_algo);
	TPA_D("%s:writing algorithm type %d\n", __func__, psch->tlsd_algo);
	TPA_D("sch%d_ctrl_register:\t%x\n", psch->tlsd_schd_id, RegRead(tlite_get_sched_addr(TMU_SCH0_CTRL_ADDR, psch->tlsd_schd_id, psch->tlsd_dev_id)));

	if (psch->tlsd_schd_id == 0)
	{
		/* writing the o/p of sch0 position connection to sch1 */
		RegWrite(tlite_get_sched_addr(TMU_SCH0_POS_ADDR, psch->tlsd_schd_id, psch->tlsd_dev_id),  psch->tlsd_position);
		/*Update que weight*/
		RegWrite(tlite_get_sched_addr(tlite_get_wt_addr(psch->tlsd_position), psch->tlsd_schd_id, psch->tlsd_dev_id), psch->tlsd_weight);
		TPA_D("%s:writing sch0 position type %d\n", __func__, psch->tlsd_position);
		TPA_D("sch0_pos_register:\t%x\n", RegRead(tlite_get_sched_addr(TMU_SCH0_POS_ADDR, psch->tlsd_schd_id, psch->tlsd_dev_id)));
	}
	fp_tdev_list[psch->tlsd_dev_id].sched_list[psch->tlsd_schd_id] = 1;

	return 0;
}

/*************************************************************************
 * Description    : To get shaper config parameters calculated based on
 *                : rate and frequency
 *************************************************************************/
int32a tlite_shaper_config_parameters(uint32a rate_units,
					uint32a rate,
					uint32a clk_frequency,
					uint32a *intwt,
					uint32a *frcwt,
					uint32a *clkd)
{
	uint32a wt = 0, sysclk_khz = 0, temp = 0;
	uint32a clkdiv = 0, trydiv = 0, w_i = 0, w_f = 0;
	/*Clock division intial value*/
	clkdiv = 2;
	/*Changing Mhz to KHz*/
	sysclk_khz = clk_frequency * 1023;
	/* find the clkdiv value that gives us the largest valid wt value */
	while (clkdiv < MAX_CLKDIV) {
		trydiv = clkdiv << 1;
		/* wt = (rate * trydiv * (4096 / 8)) / (sysclk_khz) ; */
		wt = (((rate * trydiv)/sysclk_khz) * (4096 / 8));
		if (wt > MAX_WT)
			break;
		clkdiv = trydiv;
		temp++;
	}
	/* wt = (rate * clkdiv * (4096 / 8)) / (sysclk_khz); */
	wt = (((rate * clkdiv)/sysclk_khz) * (4096 / 8));
	w_i = wt >> SHIFT_BY12;
	w_f = wt & 0xfff;
	TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO, "%x:bps Shaper wt -----\n", wt);
	TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO, "%x:bps Clk div -----\n", clkdiv);
	TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO, "%x:bps temp -----\n", temp);
	/*Updating values*/
	/* *clkd = clkdiv; */
	*clkd = temp;
	*frcwt = w_f;
	*intwt = w_i;
	return 0;
}

/*************************************************************************
 * Description    : To get shaper config parameters calculated based on
 *                : rate and frequency
 *************************************************************************/
static int32a tlite_shaper_config_parameters_pps(uint32a rate_units,
					uint32a rate,
					uint32a clk_frequency,
					uint32a *intwt,
					uint32a *frcwt,
					uint32a *clkd)
{
	uint32a wt = 0, sysclk_khz = 0, temp = 0;
	uint32a clkdiv = 0, trydiv = 0, w_i = 0, w_f = 0;
	/*Clock division intial value*/
	clkdiv = 2;
	/*Changing Mhz to KHz*/
	sysclk_khz = clk_frequency * 1000;
	/* find the clkdiv value that gives us the largest valid wt value */
	while (clkdiv < MAX_CLKDIV) {
		trydiv = clkdiv << SHIFT_BY1;
		wt = (((rate * trydiv)/sysclk_khz) * (4096));
		if (wt > MAX_WT)
			break;
		clkdiv = trydiv;
		temp++;
	}
	wt = (((rate * clkdiv)/sysclk_khz) * (4096));
	w_i = wt >> SHIFT_BY12;
	w_f = wt & 0xfff;
	TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO, "%x:pps Shaper wt -----\n", wt);
	TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO, "%x:pps Clk div -----\n", clkdiv);
	TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO, "%x:pps temp -----\n", temp);
	/*Updating values*/
	/* *clkd = clkdiv; */
	*clkd = temp;
	*frcwt = w_f;
	*intwt = w_i;
	return 0;
}

/*************************************************************************
 * Description    : This function configures given shaper in tlite module
 *************************************************************************/
int32a pcm_tlite_shaper_config(tlite_shpr_params_t *pshp, uint32a hw_type, uint32a dynamic)
{
	uint32a read_val = 0;
	uint32a intwt, frc_wt, clk_div;

	/* config_info_t r_cfg; */
	TPA_D("%s:entered.............\n", __func__);
	/*Validate shaper config parameters*/
	/*Shaper number validation*/
	if(pshp->tlsp_shpr_id < TLITE_MIN_SHPR_NUM || pshp->tlsp_shpr_id > TLITE_MAX_SHPR_NUM)
	{
		TPA_E("%s:TLITE_ERR_MSG_SHP_NUMBER %d\n", __func__, pshp->tlsp_shpr_id);
		return TLITE_ERR_MSG_SHP_NUMBER;
	}

	/*Shaper device id validation*/
	if(hw_type == TLITE_SWITCH)
	{
		if(pshp->tlsp_dev_id < TLITE_MIN_DEV_NUM || pshp->tlsp_dev_id > TLITE_SWITCH_MAX_DEV_NUM)
		{
			TPA_E("%s:TLITE_ERR_MSG_SHP_DEV switch %d\n", __func__, pshp->tlsp_dev_id);
			return TLITE_ERR_MSG_SHP_DEV;
		}
	}
	else if(hw_type == TLITE_FA)
	{
		if(pshp->tlsp_dev_id < TLITE_MIN_DEV_NUM || pshp->tlsp_dev_id > TLITE_FA_MAX_DEV_NUM)
		{
			TPA_E("%s:TLITE_ERR_MSG_SHP_DEV fa %d\n", __func__, pshp->tlsp_dev_id);
			return TLITE_ERR_MSG_SHP_DEV;
		}
	}

	/*Shaper rate validation*/
	if(pshp->tlsp_rate < TLITE_MIN_RATE ||	pshp->tlsp_rate > TLITE_MAX_RATE)
	{
		TPA_E("%s:TLITE_ERR_MSG_SHP_RATE %d\n", __func__, pshp->tlsp_rate);
		return TLITE_ERR_MSG_SHP_RATE;
	}

	/*Shaper rate units validation*/
	if(pshp->tlsp_rate_units < TLITE_MIN_RATE_UNITS || pshp->tlsp_rate_units > TLITE_MAX_RATE_UNITS)
	{
		TPA_E("%s:TLITE_ERR_MSG_SHP_RATE_UNITS %d\n", __func__, pshp->tlsp_rate_units);
		return TLITE_ERR_MSG_SHP_RATE_UNITS;
	}

	/*Shaper frequency validation*/
	if(pshp->tlsp_clk_frequency < TLITE_MIN_CLOCK_FREQ || pshp->tlsp_clk_frequency > TLITE_MAX_CLOCK_FREQ)
	{
		TPA_E("%s:TLITE_ERR_MSG_SHP_CLK_FREQUENCY %d\n", __func__, pshp->tlsp_clk_frequency);
		return TLITE_ERR_MSG_SHP_CLK_FREQUENCY;
	}

	/*Shaper position validation*/
	if(pshp->tlsp_position < TLITE_MIN_SHP_POSITON || pshp->tlsp_position > TLITE_MAX_SHP_POSITON)
	{
		TPA_E("%s:TLITE_ERR_MSG_SHP_POSITION %d\n",	__func__, pshp->tlsp_position);
		return TLITE_ERR_MSG_SHP_POSITION;
	}

#if 0
	/*Shaper min credit validation*/
	if(pshp->tlsp_min_credit < MIN_MAX_CREDIT || pshp->tlsp_min_credit > MAX_MAX_CREDIT)
	{
		TPA_E("%s:TLITE_ERR_MSG_SHP_MIN_CREDIT %d\n", __func__, pshp->tlsp_min_credit);
		return TLITE_ERR_MSG_SHP_MIN_CREDIT;
	}

	/*Shaper mode validation*/
	if(pshp->tlsp_mode < TLITE_MIN_MODE || pshp->tlsp_mode > TLITE_MAX_MODE)
	{
		TPA_E("%s:TLITE_ERR_MSG_SHP_MODE %d\n", __func__, pshp->tlsp_mode);
		return TLITE_ERR_MSG_SHP_MODE;
	}
#endif

	/*Check shaper updates flag and then update rate units*/
	/*Set original values*/
	pshp->tlsp_shpr_id--;
	pshp->tlsp_dev_id--;
	pshp->tlsp_rate_units--;
	pshp->tlsp_position--;

	/*To get shpaer config parameters calculated based on rate and frequency*/
	if (pshp->tlsp_rate_units)
	{
		tlite_shaper_config_parameters_pps(pshp->tlsp_rate_units,
					pshp->tlsp_rate,
					pshp->tlsp_clk_frequency,
					&intwt, &frc_wt, &clk_div);
	}
	else
	{
		tlite_shaper_config_parameters(pshp->tlsp_rate_units,
					pshp->tlsp_rate,
					pshp->tlsp_clk_frequency,
					&intwt, &frc_wt, &clk_div);
	}

	TPA_D("intwt\t%x\n", intwt);
	/*checking for allw_tdq_prog-> bit 4 in PHY0_TDQ_CTRL register */
	read_val = RegRead(tlite_tdq_ctrl_addr[pshp->tlsp_dev_id]);

	if(!dynamic)
	{
		/* checking  for allw_tdq_prog-> 1 and hw_en -> 0 */
		if(!(((read_val & BIT4_ONE) == BIT4_ONE) && ((read_val & BIT1_ONE) == 0)))
		{
			return TLITE_ERR_HW;
		}
	}
	TPA_D("\n\n\n %s:\n", __func__);
	TPA_D("phy%d_ctrl_register:\t%x\n", pshp->tlsp_dev_id, read_val);
	/* writing clock division value in TMU_SHP0_CTRL register */
	read_val = SHPR_EN_BIT + (clk_div << SHIFT_BY1);
	TPA_D("%s:SHPR_EN_BIT + (clk_div << SHIFT_BY1) %x\n", __func__, read_val);

	RegWrite(tlite_get_shp_addr(TMU_SHP0_CTRL_ADDR, pshp->tlsp_shpr_id, pshp->tlsp_dev_id), read_val);

	TPA_D("%s:writing clockdiv value %x\n",	__func__, clk_div);
	TPA_D("shp%d_ctrl_register:%x\t%x\n", pshp->tlsp_shpr_id, tlite_get_shp_addr(TMU_SHP0_CTRL_ADDR, pshp->tlsp_shpr_id, pshp->tlsp_dev_id),
				RegRead(tlite_get_shp_addr(TMU_SHP0_CTRL_ADDR, pshp->tlsp_shpr_id, pshp->tlsp_dev_id)));

	/* writing fractional wght and int_wgt in TMU_SHP0_WGHT register */
	read_val = (frc_wt & BIT_0TO11) | ((intwt & BIT_0TO7) << SHIFT_BY12);

	RegWrite(tlite_get_shp_addr(TMU_SHP0_WGHT_ADDR, pshp->tlsp_shpr_id, pshp->tlsp_dev_id), read_val);

	TPA_D("%s:writing frac %x and int weight %x\n", __func__, frc_wt, intwt);
	TPA_D("shp%d_wght_register:\t%x\n", pshp->tlsp_shpr_id, RegRead(tlite_get_shp_addr(TMU_SHP0_WGHT_ADDR, pshp->tlsp_shpr_id, pshp->tlsp_dev_id)));

	/* writing max credit value in TMU_SHP0_MAX_CREDIT register */
	read_val = ((pshp->tlsp_max_credit) << SHIFT_BY10);
	RegWrite(tlite_get_shp_addr(TMU_SHP0_MAX_CREDIT_ADDR, pshp->tlsp_shpr_id, pshp->tlsp_dev_id), read_val);

	TPA_D("%s:max credit %x\n", __func__, pshp->tlsp_max_credit);
	TPA_D("shp%d_max_credit_register:\t%x\n", pshp->tlsp_shpr_id, RegRead(tlite_get_shp_addr(TMU_SHP0_MAX_CREDIT_ADDR,
				pshp->tlsp_shpr_id, pshp->tlsp_dev_id)));

	/* writing rate units and position in TMU_SHP0_CTRL2 register */
	read_val = ((pshp->tlsp_rate_units) | ((pshp->tlsp_position) << SHIFT_BY1)| ((pshp->tlsp_mode)<<SHIFT_BY6));
	RegWrite(tlite_get_shp_addr(TMU_SHP0_CTRL2_ADDR, pshp->tlsp_shpr_id, pshp->tlsp_dev_id), read_val);

	/* writing min credit in TMU_SHP0_MIN_CREDIT register */
	read_val = ((pshp->tlsp_min_credit));
	RegWrite(tlite_get_shp_addr(TMU_SHP0_MIN_CREDIT_ADDR, pshp->tlsp_shpr_id, pshp->tlsp_dev_id), read_val);
	TPA_D("%s:rate units %x and positon %x\n", __func__, pshp->tlsp_rate_units, pshp->tlsp_position);
	TPA_D("shp%d_ctrl2_register:\t%x\n", pshp->tlsp_shpr_id, RegRead(tlite_get_shp_addr(TMU_SHP0_CTRL2_ADDR, pshp->tlsp_shpr_id, pshp->tlsp_dev_id)));

	/*Updating the dev list structure */
	fp_tdev_list[pshp->tlsp_dev_id].shaper_list[pshp->tlsp_shpr_id] = pshp->tlsp_position + 1;

	return 0;
} /*End of pcm_tlite_shaper_config() Function*/

/*************************************************************************
 * Description    : Helper function for pcm_classq_add() Function
 *************************************************************************/
int32a tlite_add_queue2scheduler(tlite_classq_params_t *que)
{
	uint32a read_val = 0;
	uint32a read_val1 = 0, read_val2 = 0;
	/*Loop for number of schedulers*/
	/*Read Alloc0 register*/
//TODO : read TMU_SCH0_Q_ALLOC2_ADDR, TMU_SCH0_Q_ALLOC3_ADDR,
	read_val1 = RegRead(tlite_get_sched_addr(TMU_SCH0_Q_ALLOC0_ADDR, que->tlcq_schd_id, que->tlcq_dev_id));

	/*Read alloc1 register*/
	read_val2 = RegRead(tlite_get_sched_addr(TMU_SCH1_Q_ALLOC0_ADDR, que->tlcq_schd_id, que->tlcq_dev_id));

	TPA_D("%s:\n", __func__);

//TODO check tlcq_schd_slot
	/*Switch to select que priority*/
	switch(que->tlcq_schd_slot)
	{
		case SCH_SLOT_ZERO:
			/*Update alloc register with given queue number*/
			read_val1 = (read_val1 & NIBBLE0_ZERO) | (que->tlcq_classq_id & NIBBLE0_ONE);
			break;

		case SCH_SLOT_ONE:
			/*Update alloc register with given queue number*/
			read_val1 = (read_val1 & NIBBLE2_ZERO) | ((que->tlcq_classq_id & NIBBLE0_ONE) << SHIFT_BY8);
			break;

		case SCH_SLOT_TWO:
			/*Update alloc register with given queue number*/
			read_val1 = (read_val1 & NIBBLE4_ZERO) | ((que->tlcq_classq_id & NIBBLE0_ONE) << SHIFT_BY16);
			break;

		case SCH_SLOT_THREE:
			/*Update alloc register with given queue number*/
			read_val1 = (read_val1 & NIBBLE6_ZERO) | ((que->tlcq_classq_id & NIBBLE0_ONE) << SHIFT_BY24);
			break;

		case SCH_SLOT_FOUR:
			/*Update alloc register with given queue number*/
			read_val2 = (read_val2 & NIBBLE0_ZERO) | (que->tlcq_classq_id & NIBBLE0_ONE);
			break;

		case SCH_SLOT_FIVE:
			/*Update alloc register with given queue number*/
			read_val2 = (read_val2 & NIBBLE2_ZERO) | ((que->tlcq_classq_id & NIBBLE0_ONE) << SHIFT_BY8);
			break;

		case SCH_SLOT_SIX:
			/*Update alloc register with given queue number*/
			read_val2 = (read_val2 & NIBBLE4_ZERO) | ((que->tlcq_classq_id & NIBBLE0_ONE) << SHIFT_BY16);
			break;

		case SCH_SLOT_SEVEN:
			/*Update alloc register with given queue number*/
			read_val2 = (read_val2 & NIBBLE6_ZERO) | ((que->tlcq_classq_id & NIBBLE0_ONE) << SHIFT_BY24);
			break;

		default:
			TPA_E("%s:Invalid scheduler slot\n", __func__);
			break;
	} /*End of scheduler slot switch statement*/

	/*checking for allw_tdq_prog-> bit 4 in PHY0_TDQ_CTRL register */
	read_val = RegRead(tlite_tdq_ctrl_addr[que->tlcq_dev_id]);

	/* checking  for allw_tdq_prog-> 1 and hw_en -> 0 */
	if(!(((read_val & BIT4_ONE) == BIT4_ONE) && ((read_val & BIT1_ONE) == 0)))
	{
		TPA_E("TLITE_ERR_HW\n :");
		return TLITE_ERR_HW;
	}

	/*Update que weight*/
	RegWrite(tlite_get_sched_addr(tlite_get_wt_addr(que->tlcq_classq_id), que->tlcq_schd_id, que->tlcq_dev_id), que->tlcq_weight);

	TPA_D("qweight %x\n :", RegRead(tlite_get_sched_addr(tlite_get_wt_addr(que->tlcq_classq_id), que->tlcq_schd_id, que->tlcq_dev_id)));

	/*Write que number into hardware*/
	if(que->tlcq_schd_slot < SCH_SLOT_FOUR)
	{
		RegWrite(tlite_get_sched_addr(TMU_SCH0_Q_ALLOC0_ADDR, que->tlcq_schd_id, que->tlcq_dev_id), read_val1);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO, "sched slot %x\n :",
		RegRead(tlite_get_sched_addr(TMU_SCH0_Q_ALLOC0_ADDR, que->tlcq_schd_id, que->tlcq_dev_id)));
	}
	else
	{
		RegWrite(tlite_get_sched_addr(TMU_SCH0_Q_ALLOC1_ADDR, que->tlcq_schd_id, que->tlcq_dev_id), read_val2);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO, "sched slot %x\n :",
		RegRead(tlite_get_sched_addr(TMU_SCH0_Q_ALLOC1_ADDR, que->tlcq_schd_id, que->tlcq_dev_id)));
	}

	return 0;
}
/*************************************************************************
 * Description    : This function adds classq for a given scheduler
 *************************************************************************/
int32a pcm_tlite_classq_add(tlite_classq_params_t *que, uint32a hw_type)
{
	uint32a write_val = 0;

	/*Validate classq config parameters*/
	/*classq number validation*/
	if(que->tlcq_classq_id < TLITE_MIN_QUE_NO || que->tlcq_classq_id > TLITE_MAX_QUE_NO)
	{
		TPA_E("%s:TLITE_QUE_NUM_ERR %d\n", __func__, que->tlcq_classq_id);
		return TLITE_QUE_NUM_ERR;
	}

	/*classq device id validation*/
	if(hw_type == TLITE_SWITCH)
	{
		if(que->tlcq_dev_id < TLITE_MIN_DEV_NUM || que->tlcq_dev_id > TLITE_SWITCH_MAX_DEV_NUM)
		{
			TPA_E("%s:TLITE_ERR_MSG_SHP_DEV switch %d\n", __func__, que->tlcq_dev_id);
			return TLITE_ERR_MSG_SHP_DEV;
		}
	}

	/*classq scheduuler id validation*/
	if(que->tlcq_schd_id < TLITE_MIN_SCHED_NUM || que->tlcq_schd_id > TLITE_MAX_SCHED_NUM)
	{
		TPA_E("%s:TLITE_ERR_MSG_SCH_NUMBER %d\n", __func__, que->tlcq_schd_id);
		return TLITE_ERR_MSG_SCH_NUMBER;
	}

	/*classq scheduuler slot validation*/
	if(que->tlcq_schd_slot < TLITE_MIN_SCHED_POSITION || que->tlcq_schd_slot > TLITE_MAX_SCHED_POSITION)
	{
		TPA_E("%s:TLITE_ERR_MSG_SCH_SLOT %d\n", __func__, que->tlcq_schd_slot);
		return TLITE_ERR_MSG_SCH_SLOT;
	}

	/*Set all id's to original val*/
	que->tlcq_classq_id--;
	que->tlcq_dev_id--;
	que->tlcq_schd_id--;
	que->tlcq_schd_slot--;
//TODO remove switch FA macros
	if(que->tlcq_qmgmt == TLITE_QUE_TAIL_DROP)
	{
		/* writing queue managment in register */

		/* Qmax: Qmin : cfg = ([19:11],[10:2],[1:0]) */
		write_val = ((que->tlcq_max_len) << SHIFT_BY11) + que->tlcq_qmgmt;

		write_fasw_context_memory(write_val, que->tlcq_classq_id, que->tlcq_dev_id, CURQ_QMAX_QMIN_CFG);
		TPA_E("qmgmt %x\n :", read_fasw_context_memory(que->tlcq_classq_id, que->tlcq_dev_id, CURQ_QMAX_QMIN_CFG));
	/* if queue management is WRED */
	}
	else if(que->tlcq_qmgmt == TLITE_QUE_WRED)
	{
		/* writing queue managment , Qmax and Qmin values to register */

		/* Qmax: Qmin : cfg = ([19:11],[10:2],[1:0]) */
		write_val = ((que->tlcq_max_len) << SHIFT_BY11) + ((que->tlcq_min_len) << SHIFT_BY2) + que->tlcq_qmgmt;
		write_fasw_context_memory(write_val, que->tlcq_classq_id, que->tlcq_dev_id, CURQ_QMAX_QMIN_CFG);
		TPA_E("qmgmt Qmax Qmin %x = write_val %x\n ", read_fasw_context_memory(que->tlcq_classq_id, que->tlcq_dev_id, CURQ_QMAX_QMIN_CFG), write_val);

		/* writing probability values to prob_cfg registers */
		write_val = ((que->tlcq_prob_cfg5) << SHIFT_BY25) +
				((que->tlcq_prob_cfg4) << SHIFT_BY20) +
				((que->tlcq_prob_cfg3) << SHIFT_BY15) +
				((que->tlcq_prob_cfg2) << SHIFT_BY10) +
				((que->tlcq_prob_cfg1) << SHIFT_BY5) +
				que->tlcq_prob_cfg0;

		write_fasw_context_memory(write_val, que->tlcq_classq_id, que->tlcq_dev_id, CURQ_HW_PROB_CFG_TBL0);
		TPA_E("prob_cfg req %x = write_val %x\n", read_fasw_context_memory(que->tlcq_classq_id, que->tlcq_dev_id, CURQ_HW_PROB_CFG_TBL0), write_val);
		write_val = ((que->tlcq_prob_cfg7) << SHIFT_BY5) + que->tlcq_prob_cfg6;
		write_fasw_context_memory(write_val, que->tlcq_classq_id, que->tlcq_dev_id, CURQ_HW_PROB_CFG_TBL1);
		TPA_E("prob_cfg2 req %x = write_val %x\n", read_fasw_context_memory(que->tlcq_classq_id, que->tlcq_dev_id, CURQ_HW_PROB_CFG_TBL1), write_val);
	}

	/*Add queue to scheduler*/
	tlite_add_queue2scheduler(que);
	/*Updating the dev list structure */
	fp_tdev_list[que->tlcq_dev_id].classq_list[que->tlcq_classq_id] = (que->tlcq_schd_id) + 1;
	Qposition[que->tlcq_dev_id][que->tlcq_schd_id][que->tlcq_schd_slot] = que->tlcq_classq_id + 1;/* 1 to 8 */

	return 0;
} /*End of pcm_tlite_classq_add() Function*/

/*************************************************************************
 * Description    : This function deletes que number from a given scheduler
 *************************************************************************/
int32a pcm_tlite_classq_delete(	uint32a dev_id,
				uint32a qnum,
				uint32a hw_type)
{
	uint32a que_flag = 0, sch_slot = 0, i = 0;
	uint32a read_val = 0;
	uint32a read_val1 = 0, read_val2 = 0;

	(void)que_flag;
	/*Validate classq config parameters*/
	/*classq number validation*/
	if (qnum < TLITE_MIN_QUE_NO || qnum > TLITE_MAX_QUE_NO)
		return TLITE_QUE_NUM_ERR;

	/*classq device id validation*/
	if (hw_type == TLITE_SWITCH) {
		if (dev_id < TLITE_MIN_DEV_NUM ||
			dev_id > TLITE_SWITCH_MAX_DEV_NUM)
			return TLITE_ERR_MSG_SHP_DEV;
	} else if (hw_type == TLITE_FA) {
		if (dev_id < TLITE_MIN_DEV_NUM ||
				dev_id > TLITE_FA_MAX_DEV_NUM)
			return TLITE_ERR_MSG_SHP_DEV;
	}

	/*Set to original val*/
	dev_id = dev_id - 1;
	qnum = qnum - 1;

	/*Delete que from scheduler*/
	for (i = 0; i < TLITE_MAX_SCHED_NUM; i++) {
//TODO for all
		read_val1 = RegRead(
			tlite_get_sched_addr(TMU_SCH0_Q_ALLOC0_ADDR, i, dev_id));
		read_val2 = RegRead(
			tlite_get_sched_addr(TMU_SCH1_Q_ALLOC0_ADDR, i, dev_id));


		/*Que search in scheduler alloc registers*/
		if ((read_val1 & NIBBLE0_ONE) == qnum)
			sch_slot = SCH_SLOT_ZERO;
		else if (((read_val1 >> SHIFT_BY8) & NIBBLE0_ONE) == qnum)
			sch_slot = SCH_SLOT_ONE;
		else if (((read_val1 >> SHIFT_BY16) & NIBBLE0_ONE) == qnum)
			sch_slot = SCH_SLOT_TWO;
		else if (((read_val1 >> SHIFT_BY24) & NIBBLE0_ONE) == qnum)
			sch_slot = SCH_SLOT_THREE;
		else if ((read_val2 & NIBBLE0_ONE) == qnum)
			sch_slot = SCH_SLOT_FOUR;
		else if (((read_val2 >> SHIFT_BY8) & NIBBLE0_ONE) == qnum)
			sch_slot = SCH_SLOT_FIVE;
		else if (((read_val2 >> SHIFT_BY16) & NIBBLE0_ONE) == qnum)
			sch_slot = SCH_SLOT_SIX;
		else if (((read_val2 >> SHIFT_BY24) & NIBBLE0_ONE) == qnum)
			sch_slot = SCH_SLOT_SEVEN;
		else
			sch_slot = -1;
		/*Find scheduler slot*/
		/*Delete scheduler slot que*/
		switch (sch_slot) {
		case SCH_SLOT_ZERO:
			read_val1 = (read_val1 & NIBBLE0_ZERO) + INVALID_QUEUE0;
				que_flag = 1;
		break;

		case SCH_SLOT_ONE:
			read_val1 = (read_val1 & NIBBLE2_ZERO) + INVALID_QUEUE1;
			que_flag = 1;
		break;

		case SCH_SLOT_TWO:
			read_val1 = (read_val1 & NIBBLE4_ZERO) + INVALID_QUEUE2;
			que_flag = 1;
		break;

		case SCH_SLOT_THREE:
			read_val1 = (read_val1 & NIBBLE6_ZERO) + INVALID_QUEUE3;
			que_flag = 1;
		break;

		case SCH_SLOT_FOUR:
			read_val2 = (read_val2 & NIBBLE0_ZERO) + INVALID_QUEUE4;
			que_flag = 1;
		break;

		case SCH_SLOT_FIVE:
			read_val2 = (read_val2 & NIBBLE2_ZERO) + INVALID_QUEUE5;
			que_flag = 1;
		break;

		case SCH_SLOT_SIX:
			read_val2 = (read_val2 & NIBBLE4_ZERO) + INVALID_QUEUE6;
			que_flag = 1;
		break;

		case SCH_SLOT_SEVEN:
			read_val2 = (read_val2 & NIBBLE6_ZERO) + INVALID_QUEUE7;
			que_flag = 1;
		break;

		default:
			que_flag = 0;
			TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"%s:Invalid sch_slot[%d]\n", __func__, que_flag);
		break;
		} /*End of scheduler slot switch statement*/
		/*checking for allw_tdq_prog-> bit 4 in PHY0_TDQ_CTRL register*/
		read_val = RegRead(tlite_tdq_ctrl_addr[dev_id]);

		/* checking  for allw_tdq_prog-> 1 and shp_cntrl_en -> 0 */
		if (!(((read_val & BIT4_ONE) == BIT4_ONE) &&
					((read_val & BIT1_ONE) == 0)))
			return TLITE_ERR_HW;
		/*Check slot to selct alloc0 or alloc1*/
		if (sch_slot < SCH_SLOT_FOUR)
			/*Write Alloc0 register*/
			RegWrite(
			tlite_get_sched_addr(TMU_SCH0_Q_ALLOC0_ADDR, i, dev_id), read_val1);
		else
			/*Write Alloc1 register*/
			RegWrite(
			tlite_get_sched_addr(TMU_SCH0_Q_ALLOC1_ADDR, i, dev_id), read_val2);

		/*Updating the dev list structure */
		fp_tdev_list[dev_id].classq_list[qnum] = 0;
	} /*Scheduler loop*/
	return 0;
} /*End of pcm_tmu_classq_delete() Function*/

/*************************************************************************
 * Description    : This function set inter frame gap value of given device
 *************************************************************************/
int32a pfe_tlite_set_ifg(	uint32a dev_id,
			uint32a ifg,
			uint32a hw_type)
{
	uint32a r_ifg = 0;
	uint32a read_val = 0;

	/*dev_id  validation*/
	if (hw_type == TLITE_SWITCH) {
		if (dev_id < TLITE_MIN_DEV_NUM ||
			dev_id > TLITE_SWITCH_MAX_DEV_NUM)
			return TLITE_ERR_MSG_DEV_NUM;
	} else if (hw_type == TLITE_FA) {
		if (dev_id < TLITE_MIN_DEV_NUM ||
			dev_id > TLITE_FA_MAX_DEV_NUM)
			return TLITE_ERR_MSG_DEV_NUM;
	}
	/* ifg validation*/
	if (ifg < TLITE_MIN_IFG || ifg > TLITE_MAX_IFG)
		return TLITE_ERR_MSG_IFG;
	dev_id--;
	/*Writing ifg value in tdq global register */
	r_ifg = ifg & 0xFF;
	/*checking for allw_tdq_prog-> bit 4 in PHY0_TDQ_CTRL register */
	read_val = RegRead(tlite_tdq_ctrl_addr[dev_id]);

	/* checking  for allw_tdq_prog-> 1 and shp_cntrl_en -> 0 */
	if (!(((read_val & BIT4_ONE) == BIT4_ONE) &&
				((read_val & BIT1_ONE) == 0)))
		return TLITE_ERR_HW;


	RegWrite(tlite_tdq_iifg_cfg_addr[dev_id], r_ifg);
	TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
		"%s:Set ifg config done\n", __func__);
	return 0;
} /*End of pfe_tlite_set_ifg() Function*/


/*************************************************************************
 * Description    : To get meter config parameters calculated based on
 *                : rate and frequency
 *************************************************************************/
static int32a tlite_meter_config_parameters(uint32a rate,
					uint32a clk_frequency,
					uint32a rate_units,
					uint32a *intwt,
					uint32a *frcwt)
{
	uint32a   wt = 0;
	uint32a   sysclk_hz = 0, clkdiv = 0;
	uint32a   w_i = 0, w_f = 0;
	/*Clock division intial value*/
	clkdiv = 64;
	/*Changing khz to Hz*/
	/* sysclk_hz = clk_frequency * 1000; */
	sysclk_hz = clk_frequency;
	if (rate_units)/* packets per second */
		wt = (rate * 65536 * clkdiv)/(sysclk_hz);
	else
		wt = (rate * 8192 * clkdiv)/(sysclk_hz);
		/* wt =(rate *8192 * clkdiv)/sysclk_hz; */
	TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO, "wt\t%d\n", wt);
	w_i = (wt >> SHIFT_BY16);
	w_f = wt & 0xffff;
	/*Updating values*/
	*frcwt = w_f;
	*intwt = w_i;
	return 0;
}

/*************************************************************************
 * Description    : This function configures given shaper in tlite module
 *************************************************************************/
int32a pcm_tlite_fasw_meter_config(tlite_meter_params_t *pmtr)
{
	uint32a intwt, frc_wt;
	uint32a write_val = 0, read_val = 0;
	/*Validate meter config parameters*/
	/*Meter number validation*/
	if (pmtr->tlmt_meter_no < MIN_METER_NUMBER ||
			pmtr->tlmt_meter_no > MAX_METER_NUMBER)
		return TLITE_ERR_MSG_MTR_NUMBER;
	/*meter clock frequency validation*/
	if (pmtr->tlmt_clock_freq < MIN_CLOCK_FREQ ||
			pmtr->tlmt_clock_freq > MAX_CLOCK_FREQ)
		return TLITE_ERR_MSG_MTR_CLK_FREQ;
#if 0
	/*meter max credit validation*/
	if (pmtr->tlmt_max_credit < MIN_MAX_CREDIT  ||
			MAX_MAX_CREDIT < pmtr->tlmt_max_credit)
		return TLITE_ERR_MSG_MTR_MAX_CRDT;
#endif
	/*meter enable validation*/
	if (pmtr->tlmt_enable < 1  || pmtr->tlmt_enable > 2)
		return TLITE_ERR_MSG_MTR_ENABLE;
	/*meter ifg add validation*/
	if (pmtr->tlmt_ifg_add < 1  || pmtr->tlmt_ifg_add > 2)
		return TLITE_ERR_MSG_MTR_IFG_ADD;
	/*meter rate units validation*/
	if (pmtr->tlmt_rate_units < 1  || pmtr->tlmt_rate_units > 2)
		return TLITE_ERR_MSG_MTR_RATE_UNITS;
	/*meter clear validation*/
	if (pmtr->tlmt_clear < 1  || pmtr->tlmt_clear > 2)
		return TLITE_ERR_MSG_MTR_CLEAR;
	/*meter rate validation*/
	if (pmtr->tlmt_rate < TLITE_METER_MIN_RATE  ||
			pmtr->tlmt_rate > TLITE_METER_MAX_RATE)
		return TLITE_ERR_MSG_MTR_RATE;
	/*Set original values*/
	pmtr->tlmt_meter_no = pmtr->tlmt_meter_no - 1;
	pmtr->tlmt_enable = pmtr->tlmt_enable - 1;
	pmtr->tlmt_ifg_add = pmtr->tlmt_ifg_add - 1;
	pmtr->tlmt_rate_units = pmtr->tlmt_rate_units - 1;
	pmtr->tlmt_clear = pmtr->tlmt_clear - 1;
	/*To get meter config parameters calculted based on rate and frequency*/
	/*tlite_meter_config_parameters(pmtr->tlmt_rate,
		pmtr->tlmt_clock_freq, pmtr->tlmt_rate_units, &intwt,&frc_wt);*/
	intwt = ((pmtr->tlmt_wt) >> SHIFT_BY16);
	frc_wt = (pmtr->tlmt_wt) & BIT_0TO15;
	/*Programming meter number and clear old credits bit */
	read_val = RegRead((uint32)(TMU_METER_ADDR_ADDR));
	write_val = (pmtr->tlmt_meter_no & BIT_0TO7) +
			(pmtr->tlmt_clear << SHIFT_BY9) + (read_val & BIT8);
	TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"write_val for meter no\t %d\n", write_val);
	RegWrite(TMU_METER_ADDR_ADDR, write_val);
	TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO, "TLITE_METER_ADDR\t%d\n",
			RegRead(TMU_METER_ADDR_ADDR));

	/* writing fractional wght */
	write_val = frc_wt & BIT_0TO15;
	RegWrite(TMU_METER_CFG0_ADDR, write_val);
	FP_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO, "intwt\t%d\n", intwt);
	FP_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO, "frc_wt\t%d\n", frc_wt);
	/* writing max credit , integer wgt, meter_disable ,
				meter IFG no add and pkt rate */
	write_val = ((pmtr->tlmt_max_credit & BIT_0TO21) << SHIFT_BY7) +
			(intwt & BIT_0TO6) +
			((pmtr->tlmt_enable & BIT0) << SHIFT_BY29) +
			((pmtr->tlmt_ifg_add & BIT0) << SHIFT_BY30) +
			((pmtr->tlmt_rate_units & BIT0) << SHIFT_BY31);
	RegWrite(TMU_METER_CFG1_ADDR, write_val);

	/* csr_mtr_cmd-> 1 and csr_mtr_start ->1 */
	write_val = METER_WRITE_CMD;
	RegWrite(TMU_METER_CMD_ADDR, write_val);
	write_val = METER_WRITE_CMD + METER_START_BIT;
	RegWrite(TMU_METER_CMD_ADDR, write_val);

	/* poll for csr_mtr_done bit */
	while (!(RegRead(TMU_METER_CMD_ADDR) & METER_DONE_BIT))
		; /* End of while loop */
	return 0;
} /* End of pcm_tlite_fasw_meter_config function */

/*************************************************************************
 * Description    : This function enable or disable all meters in tlite module
 *************************************************************************/
int32a pfe_tlite_fasw_meter_enable(uint32a enable)
{
	uint32a read_val = 0, write_val = 0;
	/*Validate meter enable parameters*/
	/*enable validation*/
	if (enable < 1 || enable > 2)
		return TLITE_ERR_MSG_MTR_ENABLE;
	/*Set original values*/
	enable--;
	/* writing enable */
	read_val = RegRead(TMU_METER_ADDR_ADDR);
	if (enable)
		write_val = (enable << SHIFT_BY8) | read_val;
	else
		write_val = (read_val & 0x2FF);
	RegWrite(TMU_METER_ADDR_ADDR, write_val);


	/* csr_mtr_cmd-> 1 and csr_mtr_start ->1 */
	write_val = METER_WRITE_CMD;
	RegWrite(TMU_METER_CMD_ADDR, write_val);
	write_val = METER_WRITE_CMD + METER_START_BIT;
	RegWrite(TMU_METER_CMD_ADDR, write_val);

	/* poll for csr_mtr_done bit */
	while (!(RegRead(TMU_METER_CMD_ADDR) & METER_DONE_BIT))
		; /* End of while loop */
	return 0;
}

/*************************************************************************
 * Description    : This function set intialization done, so that hardware
 *                : will start to process
 *************************************************************************/
int32a pfe_tlite_dynamic_config_done()
{
	int32a phy_no = 0;
	for (phy_no = 0; phy_no < TLITE_SWITCH_MAX_DEV_NUM; phy_no++)
	/* HW enable for the tdq fsm */
	RegWrite(tlite_tdq_ctrl_addr[phy_no], TLITE_HW_EN);
	return 0;
}

/*************************************************************************
 * Description    : This function reads the transmit packet count and current
 *                : queue drop count send to user side
 *************************************************************************/

pcm_msg_header_t *pfe_tlite_que_stats(uint32a dev_id,
					uint32a que_number,
					uint32a hw_type)
{
	uint32a read_val = 0, read_val2 = 0, read_val3 = 0;
	/*Validate config parameters*/
	/*classq number validation*/
	if (que_number < TLITE_MIN_QUE_NO || que_number > TLITE_MAX_QUE_NO) {
		gpmsg.pcmh_flags = TLITE_QUE_NUM_ERR;
		return (pcm_msg_header_t *)&gpmsg;
	}
	/*classq device id validation*/
	if (hw_type == TLITE_SWITCH) {
		if (dev_id < TLITE_MIN_DEV_NUM ||
				dev_id > TLITE_SWITCH_MAX_DEV_NUM) {
			gpmsg.pcmh_flags = TLITE_ERR_MSG_SHP_DEV;
			return (pcm_msg_header_t *)&gpmsg;
		}
	} else if (hw_type == TLITE_FA) {
		if (dev_id < TLITE_MIN_DEV_NUM ||
				dev_id > TLITE_FA_MAX_DEV_NUM) {
			gpmsg.pcmh_flags = TLITE_ERR_MSG_SHP_DEV;
			return (pcm_msg_header_t *)&gpmsg;
		}
	}
	dev_id--;
	que_number--;
	/*xmit packet count*/
	read_val = read_fasw_context_memory(que_number, dev_id, CURQ_TRANS_CNT);
	/*Read current que dropcount*/
	read_val2 = read_fasw_context_memory(que_number, dev_id, CURQ_DROP_CNT);
	/*Read pkt count */
	read_val3 = read_fasw_context_memory(que_number, dev_id, CURQ_PKT_CNT);
	/*Reset message header */
	SAL_MemSet(&gpmsg, 0, sizeof(pcm_msg_header_t));
	/*Read pkt count*/
	gpmsg.pcmh_flags = read_val3;
	/*Update tx packet count*/
	gpmsg.pcmh_length = read_val;
	/*Message header value contrains given que number dropcount*/
	gpmsg.pcmh_value = read_val2;
	return (pcm_msg_header_t *)&gpmsg;
}

/*************************************************************************
 * Description    : This function reads the inq write pointer,
 *                : inq read pointer and fifo count send to user side
 *************************************************************************/
pcm_msg_header_t *pfe_tlite_inq_stats()
{
	uint32a read_val = 0;
//TODO check address of TLITE_PHY_INQ_STAT_ADDR, commmenting for now
	/*Read inq stats register*/
	//read_val = RegRead((uint32)(TLITE_PHY_INQ_STAT_ADDR));

	/*Reset message header */
	SAL_MemSet(&gpmsg, 0, sizeof(pcm_msg_header_t));
	/*Message header flags contains inq write pointer*/
	gpmsg.pcmh_flags = read_val & BIT_0TO7;
	/*Message header length contains inq read pointer*/
	gpmsg.pcmh_length = (read_val >> SHIFT_BY8) & BIT_0TO7;
	/*Message header vlaue contains fifo count*/
	gpmsg.pcmh_value = (read_val >> SHIFT_BY16) & BIT_0TO15;
	return (pcm_msg_header_t *)&gpmsg;
}

/*************************************************************************
 * Description    : This function reads the configured schedulers
 *                : and send to user
 *************************************************************************/
uint32a *pfe_tlite_sch_list(uint32a dev_id)
{
	uint32a *iptr;
	tlite_dev_list_t *pdev_list;
	pdev_list = &fp_tdev_list[dev_id];
	iptr = pdev_list->sched_list;
	return iptr;
}

/*************************************************************************
 * Description    : This function reads the configured shapers
 *                : and send to user
 *************************************************************************/
uint32a *pfe_tlite_shp_list(uint32a dev_id)
{
	uint32a *iptr;
	tlite_dev_list_t *pdev_list;

	pdev_list = &fp_tdev_list[dev_id];
	iptr = pdev_list->shaper_list;
	return iptr;
}

/*************************************************************************
 * Description    : This function reads the configured queue
 *                : and send to user
 *************************************************************************/
uint32a *pfe_tlite_classq_list(uint32a dev_id)
{
	uint32a *iptr;
	tlite_dev_list_t *pdev_list;
	pdev_list = &fp_tdev_list[dev_id];
	iptr = pdev_list->classq_list;
	return iptr;
}

/*************************************************************************
 * Description    : This function reads the configured queue
 *                : and send to user
 *************************************************************************/
uint32a *pfe_tlite_classq_per_sched_list(uint32a dev_id)
{
	uint32a *iptr;
	tlite_dev_list_t *pdev_list;
	pdev_list = &fp_tdev_list[dev_id];
	iptr = pdev_list->classq_list;
	return iptr;
}

/*************************************************************************
 * Description    : Main function to intialize all parameters in tlite
 *************************************************************************/


int32a pfe_tlite_init(void)
{
	uint32a i = 0;
	uint32a que_no = 0;
	uint32a reg_no = 0;
	uint32a shp_no = 0;

	TPA_D("Entered in function pfe_tlite_init\n");
	SAL_MemSet(fp_tdev_list, 0, TLITE_SWITCH_MAX_DEV_NUM * sizeof(tlite_dev_list_t));
	SAL_MemSet(Qposition, 0, TLITE_SWITCH_MAX_DEV_NUM *	TLITE_MAX_SCHED_NUM * TLITE_MAX_QUE_NO * sizeof(uint32a));

	TPA_D("Entered in function pfe_tlite_init after regwrite\n");

	/* making the default shapers as invalid */
	for (i = 0; i < FP_MAX_PORTS; i++) {
		if ((FWD_PORT_LIST_MASK >> i) & 0x1) {
			for (shp_no = 0; shp_no < TLITE_MAX_SHPR_NUM; shp_no++) {
				RegWrite(tlite_get_shp_addr(TMU_SHP0_CTRL2_ADDR, shp_no, i), 0x22);
			}
		}
	}

	/* context memory initialization for  tlite */
	for (i = 0; i < FP_MAX_PORTS; i++) {
		if ((FWD_PORT_LIST_MASK >> i) & 0x1) {
			for (que_no = 0; que_no < TLITE_MAX_QUE_NO; que_no++) {
				for (reg_no = 0; reg_no < 8; reg_no++) {
					write_fasw_context_memory(0, que_no, i, reg_no);
				}
			}
		}
	}
	return 0;
} /*End of pfe_tlite_init() Function*/

/*************************************************************************
 * Description    : This function intialize schedulers, shapers and queues
 *                : with default configuration
 *************************************************************************/
int32a pfe_tlite_default_config(void)
{
	uint32a i = 0;
	uint32a j = 0;
	uint32a read_val = 0;
//	uint32a ret_val = 0;
	uint32a write_val = 0;
	tlite_schd_params_t tsch;
	tlite_shpr_params_t tshp;
	tlite_classq_params_t tque;

	SAL_MemSet(&tsch, 0, sizeof(tlite_schd_params_t));
	SAL_MemSet(&tshp, 0, sizeof(tlite_shpr_params_t));
	SAL_MemSet(&tque, 0, sizeof(tlite_classq_params_t));

	for (i = 0; i < FP_MAX_PORTS; i++) {
		if ((FWD_PORT_LIST_MASK >> i) & 0x1) {
			/*making the hw_en -> 0 */
			read_val = RegRead(tlite_tdq_ctrl_addr[i]);
			TPA_D("TLITE_PHY%d_TDQ_CTRL_ADDR1:\t%x\n", i, read_val);
			write_val = read_val & BIT1_ZERO;
			TPA_D("TLITE_PHY%d_TDQ_CTRL_ADDR2:\t%x\n", i, write_val);
			RegWrite(tlite_tdq_ctrl_addr[i], write_val);
			TPA_D("TLITE_PHY%d_TDQ_CTRL_ADDR3:\t%x\n", i, ((RegRead(tlite_tdq_ctrl_addr[i])) & BIT4_ONE));

			/* polling for allw_tdq_prog-> 1 */
			while (!((RegRead(tlite_tdq_ctrl_addr[i]) & BIT4_ONE) == BIT4_ONE))
				; /* End of while loop */
			TPA_D("TLITE_PHY%d_TDQ_CTRL_ADDR4:\t%x\n", i, (RegRead(tlite_tdq_ctrl_addr[i]) & BIT4_ONE));
		}
	}

	/*Scheduler config*/
	for (i = 0; i < FP_MAX_PORTS; i++) {
		if ((FWD_PORT_LIST_MASK >> i) & 0x1) {
			for (j = 0; j < TLITE_MAX_SCHED_NUM; j++) {
				if (j == 0) {
					tsch.tlsd_position = 1;
					tsch.tlsd_algo = 4; /* Round Robbin */
				} else {
					tsch.tlsd_algo = 1; /* priority queuing */
				}
				tsch.tlsd_dev_id = i + 1;
				tsch.tlsd_schd_id = j + 1;
				pcm_tlite_scheduler_config(&tsch, TLITE_SWITCH);
			}
		}
	}

#ifdef TLITE_SHAPER_EN
// System clock frequency in MHz
#define CLOCK_FREQUENCY 10
// Required reate in kbps
#define SHP_REQ_RATE 10000

	/*Shaper config*/
	for (i = 0; i < FP_MAX_PORTS; i++) {
		if ((FWD_PORT_LIST_MASK >> i) & 0x1) {
			for (j = 0; j < TLITE_MAX_SHPR_NUM; j++) {
				tshp.tlsp_max_credit = 0x3FFE00;
				tshp.tlsp_rate_units = 1;

				tshp.tlsp_clk_frequency  = CLOCK_FREQUENCY;
				tshp.tlsp_rate  = SHP_REQ_RATE;
				tshp.tlsp_dev_id = i + 1;
				tshp.tlsp_shpr_id = j + 1;

				/* shaper is attached at the output of the second scheduler */
				if (j == 2)
				{
					tshp.tlsp_mode = 0x1; /*0x1-credit based mode */
					tshp.tlsp_position = 0x1;
				}
				else
				{
					continue;
				}

				if (tshp.tlsp_mode == 0)
				{
					tshp.tlsp_min_credit = (tshp.tlsp_max_credit);
				}
				else
				{
					tshp.tlsp_min_credit = tshp.tlsp_max_credit;
				}

				pcm_tlite_shaper_config(&tshp, TLITE_SWITCH, 0);
			}
		}
	}
#endif

	/* queues adding*/
	for (i = 0; i < FP_MAX_PORTS; i++) {
		if ((FWD_PORT_LIST_MASK >> i) & 0x1) {
			for (j = 0; j < TLITE_MAX_QUE_NO; j++) {
				tque.tlcq_qmgmt =  TLITE_QUE_TAIL_DROP;
				tque.tlcq_max_len = 100;
				tque.tlcq_weight = 0x500;
				tque.tlcq_qmgmt = 0;
				tque.tlcq_dev_id = i + 1;
				tque.tlcq_classq_id = j + 1;
				tque.tlcq_schd_id = 1;
				tque.tlcq_schd_slot = j + 1;

				if (j == 0)
				{
					tque.tlcq_weight = 0x450;
				}

				if (j == 1)
				{
					tque.tlcq_weight = 0x460;
				}

				if (j == 2)
				{
					tque.tlcq_weight = 0x470;
				}
				else
				{
					tque.tlcq_weight = 0x500;
				}

				pcm_tlite_classq_add(&tque, TLITE_SWITCH);
			}
		}
	}

	for (i = 0; i < FP_MAX_PORTS; i++) {
		if ((FWD_PORT_LIST_MASK >> i) & 0x1) {
			/* HW enable for the tdq fsm */
			RegWrite(tlite_tdq_ctrl_addr[i], TLITE_HW_EN);
		}
	}

	return 0;
} /*End of pfe_tlite_default_config() Function*/

/*************************************************************************
 * Description    : This function configures credit mode shapers for
 *                  given device
 *                :
 *************************************************************************/
int32a pcm_tlite_creditmode_shaper_config(tlite_creditmode_params_t *ptdp)
{
	uint32a i = 0;
	uint32a j = 0;
	uint32a k = 0;
	uint32a ret_val = 0;
	tlite_shpr_params_t tshp;

	SAL_MemSet(&tshp, 0, sizeof(tlite_shpr_params_t));
	pfe_tlite_dynamic_config_enable(1);
	TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO, "%s:\n", __func__);
	/*Shaper config*/
	for (i = 0; i < FP_MAX_PORTS; i++) {
		if ((FWD_PORT_LIST_MASK >> i) & 0x1) {
			for (j = 0; j < TLITE_MAX_SCHED_NUM; j++) {
				for (k = 0; k < TLITE_MAX_QUE_NO; k++) {
					if (Qposition[i][j][k] ==
						ptdp->tld_traffic_class) {
						/* 2 to 17 */
						tshp.tlsp_position =
						k + ((1 - j) * 8) + 1 + 1;
					}
				}
			}
		}
	}
	tshp.tlsp_rate  = ptdp->tld_idle_slope;
	tshp.tlsp_dev_id = ptdp->tld_port_no;
	tshp.tlsp_shpr_id = ptdp->tld_shaper_id;
	tshp.tlsp_max_credit = 0x3FFE00;
	tshp.tlsp_min_credit = 0x3FFE00;
	tshp.tlsp_mode = 0x1;
	tshp.tlsp_rate_units = 1;
	tshp.tlsp_clk_frequency  = 39;
	ret_val = pcm_tlite_shaper_config(&tshp, TLITE_SWITCH, 0);
	pfe_tlite_dynamic_config_done();
	return ret_val;

} /*End of pcm_tlite_creditmode_shaper_config Function*/

/*************************************************************************
* Description    : This function set regenerate  pcp for
*                  given divice
*                :
*************************************************************************/
//TODO
static void pfe_tlite_set_regenerate_pcp(uint32a devId, uint32a pcp_value)
{
	//RegWrite((uint32)(CLASS_PORT0_STRUC3
	//			 + (REG_LEN * devId)), pcp_value);
	return;
}

/*************************************************************************
* Description    : This function set regenerate  pcp for
*                  given divice
*                :
*************************************************************************/
static uint32a pfe_tlite_get_regenerate_pcp(uint32a devId)
{
	uint32a read_val = 0;
	//read_val = RegRead(
	//	(uint32)(CLASS_PORT0_STRUC3 + (REG_LEN * devId)));
	return read_val;
}
/*************************************************************************
 * Description    : This function enables taildrop
 *************************************************************************/
static int32a pfe_tlite_taildrop_enable(	uint32a dev_id,
				uint32a que_no,
				uint32a value)
{
	uint32a write_val = 0;
	/*dev_id  validation*/
	if (dev_id < TLITE_MIN_DEV_NUM || dev_id > TLITE_SWITCH_MAX_DEV_NUM)
		return TLITE_ERR_MSG_DEV_NUM;
	/*classq number validation*/
	if (que_no < TLITE_MIN_QUE_NO || que_no > TLITE_MAX_QUE_NO)
		return TLITE_QUE_NUM_ERR;
	/* queue validation*/
	if (value < TLITE_MIN_TAILDROP_VALUE ||
			value > TLITE_MAX_TAILDROP_VALUE)
		return TLITE_ERR_MSG_TAILDROP_VALUE;
	dev_id--;
	que_no--;
	value--;
	write_val =  (value << 11) | 0x1;
	write_fasw_context_memory(write_val, que_no, dev_id,
						CURQ_QMAX_QMIN_CFG);
	return 0;
} /*End of pfe_tlite_taildrop_enable() Function*/

/*************************************************************************
 * Description    : This function disables taildrop
 *************************************************************************/
static int32a pfe_tlite_taildrop_disable(uint32a dev_id, uint32a que_no)
{
	/*dev_id  validation*/
	if (dev_id < TLITE_MIN_DEV_NUM || dev_id > TLITE_SWITCH_MAX_DEV_NUM)
		return TLITE_ERR_MSG_DEV_NUM;
	/*classq number validation*/
	if (que_no < TLITE_MIN_QUE_NO || que_no > TLITE_MAX_QUE_NO)
		return TLITE_QUE_NUM_ERR;
	dev_id--;
	que_no--;
	write_fasw_context_memory(0x00, que_no, dev_id, CURQ_QMAX_QMIN_CFG);
	return 0;
} /*End of pfe_tlite_taildrop_disable() Function*/


/*************************************************************************
 * Description    : This function get taildrop value
 *************************************************************************/
static int32a pfe_tlite_get_taildrop_value(uint32a dev_id, uint32a que_no)
{
	uint32a read_val = 0;

	/*dev_id  validation*/
	if (dev_id < TLITE_MIN_DEV_NUM || dev_id > TLITE_SWITCH_MAX_DEV_NUM)
		return TLITE_ERR_MSG_DEV_NUM;
	/*classq number validation*/
	if (que_no < TLITE_MIN_QUE_NO || que_no > TLITE_MAX_QUE_NO)
		return TLITE_QUE_NUM_ERR;
	dev_id--;
	que_no--;
	read_val = read_fasw_context_memory(que_no, dev_id, CURQ_QMAX_QMIN_CFG);
	return read_val;
} /*End of pfe_tlite_get_taildrop_value() Function*/

/*************************************************************************
 * Description    : This function set shaper mode
 *************************************************************************/
static int32a pfe_tlite_shaper_mode_config(	uint32a dev_id,
					uint32a shaper_no,
					uint32a mode)
{
	uint32a read_val = 0;

	/*dev_id  validation*/
	if (dev_id < TLITE_MIN_DEV_NUM || dev_id > TLITE_SWITCH_MAX_DEV_NUM)
		return TLITE_ERR_MSG_DEV_NUM;
	/*Shaper number validation*/
	if (shaper_no < TLITE_MIN_SHPR_NUM ||
		shaper_no > TLITE_MAX_SHPR_NUM) {
		TL_DEBUG(DBGP_FEAT_ERR, FP_LOG_EMERG,
			"%s:TLITE_ERR_MSG_SHP_NUMBER %d\n", __func__,
				shaper_no);
		return TLITE_ERR_MSG_SHP_NUMBER;
	}

#if 0
	if (mode < TLITE_MIN_MODE || mode > TLITE_MAX_MODE)
		return TLITE_ERR_MSG_SHP_MODE;
#endif

	dev_id--;
	shaper_no--;
	pfe_tlite_dynamic_config_enable(1);
	/* writing rate units and position in TMU_SHP0_CTRL2 register */
	read_val = RegRead(tlite_get_shp_addr(TMU_SHP0_CTRL2_ADDR, shaper_no, dev_id));

	read_val =  (read_val & 0x3F) | (mode << SHIFT_BY6);
	RegWrite(tlite_get_shp_addr(TMU_SHP0_CTRL2_ADDR, shaper_no, dev_id), read_val);

	read_val = RegRead(tlite_get_shp_addr(TMU_SHP0_CTRL2_ADDR, shaper_no, dev_id));
	pfe_tlite_dynamic_config_done();
	return read_val;
} /*End of pfe_tlite_shaper_mode_config () Function*/

#if 0
/*************************************************************************
* Description    : Main function to set tlite config parameters
*************************************************************************/
int32a pcm_tlite_config_ioctl(struct net_device *dev, struct ifreq *rq, int32a cmd)
{
	uint32a retval = 0;
	uint32a *iptr, pcpval = 0;
	nc_ioctl_ops_t pnc_ops;
	pcm_msg_header_t pmsg;
	tlite_schd_params_t psch;
	tlite_shpr_params_t shp;
	tlite_shpr_params_t sp;
	tlite_classq_params_t params;
	tlite_meter_params_t q;
	pcm_msg_header_t *p_msg;
	tlite_creditmode_params_t ps;

	int32a ret = copy_from_user(&pnc_ops,
					(nc_ioctl_ops_t *)rq->ifr_ifru.ifru_data,
					sizeof(nc_ioctl_ops_t));
	if (ret)
		return -1;
	ret = copy_from_user(&pmsg,
				(pcm_msg_header_t *)pnc_ops.io_data,
				sizeof(pcm_msg_header_t));
	if (ret)
		return -1;
	/*Get pci base address*/
	baseaddr = getPciBaseAddr(dev);
	switch (pmsg.pcmh_type) {
	case PCM_MSG_TLITE_DYNAMIC_CONFIG_ENABLE:
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"%s:dynamic config enable\n", __func__);
		/*dynamic configuration enable for
					all schedulers and shapers*/
		return pfe_tlite_dynamic_config_enable(pmsg.pcmh_value);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"%s:dynamic config enable\n",
						__func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"hw_type:\t%x\n", pmsg.pcmh_value);
	break;

	case PCM_MSG_TLITE_SCHD_CONFIG:
		ret = copy_from_user(	&psch,
					(tlite_schd_params_t *)((int8 *)pnc_ops.io_data + sizeof(pcm_msg_header_t)),
					sizeof(tlite_schd_params_t));
		if (ret)
			return -1;
		retval = pcm_tlite_scheduler_config(&psch, pmsg.pcmh_value);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"schconfig return value:%x\n", retval);
		return retval;
	{
		tlite_schd_params_t sh;
		ret = copy_from_user(&sh,
					(tlite_schd_params_t *)((int8 *)pnc_ops.io_data + sizeof(pcm_msg_header_t)),
					sizeof(tlite_schd_params_t));
		if (ret)
			return -1;
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"%s:Scheduler config\n", __func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"sch_id:\t%x\n", sh.tlsd_schd_id);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"dev_id:\t%x\n", sh.tlsd_dev_id);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"algo  :\t%x\n", sh.tlsd_algo);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"position:\t%x\n", sh.tlsd_position);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"hw_type:\t%x\n", pmsg.pcmh_value);
	}
	break;

	case PCM_MSG_TLITE_SHPR_CONFIG:
		ret = copy_from_user(	&shp,
					(tlite_shpr_params_t *)((int8 *)pnc_ops.io_data + sizeof(pcm_msg_header_t)),
					sizeof(tlite_shpr_params_t));
		if (ret)
			return -1;
		return pcm_tlite_shaper_config(&shp, pmsg.pcmh_value, 0);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"%s:Shaper config\n", __func__);
	{
#ifdef TLITE_DEBUG
		ret = copy_from_user(	&sp,
					(tlite_shpr_params_t *)((int8 *)pnc_ops.io_data + sizeof(pcm_msg_header_t)),
					sizeof(tlite_shpr_params_t));
		if (ret)
			return -1;
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"shp_update:\t%x\n", sp.tlsp_shpr_updates);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"shpr_id:\t%x\n", sp.tlsp_shpr_id);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"dev_id  :\t%x\n", sp.tlsp_dev_id);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"clk_freq:\t%x\n", sp.tlsp_clk_frequency);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"rate:\t%x\n", sp.tlsp_rate);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"r_units:\t%x\n", sp.tlsp_rate_units);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"max_credit:\t%x\n", sp.tlsp_max_credit);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"shp_position:\t%x\n", sp.tlsp_position);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"hw_type:\t%x\n", pmsg.pcmh_value);
#endif
	}
	break;

	case PCM_MSG_TLITE_CLASSQ_ADD:
		ret = copy_from_user(	&params,
					(tlite_classq_params_t *)((int8 *)pnc_ops.io_data + sizeof(pcm_msg_header_t)),
					sizeof(tlite_classq_params_t));
		if (ret)
			return -1;
		return pcm_tlite_classq_add(&params, pmsg.pcmh_value);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"%s:Class que add\n", __func__);
	{
		tlite_classq_params_t q;
		ret = copy_from_user(	&q,
					(tlite_classq_params_t *)((int8 *)pnc_ops.io_data + sizeof(pcm_msg_header_t)),
					sizeof(tlite_classq_params_t));
		if (ret)
			return -1;
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"dev_id\t%x\n", q.tlcq_dev_id);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"q_id:\t%x\n", q.tlcq_classq_id);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"sch_id  :\t%x\n", q.tlcq_schd_id);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"schd_slot:\t%x\n", q.tlcq_schd_slot);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"max_len:\t%x\n", q.tlcq_max_len);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"q_wt:\t%x\n", q.tlcq_weight);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"q_mgmt:\t%x\n", q.tlcq_qmgmt);
		if ((q.tlcq_qmgmt) == 2) {
			TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"min_length:\t%x\n",
						q.tlcq_min_len);
			TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"prob0:\t%x\n",
					q.tlcq_prob_cfg0);
			TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"prob1:\t%x\n",
					q.tlcq_prob_cfg1);
			TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"prob2:\t%x\n",
					q.tlcq_prob_cfg2);
			TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"prob3:\t%x\n",
					q.tlcq_prob_cfg3);
			TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"prob4:\t%x\n",
					q.tlcq_prob_cfg4);
			TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"prob5:\t%x\n",
					q.tlcq_prob_cfg5);
			TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"prob6:\t%x\n",
					q.tlcq_prob_cfg6);
			TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"prob7:\t%x\n",
					q.tlcq_prob_cfg7);
		}
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"hw_type:\t%x\n", pmsg.pcmh_value);
	}
	break;

	case PCM_MSG_TLITE_CLASSQ_DELETE:
		FP_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"%s:Cls q del  dev:%x q_num:%x hw_type:%x\n",
				__func__, pmsg.pcmh_flags,
				pmsg.pcmh_value, pmsg.pcmh_length);
		return pcm_tlite_classq_delete((uint32)pmsg.pcmh_flags,
					(uint32)pmsg.pcmh_value,
						pmsg.pcmh_length);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"%s:Class Que delete dev:%x q_num:%x hw_type:%x\n",
				__func__, pmsg.pcmh_flags,
					pmsg.pcmh_value, pmsg.pcmh_length);
	break;

	case PCM_MSG_TLITE_SET_IFG:
		/*Set ifg value based on device id*/
		return pfe_tlite_set_ifg((uint32)pmsg.pcmh_flags,
				(uint32)pmsg.pcmh_value, pmsg.pcmh_length);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"%s:set ifg\n", __func__);
	{
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"dev_id\t%x\n", pmsg.pcmh_flags);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"ifg:\t%x\n", pmsg.pcmh_value);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"hw_type:\t%x\n", pmsg.pcmh_length);
	}
	break;

	case PCM_MSG_TLITE_METER_CONFIG:
		ret = copy_from_user(	&q,
					(tlite_meter_params_t *)((int8 *)pnc_ops.io_data + sizeof(pcm_msg_header_t)),
					sizeof(tlite_meter_params_t));
		if (ret)
			return -1;
		return pcm_tlite_fasw_meter_config(&q);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"%s:meter_config\n", __func__);
	{
		tlite_meter_params_t q;
		ret = copy_from_user(	&q,
					(tlite_meter_params_t *)((int8 *)pnc_ops.io_data + sizeof(pcm_msg_header_t)),
					sizeof(tlite_meter_params_t));
		if (ret)
			return -1;
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"meter_no\t%x\n", q.tlmt_meter_no);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"cloc_freq:\t%x\n", q.tlmt_clock_freq);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"max_credit:\t%x\n", q.tlmt_max_credit);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"enable:\t%x\n", q.tlmt_enable);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"ifg_add:\t%x\n", q.tlmt_ifg_add);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"rate_units:\t%x\n", q.tlmt_rate_units);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"clear:\t%x\n", q.tlmt_clear);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_DEBUG ,
			"rate :\t%x\n", q.tlmt_rate);
	}
	break;

	case PCM_MSG_TLITE_METER_GLOBAL_ENABLE:
		/*Enable or disable based on input*/
		return pfe_tlite_fasw_meter_enable((uint32)pmsg.pcmh_value);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"%s:meter_global_enable\n", __func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"enable:\t%x\n", pmsg.pcmh_value);
	break;

	case PCM_MSG_TLITE_DYNAMIC_CONFIG_DONE:
		/*Set init done bit, after intialization
					of all schedulers and shapers*/
		return pfe_tlite_dynamic_config_done();
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"%s:dynamic_config_done\n", __func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"hw_type:\t%x\n", pmsg.pcmh_value);
	break;

	case PCM_MSG_TLITE_QUE_STATS:
		p_msg = pfe_tlite_que_stats(pmsg.pcmh_value,
					pmsg.pcmh_length, pmsg.pcmh_flags);
		/*Update information to user*/
		ret = copy_to_user(pnc_ops.io_data, p_msg,
						sizeof(pcm_msg_header_t));
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"%s:get_que_stats\n", __func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"tx packet count\t%x\n", pmsg.pcmh_length);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"dropcount:\t%x\n", pmsg.pcmh_value);
	break;

	case PCM_MSG_TLITE_INQ_STATS:
		p_msg =  pfe_tlite_inq_stats();
		/*Update inq stats information to user*/
		ret = copy_to_user(pnc_ops.io_data, p_msg,
						sizeof(pcm_msg_header_t));
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"%s:get_inq_stats\n", __func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"hw_type:\t%x\n", pmsg.pcmh_value);
	break;

	case PCM_MSG_TLITE_CLASSQ_CHECK:
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"dev_id:\t%x\n", pmsg.pcmh_flags);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"classq_id:\t%x\n", pmsg.pcmh_length);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"sched_id:\t%x\n", pmsg.pcmh_value);
		if (fp_tdev_list[pmsg.pcmh_flags].
					classq_list[pmsg.pcmh_length] == 0) {
			pmsg.pcmh_length = CLASSQ_NOTCONNECTED;
			FP_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"%s: CLASSQ_NOTCONNECTED\n", __func__);
		} else {
			FP_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"%s:CLASSQ_CONNECTED\n", __func__);
			pmsg.pcmh_value =
		fp_tdev_list[pmsg.pcmh_flags].classq_list[pmsg.pcmh_length];
			pmsg.pcmh_length = CLASSQ_CONNECTED;
		}
		ret = copy_to_user(pnc_ops.io_data,
					&pmsg, sizeof(pcm_msg_header_t));
	break;

	case PCM_MSG_TLITE_SCH_LIST:
		iptr = pfe_tlite_sch_list((pmsg.pcmh_value) - 1);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"%s:get_sch_list\n", __func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					":\t%x \t%x\n", *iptr, *(iptr + 1));
		ret = copy_to_user(pnc_ops.io_data,
				iptr, TLITE_MAX_SCHED_NUM * sizeof(uint32a));
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"%s:get_sch_list\n", __func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"dev_id:\t%x\n", pmsg.pcmh_value);
	break;

	case PCM_MSG_TLITE_SHP_LIST:
		iptr = pfe_tlite_shp_list((pmsg.pcmh_value) - 1);
		ret = copy_to_user(pnc_ops.io_data, iptr,
					TLITE_MAX_SHPR_NUM * sizeof(uint32a));
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"%s:get_shp_list\n", __func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"dev_id:\t%x\n", pmsg.pcmh_value);
	break;

	case PCM_MSG_TLITE_CLASSQ_LIST:
		FP_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"dev_id:\t%x\n", pmsg.pcmh_value);
		iptr = pfe_tlite_classq_list((pmsg.pcmh_value) - 1);
		ret = copy_to_user(pnc_ops.io_data,
					iptr, TLITE_MAX_QUE_NO * sizeof(uint32a));
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"%s:get_classq_list\n", __func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"dev_id:\t%x\n", pmsg.pcmh_value);
	break;
	case PCM_MSG_TLITE_CLASSQ_PER_SCH_LIST:
		iptr = pfe_tlite_classq_per_sched_list(
						(pmsg.pcmh_value) - 1);
		ret = copy_to_user(pnc_ops.io_data, iptr,
					TLITE_MAX_QUE_NO * sizeof(uint32a));
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"%s:get_classq_per_sch_list\n", __func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"dev_id:\t%x\n", pmsg.pcmh_value);
	break;

	case PCM_MSG_TLITE_CREDITMODE_SHP_CONFIG:
		ret = copy_from_user(	&ps,
					(tlite_creditmode_params_t *)((int8 *)pnc_ops.io_data + sizeof(pcm_msg_header_t)),
					sizeof(tlite_creditmode_params_t));
		if (ret)
			return -1;
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"%s:get_classq_per_sch_list\n", __func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
					"dev_id:\t%x\n", pmsg.pcmh_value);
		return pcm_tlite_creditmode_shaper_config(&ps);
	break;

	case PCM_MSG_TLITE_SET_REGENERATE_PCP:
		pfe_tlite_set_regenerate_pcp((pmsg.pcmh_flags) - 1,
						 pmsg.pcmh_value);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"%s:set_regenerate_pcpvalue\n", __func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"port_no:\t%x value:\t%x\n",
				pmsg.pcmh_flags, pmsg.pcmh_value);
	break;

	case PCM_MSG_TLITE_GET_REGENERATE_PCP:
		pcpval = pfe_tlite_get_regenerate_pcp((pmsg.pcmh_flags) - 1);
		iptr = &pcpval;
		if (iptr == NULL)
			break;
		ret = copy_to_user(pnc_ops.io_data, iptr, sizeof(uint32a));
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"%s:get_regenerate_pcpvalue\n", __func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO, "value:\t%x\n", *iptr);
	break;

	case PCM_MSG_TLITE_TAILDROP_ENABLE:
		pfe_tlite_taildrop_enable(pmsg.pcmh_value,
				pmsg.pcmh_length, pmsg.pcmh_flags);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"%s:taildrop_enable\n", __func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"dev_id:\t%x classq_id:\t%x value:\t%x\n",
			pmsg.pcmh_value, pmsg.pcmh_length, pmsg.pcmh_flags);
	break;

	case PCM_MSG_TLITE_TAILDROP_DISABLE:
		pfe_tlite_taildrop_disable(pmsg.pcmh_value,
			pmsg.pcmh_length);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"%s:taildrop_disable\n", __func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"dev_id:\t%x classq_id:\t%x\n",
			pmsg.pcmh_value, pmsg.pcmh_length);
	break;

	case PCM_MSG_TLITE_GET_TAILDROP_VALUE:
		retval = pfe_tlite_get_taildrop_value(pmsg.pcmh_value,
					pmsg.pcmh_length);
		iptr = &retval;
		if (iptr == NULL)
			break;
		ret = copy_to_user(pnc_ops.io_data, iptr, sizeof(uint32a));
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"%s:get_taildrop_value\n", __func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"dev_id:\t%x classq_id:\t%x\n",
			pmsg.pcmh_value, pmsg.pcmh_length);
	break;

	case PCM_MSG_TLITE_SHAPER_SET_MODE:
		retval = pfe_tlite_shaper_mode_config(pmsg.pcmh_value,
			pmsg.pcmh_length, pmsg.pcmh_flags);
		iptr = &retval;
		if (iptr == NULL)
			break;
		ret = copy_to_user(pnc_ops.io_data, iptr, sizeof(uint32a));
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"%s:shaper_mode_config\n", __func__);
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
			"dev_id:\t%x shaper_id:\t%x mode value:\t%x\n",
			pmsg.pcmh_value, pmsg.pcmh_length, pmsg.pcmh_flags);
	break;

	default:
		TL_DEBUG(DBGP_FEAT_TMU, FP_LOG_INFO,
				"%s:Unknown message type\n", __func__);
		return PCM_ERR_MSG_TMU_UNKNOWN_TYPE;
	break;
	} /*End of message type switch*/
	return 0;
} /*End of pcm_tmu_config_ioctl() Function*/
#endif

