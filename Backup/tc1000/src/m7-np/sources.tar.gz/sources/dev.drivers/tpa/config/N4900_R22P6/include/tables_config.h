/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          tables_config.h
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    Table and port configurations
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifndef _TABLES_CONFIG_H_
#define _TABLES_CONFIG_H_

/************************************************************************
                             MACROS FOR SWITCH TABLES
************************************************************************/
#define FP_MAX_PORTS			11
#define FP_MAX_SWITCH_PORTS		11

#define EMAC_PORT_LIST_MASK		0x07	// ports 0,1,2 (P6)
#define HOST_PORT_LIST_MASK		0x10	// port 4 (P6)
#define HOSTPORT_NO			4	// Physical Port Number of Host
#define HIF_PORT_NUM			4	// Physical Port Number of Host
#define FWD_PORT_LIST_MASK		(EMAC_PORT_LIST_MASK | HOST_PORT_LIST_MASK)

#define FP_MAX_BRTBL			1
#define FP_MAX_VLAN_GRPTBL		1

#define VLANID_MASK			0x1FFF

#define BIT_SET_VLAN_1F_VLANTBL		0x00000100

//==============================================================================
extern uint32a egpi_base_addr[FP_MAX_PORTS];

static const int32a VALID_PORT[]		= { 1, 2, 3 };
static const int32a VALID_PARTITION[]	= { 1, 2, 3, 4, 5 };	// needs to be set correctly

#define MAC_HASH_RAM_ADD_WIDTH		(11U)
#define MAC_HASH_NUM_ENTRIES		(2048U)
#define MAC_HASH_NUM_FIELDS		(2U)
#define MAC_HASH_FIELD1_WIDTH		(48U)
#define MAC_HASH_FIELD2_WIDTH		(13U)

#define VLAN_HASH_RAM_ADD_WIDTH		(9U)
#define VLAN_HASH_NUM_ENTRIES		(512U)
#define VLAN_HASH_NUM_FIELDS		(1U)
#define VLAN_HASH_FIELD1_WIDTH		(13U)
#define VLAN_HASH_FIELD2_WIDTH		(0)

#define CBSTREAM_HASH_NUM_ENTRIES	(256U)
#define CBSTREAM_HASH_NUM_FIELDS	(2U)
#define CBSTREAM_HASH_FIELD1_WIDTH	(48U)
#define CBSTREAM_HASH_FIELD2_WIDTH	(13U)

#define SMAC_HASH_NUM_ENTRIES		(256U)
#define SMAC_HASH_NUM_FIELDS		(1U)
#define SMAC_HASH_FIELD1_WIDTH		(48U)
#define SMAC_HASH_FIELD2_WIDTH		(0)

/* moved from hw_2field_hash_table.h */
#define TWO_FIELD_HASH_ENTRIES		0x400
#define TWO_FIELD_COLL_ENTRIES		0x400
#define TWO_FIELD_INIT_HEAD_PTR		0x400
#define TWO_FIELD_INIT_TAIL_PTR		0x7FF


/* moved from fp_cb_api.h */
#define CB_TABLE_HASH_ENTRIES		128
#define CB_TABLE_COLL_ENTRIES 		128
#define CB_TABLE_SIZE			(CB_TABLE_HASH_ENTRIES+CB_TABLE_COLL_ENTRIES)

#define CB_SMAC_HASH_ENTRIES		128
#define CB_SMAC_COLL_ENTRIES 		128

#define ROUTE_TABLE_OFFSET		(EGPI1_CLASS_HW_ROUTE_TABLE_BASE_ADDR - (EGPI1_BASE_ADDR + INGRESS_CLASSIFIER_BASE_ADDR))

#endif	// end of  _TABLES_CONFIG_H_
