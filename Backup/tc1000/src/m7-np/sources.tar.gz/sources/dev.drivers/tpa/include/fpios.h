/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          fpios.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    data structures for ioctl
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifndef _FPATHIOS_H_
#define _FPATHIOS_H_

#include <linux/sockios.h>
#include "sal_com.h"

typedef struct {
	uint32a	cmd;		/* sub command within an IOCTL option */
	uint32a	offset;		/* read/write config offset */
	uint32a	size;		/* no.of bytes for read config */
	uint32	addr;		/* read/write PCI address */
	uint32a	value;		/* value to write at PCI mem addr */
	int8		Buff[256];	/* buffer send/receive data between */
					/* CLI and device */
	int8		pciBuff[256];	/* buffer send/receive data b/w CLI and PCI */
	int8		*data;		/* Pointer to an array; */
}   fpathcmd_t;

#define    FPATH_READ_CONFIG			SIOCDEVPRIVATE+0
#define    FPATH_WRITE_CONFIG			SIOCDEVPRIVATE+1
#define    FPATH_READ_PCI_MEM			SIOCDEVPRIVATE+2
#define    FPATH_WRITE_PCI_MEM			SIOCDEVPRIVATE+3
#define    FPATH_RX_PCI_DMA			SIOCDEVPRIVATE+16
#define    FPATH_TX_PCI_DMA			SIOCDEVPRIVATE+17
#define    FPATH_READ_STATS			SIOCDEVPRIVATE+6  /* Obtain Stats */
#define    FPATH_READ_INTF_STATS		SIOCDEVPRIVATE+10 /* Obtain Stats */
/* Obtain Flow information */
#define    FPATH_READ_FLOW_ENTRIES		SIOCDEVPRIVATE+8  /* Entries */
#define    FPATH_READ_FLOW_ENTRIES_NUM		SIOCDEVPRIVATE+7  /* Number of Stats */
#define    FPATH_READ_FLOW_ENTRIES_EXT		SIOCDEVPRIVATE+9  /* Number of Stats */
//#define    NC_SET_FASTPATH			SIOCDEVPRIVATE+12 /* Number of Stats */

/* Obtain Bridge information */
#define    FPATH_READ_BRIDGE_ENTRIES		SIOCDEVPRIVATE+10 /* Entries */
#define    FPATH_READ_BRIDGE_ENTRIES_NUM	SIOCDEVPRIVATE+11 /* Number of Entries */
#define    FPATH_READ_BRIDGE_ENTRIES_EXT	SIOCDEVPRIVATE+12 /* Extensive Info */
//#define    PCM_MSG_SET_TMU			SIOCDEVPRIVATE+13 /* Set tmu parameters */
//#define    PCM_MSG_GET_TMU			SIOCDEVPRIVATE+14 /* Get tmu parameters */
//#define    PCM_MSG_TMU			SIOCDEVPRIVATE+13 /* Set and Get tmu parameters */
#define    PCM_MSG_SWITCH			SIOCDEVPRIVATE+13 /* Set and Get tmu parameters */
#define    PCM_MSG_TLITE			SIOCDEVPRIVATE+14 /* Set and Get tlite parameters */
#define    SET_6RAFILTER			SIOCDEVPRIVATE+15 /* Set 6RA filter enable/disable */
#define    FPATH_READ_PHY_MEM			SIOCDEVPRIVATE+4
#define    FPATH_WRITE_PHY_MEM			SIOCDEVPRIVATE+5

#endif /*End of _FPATHIOS_H_ file */
