// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_switch_host_timer.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    timer registration for switch ageing
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                      Include Files
 **********************************************************************/
#include <linux/timer.h>

#include "fp_library.h"
#include "fp_switch.h"

/**********************************************************************
 *                              Global Declarations
***********************************************************************/
/* This value is used to refresh bridge entries */
#define FP_SWITCH_REFRESH    (300*HZ)

spinlock_t tbl_lock;

/* The timer structure used to refresh the mac table entries */
static struct timer_list fp_switchflow_timer;
extern uint8 *fp_net_dev;
int32a fp_send_ccm_frame(struct net_device *dev, uint32a port);

/*******************************************************************************
 * Function name:       fp_switch_timer_handler
 * Input Parameters:    The long value  passed to every timer handler
 * Output Parameters:   none
 * Result:              none
 * Description:         This functions invokes agaeing handler & reschedule
 *                      when ever its called
 ******************************************************************************/
void fp_switch_timer_handler(struct timer_list *t)
{
	fp_switch_host_ageing();
	/* Update the refresh timer to call this fucntion again */
	fp_switchflow_timer.expires = jiffies + FP_SWITCH_REFRESH;
	add_timer(&fp_switchflow_timer);
	mod_timer(&fp_switchflow_timer, jiffies + FP_SWITCH_REFRESH);
	FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO, "END of bridge timer function\n");
}

/**********************************************************************
 * Function Name  : fp_switch_init_timer.c
 * Description    : do bridge ageing timer registration
 * Inputs         :
 * Parameters     : int *data
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_switch_init_timer(int32a init)
{
	int32a ret = 0;
	if (!init)
		goto delbr_timer;
	spin_lock_init(&tbl_lock);
	timer_setup(&fp_switchflow_timer, fp_switch_timer_handler, 0);
	mod_timer(&fp_switchflow_timer, jiffies + FP_SWITCH_REFRESH);
	FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO, "INIT SWITCH TIMER\n");
	return 0;
delbr_timer:
	del_timer((struct timer_list *)&fp_switchflow_timer);
	FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO, "DELETE SWITCH TIMER\n");
	return ret;
}

