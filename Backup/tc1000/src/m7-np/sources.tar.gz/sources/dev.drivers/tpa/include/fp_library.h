/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          fp_library.h
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    all user defined wrapper functions
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

#ifndef _FP_LIBRARY_H_
#define _FP_LIBRARY_H_

#ifdef __linux__
#include <linux/kernel.h>
#include <linux/string.h>	/* for	memcpy / memset etc. */
#endif

#include <stddef.h>  /* for	size_t */
#include "sal_internal.h"

/* TSNC note : temporary. typedef of kernel */
typedef uint32 dma_addr_t;
typedef uint32 spinlock_t;

#ifndef false
#define false (0U)
#endif

/* TSNC note : temporary. define error code of kernel */
#define ENOMEM (-12)

//#include "class_hw_csr.h"
/* debug log base function */
#include "debug.h"
#if 1// (DEBUG_ENABLE)

    #define TPA_D(fmt,args...)          {LOGD(DBG_TAG_TPA, fmt, ## args)}
    #define TPA_E(fmt,args...)          {LOGE(DBG_TAG_TPA, fmt, ## args)}
#else
    #define TPA_D(fmt,args...)
    #define TPA_E(fmt,args...)
#endif

/* TSNC note: Temporary ignore funtions for linux kernel debug*/
#define printk(fmt, args...)
#define pr_err(fmt, args...)
#define pr_info(fmt, args...)
#define pr_debug(fmt, args...)

#ifdef DEBUG_FUNCTION_FLOW
#define ENTER	TPA_D("Enter %s",__FUNCTION__)
#define LEAVE	TPA_D("Leaving %s at %i" , __FUNCTION__, __LINE__)
#define TRACE	TPA_D("%s:%s:%i",__FILE__, __FUNCTION__, __LINE__);
#else
#define ENTER	do {} while (0)
#define LEAVE	do {} while (0)
#define TRACE	do {} while (0)
#endif
void fp_convert_le2be(int8 *, uint32a);	/* WARNING -- UNSAFE CONVERSION */

extern int32a fp_entry(void);
extern int32a nkprintf(const int8 *fmt, ...);

/* fpath trace levels */
/* TSNC note : change FP_LOG_EMERG value from 0 to 1, to avoid build error 'FP_LOG_EMERG'*/
#define FP_LOG_EMERG	1	/* system is unusable */
#define FP_LOG_ALERT	1	/* action must be taken immediately */
#define FP_LOG_CRIT	2	/* critical conditions */
#define FP_LOG_ERR	3	/* error conditions */
#define FP_LOG_WARNING	4	/* warning conditions */
#define FP_LOG_NOTICE	5	/* normal but significant condition */
#define FP_LOG_INFO	6	/* informational */
#define FP_LOG_DEBUG	7	/* debug-level messages */

/* fpath trace types */
#define FP_TRACE_INIT		0x1
#define FP_TRACE_CLEANUP	0x2
#define FP_TRACE_L2_PARSING	0x4
#define FP_TRACE_L3_PARSING	0x8
#define FP_TRACE_L4_PARSING	0x10
#define FP_TRACE_ROUTING	0x20
#define FP_TRACE_BRIDGING	0x40
#define FP_TRACE_NF_HOOKS	0x80
#define FP_TRACE_CONFIG		0x100
#define FP_TRACE_LINUX		0x200
#define FP_TRACE_OTHER		0x400
#define FP_TRACE_ALL		0xFFFFFFFF

/* fpath trace macros and data structures */
typedef struct fpath_trace_s {
	uint32a	trace_flags;
	uint32a	trace_level;
} fpath_trace_t;

extern fpath_trace_t fpath_trace;

#define FPATH_TRACE(type, trace_level, fmt_str)

//extern uint8 *fp_baseAddr;

#define FP_MAX_DBGP 32
#define FP_MAX_DBGP_LEN 32
extern uint8 fp_dbgp_arr[FP_MAX_DBGP][FP_MAX_DBGP_LEN];
extern uint32a	fp_dbgp_flags;
extern uint32a	fp_trace_level;

enum fp_dbgp_features {
	DBGP_FEAT_HIF		= 0x1,
	DBGP_FEAT_BRIDGE	= 0x2,
	DBGP_FEAT_ROUTE		= 0x4,
	DBGP_FEAT_FWD_PE	= 0x8,
	DBGP_FEAT_TMU		= 0x10,
	DBGP_FEAT_CLI		= 0x20,
	DBGP_FEAT_L2CLI		= 0x40,
	DBGP_FEAT_L3CLI		= 0x80,
	DBGP_FEAT_L2API		= 0x100,
	DBGP_FEAT_L3API		= 0x200,
	DBGP_FEAT_IOCTL		= 0x400,
	DBGP_FEAT_LIB		= 0x800,
	DBGP_FEAT_ERR		= 0x1000,
	/*
	 * This is an execution time feature, so max number of allowed
	 * groups are 0-31. You may add your features before this comment.
	 */
	DBGP_FEAT_MAX = 0x80000000
};

#if 0
#define FP_DEBUG(feat, level, msg, args...) if(feat & fp_dbgp_flags){ \
	int32a count = 0; \
	for (; count < 32; count++) { \
		if ((1 << count) & feat) { \
			break; \
		} \
	} \
	if (level <= fp_trace_level) \
	printk("%s: " msg,fp_dbgp_arr[count], ## args); \
};
#elif 1
#define FP_DEBUG(feat, level, msg, args...) if(feat & fp_dbgp_flags){ \
	int32a count = 0; \
	for (; count < 32; count++) { \
		if ((1 << count) & feat) { \
			break; \
		} \
	} \
	if (level <= fp_trace_level) \
	{ TPA_D("%s: " msg,fp_dbgp_arr[count], ## args); } \
};
#else
#define FP_DEBUG(type, debug_level, msg, args...) while (0) {;}
#endif

extern void tpa_udelay_busy(uint32 usec);
#define udelay(x) tpa_udelay_busy(x)

//#define FP_DEBUG_LEVEL_MAX
//#define TC_DEBUG_PACKET_DATA
#define ENABLE_RX

void spin_lock_init(spinlock_t *lock, const uint8* name);
void spin_lock_bh(spinlock_t *lock);
void spin_unlock_bh(spinlock_t *lock);
void spin_lock_deinit(spinlock_t *lock);

#endif /*End of _FP_LIBRARY_H_ File */
