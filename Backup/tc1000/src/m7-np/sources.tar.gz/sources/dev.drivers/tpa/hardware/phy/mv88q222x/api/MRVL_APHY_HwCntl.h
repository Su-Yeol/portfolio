/**
 * @file MRVL_APHY_HwCntl.h
 * @brief APHY hardware control Header File for API interfacing with APHY and register
 *
 * @par Copyright and Version
 * See MRVL_Q222X_Copyright_and_Version.h
 */

#ifndef MRVL_APHY_HWCNTL_H
#define MRVL_APHY_HWCNTL_H

#include "MRVL_APHY_Device.h"

/** @defgroup CodeMertic Code Mertic */

/******************************************************************************
 *      lib/utility functions, need to justify if Code Mertic complaint
 ******************************************************************************/
/** @defgroup Utility_Lib CodeMertic[ASH-926] Lib Func: CODE-METRICS:CALLING
 *
 * lib/utility functions, need to justify if Code Mertic complaint
 *
 * @ingroup CodeMertic
*/

/******************************************************************************
 *      high scope value functions, need to justify if Code Mertic complaint
 ******************************************************************************/
/** @defgroup VOCF_High CodeMertic[ASH-925] VOCF High Func: CODE-METRICS:VOCF
 *
 * high scope value functions, need to justify if Code Mertic complaint
 *
 * @ingroup CodeMertic
*/

EXPORT_FUNC void mrvl_aphy_hwXmdioRead(MRVL_DEV_PTR device, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16* data);

EXPORT_FUNC void mrvl_aphy_hwXmdioWrite(MRVL_DEV_PTR device, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16 data);

EXPORT_FUNC void mrvl_aphy_wait(MRVL_DEV_PTR device, MRVL_APHY_U16 waitTime);

#endif
