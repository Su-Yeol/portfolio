/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          fp_stats.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    stats related data structures and APIs for fast path
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifndef _FP_STATS_H_
#define _FP_STATS_H_

#include "tables_config.h"

#define FP_PARSE_MGMT_MODULE		0x1
#define FP_PARSE_INRATE_MODULE		0x2
#define FP_PARSE_OUTRATE_MODULE	0x4
#define FP_PARSE_INGRVLAN_MODULE	0x8
#define FP_PARSE_EGRVLAN_MODULE	0x10
#define FP_PARSE_QOS_MODULE		0x20
#define FP_PARSE_L2SPECIAL_MODULE	0x40


#define ALL_STATS		0x1
#define MGMT_STATS		0x2
#define INRATE_STATS		0x3
#define L2SPECIAL_STATS		0x4
#define INGRVLAN_STATS		0x5
#define EGRVLAN_STATS		0x6
#define QOS_STATS		0x7
#define OUTRATE_STATS		0x8

/* MOdule index for kernel stastics */
#define FP_MGMT		0x1
#define FP_L2SPECIAL	0x2
#define FP_INGRVLAN	0x3
#define FP_QOS		0x4

typedef struct fp_stats_s {
	/* protocol stats */
	uint32a ip4_pkt_cnt;
	uint32a udp_pkt_cnt;
	uint32a tcp_pkt_cnt;
	uint32a icmp_pkt_cnt;
	uint32a igmp_pkt_cnt;
	uint32a ip6_pkt_cnt;

	/* packet parsing error counters */
	uint32a ip_hdr_len_err_cnt;
	uint32a ip_pkt_len_err_cnt;
	uint32a ip_chksum_err_cnt;

	/* other counters */
	uint32a mem_alloc_err_cnt;
	uint32a unknown_pkt_cnt; /* arp and unknown packets count */
	uint32a intf_match_cnt;
	uint32a intf_mismatch_cnt;
	uint32a src_be_found;           /* source bridge entry found */
	uint32a dst_be_found;           /* destination bridge entry found */
	uint32a src_be_not_found;       /* source bridge entry not found */
	uint32a dst_be_not_found;       /* destination bridge entry not found */
	uint32a re_found;               /* route entry found */
	uint32a re_not_found;           /* route entry not found */
	/*Added for rx/tx/pe-host counters*/
	uint32a rx_pkt_cnt;
	uint32a tx_pkt_cnt;
	uint32a pe_host_pkt_cnt;
	struct {
		uint32a ingq_class_drop_cnt;
		uint32a ingq_lmemq_drop_cnt;
		uint32a ingq_dmemq_drop_cnt;
		uint32a ingq_rxfq_drop_cnt;
		uint32a ingq_shp0_drop_cnt;
		uint32a ingq_shp1_drop_cnt;
		uint32a ingq_managed_cnt;
		uint32a ingq_unmanaged_cnt;
		uint32a ingq_reserved_cnt;
		uint32a ingq_total_drop_cnt;
		uint32a ingq_csrshp_drop_cnt;
	} ingqos_info[FP_MAX_PORTS];

	uint32a safety_reset_with_failstop;
	uint32a safety_reset_without_failstop;
	uint32a num_hif_tx_interrupts;
	uint32a num_hif_rx_interrupts;
	uint32a dummy[65];
} fp_stats_t; /* SIZE - 88 Bytes */

extern fp_stats_t fp_stats;

typedef struct fp_debugstats_s {
	uint32a emac_tx_counters0;
	uint32a emac_tx_counters1;

	uint32a emac_rx_counters0;
	uint32a emac_rx_counters1;

	uint32a emac_errors0[13];
	uint32a emac_errors1[13];

	uint32a gpi_fifo_count0;
	uint32a gpi_fifo_count1;
	uint32a gpi_fifo_count2;
	uint32a gpi_fifo_count3;

	uint32a gpi_drop_count0;
	uint32a gpi_drop_count1;

	uint32a class_phy1_count[10];
	uint32a class_phy2_count[10];

	uint32a bmu_buffer_count;
	uint32a bmu_rem_count;
	uint32a bmu_cur_count;

	uint32a bmu_master_based_buffer_counts[9];

	uint32a hif1_tx_counters0;
	uint32a hif1_tx_counters1;

	uint32a hif1_rx_counters0;
	uint32a hif1_rx_counters1;

	uint32a hif2_tx_counters0;
	uint32a hif2_tx_counters1;

	uint32a hif2_rx_counters0;
	uint32a hif2_rx_counters1;

	uint32a hgpi1_state0;
	uint32a hgpi1_state1;

	uint32a hgpi2_state0;
	uint32a hgpi2_state1;

	uint32a egpi1_state0;
	uint32a egpi1_state1;

	uint32a egpi2_state0;
	uint32a egpi2_state1;
} fp_debugstats_t;

#define NFP_STATS(field) do { \
	fp_stats.field++; \
} while(/*CONSTCOND*/0)

#define PHY0_RX_CNT		(CLASS_HW_BASE_ADDR + 0x11c)
#define PHY0_TX_CNT		(CLASS_HW_BASE_ADDR + 0x120)
#define PHY0_L2F_CNT		(CLASS_HW_BASE_ADDR + 0x124)
#define PHY0_INF_CNT		(CLASS_HW_BASE_ADDR + 0x128)
#define PHY0_INM_CNT		(CLASS_HW_BASE_ADDR + 0x12c)
#define PHY0_L3F_CNT		(CLASS_HW_BASE_ADDR + 0x130)
#define PHY0_IPV4_CNT		(CLASS_HW_BASE_ADDR + 0x134)
#define PHY0_IPV6_CNT		(CLASS_HW_BASE_ADDR + 0x138)
#define PHY0_CSUM_ERR_CNT	(CLASS_HW_BASE_ADDR + 0x13c)
#define PHY0_TTl_ERR_CNT	(CLASS_HW_BASE_ADDR + 0x140)
#define PHY0_UDP_CNT		(CLASS_HW_BASE_ADDR + 0x1a0)
#define PHY0_TCP_CNT		(CLASS_HW_BASE_ADDR + 0x19c)
#define PHY0_ICMP_CNT		(CLASS_HW_BASE_ADDR + 0x194)
#define PHY0_IGMP_CNT		(CLASS_HW_BASE_ADDR + 0x198)

#define PHY1_RX_CNT		(CLASS_HW_BASE_ADDR + 0x144)
#define PHY1_TX_CNT		(CLASS_HW_BASE_ADDR + 0x148)
#define PHY1_L2F_CNT		(CLASS_HW_BASE_ADDR + 0x14c)
#define PHY1_INF_CNT		(CLASS_HW_BASE_ADDR + 0x150)
#define PHY1_INM_CNT		(CLASS_HW_BASE_ADDR + 0x154)
#define PHY1_L3F_CNT		(CLASS_HW_BASE_ADDR + 0x158)
#define PHY1_IPV4_CNT		(CLASS_HW_BASE_ADDR + 0x15c)
#define PHY1_IPV6_CNT		(CLASS_HW_BASE_ADDR + 0x160)
#define PHY1_CSUM_ERR_CNT	(CLASS_HW_BASE_ADDR + 0x164)
#define PHY1_TTl_ERR_CNT	(CLASS_HW_BASE_ADDR + 0x168)
#define PHY1_UDP_CNT		(CLASS_HW_BASE_ADDR + 0x1b0)
#define PHY1_TCP_CNT		(CLASS_HW_BASE_ADDR + 0x1ac)
#define PHY1_IGMP_CNT		(CLASS_HW_BASE_ADDR + 0x1a8)
#define PHY1_ICMP_CNT		(CLASS_HW_BASE_ADDR + 0x1a4)

#define PHY2_RX_CNT		(CLASS_HW_BASE_ADDR + 0x16c)
#define PHY2_TX_CNT		(CLASS_HW_BASE_ADDR + 0x170)
#define PHY2_L2F_CNT		(CLASS_HW_BASE_ADDR + 0x174)
#define PHY2_INF_CNT		(CLASS_HW_BASE_ADDR + 0x178)
#define PHY2_INM_CNT		(CLASS_HW_BASE_ADDR + 0x17c)
#define PHY2_L3F_CNT		(CLASS_HW_BASE_ADDR + 0x180)
#define PHY2_IPV4_CNT		(CLASS_HW_BASE_ADDR + 0x184)
#define PHY2_IPV6_CNT		(CLASS_HW_BASE_ADDR + 0x188)
#define PHY2_CSUM_ERR_CNT	(CLASS_HW_BASE_ADDR + 0x18c)
#define PHY2_TTl_ERR_CNT	(CLASS_HW_BASE_ADDR + 0x190)
#define PHY2_UDP_CNT		(CLASS_HW_BASE_ADDR + 0x1c0)
#define PHY2_TCP_CNT		(CLASS_HW_BASE_ADDR + 0x1bc)
#define PHY2_ICMP_CNT		(CLASS_HW_BASE_ADDR + 0x1b4)
#define PHY2_IGMP_CNT		(CLASS_HW_BASE_ADDR + 0x1b8)

#define PHY3_RX_CNT		(CLASS_HW_BASE_ADDR + 0x1d4)
#define PHY3_TX_CNT		(CLASS_HW_BASE_ADDR + 0x1d8)
#define PHY3_L2F_CNT		(CLASS_HW_BASE_ADDR + 0x1dc)
#define PHY3_INF_CNT		(CLASS_HW_BASE_ADDR + 0x1e0)
#define PHY3_INM_CNT		(CLASS_HW_BASE_ADDR + 0x1e4)
#define PHY3_L3F_CNT		(CLASS_HW_BASE_ADDR + 0x1e8)
#define PHY3_IPV4_CNT		(CLASS_HW_BASE_ADDR + 0x1ec)
#define PHY3_IPV6_CNT		(CLASS_HW_BASE_ADDR + 0x1f0)
#define PHY3_CSUM_ERR_CNT	(CLASS_HW_BASE_ADDR + 0x1f4)
#define PHY3_TTl_ERR_CNT	(CLASS_HW_BASE_ADDR + 0x1f8)
#define PHY3_UDP_CNT		(CLASS_HW_BASE_ADDR + 0x1d0)
#define PHY3_TCP_CNT		(CLASS_HW_BASE_ADDR + 0x1cc)
#define PHY3_ICMP_CNT		(CLASS_HW_BASE_ADDR + 0x1c4)
#define PHY3_IGMP_CNT		(CLASS_HW_BASE_ADDR + 0x1c8)

#define PHY4_RX_CNT		(CLASS_HW_BASE_ADDR + 0x1d4)
#define PHY4_TX_CNT		(CLASS_HW_BASE_ADDR + 0x1d8)
#define PHY4_L2F_CNT		(CLASS_HW_BASE_ADDR + 0x1dc)
#define PHY4_INF_CNT		(CLASS_HW_BASE_ADDR + 0x1e0)
#define PHY4_INM_CNT		(CLASS_HW_BASE_ADDR + 0x1e4)
#define PHY4_L3F_CNT		(CLASS_HW_BASE_ADDR + 0x1e8)
#define PHY4_IPV4_CNT		(CLASS_HW_BASE_ADDR + 0x1ec)
#define PHY4_IPV6_CNT		(CLASS_HW_BASE_ADDR + 0x1f0)
#define PHY4_CSUM_ERR_CNT	(CLASS_HW_BASE_ADDR + 0x1f4)
#define PHY4_TTl_ERR_CNT	(CLASS_HW_BASE_ADDR + 0x1f8)
#define PHY4_UDP_CNT		(CLASS_HW_BASE_ADDR + 0x1d0)
#define PHY4_TCP_CNT		(CLASS_HW_BASE_ADDR + 0x1cc)
#define PHY4_ICMP_CNT		(CLASS_HW_BASE_ADDR + 0x1c4)
#define PHY4_IGMP_CNT		(CLASS_HW_BASE_ADDR + 0x1c8)


#define PHY5_RX_CNT		(CLASS_HW_BASE_ADDR + 0x1d4)
#define PHY5_TX_CNT		(CLASS_HW_BASE_ADDR + 0x1d8)
#define PHY5_L2F_CNT		(CLASS_HW_BASE_ADDR + 0x1dc)
#define PHY5_INF_CNT		(CLASS_HW_BASE_ADDR + 0x1e0)
#define PHY5_INM_CNT		(CLASS_HW_BASE_ADDR + 0x1e4)
#define PHY5_L3F_CNT		(CLASS_HW_BASE_ADDR + 0x1e8)
#define PHY5_IPV4_CNT		(CLASS_HW_BASE_ADDR + 0x1ec)
#define PHY5_IPV6_CNT		(CLASS_HW_BASE_ADDR + 0x1f0)
#define PHY5_CSUM_ERR_CNT	(CLASS_HW_BASE_ADDR + 0x1f4)
#define PHY5_TTl_ERR_CNT	(CLASS_HW_BASE_ADDR + 0x1f8)
#define PHY5_UDP_CNT		(CLASS_HW_BASE_ADDR + 0x1d0)
#define PHY5_TCP_CNT		(CLASS_HW_BASE_ADDR + 0x1cc)
#define PHY5_ICMP_CNT		(CLASS_HW_BASE_ADDR + 0x1c4)
#define PHY5_IGMP_CNT		(CLASS_HW_BASE_ADDR + 0x1c8)

	/* l2policies stats */
typedef struct fp_l2policies_stats_s {
	/* policies match success count */
	uint32a  smac_match_cnt;
	uint32a  dmac_match_cnt;
	uint32a  etype_match_cnt;
	uint32a  vid_match_cnt;
	uint32a  cos_match_cnt;
	uint32a  dscp_match_cnt;
	uint32a  ipproto_match_cnt;
	uint32a  data_match_cnt;
	/* policies match failure count */
	uint32a  mismatch_cnt;
	uint32a  smac_mismatch_cnt;
	uint32a  dmac_mismatch_cnt;
	uint32a  vid_mismatch_cnt;
	uint32a  cos_mismatch_cnt;
	uint32a  dscp_mismatch_cnt;
	uint32a  ipproto_mismatch_cnt;
} fp_l2policies_stats_t; /* SIZE - 60 byttes */

#ifndef PE_STRUCT_SIZE
	/* mgmt module stats */
typedef struct fp_mgmt_stats_s {
	uint32a  stp_pkt_cnt;
	uint32a  igmp_pkt_cnt;
	uint32a  policies_succ;
	uint32a  policies_fail;
	fp_l2policies_stats_t  mgmt_policies;
} fp_mgmt_stats_t;

	/* inrate module stats */
typedef struct fp_inrate_stats_s {
	uint32a  green_pkt_cnt;
	uint32a  yellow_pkt_cnt;
	uint32a  red_flowctrl_pkt_cnt;
	uint32a  red_drop_pkt_cnt;
} fp_inrate_stats_t;

	/* outrate module stats */
typedef struct fp_outrate_stats_s {
	uint32a  sched_type;
	uint32a  enqueue_pkt_cnt;
	uint32a  dequeue_pkt_cnt;
	uint32a  drop_pkt_cnt;
} fp_outrate_stats_t;

#endif /*End of ifndef PE_STRUCT_SIZE*/

	/* ingress vlan module stats */
typedef struct fp_ingr_vlan_stats_s {
	uint32a  tag_pkt_cnt;
	uint32a  untag_pkt_cnt;
	uint32a  droptag_pkt_cnt;
	uint32a  dropuntag_pkt_cnt;
	uint32a  no_mship_cnt;
	uint32a  ingr_mship_match_cnt;
	uint32a  egr_mship_match_cnt;
	uint32a  ingr_mship_mismatch_cnt;
	uint32a  egr_mship_mismatch_cnt;
	fp_l2policies_stats_t  ingr_vlan_policies;
} fp_ingr_vlan_stats_t; /* SIZE - 96 bytes */

	/* egress vlan module stats */
typedef struct fp_egr_vlan_stats_s {
	uint32a  tag_pkt_cnt;
	uint32a  untag_pkt_cnt;
	uint32a  droptag_pkt_cnt;
	uint32a  dropuntag_pkt_cnt;
	uint32a  no_mship_cnt;
	uint32a  ingr_mship_match_cnt;
	uint32a  egr_mship_match_cnt;
	uint32a  ingr_mship_mismatch_cnt;
	uint32a  egr_mship_mismatch_cnt;
} fp_egr_vlan_stats_t; /* SIZE - 36 */

#ifndef PE_STRUCT_SIZE
	/* qos module stats */
typedef struct fp_qos_mapmask_stats_s {
	uint32a  cos_2primap_cnt;
	uint32a  dscp_2primap_cnt;
	uint32a  cos_2xmark_cnt;
	uint32a  dscp_2xmark_cnt;
	fp_l2policies_stats_t  qos_policies;
} fp_qos_mapmask_stats_t;
#endif /*End of ifndef PE_STRUCT_SIZE*/

	/* bridge module stats */
typedef struct fp_bridge_stats_s {
	uint32a  learn_pkt_cnt;
	uint32a  flood_pkt_cnt;
	uint32a  src_be_found;           /* source bridge entry found */
	uint32a  dst_be_found;           /* destination bridge entry found */
	uint32a  src_be_not_found;       /* source bridge entry not found */
	uint32a  dst_be_not_found;       /* destination bridge entry not found */
} fp_bridge_stats_t; /* SIZE - 24 bytes */

   /* all module stats */
typedef struct fp_all_modules_stats_s {
	uint32a  mgmt_pkt_cnt;
	uint32a  inrate_pkt_cnt;
	uint32a  speciall2_pkt_cnt;
	uint32a  outrate_pkt_cnt;
	uint32a  ingrvlan_pkt_cnt;
	uint32a  rx_pkt_cnt;
	uint32a  tx_pkt_cnt;
	uint32a  ip_pkt_cnt;
	uint32a udp_pkt_cnt;
	uint32a tcp_pkt_cnt;
	uint32a icmp_pkt_cnt;
	uint32a igmp_pkt_cnt;
	uint32a arp_pkt_cnt;
} fp_all_modules_stats_t; /* SIZE - 52 */

  /* switch statastics */
typedef struct fp_switch_stats_s {
	/* All module stats */
	fp_all_modules_stats_t  all;
#ifndef PE_STRUCT_SIZE
	/* mgmt module stats */
	fp_mgmt_stats_t  mgmt;

	/* inrate module stats */
	fp_inrate_stats_t  inrate_1;

	/* inrate module stats */
	fp_inrate_stats_t  inrate_2;

	/* outrate module stats */
	fp_outrate_stats_t  outrate;
#endif /*End of ifndef PE_STRUCT_SIZE*/

	/* ingress vlan module stats */
	fp_ingr_vlan_stats_t  ingrvlan;

	/* egress vlan module stats */
	fp_egr_vlan_stats_t  egrvlan;

#ifndef PE_STRUCT_SIZE
	/* qos module stats */
	fp_qos_mapmask_stats_t  qos;
#endif /*End of ifndef PE_STRUCT_SIZE*/

	/* special l2policies module stats */
	fp_l2policies_stats_t  speciall2;

	/* bridge module stats */
	fp_bridge_stats_t  bridge;

	uint16 parse_modules;
} fp_switch_stats_t; /* 52 + 96 + 36 + 60 + 24 + 2  = 270 */

//extern fp_switch_stats_t *sw_stats;
extern fp_switch_stats_t sw_stats;
extern void fp_policy_stats(int32a module_index, int32a policy_index);

#endif  /* _FP_STATS_H_ */

