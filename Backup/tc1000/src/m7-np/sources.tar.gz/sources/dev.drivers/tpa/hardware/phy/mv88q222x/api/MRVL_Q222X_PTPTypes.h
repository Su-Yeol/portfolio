/**
 * @file MRVL_Q222X_PTPTypes.h
 * @brief Q222X PTP Types Header File
 * Header file contains PTP types and defines of Marvell Q222X
  *
 * @par Copyright and Version
 * See MRVL_Q222X_Copyright_and_Version.h
 */

#ifndef MRVL_Q222X_PTP_TYPES_H
#define MRVL_Q222X_PTP_TYPES_H

#include "MRVL_Q222X_Types.h"

/* device address */
#define MRVL_Q222X_PTP_BASE_DEV               0x1FU    /* PTP module register device address */
#define MRVL_Q222X_NT_CORE_DEV                0x4U     /* nt_core submodule*/

/* Register base address for different module */
#define MRVL_Q222X_PTP_PORT_0_REG_ADDR        0xA800U
#define MRVL_Q222X_PTP_TAI_REG_ADDR           0xA840U
#define MRVL_Q222X_PTP_GLOBAL_REG_ADDR        0xA860U

/* PTP port register address offset relative to base address */
#define MRVL_Q222X_PTP_PORT_CFG_REG_1         0x0U
#define MRVL_Q222X_PTP_PORT_CFG_REG_2         0x1U
#define MRVL_Q222X_PTP_PORT_CFG_REG_3         0x2U
#define MRVL_Q222X_PTP_PORT_ARR0_TS_STATUS    0x8U
#define MRVL_Q222X_PTP_PORT_ARR1_TS_STATUS    0xCU
#define MRVL_Q222X_PTP_PORT_DEP_TS_STATUS     0x10U

/* PTP TAI register address offset relative to base address */
#define MRVL_Q222X_PTP_TAI_GLB_TIME_LSB       0xEU
#define MRVL_Q222X_PTP_TAI_GLB_TIME_MSB       0xFU

/* PTP global register address offset relative to base address */
#define MRVL_Q222X_PTP_GLB_MSG_TYPE_TS_EN     0x1U     /* Message Type TS Enables */
#define MRVL_Q222X_PTP_GLB_CFG_IDR_RW         0x7U     /* PTP global config indirect read,write */
#define MRVL_Q222X_PTP_GLB_RD_PLUS_CMD        0xEU     /* Read plus command */
#define MRVL_Q222X_PTP_GLB_RD_PLUS_DATA       0xFU     /* Read plus data */
#define MRVL_Q222X_PTP_GLB_TOD_LOAD_P_LSB     0x10U    /* TOD load point [15:0] */
#define MRVL_Q222X_PTP_GLB_TOD_LOAD_P_MSB     0x11U    /* TOD load point [31:16] */
#define MRVL_Q222X_PTP_GLB_TOD_CTRL           0x12U    /* TOD Control */
#define MRVL_Q222X_PTP_GLB_TOD_NANO_LSB       0x13U    /* TOD Nano Seconds [15:0] */
#define MRVL_Q222X_PTP_GLB_TOD_NANO_MSB       0x14U    /* TOD Nano Seconds [31:16] */
#define MRVL_Q222X_PTP_GLB_TOD_SEC_LSB        0x15U    /* TOD Seconds [15:0] */
#define MRVL_Q222X_PTP_GLB_TOD_SEC_MSB1       0x16U    /* TOD Seconds [31:16] */
#define MRVL_Q222X_PTP_GLB_TOD_SEC_MSB2       0x17U    /* TOD Seconds [47:32] */
#define MRVL_Q222X_PTP_GLB_1722_NANO_LSB1     0x18U    /* 1722 Nano Seconds [15:0] */
#define MRVL_Q222X_PTP_GLB_1722_NANO_LSB2     0x19U    /* 1722 Nano Seconds [31:16] */
#define MRVL_Q222X_PTP_GLB_1722_NANO_MSB1     0x1AU    /* 1722 Nano Seconds [47:32] */
#define MRVL_Q222X_PTP_GLB_1722_NANO_MSB2     0x1BU    /* 1722 Nano Seconds [63:48] */
#define MRVL_Q222X_PTP_GLB_TOD_COMP_LSB       0x1CU    /* TOD/1772 Compensation [15:0] */
#define MRVL_Q222X_PTP_GLB_TOD_COMP_MSB       0x1DU    /* TOD/1772 Compensation [31:16] */
#define MRVL_Q222X_PTP_GLB_1PPS_CTRL          0x1EU    /* 1PPS Control */

/* prm_mpm_top submodule module, register absolute address */
#define MRVL_Q222X_PM_TOP_PTP_CTRL1           0xA001U
#define MRVL_Q222X_PM_TOP_MPTP_CFG            0xA008U
#define MRVL_Q222X_PM_TOP_PTP_SPEED_OW        0xA013U

/* nt_core submodule, register absolute address */
#define MRVL_Q222X_NT_CORE_WAKE_GPIO_EN       0x821BU
#define MRVL_Q222X_NT_CORE_PTP_CTRL_REG1      0x87F0U

/* Constant used in PTP API */
#define MRVL_Q222X_PTP_WAIT_COUNT             100U
#define MRVL_Q222X_PTP_TOD_STORE_COMP         0x2U     /*  TOD Op Code, Store Comp register to selected TimeArray  */
#define MRVL_Q222X_PTP_TOD_STORE_ALL          0x3U     /*  TOD Op Code, Store all PTP TimeArray register to selected TimeArray */

/**
 * @brief Define PTP supported time array index Enum
 *
 */
typedef enum
{
	MRVL_Q222X_PTP_TIME_ARRAY_INDEX_0 = 0,
	MRVL_Q222X_PTP_TIME_ARRAY_INDEX_1 = 1
} MRVL_Q222X_PTP_TIME_ARRAY_INDEX;

/**
 * @brief Define PTP Time Array Struct
 *
 */
typedef struct
{
	MRVL_APHY_U32  todLoadPoint;		/*!< Time of Day Load Point */
	MRVL_APHY_BOOL clkActive;			/*!< Clock Active bit, whether Time Array will start keeping time */
	MRVL_APHY_U8   domainNumber;		/*!< Domain Number, to be associated with the selected Time Array */
	MRVL_APHY_U32  todNanoseconds;		/*!< Time Array Time of Day, Nano second 32 bits */
	MRVL_APHY_U32  todSecondsLow;		/*!< Time Array Time of Day, second portion 0-31 bits */
	MRVL_APHY_U16  todSecondsHigh;		/*!< Time Array Time of Day, second portion 32-47 bits */
	MRVL_APHY_U32  nanoseconds1722Low;	/*!< Time Array 1722 Time of Day in Nano seconds 0-31 bits */
	MRVL_APHY_U32  nanoseconds1722High;	/*!< Time Array 1722 Time of Day in Nano seconds 32-63 bits */
	MRVL_APHY_U32  todCompensation;		/*!< Time Array Time of Day Compensation 32 bits */
}MRVL_Q222X_PTP_TIME_ARRAY;

/**
 * @brief Define PTP mode Enum
 *
 */
typedef enum
{
	MRVL_Q222X_PTP_MODE_BOUNDARY = 0x0,		/*!< Boundary clock */
	MRVL_Q222X_PTP_MODE_PEER_TO_PEER = 0x1,	/*!< Peer to peer transparent clock */
	MRVL_Q222X_PTP_MODE_END_TO_END = 0x2	/*!< End to end transparent clock */
}MRVL_Q222X_PTP_MODE;

/**
 * @brief Define PTP 802.1AS mode Enum
 *
 */
typedef enum
{
	MRVL_Q222X_PTP_RELAY_MODE_END_STATION = 0,	/*!< end-station mode for 802.1AS */
	MRVL_Q222X_PTP_RELAY_MODE_RELAY = 1			/*!< relay mode for 802.1AS */
} MRVL_Q222X_PTP_RELAY_MODE;

/**
 * @brief Define PTP step emum
 *
 */
typedef enum
{
	MRVL_Q222X_PTP_STEP_TWO_STEP = 0x0,
	MRVL_Q222X_PTP_STEP_ONE_STEP = 0x1
}MRVL_Q222X_PTP_STEP;

/**
 * @brief Define PTP timestamp to be read Enum
 *
 */
typedef enum
{
	MRVL_Q222X_PTP_TIMESTAMP_ARR0_TIME = 0x0,	/*!< PTP Arrival Time 0 */
	MRVL_Q222X_PTP_TIMESTAMP_ARR1_TIME = 0x1,	/*!< PTP Arrival Time 1 */
	MRVL_Q222X_PTP_TIMESTAMP_DEP_TIME = 0x2		/*!< PTP Departure Time */
}MRVL_Q222X_PTP_TIMESTAMP_SELECT;

/**
 * @brief Define PTP port interrupt status Enum for timestamp
 *
 */
typedef enum
{
	MRVL_Q222X_PTP_INT_STATUS_NORMAL = 0x0,		/*!< No error condition occurred */
	MRVL_Q222X_PTP_INT_STATUS_OVERWRITE = 0x1, 	/*!< PTP logic has to process more than one PTP frame that needs time stamping before the current read. Only the latest one is saved. */
	MRVL_Q222X_PTP_INT_STATUS_DROP = 0x2 		/*!< PTP logic has to process more than one PTP frame that needs time stamping before the current read. Only the oldest one is saved. */
}MRVL_Q222X_PTP_INT_STATUS;

/**
 * @brief Define PTP port timestamp status Enum
 *
 */
typedef struct
{
	MRVL_APHY_BOOL isValid;		/*!< Time stamp is valid */
	MRVL_APHY_U32 timeStamped;	/*!< Time stamp value of a PTP frame that needs to be time stamped */
	MRVL_APHY_U16 ptpSeqId;		/*!< Sequence ID of the frame whose time stamp information has been captured */
	MRVL_Q222X_PTP_INT_STATUS status;		/*!< Time stamp error status */
} MRVL_Q222X_PTP_TIMESTAMP;

/**
 * @brief Define PTP 1PPS Pulse parameters Struct
 *
 */
typedef struct
{
	MRVL_APHY_U8 ptpPulseWidth;		/*!< Pulse width for the 1 pulse per second on the second signal */
	MRVL_APHY_U8 ptp1ppsWidthRange;	/*!< Pulse width range for the 1 pulse per second on the second signal */
	MRVL_APHY_U8 ptp1ppsPhase;		/*!< Phase of the 1 pulse per second on the second signal */
	MRVL_APHY_U8 ptp1ppsSelect;		/*!< Select for the 1 pulse per second on the second signal */
} MRVL_Q222X_PTP_1PPS_CONTROL;


/******************************************************************************
 *    Below struct/enmu is used for PTP static function
 ******************************************************************************/

/**
 * @brief Define PTP SPEC type Enum
 *
 */
typedef enum
{
	MRVL_Q222X_PTP_SPEC_IEEE_1588 = 0x0,      /*!< IEEE 1588 */
	MRVL_Q222X_PTP_SPEC_IEEE_802_1AS = 0x1,   /*!<  IEEE 802.1as */
	MRVL_Q222X_PTP_SPEC_UNKNOW
}MRVL_Q222X_PTP_SPEC;

/**
 * @brief Define PTP read plus types Enum
 *
 */
typedef enum
{
	MRVL_Q222X_PTP_READ_PLUS_TYPE_TAI = 0xE,
	MRVL_Q222X_PTP_READ_PLUS_TYPE_GLOBAL = 0xF,
	MRVL_Q222X_PTP_READ_PLUS_TYPE_P0 = 0,
}MRVL_Q222X_PTP_READ_PLUS_TYPE;

/**
 * @brief Define PTP read plus value length Enum
 *
 */
typedef enum
{
	MRVL_Q222X_PTP_READ_PLUS_SIZE_16 = 1,
	MRVL_Q222X_PTP_READ_PLUS_SIZE_32 = 2,
	MRVL_Q222X_PTP_READ_PLUS_SIZE_64 = 4
}MRVL_Q222X_PTP_READ_PLUS_SIZE;

#endif  /* MRVL_Q222X_PTP_TYPES_H */
