// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          platform.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    Functions to handle different hardware platforms
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

#include <string.h>  /* for memset */

#include "reg_hal.h"		/* brings in "InitBaseAddr()" */
#include "platform.h"
#include "global_base_address.h"
#include "global_address_map_fpga.h"
#include "xpcs_define.h"
#include "asic.h"

#define USE_MARVELL_API
#ifdef USE_MARVELL_API
#include "MRVL_Q222X_API.h"
#include "MRVL_MVQ3244_API.h"
//#define USE_5G_PHY //if disabled, use 5g switch
#endif

//#define GMAC_SPD_100M
//#define GMAC_SPD_10M
//#define GMAC_LOOPBACK_MODE

#define USE_DB_BUFFER_FPGA_DRAM
#define FPGA_DRAM_START_ADDR (0x80000000)

#ifdef PLATFORM_FPGA_CM7
#define FPGA_EPP_START_ADDR (0x46000000)
#endif

#ifdef PLATFORM_TCN1000_CM7
#define TCN1000_EPP_START_ADDR (0x46000000)
#endif

#define BYTE_ALIGN_BIT_MASK (8) /*8 byte align */
static unsigned char *fpga_dram_base = NULL;

#ifdef USE_DB_BUFFER_FPGA_DRAM
static uint32 used_offset=0;
#endif

#ifdef __linux__
#define ZERO_BUFFER_SIZE (1024*1024)
static unsigned char *zero_buffer = NULL;

#define COPY_SIZE_ALIGN (2)
#define COPY_BUFFER_SIZE (1024*4)
static unsigned char *copy_buffer = NULL;
#endif

/* TPA config register */
#define TPA_CFG_SWRESETN 0xD30004
#define GMAC0_CFG0       0xD31000
#define GMAC0_CFG1       0xD31004
#define GMAC0_DLY_CFG_0  0xD32000
#define GMAC0_DLY_CFG_1  0xD32004
#define GMAC0_DLY_CFG_2  0xD32008
#define GMAC0_DLY_CFG_3  0xD3200C
#define GMAC0_DLY_CFG_4  0xD32010
#define GMAC1_CFG0       0xD33000
#define GMAC1_CFG1       0xD33004
#define GMAC1_DLY_CFG_0  0xD34000
#define GMAC1_DLY_CFG_1  0xD34004
#define GMAC1_DLY_CFG_2  0xD34008
#define GMAC1_DLY_CFG_3  0xD3400C
#define GMAC1_DLY_CFG_4  0xD34010

/* function prototype */
static void tpa_config(void);
static void display_safety_func_regs(void);
static void display_partition_3_5_regs(void);
static void display_mac_phy_reg(void);
static void init_realtek_phy(void);
static void display_realtek_phy_status(void);
static void init_marvell_phy_100M__(unsigned int isMaster);
static void display_marvell_phy_status(void);

static void init_gmac(unsigned int gmac_idx);
static void init_gmac_alt(unsigned int gmac_idx);
static void init_xgmac(unsigned int gmac_idx);

static void set_pll(void);
static void register_rw_test(void);
void tpa_clock_setting(void);
void set_tpa_csr(void);
void tpa_gpio_setting(void);
void phy_1G_reset(void);


static void tpa_config(void)
{
	unsigned long addr;
	unsigned int val;


	TPA_D("[%s]\n", __func__);

	/* set GMAC0 Configuration */
	TPA_D("[%s] set GMAC0 Configuration\n", __func__);
	addr = GMAC0_CFG1; // GMAC0_CFG1 CLKEN to 1
	val = RegRead(addr);
	TPA_D(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(1<<28); //28bit 1 mask
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
	TPA_D("\n");

	addr = GMAC0_CFG1; // GMAC0_CFG1 RGMII INFSEL
	val = RegRead(addr);
	TPA_D(" read addr[%08lx] val[%08x]\n", addr, val);
	val = (val&(~(0x7<<24)))|(0x1<<24); //[26:24] 001b
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
	TPA_D("\n");

	addr = GMAC0_CFG0; // GMAC0_CFG1 TR,RR enable
	val = RegRead(addr);
	TPA_D(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(1<<28)|(1<<12);
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
	TPA_D("\n");

	addr = GMAC0_CFG1; // GMAC0_CFG1 CLKEN to 0
	val = RegRead(addr);
	TPA_D(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val&(~(1<<28)); //28bit 0 mask
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
	TPA_D("\n");

	addr = GMAC0_CFG0; // GMAC0_CFG0 TxDIV, RxDIV set
	val = RegRead(addr);
	TPA_D(" read addr[%08lx] val[%08x]\n", addr, val);

	#ifdef GMAC_SPD_100M
	val = val&~((0x3F<<20)|(0x3F<<4));
	val = val|(1<<22); //22bit 1 mask (25:20) 0->4 //25MHz
	//val = val|(1<<6);  // (9:4) 0->4 //25MHz
	#elif defined(GMAC_SPD_10M)
	val = val&~((0x3F<<20)|(0x3F<<4));
	val = val|(0x31<<20); //22bit 1 mask (25:20) 49 = 0x31 //2.5MHz = 125/(49+1)
	val = val|(0x31<<4);  //               (9:4) 49 = 0x31 //2.5MHz = 125/(49+1)
	#else
	val = val&~((0x3F<<20)|(0x3F<<4)); //[25:20] 0, [9:4] 0 //125MHz
	#endif
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
	TPA_D("\n");

	addr = GMAC0_CFG1; // GMAC0_CFG1 CLKEN to 1
	val = RegRead(addr);
	TPA_D(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(1<<28); //28bit 1 mask
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
	TPA_D("\n");

	addr = GMAC0_CFG1; // GMAC0_CFG1 TXCLKOEN to 1
	val = RegRead(addr);
	TPA_D(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(1<<16); //16bit 1 mask
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
	TPA_D("\n");

	addr = TPA_CFG_SWRESETN; // TPA CFG GMAC0 swreset
	val = RegRead(addr);
	TPA_D(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val&(~(1<<1)); //1bit 0 mask
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
	udelay(100);
	val = val|(1<<1); //1bit 1 mask
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);

	/* set Delay control registers */
	addr = GMAC0_DLY_CFG_0; // Delay control register 0
	val = 0x10109010;
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);

#if 0
	addr = GMAC0_DLY_CFG_1; // Delay control register 1
	val = 0x00000000;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
#endif
	addr = GMAC0_DLY_CFG_2; // Delay control register 2
	val = 0x10100010; // cfg_rxclki_inv1 0
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
#if 0
	addr = GMAC0_DLY_CFG_3; // Delay control register 3
	val = 0x00000000;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = GMAC0_DLY_CFG_4; // Delay control register 4
	val = 0x00000000;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
#endif

	/* set GMAC1 Configuration */
	TPA_D("[%s] set GMAC1 Configuration\n", __func__);
	addr = GMAC1_CFG1; // GMAC1_CFG1 CLKEN to 1
	val = RegRead(addr);
	TPA_D(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(1<<28); //28bit 1 mask
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
	TPA_D("\n");

	addr = GMAC1_CFG1; // GMAC1_CFG1 RGMII INFSEL
	val = RegRead(addr);
	TPA_D(" read addr[%08lx] val[%08x]\n", addr, val);
	val = (val&(~(0x7<<24)))|(0x1<<24); //[26:24] 001b
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
	TPA_D("\n");

	addr = GMAC1_CFG0; // GMAC1_CFG1 TR,RR enable
	val = RegRead(addr);
	TPA_D(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(1<<28)|(1<<12);
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
	TPA_D("\n");

	addr = GMAC1_CFG1; // GMAC1_CFG1 CLKEN to 0
	val = RegRead(addr);
	TPA_D(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val&(~(1<<28)); //28bit 0 mask
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
	TPA_D("\n");

	addr = GMAC1_CFG0; // GMAC1_CFG0 TxDIV, RxDIV set
	val = RegRead(addr);
	TPA_D(" read addr[%08lx] val[%08x]\n", addr, val);
	#ifdef GMAC_SPD_100M
	val = val&~((0x3F<<20)|(0x3F<<4));
	val = val|(1<<22); //22bit 1 mask (25:20) 0->4 //25MHz
	//val = val|(1<<6);  // (9:4) 0->4 //25MHz
	#elif defined(GMAC_SPD_10M)
	val = val&~((0x3F<<20)|(0x3F<<4));
	val = val|(0x31<<20); //22bit 1 mask (25:20) 49 = 0x31 //2.5MHz = 125/(49+1)
	val = val|(0x31<<4);  //               (9:4) 49 = 0x31 //2.5MHz = 125/(49+1)
	#else
	val = val&~((0x3F<<20)|(0x3F<<4)); //[25:20] 0, [9:4] 0 //125MHz
	#endif
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
	TPA_D("\n");

	addr = GMAC1_CFG1; // GMAC1_CFG1 CLKEN to 1
	val = RegRead(addr);
	TPA_D(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(1<<28); //28bit 1 mask
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
	TPA_D("\n");

	addr = GMAC1_CFG1; // GMAC1_CFG1 TXCLKOEN to 1
	val = RegRead(addr);
	TPA_D(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(1<<16); //16bit 1 mask
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
	TPA_D("\n");

	addr = TPA_CFG_SWRESETN; // TPA CFG GMAC0 swreset
	val = RegRead(addr);
	TPA_D(" read addr[%08lx] val[%08x]\n", addr, val);
	val = val&(~(2<<1)); //2bit 0 mask
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
	udelay(100);
	val = val|(2<<1); //2bit 1 mask
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);

	/* set Delay control registers */
	addr = GMAC1_DLY_CFG_0; // Delay control register 0
	val = 0x10109010;
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
#if 0
	addr = GMAC1_DLY_CFG_1; // Delay control register 1
	val = 0x00000000;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
#endif
	addr = GMAC1_DLY_CFG_2; // Delay control register 2
	val = 0x10100010; // cfg_rxclki_inv1 0
	RegWrite(addr, val);
	TPA_D("write addr[%08lx] val[%08x]\n", addr, val);
#if 0
	addr = GMAC1_DLY_CFG_3; // Delay control register 3
	val = 0x00000000;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = GMAC1_DLY_CFG_4; // Delay control register 4
	val = 0x00000000;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
#endif

}

static void display_safety_func_regs(void)
{
	unsigned long addr;
	//unsigned int val;

	/* check safty function disable */
#ifdef DISABLE_EPP_SAFETY
	printk("\n");
	printk("[%s] safety function disabled.\n", __func__);
#else
	printk("\n");
	printk("[%s] safety function enabled.\n", __func__);
#endif
	addr = WSP_FAIL_STOP_MODE_EN_ADDR;
	printk("read addr[%08lx] val[%08x] EPP_GLOBAL_CSR WSP_FAIL_STOP_MODE_EN_ADDR \n", addr, RegRead(addr));

	addr = PART2_GLOBAL_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x] PART2 WSP_FAIL_STOP_MODE_EN\n", addr, RegRead(addr));
	addr = PART2_GLOBAL_BASE_ADDR+0x8;
	printk("read addr[%08lx] val[%08x] PART2 WSP_EMAC_CONFIG_EN_FAIL_STOP_MODE\n", addr, RegRead(addr));
	addr = PART2_GLOBAL_BASE_ADDR+0xC;
	printk("read addr[%08lx] val[%08x] PART2 WSP_EMAC_REG2_CONFIG_EN_FAIL_STOP_MODE\n", addr, RegRead(addr));
	addr = PART2_GLOBAL_BASE_ADDR+0x78;
	printk("read addr[%08lx] val[%08x] PART2 WSP_PARITY_INT_EN\n", addr, RegRead(addr));
	addr = PART2_GLOBAL_BASE_ADDR+0x80;
	printk("read addr[%08lx] val[%08x] PART2 WSP_PARITY_REG2_INT_EN\n", addr, RegRead(addr));

#if 0
	addr = EGPI1_BASE_ADDR+0x0;
	printk("read addr[%08lx] val[%08x] P2 EGPI1 GPI_VERSION\n", addr, RegRead(addr));
	addr = EGPI1_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x] P2 EGPI1 GPI_CTRL\n", addr, RegRead(addr));
	addr = EGPI1_BASE_ADDR+0x8;
	printk("read addr[%08lx] val[%08x] P2 EGPI1 GPI_RX_CONFIG\n", addr, RegRead(addr));

	addr = EGPI4_BASE_ADDR+0x0;
	printk("read addr[%08lx] val[%08x] P3 EGPI4 GPI_VERSION\n", addr, RegRead(addr));
	addr = EGPI4_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x] P3 EGPI4 GPI_CTRL\n", addr, RegRead(addr));
	addr = EGPI4_BASE_ADDR+0x8;
	printk("read addr[%08lx] val[%08x] P3 EGPI4 GPI_RX_CONFIG\n", addr, RegRead(addr));
#endif

#if 0
	addr = PART3_GLOBAL_BASE_ADDR+0x4;
	val = 0;
	RegWrite(addr, val);
	printk("writeaddr[%08lx] val[%08x] PART3 WSP_FAIL_STOP_MODE_EN\n", addr, 0);
	printk("read addr[%08lx] val[%08x] PART3 WSP_FAIL_STOP_MODE_EN\n", addr, RegRead(addr));
	addr = PART3_GLOBAL_BASE_ADDR+0x78;
	val = 0;
	RegWrite(addr, val);
	printk("writeaddr[%08lx] val[%08x] PART3 WSP_PARITY_INT_EN\n", addr, 0);
	printk("read addr[%08lx] val[%08x] PART3 WSP_PARITY_INT_EN\n", addr, RegRead(addr));
	addr = PART3_GLOBAL_BASE_ADDR+0x80;
	val = 0;
	RegWrite(addr, val);
	printk("writeaddr[%08lx] val[%08x] PART3 WSP_PARITY_REG2_INT_EN\n", addr, 0);
	printk("read addr[%08lx] val[%08x] PART3 WSP_PARITY_REG2_INT_EN\n", addr, RegRead(addr));
#endif

	addr = PART4_GLOBAL_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x] PART4 WSP_FAIL_STOP_MODE_EN\n", addr, RegRead(addr));
	addr = PART4_GLOBAL_BASE_ADDR+0x8;
	printk("read addr[%08lx] val[%08x] PART4 WSP_EMAC_CONFIG_EN_FAIL_STOP_MODE\n", addr, RegRead(addr));
	addr = PART4_GLOBAL_BASE_ADDR+0xC;
	printk("read addr[%08lx] val[%08x] PART4 WSP_EMAC_REG2_CONFIG_EN_FAIL_STOP_MODE\n", addr, RegRead(addr));
	addr = PART4_GLOBAL_BASE_ADDR+0x78;
	printk("read addr[%08lx] val[%08x] PART4 WSP_PARITY_INT_EN\n", addr, RegRead(addr));
	addr = PART4_GLOBAL_BASE_ADDR+0x80;
	printk("read addr[%08lx] val[%08x] PART4 WSP_PARITY_REG2_INT_EN\n", addr, RegRead(addr));

	addr = PART5_GLOBAL_BASE_ADDR+0x4;
	RegWrite(addr, 0);
	printk("read addr[%08lx] val[%08x] PART5 WSP_FAIL_STOP_MODE_EN\n", addr, RegRead(addr));
	addr = PART5_GLOBAL_BASE_ADDR+0x8;
	RegWrite(addr, 0);
	printk("read addr[%08lx] val[%08x] PART5 WSP_EMAC_CONFIG_EN_FAIL_STOP_MODE\n", addr, RegRead(addr));
	addr = PART5_GLOBAL_BASE_ADDR+0xC;
	RegWrite(addr, 0);
	printk("read addr[%08lx] val[%08x] PART5 WSP_EMAC_REG2_CONFIG_EN_FAIL_STOP_MODE\n", addr, RegRead(addr));
	addr = PART5_GLOBAL_BASE_ADDR+0x78;
	RegWrite(addr, 0);
	printk("read addr[%08lx] val[%08x] PART5 WSP_PARITY_INT_EN\n", addr, RegRead(addr));
	addr = PART5_GLOBAL_BASE_ADDR+0x80;
	RegWrite(addr, 0);
	printk("read addr[%08lx] val[%08x] PART5 WSP_PARITY_REG2_INT_EN\n", addr, RegRead(addr));

}

static void display_partition_3_5_regs(void)
{

#if 0
	unsigned long addr;
	unsigned int val;

	printk("\n");
	printk("[%s] partition 3 test.\n", __func__);
	addr = EGPI4_BASE_ADDR+0x0;
	printk("read addr[%08lx] val[%08x] P3 EGPI4 GPI_VERSION\n", addr, RegRead(addr));
	addr = EGPI4_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x] P3 EGPI4 GPI_CTRL\n", addr, RegRead(addr));
	addr = EGPI4_BASE_ADDR+0x8;
	printk("read addr[%08lx] val[%08x] P3 EGPI4 GPI_RX_CONFIG\n", addr, RegRead(addr));
#endif

#if 0
	printk("\n");
	printk("[%s] partition 5 R/W test.\n", __func__);
	addr = IPSEC_GPI_BASE_ADDR+0x0;
	printk("read addr[%08lx] val[%08x] P5 IPSEC_GPI GPI_VERSION\n", addr, RegRead(addr));
	addr = IPSEC_GPI_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x] P5 IPSEC_GPI GPI_CTRL\n", addr, RegRead(addr));
	addr = IPSEC_GPI_BASE_ADDR+0x8;
	printk("read addr[%08lx] val[%08x] P5 IPSEC_GPI GPI_RX_CONFIG\n", addr, RegRead(addr));

	addr = IPSEC_CSR_BASE_ADDR+0x0;
	printk("read addr[%08lx] val[%08x] P5 IPSEC IPSEC_VERSION\n", addr, RegRead(addr));
	addr = IPSEC_CSR_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x] P5 IPSEC IPSEC_INT_SRC\n", addr, RegRead(addr));
	addr = IPSEC_CSR_BASE_ADDR+0x14;
	val = 0xaa55aa55;
	RegWrite(addr, val);
	printk("writeaddr[%08lx] val[%08x] P5 IPSEC PSEC_EG_MTU_SIZE\n", addr, val);
	printk("read addr[%08lx] val[%08x] P5 IPSEC PSEC_EG_MTU_SIZE\n", addr, RegRead(addr));
#endif

}

static void display_mac_phy_reg(void)
{
	unsigned long addr;
	unsigned int val;

	/* check GMAC1 Identification and mac address write */
	printk("\n");
	printk("[%s] check GMAC1.\n", __func__);

	addr = EMAC1_BASE_ADDR+0x0;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_BASE_ADDR+0x110;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_BASE_ADDR+0x11C;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_BASE_ADDR+0x120;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_BASE_ADDR+0x124;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_BASE_ADDR+0x128;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));

	addr = EMAC1_MAC_ADDR0_HIGH;
	RegWrite(addr, 0); /* clear reg */
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_MAC_ADDR0_LOW;
	RegWrite(addr, 0); /* clear reg */
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_MAC_ADDR0_HIGH;
	val = 0x00001234;
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	RegWrite(addr, val);
	addr = EMAC1_MAC_ADDR0_LOW;
	val = 0x567890AB;
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	RegWrite(addr, val);
	addr = EMAC1_MAC_ADDR0_HIGH;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_MAC_ADDR0_LOW;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));

	/* check GMAC0 Identification and mac address write */
	printk("\n");
	printk("[%s] check GMAC0.\n", __func__);

	addr = EMAC2_BASE_ADDR+0x0;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_BASE_ADDR+0x4;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_BASE_ADDR+0x110;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_BASE_ADDR+0x11C;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_BASE_ADDR+0x120;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_BASE_ADDR+0x124;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_BASE_ADDR+0x128;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));

	addr = EMAC2_MAC_ADDR0_HIGH;
	RegWrite(addr, 0); /* clear reg */
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_MAC_ADDR0_LOW;
	RegWrite(addr, 0); /* clear reg */
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_MAC_ADDR0_HIGH;
	val = 0x00001234;
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	RegWrite(addr, val);
	addr = EMAC2_MAC_ADDR0_LOW;
	val = 0x567890CD;
	printk("write addr[%08lx] val[%08x]\n", addr, val);
	RegWrite(addr, val);
	addr = EMAC2_MAC_ADDR0_HIGH;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC2_MAC_ADDR0_LOW;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));


	/* check GMAC 1 again */
	addr = EMAC1_MAC_ADDR0_HIGH;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));
	addr = EMAC1_MAC_ADDR0_LOW;
	printk("read addr[%08lx] val[%08x]\n", addr, RegRead(addr));

	/* check phy r/w */
	{
		unsigned int emac_idx;
		unsigned int phy_addr;
		unsigned int reg_addr;
		unsigned int dev_addr;
		//unsigned int val;

#if 1
		/* check PHY GMAC1 Identification and mac addresss write */
		printk("\n");
		printk("[%s] check GMA1 PHY RTL8211.\n", __func__);
		emac_idx = 0;
		phy_addr = 0;
		printk("[%s] mdio access emac_idx=%d, phy_addr=%d\n", __func__, emac_idx, phy_addr);
		reg_addr = 2;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);
		reg_addr = 3;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);
		reg_addr = 1;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);
		reg_addr = 0xF;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);

		emac_idx = 0;
		phy_addr = 1;
		printk("[%s] mdio access emac_idx=%d, phy_addr=%d\n", __func__, emac_idx, phy_addr);
		reg_addr = 2;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);
		reg_addr = 3;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);
		reg_addr = 1;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);
		reg_addr = 0xF;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);
#endif

		/* check PHY GMAC0 Identification and mac addresss write */
		printk("\n");
		printk("[%s] check GMAC0 PHY MARVELL 88Q2210.\n", __func__);

		emac_idx = 1;
		phy_addr = 5;
		printk("[%s] mdio access emac_idx=%d, phy_addr=%d\n", __func__, emac_idx, phy_addr);
		reg_addr = 2;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);
		reg_addr = 3;
		val = MdioRegRead(emac_idx, phy_addr, reg_addr);

		dev_addr = 1;
		reg_addr = 0x2;
		val = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);

		dev_addr = 1;
		reg_addr = 0x3;
		val = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
	}
}

/* this code from linux up stream driver */
static void init_realtek_phy(void)
{
	int ret;
	unsigned int emac_idx;
	unsigned int phy_addr;
	unsigned int reg_addr;
	unsigned int phy_data;
	//unsigned int old_page;

	printk("\n");
	printk("[%s] start\n", __func__);

	emac_idx = 0;
	phy_addr = 1;

//read phy 0x0, addr 0x1F, data 0x0
//write phy 0x0, addr 0x1F, data 0x07                             PageSel: 7:Extension page
//write phy 0x0, addr 0x1E, data 0xA4                             Extension Page Select : 0xA4
//read phy 0x0, addr 0x1C, data 0x8577                                ????    not indata sheet
//write phy 0x0, addr 0x1C, data 0x8571                               ????    not indata sheet
//write phy 0x0, addr 0x1F, data 0x0000                               PageSel: 0:Page 0 (restore page)

#if 0
	/* rtl8211e_config_init() */
	reg_addr = 0x1F; //RTL821x_PAGE_SELECT
	phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);
	old_page = phy_data;

	reg_addr = 0x1F; //RTL821x_PAGE_SELECT
	phy_data = 0x07;
	ret = MdioRegWrite(emac_idx, phy_addr, reg_addr, phy_data);

	reg_addr = 0x1E; // RTL821x_EXT_PAGE_SELECT
	phy_data = 0xA4;
	ret = MdioRegWrite(emac_idx, phy_addr, reg_addr, phy_data);

	reg_addr = 0x1C;
	phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);
#if 1
	phy_data &= ~(0x6); //clear RTL8211E_TX_DELAY | RTL8211E_RX_DELAY
#else
	phy_data |= 0x6; //set RTL8211E_TX_DELAY | RTL8211E_RX_DELAY
#endif
	ret = MdioRegWrite(emac_idx, phy_addr, reg_addr, phy_data);

	reg_addr = 0x1F; //RTL821x_PAGE_SELECT, restore page
	phy_data = old_page;
	ret = MdioRegWrite(emac_idx, phy_addr, reg_addr, phy_data);
#endif

	/* phy_start_aneg() */
	/* genphy_config_advert */
	reg_addr = 0x4; // MII_ADVERTISE
	phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);
	phy_data =  0x0DE1; //set ADVERTISE_ALL | ADVERTISE_100BASE4 | ADVERTISE_PAUSE_CAP | ADVERTISE_PAUSE_ASYM
	ret = MdioRegWrite(emac_idx, phy_addr, reg_addr, phy_data);

	reg_addr = 0x9;
	phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);
	phy_data = 0x0300;
	ret = MdioRegWrite(emac_idx, phy_addr, reg_addr, phy_data);

	reg_addr = 0x0;
	phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);
	phy_data = 0x1340;
	ret = MdioRegWrite(emac_idx, phy_addr, reg_addr, phy_data);

	/* supress error 'variable set but not used' */
	(void)ret;
}

static void display_realtek_phy_status(void)
{
	//int ret;
	unsigned int emac_idx;
	unsigned int phy_addr;
	unsigned int reg_addr;
	unsigned int phy_data;

	printk("\n");
	printk("[%s] start\n", __func__);

	emac_idx = 0;
	phy_addr = 1;

	/* phy_check_link_status() */
	reg_addr = 0x0;
	phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);

	//bit 2 : link status

	reg_addr = 0x1;
	phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);

//	bit14: 1: Local PHY configuration resolved to MASTER
//	bit13: 1: Local Receiver OK
//	bit12: 1: Remote Receiver OK
//	bit11: 1: Link Partner is capable of 1000Base-T full duplex

	reg_addr = 0xA;
	phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);

#if 0
	udelay(5000);
	init_realtek_phy();
	//udelay(5000);
	printk("\n");
	printk("wait for link up\n");
	{
		int i;
		unsigned int emac_idx;
		unsigned int phy_addr;
		unsigned int reg_addr;
		unsigned int phy_data;
		emac_idx = 0;
		phy_addr = 1;
		for(i=0;i<1000;i++)
		{
			display_realtek_phy_status();
			msleep(100);

			reg_addr = 0xA;
			phy_data = MdioRegRead(emac_idx, phy_addr, reg_addr);
			if( (phy_data&0x3000)==0x3000 )
			{
				printk("confirm link up\n");
				break;
			}
		}
	}
#endif

	/* supress error 'variable set but not used' */
	(void)phy_data;
}

/* Marvell PHY
  100Base-T1 Initialization Procedure
  from Maevell PHY API User Guide */
static void init_marvell_phy_100M__(unsigned int isMaster)
{
	unsigned int emac_idx;
	unsigned int phy_addr;
	//unsigned int isMaster = 0; // should be 1 or 0

	printk("\n");
	printk("[%s] start\n", __func__);

	emac_idx = 1;
	phy_addr = 5;

	XMdioRegWrite( emac_idx, phy_addr, 0x1, 0x0834, (isMaster<<14)|0x0 );

	printk("[%s] finish\n", __func__);

}

static void display_marvell_phy_status(void)
{
	unsigned int emac_idx;
	unsigned int phy_addr;


	printk("\n");
	printk("[%s] start\n", __func__);

	emac_idx = 1;
	phy_addr = 5;

#if 0
	/* code from marvell phy sample code */
	/* 4) check status */
	checkLink(DUT, &isLinkup);
	checkIsMaster(DUT, &isMaster);
	getSpeed(DUT, &speed);
	printf(">> Link Status: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
	getLatchedLinkStatus(DUT, &isLinkup);
	printf(">> Latched Link Status 1: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
	getRealTimeLinkStatus(DUT, &isLinkup);
	printf(">> Real Time Link Status: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
	getLatchedLinkStatus(DUT, &isLinkup);
	printf(">> Latched Link Status 2: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
	printf(">> Master/Slave: %s\n", MRVL_APHY_TRUE == isMaster ? "Master" : "Slave");
	printf(">> Speed: %s\n", MRVL_APHY_SPEED_1000 == speed ? "GE/1000" : "FE/100");
#else
	{
		unsigned int dev_addr;
		unsigned int reg_addr;
		unsigned int phy_data;
		unsigned int regVal1;
		unsigned int regVal2;
		unsigned int regVal3;

		unsigned int isMaster;
		unsigned int isAnEnabled;
		unsigned int isLinkup;
		unsigned int currSpeed;

		/* get An enabled */
		dev_addr = 7;
		reg_addr = 0x0200;
		phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
		//printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);
		isAnEnabled = ((phy_data&0x1000) != 0x0) ? 1 : 0;

		printk(">> AN enabled : %d\n", isAnEnabled);

		if( isAnEnabled == 1 )
		{
			dev_addr = 7;
			reg_addr = 0x801a;
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
			//printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);
			if((phy_data&0x4000)!=0x0)
			{
				currSpeed = 1000;
			}
			else
			{
				currSpeed = 100;
			}
			printk(">> speed : %s\n", (currSpeed==1000) ? "1G" : "100M");
			dev_addr = 7;
			reg_addr = 0x8001;
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
			//printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);
			isMaster = ((phy_data&0x4000)!=0 ) ? 1:0;
			printk(">> M/S : %s\n", isMaster ? "Master" : "Slave");
		}
		else
		{
			dev_addr = 1;
			reg_addr = 0x0834;
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
			//printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);
			if( (phy_data&0x1)!=0x0 )
			{
				currSpeed = 1000;
			}
			else
			{
				currSpeed = 100;
			}
			printk(">> speed : %s\n", (currSpeed==1000) ? "1G" : "100M");

			isMaster = ((phy_data&0x4000)!=0) ? 1:0;
			printk(">> M/S : %s\n", isMaster ? "Master" : "Slave");
		}

		if(currSpeed == 1000)
		{
			printk(">> check link 1G\n");

			dev_addr = 3;
			reg_addr = 0x0901;
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr); /* Read twice: link latches low status */
			regVal1 = phy_data;
			//printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);

			dev_addr = 7;
			reg_addr = 0x8001;
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr); /* local and remote receiver status */
			regVal2 = phy_data;
			//printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);

			dev_addr = 3;
			reg_addr = 0xFD9D;
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr); /* local receiver status 2 */
			regVal3 = phy_data;
			//printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);

			isLinkup = ((0x0004U == (regVal1 & 0x0004U))
							&& (0x3000U == (regVal2 & 0x3000U))
							&& (0x0010U == (regVal3 & 0x0010U))) ? 1 : 0;
			printk(">> link up : %d (1G)\n", isLinkup);
		}
		else
		{
			printk(">> check link 100M\n");
			dev_addr = 3;
			reg_addr = 0x8109;
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
			regVal1 = phy_data;

			dev_addr = 3;
			reg_addr = 0x8108;
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
			regVal2 = phy_data;

			dev_addr = 3;
			reg_addr = 0x8230;
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
			regVal3 = phy_data;

			isLinkup = ((0x0004U == (regVal1 & 0x0004U))
							&& (0x3000U == (regVal2 & 0x3000U))
							&& (0x0001U == (regVal3 & 0x0001U))) ? 1 : 0;
			printk(">> link up : %d (100M)\n", isLinkup);
		}

		dev_addr = 7;
		reg_addr = 0x0201; //BASE-T1 Auto-Negotiation Status Register
		phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
		isLinkup = (0x0U != (phy_data & 0x0004U)) ? 1 : 0;
		printk(">> Latched Link Status 1: %s\n", isLinkup ? "Up" : "Down");

		if(currSpeed == 1000)
		{
			/* 1000 speed real time link is a latched link */
			dev_addr = 3;
			reg_addr = 0x0901; //PCS 1000BASE-T1 Status Register 1
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr); /* Read twice: link latches low status */
			//printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);
		}
		else
		{
			dev_addr = 3;
			reg_addr = 0x8109;
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);

		}
		isLinkup = (0x0U != (phy_data & 0x0004U)) ? 1 : 0;
		printk(">> Real Time Link Status: %s\n", isLinkup ? "Up" : "Down");

		dev_addr = 7;
		reg_addr = 0x0201; //BASE-T1 Auto-Negotiation Status Register
		phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
		isLinkup = (0x0U != (phy_data & 0x0004U)) ? 1 : 0;
		printk(">> Latched Link Status 2: %s\n", isLinkup ? "Up" : "Down");

		#if 0 /* disable TC10 function by register */
		dev_addr = 3;
		reg_addr = 0x8027; //Common Sleep/Wakeup Configuration
		phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
		printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);

		phy_data &= ~(0x1);
		XMdioRegWrite( emac_idx, phy_addr, dev_addr, reg_addr, phy_data);
		printk("XMdioRegWrite dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);

		phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
		printk("XMdioRegRead dev_addr %d, reg_addr 0x%08x phy_data 0x%08x\n", dev_addr, reg_addr, phy_data);
		#endif

		/* supress error 'variable set but not used' */
		(void)isLinkup;
		(void)isMaster;
	}
#endif
}

static void init_gmac(unsigned int gmac_idx)
{
	unsigned long base_addr;
	unsigned long addr;
	unsigned int val;
	unsigned int wrval;
	unsigned int mac_high;
	unsigned int mac_low;

	switch(gmac_idx)
	{
		case 0:
			base_addr = EMAC2_BASE_ADDR;
			mac_high = 0xDBA9;
			mac_low  = 0x87650000;
			break;

		case 1:
			base_addr = EMAC1_BASE_ADDR;
			mac_high = 0xDBA9;
			mac_low  = 0x87651111;
			break;

		default:
			break;
	}

	printk("\n");
	printk("[%s] initialize GMAC%d.\n", __func__, gmac_idx);

	addr = base_addr+0xC00; // MTL_Operation_Mode
	wrval = val = RegRead(addr);
	#if 0
	wrval &= ~(1<<2); //Receive Arbitration Algorithm; 0: Strict priority (SP).
	wrval |= (0x3<<5); //Tx Scheduling Algorithm; 0x3 (SP): Strict priority algorithm
	#else
	wrval = 0;
	#endif
	RegWrite(addr, wrval);
	printk("write addr[%08lx] val[%08x]->[%08x]\n", addr, val, wrval);

	addr = base_addr+0xC30; // MTL_RxQ_DMA_Map0
	wrval = val = RegRead(addr);
	#if 0
	wrval &= ~(0x7<<0); // Queue 0 Mapped to DMA Channel 0
	wrval |= (0x1<<4); // Queue 0 Enabled : 0x1 enabled
	wrval &= ~(0x7<<8); // Queue 1 Mapped to DMA Channel 0
	wrval |= (0x1<<12); // Queue 1 Enabled : 0x1 enabled
	#else
	wrval = 0; //static, DMA channel 0
	#endif
	RegWrite(addr, wrval);
	printk("write addr[%08lx] val[%08x]->[%08x]\n", addr, val, wrval);

	addr = base_addr+0xD00; // MTL_TxQ0_Operation_Mode
	wrval = val = RegRead(addr);
	#if 0
	wrval &= ~((0x7F<<16)|(1<<3)              );
	wrval |=  ((0x40<<16)       |(1<<2)|(1<<1));
	                         // TQS=0x40, maybe shloul 0x3F,
	                         //     size of Queue=(0x3F+1)*0x100 = 0x4000 = 16KB
	                         // TXQEN = 01b = Enable in AV mode
	                         // TSF = Enable Transmit Store and Forward
	#else
	wrval = 0x001F000A;
	#endif

	RegWrite(addr, wrval);
	printk("write addr[%08lx] val[%08x]->[%08x]\n", addr, val, wrval);

	addr = base_addr+0xD30; // MTL_RxQ0_Operation_Mode
	wrval = val = RegRead(addr);
	#if 0
	wrval &= ~((0x7F<<20)              );
	wrval |=   (0x40<<20)|(1<<7)|(1<<5);
	#else
	wrval = 0x01F18AF8;
	#endif
	RegWrite(addr, wrval);
	printk("write addr[%08lx] val[%08x]->[%08x]\n", addr, val, wrval);

	addr = base_addr+0xD40; // MTL_TxQ1_Operation_Mode
	wrval = val = RegRead(addr);
	#if 0
	wrval &= ~((0x7F<<16)|(1<<3)              );
	wrval |=  ((0x40<<16)       |(1<<2)|(1<<1));
	                         // TQS=0x40, maybe shloul 0x3F,
	                         //     size of Queue=(0x3F+1)*0x100 = 0x4000 = 16KB
	                         // TXQEN = 01b = Enable in AV mode
	                         // TSF = Enable Transmit Store and Forward
	#else
	wrval = 0;
	//wrval = 0x001F000A;
	#endif
	RegWrite(addr, wrval);
	printk("write addr[%08lx] val[%08x]->[%08x]\n", addr, val, wrval);

	addr = base_addr+0xD70; // MTL_RxQ1_Operation_Mode
	wrval = val = RegRead(addr);
	#if 0
	wrval &= ~((0x7F<<20)              );
	wrval |=   (0x40<<20)|(1<<7)|(1<<5);
	#else
	wrval = 0;
	//wrval = 0x01F18AF8;
	#endif
	RegWrite(addr, wrval);
	printk("write addr[%08lx] val[%08x]->[%08x]\n", addr, val, wrval);

	addr = base_addr + 0x300; // MAC_Address0_High
	val  = mac_high;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0x304; // MAC_Address0_Low
	val  = mac_low;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0x008; // MAC_Packet_Filter
	#if 0
	val = 0x80000400;
	#else
	val = 0x80000050;
	#endif
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0xA0; // MAC_RxQ_Ctrl0
	#if 0
	val  = 0x5;
	#else
	val = 0x00000002;
	//val = 0x00000006;
	#endif
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0xB4;; // MAC_Interrupt_Enable
	//val  = 0xFFFFFFFF;
	val  = 0x00067009;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0x0; // MAC_Configuration
#if 0
	#ifdef GMAC_SPD_100M
	val  = 0xE403; // 100Mbps  [15]:PS=1, [14]:FES=1
	#elif defined(GMAC_SPD_10M)
	val  = 0xA403; // 10Mbps   [15]:PS=1, [14]:FES=0
	#else
	val  = 0x2403; // 1Gbps    [15]:PS=0, [14]:FES=0
	#endif
	#ifdef GMAC_LOOPBACK_MODE
	val |= (1<<12);
	#endif
#else
	#ifdef GMAC_SPD_100M
	//val = 0x0000E203;
	val = 0x0030E203;
	#else
	val = 0x00302203;
	#endif
#endif
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

}

static void init_gmac_alt(unsigned int gmac_idx)
{
	unsigned long base_addr=0;
	unsigned long addr;
	unsigned int val;
	//unsigned int wrval;
	unsigned int mac_high;
	unsigned int mac_low=0;

	switch(gmac_idx)
	{
		case 0:
			base_addr = EMAC2_BASE_ADDR;
			mac_high = 0xDBA9;
			mac_low  = 0x87650000;
			break;

		case 1:
			base_addr = EMAC1_BASE_ADDR;
			mac_high = 0xDBA9;
			mac_low  = 0x87651111;
			break;

		default:
			break;
	}

	printk("\n");
	printk("[%s] initialize GMAC%d.\n", __func__, gmac_idx);

	addr = base_addr+0xC00; // MTL_Operation_Mode
	val = 0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0xC30; // MTL_RxQ_DMA_Map0
	val = 0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0xD00; // MTL_TxQ0_Operation_Mode
	val = 0x001F000A;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0xD30; // MTL_RxQ0_Operation_Mode
	val = 0x01F18AA0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0x300; // MAC_Address0_High
	val  = mac_high | (1<<31);
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0x304; // MAC_Address0_Low
	val  = mac_low;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0x008; // MAC_Packet_Filter
	val = 0x80000050;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0xA0; // MAC_RxQ_Ctrl0
	val = 0x00000002;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0xB4;; // MAC_Interrupt_Enable
	//val  = 0xFFFFFFFF;
	val  = 0x00067009;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr + 0x0; // MAC_Configuration
	#ifdef GMAC_SPD_100M
	//val  = 0x0837E203; // 100Mbps  [15]:PS=1, [14]:FES=1
	val  = 0x0837E202; // 100Mbps  [15]:PS=1, [14]:FES=1 // rvc disable
	#elif defined(GMAC_SPD_10M)
	val  = 0x0837A203; // 10Mbps   [15]:PS=1, [14]:FES=0
	#else
	val  = 0x08372203; // 1Gbps    [15]:PS=0, [14]:FES=0
	#endif
	#ifdef GMAC_LOOPBACK_MODE
	val |= (1<<12);
	#endif
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

}

/* FPGA simulation setting */
static void init_xgmac(unsigned int gmac_idx)
{
	unsigned long base_addr;
	unsigned long addr;
	unsigned int val;
	unsigned int mac_high;
	unsigned int mac_low;

	switch(gmac_idx)
	{
		case 0:
			base_addr = EMAC3_BASE_ADDR;
			mac_high = 0x8877;
			mac_low  = 0x665544F3;
			break;

		case 1:
			base_addr = EMAC4_BASE_ADDR;
			mac_high = 0x8877;
			mac_low  = 0x665544F4;
			break;

		default:
			break;
	}

	printk("\n");
	printk("[%s] initialize XGMAC%d.\n", __func__, gmac_idx);
	printk("[%s] SOC setting.\n", __func__);

#if 1
	addr = base_addr+0x158; // MAC_FSM_Control
	val = RegRead(addr);
	val |= 0x2;
	val &= ~(0x1);
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
#endif
	addr = base_addr+0x10e0; // MTL_DPP_Control
	val = 0x7;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x000; // MAC_Tx_Configuration
	val = 0x60000001; //1G GMII
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x0b4; // MAC_Interrupt_Enable
	val = 1;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x004; // MAC_Rx_Configuration
	val = 0x000002C7;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x008; // MAC_Packet_Filter
	val = 0x00000001;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x280; // MAC_FPE_CTRL_STS
	val = 0x0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x0a4; // MAC_RxQ_Ctrl1
	val = 0x0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x1090; // MAC_RxQ_Ctrl1
	val = 0x100;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x0b4; // MAC_Interrupt_Enable
	val = 0x8001;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x1000; // MTL_Operation_Mode
	val = 0x0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x0a0; // MAC_RxQ_Ctrl0
	val = 0x00000002;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x0a8; // MAC_RxQ_Ctrl2
	val = 0x08040201;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x0ac; // MAC_RxQ_Ctrl3
	val = 0x80402010;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x008; // MAC_Packet_Filter
	val = 0x80000000; //RA=1
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x050; // MAC_VLAN_Tag_Ctrl
	val = 0x81000000;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x1040; // MTL_TC_Prty_Map0
	val = 0x0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x1044; // MTL_TC_Prty_Map1
	val = 0x0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x090; // MAC_Rx_Flow_Ctrl
	val = 0x0;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x300; // MAC_Address0_High
	val  = 0x0504 | (1<<31);
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x304; // MAC_Address0_Low
	val  = 0x03020100;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x1000; // MTL_Operation_Mode
	val = 0x2;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x11C0; // MTL_RxQ1_Operation_Mode
	val = 0x003f0000;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x1180; // MTL_TxQ11_Operation_Mode
	val = 0x003f0108;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x1140; // MTL_RxQ0_Operation_Mode
	val = 0x007f0010;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	addr = base_addr+0x1100; // MTL_TxQ0_Operation_Mode
	val = 0x007f0008;
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	/* supress error 'variable set but not used' */
	(void)mac_high;
	(void)mac_low;
}

void platform_emac_enable(void)
{
	unsigned long base_addr;
	unsigned long addr;
	unsigned int val;

	mcu_printf("[%s]\n", __func__);

	base_addr = EMAC1_BASE_ADDR;
	addr = base_addr + 0x0; // MAC_Configuration

	/* GMAC0 receive enable */
	val = RegRead(addr);
	val |= 0x2; // Tx enable
	#ifdef ENABLE_RX
	val |= 0x1; // Rx enable
	#endif
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);

	base_addr = EMAC2_BASE_ADDR;
	addr = base_addr + 0x0; // MAC_Configuration

	/* GMAC0 receive enable */
	val = RegRead(addr);
	val |= 0x2; // Tx enable
	#ifdef ENABLE_RX
	val |= 0x1; // Rx enable
	#endif
	RegWrite(addr, val);
	printk("write addr[%08lx] val[%08x]\n", addr, val);
}

static void register_rw_test(void)
{
	unsigned long addr;
	unsigned int val;

	mcu_printf("\n\nRegister read / write test!!!\n");


	mcu_printf("EPP ID(read only)\n");
	addr = 0xa0d000;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);


	mcu_printf("EGPI3 GPI_BUF_SIZE\n");
	addr = 0x202010;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n", addr, val);
	val = 0xa5a55a5a;
	RegWrite(addr, val);
	mcu_printf("write addr[%08lx] val[%08x]\n", addr, val);
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);


	mcu_printf("EGPI3 CLASS_VERSION(read only)\n");
	addr = 0x202600;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);


	mcu_printf("HIF_RX_QUEUE_MAP_CH_NO\n");
	addr = 0x6800CC;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n", addr, val);
	val = 0xa5a55a5a;
	RegWrite(addr, val);
	mcu_printf("write addr[%08lx] val[%08x]\n", addr, val);
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);


	mcu_printf("HIF_CH0_INT_EN\n");
	addr = 0x681064;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n", addr, val);
	val = 0x000005a5;
	RegWrite(addr, val);
	mcu_printf("write addr[%08lx] val[%08x]\n", addr, val);
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);


	mcu_printf("IPSEC_GPI GPI_BUF_SIZE\n");
	addr = 0x800010;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n", addr, val);
	val = 0xa5a55a5a;
	RegWrite(addr, val);
	mcu_printf("write addr[%08lx] val[%08x]\n", addr, val);
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);


	mcu_printf("IPSEC_GPI CLASS_VERSION(read only)\n");
	addr = 0x800600;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);


	mcu_printf("EGPI4 GPI_BUF_SIZE\n");
	addr = 0x400010;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n", addr, val);
	val = 0xa5a55a5a;
	RegWrite(addr, val);
	mcu_printf("write addr[%08lx] val[%08x]\n", addr, val);
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);


	mcu_printf("EGPI4 CLASS_VERSION(read only)\n");
	addr = 0x400600;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);


	mcu_printf("EMAC4 MAC_Version(read only)\n");
	addr = 0x4d0110;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);


	mcu_printf("EMAC4 MAC_Address0_High\n");
	addr = 0x4d0300;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n", addr, val);
	val = 0xa5a55a5a;
	RegWrite(addr, val);
	mcu_printf("write addr[%08lx] val[%08x]\n", addr, val);
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);


	mcu_printf("EMAC4 MAC_Address0_Low\n");
	addr = 0x4d0304;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n", addr, val);
	val = 0xa5a55a5a;
	RegWrite(addr, val);
	mcu_printf("write addr[%08lx] val[%08x]\n", addr, val);
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);


	mcu_printf("\n\n");
}

static void set_pll(void)
{
	unsigned long addr;
	unsigned int val;

	mcu_printf("\nSET PLL\n");


	mcu_printf("CSR4\n");
	addr = 0xd3a010;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(7<<8);
	RegWrite(addr, val);
	mcu_printf("write addr[%08lx] val[%08x]\n", addr, val);
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);

	mcu_printf("CSR3\n");
	addr = 0xd3a00c;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(2<<16);
	RegWrite(addr, val);
	mcu_printf("write addr[%08lx] val[%08x]\n", addr, val);
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);

	mcu_printf("CSR0\n");
	addr = 0xd3a000;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n", addr, val);
	val = val|(625<<8);
	RegWrite(addr, val);
	mcu_printf("write addr[%08lx] val[%08x]\n", addr, val);
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);

	mcu_printf("CSR2\n");
	addr = 0xd3a008;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n", addr, val);
	val = val|((6<<2) + (1<<8));
	RegWrite(addr, val);
	mcu_printf("write addr[%08lx] val[%08x]\n", addr, val);
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);

	mcu_printf("CSR1\n");
	addr = 0xd3a004;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n", addr, val);
	val = val|((1<<18)+(4<<19)+(1<<26));
	RegWrite(addr, val);
	mcu_printf("write addr[%08lx] val[%08x]\n", addr, val);
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);

	mcu_printf("ERIO\n");
	addr = 0xd3a018;
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n", addr, val);
	val = val|((1<<18)+(1<<5)+(1<<4)+(1<<0));
	RegWrite(addr, val);
	mcu_printf("write addr[%08lx] val[%08x]\n", addr, val);
	val = RegRead(addr);
	mcu_printf("read addr[%08lx] val[%08x]\n\n", addr, val);

	while(1)
	{
		addr = 0xd3a010;
		val = RegRead(addr);
		mcu_printf("read addr[%08lx] val[%08x]\n", addr, val);

		if(val && 0x02)
			break;
	}

	mcu_printf("\n\n");
}

void tpa_clock_setting(void)
{
	//unsigned long base_addr;
	unsigned long addr;
	unsigned int val;

	mcu_printf("[%s]\n", __func__);

	addr = 0x4B10038C;
	val = RegAbsRead(addr);
	/* OUTEN(bit30)에 0을 write한 뒤, OUTEN(M)에서 0 read. */
	val &= ~(1<<30);
	RegAbsWrite(addr, val);
	while( (RegAbsRead(addr)&(1<<31)) != 0);
	/* OUTEN and OUTEN(M) is already 0 */
	/* DIVEN=1, SEL=2, DIV=12를 write */
	val = (1<<29) | (11<<24) | 11;
	RegAbsWrite(addr, val);
	val |= (1<<30);
	RegAbsWrite(addr, val);
	//while( (RegAbsRead(addr)&(1<<31)) == 0);
	while(1)
	{
		val = RegAbsRead(addr);
		if( (val&(1<<31)) != 0 )
		{
			break;
		}
	}
	mcu_printf("gmac0 peri clock checked\n");

	addr = 0x4B100390;
	val = RegAbsRead(addr);
	/* OUTEN(bit30)에 0을 write한 뒤, OUTEN(M)에서 0 read. */
	val &= ~(1<<30);
	RegAbsWrite(addr, val);
	while( (RegAbsRead(addr)&(1<<31)) != 0);
	/* OUTEN and OUTEN(M) is already 0 */
	/* DIVEN=1, SEL=11, DIV=12를 write */
	val = (1<<29) | (11<<24) | 11;
	RegAbsWrite(addr, val);
	val |= (1<<30);
	RegAbsWrite(addr, val);
	//while( (RegAbsRead(addr)&(1<<31)) == 0);
	while(1)
	{
		val = RegAbsRead(addr);
		if( (val&(1<<31)) != 0 )
		{
			break;
		}
	}
	mcu_printf("gmac1 peri clock checked\n");

	addr = 0x4B100398;
	val = RegAbsRead(addr);
	/* OUTEN(bit30)에 0을 write한 뒤, OUTEN(M)에서 0 read. */
	val &= ~(1<<30);
	RegAbsWrite(addr, val);
	while( (RegAbsRead(addr)&(1<<31)) != 0);
	/* OUTEN and OUTEN(M) is already 0 */
	/* DIVEN=1,SEL=11,DIV=29를 write */
	val = (1<<29) | (11<<24) | 29;
	RegAbsWrite(addr, val);
	val |= (1<<30);
	RegAbsWrite(addr, val);
	//while( (RegAbsRead(addr)&(1<<31)) == 0);
	while(1)
	{
		val = RegAbsRead(addr);
		if( (val&(1<<31)) != 0 )
		{
			break;
		}
	}
	mcu_printf("gmac0 ptp clock checked\n");
}

void tpa_gpio_setting(void)
{
	uint32 addr;
	uint32a val;

	mcu_printf("[%s]\n", __func__);

	/* GMAC0 */
	//RegAbsWrite(MC_GPIO_BASE_ADDR + GPC_IEN , 0x1A671D);  //0000 0000 0001 1010 0110 0111 0001 1101
	addr = MC_GPIO_BASE_ADDR + GPC_IEN;
	val = RegAbsRead(addr);
	val &= 0x00018000; // clear all except GPC[16:15]
	val |= 0x1A671D & (~0x00018000); // provided value from SOC
	RegAbsWrite(addr , val);

	//RegAbsWrite(MC_GPIO_BASE_ADDR + GPC_OEN , 0x598E7);   //0000 0000 0000 0101 1001 1000 1110 0111
	addr = MC_GPIO_BASE_ADDR + GPC_OEN;
	val = RegAbsRead(addr);
	val &= 0x00018000; // clear all except GPC[16:15]
	val = 0x598E7 & (~0x00018000);
	RegAbsWrite(addr , val);

	/* TPA_GMAC0_RESET(GPC[18]) to HIGH */
	addr = MC_GPIO_BASE_ADDR + GPC_DAT;
	val = RegAbsRead(addr);
	val |= (1<<18);
	RegAbsWrite(addr , val);

	RegAbsWrite(MC_GPIO_BASE_ADDR + GPC_FNC0 , 0x11111111);

	/* Do not modify below 2 port, these are for other function.
	    GPC[15]=UART2_TX, GPC[16]=UART_RX */
	/* don't touch GPI_C[15] */
	addr = MC_GPIO_BASE_ADDR + GPC_FNC1;
	val = RegAbsRead(addr);
	val &= 0xF0000000;
	val |= 0x01111111;
	RegAbsWrite(addr, val);

	/* don't touch other port, only set GPI_C[20:17] as fucn_0*/
	addr = MC_GPIO_BASE_ADDR + GPC_FNC2;
	val = RegAbsRead(addr);
	val &= 0xFFF0000F;
	RegAbsWrite(addr , val);

	/* GMAC1 */
	//RegAbsWrite(MC_GPIO_BASE_ADDR + GPD_IEN , 0x1A671D);
	addr = MC_GPIO_BASE_ADDR + GPD_IEN;
	val = RegAbsRead(addr);
	val &= 0x00018000; // clear all except GPD[16:15]
	val |= 0x1A671D & (~0x00018000); // provided value from SOC
	RegAbsWrite(addr , val);

	//RegAbsWrite(MC_GPIO_BASE_ADDR + GPD_OEN , 0x598E7);
	addr = MC_GPIO_BASE_ADDR + GPD_OEN;
	val = RegAbsRead(addr);
	val &= 0x00018000; // clear all except GPD[16:15]
	val = 0x598E7 & (~0x00018000);
	RegAbsWrite(addr , val);

	/* TPA_GMAC1_RESET(GPD[18]) to HIGH */
	addr = MC_GPIO_BASE_ADDR + GPD_DAT;
	val = RegAbsRead(addr);
	val |= (1<<18);
	RegAbsWrite(addr , val);

	RegAbsWrite(MC_GPIO_BASE_ADDR + GPD_FNC0 , 0x11111111);
	/* don't touch GPI_D[15] */
	//RegAbsWrite(MC_GPIO_BASE_ADDR + GPD_FNC1 , 0x11111111);
	addr = MC_GPIO_BASE_ADDR + GPD_FNC1;
	val = RegAbsRead(addr);
	val &= 0xF0000000;
	val |= 0x01111111;
	RegAbsWrite(addr, val);

	/* don't touch other port, only set GPI_D[20:17] as fucn_0*/
	//RegAbsWrite(MC_GPIO_BASE_ADDR + GPD_FNC2 , 0x11111);
	addr = MC_GPIO_BASE_ADDR + GPD_FNC2;
	val = RegAbsRead(addr);
	val &= 0xFFF0000F;
	RegAbsWrite(addr , val);

	/* GPIO_C TX drive strength */
	addr = MC_GPIO_BASE_ADDR + GPC_DS0;
	val = 0x33300003;
	RegAbsWrite(addr , val);

	addr = MC_GPIO_BASE_ADDR + GPC_DS1;
	val = 0x00033000;
	RegAbsWrite(addr , val);

	/* GPIO_D TX drive strength */
	addr = MC_GPIO_BASE_ADDR + GPD_DS0;
	val = 0x33300003;
	RegAbsWrite(addr , val);

	addr = MC_GPIO_BASE_ADDR + GPD_DS1;
	val = 0x00033000;
	RegAbsWrite(addr , val);


	/* SERDES1_RESET(GPIO_I03), SERDES1_WAKE(GPIO_I06) */
	addr = MC_GPIO_BASE_ADDR + GPI_IEN;
	val = RegAbsRead(addr);
	val &= ~((1<<6)|(1<<3)); // clear GPIO_I03, GPIO_I06
	RegAbsWrite(addr , val);

	addr = MC_GPIO_BASE_ADDR + GPI_DAT;
	val = RegAbsRead(addr);
	val |= ((1<<6)|(1<<3)); // set GPIO_I03, GPIO_I06 as HIGH
	RegAbsWrite(addr , val);

	addr = MC_GPIO_BASE_ADDR + GPI_OEN;
	val = RegAbsRead(addr);
	val |= ((1<<6)|(1<<3)); // set GPIO_I03, GPIO_I06 as OUTPUT
	RegAbsWrite(addr , val);

	addr = MC_GPIO_BASE_ADDR + GPI_FNC0;
	val = RegAbsRead(addr);
	val &= 0xF0FF0FFF; // set GPIO_I03, GPIO_I06 as Func0
	RegAbsWrite(addr , val);

	addr = MC_GPIO_BASE_ADDR + GPI_DS0;
	val = RegAbsRead(addr);
	val &= 0xF0FF0FFF;
	val |= 0x03003000;
	RegAbsWrite(addr , val);


	/* SERDES0_RESET(GPIO_L14), SERDES0_WAKE(GPIO_L17) */
	addr = MC_GPIO_BASE_ADDR + GPL_IEN;
	val = RegAbsRead(addr);
	val &= ~((1<<17)|(1<<14)); // clear GPIO_L14, GPIO_L17
	RegAbsWrite(addr , val);

	addr = MC_GPIO_BASE_ADDR + GPL_DAT;
	val = RegAbsRead(addr);
	val |= ((1<<17)|(1<<14)); // set GPIO_L14, GPIO_L17 as HIGH
	RegAbsWrite(addr , val);

	addr = MC_GPIO_BASE_ADDR + GPL_OEN;
	val = RegAbsRead(addr);
	val |= ((1<<17)|(1<<14)); // set GPIO_L14, GPIO_L17 as OUTPUT
	RegAbsWrite(addr , val);

	addr = MC_GPIO_BASE_ADDR + GPL_FNC1; //[15:8]
	val = RegAbsRead(addr);
	val &= 0xF0FFFFFF; // set GPIO_L14 as Func0
	RegAbsWrite(addr , val);

	addr = MC_GPIO_BASE_ADDR + GPL_FNC2; //[23:16]
	val = RegAbsRead(addr);
	val &= 0xFFFFFF0F; // set GPIO_L17 as Func0
	RegAbsWrite(addr , val);

	addr = MC_GPIO_BASE_ADDR + GPL_DS1; //[15:8]
	val = RegAbsRead(addr);
	val &= 0xF0FFFFFF;
	val |= 0x03000000;
	RegAbsWrite(addr , val);

	addr = MC_GPIO_BASE_ADDR + GPL_DS2; //[23:16]
	val = RegAbsRead(addr);
	val &= 0xFFFFFF0F;
	val |= 0x00000030;
	RegAbsWrite(addr , val);
}

void phy_1G_reset(void)
{
	uint32 addr;
	uint32a val;

	/* Assert TPA_GMAC0_RESET(GPC[18]), TPA_GMAC1_RESET(GPD[18]) */
	/* Assert SERDES1_RESET(GPI[03]), SERDES0_RESET(GPL[14]) */

	addr = MC_GPIO_BASE_ADDR + GPC_DAT;
	val = RegAbsRead(addr);
	val &= ~(1<<18);
	RegAbsWrite(addr , val);

	addr = MC_GPIO_BASE_ADDR + GPD_DAT;
	val = RegAbsRead(addr);
	val &= ~(1<<18);
	RegAbsWrite(addr , val);

	addr = MC_GPIO_BASE_ADDR + GPI_DAT;
	val = RegAbsRead(addr);
	val &= ~(1<<3);
	RegAbsWrite(addr, val);

	addr = MC_GPIO_BASE_ADDR + GPL_DAT;
	val = RegAbsRead(addr);
	val &= ~(1<<14);
	RegAbsWrite(addr, val);


	udelay(150); // 11msec, proved with oscillo.

	/* Deassert TPA_GMAC0_RESET, TPA_GMAC1_RESET */
	/* Deassert SERDES1_RESET(GPI[03]), TPA_GMAC1_RESET(GPL[14]) */
	addr = MC_GPIO_BASE_ADDR + GPC_DAT;
	val = RegAbsRead(addr);
	val |= (1<<18);
	RegAbsWrite(addr , val);

	addr = MC_GPIO_BASE_ADDR + GPD_DAT;
	val = RegAbsRead(addr);
	val |= (1<<18);
	RegAbsWrite(addr, val);

	addr = MC_GPIO_BASE_ADDR + GPI_DAT;
	val = RegAbsRead(addr);
	val |= (1<<3);
	RegAbsWrite(addr, val);

	addr = MC_GPIO_BASE_ADDR + GPL_DAT;
	val = RegAbsRead(addr);
	val |= (1<<14);
	RegAbsWrite(addr, val);
}

int platform_init(void)
{

	#if 1
	/* Workround for FPGA DRAM memset/memcpy error */
#ifdef PLATFORM_FPGA_CM7
	fpga_dram_base = (unsigned char *)FPGA_DRAM_START_ADDR;;
#endif

#ifdef PLATFORM_TCN1000_CM7
	fpga_dram_base = (unsigned char *)tpa_dmastart__;
#endif
	#endif

	#if 0
	printk("\n[%s] invoke test_reg_map()\n", __func__);
	test_reg_map();
	#endif

#ifdef PLATFORM_FPGA_CM7
	InitBaseAddr((void*)FPGA_EPP_START_ADDR);
#endif

#ifdef PLATFORM_TCN1000_CM7
	InitBaseAddr((void*)TCN1000_EPP_START_ADDR);
#endif

#if 0
	set_pll();
	tpa_clock_setting();
	set_tpa_csr();
	tpa_gpio_setting();
#endif
	return 1;
}


/**********************************************************************
 * Function Name  : platform_dma_alloc
 * Description    : get dma allocation done for this specific platform
 * Inputs
 *   Parameters   : - offset
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void *platform_dma_alloc(unsigned int ch_id,
            unsigned int  total_ring_size,
            dma_addr_t    *pdev_addr )
{
	dma_addr_t phy_addr;
	unsigned char *vir_addr;
	unsigned int aligned_ring_size;
	unsigned int local_used;

#ifdef PLATFORM_FPGA_CM7
	*pdev_addr = phy_addr = (dma_addr_t)(FPGA_DRAM_START_ADDR + used_offset);
#endif

#ifdef PLATFORM_TCN1000_CM7
	phy_addr = ((uint32)(&tpa_dmastart__) + BYTE_ALIGN_BIT_MASK-1) & ~(BYTE_ALIGN_BIT_MASK-1);
	*pdev_addr = phy_addr = phy_addr + used_offset;
#endif

	//vir_addr = config[4].membase + used_offset;
	vir_addr = (unsigned char *)phy_addr;


	/* 8byte align */
	aligned_ring_size = (total_ring_size+BYTE_ALIGN_BIT_MASK-1)&(~(BYTE_ALIGN_BIT_MASK-1));
	//used_offset += aligned_ring_size;
	local_used = used_offset;
	local_used += aligned_ring_size;
	used_offset = local_used;

	TPA_D("pdev_addr = 0x%08x, cpu_addr= 0x%08x, size=[%d=>%d]\n", phy_addr, vir_addr, total_ring_size, aligned_ring_size);
	return vir_addr;
}

/**********************************************************************
 * Function Name  : platform_start
 * Description    : write non-EPP registers in memory space to start or
 *                  configure the specific platform
 * Inputs
 *   Parameters   : -
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void platform_start()
{

#if 1//def PLATFORM_TCN1000_CM7
	/* GMAC/XGMAC setting for SOC */
	phy_1G_reset();
	asic_setting();

	#ifdef USE_MARVELL_API
	/* test for Marvell API */
	{
		MRVL_DEV mrvlDev_e1;
		MRVL_APHY_STATUS ret;
		(void)ret;

		TPA_D("\n[%s] PHY_TPA_GMAC0 88q2220 marvell  api start\n", __func__);
		memset(&mrvlDev_e1, 0, sizeof(MRVL_DEV));
		mrvlDev_e1.phyAddr = 0x07;
		mrvlDev_e1.smiPort = 2; //emac number 1~4
		ret = Sample_Code_Init_FixedSpeed(&mrvlDev_e1);
	}

	/* test for Marvell API */
	{
		MRVL_DEV mrvlDev_e2;
		MRVL_APHY_STATUS ret;
		(void)ret;

		TPA_D("\n[%s] PHY_TPA_GMAC1 88q2220 marvell  api start\n", __func__);
		memset(&mrvlDev_e2, 0, sizeof(MRVL_DEV));
		mrvlDev_e2.phyAddr = 0x07;
		mrvlDev_e2.smiPort = 1; //emac number 1~4
		ret = Sample_Code_Init_FixedSpeed(&mrvlDev_e2);
	}

	/* 2.5G - XGMAC1 - EMAC3 Marvell MVQ3244 */
	{
		PHY_MVQ3244_Init(1);
		PHY_MVQ3244_Check(1);
	}

	#ifdef USE_5G_PHY
	/* 5G - XGMAC0 - EMAC4 Marvell MVQ3244*/
	{
		PHY_MVQ3244_Init(0);
		PHY_MVQ3244_Check(0);
	}
	#else
	/* 5G SWitch */

	#endif

	SAL_TaskSleep(1000);

	Serdes_init_5p0G();
//	Serdes_init_XpXG();

	#endif

	#if 0
	{
		/* PHY SCAN */
		unsigned int emac_idx;
		unsigned int phy_addr;
		unsigned int dev_addr;
		unsigned int reg_addr;
		unsigned int phy_data;

		emac_idx = 0;
		dev_addr = 1;
		reg_addr = 0x02;
		//phy_addr = 7;
		for(phy_addr=0; phy_addr<32; phy_addr++)
		{
			phy_data = XMdioRegRead(emac_idx, phy_addr, dev_addr, reg_addr);
			(void)phy_data;
		}
	}
	#endif

#else
	display_safety_func_regs();

	display_partition_3_5_regs();

	display_mac_phy_reg();

	init_gmac_alt(1);
	init_gmac_alt(0);
	init_xgmac(0);

	udelay(1000);
#if 1
	init_realtek_phy();
#endif
	display_realtek_phy_status();

#if 1
	init_marvell_phy_100M__(1);
#endif
	udelay(10000);

	display_marvell_phy_status();

	//display_realtek_phy_status();

	TPA_D("[%s] finish\n", __func__);
	TPA_D("\n");

#endif
}

void platform_check_phy_status(int phy_num)
{



}

/**********************************************************************
 * Function Name  : platform_clear_interrupt
 * Description    : clear platform interrupts ( if needed )
 * Inputs
 *   Parameters   : -
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void platform_clear_interrupt()
{
	;	//
}

#if 1
void *platform_memset(void *s, int c, size_t n)
{
#if 1
	SAL_MemSet(s, c, n);
#else
	char *dst=(char*)s;
	if(n>0)	{
		do {
			*dst++=c;
			n--;
		}while(n>0);
	}
#endif
	return s;
}

void *platform_memcpy(void *d, void *s, size_t n)
{
#if 1
	//TPA_D("[%s] from 0x%08x to 0x%08x, %ld\n",__func__, s, d, n);
	SAL_MemCopy(d,s,n);
#else
	platform_memcpy_sw(d,s,n);
#endif
	return d;
}

void *platform_memcpy_sw(void *d, void *s, size_t n)
{
#if 1
	//TPA_D("[%s] from 0x%08x to 0x%08x, %ld\n",__func__, s, d, n);
	SAL_MemCopy(d,s,n);
#else
	char *src=(char*)s;
	char *dst=(char*)d;

	//printk("[%s] from %px to %px, %ld\n",__func__, s, d, n);
	if(n>0)	{
		do {
			*dst++=*src++;
			n--;
		}while(n>0);
	}
	//printk("[%s] done\n",__func__);
#endif
	return d;
}
#endif

void dump_mem(unsigned char* addr, unsigned int size)
{
	unsigned int align_size;
	unsigned long offset;
	unsigned int *uiaddr = (unsigned int*)addr + 0x00;

	addr = (unsigned char*)((unsigned long)addr & (~0xF));
	align_size = (size>>4)<<4;

	for(offset=0; offset<align_size; offset+=0x10)
	{
		uiaddr = (unsigned int*)(addr + offset);
 		printk("addr %px value %08x %08x %08x %08x\n", uiaddr, uiaddr[0], uiaddr[1], uiaddr[2], uiaddr[3]);
	}

	/* supress error 'variable set but not used' */
	(void)uiaddr;
}

void dump_byte(unsigned char* addr, unsigned int size)
{
	unsigned long offset;
	unsigned char *ucaddr;

	for(offset=0; offset<size; offset+=0x10)
	{
		ucaddr = addr + offset;
 		printk("addr %px byte %02x%02x%02x%02x %02x%02x%02x%02x %02x%02x%02x%02x %02x%02x%02x%02x\n", ucaddr, ucaddr[0], ucaddr[1], ucaddr[2], ucaddr[3]
 		, ucaddr[4], ucaddr[5], ucaddr[6], ucaddr[7]
 		, ucaddr[8], ucaddr[9], ucaddr[10], ucaddr[11]
 		, ucaddr[12], ucaddr[13], ucaddr[14], ucaddr[15]);
	}

	/* supress error 'variable set but not used' */
	(void)ucaddr;
}

void wait_init_done_signal_to_main_ap(void)
{
	unsigned long addr;
	unsigned int val;

	addr = HIF_ABS_FRAME_COUNT_CH8;
	val = 0;
	RegWrite(addr, val);

	/* Main AP will write 0xCC33AA55 to reg HIF_ABS_FRAME_COUNT_CH8, after ifconfig up done. */
	do {
		(void) SAL_TaskSleep(10);
		val = RegRead(addr);
		//TPA_D("wait\n");
	} while(val!=0xCC33AA55);

	//TPA_D("got\n");
	val = 0;
	RegWrite(addr, val);
}

