/**
 * @file MRVL_AMG_REG_MAIN.h
 * @brief Marvell Multi-gig Automotive Ethernet PHY general register defines
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */

#ifndef MRVL_AMG_REG_MAIN_H
#define MRVL_AMG_REG_MAIN_H

#define IeeeMmd1Reg0 0x40040000
#define pma_remote_loopback 1 /* 1 bit */

#define IeeeMmd1Reg2310 0x40042418
#define rx_link_status 0
#define rx_polarity 2

#define IeeeMmd1Reg2100 0x400420D0
#define master_slave 14
#define speed_selection 0x0 /* 4 bits */


#define IeeeMmd7Reg512 0x40080800
#define restart_an 9

#define IeeeMmd1Reg2314 0x40042428
#define snr_operating_margin 8 /* 8 bits */

#define IeeeMmd1Reg2315 0x4004242C
#define min_observed_snr_margin 8 /* 8 bits */

#define IeeeMmd1Reg2309 0x40042414
#define low_power 11 /* 1 bit */
#define tx_disable 14 /* 1 bit */

#define IeeeMmd3Reg2322 0x400C2448
#define ctrl_mdio_pcs_Loopback 14 /* 1 bit */


#define IeeeMmd1Reg2313 0x400C2424
#define jitter_test_ctrl 0 /* 2 bits */
#define test_mode_ctrl 13 /* 3 bits */

#define CmnVenCfgCfgNunoOv 0x4010F1FC
#define NunoLink 12 /* 1 bit */

#define Smi2ahbCtrlAddr0 0x28
#define Smi2ahbCtrlAddr1 0x29
#define Smi2ahbCtrlWdata0 0x2A
#define Smi2ahbCtrlWdata1 0x2B
#define Smi2ahbStatRdata0 0x2D
#define Smi2ahbStatRdata1 0x2E
#define Smi2ahbCtrlCmd 0x2C
#define ahb_opcode 0 /* 2 bits */

/* Network inf: BaseT1Pcs_SysToLine: Tx */
#define VendorSpecificPacketStatsTxStatGood 0x400E0410
#define VendorSpecificPacketStatsTxStatBad 0x400E0420
/* Network Inf: BaseT1Pcs_LineToSys: Rx */
#define VendorSpecificPacketStatsRxStatGood 0x400E0460
#define VendorSpecificPacketStatsRxStatBad 0x400E0470
/* System Inf: SysIfPhyXs_SysToLine: Tx */
#define NtunitCountersTxIfStatGood 0x4010F910
#define NtunitCountersTxIfStatBad 0x4010F920
/* System Inf: SysIfPhyXs_LineToSys: Rx */
#define NtunitCountersRxIfStatGood 0x4010F960
#define NtunitCountersRxIfStatBad 0x4010F970


#define PcsBaseRegister 0x48080000
#define RxRsFecStatCorrectedFrames 0x1244
#define RxRsFecStatUncorrectedFrames 0x1248
#define RxRsFecStatGoodFrames 0x124C
#define fec_counter_step 0x20

#define FwMmd1eSet0CfgFwIfConfig0 0x40780964
#define sys_pcs_mode 0 /* 3 bits */

#define FwMmd1eSet0StatusStat1 0x407809a4
#define deviceInitialized 0 /* 1 bit */

#define CommonRegisterClockResetRstCtrlRstFlash 0x48000304
#define dma_rst 8 /* 1 bit */
#define if_rst 0 /* 1 bit */

#define FlashCtrlSwInterface1 0x48002628
#define sw_clk_div 8 /* 9 bits */
#define sw_dummy_len 24 /* 6 bits */
#define sw_addr_len 20 /* 2 bits */
#define sw_opcode 0 /* 8 bits */

#define FlashCtrlSwInterface2 0x4800262C
#define sw_data_len 16 /* 3 bits */
#define sw_wr_mode 0 /* 1 bit */

#define FlashCtrlSwBurst 0x4800263C
#define burst_en 0 /* 1 bit */

#define FlashStatSwRdData 0x48002644

#define FlashCtrlSwAddr   0x48002634
#define FlashCtrlSwWrData 0x48002638

#define FlashCtrlSwStart 0x48002640
#define start_ 0 /* 1 bit */

#define FlashStatSwBusy 0x48002648
#define busy 0 /* 1 bit */

#define FlashCtrlDmaRdAck 0x48002618
#define buf0_rd_ack 0 /* 1 bit */
#define buf1_rd_ack 4 /* 1 bit */

#define FlashStatDmaFsm 0x48002624
#define state_ 0 /* 3 bits */

#define FlashCtrlDmaSpiInterface 0x48002604
#define dma_opcode 0 /* 8 bits */
#define dma_clk_div 8 /* 9 bits */
#define dma_addr_len 20 /* 2 bits */
#define dma_dummy_len 24 /* 6 bits */

#define FlashCtrlDmaInputMode 0x48002608 /* CTRL_DMA_INPUT_MODE bit 0, 2 bits */
#define SPI_INPUT_DUAL 1

#define SPI_CLOCK_DIVIDER 0x6U

#define FlashCtrlDmaStartAddr 0x4800260C
#define FlashCtrlDmaTransfers 0x48002610

#define FlashCtrlDmaStart 0x48002614

#define FlashStatDmaRd 0x4800261C
#define data_rdy0 0 /* 1 bit */
#define data_rdy1 4 /* 1 bit */
#define done_dma 16 /* 1 bit */
#define rdy_next 8 /* 2 bits */


#define CommonRegisterClockResetRstCtrlChipPor 0x407A0300
#define rst 0 /* 1 bit */

#define IdStatPartId 0x407A100C
#define minorRev 0 /* 4 bits */

#define MAX_NUM_XFERS 1<<19
#define DMA_TIMEOUT_MS 5000

#define SPI_DMA_BUFFER0_ADDR 0x48020000
#define SPI_DMA_BUFFER1_ADDR 0x48020040

#define HostManagementCtrlScratchpad 0x40780800 /* step 4, count 128 */
#define ServiceModeReqOffset 6
#define ColdResetEmuOffset 7
#define BootIfMaskOffset 6
#define sWaitTime 5000


#define IdStatEnvId 0x407A1018

#define FwSet0RblProgressBarCurr 0x48001000
#define FwMmd1eSet0StatusFwSysStat1 0

#define FwMmd1eSet0CmdMailboxCmdAndStatus 0x40780800
#define cmdmbExecute 4 /* 1 bit */
#define cmdmbStatus 5 /* 1 bit */
#define cmdmbCmd 0 /* 4 bits */

#define FwMmd1eSet0CmdMailboxData 0x40780804 /* step 4, count 15 */

#define FwMmd1eSet0InfoProvIdPlatformId 0x40780924
#define FwMmd1eSet0InfoProvIdProvFileVersion 0x40780928

#define FwMmd1eSet0InfoFwVersion0 0x40780900
#define revision_ 0 /* 8 bits */
#define minor_ 8 /* 8 bits */
#define FwMmd1eSet0InfoFwVersion1 0x40780904
#define major_ 0 /* 12 bits */
#define stream_ 12 /* 4 bits */

#define FwSet0HeartbeatTimeLo 0x480010d0
#define FwSet0HeartbeatTimeHi 0x480010d4

#define FwMmd1eSet0StatusStat0 0x407809A0

#define FwMmd1eSet0HostConfigStageConfig0 0x407809C0
#define FwMmd1eSet0HostConfigStageControl0 0x407809C8
#define disableStageTimeout 2 /* 1 bit */
#define commenceStage 0 /* 1 bit */
#define finalizeStage 1 /* 1 bit */

#define FwMmd1eSet0HostConfigStageStatus0 0x407809D0
#define hcs_state 0 /* 4 bits */

#define FwMmd1eSet0HostConfigStageStatus1 0x407809D4
#define elapsedTime 0 /* 16 bits */

#define FwMmd1eSet0HostConfigStageStatus2 0x407809D8
#define hostReactionTime 0 /* 16 bits */

#define ClockResetMuxesCtrlCmxPktGenCheck 0x407C2108
#define gen_select 0 /* 2 bits */
#define check_select 8 /* 2 bits */

#define DbgCtrlPktMax 0x407D401C 

#define DbgCtrlPktModes 0x407D4020
#define gen_mode 12 /* 2 bits */
#define payld_mode 8 /* 3 bits */
#define plen_mode 4 /* 2 bits */
#define ifg_mode 0 /* 2 bits */

#define DbgCtrlMinIfgBits150 0x407D4024 
#define DbgCtrlMinIfgBits3116 0x407D4028
#define DbgCtrlMaxIfgBits150 0x407D402C 
#define DbgCtrlMaxIfgBits3116 0x407D4030
#define DbgCtrlMinPlen 0x407D4034
#define DbgCtrlMaxPlen 0x407D4038
#define DbgStatDone 0x407D4048

#define DebugDbgCtrlPktGenCheckEnables 0x407C2F60
#define generator_enable 0 /* 1 bit */
#define checker_enable 8 /* 1 bit */
#define latency_enable 12 /* 1 bit */

#define FwMmd1eSet0CtrlFwIfControl0 0x40780944
#define line_link_restart 0 /* 1 bit */
#define sys_link_restart 1 /* 1 bit */

#define LedCtrlBlink 0x407A1600
#define blink_len 0 /* 8 bits */
#define LedCtrlLinkStatus 0x407A1604
#define link_status_mask 0 /* 2 bits */
#define LedCtrlLinkActivity 0x407A1608
#define link_activity_mask 0 /* 2 bits */

#define CheckerStatsDbgCtrlChkClearMode 0x407D5010
#define pmp_clear_mode 8 /* 1 bit */

#define VendorSpecificRsFecCtrlCtrlCounters 0x400E0000
#define pcs_clear_mode 4 /* 1 bit */

#define PhyCtrlInterfaceDiagCtrl 0x001F8610
#define tdrStart 0 /* 1 bit */

#define PhyStatusDiagStat0 0x001F86B0
#define tdrFaultType 0 /* 4 bits */
#define tdrFaultValue 4 /* 12 bits */
#define tdrFaultLength 16 /* 12 bits */
#define tdrNumDiscontinuities 28 /* 4 bits */

#define PhyStatusDiagStatDiscontinuity 0x001F86D0
#define tdrDiscontinuityLength 16 /* 12 bits */
#define tdrDiscontinuityValue 0 /* 12 bits */


#endif  /* defined MRVL_AMG_REG_MAIN_H */
