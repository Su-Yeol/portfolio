// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_net_driver.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    network driver for wsp module
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

/**********************************************************************
 *                                     Include Files
 **********************************************************************/
#include "reg_hal.h"
#include "fp_net_driver.h"
#include "fp_bd_api.h"
#include "fp_hif_reg.h"
#include "fp_acl_api.h"
#include "fp_library.h"
#include "tlite_blocks_ctrlm.h"
#include "fp_cb_api.h"
//#include "fp_hw_util.h"
//#include "platform.h"
//#include "gem_ptp.h"

/**********************************************************************
 *                              Global Declarations                   *
* Buffers for Config and PCI memory */
//int8 buff[256];
struct fp_private fpInst;

struct fp_private *fpGlobal = &fpInst;

void acl_manual_setting(void);


void acl_manual_setting(void)
{
	uint32a id;
	struct acl_entry aclEntry;
	struct acl_entry *data = &aclEntry;
	struct acl_entry aclEntry_read;;

	(void)aclEntry_read;
	TPA_D("[%s] \n", __func__);

	SAL_MemSet(data, 0, sizeof(struct acl_entry));

	/* refer Set_Acl_Config_Callback() of l2cli_switchApi.c of libs\l2cli */
	/* refer pcm_switchApi_config_ioctl() "case PCM_MSG_ACL_CONFIG_ADD" of switchApi_ioctl.c */

#if 1
	TPA_D("[%s] ACL entry : HIF to EMAC \n", __func__);
	/* ACL entry : HIF to EMAC */
	SAL_MemSet(data, 0, sizeof(struct acl_entry));
	id = 0;
	data->iport = 0x10;
	data->match_iport = 0x1;
	data->fwd_port_list = 0x0F; // to All EMAC1~4
	//data->fwd_port_list = 0x02; // to EMAC2
	data->action = 1; // forward
	fp_acl_add_entry(id, data);
#endif

#if 1
	TPA_D("[%s] ACL entry : EMAC to HIF \n", __func__);
	/* ACL entry : EMAC to HIF */
	SAL_MemSet(data, 0, sizeof(struct acl_entry));
	id = 1;
	data->iport = 0xF;
	data->match_iport = 0x1;
	data->fwd_port_list = 0x10; // to All EMAC
	data->action = 1; // forward
	fp_acl_add_entry(id, data);
#endif

#if 0
	TPA_D("[%s] ACL entry : EMAC1 to EMAC2 \n", __func__);
	/* ACL entry : HIF to EMAC */
	SAL_MemSet(data, 0, sizeof(struct acl_entry));
	id = 2;
	data->iport = 0x1;
	data->match_iport = 0x1;
	data->fwd_port_list = 0x2; // to All EMAC1~4
	data->action = 1; // forward
	fp_acl_add_entry(id, data);
#endif

#if 0
	TPA_D("[%s] ACL entry : EMAC2 to EMAC1 \n", __func__);
	/* ACL entry : HIF to EMAC */
	SAL_MemSet(data, 0, sizeof(struct acl_entry));
	id = 3;
	data->iport = 0x2;
	data->match_iport = 0x1;
	data->fwd_port_list = 0x1; // to All EMAC1~4
	data->action = 1; // forward
	fp_acl_add_entry(id, data);
#endif

#if 0
	TPA_D("[%s] verify \n", __func__);
	/* verify */
	fp_acl_get_entry(id, &aclEntry_read);
#endif
}


int32a fp_net_init(void)
{
	struct fp_private *fp;
	fp = fpGlobal;

	fp_assign_hif_base_addr(fp);

	spin_lock_init(&fp->lock, (const uint8*)"fp_lock");
	spin_lock_init(&fp->rx_lock, (const uint8*)"fp_rxlock");

	return 0;
}

/**********************************************************************
 * Function Name  : fp_net_open
 * Description    : Fastpath init routine for network driver, once device
 *                  is detected this routine is called immeadiately.
 *                  initialize rx ring buffer descriptors, initialize tx
 *                  ring buffer descriptors, loading fastpath dump, loading
 *                  fastpath global data structures, creating network device,
 *                  initialize network device handlers, irq registration,
 *                  register fp_phy interfaces, etc..
 * Inputs
 *   Parameters   : struct net_device *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
int32a fp_net_open(void)
{
	struct fp_private *fp;
	int32a rc = 0;
	//uint32a cmd_done;
	//int32a loop_count;


	TPA_D("[%s] enter\n", __func__);
	fp = fpGlobal;
	TPA_D("[%s] fpGlobal %p\n", __func__, fpGlobal);

#if 0
	/* TC added : Fix that SW reset failed, when host only reboot
		Follow '12. Soft Reset Sequence' in TRM document.*/
	fp_disable_hif_dma_engine(fp);

	/* TC edit : Fix kernel error, when host reboot while FPGA is running(tx/rx)
		Clear HIF interrupt request, and Disable HIF interrupt while initialize */
	fp_disable_interrupts(fp);

	TPA_D("[%s] invoke fp_init_fastpath\n", __func__);
	fp_init_fastpath();
	platform_start();

	fp_acl_table_init();
#endif

	/* Allocate memory and initialize bd rings */
	rc = fp_bd_init(fp);
	if (rc < 0) {
		TPA_D("error while initializiing bd table\n");
		return rc;
	}

	/* CLEAR - Program the bdp reg base addresses */
	fp_init_bdp_base_reg(fp);

	fp_init_rx_tasklet(fp);
	fp_init_tx_tasklet(fp);

#if 0//def FP_PRIMARY_DRIVER
	/* added for tlite */
	SAL_MemSet(fp_tdev_list, 0, TLITE_SWITCH_MAX_DEV_NUM * sizeof(tlite_dev_list_t));
	/* tlite init */
	pfe_tlite_init();
	pfe_tlite_default_config();

#if 0
	/* initialize ageing timer */
	fp_switch_init_timer(1);
#endif

#ifdef NPU_ING_QOS
	fp_ingqos_table_init();
#endif
//	fp_cb_table_init();

	fp_smac_vlan_table_init();
#endif

#if 0
	TPA_D("[%s] start sw reset\n", __func__);
	RegWrite(WSP_SYS_GENERIC_CONTROL, 0x40000000);

	loop_count = 100;
	do {
		SAL_TaskSleep(1);
		cmd_done = RegRead(WSP_DBUG_BUS1);
		loop_count--;
	} while ((loop_count > 0) && ((cmd_done & 0x001c0000) != 0x001c0000));

	if(loop_count == 0)
	{
		TPA_D("[%s] sw reset timeout. cmd_done=0x%08x\n", __func__, cmd_done);
	}
	else
	{
		TPA_D("[%s] sw reset done. cmd_done=0x%08x, loop_count=%d\n", __func__, cmd_done, loop_count);
	}

	/* clear soft reset done */
	RegWrite(WSP_SYS_GENERIC_CONTROL, 0x18000000);
#endif

	fp_bd_reinit();

#if 0
	acl_manual_setting();
#endif
#if 0
	/* TC edit : Fix kernel error, when host reboot while FPGA is running(tx/rx)
		Clear HIF interrupt request, and Disable HIF interrupt while initialize */
	fp_enable_interrupts(fp);
#endif

	/* Enable Emac Registers */
//	fpathConfig.fastpath = 1;
	//fp_emac_enable(fp);
	#if 0
	platform_emac_enable();
	#endif
	//fp_ccm_init((uint8 *)fp->pcimem_base);

	fp_enable_interrupts(fp);
	TPA_D("[%s]done fp_enable_interrupts\n",__func__);

	TPA_D("fp_net_open -end\n");

	return 0;
}

