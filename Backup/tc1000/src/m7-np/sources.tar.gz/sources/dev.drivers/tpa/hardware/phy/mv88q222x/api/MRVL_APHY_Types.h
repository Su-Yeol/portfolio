/**
 * @file MRVL_APHY_Types.h
 * @brief APHY Header File for General Types and Defines in APHY API
 *
 * @par Copyright and Version
 * See MRVL_Q222X_Copyright_and_Version.h
 */

#ifndef MRVL_APHY_TYPES_H
#define MRVL_APHY_TYPES_H

/* Test related define */
#ifdef APHY_TEST
#define STATIC
#else
#ifndef STATIC
#define STATIC static
#endif
#endif

/* DLL related define */
#ifdef MRVL_APHY_EXPORT_FUNC
#define EXPORT_FUNC __declspec(dllexport)
#else
#define EXPORT_FUNC
#endif

/* General ID detection related registers */
#define MRVL_ID_DEVICE				1
#define MRVL_ORGANIZATION_ID_REG	0x2
#define MRVL_APHY_ID_REG			0x3
#define MRVL_APHY_ID				0x0032
#define MRVL_ORGANIZATION_ID		0x2B
#define MRVL_APHY_ID_EXT_DEVICE		4
#define MRVL_APHY_ID_EXT_REG		0x80FF


typedef unsigned char        MRVL_APHY_U8;
typedef unsigned short       MRVL_APHY_U16;
typedef unsigned int         MRVL_APHY_U32;
typedef unsigned long long   MRVL_APHY_U64;

/** @defgroup MRVL_APHY_STATUS API Return Codes
 *  @{
 */
typedef MRVL_APHY_U32 		MRVL_APHY_STATUS;			/*!< Status code */
#define MRVL_APHY_STATUS_OK					0x0000U		/*!< Status code - Success */
#define MRVL_APHY_STATUS_ERROR_GENERAL		0x0001U		/*!< Status code - Error */
#define MRVL_APHY_STATUS_ERROR_TIMEOUT		0x0002U		/*!< Status code - Timeout error */
#define MRVL_APHY_STATUS_ERROR_MDIO			0x0004U		/*!< Status code - Reg access error */
#define MRVL_APHY_STATUS_ERROR_NOTSUPPORT	0x0010U		/*!< Status code - Non-support error */
#define MRVL_APHY_STATUS_UNKNOW				0x1000U		/*!< Status code - Other unknow error */
/** @} */

typedef enum {
	MRVL_APHY_FALSE = 0,
	MRVL_APHY_TRUE = 1
} MRVL_APHY_BOOL;

/**
 * @brief  Define speed enum
 *
 */
typedef enum {
	MRVL_APHY_SPEED_1000 = 0,
	MRVL_APHY_SPEED_100 = 1
} MRVL_APHY_SPEED;

/**
 * @brief Define the operation modes
 *
 */
typedef enum {
	MRVL_APHY_OP_SLAVE = 0, 	/*!< OP mode: SLAVE */
	MRVL_APHY_OP_MASTER = 1		/*!< OP mode: MASTER */
} MRVL_APHY_OPERATION_MODE;

/**
 * @brief Define the harness status code
 *
 */
typedef enum {
	MRVL_APHY_HARNESS_SHORT = 0,
	MRVL_APHY_HARNESS_OPEN = 1,
	MRVL_APHY_HARNESS_OK = 3,
	MRVL_APHY_HARNESS_NOISE = 4,
	MRVL_APHY_HARNESS_UNKNOWN
} MRVL_APHY_HARNESS_STATUS;
#endif
