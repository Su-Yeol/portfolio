// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
 * @File
 * @Title        fp_app_init.c
 * @Copyright    Copyright (c) Imagination Technologies Ltd. All Rights Reserved
 * @Description  Initialization routines for global data structures
 *                 like phyports and interface portsfast path module
 * @License      Dual MIT/GPLv2
 *
 * The contents of this file are subject to the MIT license as set out below.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * the GNU General Public License Version 2 ("GPL") in which case the provisions
 * of GPL are applicable instead of those above.
 *
 * If you wish to allow use of your version of this file only under the terms of
 * GPL, and not to allow others to use your version of this file under the terms
 * of the MIT license, indicate your decision by deleting the provisions above
 * and replace them with the notice and other provisions required by GPL as set
 * out in the file called "GPL-COPYING" included in this distribution. If you do
 * not delete the provisions above,a recipient may use your version of this file
 * under the terms of either the MIT license or GPL.
 *
 * This License is also included in this distribution in the file called
 * "MIT-COPYING".
 *
 * EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 * PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */ /**************************************************************************/

/**********************************************************************
 *                                     Include Files
 **********************************************************************/
#include "fp_library.h"
#include "fp_interface.h"
//#include "fp_ether.h"
#include "fp_router.h"
#include "fp_stats.h"
#include "fp_sa.h"
#include "fp_poolalloc.h"
#include "fp_app_init.h"

/**********************************************************************
 *                              Global Declarations                   *
 **********************************************************************/
uint32a enable_fw_route_search;
uint32a switch_port_list_mask;
int8 phyPortNames[MAX_PHY_PORTS][FP_MAX_PORT_NAME_SIZE];

struct IfData gIfPorts[MAX_PHY_PORTS][MAX_LOGICAL_IFS];
struct phyPort gPhyPorts[MAX_PHY_PORTS];
struct cacheFlow  *grtHashArr;
struct cacheFlow *npu_get_routehash_addr(void);

struct cacheFlow *fp_get_route_hash_array(void)
{
	return grtHashArr;
}
/**********************************************************************
 * Function Name  : fp_init_ports
 * Description    : Intializing Phyport Data Structures in init
 *                  initialize the media type as ethernet by default
 * Inputs
 *   Parameters   : -
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
static void fp_init_ports(void)
{
	struct phyPort *phyPtr;
	int32a i;

	for (i = 0; i < MAX_PHY_PORTS; i++) {
		phyPtr = &gPhyPorts[i];
		phyPtr->ifPtr = &gIfPorts[i][0];
		phyPtr->mediaType = IF_MEDIA_ETHERNET;
		phyPtr->maxLogicalIfs = MAX_LOGICAL_IFS;
#ifdef __FP_OS__
		phyPtr->curLogicalIfs = 1;
#else
		phyPtr->curLogicalIfs = 4;
#endif
		phyPtr->commonIfFlags = IF_MATCH_PHYPORT;
		phyPtr->phyno = i;
		phyPtr->res = 0;
		phyPtr->fp_port_stats.rx_pkts = 0;
		phyPtr->fp_port_stats.tx_pkts = 0;
		phyPtr->device = NULL;
#ifdef __FP_OS__
		phyPortNames[i][0] = '\0';
#endif
	}
}

/**********************************************************************
 * Function Name  : fp_init_interfaces
 * Description    : Intializing Interface Port Data Structures in init
 * Inputs
 *   Parameters   : -
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
static void fp_init_interfaces(void)
{
	struct IfData *ifPtr;
	int32a i;
	int32a j;

	TPA_E("switch_port_list_mask = %x\n", switch_port_list_mask);
	for(i = 0; i < MAX_PHY_PORTS; i++)
	{
		for(j = 0; j < MAX_LOGICAL_IFS; j++)
		{
			ifPtr = &gIfPorts[i][j];
			ifPtr->ifMatchFlags  = IF_MATCH_PHYPORT;

			/* Set operational flags based on ports mask */
			if ((switch_port_list_mask >> i) & 1)
			{
				ifPtr->opFlags = IF_BRIDGE;
			}
			else
			{
				ifPtr->opFlags = IF_ROUTE;
			}

			ifPtr->phyPort = i;
			ifPtr->type = IF_ETH;
			ifPtr->ifNum = 0;

			/* initialize the stats pointers */
			ifPtr->fp_if_stats = NULL;
			/* Intialising PhyPorts with bridge and route tables */
#ifdef HW_SIM
			ifPtr->vlan = 0x9;
			ifPtr->inSessid = 0x1;
#else /*Else of  HW_SIM*/
#ifdef __FP_OS__
			ifPtr->rtv4Table   = fp_router_hash_table;
#else
//			ifPtr->rtv4Table   = &peRouteTable;
#endif
			ifPtr->vlan = 0;
			ifPtr->inSessid = 0;
			ifPtr->valid = 0;
#endif /*End of HW_SIM*/
			ifPtr->u.rtv6Table = NULL;
			ifPtr->ifadmin_status = FP_IF_ADMIN_STATUS_DOWN;
			ifPtr->ipaddr = 0x11223344;
#ifdef HW_SIM
			if (j == 0)
			{
				ifPtr->ifMatchFlags = IF_MATCH_PHYPORT;
				ifPtr->type = IF_ETH;
			}
			else if (j == 1)
			{
				ifPtr->ifMatchFlags = IF_MATCH_PHYPORT | IF_MATCH_VLAN | IF_MATCH_PPPOE;
				ifPtr->type = IF_PPPOE_VLAN;
			}
			else if (j == 2)
			{
				ifPtr->ifMatchFlags = IF_MATCH_PHYPORT | IF_MATCH_PPPOE;
				ifPtr->type = IF_PPPOE;
			}
			else if (j == 3)
			{
				ifPtr->ifMatchFlags = IF_MATCH_PHYPORT | IF_MATCH_VLAN;
				ifPtr->type = IF_VLAN;
			}
#endif
		}
	}
}

/****************************************************************************
 * Function Name  : fp_init
 * Description    : Helper routine to intialize Interface Port Data Structures
 *                  and Phyport Data Structures with default parameters
 * Inputs
 *   Parameters   : -
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 ****************************************************************************/
void fp_route_init(void)
{
	/* TODO : hard coded route */
	//switch_port_list_mask = 0;

	//grtHashArr = (struct cacheFlow *)npu_get_routehash_addr();

	/*Disable firmware route fetch*/
	enable_fw_route_search = 0;

	/* initialize physical ports */
	fp_init_ports();

	/* initialize logical interfaces */
	fp_init_interfaces();
}
