/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          fp_interface.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    This file has all physical ports and logical interface structures
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifndef	_FP_INTERFACE_H_
#define	_FP_INTERFACE_H_

#define	MAX_PHY_PORTS		10
#define	MAX_LOGICAL_IFS		4

#define	FP_MAX_PORT_NAME_SIZE	32		/* max. size of port name */
#define	FP_IF_IDX_ALL		0xFFFFFFFF	/* represents all ifls for given port */
#define	FP_PORT_IDX_ALL		0xFFFFFFFF	/* represents all ports in the system */

/* admin status for interfaces */
#define	FP_IF_ADMIN_STATUS_DOWN	0	/* interface is not configured yet */
#define	FP_IF_ADMIN_STATUS_UP	1	/* interface is configured */

typedef struct fp_ifstats_s {
	uint32a	rx_pkts;	/* total rx packets for the logical intf. */
	uint32a	tx_pkts;	/* total tx packets for the logical intf. */
} fp_if_stats_t;

typedef struct fp_portstats_s {
	uint32a	rx_pkts;	/* total rx packets for the physical port */
	uint32a	tx_pkts;	/* total tx packets for the physical port */
} fp_port_stats_t;

/* global stats structures for interfaces and ports */
#if 0
#ifdef __FP_OS__
extern fp_if_stats_t fp_if_stats[MAX_PHY_PORTS][MAX_LOGICAL_IFS];
#else
#ifdef PE_LMEM_EN
extern fp_if_stats_t (*fp_if_stats)[4];
#else
extern fp_if_stats_t fp_if_stats[MAX_PHY_PORTS][MAX_LOGICAL_IFS];
#endif
#endif
#endif
extern fp_port_stats_t fp_port_stats[MAX_PHY_PORTS];

/*
 * fp_IfData_t represents a logical interface. Each physical
 * interface/port can have multiple logical interfaces.
 */
typedef struct IfData {
	uint16	ifMatchFlags;
	uint8	opFlags;
	uint8	phyPort;
	uint16	inSessid;
	uint16	vlan;
	uint8	ifadmin_status;	/*FP_IF_ADMIN_STATUS_DOWN/FP_IF_ADMIN_STATUS_UP*/
	uint8	valid;		/* unique identifier for interface usage */
	uint8	ifNum;		/* interface num */
	uint8	type;
	uint32a	ipaddr;		/*To store local ip address*/
	uint8	mac[6];		/*find a way to convert this*/
	uint16	res2;
	void		*rtv4Table;
	fp_if_stats_t *fp_if_stats;	/* pointer to global if stats structure */
	uint32a	r_ipv4;		/*Store remote ip address*/
#ifndef HW_LMEM_BRCM
	uint32a	l_ipv6[4];
	uint32a	r_ipv6[4];
#endif
	union {
	uint16	brHash;
	uint8	brGrpNo;
	uint8	res;
	uint16	gemId;
	uint8	noOfEthTypes;
	uint8	noOfVpvc;
	uint16	outSessid;
	uint16	vpvc[1];
	uint16	ethTypes_0[2];	/*find a way to convert this*/
	uint16	ethTypes_1[2];	/*find a way to convert this*/
	uint16	rtv6Hash;
	uint16	rtv4Hash;
	/* FIXME - these pointers should be hash arry rather than table structure*/
	void		*rtv6Table;
	void		*brTable;
	/* FIXME - AVOID the device pointer */
	void		*device;	/* pointer to device */
	/* FIXEME - avoid this pointer reference */
	}u;

} fp_IfData_t;	/* SIZE - 72Bytes--For BRCM  */
extern fp_IfData_t gIfPorts[MAX_PHY_PORTS][MAX_LOGICAL_IFS];

/*
 * fp_phyPort_t represents a physical port. This data structure contains all
 * logical interfaces attached to a given physical port
 */
typedef struct phyPort {
	fp_IfData_t *ifPtr;
	uint16	mediaType;
	uint8	maxLogicalIfs;
	uint8	curLogicalIfs;
	uint8	res;		/*Reserved one byte*/
	uint8	phyno;		/*Physical port number*/
	uint16	commonIfFlags;	/*common for all logical interfaces */
	fp_port_stats_t	fp_port_stats;	/*pointer to global port stats structure*/
	void *device;			/*pointer to the linux device */
} fp_phyPort_t; /* SiZE - 24 Bytes */

extern fp_phyPort_t gPhyPorts[MAX_PHY_PORTS];

/* table to map port id to port name */
extern int8 phyPortNames[MAX_PHY_PORTS][FP_MAX_PORT_NAME_SIZE];

/* opFlags for Bridge and Route */
#define	IF_STATUS		0x1  // 1- UP, 0 - DOWN
#define	IF_BRIDGE		0x2
#define	IF_ROUTE		0x4
#define	IF_VLAN_BRIDGE	0x8

/* Matching flags to interface criteria */
#define	IF_MATCH_PHYPORT	0x1
#define	IF_MATCH_VLAN		0x2
#define	IF_MATCH_PPPOE		0x4
#define	IF_MATCH_SMAC		0x8
#define	IF_MATCH_ETHTYPE	0x10
#define	IF_MATCH_SIPADDR	0x20
#define	IF_MATCH_VPVC		0x40
#define	IF_MATCH_GEMID		0x80

/* Interface type values */
#define	IF_UNKNOWN		0x0   /* this must be the first one */
#define	IF_ETH			0x1
#define	IF_VLAN			0x2
#define	IF_PPPOE		0x3
#define	IF_PPPOE_VLAN		0x4
#define	IF_IPOA			0x5
#define	IF_PPPOA		0x6
#define	IF_PPPOE_ATM		0x7
#define	IF_PPPOE_VLAN_ATM	0x8
#define	IF_ETHOA		0x9
#define	IF_MAX			0xA   /* this must be the last one */

/* Physical ports Media Types */
#define	IF_MEDIA_UNKNOWN              0x0   /* this must be the first one */
#define	IF_MEDIA_ATM		0x1
#define	IF_MEDIA_ETHERNET	0x2
#define	IF_MEDIA_WLAN		0x3
#define	IF_MEDIA_GPON		0x4
#define	IF_MEDIA_MAX		0x5   /* this must be the last one */

#define NFP_IFPORT_STATS(phyno,ifnum,field) do { \
	fp_if_stats[phyno][ifnum].field++; \
} while(/*CONSTCOND*/0)

#define NFP_PHYPORT_STATS(phyno,field) do { \
	fp_port_stats[phyno].field++; \
} while(/*CONSTCOND*/0)
#endif  /*End of _FP_INTERFACE_H_ File */

