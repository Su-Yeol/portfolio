// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_switch_api.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    contains switch API functions
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                      Include Files
 **********************************************************************/
#include <linux/string.h>

#include "reg_hal.h"
#include "fp_library.h"
#include "fp_macros.h"
#include "fp_port.h"
#include "fp_switch_api.h"
#include "switchApi_blocks_ctrlm.h"
#include "fp_switch.h"
#include "hw_2field_hash_table.h"
#include "hw_vlan_hash_table.h"
#include "global_address_map_fpga.h"

/**********************************************************************
 *                                      #defines
 **********************************************************************/


/**********************************************************************
 *                              Extern Declarations
***********************************************************************/

/* VLAN (BD) Hash table action entry map:*
*=======================================*
* [19:00]         - forward port list
* [39:20]         - untag list
* [42:40]         - ucast_hit_action
* [45:43]         - mcast_hit_action
* [48:46]         - ucast_miss_action
* [51:49]         - mcast_miss_action
* [54:52]         - mstp
* [64:55]         - Not used yet
*=======================================*/

/*******************************************************************
 * Function Name  : fp_br_entry_add
 * Description    : Adds an bridge entry into vlan hash table
 * Inputs         :
 * Parameters     : vlanId, fwdPortList, untagList, ucastHitAct, mcastHitAct,
 *                  ucastMissAct, mcastMissAct, mstpAct
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_br_entry_add(uint32a vlanId,
			uint32a fwdPortList,
			uint32a untagList,
			uint32a ucastHitAct,
			uint32a mcastHitAct,
			uint32a ucastMissAct,
			uint32a mcastMissAct,
			uint32a mstpAct)
{
	uint32a field_entries[5];
	int64 action_entry = 0;
	int64 i = 0;

	/*vlan id validation*/
	if (vlanId < SWITCHAPI_MIN_VLAN_ID || vlanId > SWITCHAPI_MAX_VLAN_ID) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_VLANID %d\n", __func__, vlanId);
#endif
		return SWITCHAPI_ERR_MSG_VLANID;
	}

	for (i = 0; i < FP_MAX_PORTS; i++) {
		if (((fwdPortList >> i) & 0x1)) {
			if (!((FWD_PORT_LIST_MASK >> i) & 0x1)) {
				return SWITCHAPI_ERR_MSG_FWDPORTLIST;
			}
		}
	}

	/*untag list validation*/
	for (i = 0; i < FP_MAX_PORTS; i++) {
		if (((untagList >> i) & 0x1)) {
			if (!((FWD_PORT_LIST_MASK >> i) & 0x1)) {
				return SWITCHAPI_ERR_MSG_UNTAGLIST;
			}
		}
	}
	/*unicast hit action validation*/
	if (ucastHitAct < SWITCHAPI_MIN_UCASTHITACT ||
			ucastHitAct > SWITCHAPI_MAX_UCASTHITACT) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_UCASTHITACT %d\n", __func__,
			ucastHitAct);
#endif
		return SWITCHAPI_ERR_MSG_UCASTHITACT;
	}
	/*multicast hit action validation*/
	if (mcastHitAct < SWITCHAPI_MIN_MCASTHITACT ||
			mcastHitAct > SWITCHAPI_MAX_MCASTHITACT) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_MCASTHITACT %d\n", __func__,
			mcastHitAct);
#endif
		return SWITCHAPI_ERR_MSG_MCASTHITACT;
	}
	/*unicast miss action validation*/
	if (ucastMissAct < SWITCHAPI_MIN_UCASTMISSACT ||
			ucastMissAct > SWITCHAPI_MAX_UCASTMISSACT) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_UCASTMISSACT %d\n", __func__,
			ucastMissAct);
#endif
		return SWITCHAPI_ERR_MSG_UCASTMISSACT;
	}

	/*multicast miss action validation*/
	if (mcastMissAct < SWITCHAPI_MIN_MCASTMISSACT ||
			mcastMissAct > SWITCHAPI_MAX_MCASTMISSACT) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_MCASTMISSACT %d\n", __func__,
			mcastMissAct);
#endif
		return SWITCHAPI_ERR_MSG_MCASTMISSACT;
	}
	/*mstp action validation*/
	if (mstpAct < SWITCHAPI_MIN_MCASTMISSACT ||
			mstpAct > SWITCHAPI_MAX_MCASTMISSACT) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_MSTPACT %d\n", __func__,
			mstpAct);
#endif
		return SWITCHAPI_ERR_MSG_MSTPACT;
	}
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"ADD:vlanId:%x, fwdPortList:%x, untaglist:%x\n",
			vlanId, fwdPortList, untagList);
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"ucasthit:%x, mcasthit:%x\n",
			ucastHitAct, mcastHitAct);
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"ucastMissAct:%x, mcastmiss:%x, mstp:%x\n",
			ucastMissAct, mcastMissAct, mstpAct);
	field_entries[0] = vlanId;
	action_entry = (((fwdPortList << BRENTRY_FWD_PORT_LIST_START_POS)
				& BRENTRY_FWD_PORT_LIST_MASK) |
			(((uint64)untagList << BRENTRY_UNTAG_LIST_START_POS)
				& BRENTRY_UNTAG_LIST_MASK) |
			(((uint64)ucastHitAct << BRENTRY_UCAST_HIT_ACT_START_POS)
				& BRENTRY_UCAST_HIT_ACT_MASK) |
			(((uint64)mcastHitAct << BRENTRY_MCAST_HIT_ACT_START_POS)
				& BRENTRY_MCAST_HIT_ACT_MASK) |
			(((uint64)ucastMissAct << BRENTRY_UCAST_MISS_ACT_START_POS)
				& BRENTRY_UCAST_MISS_ACT_MASK) |
			(((uint64)mcastMissAct << BRENTRY_MCAST_MISS_ACT_START_POS)
				& BRENTRY_MCAST_MISS_ACT_MASK) |
			(((int64)mstpAct << BRENTRY_MSTP_HIT_ACT_START_POS)
				& BRENTRY_MSTP_HIT_ACT_MASK)
			);
	return wsp_vlan_entry_add(field_entries, 0,
				action_entry, BIT_SET_VLAN_1F_VLANTBL);
}

/*******************************************************************
 * Function Name  : fp_br_entry_add_ports
 * Description    : Add ports to existing bridge entry
 * Inputs         :
 * Parameters     : vlanId, PortList, untagList
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_br_entry_add_ports(uint32a vlanId, uint32a portList, uint32a untagList)
{
	uint32a field_entries[5];
	int64 action_entry = 0;

	/*vlan id validation*/
	if (vlanId < SWITCHAPI_MIN_VLAN_ID || vlanId > SWITCHAPI_MAX_VLAN_ID) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_VLANID %d\n", __func__, vlanId);
#endif
		return SWITCHAPI_ERR_MSG_VLANID;
	}
	/*port list validation*/
	if (portList < SWITCHAPI_MIN_PORT_LIST ||
			portList > SWITCHAPI_MAX_PORT_LIST) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_PORTLIST %d\n",
			__func__, portList);
#endif
		return SWITCHAPI_ERR_MSG_PORTLIST;
	}

	/*untag list validation*/
	if (untagList < SWITCHAPI_MIN_UNTAG_LIST ||
			untagList > SWITCHAPI_MAX_UNTAG_LIST) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_UNTAGLIST %d\n",
			__func__, untagList);
#endif
		return SWITCHAPI_ERR_MSG_UNTAGLIST;
	}
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
		"ADDPORTS:vlanId:%x, fwdPortList:%x, untaglist:%x\r\n",
				vlanId, portList, untagList);
	field_entries[0] = vlanId;
	action_entry = wsp_vlan_entry_search(vlanId);
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "action entry:%llx\r\n",
					action_entry);
	/* clear the target feilds in action entry */
	action_entry = (action_entry &
				~(portList |
				(portList << BRENTRY_UNTAG_LIST_START_POS)));
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"after clear action entry:%llx\r\n", action_entry);
	/* update the target feilds */
	action_entry = action_entry |
				((portList & FWD_PORT_LIST_MASK) |
				((untagList & FWD_PORT_LIST_MASK) <<
				BRENTRY_UNTAG_LIST_START_POS));
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "modified action entry:%llx\r\n",
								action_entry);
	return wsp_vlan_entry_update(field_entries,
				action_entry, BIT_SET_VLAN_1F_VLANTBL);
}

/*******************************************************************
 * Function Name  : fp_br_entry_portlist_get
 * Description    : Get ports list from bridge entry
 * Inputs         :
 * Parameters     : vlanId
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_br_entry_portlist_get(uint32a vlanId)
{
	int64 action_entry = 0;
	/*vlan id validation*/
	if (vlanId < SWITCHAPI_MIN_VLAN_ID || vlanId > SWITCHAPI_MAX_VLAN_ID) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_VLANID %d\n", __func__, vlanId);
#endif
		return SWITCHAPI_ERR_MSG_VLANID;
	}
	action_entry = wsp_vlan_entry_search(vlanId);
	if (action_entry == -1)
		return 0;
	action_entry = action_entry & FWD_PORT_LIST_MASK;
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
		"GETPORTS:vlanId:%x, fwdPortList:%x\r\n", vlanId, (uint32a)action_entry);
	return action_entry;
}

/*******************************************************************
 * Function Name  : fp_br_entry_search
 * Description    : Get bridge entry from bridge table
 * Inputs         :
 * Parameters     : vlanId
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int64 fp_br_entry_search(uint32a vlanId)
{
	int64_t action_entry = 0;
	/*vlan id validation*/
	if (vlanId < SWITCHAPI_MIN_VLAN_ID || vlanId > SWITCHAPI_MAX_VLAN_ID) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_VLANID %d\n", __func__, vlanId);
#endif
		return SWITCHAPI_ERR_MSG_VLANID;
	}
	action_entry = wsp_vlan_entry_search(vlanId);
	return action_entry;
}

/*******************************************************************
 * Function Name  : fp_br_entry_untaglist_get
 * Description    : Get port's untag list from bridge entry
 * Inputs         :
 * Parameters     : vlanId
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_br_entry_untaglist_get(uint32a vlanId)
{
	int64 action_entry = 0;
	/*vlan id validation*/
	if (vlanId < SWITCHAPI_MIN_VLAN_ID || vlanId > SWITCHAPI_MAX_VLAN_ID) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_VLANID %d\n", __func__, vlanId);
#endif
		return SWITCHAPI_ERR_MSG_VLANID;
	}
	action_entry = wsp_vlan_entry_search(vlanId);
	action_entry = ((action_entry >> BRENTRY_UNTAG_LIST_START_POS) &
							FWD_PORT_LIST_MASK);
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"GETUNTAGLIST:vlanId:%x, untaglist:%llx\r\n",
			vlanId, action_entry);
	return action_entry;
}

/*******************************************************************
 * Function Name  : fp_br_entry_port_tag_chg
 * Description    : change port's tag value
 * Inputs         :
 * Parameters     : vlanId, portNo and Tagvalue
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_br_entry_port_tag_chg(uint32a vlanId, uint32a portNo, uint32a TagValue)
{
	uint32a field_entries[5];
	int64 action_entry = 0;
	action_entry = wsp_vlan_entry_search(vlanId);
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "PORTTAGCHG\r\n");
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "action entry:%llx\r\n",
							action_entry);
	/* CHK: Is the port is already in the fwd port list */
	if (portNo & ~FWD_PORT_LIST_MASK)
		return -1;
	/* clear the target feilds in action entry */
	action_entry = (action_entry &
		~(portNo << BRENTRY_UNTAG_LIST_START_POS));
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"after clear action entry:%llx\r\n", action_entry);
	/* update the target feilds */
	action_entry = action_entry | ((TagValue & portNo) <<
				BRENTRY_UNTAG_LIST_START_POS);
	field_entries[0] = vlanId;
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"modified action entry:%llx\r\n", action_entry);
	return wsp_vlan_entry_update(field_entries,
				action_entry, BIT_SET_VLAN_1F_VLANTBL);
}

/*******************************************************************
 * Function Name  : fp_br_entry_fwd_action_get
 * Description    : Get fwd action entry from bridge entry
 * Inputs         :
 * Parameters     : vlanId
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int64 fp_br_entry_fwd_action_get(uint32a vlanId)
{
	int64 action_entry = 0;
	/*vlan id validation*/
	if (vlanId < SWITCHAPI_MIN_VLAN_ID ||
			vlanId > SWITCHAPI_MAX_VLAN_ID) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
		"%s:SWITCHAPI_ERR_MSG_VLANID %d\n", __func__, vlanId);
#endif
		return SWITCHAPI_ERR_MSG_VLANID;
	}
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
		"entered in fp_br_entry_fwd_action_get function\n");
	action_entry = wsp_vlan_entry_search(vlanId);
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
		"GETACT:vlanId:%x, fwdact:%llx \r\n", vlanId, action_entry);
	return action_entry;
}

/*******************************************************************
 * Function Name  : fp_port_config_get
 * Description    : To get port's config
 * Inputs         :
 * Parameters     : portNo, struct port_s *
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_port_config_get(uint8 *dev, uint32a portNo, struct port_s *pPortInfo)
{
	/* uint32a port_addr = PORT_BASE_ADDR +
			(portNo * sizeof(struct port_s)); */
	int32a ret = 0;
	/*port number validation*/
	if (portNo < SWITCHAPI_MIN_PORT_NO ||
			portNo > SWITCHAPI_MAX_PORT_NO) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_PORTNO %d\n", __func__, portNo);
#endif
		return SWITCHAPI_ERR_MSG_PORTNO;
	}
	/* FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "GETPORTCFG:\r\n"); */
	if (pPortInfo != NULL) {
		memcpy(pPortInfo, &fp_port[portNo], sizeof(struct port_s));
		/* fp_read_hw_data((uint8 *)pPortInfo,
					port_addr, sizeof(struct port_s)); */
		/* FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"portno:%x, shutdown:%x, tpid:%x\r\n", portNo,
			pPortInfo->shutdown, pPortInfo->tpid); */
		/* FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"aft:%x, fallback_bd_id:%x, blockstate:%x\r\n",
			pPortInfo->aft, pPortInfo->fallback_bd_id,
			pPortInfo->block_state); */
	} else {
		ret = -1;
	}
	return ret;
}

/*******************************************************************
 * Function Name  : fp_global_br_entry_config_get
 * Description    : To get global bridge entry's data
 * Inputs         :
 * Parameters     : struct global_s *
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_global_br_entry_config_get(	struct global_s *pGlobal_br_entry)
{
	/* uint32a global_addr = GLOBAL_BR_ENTRY_ADDR; */
	int32a ret = 0;
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "GETGLOBAL:\r\n");
	if (NULL != pGlobal_br_entry) {
		memcpy(pGlobal_br_entry, &fp_global,
					sizeof(struct global_s));
		/* fp_read_hw_data((uint8 *)pGlobal_br_entry,
				global_addr, sizeof(struct global_s)); */
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
				"In function fp_global_br_entry_config_get"
				"l2splpunt:%x, brentry:%lx\r\n",
				pGlobal_br_entry->l2_special_punt_enable,
				(uint32)(&pGlobal_br_entry->fallback_bd_entry));
	} else {
		ret = -1;
	}
return ret;
}

/*******************************************************************
 * Function Name  : fp_br_entry_fwd_action_change
 * Description    : Changes action feilds of an existing bridge entry
 * Inputs         :
 * Parameters     : vlanId, field, field_value
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_br_entry_fwd_action_change(uint32a vlanId, uint32a field, uint32a value)
{
	uint32a field_entries[5];
	int64 action_entry = 0;
	int32a ret = 0;
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "FWD_ACT_CHG:\r\n");
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "vlan:%x,field:%x,value:%x\r\n",
							vlanId, field, value);
	/*vlan id validation*/
	if (vlanId < SWITCHAPI_MIN_VLAN_ID || vlanId > SWITCHAPI_MAX_VLAN_ID) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_VLANID %d\n", __func__, vlanId);
#endif
		return SWITCHAPI_ERR_MSG_VLANID;
	}
	/*field validation*/
	if (field < SWITCHAPI_MIN_FIELD || field > SWITCHAPI_MAX_FIELD) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_FIELD %d\n", __func__, field);
#endif
		return SWITCHAPI_ERR_MSG_FIELD;
	}
	/*value validation*/
	if (value < SWITCHAPI_MIN_VALUE || value > SWITCHAPI_MAX_VALUE) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_VALUE %d\n", __func__, value);
#endif
		return SWITCHAPI_ERR_MSG_VALUE;
	}
	field_entries[0] = vlanId;
	action_entry = wsp_vlan_entry_search(vlanId);
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"before actionentry:%llx\r\n", action_entry);
	if (action_entry != -1) {
		switch (field) {
			/* clear the targetted feilds and set the new values */
#if 0 /* These two are not actions */
		case BRENTRY_FWDPORT:
			action_entry = (action_entry & ~FWD_PORT_LIST_MASK) |
				(value << BRENTRY_FWD_PORT_LIST_START_POS);
		break;
		case BRENTRY_UNTAGLIST:
		action_entry = (action_entry & ~BRENTRY_UNTAG_LIST_MASK) |
				(value << BRENTRY_UNTAG_LIST_START_POS);
		break;
#endif
		case BRENTRY_UCAST_HIT:
			action_entry =
				(action_entry & ~BRENTRY_UCAST_HIT_ACT_MASK) |
				((uint64)value << BRENTRY_UCAST_HIT_ACT_START_POS);
		break;
		case BRENTRY_MCAST_HIT:
			action_entry =
				(action_entry & ~BRENTRY_MCAST_HIT_ACT_MASK) |
				((uint64)value  << BRENTRY_MCAST_HIT_ACT_START_POS);
		break;
		case BRENTRY_UCAST_MISS:
			action_entry =
				(action_entry & ~BRENTRY_UCAST_MISS_ACT_MASK) |
				((uint64)value << BRENTRY_UCAST_MISS_ACT_START_POS);
		break;
		case BRENTRY_MCAST_MISS:
			action_entry =
				(action_entry & ~BRENTRY_MCAST_MISS_ACT_MASK) |
				((uint64)value  << BRENTRY_MCAST_MISS_ACT_START_POS);
		break;
		case BRENTRY_MSTP:
			action_entry =
				(action_entry & ~BRENTRY_MSTP_HIT_ACT_MASK) |
				((uint64)value << BRENTRY_MSTP_HIT_ACT_START_POS);
		break;
		default:
		break;
		}
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
				"after action entry:%llx\r\n", action_entry);
		ret = wsp_vlan_entry_update(field_entries,
				action_entry, BIT_SET_VLAN_1F_VLANTBL);
	} else {
		ret = -1;
	}
	return ret;
}

/*******************************************************************
 * Function Name  : fp_port_config
 * Description    : Configures port
 * Inputs         :
 * Parameters     : portNo, struct posrt_s *
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_port_config(uint32a portNo, struct port_s *pPort)
{
	int32a ret = 0;
	uint32a addr1, addr2, i = 0;
	/* uint32a port_addr = PORT_BASE_ADDR +
			(portNo * sizeof(struct port_s)); */
	/*port number validation*/
	if (portNo < SWITCHAPI_MIN_PORT_NO || portNo > SWITCHAPI_MAX_PORT_NO) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_PORTNO %d\n", __func__, portNo);
#endif
		return SWITCHAPI_ERR_MSG_PORTNO;
	}
	/* FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
				"PORTCFG: port_addr:%x\r\n", port_addr); */
	if ((portNo < FP_MAX_SWITCH_PORTS) && pPort) {
		/* FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
				"portno:%x, shutdown:%x, tpid:%x\r\n", portNo,
				pPort->shutdown, pPort->tpid); */
		/* FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
				"aft:%x, fallback_bd_id:%x, blockstate:%x\r\n",
				pPort->aft, pPort->fallback_bd_id,
				pPort->block_state); */
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
				"before memcpy shutdown = %x\ntpid = %x\n"
				"aft = %x\nfallback_bd_id = %x\n"
				"block_state = %x\ntrusted = %x\n"
				"tcsel_table = %x\npcp2tc_table = %x\n"
				"def_cfi = %x\ndef_pri = %x\ndef_tc = %x\n"
				"tc2cos_table = %x\npindex = %x\n"
				"csr_untag_from_btable = %x", pPort->shutdown,
				pPort->tpid, pPort->aft, pPort->fallback_bd_id,
				pPort->block_state, pPort->trusted,
				pPort->tcsel_table, pPort->pcp2tc_table,
				pPort->def_cfi, pPort->def_pri, pPort->def_tc,
				pPort->tc2cos_table, pPort->pindex,
				pPort->csr_untag_from_btable);
		memcpy(&fp_port[portNo], pPort, sizeof(struct port_s));
		/* START */
		i = portNo;
		fp_get_port_addr(portNo, &addr1, &addr2);
		/* class hw port csr reg:
		*=============================================================*
		* res | block_state | aft | shutdown | fallback_bd_id | tpid  *
		*=============================================================*
		* 20-bit| 4-bit     |4-bit| 1-bit    | 16-bit         |16-bit *
		*=============================================================*/
		if (addr1 && addr2) {
			RegWrite(addr1,
				((fp_port[i].fallback_bd_id <<
				PORT_FALLBACK_BDID_START_POS) &
				PORT_FALLBACK_BDID_MASK) |
				((fp_port[i].tpid << PORT_TPID_START_POS) &
				PORT_TPID_MASK));
			RegWrite(addr2,
				((fp_port[i].csr_untag_from_btable <<
				PORT_UNTAG_FROM_BTABLE_START_POS) &
				PORT_UNTAG_FROM_BTABLE_MASK) |
				((fp_port[i].block_state <<
				PORT_BLOCKSTATE_START_POS) &
				PORT_BLOCKSTATE_MASK)        |
				((fp_port[i].aft << PORT_AFT_START_POS) &
				PORT_AFT_MASK) |
				((fp_port[i].shutdown <<
				PORT_SHUTDOWN_START_POS) &
				PORT_SHUTDOWN_MASK));
		}
		/* END */
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"after memcpy shutdown = %x\ntpid = %x\naft = %x\n"
			"fallback_bd_id = %x\nblock_state = %x\ntrusted = %x\n"
			"tcsel_table = %x\npcp2tc_table = %x\ndef_cfi = %x\n"
			"def_pri = %x\ndef_tc = %x\ntc2cos_table = %x\n"
			"pindex = %x\ncsr_untag_from_btable = %x",
			fp_port[portNo].shutdown, fp_port[portNo].tpid,
			fp_port[portNo].aft, fp_port[portNo].fallback_bd_id,
			fp_port[portNo].block_state, fp_port[portNo].trusted,
			fp_port[portNo].tcsel_table,
			fp_port[portNo].pcp2tc_table,
			fp_port[portNo].def_cfi, fp_port[portNo].def_pri,
			fp_port[portNo].def_tc, fp_port[portNo].tc2cos_table,
			fp_port[portNo].pindex,
			fp_port[portNo].csr_untag_from_btable);
		/* fp_write_hw_data((uint8 *)pPort, port_addr,
						sizeof(struct port_s)); */
	} else {
		ret = -1;
	}
	return ret;
}

/*******************************************************************
 * Function Name  : fp_global_br_entry_config
 * Description    : Configures GLobal bridge entry
 * Inputs         :
 * Parameters     : struct gloabl_s *
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_global_br_entry_config(	struct global_s *pGlobal_br_entry)
{
	int32a ret = 0;
	uint64 gBrEntry = 0;

	/* uint32a global_addr = GLOBAL_BR_ENTRY_ADDR; */
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "CFGGLOBAL:\r\n");

	if (NULL != pGlobal_br_entry) {
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"before writing  l2_splPunt_enable = %x,"
			"fwdPortList = %x, untagList = %xucastHitAct = %x,"
			"mcastHitAct = %x,ucastMissAct = %xmcastMissAct = %x,"
			"mstpAct = %x\n\n",
			pGlobal_br_entry->l2_special_punt_enable,
			pGlobal_br_entry->fallback_bd_entry.forward_list,
			pGlobal_br_entry->fallback_bd_entry.untag_list,
			pGlobal_br_entry->fallback_bd_entry.ucast_hit_action,
			pGlobal_br_entry->fallback_bd_entry.mcast_hit_action,
			pGlobal_br_entry->fallback_bd_entry.ucast_miss_action,
			pGlobal_br_entry->fallback_bd_entry.mcast_miss_action,
			pGlobal_br_entry->fallback_bd_entry.mstp_id);

		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"l2splpunt:%x, brentry:%lx\r\n",
			pGlobal_br_entry->l2_special_punt_enable,
			(uint32)(&pGlobal_br_entry->fallback_bd_entry));
		memcpy(&fp_global, pGlobal_br_entry,
					sizeof(struct global_s));
		/* fp_write_hw_data((uint8 *)pGlobal_br_entry,
				global_addr, sizeof(struct global_s)); */

		gBrEntry = ((((uint64)fp_global.fallback_bd_entry.ucast_hit_action <<
			BRENTRY_UCAST_HIT_ACT_START_POS) &
			BRENTRY_UCAST_HIT_ACT_MASK) |
			(((uint64)fp_global.fallback_bd_entry.ucast_miss_action <<
			BRENTRY_UCAST_MISS_ACT_START_POS) &
			BRENTRY_UCAST_MISS_ACT_MASK) |
			(((uint64)fp_global.fallback_bd_entry.mcast_hit_action <<
			BRENTRY_MCAST_HIT_ACT_START_POS) &
			BRENTRY_MCAST_HIT_ACT_MASK) |
			(((uint64)fp_global.fallback_bd_entry.mcast_hit_action <<
			BRENTRY_MCAST_MISS_ACT_START_POS) &
			BRENTRY_MCAST_MISS_ACT_MASK)  |
			(((uint64)fp_global.fallback_bd_entry.untag_list <<
			BRENTRY_UNTAG_LIST_START_POS) &
			BRENTRY_UNTAG_LIST_MASK) |
			(((uint64)fp_global.fallback_bd_entry.forward_list) &
			BRENTRY_FWD_PORT_LIST_MASK));
		gBrEntry = ((gBrEntry << 1) |
			(fp_global.l2_special_punt_enable & 0x1));
		/* RegWrite(CLASS_HW_GLOBAL_CFG,
			((gBrEntry << 1) | GLOBAL_L2_SPL_PUNT_ACT)); */
		RegWrite(CLASS_HW_GLOBAL_CFG, gBrEntry & 0xFFFFFFFF);
		RegWrite(CLASS_HW_GLOBAL_CFG1, (gBrEntry >> 32));
	} else {
		ret = -1;
	}
	return ret;
}

/*******************************************************************
 * Function Name  : fp_br_entry_del
 * Description    : Deletes an bridge entry
 * Inputs         :
 * Parameters     : vlanId
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_br_entry_del(uint32a vlanId)
{
	uint32a field_entries[5];

	/*vlan id validation*/
	if (vlanId < SWITCHAPI_MIN_VLAN_ID || vlanId > SWITCHAPI_MAX_VLAN_ID) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_VLANID %d\n", __func__, vlanId);
#endif
		return SWITCHAPI_ERR_MSG_VLANID;
	}
	field_entries[0] = vlanId;
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "DELENTRY\r\n");
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "vlanId:%x\r\n", vlanId);
	return wsp_vlan_entry_delete(field_entries, BIT_SET_VLAN_1F_VLANTBL);
}

/*******************************************************************
 * Function Name  : fp_br_entry_del_ports
 * Description    : Deletes ports from an existing bridge entry
 * Inputs         :
 * Parameters     : vlanId
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_br_entry_del_ports(uint32a vlanId, uint32a portList)
{
	uint32a field_entries[5];
	int64 action_entry = 0;

	/*vlan id validation*/
	if (vlanId < SWITCHAPI_MIN_VLAN_ID || vlanId > SWITCHAPI_MAX_VLAN_ID) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_VLANID %d\n", __func__, vlanId);
#endif
		return SWITCHAPI_ERR_MSG_VLANID;
	}
	/*port list validation*/
	if (portList < SWITCHAPI_MIN_PORT_LIST ||
			portList > SWITCHAPI_MAX_PORT_LIST) {
#if SWITCHAPI_DEBUG
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s:SWITCHAPI_ERR_MSG_PORTLIST %d\n",
			__func__, portList);
#endif
		return SWITCHAPI_ERR_MSG_PORTLIST;
	}
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "DELPORTS:\r\n");
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "vlanId:%x, PortList:%x\r\n",
			vlanId, portList);
	field_entries[0] = vlanId;
	action_entry = wsp_vlan_entry_search(vlanId);
	if (action_entry == -1)
		return 0;
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "actentry before:%llx\r\n",
			action_entry);
	action_entry = action_entry & (~((portList & FWD_PORT_LIST_MASK) |
					((portList & FWD_PORT_LIST_MASK) <<
					BRENTRY_UNTAG_LIST_START_POS)));
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "actentry after:%llx\r\n",
			action_entry);
	return wsp_vlan_entry_update(field_entries, action_entry,
			BIT_SET_VLAN_1F_VLANTBL);
}

/*******************************************************************
 * Function Name  : fp_static_mac_entry_add
 * Description    : Adds MAC entry into mac hash table
 * Inputs         :
 * Parameters     : phy_port, mac, vlanid
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_static_mac_entry_add(uint8 *mac,
				uint32a vlanid,
				uint32a fwd_ports,
				uint32a hit_action,
				uint32a tc)
{
	int32a ret = -1;
	uint32a action_entry = 0;
	uint32a field_entries[5];
	uint32a field_valids = BIT_SET_MAC_2F_MACTBL;
	uint32a *entry = (uint32a *)mac;

	/* need to updated field entries valid filed basis */
	field_entries[0] = entry[0];
	field_entries[1] = entry[1] & 0xFFFF;
	field_entries[1] |= (vlanid << 16);
	field_entries[2] = 0;
	field_entries[3] = 0;
	field_entries[4] = 0;
	/* update vlan field valid for mac table */
	field_valids |= BIT_SET_VLAN_2F_MACTBL;
	/* check for for already entry existence */
	ret = hw_hash_table_search(field_entries, field_valids);
	if (-1 == ret) { /* entry not found */
		/* fill action_entry's fresh bit */
		action_entry = FRESH_FLAG_SET | MAC_2F_ENTRY_STATIC_MASK;
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
				"%s: Search Fail before add\n", __func__);
		/* Add SMAC entry with action entry & valid fields */
		/* update action entry with port info on which it arrived */
		action_entry |= ((fwd_ports << MAC_2F_ENTRY_FWD_PORT_LIST_START_POS)
				& FWD_PORT_LIST_MASK);
		/* update TC field */
		action_entry |= ((tc << MAC_2F_ENTRY_TC_START_POS) & MAC_2F_ENTRY_TC_MASK);
		/* update hit action */
		action_entry |= (hit_action << MAC_2F_ENTRY_FWD_ACT_START_POS)
				& MAC_2F_ENTRY_FWD_ACT_MASK;
		/* add mac entry */
		ret = hw_hash_table_add(field_entries, 0,
						action_entry, field_valids);
		if (ret == -1) {
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
						"hash table add Fail\n");
		} else {
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
						"entry added successfully\n");
		}
	} else { /* entry found, but not a static one then overwrite */
		/* mac hash entry found */
		if (ret & MAC_2F_ENTRY_STATIC_MASK) {
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"%s:entry found already, not able to add\n", __func__);
			return ret;
		}
		/* non static entry, update with static data */
		/* fill action_entry's fresh bit */
		action_entry = FRESH_FLAG_SET | MAC_2F_ENTRY_STATIC_MASK;
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
				"%s: Search Fail before add\n", __func__);
		/* Add SMAC entry with action entry & valid fields */
		/* update action entry with port info on which it arrived */
		action_entry |= ((fwd_ports & FWD_PORT_LIST_MASK)
				<< MAC_2F_ENTRY_FWD_PORT_LIST_START_POS);
		/* update hit action */
		action_entry |= (hit_action << MAC_2F_ENTRY_FWD_ACT_START_POS)
				& MAC_2F_ENTRY_FWD_ACT_MASK;
		/* update TC field */
		action_entry |= ((tc << MAC_2F_ENTRY_TC_START_POS)
				& MAC_2F_ENTRY_TC_MASK);
		/* add mac entry */
		ret = hw_hash_table_update(field_entries,
						action_entry, field_valids);
		if (ret == -1) {
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
						"hash table add Fail\n");
		} else {
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
						"entry added successfully\n");
		}
	}
	return ret;
}

/*******************************************************************
 * Function Name  : fp_mac_entry_add
 * Description    : Adds MAC entry into mac hash table
 * Inputs         :
 * Parameters     : phy_port, mac, vlanid
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_mac_entry_add(uint32a phy_port, uint8 *mac, uint32a vlanid)
{
	int64 ret = -1;
	uint32a fwd_action = 0;
	uint32a action_entry = 0;
	uint32a field_entries[5];
	uint32a field_valids = BIT_SET_MAC_2F_MACTBL;
	uint32a *entry = (uint32a *)mac;
	/* need to updated field entries valid filed basis */
	field_entries[0] = entry[0];
	field_entries[1] = entry[1] & 0xFFFF;
	field_entries[1] |= (vlanid << 16);
	field_entries[2] = 0;
	field_entries[3] = 0;
	field_entries[4] = 0;
	/* FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "%s: mac1 %x mac2 %x\n",
			__func__, field_entries[0], field_entries[1]); */
	/* update vlan field valid for mac table */
	field_valids |= BIT_SET_VLAN_2F_MACTBL;
	/* check for for already entry existence */
	ret = hw_hash_table_search(field_entries, field_valids);
	if (-1 == ret) { /* entry not found */
		/* fill action_entry's fresh bit */
		action_entry = FRESH_FLAG_SET;
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
				"%s: Search Fail before add\n", __func__);
		/* Add SMAC entry with action entry & valid fields */
		/* update action entry with port info on which it arrived */
		action_entry |= ((0x1 << phy_port) & FWD_PORT_LIST_MASK);
		/* Get bridge action entry */
		ret = wsp_vlan_entry_search(vlanid);
		if (-1 == ret) {
			/* Un handeled bridge entry,
			take fwd action of fp_global br entry */
			fwd_action =
				fp_global.fallback_bd_entry.ucast_hit_action;
		} else {
			/* Get bridge action entry's unicast hit fwd action */
			fwd_action = (ret & BRENTRY_UCAST_HIT_ACT_MASK) >>
			BRENTRY_UCAST_HIT_ACT_START_POS;
		}
		/* Update mac action entry's fwd action */
		action_entry = (action_entry & ~MAC_2F_ENTRY_FWD_ACT_MASK) |
			(fwd_action << MAC_2F_ENTRY_FWD_ACT_START_POS);
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "%s: action_entry %x\n",
							__func__, action_entry);
		/* add mac entry */
		ret = hw_hash_table_add(field_entries, phy_port,
						action_entry, field_valids);
		if (ret == -1) {
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
						"hash table add Fail\n");
		} else {
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
						"entry added successfully\n");
		}
	} else { /* entry found */
		/* mac hash entry found */
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"%s:entry found already, not able to add\n", __func__);
	}
	return ret;
}

/*******************************************************************
 * Function Name  : fp_mac_entry_delete
 * Description    : Delete MAC entry from mac hash table
 * Inputs         :
 * Parameters     : mac, vlanid
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_mac_entry_del(uint8 *mac, uint32a vlanid)
{
	int32a ret = -1;
	uint32a field_entries[5];
	uint32a field_valids = BIT_SET_MAC_2F_MACTBL;
	uint32a *entry = (uint32a *)mac;
	/* need to updated field entries valid filed basis */
	field_entries[0] = entry[0];
	field_entries[1] = entry[1] & 0xFFFF;
	field_entries[1] |= (vlanid << 16);
	field_entries[2] = 0;
	field_entries[3] = 0;
	field_entries[4] = 0;
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "%s: mac1 %x mac2 %x\n",
				__func__, field_entries[0], field_entries[1]);
	/* update vlan field valid for mac table */
	field_valids |= BIT_SET_VLAN_2F_MACTBL;
	/* check for for already entry existence */
	ret = hw_hash_table_search(field_entries, field_valids);
	if (-1 == ret) { /* entry not found */
		/* fill action_entry's fresh bit */
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s: Entry not found to delete\n", __func__);
	} else { /* entry found */
		/* mac hash entry found */
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s: Entry found to delete\n", __func__);
		field_entries[0] = entry[0];
		field_entries[1] = entry[1] & 0xFFFF;
		field_entries[1] |= (vlanid << 16);
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"%s: mac1 %x mac2 %x\n", __func__, field_entries[0],
			field_entries[1]);
		hw_hash_table_delete(field_entries[0],
			field_entries[1]);
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
			"%s: mac1 %x mac2 %x\n", __func__, field_entries[0],
			field_entries[1]);
		/* check for entry after deletion */
		ret = hw_hash_table_search(field_entries,
			field_valids);
		if (-1 == ret) {
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s: Entry deleted\n", __func__);
			fp_rc_stats.hw_hash_entry_count--;
		} else { /* entry not deleted */
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
			"%s: Entry not deleted\n", __func__);
		}
	}
	return 0;
}

/*******************************************************************
 * Function Name  : fp_mac_entry_search
 * Description    : search MAC entry from mac hash table
 * Inputs         :
 * Parameters     : mac, vlanid
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_mac_entry_search(uint8 *mac, uint32a vlanid)
{
	int32a ret = -1;
	uint32a field_entries[5];
	uint32a field_valids = BIT_SET_MAC_2F_MACTBL;
	uint32a *entry = (uint32a *)mac;
	/* need to updated field entries valid filed basis */
	field_entries[0] = entry[0];
	field_entries[1] = entry[1] & 0xFFFF;
	field_entries[1] |= (vlanid << 16);
	field_entries[2] = 0;
	field_entries[3] = 0;
	field_entries[4] = 0;
	/* FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "%s: mac1 %x mac2 %x\n",
			__func__, field_entries[0], field_entries[1]); */
	/* update vlan field valid for mac table */
	field_valids |= BIT_SET_VLAN_2F_MACTBL;
	/* check for for already entry existence */
	ret = hw_hash_table_search(field_entries, field_valids);
	FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "%s: ret = %x",  __func__, ret);
	if (-1 == ret) { /* entry not found */
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
				"%s: Entry not found\n", __func__);
	} else { /* entry found */
		/* mac hash entry found */
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_EMERG,
				"%s: Entry found\n", __func__);
	}
	return ret;
}

/*******************************************************************
 * Function Name  : fp_mac_entry_update
 * Description    : Update MAC entry into mac hash table
 * Inputs         :
 * Parameters     : mac_entry, mac, vlanid
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_mac_entry_update(uint32a mac_entry, uint8 *mac, uint32a vlanid)
{
	int32a ret = -1;
	uint32a field_entries[5];
	uint32a field_valids = BIT_SET_MAC_2F_MACTBL;
	uint32a *entry = (uint32a *)mac;
	/* need to updated field entries valid filed basis */
	field_entries[0] = entry[0];
	field_entries[1] = entry[1] & 0xFFFF;
	field_entries[1] |= (vlanid << 16);
	field_entries[2] = 0;
	field_entries[3] = 0;
	field_entries[4] = 0;
	/* FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "%s: mac1 %x mac2 %x\n",
			__func__, field_entries[0], field_entries[1]); */
	/* update vlan field valid for mac table */
	field_valids |= BIT_SET_VLAN_2F_MACTBL;
	/* check for for already entry existence */
	ret = hw_hash_table_search(field_entries, field_valids);
	if (-1 == ret) { /* entry not found */
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_EMERG,
			"%s: Entry not found to update\n", __func__);
	} else { /* entry found */
		/* mac hash entry found */
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO,
				"%s: Entry found to update\n", __func__);
		/* Add SMAC entry with action entry & valid fields */
		FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_INFO, "%s: mac_entry %x\n",
							__func__, mac_entry);
		/* update mac entry */
		ret = hw_hash_table_update(field_entries,
						mac_entry, field_valids);
		if (ret == -1) {
			FP_DEBUG(DBGP_FEAT_L2API, FP_LOG_ERR,
					"hash table update Fail\n");
		}
	}
	return ret;
}
