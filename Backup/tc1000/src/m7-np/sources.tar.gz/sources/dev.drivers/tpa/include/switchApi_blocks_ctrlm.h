/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          switchApi_blocks_ctrlm.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    defines for switch apis
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifndef _SWITCH_BLOCKS_CTRLM_H_
#define _SWITCH_BLOCKS_CTRLM_H_
/***********************************************************
    DEFINES
***********************************************************/

#define SWITCHAPI_DEBUG  1

/***************** ERR_CODES ****************/

#define SWITCHAPI_ERR_BASE_ADDR		(-200)
#define SWITCHAPI_ERR_MSG_VLANID	( SWITCHAPI_ERR_BASE_ADDR + 1 )
#define SWITCHAPI_ERR_MSG_FWDPORTLIST	( SWITCHAPI_ERR_MSG_VLANID + 1 )
#define SWITCHAPI_ERR_MSG_UNTAGLIST	( SWITCHAPI_ERR_MSG_FWDPORTLIST + 1 )
#define SWITCHAPI_ERR_MSG_UCASTHITACT	( SWITCHAPI_ERR_MSG_UNTAGLIST + 1 )
#define SWITCHAPI_ERR_MSG_MCASTHITACT	( SWITCHAPI_ERR_MSG_UCASTHITACT + 1 )
#define SWITCHAPI_ERR_MSG_UCASTMISSACT	( SWITCHAPI_ERR_MSG_MCASTHITACT + 1 )
#define SWITCHAPI_ERR_MSG_MCASTMISSACT	( SWITCHAPI_ERR_MSG_UCASTMISSACT + 1 )
#define SWITCHAPI_ERR_MSG_MSTPACT	( SWITCHAPI_ERR_MSG_MCASTMISSACT + 1 )
#define SWITCHAPI_ERR_MSG_PORTLIST	( SWITCHAPI_ERR_MSG_MSTPACT + 1 )
#define SWITCHAPI_ERR_MSG_PORTNO	( SWITCHAPI_ERR_MSG_PORTLIST + 1 )
#define SWITCHAPI_ERR_MSG_FIELD		( SWITCHAPI_ERR_MSG_PORTNO + 1 )
#define SWITCHAPI_ERR_MSG_VALUE		( SWITCHAPI_ERR_MSG_FIELD + 1 )
#define SWITCHAPI_ERR_MSG_LTC_TIMEDIFF	( SWITCHAPI_ERR_MSG_VALUE + 1 )

/*scheduler defines*/
#define SWITCHAPI_MIN_VLAN_ID			0x01
#define SWITCHAPI_MAX_VLAN_ID			4093
#define SWITCHAPI_MIN_FWDPORTLIST		0x00
#define SWITCHAPI_MAX_FWDPORTLIST		0x0f
#define SWITCHAPI_MIN_UCASTHITACT		0x00
#define SWITCHAPI_MAX_UCASTHITACT		0x06
#define SWITCHAPI_MIN_MCASTHITACT		0x00
#define SWITCHAPI_MAX_MCASTHITACT		0x06
#define SWITCHAPI_MIN_UCASTMISSACT		0x00
#define SWITCHAPI_MAX_UCASTMISSACT		0x06
#define SWITCHAPI_MIN_MCASTMISSACT		0x00
#define SWITCHAPI_MAX_MCASTMISSACT		0x06
#define SWITCHAPI_MIN_MSTPACT			0x00
#define SWITCHAPI_MAX_MSTPACT			0x06
#define SWITCHAPI_MIN_ACTION_TYPE 		0x01
#define SWITCHAPI_MAX_ACTION_TYPE 		0x04
#define SWITCHAPI_MIN_PORT_NO			0x00
#define SWITCHAPI_MAX_PORT_NO			0x03
#define SWITCHAPI_MIN_PORT_LIST			0x00
#define SWITCHAPI_MAX_PORT_LIST			0x0f
#define SWITCHAPI_MIN_UNTAG_LIST		0x00
#define SWITCHAPI_MAX_UNTAG_LIST		0x0f
#define SWITCHAPI_MIN_TAG_VALUE			0x00
#define SWITCHAPI_MAX_TAG_VALUE			0x0f
#define SWITCHAPI_MIN_FIELD			0x00
#define SWITCHAPI_MAX_FIELD			0x04
#define SWITCHAPI_MIN_VALUE			0x00
#define SWITCHAPI_MAX_VALUE			0x06
#define SWITCHAPI_MIN_ACTION_FIELD_TYPE		0x00
#define SWITCHAPI_MAX_ACTION_FIELD_TYPE		0x06
#define SWITCHAPI_MIN_STATIC_VALUE		0x00
#define SWITCHAPI_MAX_STATIC_VALUE		0x01

/*Bridge Entry Add structure*/
typedef struct _switch_br_entry_add_params_t_ {
	uint32a swbea_vlanId;
	uint32a swbea_fwdPortList;
	uint32a swbea_untagList;
	uint32a swbea_ucastHitAct;
	uint32a swbea_mcastHitAct;
	uint32a swbea_ucastMissAct;
	uint32a swbea_mcastMissAct;
	uint32a swbea_mstpAct;
} switch_br_entry_add_params_t;


/*Bridge Entry Add Ports structure*/
typedef struct _switch_br_entry_add_ports_params_t_ {
	uint32a swbeap_vlanId;
	uint32a swbeap_portList;
	uint32a swbeap_untagList;
} switch_br_entry_add_ports_params_t;


/*Bridge Entry Port Tag Change structure*/
typedef struct _switch_br_entry_port_tag_chg_params_t_ {
	uint32a ptchg_vlanId;
	uint32a ptchg_portNo;
	uint32a ptchg_tagValue;
} switch_br_entry_port_tag_chg_params_t;


/*Bridge Entry Farward Action Change structure*/
typedef struct _switch_br_entry_farward_action_chg_params_t_ {
	uint32a pfachg_vlanId;
	uint32a pfachg_field;
	uint32a pfachg_value;
} switch_br_entry_farward_action_chg_params_t;

/*Mac entry structure */
typedef struct _switch_fp_mac_entry_params_t_ {
	uint8 addr[6];
	uint32a swbea_vlanId;
	uint32a swbea_fwdPortList;
	uint32a swbea_hitAct;
	uint32a swbea_tc;
} switch_fp_mac_entry_params_t;

typedef struct _ing_qos_data_t_ {
	uint32a data[8];
} ing_qos_data_t;

/* forward declaration to avoid warnings */
struct net_device;
struct ifreq;

int32a pcm_switchApi_config_ioctl(struct net_device *dev,struct ifreq *rq, int32a cmd);

#endif /*End of _SWITCH_BLOCKS_CTRLM_H_*/
