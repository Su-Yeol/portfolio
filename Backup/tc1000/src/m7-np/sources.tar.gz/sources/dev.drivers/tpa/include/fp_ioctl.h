/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          fp_ioctl.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    contains user level data structures for cli
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifndef  _FP_IOCTL_H_
#define  _FP_IOCTL_H_

#include "fp_types.h"	//	only needed for struct fp_table_type_t
#include "fp_stats.h"

#if 0
int32a getFPStats(fp_stats_t *fpStats);
int32a getIoctlInt(int32a fp_request, int32a *iValue, int8 *argv[]);
int32a getIoctlIntVals(int32a fp_request, int8 *argv[], int32a *intCnt, void **buffer);
int32a writeMem(int32a fp_request, int8 *argv[]);
int32a getEntries(int32a entryNum, int32a entryType, int32a *numEntries, void **entries);
#endif
typedef struct nc_ioctl_ops_s {
	uint16 io_cmd;
	uint16 io_size;
	int8    *io_data;
} nc_ioctl_ops_t;
#define NC_CMD_BASE		SIOCDEVPRIVATE
/* Upto case-5 direct ioctl using */
#define NC_STATS_GET       	NC_CMD_BASE + 6		/*  GET FPSTATS */
#define NC_SWITCH_ENTRIES_GET	NC_CMD_BASE + 7		/* GET BRDIGE ENTRIES */
#define NC_ROUTE_ENTRIES_GET	NC_CMD_BASE + 8		/* GET ROUTE ENTRIES */
#define NC_SET_FASTPATH		NC_CMD_BASE + 9		/* enable or disable fastpath */
#define NC_DEBUGSTATS_GET	NC_CMD_BASE + 10	/* GET DEBUG STATS */
#define NC_DEBUGPRINTS_ENABLE	NC_CMD_BASE + 11	/* DEBUG PRINTS ENABLE */
#define NC_DEBUGPRINTS_DISABLE	NC_CMD_BASE + 12	/* DEBUG PRINTS DISABLE */
#ifdef _FEATURE_RTP_RELAY_
#define PCM_REQ_SET_RTP_RELAY	NC_CMD_BASE + 15
#endif
//#define PCM_MSG_SET_TMU	NC_CMD_BASE + 5	/*Pushing various configurations */
//#define PCM_MSG_GET_TMU	NC_CMD_BASE + 4	/*Pushing various configurations */

/* DEBUG COMMANDS */

#define NC_SET_TRACE	1
#define NC_GET_TRACE	2

typedef struct nc_trace_ops_s {
	uint16	tr_cmd;
	uint32a	tr_trace_flags;
	uint8	tr_trace_option; /* 1 On, 0 Off */
	uint32a	tr_trace_level;
} nc_trace_ops_t;


/* TABLE SET commands  NC_TABLE_SET */
#define NC_CREATE_TABLE			1
#define NC_DELETE_TABLE			2

/* TABLE GET COMMANDS NC_TABLE_GET */

#define NC_GET_TABLE_COUNT		1
#define NC_GET_TABLES_INFO		2
#define NC_GET_ROUTE_TABLES_INFO	3
#define NC_GET_BRIDGE_TABLES_INFO	4
#define NC_GET_ROUTE_TABLE_ENTRIES	5
#define NC_GET_BRIDGE_TABLE_ENTRIES	6


/* data structure for table all table commands */
typedef struct nc_table_ops_s {
	uint16 tb_cmd;		/* table command */
	fp_table_type_t tb_type;	/* table type */
	uint16 tb_size;		/* table size */
	uint16 tb_id;		/* table id */
	uint16 tb_num_tbs;	/* number of tables */
	int8 		*tb_data;	/* command specific data */
} nc_table_ops_t;

/* GET INTERFACE STATS COMMANDS NC_INTF_STATS */
#define NC_GET_PORTID_STATS		1  /* Get this port information */
#define NC_GET_PORTALL_STATS		2  /* Obtain Array of Ports Information */
#define NC_GET_PORTID_INTFID_STATS	3  /* Get Stats of one intf under 1 port*/
#define NC_GET_PORTID_INTFALL_STATS	4  /* Get array of intf stats for a port*/
#define NC_GET_PORTALL_INTFALL_STATS	5  /* Get all Ports and all units */


typedef struct nc_intf_stats_ops_s {
	uint16	ifs_cmd;	/* Interface statistics command */
	uint16	ifs_port_idx;	/* Port Index */
	uint16	ifs_intf_idx;	/* Interface  Index */
	uint16	ifs_num_ports;	/* Number of port entries */
	uint16	ifs_num_ifls;	/* Number of interface entries */
	int8		*ifs_data;	/* pointer to data */
} nc_intf_stats_ops_t;

#define NC_GET_FLOW_ENTRIES		1  /* Obtain the flow entries */
#define NC_GET_FLOW_ENTRIES_COUNT	2  /* Obtain the flow entries Count*/
#define NC_GET_FLOW_ENTRIES_EXT		3  /* Obtain the flow entries Extensive*/
#define NC_GET_BRIDGE_ENTRIES		4  /* Obtain the bridge entries */
#define NC_GET_BRIDGE_ENTRIES_COUNT	5  /* Obtain the bridge entries count*/
#define NC_GET_BRIDGE_ENTRIES_EXT	6  /* Obtain the bridge entries extensive*/
#define NC_GET_BRIDGE_ENTRIES_TABLE	7  /* Obtain the bridge entries in given index*/
#define NC_GET_VLAN_ENTRIES		8  /* Obtain the vlan entries */
#define NC_GET_VLAN_ENTRIES_COUNT	9  /* Obtain the vlan entries count*/
#define NC_GET_VLAN_ENTRIES_EXT		10 /* Obtain the vlan entries extensive*/
#define NC_GET_VLAN_ENTRIES_TABLE	11 /* Obtain the vlan entries in given index*/


typedef struct nc_entries_ops_s {
	uint16 ent_cmd;
	uint16 ent_size;
	uint16 ent_count;
	uint16 ent_index; /* SWITCH */
	int8    *ent_data;
} nc_entries_ops_t;

/* #define NC_INTF_SET  */

#define NC_SET_INTFS_MODE	1	/* SET INTERFACES MODE */
#define NC_GET_INTFS_MODE	2	/* SET INTERFACES MODE */
#define NC_SET_INTFIDX_MODE	3	/* SET ONE INTERFACE MODE */
#define NC_SET_PORTIDX_MODE	4	/* SET ONE PORT MODE */

typedef struct nc_intf_ops_s {
	uint16	ifo_cmd;	/* Interface operations command */
	uint16	ifo_port_idx;	/* Port Index */
	uint16	ifo_intf_idx;	/* Interface  Index */
	uint16	ifo_size;	/* SIZE OF the buffer */
	int8		*ifo_data;	/* pointer to data */
} nc_intf_ops_t;


int32a ncu_create_table(int8 *arg_table_type, uint16 table_size, uint16 *);
int32a ncu_delete_table(uint16 table_id);
int32a intfIoctl(nc_intf_stats_ops_t *ncIsOps);
extern uint32a fp_host_pkt_cnt;

#define NC_CONFIG_BRIDGE_ADD_PORT	1	/* Add a port to Bridge */
#define NC_CONFIG_BRIDGE_ADD_UNIT	2	/* Add a Unit to Bridge */
#define NC_CONFIG_BRIDGE_DEL_PORT	3	/* Delete a port from Bridge */
#define NC_CONFIG_BRIDGE_DEL_UNIT	4	/* Delete a unit from Bridge */

#define NC_CONFIG_VLAN_ADD_PORT		5	/* Add VLAN to a Port */
#define NC_CONFIG_VLAN_DEL_PORT		6	/* Delete VLAN from a Port */
#define NC_CONFIG_VLAN_ADD_UNIT		7	/* Add a VLAN to a Unit */
#define NC_CONFIG_VLAN_DEL_UNIT		8	/* Delete a VLAN from a Unit */

#define NC_CONFIG_ROUTE_ADD_PORT	9	/* Add a port to Bridge */
#define NC_CONFIG_ROUTE_ADD_UNIT	10	/* Add a Unit to Bridge */
#define NC_CONFIG_ROUTE_DEL_PORT	11	/* Delete a port from Bridge */
#define NC_CONFIG_ROUTE_DEL_UNIT	12	/* Delete a unit from Bridge */

#define NC_CONFIG_BRIDGE_DELETE		13	/* Delete an Entire Bridge Configuration*/

#define NC_CONFIG_SET_PORT_PARAM	15	/* Set  a parameter for a port */
#define NC_CONFIG_SET_UNIT_PARAM	16	/* Set  a parameter for a unit */


#define NC_PARAM_PORT_MODE		1 /* set Port Mode */
#define NC_PARAM_PORT_MEDIA_TYPE	2 /* Set Port Type */
#define NC_PARAM_PORT_NAME		3 /* Set Port Type */
#define NC_PARAM_UNIT_TYPE		6 /* Set Unit Type */
#define NC_PARAM_UNIT_MODE		7 /* Set Unit Mode */
#define NC_PARAM_UNIT_MACADDR		8 /* Set Unit MacAddr */


#define CONFIG_OPS_SUCCESS	0
#define CONFIG_OPS_FAILURE	1

#ifndef MAX_BRIDGE_GROUP_NAME
#define MAX_BRIDGE_GROUP_NAME	16
#endif

#ifndef MAX_PARAM_VALUE_LEN
#define MAX_PARAM_VALUE_LEN	512
#endif

#ifndef MAX_ERROR_LEN
#define MAX_ERROR_LEN		512
#endif

#define MAX_DEV_MODE_LEN	16

typedef struct nc_config_ops_s {
	uint16	cops_cmd;				/* NC_CONFIG_* */
	uint32a	cops_port_id;				/* Action on Which Port */
	uint32a	cops_unit_id;				/* Action on Which Unit */
	uint32a	cops_param_id;				/* Action on Which Parameter NC_PARAM_* */
	uint16	cops_ret_val;				/* Success or Failure */
	uint32a	cops_media_type;			/* Media Type */
	uint32a	cops_vlan_id;				/* VLAN ID */
	int8		cops_dev_mode[MAX_DEV_MODE_LEN];	/* Device Mode */ /* SWITCH */
	int8		cops_br_name[MAX_BRIDGE_GROUP_NAME];	/* Bridge Name */
	int8		cops_param_val[MAX_PARAM_VALUE_LEN];	/* Param Value */
	int8		cops_ret_err[MAX_ERROR_LEN];		/* Return any Error on Failure */
} nc_config_ops_t;

#define CREATE_HOST_INTF 1
#define REMOVE_HOST_INTF 2

typedef struct nc_host_intf_s {
	uint16	hintf_phyno;
	uint16	hintf_mode;
	int8		hintf_name[30];

} nc_host_intf_t;

/* Switch Registers */
#define NC_SWITCH_REG_READ	1 /* Read value from switch register */
#define NC_SWITCH_REG_WRITE	2 /* Write a value in switch register*/
#define NC_GET_SWPORT_ADDR	3 /*To Get switch Port Base Address*/
#define NC_GET_SWGLOBAL_ADDR	4 /*TO Get switch Global Base address*/
#define NC_SWITCH_REG_READ_ALL	5 /* All registers reading */
#define NC_SWITCH_REG_WRITE_ALL	6 /* All registers writing */
typedef struct nc_reg_ops_s {

	uint16	reg_cmd;	/* Register Read/Write Cmd */
	uint16	reg_ret_val;	/* Success or Failure */
	uint32a	reg_addr;	/* Switch register value */
	uint32a	reg_baseaddr;	/* register base address */
	uint32a	reg_val;	/* Switch register value */
	uint32a	reg_addrtype;
} nc_reg_ops_t;

int32a fp_ioctl_get(void *, int32a, int32a);

#endif  /* _FP_IOCTL_H_ */

