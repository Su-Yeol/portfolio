/*************************************************************************/ /*!
@File
@Title          gem_ptp.h
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    Hardware clock register offsets and API.
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

#include <linux/time.h>
#include <linux/ptp_clock_kernel.h>
#include <linux/netdevice.h>
#include <linux/net_tstamp.h>

#include "fp_macros.h"
#include "fp_library.h"


#define MAC_TIMESTAMP_CONTROL                      (EMAC1_BASE_ADDR + 0xD00)
#define MAC_SUB_SECOND_INCREMENT                   (EMAC1_BASE_ADDR + 0xD04)
#define MAC_SYSTIME_SECONDS                        (EMAC1_BASE_ADDR + 0xD08)
#define MAC_SYSTIME_NANO_SECONDS                   (EMAC1_BASE_ADDR + 0xD0C)
#define SYS_TIME_SECONDS_UPDATE                    (EMAC1_BASE_ADDR + 0xD10)
#define SYS_TIME_NANO_SECONDS_UPDATE               (EMAC1_BASE_ADDR + 0xD14)
#define SYS_TIMESTAMP_ADDEND                       (EMAC1_BASE_ADDR + 0xD18)
#define SYS_TIME_HIGHER_WORD_SECONDS               (EMAC1_BASE_ADDR + 0xD1C)

#define PTP_CLOCK_FREQ			      25000
#define MAX_SUB_NS_VALUE                      16777215
/* The default ns increment value for 40MHz clock  */
#define DEFAULT_INCREMENT_VALUE               (1000000 / PTP_CLOCK_FREQ)


#define RREG32(r)      readl(r)
#define WREG32(r, v)   writel((v), (r))

struct ptp_regs
{
    void __iomem *mac_timestamp_control;
    void __iomem *mac_sub_sec_incr;
    void __iomem *mac_systime_sec;
    void __iomem *mac_systime_nsec;
    void __iomem *sys_time_sec_update;
    void __iomem *sys_time_nano_update;
    void __iomem *sys_time_addend;
    void __iomem *systime_higher_seconds;
};

/* Function to check if packet received is ptp packet or not */
int32a ptp_packet(struct sk_buff *skb);
