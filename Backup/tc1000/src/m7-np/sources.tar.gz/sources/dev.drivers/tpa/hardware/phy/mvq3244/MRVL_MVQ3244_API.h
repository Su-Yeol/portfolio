#ifndef MRVL_MVQ3244_API_H__
#define MRVL_MVQ3244_API_H__

extern int PHY_MVQ3244_Init(int xgmac_index);
extern int PHY_MVQ3244_Check(int xgmac_index);
#endif // MRVL_MVQ3244_API_H__
