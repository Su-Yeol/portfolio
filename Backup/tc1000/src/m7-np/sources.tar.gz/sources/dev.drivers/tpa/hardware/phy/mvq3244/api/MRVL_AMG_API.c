/**
 * @file MRVL_AMG_API.c
 * @brief Marvell Multi-gig Automotive Ethernet PHY Mode Ctrl API source for device control and status checking
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */

#include "MRVL_AMG_API.h"
#include "MRVL_AMG_REG_MAIN.h"

/******************************************************************************
 *      General Status
 ******************************************************************************/

/**
 * @brief get device information and check if device initialization has been completed
 * @param[in] device	pointer to MRVL_DEV
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_STATUS
 */
MRVL_APHY_STATUS MRVL_AMG_GetDeviceInfo(MRVL_DEV_PTR device)
{
	MRVL_APHY_U32 regData = 0;
	MRVL_APHY_U16 counter = 0;
	const MRVL_APHY_U16 counterCount = 50;//5000;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;

	status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0StatusStat1, &regData);
	while ( counter < counterCount)
	{
		if (regData == 0xFFFFFFFF)
		{
				MRVL_AMG_Wait(device, 10);
				status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0StatusStat1, &regData);
				counter++;
		}
		else
			break;
	}

	if (regData == 0xFFFFFFFF)
	{
		MRVL_AMG_DBG_ERROR("MRVL_AMG_GetDeviceInfo error: Could not get MDIO \n");
		status |=  MRVL_APHY_STATUS_ERROR_GENERAL;
	}

	else if (0 == ((regData >> deviceInitialized) & 1U)) {
		/* MRVL_AMG_GetDeviceInfo error: Device initialization is not completed. */
		status |=  MRVL_APHY_STATUS_ERROR_GENERAL;
	}
	else
	{
		MRVL_AMG_DBG_INFO("Host can start device configuration and control\n");
	}
	
	return status;
}

/**
 * @brief get chip temperature in 1/100 of a degree Celsius
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] temperature	MRV L_APHY_U16
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_STATUS
 */
MRVL_APHY_STATUS MRVL_AMG_GetTemperature(MRVL_DEV_PTR device, MRVL_APHY_U16* temperature)
{
	MRVL_APHY_U32 regData = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;

	status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0StatusStat0, &regData);
	*temperature = (MRVL_APHY_U16)(regData & 0xFFFFU);

	return status;
}

/**
 * @brief get chip revision : Idenitifying if it's A0 or A1
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] chipRev	pointer to MRVL_AMG_ChipRevision
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_STATUS
 */
MRVL_APHY_STATUS MRVL_AMG_GetChipRevision(MRVL_DEV_PTR device, MRVL_AMG_ChipRevision* chipRev)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;
	status |= MRVL_AMG_ReadReg32(device, IdStatPartId, &regData);
	regData &= 0xF;
	switch (regData)
	{
		case 0:
			*chipRev = MRVL_AMG_REV_A0;
			break;
		case 3:
			*chipRev = MRVL_AMG_REV_A1;
			break;
		default:
			*chipRev = MRVL_AMG_REV_INVALID;
			break;
	}

	return status;
}


/******************************************************************************
 *      T1 Mode Configuration and Status Checking
 ******************************************************************************/

/**
 * @brief get T1 link status (latched link)
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] linkStatus	pointer to MRVL_AMG_LinkStatus enumeration.
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_T1_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_T1_GetLinkStatus(MRVL_DEV_PTR device, MRVL_AMG_LinkStatus* linkStatus)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;

	status |= MRVL_AMG_ReadReg32(device, IeeeMmd1Reg2310, &regData);
	
	if ((regData >> rx_link_status) & 1U) {
		*linkStatus = MRVL_AMG_LINK_UP;
	}
	else {
		*linkStatus = MRVL_AMG_LINK_DOWN;
	}

	return status;
}

/**
 * @brief get T1 polarity
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] polarity	pointer to MRVL_AMG_Polarity enumeration.
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_T1_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_T1_GetPolarity(MRVL_DEV_PTR device, MRVL_AMG_Polarity* polarity)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;
	status |= MRVL_AMG_ReadReg32(device, IeeeMmd1Reg2310, &regData);

	if ((regData >> rx_polarity) & 1U) {
		*polarity = MRVL_AMG_POLARITY_REVERSED;
	}
	else {
		*polarity = MRVL_AMG_POLARITY_NORMAL;
	}

	return status;
}

/**
 * @brief get T1 MASTER/SLAVE mode
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] mode	pointer to MRVL_APHY_OPERATION_MODE enumeration.
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_T1_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_T1_GetMasterSlaveStatus(MRVL_DEV_PTR device, MRVL_APHY_OPERATION_MODE* mode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;

	status |= MRVL_AMG_ReadReg32(device, IeeeMmd1Reg2100, &regData);

	if ((regData >> master_slave) & 1U) {
		*mode = MRVL_APHY_OP_MASTER;
	}
	else {
		*mode = MRVL_APHY_OP_SLAVE;
	}
	return status;
}

/**
 * @brief set T1 MASTER/SLAVE mode
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] mode	MRVL_APHY_OPERATION_MODE: MASTER/SLAVE 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_T1_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_T1_SetMasterSlaveStatus(MRVL_DEV_PTR device, MRVL_APHY_OPERATION_MODE mode) 
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;

	status |= MRVL_AMG_ReadReg32(device, IeeeMmd1Reg2100, &regData);

	switch (mode)
	{
	case MRVL_APHY_OP_SLAVE:
		regData &= ~(1U << master_slave);
		break;
	case MRVL_APHY_OP_MASTER:
		regData |= (1U << master_slave);
		break;
	
	default:
		status |= MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
		break;
	}

	status |= MRVL_AMG_WriteReg32(device, IeeeMmd1Reg2100, regData);
	return status;
}


/**
 * @brief get T1 speed
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] speed	pointer to MRVL_APHY_SPEED
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_T1_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_T1_GetSpeed(MRVL_DEV_PTR device, MRVL_APHY_SPEED* speed)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;
	/* 1.834.3:0 */
	status |= MRVL_AMG_ReadReg32(device, IeeeMmd1Reg2100, &regData);

	regData = (regData >> speed_selection) & 0xFU;
	switch (regData)
	{
		case 0x4:
			*speed = MRVL_APHY_SPEED_2P5G;
			break;
		case 0x5:
			*speed = MRVL_APHY_SPEED_5G;
			break;
		case 0x6:
			*speed = MRVL_APHY_SPEED_10G;
			break;
		default:
			*speed = MRVL_APHY_SPEED_NA;
			MRVL_AMG_DBG_ERROR("MRVL_AMG_T1_GetSpeed error: Unknown speed\n");
			status |=  MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
			break;
	}

	return status;
}

/**
 * @brief set T1 speed
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] speed	MRVL_APHY_SPEED
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_T1_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_T1_SetSpeed(MRVL_DEV_PTR device, MRVL_APHY_SPEED speed)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;
	/* 1.834.3:0 */
	status |= MRVL_AMG_ReadReg32(device, IeeeMmd1Reg2100, &regData);

	regData &= 0xFFF0;
	switch (speed)
	{
		case MRVL_APHY_SPEED_2P5G:
			regData |= 0x4U;
			break;
		case MRVL_APHY_SPEED_5G:
			regData |= 0x5U;
			break;
		case MRVL_APHY_SPEED_10G:
			regData |= 0x6U;
			break;
		default:
			MRVL_AMG_DBG_ERROR("MRVL_AMG_T1_SetSpeed error: Unknown speed\n");
			status |=  MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
			break;
	}

	status |= MRVL_AMG_WriteReg32(device, IeeeMmd1Reg2100, regData);

	return status;
}

/**
 * @brief restart line side link
 * @param[in] device	pointer to MRVL_DEV
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_T1_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_T1_RestartLineLink(MRVL_DEV_PTR device)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;

	status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0CtrlFwIfControl0, &regData);

	regData |= (1U << line_link_restart);

	status |= MRVL_AMG_WriteReg32(device, FwMmd1eSet0CtrlFwIfControl0, regData);

	return status;
}

/**
 * @brief get T1 counters
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] counters	pointer to MRVL_AMG_Counter
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_T1_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_T1_GetCounter(MRVL_DEV_PTR device, MRVL_AMG_Counter* counters)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 cnt = 0;
	MRVL_APHY_U64 cntlong;
	/* rx */
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsRxStatGood, &cnt);
	counters->goodRxEthernetFrames = cnt;
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsRxStatGood + 4, &cnt);
	cntlong = (MRVL_APHY_U64)(cnt);
	counters->goodRxEthernetFrames += cntlong << 16;
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsRxStatGood + 8, &cnt);
	cntlong = (MRVL_APHY_U64)(cnt);
	counters->goodRxEthernetFrames += cntlong << 32;

	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsRxStatBad, &cnt);
	counters->badRxEthernetFrames = cnt;
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsRxStatBad + 4, &cnt);
	cntlong = (MRVL_APHY_U64)(cnt);
	counters->badRxEthernetFrames += cntlong << 16;
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsRxStatBad + 8, &cnt);
	cntlong = (MRVL_APHY_U64)(cnt);
	counters->badRxEthernetFrames += cntlong << 32;

	/* tx */
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsTxStatGood, &cnt);
	counters->goodTxEthernetFrames = cnt;
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsTxStatGood + 4, &cnt);
	cntlong = (MRVL_APHY_U64)(cnt);
	counters->goodTxEthernetFrames += cntlong << 16;
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsTxStatGood + 8, &cnt);
	cntlong = (MRVL_APHY_U64)(cnt);
	counters->goodTxEthernetFrames += cntlong << 32;

	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsTxStatBad, &cnt);
	counters->badTxEthernetFrames = cnt;
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsTxStatBad + 4, &cnt);
	cntlong = (MRVL_APHY_U64)(cnt);
	counters->badTxEthernetFrames += cntlong << 16;
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsTxStatBad + 8, &cnt);
	cntlong = (MRVL_APHY_U64)(cnt);
	counters->badTxEthernetFrames += cntlong << 32;

	return status;
}

/**
 * @brief clear T1 counter
 * @param[in] device	pointer to MRVL_DEV
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_T1_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_T1_ClearCounter(MRVL_DEV_PTR device)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 cnt = 0;
	MRVL_APHY_U32 regData, newData;

	status |= MRVL_AMG_ReadReg32(device, CheckerStatsDbgCtrlChkClearMode, &regData);
	newData = regData | (1U << pmp_clear_mode);
	status |= MRVL_AMG_WriteReg32(device, CheckerStatsDbgCtrlChkClearMode, newData);

	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsRxStatGood, &cnt);
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsRxStatGood + 4, &cnt);
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsRxStatGood + 8, &cnt);

	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsRxStatBad, &cnt);
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsRxStatBad + 4, &cnt);
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsRxStatBad + 8, &cnt);

	/* tx */
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsTxStatGood, &cnt);
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsTxStatGood + 4, &cnt);
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsTxStatGood + 8, &cnt);

	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsTxStatBad, &cnt);
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsTxStatBad + 4, &cnt);
	status |= MRVL_AMG_ReadReg32(device, VendorSpecificPacketStatsTxStatBad + 8, &cnt);

	/* Set 0x407D5010 back to its original value. */
	status |= MRVL_AMG_WriteReg32(device, CheckerStatsDbgCtrlChkClearMode, regData);

	return status;
}


/**
 * @brief get T1 SNR
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] snr	pointer to MRVL_AMG_SNR
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_T1_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_T1_GetSNR(MRVL_DEV_PTR device, MRVL_AMG_SNR* snr)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;

	status |= MRVL_AMG_ReadReg32(device, IeeeMmd1Reg2314, &regData);
	snr->snrOperatingMargin = ((MRVL_APHY_DOUBLE)(regData >> snr_operating_margin) - 0x80) / 10;
	snr->snrOperatingMargin += 21;
	status |= MRVL_AMG_ReadReg32(device, IeeeMmd1Reg2315, &regData);
	snr->snrMinimumMargin = ((MRVL_APHY_DOUBLE)(regData >> min_observed_snr_margin) - 0x80) / 10;
	snr->snrMinimumMargin += 21;

	return status;
}


/**
 * @brief set T1 to low power or to normal mode 
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] isLowPower	TRUE: set to low power; FALSE: set to normal
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_T1_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_T1_ConfigLowPower(MRVL_DEV_PTR device, MRVL_APHY_BOOL isLowPower) 
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;
	status |= MRVL_AMG_ReadReg32(device, IeeeMmd1Reg2309, &regData);
	if (isLowPower == MRVL_APHY_TRUE) {
		regData |= 1U << low_power;
	}
	else {
		regData &= ~(1U << low_power);
	}
	status |= MRVL_AMG_WriteReg32(device, IeeeMmd1Reg2309, regData);

	return status;
}

/**
 * @brief disable or enable T1 port Tx
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] isDisableTx	TRUE: disable T1 Tx; FALSE: enable T1 Tx
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_T1_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_T1_ConfigDisableTx(MRVL_DEV_PTR device, MRVL_APHY_BOOL isDisableTx) 
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;
	status |= MRVL_AMG_ReadReg32(device, IeeeMmd1Reg2309, &regData);
	if (isDisableTx == MRVL_APHY_TRUE) {
		regData |= 1U << tx_disable;
	}
	else {
		regData &= ~(1U << tx_disable);
	}
	status |= MRVL_AMG_WriteReg32(device, IeeeMmd1Reg2309, regData);

	return status;
}

/**
 * @brief get T1 RS frame counters. Counter is clear on read.
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] counters	pointer to MRVL_AMG_RS_Frame_Counter
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_T1_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_T1_GetRSFrameCounter(MRVL_DEV_PTR device, MRVL_AMG_RS_Frame_Counter* counters)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 cnt = 0;
	MRVL_APHY_U32 offset = 0;
	
	status |= MRVL_AMG_ReadReg32(device, PcsBaseRegister + RxRsFecStatCorrectedFrames, &cnt);
	counters->correctedRSFrames = cnt;
	status |= MRVL_AMG_ReadReg32(device, PcsBaseRegister + RxRsFecStatUncorrectedFrames, &cnt);
	counters->notCorrectedRSFrames = cnt;
	status |= MRVL_AMG_ReadReg32(device, PcsBaseRegister + RxRsFecStatGoodFrames, &cnt);
	counters->goodRSFrames = cnt;

	offset = fec_counter_step;
	status |= MRVL_AMG_ReadReg32(device, PcsBaseRegister + RxRsFecStatCorrectedFrames + offset, &cnt);
	counters->correctedRSFrames += cnt;
	status |= MRVL_AMG_ReadReg32(device, PcsBaseRegister + RxRsFecStatUncorrectedFrames + offset, &cnt);
	counters->notCorrectedRSFrames += cnt;
	status |= MRVL_AMG_ReadReg32(device, PcsBaseRegister + RxRsFecStatGoodFrames + offset, &cnt);
	counters->goodRSFrames += cnt;

	offset = fec_counter_step * 2;
	status |= MRVL_AMG_ReadReg32(device, PcsBaseRegister + RxRsFecStatCorrectedFrames + offset, &cnt);
	counters->correctedRSFrames += cnt;
	status |= MRVL_AMG_ReadReg32(device, PcsBaseRegister + RxRsFecStatUncorrectedFrames + offset, &cnt);
	counters->notCorrectedRSFrames += cnt;
	status |= MRVL_AMG_ReadReg32(device, PcsBaseRegister + RxRsFecStatGoodFrames + offset, &cnt);
	counters->goodRSFrames += cnt;

	offset = fec_counter_step * 3;
	status |= MRVL_AMG_ReadReg32(device, PcsBaseRegister + RxRsFecStatCorrectedFrames + offset, &cnt);
	counters->correctedRSFrames += cnt;
	status |= MRVL_AMG_ReadReg32(device, PcsBaseRegister + RxRsFecStatUncorrectedFrames + offset, &cnt);
	counters->notCorrectedRSFrames += cnt;
	status |= MRVL_AMG_ReadReg32(device, PcsBaseRegister + RxRsFecStatGoodFrames + offset, &cnt);
	counters->goodRSFrames += cnt;

	return status;
}

/**
 * @brief get SerDes link status (latched link)
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] linkStatus	pointer to MRVL_AMG_LinkStatus enumeration.
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_T1_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_SerDes_GetLinkStatus(MRVL_DEV_PTR device, MRVL_AMG_LinkStatus* linkStatus)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;	
	status |= MRVL_AMG_ReadReg32(device, CmnVenCfgCfgNunoOv, &regData);
	
	if ((regData >> NunoLink) & 1U) {
		*linkStatus = MRVL_AMG_LINK_UP;
	}
	else {
		*linkStatus = MRVL_AMG_LINK_DOWN;
	}

	return status;
}


/******************************************************************************
 *      SerDes Mode Configuration and Status Checking
 ******************************************************************************/

/**
 * @brief restart system side link
 * @param[in] device	pointer to MRVL_DEV
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_SerDes_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_SerDes_RestartSysLink(MRVL_DEV_PTR device)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;

	status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0CtrlFwIfControl0, &regData);

	regData |= (1U << sys_link_restart);

	status |= MRVL_AMG_WriteReg32(device, FwMmd1eSet0CtrlFwIfControl0, regData);

	return status;
}

/**
 * @brief get SerDes speed
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] speed	pointer to MRVL_APHY_SERDES_SPEED
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_SerDes_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_SerDes_GetSpeed(MRVL_DEV_PTR device, MRVL_APHY_SERDES_SPEED* speed)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;

	status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0CfgFwIfConfig0, &regData);

	regData = ((regData >> sys_pcs_mode) & 0x7U);
	*speed = (MRVL_APHY_SERDES_SPEED)(regData);

	return status;
}

/**
 * @brief set SerDes speed
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] speed	MRVL_APHY_SERDES_SPEED
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_SerDes_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_SerDes_SetSpeed(MRVL_DEV_PTR device, MRVL_APHY_SERDES_SPEED speed)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;

	status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0CfgFwIfConfig0, &regData);
	regData &= 0xFFFFFFF8U;
	regData |= (MRVL_APHY_U32)speed;
	status |= MRVL_AMG_WriteReg32(device, FwMmd1eSet0CfgFwIfConfig0, regData);
	return status;
}

/**
 * @brief get SerDes counters.
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] counters	pointer to MRVL_AMG_Counter
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_SerDes_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_SerDes_GetCounter(MRVL_DEV_PTR device, MRVL_AMG_Counter* counters)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 cnt = 0;
	MRVL_APHY_U64 cntlong;
	/* rx */
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersRxIfStatGood, &cnt);
	counters->goodRxEthernetFrames = cnt;
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersRxIfStatGood + 4, &cnt);
	cntlong = (MRVL_APHY_U64)(cnt);
	counters->goodRxEthernetFrames += cntlong << 16;
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersRxIfStatGood + 8, &cnt);
	cntlong = (MRVL_APHY_U64)(cnt);
	counters->goodRxEthernetFrames += cntlong << 32;

	status |= MRVL_AMG_ReadReg32(device, NtunitCountersRxIfStatBad, &cnt);
	counters->badRxEthernetFrames = cnt;
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersRxIfStatBad + 4, &cnt);
	cntlong = (MRVL_APHY_U64)(cnt);
	counters->badRxEthernetFrames += cntlong << 16;
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersRxIfStatBad + 8, &cnt);
	cntlong = (MRVL_APHY_U64)(cnt);
	counters->badRxEthernetFrames += cntlong << 32;

	/* tx */
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersTxIfStatGood, &cnt);
	counters->goodTxEthernetFrames = cnt;
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersTxIfStatGood + 4, &cnt);
	cntlong = (MRVL_APHY_U64)(cnt);
	counters->goodTxEthernetFrames += cntlong << 16;
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersTxIfStatGood + 8, &cnt);
	cntlong = (MRVL_APHY_U64)(cnt);
	counters->goodTxEthernetFrames += cntlong << 32;

	status |= MRVL_AMG_ReadReg32(device, NtunitCountersTxIfStatBad, &cnt);
	counters->badTxEthernetFrames = cnt;
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersTxIfStatBad + 4, &cnt);
	cntlong = (MRVL_APHY_U64)(cnt);
	counters->badTxEthernetFrames += cntlong << 16;
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersTxIfStatBad + 8, &cnt);
	cntlong = (MRVL_APHY_U64)(cnt);
	counters->badTxEthernetFrames += cntlong << 32;

	return status;
}

/**
 * @brief clear SerDes counter
 * @param[in] device	pointer to MRVL_DEV
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_SerDes_MODE
 */
MRVL_APHY_STATUS MRVL_AMG_SerDes_ClearCounter(MRVL_DEV_PTR device) 
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 cnt = 0;
	MRVL_APHY_U32 regData, newData;

	status |= MRVL_AMG_ReadReg32(device, VendorSpecificRsFecCtrlCtrlCounters, &regData);
	newData = regData | (1U << pcs_clear_mode);
	status |= MRVL_AMG_WriteReg32(device, VendorSpecificRsFecCtrlCtrlCounters, newData);


	status |= MRVL_AMG_ReadReg32(device, NtunitCountersTxIfStatGood, &cnt);
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersTxIfStatGood + 4, &cnt);
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersTxIfStatGood + 8, &cnt);

	status |= MRVL_AMG_ReadReg32(device, NtunitCountersTxIfStatBad, &cnt);
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersTxIfStatBad + 4, &cnt);
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersTxIfStatBad + 8, &cnt);

	/* tx */
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersRxIfStatGood, &cnt);
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersRxIfStatGood + 4, &cnt);
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersRxIfStatGood + 8, &cnt);

	status |= MRVL_AMG_ReadReg32(device, NtunitCountersRxIfStatBad, &cnt);
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersRxIfStatBad + 4, &cnt);
	status |= MRVL_AMG_ReadReg32(device, NtunitCountersRxIfStatBad + 8, &cnt);

	/* Set 0x400E0000 back to its original value. */
	status |= MRVL_AMG_WriteReg32(device, VendorSpecificRsFecCtrlCtrlCounters, regData);

	return status;
}


/******************************************************************************
 *      Test Mode
 ******************************************************************************/

/**
 * @brief set Test Mode 2 jitter pattern 
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] testControl	MRVL_AMG_TestModeControl
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_TEST
 * 
 */
MRVL_APHY_STATUS MRVL_AMG_SetTM2JitterTestControl(MRVL_DEV_PTR device, MRVL_AMG_JitterTestControl jitterPattern) 
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;
	
	status |= MRVL_AMG_ReadReg32(device, IeeeMmd1Reg2313, &regData);
	regData &= 0xFFFCU;
	switch (jitterPattern) {
	case MRVL_AMG_JITTER_PATTERN_SQUAREWAVE:
		regData |= 0x0U;
		break;
	case MRVL_AMG_JITTER_PATTERN_JP03A:
		regData |= 0x1U;
		break;
	case MRVL_AMG_JITTER_PATTERN_JP03B:
		regData |= 0x2U;
		break;
	default:
		MRVL_AMG_DBG_ERROR("MRVL_AMG_SetTM2JitterTestControl error: Unknown jitter test pattern\n");
		return MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}
	status |= MRVL_AMG_WriteReg32(device, IeeeMmd1Reg2313, regData);
	return status;
}

/**
 * @brief get TM2 jitter pattern 
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] testControl	MRVL_AMG_TestModeControl
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_TEST
 */
MRVL_APHY_STATUS MRVL_AMG_GetTM2JitterTestControl(MRVL_DEV_PTR device, MRVL_AMG_JitterTestControl* jitterPattern)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;

	status |= MRVL_AMG_ReadReg32(device, IeeeMmd1Reg2313, &regData);
	regData &= 0x3U;
	switch (regData) {
	case 0:
		*jitterPattern = MRVL_AMG_JITTER_PATTERN_SQUAREWAVE;
		break;
	case 1:
		*jitterPattern = MRVL_AMG_JITTER_PATTERN_JP03A;
		break;
	case 2:
		*jitterPattern = MRVL_AMG_JITTER_PATTERN_JP03B;
		break;
	default:
		*jitterPattern = MRVL_AMG_JITTER_PATTERN_RESERVED;
		break;
	}
	return status;
}

/**
 * @brief set IEEE test mode
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] testControl	MRVL_AMG_TestModeControl
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_TEST
 */
MRVL_APHY_STATUS MRVL_AMG_SetTestMode(MRVL_DEV_PTR device, MRVL_AMG_TestMode testControl)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;

	status |= MRVL_AMG_ReadReg32(device, IeeeMmd1Reg2313, &regData);
	regData &= 0x1FFFU;
	regData |= testControl << test_mode_ctrl;

	status |= MRVL_AMG_WriteReg32(device, IeeeMmd1Reg2313, regData);
	return status;
}

/**
 * @brief get IEEE test mode
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] testControl	MRVL_AMG_TestModeControl
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_TEST
 */
MRVL_APHY_STATUS MRVL_AMG_GetTestMode(MRVL_DEV_PTR device, MRVL_AMG_TestMode* testControl)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;

	status |= MRVL_AMG_ReadReg32(device, IeeeMmd1Reg2313, &regData);
	*testControl = (MRVL_AMG_TestMode)(regData >> test_mode_ctrl);

	return status;
}


/******************************************************************************
 *      Loopback
 ******************************************************************************/

/**
 * @brief set loopback
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] loopback	MRVL_AMG_Loopback
 * @param[in] enable	MRVL_APHY_BOOL
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_LOOPBACK
 */
MRVL_APHY_STATUS MRVL_AMG_SetLoopback(MRVL_DEV_PTR device, MRVL_AMG_Loopback loopback, MRVL_APHY_BOOL enable)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;

	switch (loopback)
	{
		case MRVL_AMG_LINE_LOOPBACK:
			/* 1.0.1 */
			status |= MRVL_AMG_ReadReg32(device, IeeeMmd1Reg0, &regData);
			regData &= 0xFFFDU;
			regData |= ((MRVL_APHY_U32)enable << pma_remote_loopback);
			status |= MRVL_AMG_WriteReg32(device, IeeeMmd1Reg0, regData);
			break;
		case MRVL_AMG_SYSTEM_LOOPBACK:
			/* 3.912.E */
			status |= MRVL_AMG_ReadReg32(device, IeeeMmd3Reg2322, &regData);
			regData &= 0xBFFFU;
			regData |= ((MRVL_APHY_U32)enable << ctrl_mdio_pcs_Loopback);
			status |= MRVL_AMG_WriteReg32(device, IeeeMmd3Reg2322, regData);
			break;
	}

	return status;
}

/**
 * @brief get loopback
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] loopback	MRVL_AMG_Loopback
 * @param[out] enable	pointer to MRVL_APHY_BOOL
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_LOOPBACK
 */
MRVL_APHY_STATUS MRVL_AMG_GetLoopback(MRVL_DEV_PTR device, MRVL_AMG_Loopback loopback, MRVL_APHY_BOOL* enable)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData = 0;

	switch (loopback)
	{
		case MRVL_AMG_LINE_LOOPBACK:
			/* 1.0.1 */
			status |= MRVL_AMG_ReadReg32(device, IeeeMmd1Reg0, &regData);
			*enable = ((regData >> pma_remote_loopback) & 1U) == 1U ? MRVL_APHY_TRUE: MRVL_APHY_FALSE;
			break;
		case MRVL_AMG_SYSTEM_LOOPBACK:
			/* 3.912.E */
			status |= MRVL_AMG_ReadReg32(device, IeeeMmd3Reg2322, &regData);
			*enable = ((regData >> ctrl_mdio_pcs_Loopback) & 1U) == 1U ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
			break;
	}

	return status;
}


/******************************************************************************
 *      Host Initialization or Configuration
 ******************************************************************************/

/**
 * @brief reset chip : Power-On Reset of the Digital Logic and re-triggers HW-configuration
 * @param[in] device	pointer to MRVL_DEV
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_HOST
 */
MRVL_APHY_STATUS MRVL_AMG_ResetChip(MRVL_DEV_PTR device)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, CommonRegisterClockResetRstCtrlChipPor, &regData);
	regData |= 1U;
	status |= MRVL_AMG_WriteReg32(device, CommonRegisterClockResetRstCtrlChipPor, regData);
	MRVL_AMG_Wait(device, 500);
	return status;
}

/**
 * @brief get host configuration stage timeout 
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] timeout	pointer to MRVL_APHY_U16
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_HOST
 */
MRVL_APHY_STATUS MRVL_AMG_HCS_GetTimeout(MRVL_DEV_PTR device, MRVL_APHY_U16* timeout)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0HostConfigStageConfig0, &regData);

	/* hcs_timeout 0x407809C0.15:0 */
	*timeout = regData & 0xFFFFU;
	return status;
}

/**
 * @brief set host configuration stage timeout 
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] timeout	MRVL_APHY_U16 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_HOST
 */
MRVL_APHY_STATUS MRVL_AMG_HCS_SetTimeout(MRVL_DEV_PTR device, MRVL_APHY_U16 timeout)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0HostConfigStageConfig0, &regData);

	/* hcs_timeout 0x407809C0.15:0 */
	regData = (regData & 0xFFFF0000U) | (MRVL_APHY_U32)timeout;

	status |= MRVL_AMG_WriteReg32(device, FwMmd1eSet0HostConfigStageConfig0, regData);

	return status;
}

/**
 * @brief Enable or disable host configuration stage timeout 
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] disable	MRVL_APHY_BOOL MRVL_APHY_TRUE: disable MRVL_APHY_FALSE: enable 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_HOST
 */
MRVL_APHY_STATUS MRVL_AMG_HCS_DisableTimeout(MRVL_DEV_PTR device, MRVL_APHY_BOOL disable)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0HostConfigStageControl0, &regData);

	/* disableStageTimeout 0x407809C8.2 */
	regData = (regData & 0xFFFFFFBU) | ((MRVL_APHY_BOOL)disable << disableStageTimeout); 

	status |= MRVL_AMG_WriteReg32(device, FwMmd1eSet0HostConfigStageControl0, regData);

	return status;
}

/**
 * @brief Set commence HCS bit, this indicates the beginnig of HCS by host
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] commence	MRVL_APHY_BOOL MRVL_APHY_TRUE: set MRVL_APHY_FALSE: unset 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_HOST
 */
MRVL_APHY_STATUS MRVL_AMG_HCS_Commence(MRVL_DEV_PTR device, MRVL_APHY_BOOL commence)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0HostConfigStageControl0, &regData);

	/* disableStageTimeout 0x407809C8.0 */
	regData = (regData & 0xFFFFFFEU) | (commence << commenceStage); 

	status |= MRVL_AMG_WriteReg32(device, FwMmd1eSet0HostConfigStageControl0, regData);

	return status;
}

/**
 * @brief Set finalize HCS bit, this indicates the end of HCS by host
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] finalize	MRVL_APHY_BOOL MRVL_APHY_TRUE: set MRVL_APHY_FALSE: unset 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_HOST
 */
MRVL_APHY_STATUS MRVL_AMG_HCS_Finalize(MRVL_DEV_PTR device, MRVL_APHY_BOOL finalize)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0HostConfigStageControl0, &regData);

	/* disableStageTimeout 0x407809C8.1 */
	regData = (regData & 0xFFFFFFDU) | (finalize << finalizeStage); 

	status |= MRVL_AMG_WriteReg32(device, FwMmd1eSet0HostConfigStageControl0, regData);

	return status;
}

/**
 * @brief Get the state of host configuration stage
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] state	pointer to MRVL_AMG_HCS_State 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_HOST
 */
MRVL_APHY_STATUS MRVL_AMG_HCS_GetState(MRVL_DEV_PTR device, MRVL_AMG_HCS_State* state)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0HostConfigStageStatus0, &regData);

	/* hcs_state 0x407809D0.3:0 */
	regData = ((regData >> hcs_state) & 0xFU); 

	switch(regData)
	{
		case 0:
			*state = MRVL_AMG_HCS_INACTIVE;
			break;
		case 1:
			*state = MRVL_AMG_HCS_STARTED;
			break;
		case 2:
			*state = MRVL_AMG_HCS_COMMENCED;
			break;
		case 3:
			*state = MRVL_AMG_HCS_FINALIZED;
			break;
		case 4:
			*state = MRVL_AMG_HCS_TIMEOUT;
			break;
		default:
			*state = MRVL_AMG_HCS_INACTIVE;
	}

	return status;
}

/**
 * @brief Get elapsed time of host configuration stage
	Time in 1 millisecond increments spent in Host Config Stage
	Saturates at 0xFFFF
	Starts incrementing on transition to Started state, at the start of the Host Config Stage
	Stops incrementing when the Host Config Stage either timeouts or gets finalized

 * @param[in] device	pointer to MRVL_DEV
 * @param[out] time	HCS elapsed time 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_HOST
 */
MRVL_APHY_STATUS MRVL_AMG_HCS_GetElapsedTime(MRVL_DEV_PTR device, MRVL_APHY_U16* time)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0HostConfigStageStatus1, &regData);

	/* elapsedTime 0x407809D4.15:0 */
	*time = ((regData >> elapsedTime) & 0xFFFFU); 

	return status;
}

/**
 * @brief Get host reaction time to start the host configuration stage
	Time in 1 millisecond increments spent in the Host Config Stage
    until the Host indicates that it has activelystarted configuring the device    
    Saturates at 0xFFFF
    Starts incrementing on transition to Started state, at the start of the Host Config Stage
    Stops incrementing on the detection of the first occurrence of one of the following events
        - Host Commenced the Host Config Stage
        - Host Finalized the Host Config Stage
        - The Host Config Stage timeouts without being Finalized
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] time	host reaction time 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_HOST
 */
MRVL_APHY_STATUS MRVL_AMG_HCS_GetHostReactionTime(MRVL_DEV_PTR device, MRVL_APHY_U16* time)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, FwMmd1eSet0HostConfigStageStatus2, &regData);

	/* hostReactionTime 0x407809D8.15:0 */
	*time = ((regData >> hostReactionTime) & 0xFFFFU); 

	return status;
}


/******************************************************************************
 *      Packet Generator and Checker
 ******************************************************************************/

/**
 * @brief Get the packet generator datapath selection
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] datapath	pointer to MRVL_AMG_DATAPATH 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_GetGeneratorDataPath(MRVL_DEV_PTR device, MRVL_AMG_DATAPATH* datapath)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, ClockResetMuxesCtrlCmxPktGenCheck, &regData);

	/* gen_select 0x407C2108.1:0 */
	regData = (regData >> gen_select) & 0x3U; 

	switch(regData)
	{
		case 0:
			*datapath = MRVL_AMG_SYS_INTF_LINE_TO_SYS;
			break;
		case 1:
			*datapath = MRVL_AMG_SYS_INTF_SYS_TO_LINE;
			break;
		case 2:
			*datapath = MRVL_AMG_LINE_INTF_LINE_TO_SYS;
			break;
		case 3:
			*datapath = MRVL_AMG_LINE_INTF_SYS_LINE;
			break;
		default:
			*datapath = MRVL_AMG_SYS_INTF_LINE_TO_SYS;
			break;
	}

	return status;
}

/**
 * @brief Get the packet checker datapath selection
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] datapath	pointer to MRVL_AMG_DATAPATH 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_GetCheckerDataPath(MRVL_DEV_PTR device, MRVL_AMG_DATAPATH* datapath)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, ClockResetMuxesCtrlCmxPktGenCheck, &regData);

	/* check_select 0x407C2108.9:8 */
	regData = (regData >> check_select) & 0x3U; 

	switch(regData)
	{
		case 0:
			*datapath = MRVL_AMG_SYS_INTF_LINE_TO_SYS;
			break;
		case 1:
			*datapath = MRVL_AMG_SYS_INTF_SYS_TO_LINE;
			break;
		case 2:
			*datapath = MRVL_AMG_LINE_INTF_LINE_TO_SYS;
			break;
		case 3:
			*datapath = MRVL_AMG_LINE_INTF_SYS_LINE;
			break;
	}
	
	return status;
}

/**
 * @brief Set the packet generator datapath selection
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] datapath	MRVL_AMG_DATAPATH 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_SetGeneratorDataPath(MRVL_DEV_PTR device, MRVL_AMG_DATAPATH datapath)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, ClockResetMuxesCtrlCmxPktGenCheck, &regData);

	/* gen_select 0x407C2108.1:0 */
	regData = (regData & 0xFFFFFFFCU) | (datapath << gen_select); 

	status |= MRVL_AMG_WriteReg32(device, ClockResetMuxesCtrlCmxPktGenCheck, regData);
	
	return status;
}

/**
 * @brief Set the packet checker datapath selection
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] datapath	MRVL_AMG_DATAPATH 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_SetCheckerDataPath(MRVL_DEV_PTR device, MRVL_AMG_DATAPATH datapath)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, ClockResetMuxesCtrlCmxPktGenCheck, &regData);

	/* check_select 0x407C2108.9:8 */
	regData = (regData & 0xFFFFFCFFU) | ((MRVL_APHY_U32)datapath << check_select); 

	status |= MRVL_AMG_WriteReg32(device, ClockResetMuxesCtrlCmxPktGenCheck, regData);
	
	return status;
}

/**
 * @brief Get the Inter-Frame Gap (IFG) mode of the At-speed Packet Generator
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] mode	pointer to MRVL_AMG_PACKETGEN_IFG 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_GetIFGMode(MRVL_DEV_PTR device, MRVL_AMG_PACKETGEN_IFG* mode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, DbgCtrlPktModes, &regData);

	/* ifg_mode 0x407D4020.1:0 */
	regData = ((regData >> ifg_mode) & 0x3U); 

	switch(regData)
	{
		case 0:
			*mode = MRVL_AMG_PACKETGEN_IFG_FIXED;
			break;
		case 1:
			*mode = MRVL_AMG_PACKETGEN_IFG_RANDOM;
			break;
		case 2:
			*mode = MRVL_AMG_PACKETGEN_IFG_DIFICIT;
			break;
		default:
			*mode = MRVL_AMG_PACKETGEN_IFG_INVALID;
			break;
	}
	
	return status;
}

/**
 * @brief Set the Inter-Frame Gap (IFG) mode of the At-speed Packet Generator
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] mode	MRVL_AMG_PACKETGEN_IFG 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_SetIFGMode(MRVL_DEV_PTR device, MRVL_AMG_PACKETGEN_IFG mode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, DbgCtrlPktModes, &regData);

	/* ifg_mode 0x407D4020.1:0 */
	regData = (regData & 0xFFFFFFFCU) | ((MRVL_APHY_U32)mode << ifg_mode); 

	status |= MRVL_AMG_WriteReg32(device, DbgCtrlPktModes, regData);
	
	return status;
}


/**
 * @brief Get the packet length mode of the At-speed Packet Generator
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] mode	pointer to MRVL_AMG_PACKETGEN_LENGHT 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_GetLengthMode(MRVL_DEV_PTR device, MRVL_AMG_PACKETGEN_LENGHT* mode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, DbgCtrlPktModes, &regData);

	/* gen_mode 0x407D4020.5:4 */
	regData = ((regData >> plen_mode) & 0x3); 

	switch(regData)
	{
		case 0:
			*mode = MRVL_AMG_PACKETGEN_LENGHT_FIXED;
			break;
		case 1:
			*mode = MRVL_AMG_PACKETGEN_LENGHT_RANDOM;
			break;
		default:
			*mode = MRVL_AMG_PACKETGEN_LENGHT_INVALID;
			break;
	}
	
	return status;
}

/**
 * @brief Set the packet length mode of the At-speed Packet Generator
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] mode	MRVL_AMG_PACKETGEN_LENGHT 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_SetLengthMode(MRVL_DEV_PTR device, MRVL_AMG_PACKETGEN_LENGHT mode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, DbgCtrlPktModes, &regData);

	/* gen_mode 0x407D4020.5:4 */
	regData = (regData & 0xFFFFFFCF) | ((MRVL_APHY_U32)mode << plen_mode); 

	status |= MRVL_AMG_WriteReg32(device, DbgCtrlPktModes, regData);
	
	return status;
}

/**
 * @brief Get the payaload mode of the At-speed Packet Generator
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] mode	pointer to MRVL_AMG_PACKETGEN_PAYLOAD_MODE 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_GetPayloadMode(MRVL_DEV_PTR device, MRVL_AMG_PACKETGEN_PAYLOAD_MODE* mode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, DbgCtrlPktModes, &regData);

	/* gen_mode 0x407D4020.A:8 */
	regData = ((regData >> payld_mode) & 0x7); 

	switch(regData)
	{
		case 0:
			*mode = MRVL_AMG_PAYLOAD_ALL_ZEROS;
			break;
		case 1:
			*mode = MRVL_AMG_PAYLOAD_ALL_ONES;
			break;
		case 2:
			*mode = MRVL_AMG_PAYLOAD_INC_WORD;
			break;
		case 3:
			*mode = MRVL_AMG_PAYLOAD_INC_BYTE;
			break;
		case 4:
			*mode = MRVL_AMG_PAYLOAD_ALTERNATE;
			break;
		case 5:
			*mode = MRVL_AMG_PAYLOAD_WALKING_ZERO;
			break;
		case 6:
			*mode = MRVL_AMG_PAYLOAD_WALKING_ONE;
			break;
		case 7:
			*mode = MRVL_AMG_PAYLOAD_RANDOM;
			break;
	}
	
	return status;
}

/**
 * @brief Set the payaload mode of the At-speed Packet Generator
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] mode	MRVL_AMG_PACKETGEN_PAYLOAD_MODE 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_SetPayloadMode(MRVL_DEV_PTR device, MRVL_AMG_PACKETGEN_PAYLOAD_MODE mode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, DbgCtrlPktModes, &regData);

	/* gen_mode 0x407D4020.A:8 */
	regData = (regData & 0xFFFFF8FF) | ((MRVL_APHY_U32)mode << payld_mode); 

	status |= MRVL_AMG_WriteReg32(device, DbgCtrlPktModes, regData);
	
	return status;
}

/**
 * @brief Get the operating mode of the At-speed Packet Generator
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] mode	pointer to MRVL_AMG_PACKETGEN_OPERATION_MODE 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_GetOperationMode(MRVL_DEV_PTR device, MRVL_AMG_PACKETGEN_OPERATION_MODE* mode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, DbgCtrlPktModes, &regData);

	/* gen_mode 0x407D4020.D:C */
	regData = ((regData >> gen_mode) & 0x3); 

	switch(regData)
	{
		case 0:
			*mode = MRVL_AMG_PACKETGEN_SINGLESHOT;
			break;
		case 1:
			*mode = MRVL_AMG_PACKETGEN_CONTINOUS;
			break;
		default:
			*mode = MRVL_AMG_PACKETGEN_INVALID;
			break;
	}
	
	return status;
}

/**
 * @brief Set the operating mode of the At-speed Packet Generator
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] mode	MRVL_AMG_PACKETGEN_OPERATION_MODE 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_SetOperationMode(MRVL_DEV_PTR device, MRVL_AMG_PACKETGEN_OPERATION_MODE mode)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, DbgCtrlPktModes, &regData);

	/* gen_mode 0x407D4020.D:C */
	regData = (regData & 0xFFFFCFFF) | (mode << gen_mode); 

	status |= MRVL_AMG_WriteReg32(device, DbgCtrlPktModes, regData);
	
	return status;
}


/**
 * @brief Get the packet generator packet max count
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] mode	pointer to MRVL_APHY_U16 
 * @return MRVL_APHY_STATUSP
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_GetMaxCount(MRVL_DEV_PTR device, MRVL_APHY_U16* count)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, DbgCtrlPktMax, &regData);

	/* 0x407D401C.F:0 */
	*count = regData & 0xFFFF; 

	return status;
}

/**
 * @brief Set the packet generator packet max count
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] mode	MRVL_APHY_U16 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_SetMaxCount(MRVL_DEV_PTR device, MRVL_APHY_U16 count)
{
	/* 0x407D401C.F:0 */
	return MRVL_AMG_WriteReg32(device, DbgCtrlPktMax, count);
}



/**
 * @brief Get the minimum or fixed IFG of the At-speed Packet Generator.
This is used for the random and fixed IFG modes. Programming IFGs larger than 2^16-1 are only supported in fixed IFG mode.
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] mode	pointer to MRVL_APHY_U32 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_GetMinIFG(MRVL_DEV_PTR device, MRVL_APHY_U32* count)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	/* 0x407D4024.F:0 */
	status |= MRVL_AMG_ReadReg32(device, DbgCtrlMinIfgBits150, &regData);

	*count = regData;

	/* 0x407D4028.F:0 */
	status |= MRVL_AMG_ReadReg32(device, DbgCtrlMinIfgBits3116, &regData);

	*count = (regData << 16) | *count; 

	return status;
}

/**
 * @brief Set the minimum or fixed IFG of the At-speed Packet Generator. 
This is used for the random and fixed IFG modes. Programming IFGs larger than 2^16-1 are only supported in fixed IFG mode.
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] mode	MRVL_APHY_U32 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_SetMinIFG(MRVL_DEV_PTR device, MRVL_APHY_U32 count)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	/* 0x407D4024.F:0 */
	status |= MRVL_AMG_WriteReg32(device, DbgCtrlMinIfgBits150, (count & 0xFFFFU));

	/* 0x407D4028.F:0 */
	status |= MRVL_AMG_WriteReg32(device, DbgCtrlMinIfgBits3116, (count >> 16));
	
	return status;
}

/**
 * @brief Get the maximum IFG of the At-speed Packet Generator
This is used for the random and fixed IFG modes. Programming IFGs larger than 2^16-1 are only supported in fixed IFG mode.
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] mode	pointer to MRVL_APHY_U32 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_GetMaxIFG(MRVL_DEV_PTR device, MRVL_APHY_U32* count)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;
	/* 0x407D402C.F:0 */
	status |= MRVL_AMG_ReadReg32(device, DbgCtrlMaxIfgBits150, &regData);

	*count = regData;

	/* 0x407D4030.F:0 */
	status |= MRVL_AMG_ReadReg32(device, DbgCtrlMaxIfgBits3116, &regData);

	*count = (regData << 16) | *count; 

	return status;
}

/**
 * @brief Set the maximum IFG of the At-speed Packet Generator
This is used for the random and fixed IFG modes. Programming IFGs larger than 2^16-1 are only supported in fixed IFG mode.
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] mode	MRVL_APHY_U32 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_SetMaxIFG(MRVL_DEV_PTR device, MRVL_APHY_U32 count)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	/* 0x407D402C.F:0 */
	status |= MRVL_AMG_WriteReg32(device, DbgCtrlMaxIfgBits150, (count & 0xFFFF));

	/* 0x407D4030.F:0 */
	status |= MRVL_AMG_WriteReg32(device, DbgCtrlMaxIfgBits3116, (count >> 16));
	
	return status;
}

/**
 * @brief Get the minimum or fixed packet length of the At-speed Packet Generator.
This is used for the random and fixed packet length modes.
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] mode	pointer to MRVL_APHY_U32 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_GetMinLength(MRVL_DEV_PTR device, MRVL_APHY_U16* count)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;
	/* 0x407D4034.F:0 */
	status |= MRVL_AMG_ReadReg32(device, DbgCtrlMinPlen, &regData);

	*count = (MRVL_APHY_U16)regData;

	return status;
}

/**
 * @brief Set the minimum or fixed packet length of the At-speed Packet Generator.
This is used for the random and fixed packet length modes.
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] mode	MRVL_APHY_U32 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_SetMinLength(MRVL_DEV_PTR device, MRVL_APHY_U16 count)
{
	/* 0x407D4034.F:0 */
	return MRVL_AMG_WriteReg32(device, DbgCtrlMinPlen, count);
}


/**
 * @brief Get the maxium packet length of the At-speed Packet Generator.
This is used for the random and fixed packet length modes.
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] mode	pointer to MRVL_APHY_U32 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_GetMaxLength(MRVL_DEV_PTR device, MRVL_APHY_U16* count)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	/* 0x407D4038.F:0 */
	status |= MRVL_AMG_ReadReg32(device, DbgCtrlMaxPlen, &regData);

	*count = regData;

	return status;
}

/**
 * @brief Set the maxium packet length of the At-speed Packet Generator.
This is used for the random and fixed packet length modes.
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] mode	MRVL_APHY_U32 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_SetMaxLength(MRVL_DEV_PTR device, MRVL_APHY_U16 count)
{
	/* 0x407D4038.F:0 */
	return MRVL_AMG_WriteReg32(device, DbgCtrlMaxPlen, count);
}

/**
 * @brief Get the Packet Generator state to see if it's done.
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] state	pointer to MRVL_APHY_BOOL 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_GetState(MRVL_DEV_PTR device, MRVL_APHY_BOOL* state)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;
	/* 0x407D4048.0 */
	status |= MRVL_AMG_ReadReg32(device, DbgStatDone, &regData);

	*state = (regData & 1U) == 1U ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;;

	return status;
}

/**
 * @brief Enables or Disables Packet Generator.
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] enable	MRVL_APHY_BOOL 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_EnableGenerator(MRVL_DEV_PTR device, MRVL_APHY_BOOL enable)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	/* 0x407C2F60.0 */
	status |= MRVL_AMG_ReadReg32(device, DebugDbgCtrlPktGenCheckEnables, &regData);

	regData &= 0xFFFFFFFEU;
	regData |=  (MRVL_APHY_U32)enable << generator_enable;

	/* 0x407C2F60.0 */
	status |= MRVL_AMG_WriteReg32(device, DebugDbgCtrlPktGenCheckEnables, regData);

	return status;
}


/**
 * @brief Enables or Disables Packet Checker.
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] enable	MRVL_APHY_BOOL 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_EnableChecker(MRVL_DEV_PTR device, MRVL_APHY_BOOL enable)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	/* 0x407C2F60.8 */
	status |= MRVL_AMG_ReadReg32(device, DebugDbgCtrlPktGenCheckEnables, &regData);

	regData &= 0xFFFFFEFF;
	regData |=  enable << checker_enable;

	/* 0x407C2F60.8 */
	status |= MRVL_AMG_WriteReg32(device, DebugDbgCtrlPktGenCheckEnables, regData);

	return status;
}

/**
 * @brief Enables or Disables the latency measuring.
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] enable	MRVL_APHY_BOOL 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_PGEN
 */
MRVL_APHY_STATUS MRVL_AMG_PKT_EnableLatencyMeasure(MRVL_DEV_PTR device, MRVL_APHY_BOOL enable)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	/* 0x407C2F60.C */
	status |= MRVL_AMG_ReadReg32(device, DebugDbgCtrlPktGenCheckEnables, &regData);

	regData &= 0xFFFFEFFFU;
	regData |=  enable << latency_enable;

	/* 0x407C2F60.C */
	status |= MRVL_AMG_WriteReg32(device, DebugDbgCtrlPktGenCheckEnables, regData);

	return status;
}


/******************************************************************************
 *      LED
 ******************************************************************************/

/**
 * @brief Get LED blinking Period +1 with 100 msec granularity. Default: 100ms (0x0) Max: 25.6s (0xff)
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] mode	pointer to MRVL_APHY_U8 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_LED
 */
MRVL_APHY_STATUS MRVL_AMG_LED_GetBlinkingLength(MRVL_DEV_PTR device, MRVL_APHY_U8* length)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;
	/* 0x407A1600.7:0 */
	status |= MRVL_AMG_ReadReg32(device, LedCtrlBlink, &regData);

	*length = (regData >> blink_len) & 0xFF ;

	return status;
}

/**
 * @brief Set LED blinking Period +1 with 100 msec granularity. Default: 100ms (0x0) Max: 25.6s (0xff)
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] mode	pointer to MRVL_APHY_U8 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_LED
 */
MRVL_APHY_STATUS MRVL_AMG_LED_SetBlinkingLength(MRVL_DEV_PTR device, MRVL_APHY_U8 length)
{
	/* 0x407A1600.7:0 */
	return MRVL_AMG_WriteReg32(device, LedCtrlBlink, (MRVL_APHY_U32)length);
}

/**
 * @brief Get the link status for LED
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] state	pointer to MRVL_AMG_LED_LINK_STATUS 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_LED
 */
MRVL_APHY_STATUS MRVL_AMG_LED_GetLinkStatus(MRVL_DEV_PTR device, MRVL_AMG_LED_LINK_STATUS* state)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, LedCtrlLinkStatus, &regData);

	/* link_status_mask 0x407A1604.1:0 */
	regData = ((regData >> link_status_mask) & 0x3); 

	switch(regData)
	{
		case 0:
			*state = MRVL_AMG_LED_OFF;
			break;
		case 1:
			*state = MRVL_AMG_LED_T1_LINK;
			break;
		case 2:
			*state = MRVL_AMG_LED_SYS_LINK;
			break;
		case 3:
			*state = MRVL_AMG_LED_T1_SYS_LINK;
	}
	
	return status;
}

/**
 * @brief Set the link status for LED
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] state	MRVL_AMG_LED_LINK_STATUS 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_LED
 */
MRVL_APHY_STATUS MRVL_AMG_LED_SetLinkStatus(MRVL_DEV_PTR device, MRVL_AMG_LED_LINK_STATUS state)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, LedCtrlLinkStatus, &regData);

	/* link_status_mask 0x407A1604.1:0 */
	regData = (regData & 0xFFFFFFFC) | (state << link_status_mask); 

	status |= MRVL_AMG_WriteReg32(device, LedCtrlLinkStatus, regData);
	
	return status;
}

/**
 * @brief Get the link activity for LED
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] state	pointer to MRVL_AMG_LED_LINK_ACTIVITY 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_LED
 */
MRVL_APHY_STATUS MRVL_AMG_LED_GetLinkActivity(MRVL_DEV_PTR device, MRVL_AMG_LED_LINK_ACTIVITY* state)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, LedCtrlLinkActivity, &regData);

	/* link_activity_mask 0x407A1608.1:0 */
	regData = ((regData >> link_activity_mask) & 0x3); 

	switch(regData)
	{
		case 0:
			*state = MRVL_AMG_LED_BLINK_OFF;
			break;
		case 1:
			*state = MRVL_AMG_LED_INGRESS_LINK;
			break;
		case 2:
			*state = MRVL_AMG_LED_EGRESS_LINK;
			break;
		case 3:
			*state = MRVL_AMG_LED_EGR_ING_LINKS;
	}
	
	return status;
}

/**
 * @brief Set the link status for LED
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] state	MRVL_AMG_LED_LINK_ACTIVITY 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_LED
 */
MRVL_APHY_STATUS MRVL_AMG_LED_SetLinkActivity(MRVL_DEV_PTR device, MRVL_AMG_LED_LINK_ACTIVITY state)
{
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 regData;

	status |= MRVL_AMG_ReadReg32(device, LedCtrlLinkActivity, &regData);

	/* link_activity_mask 0x407A1608.1:0 */
	regData = (regData & 0xFFFFFFFC) | (state << link_activity_mask); 

	status |= MRVL_AMG_WriteReg32(device, LedCtrlLinkActivity, regData);
	
	return status;
}





/******************************************************************************
 *      DIAG
 ******************************************************************************/

/**
 * @brief Get cable diagnostics
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] diagnostics	pointer to MRVL_AMG_CableDiagnostic 
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_DIAG
 */
MRVL_APHY_STATUS MRVL_AMG_T1_GetCableDiagnostic(MRVL_DEV_PTR device, MRVL_AMG_CableDiagnostic* diagnostics)
{
	MRVL_APHY_U32 regData = 0;
	MRVL_APHY_U32 regDataStatus = 0;
	MRVL_APHY_U8 segmentCnt = 0;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_STATUS localStatus = MRVL_APHY_STATUS_ERROR_GENERAL;
	MRVL_APHY_U8 i = 0;
	const MRVL_APHY_U8 loopCounter = 20;

	status |= MRVL_AMG_ReadReg32(device, PhyCtrlInterfaceDiagCtrl, &regData);
	regData |= 1U;
	status |= MRVL_AMG_WriteReg32(device, PhyCtrlInterfaceDiagCtrl, regData);

	status |= MRVL_AMG_Wait(device, 2000);

	while (i < loopCounter) 
	{		
		status |= MRVL_AMG_ReadReg32(device, PhyCtrlInterfaceDiagCtrl, &regData);
		if (status != MRVL_APHY_STATUS_OK) 
		{
			/* Reading the register failed */
			break;
		}
		else if ((regData & 1U) == 0) 
		{
			localStatus = MRVL_APHY_STATUS_OK;
			/* TDR finished */
			break;
		}
		else
		{
			status |= MRVL_AMG_Wait(device, 50);
			i++;
		}		
	}

	if (localStatus != MRVL_APHY_STATUS_OK) 
	{
		diagnostics->faultLength = 0;
		diagnostics->discontinuityCount = 0;
		diagnostics->faultType = MRVL_AMG_CableDiagnostic_FaultType_None;
		MRVL_AMG_DBG_ERROR("MRVL_AMG_T1_GetCableDiagnostic Error: TDR time out, value 0x%x\n", regData);
		status |= MRVL_APHY_STATUS_ERROR_GENERAL;
	}
	else 
	{
		status |= MRVL_AMG_ReadReg32(device, PhyStatusDiagStat0, &regDataStatus);
		diagnostics->faultLength = (MRVL_APHY_U16)(regDataStatus >> tdrFaultLength) & 0xFFFU;
		diagnostics->discontinuityCount = 0;
		switch ((regDataStatus >> tdrFaultType) & 0xFU)
		{
		case 0:
			diagnostics->faultType = MRVL_AMG_CableDiagnostic_FaultType_None;
			//check segments 
			segmentCnt = (MRVL_APHY_U8)(regDataStatus >> tdrNumDiscontinuities) & 0xFU;
			diagnostics->discontinuityCount = segmentCnt;
			while (segmentCnt > 0) 
			{
				status |= MRVL_AMG_ReadReg32(device, PhyStatusDiagStatDiscontinuity + 4U * ((MRVL_APHY_U32)segmentCnt - 1U), &regData);
				diagnostics->discontinuityLength[segmentCnt - 1] = (MRVL_APHY_U16)(regData >> tdrDiscontinuityLength) & 0xFFFFU;
				segmentCnt--;
			}
			break;
		case 1:
			diagnostics->faultType = MRVL_AMG_CableDiagnostic_FaultType_Open;
			break;
		case 2:
			diagnostics->faultType = MRVL_AMG_CableDiagnostic_FaultType_Short;
			break;
		default:
			diagnostics->faultType = MRVL_AMG_CableDiagnostic_FaultType_Invalid;
			MRVL_AMG_DBG_ERROR("MRVL_AMG_T1_GetCableDiagnostic Error: unknown fault type 0x%x\n", regDataStatus);
			status |= MRVL_APHY_STATUS_ERROR_GENERAL;
			break;
		}

	}

	return status;
}

