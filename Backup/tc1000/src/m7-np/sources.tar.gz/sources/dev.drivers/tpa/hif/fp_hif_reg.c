// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_hif_reg.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    hif driver functions
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifdef __linux__
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");
#endif

#include "reg_hal.h"
#include "fp_library.h"
#include "fp_hif_reg.h"

void fp_assign_hif_base_addr(struct fp_private *fp)
{
	int32a hif_index = 0;
	uint32a addr;
#ifdef HIF2_EN
	addr = HIF2_BASE_ADDR;
#else
	addr = HIF1_BASE_ADDR;
#endif
	for(hif_index = 0; hif_index < NUM_TOTAL_HIF; hif_index++)
	{
		if(hif_index == 0)
			fp->hif[hif_index].regs = (struct hif_regs *)((uint32)(addr));
		else if(hif_index == 1)
			fp->hif[hif_index].regs = (struct hif_regs *)((uint32)(addr));
		else {
			FP_DEBUG(DBGP_FEAT_ERR, FP_LOG_EMERG, "unknown hif channel \n");
			return;
		}
	}
}

/**********************************************************************
 * Function Name  : fp_en_hif_rx_engine
 * Description    : enable hif rx dma engine
 * Inputs
 *   Parameters   : struct fp_private *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void fp_en_hif_rxdma_engine(struct fp_private *fp)
{
	uint32a rx_ctrl = 0;
	uint32a hif_index = 0, ch_index = 0;

	for(hif_index = 0; hif_index < NUM_TOTAL_HIF; hif_index++)
	{
		/* CLEAR - Poll Counter */
		//RegWrite((uint32)&fp->hif[hif_index].regs->hif_tx_poll_ctrl, 0x04000400);
		//RegWrite((uint32)&fp->hif[hif_index].regs->hif_rx_poll_ctrl, 0x04000400);
		ch_index = HIF_CHNUM_NP; //for(ch_index = 0; ch_index < NUM_HIF_CHANNELS; ch_index++)
		{
			/* Enable the RX DMA Engine & BDP Poll Cntrl */
			rx_ctrl = HIF_CH_RX_CTRL_DMA_EN | HIF_CH_RX_BDP_POLL_CNTR_EN;
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_ctrl_ch, rx_ctrl);
			/* Enable rx write strobe */
			rx_ctrl = HIF_CH_RX_START;
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_rx_ch_start, rx_ctrl);
		}
	}
}

void fp_disable_hif_dma_engine(struct fp_private *fp)
{
	uint32a hif_index = 0, ch_index = 0;

	for(hif_index = 0; hif_index < NUM_TOTAL_HIF; hif_index++)
	{
		/* CLEAR - Poll Counter */
		//RegWrite((uint32)&fp->hif[hif_index].regs->hif_tx_poll_ctrl, 0x0);
		//RegWrite((uint32)&fp->hif[hif_index].regs->hif_rx_poll_ctrl, 0x0);
		ch_index = HIF_CHNUM_NP; //for(ch_index = 0; ch_index < NUM_HIF_CHANNELS; ch_index++)
		{
			/* Disable the RX DMA Engine & BDP Poll Cntrl */
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_ctrl_ch, 0);
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_rx_ch_start, 0);
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_tx_ch_start, 0);
		}
	}
}

void fp_disable_hif_tx_dma_engine(struct fp_private *fp)
{
	uint32a hif_index = 0, ch_index = 0;

	for(hif_index = 0; hif_index < NUM_TOTAL_HIF; hif_index++)
	{
		/* CLEAR - Poll Counter */
		//RegWrite((uint32)&fp->hif[hif_index].regs->hif_tx_poll_ctrl, 0x0);
		ch_index = HIF_CHNUM_NP; //for(ch_index = 0; ch_index < NUM_HIF_CHANNELS; ch_index++)
		{
			/* Disable the RX DMA Engine & BDP Poll Cntrl */
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_ctrl_ch, 0x00030000);
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_tx_ch_start, 0);
		}
	}
}

void fp_disable_hif_rx_dma_engine(struct fp_private *fp)
{
	uint32a hif_index = 0, ch_index = 0;

	for(hif_index = 0; hif_index < NUM_TOTAL_HIF; hif_index++)
	{
		/* CLEAR - Poll Counter */
		//RegWrite((uint32)&fp->hif[hif_index].regs->hif_rx_poll_ctrl, 0x0);
		ch_index = HIF_CHNUM_NP; //for(ch_index = 0; ch_index < NUM_HIF_CHANNELS; ch_index++)
		{
			/* Disable the RX DMA Engine & BDP Poll Cntrl */
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_ctrl_ch, 0x00000000);
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_rx_ch_start, 0);
		}
	}
}

