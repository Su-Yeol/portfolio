/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          tlite_blocks_ctrl_api.h
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    tlite api defines
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

/*!
 * @mainpage TMU Lite API
 *
 * Copyright (c) Imagination Technologies Ltd. All Rights Reserved
 *
 * The TMU Lite API is the primary method that the host uses
 * to configure the NPU TMU hardware. The API provides access to the TMU block
 *
 * @file tlite_blocks_ctrl_api.h
 * TMU Lite API
 */
#ifndef _TLITE_BLOCKS_CTRL_API_H_
#define _TLITE_BLOCKS_CTRL_API_H_

#include "fp_common_msg_header.h"

/*!
 * Error codes for invalid arguments to API's
 */

#define TLITE_ERR_BASE_ADDR		-200					/*!< error base address */
#define TLITE_ERR_MSG_SCH_NUMBER	( TLITE_ERR_BASE_ADDR + 1 )		/*!< error code for invalid scheduler number */
#define TLITE_ERR_MSG_SCH_SLOT		( TLITE_ERR_MSG_SCH_NUMBER + 1 )	/*!< error code for invalid scheduler slot */
#define TLITE_ERR_MSG_SCH_ALGO		( TLITE_ERR_MSG_SCH_SLOT + 1 )		/*!< error code for invalid scheduler algorithm */
#define TLITE_ERR_MSG_SCH_DEV		( TLITE_ERR_MSG_SCH_ALGO + 1 )		/*!< error code for invalid device number */
#define TLITE_ERR_MSG_SHP_NUMBER	( TLITE_ERR_MSG_SCH_DEV  + 1 )		/*!< error code for invalid shaper number */
#define TLITE_ERR_MSG_SHP_DEV		( TLITE_ERR_MSG_SHP_NUMBER + 1 )	/*!< error code for invalid device number */
#define TLITE_ERR_MSG_SHP_RATE_UNITS	( TLITE_ERR_MSG_SHP_DEV + 1 )		/*!< error code for invalid rate units */
#define TLITE_ERR_MSG_SHP_RATE		( TLITE_ERR_MSG_SHP_RATE_UNITS + 1)	/*!< error code for invalid shaper rate */
#define TLITE_ERR_MSG_SHP_CLK_FREQUENCY	( TLITE_ERR_MSG_SHP_RATE + 1 )		/*!< error code for invalid clock frequency */
#define TLITE_ERR_MSG_SHP_POSITION	( TLITE_ERR_MSG_SHP_CLK_FREQUENCY + 1 )/*!< error code for invalid shaper position */
#define TLITE_ERR_MSG_DEV_NUM		( TLITE_ERR_MSG_SHP_POSITION + 1 )	/*!< error code for invalid device number */
#define TLITE_ERR_MSG_IFG		( TLITE_ERR_MSG_DEV_NUM + 1 )		/*!< error code for invalid inter frame gap */

#define TLITE_QUE_NUM_ERR		( TLITE_ERR_MSG_IFG + 1 )		/*!< error code for invalid queue number */
#define TLITE_ERR_MSG_QUE_DEV		( TLITE_QUE_NUM_ERR + 1 )		/*!< error code for invalid device number */

#define TLITE_ERR_MSG_MTR_NUMBER	( TLITE_ERR_MSG_QUE_DEV + 1)		/*!< error code for invalid meter number */
#define TLITE_ERR_MSG_MTR_CLK_FREQ	( TLITE_ERR_MSG_MTR_NUMBER + 1)		/*!< error code for invalid clock frequency */
#define TLITE_ERR_MSG_MTR_MAX_CRDT	( TLITE_ERR_MSG_MTR_CLK_FREQ + 1)	/*!< error code for invalid max credit */
#define TLITE_ERR_MSG_MTR_ENABLE	( TLITE_ERR_MSG_MTR_MAX_CRDT + 1)	/*!< error code for invalid meter enable */
#define TLITE_ERR_MSG_MTR_IFG_ADD	( TLITE_ERR_MSG_MTR_ENABLE + 1)		/*!< error code for invalid inter frame gap add */
#define TLITE_ERR_MSG_MTR_RATE_UNITS	( TLITE_ERR_MSG_MTR_IFG_ADD + 1)	/*!< error code for invalid meter rate units options */
#define TLITE_ERR_MSG_MTR_CLEAR		( TLITE_ERR_MSG_MTR_RATE_UNITS + 1)	/*!< error code for invalid meter clear options */
#define TLITE_ERR_MSG_MTR_RATE		( TLITE_ERR_MSG_MTR_CLEAR + 1) 		/*!< error code for invalid meter rate */
#define TLITE_ERR_HW			( TLITE_ERR_MSG_MTR_RATE + 1)		/*!< error code for error hardware */
#define TLITE_ERR_MSG_SHP_MIN_CREDIT	( TLITE_ERR_HW + 1)			/*!< error code for invalid shaper minimum credit */
#define TLITE_ERR_MSG_SHP_MODE		( TLITE_ERR_MSG_SHP_MIN_CREDIT + 1)	/*!< error code for invalid shaper mode option */
#define TLITE_ERR_MSG_TAILDROP_VALUE	( TLITE_ERR_MSG_SHP_MODE + 1)		/*!< error code for invalid taildrop value */

/*!
 * Meter configuration structure
 */

typedef struct _tlite_meter_params_t_ {
	uint32a	tlmt_meter_no;		/*!< Meter number (1 to 255) */
	uint32a	tlmt_clock_freq;	/*!< Clock frequency used to do weights calculation a given rate (Mhz) */
	uint32a	tlmt_max_credit;	/*!< Maximum value of the credit that can accumulated per meter */
	uint32a	tlmt_enable; 		/*!< 1-Disable 2-Enable */
	uint32a	tlmt_ifg_add;		/*!< 1-Do not add ifg value for rate calculation
						     2-Add ifg value for rate calculation  */
	uint32a	tlmt_rate;		/*!< Data rate (1 kbps to 1000000 kbps) */
	uint32a	tlmt_rate_units;	/*!< 1-Data interms of bits per second
						     2-Data rate interms of packets per second */
	uint32a	tlmt_clear;		/*!< 1-Clear old credits for dynamic configuration
						     2-Do not clear credits for dynamic configuration */
	uint32a	tlmt_wt;		/*!< Meter weight */
} tlite_meter_params_t;

/*!
 * Scheduler config structure
 */

typedef struct _tlite_schd_params_t_ {

	uint32a	tlsd_schd_id;		/*!< Scheduler number (1 to 2) depends on device number */
	uint32a	tlsd_dev_id;		/*!< Device number ( 1 to 4) */
	uint32a	tlsd_algo;		/*!< Scheduler algorithm type 1-RR, 2-WRR(packet based only),3-DWRR and 4-PQ */
	uint32a	tlsd_position;		/*!< Scheduler position */
	uint32a	tlsd_weight;		/*!< Scheduler weight */

} tlite_schd_params_t;


/*!
 * Shaper config structure
 */
typedef struct _tlite_shpr_params_t_ {
	uint32a	tlsp_shpr_updates; 	/*!< Shaper updates field */
	uint32a	tlsp_shpr_id;		/*!< Shaper number to connect to scheduler depends on device number. */
	uint32a	tlsp_dev_id;		/*!< Device number ( 1 to 4) */
	uint32a	tlsp_clk_frequency;	/*!< Clock frequency used to do weights calculation a given rate (Mhz) */
	uint32a	tlsp_rate;		/*!< Data rate for a given shaper packets per second or bits per second (Mbps). */
	uint32a	tlsp_rate_units;	/*!< Rate units 1 for bits/sec and 2 for packets/sec */
	uint32a	tlsp_max_credit;	/*!< Maximum value of the credit that can accumulated per shaper. */
	uint32a	tlsp_position;		/*!< Shaper position to connect. */
	uint32a	tlsp_min_credit;	/*!< Minimum value of the credit per shaper */
	uint32a	tlsp_mode;		/*!< mode 0 for bursty mode and 1 for zero burst mode */
	uint32a	state;			/*!< state of shaper 0-disabled 1-enabled */
} tlite_shpr_params_t;


/*!
 * Queue add structure
 */

typedef struct _tlite_classq_params_t_ {
	uint32a	tlcq_classq_updates;	/*!< Raise flags for updated parameters */
	uint32a	tlcq_dev_id;		/*!< Device number ( 1 to 4) */
	uint32a	tlcq_classq_id;		/*!< Queue number (1 to 8), value depends on device number */
	uint32a	tlcq_schd_id;		/*!< Scheduler number to which this classq is going to add and
						need to enable this scheduler bit in TDQ scheduler enable register. */
	uint32a	tlcq_schd_slot;		/*!< Each scheduler contains 8 queues (1-low priority and 8-high priority),
						assign current input classq in one of this priority queue. */
	uint32a	tlcq_max_len;		/*!< Quelength */
	uint32a	tlcq_weight;		/*!< Queue weight for weighted round robin algorithm */
	uint32a	tlcq_qmgmt;		/*!< This field decides queue management for drop mechanism tail drop or WRED. */
	uint32a	tlcq_min_len;		/*!< If que management is WRED then this field is treated as Qmin */
	uint32a	tlcq_prob_cfg0;		/*!< If queue management is WRED,configure probability value cfg0 (max value 255) */
	uint32a	tlcq_prob_cfg1;		/*!< If queue management is WRED,configure probability value cfg1 (max value 255) */
	uint32a	tlcq_prob_cfg2;		/*!< If queue management is WRED,configure probability value cfg2 (max value 255) */
	uint32a	tlcq_prob_cfg3;		/*!< If queue management is WRED,configure probability value cfg3 (max value 255) */
	uint32a	tlcq_prob_cfg4;		/*!< If queue management is WRED,configure probability value cfg4 (max value 255) */
	uint32a	tlcq_prob_cfg5;		/*!< If queue management is WRED,configure probability value cfg5 (max value 255) */
	uint32a	tlcq_prob_cfg6;		/*!< If queue management is WRED,configure probability value cfg6 (max value 255) */
	uint32a	tlcq_prob_cfg7;		/*!< If queue management is WRED,configure probability value cfg7 (max value 255) */
} tlite_classq_params_t;


/*!
 * Credit based shaper config structure
 */
typedef struct _tlite_creditmode_params_t_ {
	uint32a	tld_port_no; 		/*!< Port number */
	uint32a	tld_traffic_class;	/*!< Queue number */
	uint32a	tld_idle_slope;		/*!< (0 - 100 million) This is the shaper rate in bits per second */
	uint32a	tld_shaper_id;		/*!< (0 - 1 ) shaper id  */
} tlite_creditmode_params_t;

/*!
 This function enables the dynamic configuration

 @param hw_type      Hardware type (switch or FA)
 @return status code 0=success, others=failure
**/
int32a pfe_tlite_dynamic_config_enable(uint32a hw_type);

/*!
 This function configures given scheduler in tlite module

 @param tlite_schd_params_t* Scheduler config structure
 @return status code         0=success, others=failure
**/
int32a pcm_tlite_scheduler_config(tlite_schd_params_t *psch, uint32a hw_type);

/*!
 This function configures given shaper in tlite module
 @param tlite_shpr_params_t* Shaper config structure
 @param hw_type              Hardware type (switch or FA)
 @return status code         0=success, others=failure
**/
int32a pcm_tlite_shaper_config(tlite_shpr_params_t *pshp,
				uint32a hw_type,
				uint32a dynamic);

/*!
 This function adds classq for a given scheduler

 @param tlite_classq_params_t*  Queue add structure
 @param hw_type                 Hardware type (switch or FA)
 @return status code            0=success, others=failure
**/
int32a pcm_tlite_classq_add(tlite_classq_params_t *que, uint32a hw_type);

/*!
 This function deletes que number from a given scheduler

 @param dev_id         Device number(1 to 4)
 @param qnum           Queue number for delete which is added queue (1to 8)
 @param hw_type        Hardware type (switch or FA)
 @return status code   0=success, others=failure
**/
int32a pcm_tlite_classq_delete(uint32a dev_id, uint32a qnum, uint32a hw_type);

/*!
 This function set inter frame gap value of given device

 @param dev_id        Device number (1 to 4)
 @param ifg           Ifg value for given device in terms of Bytes,
                      This value is added to the packet count for every packet
                      when decrementing from the credit value (Maximum value 255).
 @param hw_type       Hardware type (switch or FA)
 @return status code  0=success, others=failure
**/
int32a pfe_tlite_set_ifg(uint32a dev_id, uint32a ifg, uint32a hw_type);

/*!
 This function configures given shaper in tlite module

 @param tlite_meter_params_t* 	Meter configuration structure
 @return status                 code 0=success, others=failure
**/
int32a pcm_tlite_fasw_meter_config(tlite_meter_params_t *pmtr);

/*!
 This function enables or disables all meters in tlite module

 @param enable 			1-Disable all meters 2-Enable all meters
 @return status                 code 0=success, others=failure
**/
int32a pfe_tlite_fasw_meter_enable(uint32a enable);

/*!
 This function set intialization done, so that hardware will start to process

 @return status                 code 0=success, others=failure
**/
int32a pfe_tlite_dynamic_config_done(void);

/*!
 This function reads the transmit packet count and current queue drop count send to user side

 @param dev_id                 Device number (1 to 4)
 @param que_number             Queue number (1 to 8)
 @param hw_type                Hardware type (switch or FA)
 @return pcm_msg_header_t *    Queue stats structure pointer
**/
pcm_msg_header_t * pfe_tlite_que_stats(uint32a dev_id, uint32a que_number, uint32a hw_type);

/*!
 This function reads the inq write pointer, inq read pointer and fifo count send to user side

 @return pcm_msg_header_t *    Inq stats structure pointer
**/
pcm_msg_header_t * pfe_tlite_inq_stats(void);

/*!
 This function reads the configured schedulers and displays

 @param dev_id        Device number (1 to 4)
 @return iptr         schedule list pointer
**/
uint32a * pfe_tlite_sch_list(uint32a dev_id);

/*!
 This function reads the configured shapers and displays

 @param dev_id        Device number (1 to 4)
 @return iptr         Shaper list pointer
**/
uint32a * pfe_tlite_shp_list(uint32a dev_id);

/*!
 This function reads the configured queues and displays

 @param dev_id        Device number (1 to 4)
 @return iptr         Queue list pointer
**/
uint32a * pfe_tlite_classq_list(uint32a dev_id);

/*!
 This function reads the configured queues and displays per scheduler

 @param dev_id        Device number (1 to 4)
 @return iptr         Queue schedule list pointer
**/
uint32a * pfe_tlite_classq_per_sched_list(uint32a dev_id);

/*!
 This function configures given credit mode shaper in tlite module

 @param tlite_creditmode_params_t * Credit based shaper config structure
 @return status code                0=success, others=failure
**/
int32a pcm_tlite_creditmode_shaper_config(tlite_creditmode_params_t* ptdp);


#endif /*End of _TLITE_BLOCKS_CTRLM_H_*/
