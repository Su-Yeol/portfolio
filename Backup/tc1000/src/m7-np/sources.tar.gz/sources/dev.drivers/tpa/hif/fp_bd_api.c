// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_bd_api.c
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    defines for buffer descriptors
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifdef __linux__
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");
MODULE_SOFTDEP("pre: nf_conntrack");

#ifdef NPU_PLATFORM_DRIVER
#include <linux/platform_device.h>
#endif
#endif //ifdef __linux__

#include <string.h> // for memset
#include "fp_library.h"
#include "fp_net_driver.h"
#include "fp_hif_reg.h"
#include "fp_bd_api.h"
#include "platform.h"

/* holds the total ring size of the entire dma alloc */
uint32a  fp_total_ring_size;

static struct bd_ring tx_bd_ring_base[NUM_TOTAL_HIF][NUM_HIF_CHANNELS];
static struct bd_ring rx_bd_ring_base[NUM_TOTAL_HIF][NUM_HIF_CHANNELS];


/* define prototype */
static int fp_bd_create_ring(struct fp_private *fp);
static int fp_bd_init_ring(struct bd_ring *ring);
static void fp_dump_wb_bd_info(struct wb_bd *dump_bd);
static int fp_wb_bd_init_ring(struct bd_ring *ring);
static void fp_dump_bd_info(struct bd *dump_bd);

/***************************************************************************
 * Function Name  : fp_bd_create_ring
 * Description    : allocate memory for tx/rx/write_bk bd's and tx/rx pktbuf
 * Inputs
 *   Parameters   : struct fp_private *, int, int
 * Outputs        :
 *   Parameters   : struct fp_private *
 *   Returns      : int
 * Changes        :
 ***************************************************************************/
static int32a fp_bd_create_ring(struct fp_private *fp)
{
	int8 buff[256];
	uint32a *dev_addr = (uint32a *)&buff[0];
	void *cpu_addr;
	void *saved_cpu_addr = NULL;
	dma_addr_t saved_dev_addr = 0;
	struct bd_ring *txring;
	struct bd_ring *rxring;
	uint32a hif_id = 0;
	uint32a ch_id;

	for (hif_id = 0; hif_id < NUM_TOTAL_HIF; hif_id++) {
		ch_id = HIF_CHNUM_NP; //for (ch_id = 0; ch_id < NUM_HIF_CHANNELS; ch_id++)
		{
			if (!fp->reset_bd) {
				#if 0
				fp->hif[hif_id].ch[ch_id].txring = (struct bd_ring *)
				kmalloc(sizeof(struct bd_ring), GFP_ATOMIC);
				fp->hif[hif_id].ch[ch_id].rxring = (struct bd_ring *)
				kmalloc(sizeof(struct bd_ring),	GFP_ATOMIC);
				if ((fp->hif[hif_id].ch[ch_id].txring == NULL) || (fp->hif[hif_id].ch[ch_id].rxring == NULL)) {
					pr_err("error kmalloc: rx/tx ring\n");
					return -1;
				}
				#else
				/* TSNC note: use static buffer, instead of malloc */
				fp->hif[hif_id].ch[ch_id].txring = &tx_bd_ring_base[hif_id][ch_id];
				fp->hif[hif_id].ch[ch_id].rxring = &rx_bd_ring_base[hif_id][ch_id];
				#endif
			} else {
				saved_dev_addr = fp->hif[hif_id].ch[ch_id].txring->dev_addr;
				saved_cpu_addr = fp->hif[hif_id].ch[ch_id].txring->cpu_addr;
			}
			txring = fp->hif[hif_id].ch[ch_id].txring;
			rxring = fp->hif[hif_id].ch[ch_id].rxring;
			SAL_MemSet(txring, 0, sizeof(struct bd_ring));
			SAL_MemSet(rxring, 0, sizeof(struct bd_ring));
			/* Size required to be allocated for
			 * TX & RX BDs, TX & RX buffers
			 */
			txring->size = (NUM_TX_WB_DESCR * sizeof(struct wb_bd)) + (NUM_TX_DESCR * sizeof(struct bd)) + (NUM_TX_DESCR * MAX_BUFF_SIZE);
			rxring->size = (NUM_RX_WB_DESCR * sizeof(struct wb_bd)) + (NUM_RX_DESCR * sizeof(struct bd)) + (NUM_RX_DESCR * MAX_BUFF_SIZE);
			fp_total_ring_size = txring->size + rxring->size + (6 * ALIGN_64_BIT_MASK);
			if (!fp->reset_bd) {
				/* dma memory allocation */
				cpu_addr = platform_dma_alloc(ch_id, fp_total_ring_size, (dma_addr_t *)dev_addr);
				pr_debug("platform_dma_alloc returned %px\n",cpu_addr);
				if (cpu_addr == NULL) {
					pr_err("ERROR at alloc hif_id %d ch_id %d\n", hif_id, ch_id);
					return -1;
				}
				txring->dev_addr = rxring->dev_addr = *dev_addr;
				txring->cpu_addr = rxring->cpu_addr = cpu_addr;
			} else {
				txring->dev_addr = rxring->dev_addr = saved_dev_addr;
				txring->cpu_addr = rxring->cpu_addr = saved_cpu_addr;
			}
			/******************************************************
			 *  DMA Memory Mapping Order:                         *
			 *   TX WR BACK BD Desc                               *
			 *   RX WR BACK BD DESC                               *
			 *   TX BD DESC                                       *
			 *   RX BD DESC                                       *
			 *   TX PKT BUFF                                      *
			 *   RX PKT BUFF                                      *
			 ******************************************************/
			/* Mapping above DMA memory into
			 *	corresponding BD structure format
			 */
			/* Virtual bdp address initialization */
			txring->wb_bd_tbl_va = (struct wb_bd *)((((uint32)txring->cpu_addr) + ALIGN_64_BIT_MASK - 1) & ~(ALIGN_64_BIT_MASK - 1));
			rxring->wb_bd_tbl_va = (struct wb_bd *)(((uint32)txring->wb_bd_tbl_va + (NUM_TX_WB_DESCR * sizeof(struct wb_bd)) +
				ALIGN_64_BIT_MASK - 1) & ~(ALIGN_64_BIT_MASK - 1));
			txring->bd_tbl_va = (struct bd *)(((uint32)rxring->wb_bd_tbl_va + (NUM_RX_WB_DESCR * sizeof(struct wb_bd)) +
				ALIGN_64_BIT_MASK - 1) & ~(ALIGN_64_BIT_MASK - 1));
			rxring->bd_tbl_va = (struct bd *)(((uint32)txring->bd_tbl_va + (NUM_TX_DESCR * sizeof(struct bd)) +
				ALIGN_64_BIT_MASK - 1) & ~(ALIGN_64_BIT_MASK - 1));

			platform_memset(txring->wb_bd_tbl_va, 0, sizeof(struct wb_bd) * NUM_TX_WB_DESCR);
			platform_memset(rxring->wb_bd_tbl_va, 0, sizeof(struct wb_bd) * NUM_RX_WB_DESCR);
			platform_memset(txring->bd_tbl_va, 0, sizeof(struct bd) * NUM_TX_DESCR);
			platform_memset(rxring->bd_tbl_va, 0, sizeof(struct bd) * NUM_RX_DESCR);

			txring->bd_buff_va = (struct bd *)(((uint32)rxring->bd_tbl_va + (NUM_RX_DESCR * sizeof(struct bd)) +
				ALIGN_64_BIT_MASK - 1) & ~(ALIGN_64_BIT_MASK - 1));
			rxring->bd_buff_va = (struct bd *)(((uint32)txring->bd_buff_va + (NUM_TX_DESCR * MAX_BUFF_SIZE) +
				ALIGN_64_BIT_MASK - 1) & ~(ALIGN_64_BIT_MASK - 1));
			/* Physical bdp address initialization */
			txring->wb_bd_tbl_pa = (dma_addr_t)(((uint32)txring->dev_addr + ALIGN_64_BIT_MASK - 1) & ~(ALIGN_64_BIT_MASK - 1));
			rxring->wb_bd_tbl_pa = (dma_addr_t)(((uint32)txring->wb_bd_tbl_pa + (NUM_TX_WB_DESCR * sizeof(struct wb_bd)) +
				ALIGN_64_BIT_MASK - 1) & ~(ALIGN_64_BIT_MASK - 1));
			txring->bd_tbl_pa = (dma_addr_t)(((uint32)rxring->wb_bd_tbl_pa + (NUM_RX_WB_DESCR * sizeof(struct wb_bd)) +
				ALIGN_64_BIT_MASK - 1) & ~(ALIGN_64_BIT_MASK - 1));
			rxring->bd_tbl_pa = (dma_addr_t)(((uint32)txring->bd_tbl_pa + (NUM_TX_DESCR * sizeof(struct bd)) +
				ALIGN_64_BIT_MASK - 1) & ~(ALIGN_64_BIT_MASK - 1));
			txring->bd_buff_pa = (dma_addr_t)(((uint32)rxring->bd_tbl_pa + (NUM_RX_DESCR * sizeof(struct bd)) +
				ALIGN_64_BIT_MASK - 1) & ~(ALIGN_64_BIT_MASK - 1));
			rxring->bd_buff_pa = (dma_addr_t)(((uint32)txring->bd_buff_pa + (NUM_TX_DESCR * MAX_BUFF_SIZE) +
				ALIGN_64_BIT_MASK - 1) & ~(ALIGN_64_BIT_MASK - 1));

			#if 0
			mcu_printf("rxring cpu_addr 0x%08x dev_addr     0x%08x\n", (void *)rxring->cpu_addr,     rxring->dev_addr);
			mcu_printf("   wb_bd_tbl_va 0x%08x wb_bd_tbl_pa 0x%08x\n", (void *)rxring->wb_bd_tbl_va, rxring->wb_bd_tbl_pa);
			mcu_printf("      bd_tbl_va 0x%08x bd_tbl_pa    0x%08x\n", (void *)rxring->bd_tbl_va,    rxring->bd_tbl_pa);
			mcu_printf("     bd_buff_va 0x%08x bd_buff_pa   0x%08x\n", (void *)rxring->bd_buff_va,   rxring->bd_buff_pa);
			mcu_printf("txring cpu_addr 0x%08x dev_addr     0x%08x\n", (void *)txring->cpu_addr,     txring->dev_addr);
			mcu_printf("   wb_bd_tbl_va 0x%08x wb_bd_tbl_pa 0x%08x\n", (void *)txring->wb_bd_tbl_va, txring->wb_bd_tbl_pa);
			mcu_printf("      bd_tbl_va 0x%08x bd_tbl_pa    0x%08x\n", (void *)txring->bd_tbl_va,    txring->bd_tbl_pa);
			mcu_printf("     bd_buff_va 0x%08x bd_buff_pa   0x%08x\n", (void *)txring->bd_buff_va,   txring->bd_buff_pa);
			#endif

			txring->head = txring->tail = txring->bd_tbl_va;
			txring->wb_read_ptr = txring->wb_bd_tbl_va;
			txring->ring_len = NUM_TX_DESCR;
			txring->wb_seq_num = 1;
			txring->seq_num = 1;
			txring->wb_ring_len = NUM_TX_WB_DESCR;
			txring->flag = TX_BD_INIT_RING;
			rxring->head = rxring->tail = rxring->bd_tbl_va;
			rxring->wb_read_ptr = rxring->wb_bd_tbl_va;
			rxring->ring_len = NUM_RX_DESCR;
			rxring->seq_num = 1;
			rxring->wb_seq_num = 1;
			rxring->wb_ring_len = NUM_RX_WB_DESCR;
			rxring->flag = RX_BD_INIT_RING;
		} /* End of inner for loop */
	} /* End of outer for loop */
//#ifdef DOORBELL_TEST
#if 0
{
	dma_addr_t  db_phy_addr;
	uint32a db_cpu_addr = dma_alloc_coherent(&fp->pci_dev->dev,
		1024, (dma_addr_t *)&db_phy_addr, GFP_ATOMIC);
	printk("db_phy_addr is %x \n", db_phy_addr);
}
#endif
	return 0;
}

/***************************************************************************
 * Function Name  : fp_bd_init_ring
 * Description    : initialize the tx/tx/wb rings
 * Inputs
 *   Parameters   : struct fp_private *, int, int
 * Outputs        :
 *   Parameters   : struct fp_private *
 *   Returns      : int
 * Changes        :
 ***************************************************************************/
static int32a fp_bd_init_ring(struct bd_ring *ring)
{
	int32a desc_id = 0;
	struct bd *bd_va, *bd_pa;
	uint32a bd_bufaddr;

	struct bd copy_bd;
	struct bd *temp_bd = &copy_bd;
	
	//printk("[%s]\n", __func__);
	if (ring == NULL) {
		TPA_E("%s: null ring ptr\n", __func__);
		return -1;
	}
	bd_va = ring->bd_tbl_va;
	bd_pa = (struct bd *)(uint32)ring->bd_tbl_pa;
	bd_bufaddr = (uint32a)ring->bd_buff_pa;
	for (desc_id = 0; desc_id < ring->ring_len; desc_id++)
	{
		/* avoid bus error. handle on local memory */		
		platform_memcpy_sw(temp_bd, bd_va, sizeof(struct bd));

		temp_bd->bd_ctrl = 0;
		temp_bd->rsvd = 0;
		temp_bd->bd_bufaddr = (uint32a) (bd_bufaddr + ((desc_id + 0) * MAX_BUFF_SIZE));
		if (ring->flag == RX_BD_INIT_RING)
		{
			temp_bd->bd_ctrl |= BD_CTRL_CBD_INT_EN | BD_CTRL_PKT_INT_EN | BD_CTRL_DIR;
			temp_bd->bd_buflen = MAX_FRAME_SIZE;

			/* avoid bus error. restore to local memory */		
			platform_memcpy_sw(bd_va, temp_bd,  sizeof(struct bd));
			fp_enque_bd(ring, bd_va);
		}
		else
		{
			/* avoid bus error. restore to local memory */		
			platform_memcpy_sw(bd_va, temp_bd,  sizeof(struct bd));
		}

		if (desc_id == ring->ring_len - 1)
		{
			bd_va->bd_nextptr = (uint32)bd_pa;
			//bd_va->bd_ctrl |= (bd_va->bd_ctrl | BD_CTRL_LAST_BD);
		}
		else
		{
			bd_va->bd_nextptr = (uint32)(bd_pa + desc_id + 1);
		}
		
		//pr_debug("va: %p pa %u buf_ptr_pa %u\n",
		//		(void *)bd_va, bd_va->bd_nextptr,
		//		bd_va->bd_bufaddr);
		#if 0
		printk("va: %px pa %08x buf_ptr_pa %08x\n",
				(void *)bd_va, bd_va->bd_nextptr,
				bd_va->bd_bufaddr);
		#endif
		bd_va = bd_va + 1;
	}

	return 0;
}

/***************************************************************************
 * Function Name  : fp_dump_wb_bd_info
 * Description    : dump write back bd
 * Inputs
 *   Parameters   : struct wb_bd *
 * Outputs        :
 *   Parameters   :
 *   Returns      : void
 * Changes        :
 ***************************************************************************/
static void fp_dump_wb_bd_info(struct wb_bd *dump_bd)
{
#if 0
	pr_info("WBBD:\t%p size %u\n", dump_bd,
					(uint32a)sizeof(struct wb_bd));
	pr_info("ctrl\t%x bd_buflen\t%x bd_seqnum\t%x\n",
				dump_bd->bd_ctrl, dump_bd->bd_buflen,
				dump_bd->bd_seqnum);
#endif
}

/***************************************************************************
 * Function Name  : fp_dump_bd_info
 * Description    : dump tx/rx bd
 * Inputs
 *   Parameters   : struct bd *
 * Outputs        :
 *   Parameters   :
 *   Returns      : void
 * Changes        :
 ***************************************************************************/
static void fp_dump_bd_info(struct bd *dump_bd)
{
#if 0
	pr_info("ctrl    %x seqnum  %x\n",dump_bd->bd_ctrl, dump_bd->bd_seqnum);
	pr_info("buflen  %x rsvd    %x\n",dump_bd->bd_buflen, dump_bd->rsvd);
	pr_info("bufaddr %x nextptr %x\n",dump_bd->bd_bufaddr,dump_bd->bd_nextptr);
#endif
}

/***************************************************************************
 * Function Name  : fp_wb_bd_init_ring
 * Description    : initialize the tx/tx/wb rings
 * Inputs
 *   Parameters   : struct fp_private *, int, int
 * Outputs        :
 *   Parameters   : struct fp_private *
 *   Returns      : int
 * Changes        :
 ***************************************************************************/
static int32a fp_wb_bd_init_ring(struct bd_ring *ring)
{
	int32a desc_id = 0;
	struct wb_bd *curr_bd;

	if (ring == NULL) {
		pr_err("%s: null ring ptr\n", __func__);
		return -1;
	}
	//printk("[%s] memset wb_bd_tbl_va %px, size %ld\n", __func__, ring->wb_bd_tbl_va, sizeof(struct wb_bd));
	platform_memset(ring->wb_bd_tbl_va, 0, sizeof(struct wb_bd));
	curr_bd = ring->wb_bd_tbl_va;
	for (desc_id = 0; desc_id < ring->wb_ring_len; desc_id++) {
		curr_bd->bd_seqnum = 0xff;
		curr_bd++;
	}
	return 0;
}

/***************************************************************************
 * Function Name  : fp_get_next_free_bd
 * Description    : initialize the tx/tx/wb rings
 * Inputs
 *   Parameters   :
 * Outputs        :
 *   Parameters   : struct fp_private *
 *   Returns      : int
 * Changes        :
 ***************************************************************************/
struct bd *fp_get_next_free_bd(struct bd_ring *ring)
{
	struct bd *tail;

	if (ring == NULL) {
		pr_err("%s: get_next_free_bd: bd_ring is NULL\n", __func__);
		return NULL;
	}
	tail = ring->tail;
	pr_debug("Free bd %p\n", tail);
	if (tail->bd_ctrl & BD_CTRL_DESC_EN)
		return NULL;
	else
		return tail;
}

/**********************************************************************
 * Function Name  : fp_get_curr_bd_id
 * Description    : get the curr bd id from the ring
 * Inputs
 *   Parameters   : struct bd_ring *, struct bd *
 * Outputs        :
 *   Parameters   :
 *   Returns      : int
 * Changes        :
 *********************************************************************/
uint32a fp_get_curr_bd_index(struct bd_ring *ring, struct bd *bd)
{
	return (uint32a)(bd - ring->bd_tbl_va);
}

/**********************************************************************
 * Function Name  : fp_check_bd_status
 * Description    : check write back bd is avail or not for software
 * Inputs
 *   Parameters   : struct bd_ring *
 * Outputs        :
 *   Parameters   :
 *   Returns      : int
 * Changes        :
 *********************************************************************/
int32a fp_check_bd_status(struct bd_ring *ring)
{
	struct wb_bd *curr_wb = ring->wb_read_ptr;

	/* Check expected seq num in the bd */
	if ((ring->wb_seq_num == curr_wb->bd_seqnum)
	&&   (curr_wb->bd_ctrl && WB_BD_CTRL_DESC_EN)) {
		ring->wb_seq_num = ring->wb_seq_num + 1;
		return 0;
	} else {
		return -1;
	}
}

/**********************************************************************
 * Function Name  : fp_enque_bd
 * Description    : enque bd into the ring
 *                  after enque, bd gets owned by hardware unti it dequeued
 * Inputs
 *   Parameters   : struct bd_ring *, struct bd *
 * Outputs        :
 *   Parameters   :
 *   Returns      : int
 * Changes        :
 *********************************************************************/
int32a fp_enque_bd(struct bd_ring *ring, struct bd *curr_bd)
{
	if (curr_bd->bd_ctrl & BD_CTRL_DESC_EN)
	{
		pr_err("enque_bd: DESC_EN is already set\n");
		return -1;
	}

	/* Update the bd seq. num */
	curr_bd->bd_seqnum = ring->seq_num;
	ring->seq_num = ring->seq_num + 1;
	if(ring->bd_tbl_va + ring->ring_len - 1 == curr_bd)
	{
		curr_bd->bd_ctrl |= BD_CTRL_LAST_BD;
	}

	curr_bd->bd_ctrl |= BD_CTRL_DESC_EN;
	pr_debug("ring->tail is %x\n", (uint32)ring->tail);
	/* update tail to next free location */
	ring->tail = ring->tail + 1;
	if(ring->tail >= (ring->bd_tbl_va + ring->ring_len))
	{
		ring->tail = ring->bd_tbl_va;
	}

	return 0;
}

/**********************************************************************
 * Function Name  : fp_deque_bd
 * Description    : deque bd from the ring
 *                  after deque, bd gets owned by software unti it enqueued
 * Inputs
 *   Parameters   : struct bd_ring *, unsigend int *
 * Outputs        :
 *   Parameters   :
 *   Returns      : struct bd *
 * Changes        :
 *********************************************************************/
struct bd *fp_deque_bd(struct bd_ring *ring, uint32a *wb_buflen)
{
	struct bd *head;
	struct wb_bd *wrbk = ring->wb_read_ptr;
	struct wb_bd *wrbk_end = ring->wb_bd_tbl_va + ring->wb_ring_len;

	head = ring->head;
	fp_dump_wb_bd_info(wrbk);
	pr_debug("deque_bd: head is %lx, wrbk is %lx\n",
				(uint32)head, (uint32)wrbk);
	if ((head->bd_seqnum != wrbk->bd_seqnum) ||
				(!(head->bd_ctrl & BD_CTRL_DESC_EN))) {
		pr_debug("head seq num and wb seq num are not equal %d %d\n",
				head->bd_seqnum, wrbk->bd_seqnum);
		return NULL;
	}
#if 0
	pr_debug("seq_no %x, bd_ctrl %x, buf_len %x\n", wrbk->bd_seqnum,
				wrbk->bd_ctrl, wrbk->bd_buflen);
#else
	#ifdef TC_DEBUG_PACKET_DATA
	printk("dequeue seq_no %x, bd_ctrl %x, buf_len %x\n", wrbk->bd_seqnum,
			wrbk->bd_ctrl, wrbk->bd_buflen);
	#endif
#endif
	*wb_buflen = wrbk->bd_buflen;
	/* Reset DESC_EN bit, */
	head->bd_ctrl &= (~(BD_CTRL_DESC_EN));
	head->bd_seqnum = 0;
	ring->head = ring->head + 1;
	if (ring->head >= (ring->bd_tbl_va + ring->ring_len))
		ring->head = ring->bd_tbl_va;
	ring->wb_read_ptr = (((wrbk + 1) >= wrbk_end) ?
				(ring->wb_bd_tbl_va) : (wrbk + 1));
	pr_debug("read_ptr is %lx, wrbk_end  %lx\n",
		(uint32)ring->wb_read_ptr, (uint32)wrbk_end);
	pr_debug("ring->wb_read_ptr is %lx\n",
				(uint32)ring->wb_read_ptr);
	return head;
}

/**********************************************************************
 * Function Name  : fp_bd_init
 * Description    : initialize the rx bd ring & tx bd ring
 * Inputs
 *   Parameters   : struct fp_private *, int, int
 * Outputs        :
 *   Parameters   : struct fp_private *
 *   Returns      : int
 * Changes        :
 *********************************************************************/
int32a fp_bd_init(struct fp_private *fp)
{
	uint32a hif_id = 0;
	uint32a ch_id = 0;

	/* Allocate memory and initialize bd rings */
	if (fp_bd_create_ring(fp) < 0) {
		pr_err("init the txring failed...so return\n");
		return -ENOMEM;
	}

	for (hif_id = 0; hif_id < NUM_TOTAL_HIF; hif_id++) {
		ch_id = HIF_CHNUM_NP; //for (ch_id = 0; ch_id < NUM_HIF_CHANNELS; ch_id++)
		{
			if (fp_bd_init_ring(fp->hif[hif_id].ch[ch_id].txring) < 0) {
				pr_err("hif %u ch %u init txring failed\n", hif_id, ch_id);
				return -ENOMEM;
			}
			if (fp_bd_init_ring(fp->hif[hif_id].ch[ch_id].rxring) < 0) {
				pr_err("hif %u channel %u init rxring failed\n", hif_id, ch_id);
				return -ENOMEM;
			}
			//printk("[%s] invoke fp_wb_bd_init_ring ch_id=%d tx\n" , __func__, ch_id);
			if (fp_wb_bd_init_ring(fp->hif[hif_id].ch[ch_id].txring) < 0) {
				pr_err("hif %u channel %u init wbring failed\n", hif_id, ch_id);
				return -ENOMEM;
			}
			//printk("[%s] invoke fp_wb_bd_init_ring ch_id=%d rx\n" , __func__, ch_id);
			if (fp_wb_bd_init_ring(fp->hif[hif_id].ch[ch_id].rxring) < 0) {
				pr_err("hif %u channel %u init wbring failed\n", hif_id, ch_id);
				return -ENOMEM;
			}
		}
	}

	return 0;
}

int32a fp_bd_reinit(void)
{
	if (!fpGlobal) {
		pr_err("Global private device not found\n");
		return 0;
	}

	fpGlobal->reset_bd = 1;
	fp_bd_init(fpGlobal);
	fp_init_bdp_base_reg(fpGlobal);
	fp_en_hif_rxdma_engine(fpGlobal);
	fpGlobal->reset_bd = 0;
	return 0;
}
