// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_epp_init.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    epp initialization functions
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                     Include Files
 **********************************************************************/
#include <linux/proc_fs.h>
#include <linux/etherdevice.h>

#include "fp_library.h"
#include "wsp_vlan_hash_table_L.h"
#include "tables_config.h"
#include "fp_hif_reg.h"

/**********************************************************************
 *    Global Declarations
 **********************************************************************/
/* Enabling debug prints for a feature can be done by setting the respective
 * flags in the follwoing global variable. */

uint8 fp_dbgp_arr[FP_MAX_DBGP][FP_MAX_DBGP_LEN] = {
	{"DBGP_FEAT_HIF"},
	{"DBGP_FEAT_BRIDGE"},
	{"DBGP_FEAT_ROUTE"},
	{"DBGP_FEAT_FWD_PE"},
	{"DBGP_FEAT_TMU"},
	{"DBGP_FEAT_CLI"},
	{"DBGP_FEAT_L2CLI"},
	{"DBGP_FEAT_L3CLI"},
	{"DBGP_FEAT_L2API"},
	{"DBGP_FEAT_L3API"},
	{"DBGP_FEAT_IOCTL"},
	{"DBGP_FEAT_LIB"},
	{"DBGP_FEAT_ERR"}
};

#ifdef FP_DEBUG_LEVEL_MAX
uint32a fp_dbgp_flags = 0x1FFF;
uint32a fp_trace_level = 7;
#else
uint32a fp_dbgp_flags = 0x1;
uint32a fp_trace_level = 1;
#endif
uint8  *fp_net_dev;

extern int32a fp_pci_init(void);
extern void fp_pci_exit(void);

static struct proc_dir_entry  *parent;

#ifdef PROC_IPSEC_TEST_SELECT
static int32a test_num = 0;

static struct proc_dir_entry *ipsec_entry;

static ssize_t ipsec_write(struct file *file, const int8 __user *ubuf,size_t count, loff_t *ppos)
{
	sscanf(ubuf, "%d", &test_num);
	printk( KERN_DEBUG "setting test to %i",test_num);
	return count;
}

static ssize_t ipsec_read(struct file *file, int8 __user *ubuf,size_t count, loff_t *ppos)
{
	ssize_t len;
	printk( KERN_DEBUG "test num = %i",test_num);
	len = snprintf(ubuf,count,"\n%i\n",test_num);
	if (*ppos) {
		return 0;
	} else {
		*ppos = len;
	}
	return len;
}

static struct file_operations ipsec_test_ops =
{
	.owner = THIS_MODULE,
	.read  = ipsec_read,
	.write = ipsec_write,
};

int32a get_ipsec_test(void)
{
	return test_num;
}
#endif	//	end of #ifdef PROC_IPSEC_TEST_SELECT

#define PROC_HIF_CHAN_SELECT
#ifdef PROC_HIF_CHAN_SELECT

static struct proc_dir_entry *hifchan_entry;
static struct proc_dir_entry *hifcounts_entry;


extern void   proc_SetHifnum(uint32a num);
#if 0 /* org code cause unhandeld page fault. so replace to telechips code */
extern size_t proc_GetHifnum(int8 __user *ubuf,size_t buf_max);
extern size_t proc_GetHifCounts(int8 __user *ubuf,size_t buf_max);
#else
extern uint32a proc_GetHifnum(void);
int32a proc_GetHifCounts(uint32a *cnt_array);
#endif

static ssize_t hifnum_write(struct file *file, const int8 __user *ubuf,size_t count, loff_t *ppos)
{
	uint32a chan = 0;
	sscanf(ubuf, "%d", &chan);
	printk("adding port (mask = %i)\n",chan);
	proc_SetHifnum(chan);
	return count;
}

#if 0 /* org code cause unhandeld page fault. so replace to telechips code */
static ssize_t hifnum_read(struct file *file, int8 __user *ubuf,size_t count, loff_t *ppos)
{
	ssize_t len;
	len = proc_GetHifnum(ubuf, count);
	if (*ppos) {
		return 0;
	} else {
		*ppos = len;
	}
	return len;
}
#else
static ssize_t hifnum_read(struct file *file, int8 __user *ubuf,size_t count, loff_t *ppos)
{
	uint8 tempbuf[16];
	uint32a hifNum;
	ssize_t len;

	/* this function is invoked repeatdly, until return value is 0.
	   So below code forced to return at second call. */
	if (*ppos) {
		return 0;
	}

	hifNum = proc_GetHifnum();
	len = snprintf(tempbuf,16,"%i\n",hifNum);
	copy_to_user(ubuf, tempbuf, len);

	/* trick to avoid to be invoked repeatdly */
	*ppos = len;
	return len;
}
#endif

static ssize_t hifcount_write(struct file *file, const int8 __user *ubuf,size_t count, loff_t *ppos)
{
	printk("Can't write HIF channel counts\n");
	return 0;
}

#if 0  /* org code cause unhandeld page fault. so replace to telechips code */
static ssize_t hifcount_read(struct file *file, int8 __user *ubuf,size_t count, loff_t *ppos)
{
	ssize_t len;
	len = proc_GetHifCounts(ubuf, count);
	if (*ppos) {
		return 0;
	} else {
		*ppos = len;
	}
	return len;
}
#else
#define NUM_OF_HIF_CHANNEL (16)
static ssize_t hifcount_read(struct file *file, int8 __user *ubuf,size_t count, loff_t *ppos)
{
	int32a ret;
	ssize_t len;
	size_t ofs=0;
	uint32a cnt_array[NUM_OF_HIF_CHANNEL*2];
	uint8 tempbuf[128]; /* seems enough for 128byte per line */
	int32a port;
	int32a index;

	/* this function is invoked repeatdly, until return value is 0.
	   So below code forced to return at second call. */
	if (*ppos) {
		return 0;
	}

	ret = proc_GetHifCounts(&cnt_array[0]);

	for(port=0; port<NUM_OF_HIF_CHANNEL; port++)
	{
		index = port<<1;
		len = snprintf(tempbuf, 128,"Chan %2i -- %4i %4i\n", port, cnt_array[index], cnt_array[index+1]);
		if( (count-ofs)<len )
		{
			/* not enough buffer */
			printk("[%s] user_buffer is not enough.\n", __func__);
			break;
		}
		copy_to_user(ubuf+ofs, tempbuf, len);
		ofs += len;
	}

	/* trick to avoid to be invoked repeatdly */
	*ppos = ofs;
	return ofs;
}
#endif

static struct file_operations hifchan_ops =
{
	.owner = THIS_MODULE,
	.read  = hifnum_read,
	.write = hifnum_write,
};

static struct file_operations hifcounts_ops =
{
	.owner = THIS_MODULE,
	.read  = hifcount_read,
	.write = hifcount_write,
};
#endif	//	end of #ifdef PROC_HIF_CHAN_STUFF

int32a proc_init(void)
{
	printk("Adding EPP to /proc");
	parent=proc_mkdir("EPP",NULL);
#ifdef PROC_IPSEC_TEST_SELECT
	printk("Adding IPsec_test to /proc/EPP");
	ipsec_entry=proc_create("IPsec_test",0660,parent,&ipsec_test_ops);
#endif

#ifdef PROC_HIF_CHAN_SELECT
	printk("Adding HIF channel to /proc/EPP");
	hifchan_entry=proc_create("HIF_channel",0660,parent,&hifchan_ops);
	printk("Adding HIF counts to /proc/EPP");
	hifcounts_entry=proc_create("HIF_counts",0660,parent,&hifcounts_ops);
#endif
	return (0);
}

void proc_cleanup(void)
{
#ifdef PROC_IPSEC_TEST_SELECT
	proc_remove(ipsec_entry);
#endif
#ifdef PROC_HIF_CHAN_SELECT
	proc_remove(hifchan_entry);
	proc_remove(hifcounts_entry);
#endif
	proc_remove(parent);
}


struct net_device *fp_netdev_init(uint8 *membase, uint32a irq)
{
	struct fp_private *fppriv;
	struct net_device *dev = NULL;
	int8 macaddr[6];
	int32a rc = 0;


	printk("********************[%s] enter [v172]***********************\n", __func__);


	dev = alloc_etherdev_mq(sizeof(*fppriv), NPU_MAX_TX_QUEUES);
	if (!dev) {
		FP_DEBUG(DBGP_FEAT_ERR, FP_LOG_EMERG,
				"\n Unable to allocate new ethernet device");
		return NULL;
	}
	dev->flags &= ~IFF_UP;
	dev->netdev_ops   = &fp_netdev_ops;
	dev->ethtool_ops = &fp_ethtool_ops;
	dev->rtnl_link_ops = NULL;
	ether_setup(dev);
	dev->mtu = 1500;
	dev->flags &= ~IFF_MULTICAST;
//	and which code should be left in
#ifdef HIF2_EN
	/* Mac address for HIF2 fp0 device */
	macaddr[0] = 0x00;
	macaddr[1] = 0x1a;
	macaddr[2] = 0x2b;
	macaddr[3] = 0x3c;
	macaddr[4] = 0x4d;
	macaddr[5] = 0x5e;
#else
	/* Mac address for HIF1 fp0 device */
	macaddr[0] = 0x00;
	macaddr[1] = 0x01;
	macaddr[2] = 0x02;
	macaddr[3] = 0x03;
	macaddr[4] = 0x04;
	macaddr[5] = 0x05;
#endif
	memcpy(dev->dev_addr, macaddr, sizeof(macaddr));
	fppriv = (struct fp_private *)netdev_priv(dev);
	fppriv->dev = dev;
	fp_net_dev = (uint8 *)dev;
	fppriv->pcimem_base = membase;
//	printk("%s@%i - membase = %px",__FUNCTION__,__LINE__,membase);
	fp_assign_hif_base_addr(fppriv);
	//dev->base_addr = mem_start;
	dev->irq = irq;
	//FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_EMERG, "\n dev->base_addr:%lx",
	//						dev->base_addr);
	FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_EMERG, "\n PCIBASE:%p",
							fppriv->pcimem_base);
	strcpy(dev->name, "fp%d");
	rc = register_netdev(dev);
	if (rc) {
		return NULL;
	}
	FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_EMERG, "\n fpath device registered");
	FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO,
			"\n write and read the PCI memory space");
	spin_lock_init(&fppriv->lock);
	spin_lock_init(&fppriv->rx_lock);
	return dev;
}

int32a  fp_netdev_exit(void)
{
	struct net_device *dev = (struct net_device *)fp_net_dev;
	if (dev == NULL)
		return 0;
	fp_net_release(dev);
	if (dev) {
		unregister_netdev(dev);
		free_netdev(dev);
	}
	return 0;
}

static int32a __init
epp_init(void)
{
	printk("in epp_init(), calling proc_init()");
	proc_init();
	return fp_pci_init();
}

static void __exit
epp_exit(void)
{
	proc_cleanup();
	fp_pci_exit();
}

module_init(epp_init);
module_exit(epp_exit);

