/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          fp_port.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    Structures for hw switch
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

#ifndef  _FP_PORT_H_
#define  _FP_PORT_H_

#include "fp_macros.h"
/*
 * A frame can only be punted once, and the reason code will be
 * set to the first reason encountered.  Firmware must then manually
 * determine whether other reasons apply.
 */

/*!
 * Forwarding action.
 * This specifies the action to be taken by the forwarding plane
 */
enum fwd_action_e {
	ACT_FORWARD = 0,  /*!< Normal forward, use forward_list of MAC entry */
	ACT_FLOOD,        /*!< Flood to all ports in bridge domain, use forward list of BD entry */
	ACT_PUNT,         /*!< Punt packet to PE/host */
	ACT_DISCARD,      /*!< Discard this frame */
	ACT_OVERRIDE,
	ACT_FWD_MASK,
	ACT_COS_DISCARD
};

/*!
 * Acceptable frame type
 */
enum aft_e {
	ANY_TAGGING,       /*!< allow both tagged and untagged frames */
	TAGGED_ONLY,       /*!< allow only tagged frames */
	UNTAGGED_ONLY,     /*!< allow only untagged frames */
};

/*!
 * STP blocking state
 */
enum block_state_e {
	FORWARDING,        /*!< ok to learn SA and forward traffic */
	BLOCKED,           /*!< do not learn SA; do not forward frames */
	LEARN_ONLY,        /*!< ok to learn SA, but do not forward frames */
};


/*!
 * Private vlan port types
 */
enum pvlan_port_type_e {
	ISOLATED = 0,
	COMMUNITY,
	PROMISCUOUS,
	INTERSWITCH
};

/*!
 * Switch Port configuration.
 * The switch port has several fields which control its relationship with
 * the bridge domain.  The TPID field specifies how VLAN tags are
 * identified on the port (TPID is the ethertype of the VLAN tag).
 * AFT specifies whether tagged/untagged frames are filtered at ingress.
 * fallback_bd_id (or PVID or native VLAN) specifies which bridge domain
 * untagged packets will go to.
 *
 * A typical non-VLAN 802.1D port would be configured as:
 *   <TPID, AFT, BD_ID> = <0, ANY_TAGGING, 1>
 *
 * A typical 802.1Q trunk port with native VLAN 1 would be:
 *   <TPID, AFT, BD_ID> = <0x8100, ANY_TAGGING, 1>
 *
 * A typical 802.1Q access port with port-based VLAN as VLAN 5 would be:
 *   <TPID, AFT, BD_ID> = <0x8100, UNTAGGED_ONLY, 5>
 */
struct port_s {
	uint16		index;     /*!< index number identifying this port */
	uint16		shutdown;  /*!< shutdown/enable state, 1=shutdown */
	uint16		tpid;      /*!< 0, 0x8100, 0x88a8, 0x9100, 0x9200 */
	enum aft_e		aft;       /*!< acceptable frame type */
	uint16		fallback_bd_id; /*!< fallback bridge domain (PVID) */
	enum block_state_e	block_state;    /*!< block/forward state */

	/* QOS Related Fields Per Port */
	uint16	trusted;	/* Indicates the port is trusted */
	uint16	tcsel_table;	/* TC Select Table */
	uint16	pcp2tc_table;	/* PCP2TC Table */
	uint16	def_cfi;	/* Default CFI Value */
	uint16	def_pri;	/* This is the default PRI Field.
					 * The PCP bits added when a tag
					 * is added */
	uint16	def_tc;		/* This is the default TC Field.
					 * The TC bits are used for COS
					 * mapping. Ideally both def_pri
					 * and def_tc should be same,
					 * but for customer requirement */
	int32a	tc2cos_table;	/* TC2COS Table */
	uint16	pindex;		/* Actual Physical Index (PHY NO).
					 * Will be used to remap local
					 * port to Act PHY This is useful
					 * to distinguish multiple logical
					 * representations in Port-7. Also
					 * helps send multiple different pkts
					 * to same PHY VLAN/STPID to P-7 */
	uint16	csr_untag_from_btable; /* Take UNTAG Information from Bridge Table */
};


/*!
 * Bridge Domain configuration.
 * A Bridge Domain (BD) is normally associated with a VLAN ID and it consists
 * of a set of ports in its "domain".  In the fast path forwarding plane,
 * when a packet enters the bridge domain, its DA is looked up in the MAC
 * table for this BD.  If the DA is found, the normal action is to forward
 * the packet according to the forward_list in the MAC entry.  If the DA is
 * not found, the normal action is to flood the packet to all ports in the
 * bridge domain.  These actions can be overridden.
 *
 */
struct bd_entry_s {
	uint32a forward_list;	/*!< forward_list has a bit flag corresponding to each port */
	uint32a untag_list;		/*!< Indicates whether to untag the packets at egress */
	uint16 mstp_id;	/*!< Index for MSTP FSM Number. Used to clear all entries of an MSTP index */
	/*
	 * forwarding actions for various situations
	 * Note:  ACT_DO_BD_ACT is not a valid setting for these
	 * Note2: ACT_FORWARD is not really valid as a miss action, but sliently
	 *        becomes ACT_FLOOD
	 */
	enum fwd_action_e ucast_hit_action;	/*!< action to take when unicast DA found (default is ACT_FORWARD) */
	enum fwd_action_e mcast_hit_action;	/*!< action to take when multicast DA found (default is ACT_FORWARD) */
	enum fwd_action_e ucast_miss_action;	/*!< action to take when unicast DA not found (default is ACT_FLOOD) */
	enum fwd_action_e mcast_miss_action;	/*!< action to take when multicast DA not found (default is ACT_FLOOD) */
	uint32a tc;
};

/*!
 * Switch global configuration
 */
struct global_s {
	uint32a    l2_special_punt_enable; /*!< punt L2 special frames to FW */
	struct bd_entry_s fallback_bd_entry;   /*!< this entry is used if BD not found in table */
#if 0 /* TODO: */
	/* STPID1
	 *  - All the communication between the Class-FW and the Host
	 *    processor will be using a special TPID1.
	 *  - In the Host to Class-FW flow
	 *          - Host send a packet with STPID1 through the trunk port (Port-7)
	 *                  - The packet should be passed through to the class-hw
	 *                    logic (no additional tagging)
	 *                  - The class-hw will pass the packet to the class-hw
	 *                    with the port number attached to it.
	 *          - class-fw will take appropriate action
	 *                  - It will have the packet, source port number (Host port)
	 *                  - There will be a special bit to indicate the packet is
	 *                    from Host or created from FW in the VLAN fields
	 */
	uint16 mgmt_etype;	/* internal managed switch ethertype (aka STPID1),
			 * if mgmt channel disabled, set to zero
			 */
	uint8  mgmt_port;	/* index of port attached to manager (host);
			 * valid only when mgmt_etype is non-zero
			 */
	uint16 cutthru_list;	/* port list to apply cutthru rewrite
				 * if cutthru rewrite disabled, set to zero
				 */
	uint16 cutthru_etype;	/* cutthru TPID/ethertype (aka STPID2),
				 * valid only when cutthru_list is non-zero
				 */
	dscp2tc_table_s      dscp2tc_table;	/* A 6bits to 3 bits table. 64
						 * entries of 3 bits */
	bool l2_special_en_0;
	uint8 l2_special_addr_0[6] = { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x00 };
	uint8 l2_special_mask_0[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0 };
	bool l2_special_en_1;
	uint8 l2_special_addr_1[6] = { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x00 };
	uint8 l2_special_mask_1[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0 };
	bool csr_arl_dasa_only;		/* Spl option ARL Look up with only DA and SA */
	bool csr_vlan_lkup_mask_en;	/* ARL Result is "&" with VLAN Lookup to
					 * get final result
					 */
#endif /* TODO */
};


#endif /*End of _FP_PORT_H_ */

