/**
 * @file MRVL_AMG_Device.h
 * @brief Marvell Multi-gig Automotive Ethernet PHY Device Struct
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */

#ifndef MRVL_DEVICE_H
#define MRVL_DEVICE_H

#include "MRVL_AMG_Types.h"

typedef struct _MRVL_DEV MRVL_DEV;

/**
 * @brief Pointer to MRVL_DEV.
 * Indicate device information and interfaces
 *
 */
typedef MRVL_DEV* MRVL_DEV_PTR;

/* The following functions must be implemented. Implementation-specific */
typedef MRVL_APHY_STATUS(*READ_REG_XMDIO)(MRVL_DEV_PTR pDev, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16* data);
typedef MRVL_APHY_STATUS(*WRITE_REG_XMDIO)(MRVL_DEV_PTR pDev, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16 data);
typedef MRVL_APHY_STATUS(*WAIT_FUNC)(MRVL_DEV_PTR pDev, MRVL_APHY_U16 waitTime);

/* The following functions could be implemented for direct 32bit reg access. Implementation-specific */
typedef MRVL_APHY_STATUS(*READ_REG_SPI32)(MRVL_DEV_PTR pDev, MRVL_APHY_U32 regAddr, MRVL_APHY_U32* data);
typedef MRVL_APHY_STATUS(*WRITE_REG_SPI32)(MRVL_DEV_PTR pDev, MRVL_APHY_U32 regAddr, MRVL_APHY_U32 data);

/**
 * @brief Sturcture of PHY device
 *
 */
struct _MRVL_DEV {
	MRVL_APHY_U8 phyAddr;		/*!< PHY address */
	MRVL_APHY_U8 smiPort;		/*!< SMI port index */
	MRVL_APHY_SPEED t1_speed;
	MRVL_APHY_SERDES_SPEED sd_speed;
	MRVL_APHY_OPERATION_MODE op_mode;
	MRVL_APHY_BOOL use32Bit;	/*!< Set to TRUE if READ_REG_SPI32 and WRITE_REG_SPI32 are implemented and registered to struct. Set to FALSE to access 32bit reigster via AHB mailbox */
	/**
	 * @brief Read out a 16-bit value from a register through XMDIO interface.
	 *
	 * @param[in] MRVL_DEV_PTR Pointer to MRVL_DEV
 	 * @param[in] portAddr phy/port address
 	 * @param[in] devAddr MMD, device address
 	 * @param[in] regAddr register address 16bit
 	 * @param[out] data register value 16bit
	 * @return: MRVL_APHY_STATUS
	 */
	READ_REG_XMDIO readReg;
	/**
	 * @brief Write a 16-bit value into a register through XMDIO interface.
	 *
	 * @param[in] MRVL_DEV_PTR Pointer to MRVL_DEV
 	 * @param[in] portAddr phy/port address
 	 * @param[in] devAddr MMD, device address
 	 * @param[in] regAddr register address 16bit
 	 * @param[in] data register value 16bit
	 * @return: MRVL_APHY_STATUS
	 */
	WRITE_REG_XMDIO writeReg;
	/**
	 * @brief Read out a 32-bit value from a register through SPI interface.
	 *
	 * @param[in] MRVL_DEV_PTR Pointer to MRVL_DEV
 	 * @param[in] regAddr register address 32bit
 	 * @param[out] data register value 32bit
	 * @return: MRVL_APHY_STATUS
	 */
	READ_REG_SPI32 readReg32;
	/**
	 * @brief Write a 32-bit value into a register through SPI interface.
	 *
	 * @param[in] MRVL_DEV_PTR Pointer to MRVL_DEV
 	 * @param[in] regAddr register address 32bit
 	 * @param[in] data register value 32bit
	 * @return: MRVL_APHY_STATUS
	 */
	WRITE_REG_SPI32 writeReg32;
	/**
	 * @brief Delay for specified number of milliseconds.
	 *
	 * @param[in] MRVL_DEV_PTR Pointer to MRVL_DEV
	 * @param[in] waitTime delay time
	 * @return: MRVL_APHY_STATUS
	 */
	WAIT_FUNC wait;
};


#endif
