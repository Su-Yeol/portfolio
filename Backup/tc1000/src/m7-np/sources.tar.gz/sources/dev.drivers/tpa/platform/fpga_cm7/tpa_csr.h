#ifndef TPA_CSR_H_
#define TPA_CSR_H_

extern void set_tpa_csr(void);

#endif //TPA_CSR_H_
