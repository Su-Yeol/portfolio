// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
 * @File
 * @Title        fp_app_pci.c
 * @Copyright    Copyright (c) Imagination Technologies Ltd. All Rights Reserved
 * @Description  interface routines between Host module and PE Engine
 * @License      Dual MIT/GPLv2
 *
 * The contents of this file are subject to the MIT license as set out below.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * the GNU General Public License Version 2 ("GPL") in which case the provisions
 * of GPL are applicable instead of those above.
 *
 * If you wish to allow use of your version of this file only under the terms of
 * GPL, and not to allow others to use your version of this file under the terms
 * of the MIT license, indicate your decision by deleting the provisions above
 * and replace them with the notice and other provisions required by GPL as set
 * out in the file called "GPL-COPYING" included in this distribution. If you do
 * not delete the provisions above,a recipient may use your version of this file
 * under the terms of either the MIT license or GPL.
 *
 * This License is also included in this distribution in the file called
 * "MIT-COPYING".
 *
 * EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 * PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                     Include Files
 **********************************************************************/
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/skbuff.h>
#include <linux/pci.h>

#include "fp_library.h"
#include "fp_types.h"
#include "fp_router.h"
#include "fp_ether.h"
#include "fp_macros.h"
#include "fp_poolalloc.h"
#include "fp_ip.h"
#include "fp_udp.h"
#include "fp_tcp.h"
#include "fp_interface.h"
#include "fp_global.h"
#include "fp_pci_pe.h"
//#ifdef FP_IPSEC
//#include "fp_sa.h"
//#endif

/**************************************************************************
 *            GLOBAL DECLARATIONS
 **************************************************************************
 */
/*Route  Hash Table Global variable */
struct fp_router_table *fp_router_hash_table = NULL;
//uint32  gpcimem_base;
//uint8 *getPciBaseAddr(void *dev);

/**********************************************************************
 * Function Name  : fp_convert_le2be_phyport_cfg
 * Description    : converting phyport little endian to bigendian
 * Inputs
 *   Parameters   : struct phyPort *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void fp_convert_le2be_phyport_cfg(struct phyPort *pPhyStruct)
{
	pPhyStruct->mediaType   = htons(pPhyStruct->mediaType);
	pPhyStruct->commonIfFlags   = htons(pPhyStruct->commonIfFlags);
}

/**********************************************************************
 * Function Name  : fp_download_phyports_cfg
 * Description    : loading phyPort data from host to PE Phyport
 * Inputs
 *   Parameters   : struct net_device *, struct phyPort *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void fp_download_phyports_cfg(struct net_device *dev, struct phyPort *phy_port)
{
#if 0
	uint8 phyno = 0;
	uint32a configLen = 0;
	uint32a offset = 0;

	phyno = phy_port->phyno;
	configLen = sizeof(struct phyPort);
	offset = ((DMEM_ADDR_PHY) + (configLen * phyno));
	fp_convert_le2be_phyport_cfg(phy_port);
	fp_convert_le2be((int8 *)phy_port, configLen);
	phy_port->ifPtr = (struct IfData *)
			PCI_TO_PED((DMEM_ADDR_IF) + (sizeof(struct IfData) *
			(phyno * MAX_LOGICAL_IFS)));
#ifdef DEBUG_HOST
	pr_info("Ifptr: %p\n", phy_port->ifPtr);
#endif
	load_hwinit_config(dev, (DSP_RAM + offset), (uint32a *)phy_port,
							(configLen >> 2));
#endif
}


/**********************************************************************
 * Function Name  : fp_convert_le2be_ifcfg
 * Description    : converting ifData little endian to bigendian
 * Inputs
 *   Parameters   : struct IfData *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void fp_convert_le2be_ifcfg(struct IfData *pIfStruct)
{
	pIfStruct->ifMatchFlags = htons(pIfStruct->ifMatchFlags);
	pIfStruct->vlan		= htons(pIfStruct->vlan);
	pIfStruct->inSessid	= htons(pIfStruct->inSessid);
	pIfStruct->ipaddr	= htonl(pIfStruct->ipaddr);
	/* pIfStruct->vpvc[0]		= htons(pIfStruct->vpvc[0]);
	 * pIfStruct->ethTypes[0]	= htons(pIfStruct->ethTypes[0]);
	 * pIfStruct->ethTypes[1]	= htons(pIfStruct->ethTypes[1]);
	 * pIfStruct->ethTypes[2]	= htons(pIfStruct->ethTypes[2]);
	 * pIfStruct->ethTypes[3]	= htons(pIfStruct->ethTypes[3]);
	 * pIfStruct->gemId	= htons(pIfStruct->gemId);
	 * pIfStruct->rtv4Hash	= htons(pIfStruct->rtv4Hash);
	 * pIfStruct->rtv6Hash	= htons(pIfStruct->rtv6Hash);
	 * pIfStruct->brHash	= htons(pIfStruct->brHash);
	 * pIfStruct->outSessid	= htons(pIfStruct->outSessid);
	 */
}


/**********************************************************************
 * Function Name  : fp_download_logif_cfg
 * Description    : loading ifData from host to PE interface port
 * Inputs
 *   Parameters   : struct net_device *, struct IfData *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void fp_download_logif_cfg(struct net_device *dev, struct IfData *if_data)
{
#if 0
	uint8 phyno, ifnum;
	/* length of the config data need to be updated */
	uint32a configLen;
	/* offset address from the respecitive base address */
	uint32a offset;
	struct phyPort phy_port;

	phyno = if_data->phyPort;
	ifnum = if_data->ifNum;
	configLen = sizeof(struct IfData);
#ifdef DEBUG_HOST
	pr_info("INTF configlen:%x\n", configLen);
#endif
	offset = (DMEM_ADDR_IF + (configLen *
		((phyno * MAX_LOGICAL_IFS) + ifnum)));
#ifdef DEBUG_HOST
	pr_info("\n CONFIG IF OFFSET:%x ", offset);
#endif
	fp_convert_le2be_ifcfg(if_data);
	fp_convert_le2be((int8 *)if_data, configLen);
	if_data->fp_if_stats = NULL;
	if_data->rtv4Table = (void *)PCI_TO_PED(PE_CONFIG_RTABLE_ADDR);
	load_hwinit_config(dev, (DSP_RAM + offset), (uint32a *)if_data,
							(configLen >> 2));
	/* update phyport for current logical interfaces */
	memset((int8 *)&phy_port, 0, sizeof(struct phyPort));
	memcpy((void *)&phy_port, (void *)&gPhyPorts[phyno],
						sizeof(struct phyPort));
	fp_download_phyports_cfg(dev, &phy_port);
#endif
}
/**********************************************************************
 * Function Name  : fp_upd_pci_baseaddr
 * Description    : Intialize pci base addr & initialize ddr tables
 * Inputs
 *   Parameters   : struct net_device *, struct IfData *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
#if 0
void fp_upd_pci_baseaddr(struct net_device *dev)
{
	uint8 *pciAddr;

	pciAddr = getPciBaseAddr(dev);
	gpcimem_base = ((uint32)pciAddr);
	fp_pci_ddr_tbl_init(pciAddr);
}
#endif

#if 0
#ifdef FP_IPSEC
/**********************************************************************
 * Function Name  : fp_download_ipsecsa_table_cfg
 * Description    : loading sa table data from host into PE mem
 * Inputs
 *   Parameters   : struct net_device *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void fp_download_ipsec_sa_table_cfg(struct net_device *dev)
{
#if 0
	uint32a configLen;
	uint32a offset;/* offset address in device's PCI space */
	struct fp_ipsec_sa_table *phash_table = &fp_ipsec_sa_static_hash_table;
	/* loading pptp table info */
	phash_table->table = (struct fp_sa **)PCI_TO_PEL(
					(uint32)phash_table->table);
	configLen = sizeof(struct fp_ipsec_sa_table);
	configLen >>= 2;  /*convert into no.of integers*/
	offset = PE_CONFIG_IPSEC_SA_TABLE_ADDR;
	load_hwinit_config(dev, (DSP_RAM + offset),
					(uint32a *)phash_table, configLen);
	phash_table->table = (struct fp_sa **)PEL_TO_PCI(
					(uint32)phash_table->table);
#endif
}
#endif
#endif

/**********************************************************************
 * Function Name  : fp_download_phyports_cfg
 * Description    : loading phyPort data from host to PE Phyport
 * Inputs
 *   Parameters   : struct net_device *, struct phyPort *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void fp_download_rttable_cfg(struct net_device *dev)
{
#if 0
	uint32a configLen;
	uint32a offset;      /* offset address in device's PCI space */
#ifdef DEBUG_HOST
	pr_info("\n fp_router_hash_table.table :0x%x ",
						fp_router_hash_table->table);
#endif
	fp_router_hash_table->table =
		(struct cacheFlow **)((uint32)PCI_TO_PEL((uint32a)
				((uint32)fp_router_hash_table->table)));
	/*convert from PCI address to PE address*/
	configLen = sizeof(struct fp_router_table);
	configLen >>= 2;  /*convert into no.of integers*/
	offset = PE_CONFIG_RTABLE_ADDR;
	load_hwinit_config(dev, (DSP_RAM + offset),
				(uint32a *)fp_router_hash_table, configLen);
	fp_router_hash_table->table = (struct cacheFlow **)
				((uint32)PEL_TO_PCI((uint32)
					fp_router_hash_table->table));
#ifdef DEBUG_HOST
	pr_info("\n fp_router_hash_table.table PE-TO-PCI:0x%x ",
			fp_router_hash_table->table);
#endif
#endif
}
void fp_download_pe_cfg(struct net_device *dev)
{
#if 0
	struct IfData if_data;
	struct phyPort phy_port;
	int32a port = 0;
#ifdef DEBUG_HW2
	/*
	 *printk("\n\n");
	 *fp_print_phyports_cfg(dev);
	 *printk("\n\n");
	 *fp_print_logif_cfg(dev);
	 *printk("\n\n");
	 *fp_print_rttable_cfg(dev);
	 *printk("\n\n");
	 *fp_print_brtable_cfg(dev);
	 */
#endif
	memset((uint8 *)&if_data, 0, sizeof(struct IfData));
	memset((uint8 *)&phy_port, 0, sizeof(struct phyPort));
	for (port = 0; port < FP_MAX_PORTS; port++) {
		/*Load Physical ports information to Firmware*/
		memcpy((void *)&phy_port, (void *)&gPhyPorts[port],
						sizeof(struct phyPort));
		fp_download_phyports_cfg(dev, &phy_port);
		/*Load Interface ports information to Firmware*/
		memcpy((void *)&if_data, (void *)&gIfPorts[port][0],
						sizeof(struct IfData));
		fp_download_logif_cfg(dev, &if_data);
	}
	/*Load Route table information to Firmware*/
	fp_download_rttable_cfg(dev);
#ifdef FP_IPSEC
	fp_download_ipsec_sa_table_cfg(dev);
#endif
#ifdef NPU_HOST_BRIDGE_SUPPORT
	/*Load Bridge table information to Firmware*/
	fp_download_brtable_cfg(dev);
#endif
#endif
}
