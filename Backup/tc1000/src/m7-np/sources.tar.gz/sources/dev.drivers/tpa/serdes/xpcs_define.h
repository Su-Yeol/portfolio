
typedef unsigned int    uint;


//#define HwNETSS             0x46000000
#define HwNETSS             0x0
#define HwXPCS1             ((volatile uint         *)(HwNETSS + 0x000000))
#define HwXPCS1_PMA_MMD     ((volatile PMA_MMD      *)(HwNETSS + 0x010000))
#define HwXPCS1_XS_PMA_MMD  ((volatile XS_PMA_MMD   *)(HwNETSS + 0x020080))
#define HwXPCS1_XS_PCS_MMD  ((volatile XS_PCS_MMD   *)(HwNETSS + 0x040000))
#define HwXPCS1_VS_MMD1     ((volatile VS_MMD1      *)(HwNETSS + 0x080000))
#define HwXPCS1_SR_MII_MMD  ((volatile SR_MII_MMD   *)(HwNETSS + 0x0c0000))
#define HwXPCS1_VR_MII_MMD  ((volatile VR_MII_MMD   *)(HwNETSS + 0x0e0000))
#define HwEPP               ((volatile uint         *)(HwNETSS + 0x200000))
#define HwGMAC1             ((volatile uint         *)(HwNETSS + 0x2d0000))
#define HwGMAC0             ((volatile uint         *)(HwNETSS + 0x2d4000))
#define HwXGMAC2p5G         ((volatile uint         *)(HwNETSS + 0x2d8000))
#define HwXGMAC5G           ((volatile uint         *)(HwNETSS + 0x4d0000))
#define HwXPCS0             ((volatile uint         *)(HwNETSS + 0xb00000))
#define HwXPCS0_PMA_MMD     ((volatile PMA_MMD      *)(HwNETSS + 0xb10000))
#define HwXPCS0_XS_PMA_MMD  ((volatile XS_PMA_MMD   *)(HwNETSS + 0xb20080))
#define HwXPCS0_XS_PCS_MMD  ((volatile XS_PCS_MMD   *)(HwNETSS + 0xb40000))
#define HwXPCS0_VS_MMD1     ((volatile VS_MMD1      *)(HwNETSS + 0xb80000))
#define HwXPCS0_SR_MII_MMD  ((volatile SR_MII_MMD   *)(HwNETSS + 0xbc0000))
#define HwXPCS0_VR_MII_MMD  ((volatile VR_MII_MMD   *)(HwNETSS + 0xbe0000))
#define HwTPACFG            ((volatile uint         *)(HwNETSS + 0xd30000))



//============================================================================================================================
// PMA_MMD : PMA MMD Standard (SR) and Vendor Specific REgister (VR) (Except SERDES register) address block{{{
//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
//--------------------------------------------------------------
// SR_PMA_CTRL1 : SR PMA MMD Control1 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    LB                      :  1;
    uint                            :  1;
    uint    SS_5_2                  :  4;
    uint    SS6                     :  1;
    uint                            :  4;
    uint    LPM                     :  1;
    uint                            :  1;
    uint    SS13                    :  1;
    uint                            :  1;
    uint    RST                     :  1;
    uint                            : 16;
} PMA_CTRL1;

typedef union {
    uint                            nReg;
    PMA_CTRL1                       bReg;
} PMA_CTRL1_U;
/*}}}*/
//--------------------------------------------------------------
// SR_PMA_CTRL2 : SR PMA MMD Control1 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    PMA_TYPE                :  6;
    uint                            : 10;
    uint                            : 16;
} PMA_CTRL2;

typedef union {
    uint                            nReg;
    PMA_CTRL2                       bReg;
} PMA_CTRL2_U;
/*}}}*/
//--------------------------------------------------------------
// SR_PMA_KR_CTRL : SR PMA or PMD KX Control Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    TOC                     :  1;
    uint                            : 15;
    uint                            : 16;
} KX_CTRL;

typedef union {
    uint                            nReg;
    KX_CTRL                         bReg;
} PMA_KX_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// SR_PMA_KX_STS : SR PMA or PMD KX Status Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    SD                      :  1;
    uint                            :  7;
    uint    PMA_TDA                 :  1;
    uint                            :  1;
    uint    RX_F                    :  1;
    uint    TX_F                    :  1;
    uint    RFA                     :  1;
    uint    TFA                     :  1;
    uint                            :  2;
    uint                            : 16;
} KX_STS;

typedef union {
    uint                            nReg;
    KX_STS                          bReg;
} PMA_KX_STS_U;
/*}}}*/
//--------------------------------------------------------------
// SR_PMA_DIG_CTRL1 : VR PMA MMD Digital Control1 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    CL72_AUTO               :  1;
    uint    BYP_PWRUP               :  1;
    uint                            :  2;
    uint    DTXLANED_0              :  1;
    uint    DTXLANED_3_1            :  3;
    uint                            :  3;
    uint    PWRSV                   :  1;
    uint                            :  3;
    uint    VR_RST                  :  1;
    uint                            : 16;
} DIG_CTRL1;

typedef union {
    uint                            nReg;
    DIG_CTRL1                       bReg;
} PMA_DIG_CTRL1_U;
/*}}}*/
//--------------------------------------------------------------
// SR_PMA_DIG_STS : VR PMA MMD Digital Status Register{{{
//--------------------------------------------------------------
typedef struct {
    uint                            :  1;
    uint    LB_ACTIVE               :  1;
    uint    PSEQ_STATE              :  3;
    uint                            : 11;
    uint                            : 16;
} DIG_STS;

typedef union {
    uint                            nReg;
    DIG_STS                         bReg;
} PMA_DIG_STS_U;
/*}}}*/
//--------------------------------------------------------------
// PMA_MMD register bank structure
//--------------------------------------------------------------
typedef struct {
    PMA_CTRL1_U         uPMA_CTRL1                         ;// 0x10000
    uint                undef0[((0x1001c-0x10000)/4)-1]    ;// 0x11c40~0x1fffc
    PMA_CTRL2_U         uPMA_CTRL2                         ;// 0x1001c
    uint                undef1[((0x10280-0x1001c)/4)-1]    ;// 0x10020~0x1027c
    PMA_KX_CTRL_U       uPMA_KX_CTRL                       ;// 0x10280
    PMA_KX_STS_U        uPMA_KX_STS                        ;// 0x10284
    uint                undef2[((0x20000-0x10284)/4)-1]    ;// 0x11c40~0x1fffc
    PMA_DIG_CTRL1_U     uPMA_DIG_CTRL1                     ;// 0x20000
    uint                undef3[((0x20040-0x20000)/4)-1]    ;// 0x20004~0x2003c
    PMA_DIG_STS_U       uPMA_DIG_STS                       ;// 0x20040
} PMA_MMD;
/*}}}*/
//============================================================================================================================
// XS_PMA_MMD : SERDES Registers Address block{{{
//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
//--------------------------------------------------------------
// RX_LSTS : VR XS or PMA PHY Rx Lane Status Register{{{
//--------------------------------------------------------------
typedef struct {
    uint                            :  4;
    uint    SIG_DET_0               :  1;
    uint    SIG_DET_3_1             :  3;
    uint    RX_PLL_STATE_0          :  1;
    uint    RX_PLL_STATE_3_1        :  3;
    uint    RX_VALID_0              :  1;
    uint    RX_VALID_3_1            :  3;
    uint                            : 16;
} RX_LSTS;

typedef union {
    uint                            nReg;
    RX_LSTS                         bReg;
} XS_PMA_RX_LSTS_U;
/*}}}*/
//--------------------------------------------------------------
// TX_GENCTRL0 : PHY Tx General-0 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    TX_BCN_EN_0             :  1;
    uint    TX_BCN_EN_3_1           :  3;
    uint    TX_INV_0                :  1;
    uint    TX_INV_3_1              :  3;
    uint    TX_RST_0                :  1;
    uint    TX_RST_3_1              :  3;
    uint    TX_DT_EN_0              :  1;
    uint    TX_DT_EN_3_1            :  3;
    uint                            : 16;
} TX_GENCTRL0;

typedef union {
  uint                              nReg;
  TX_GENCTRL0                       bReg;
} XS_PMA_TX_GENCTRL0_U;
/*}}}*/
//--------------------------------------------------------------
// TX_GENCTRL1 : PHY Tx General-1 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    DET_RX_REQ_0            :  1;
    uint    DET_RX_REQ_3_1          :  3;
    uint    VBOOST_EN_0             :  1;
    uint    VBOOST_EN_3_1           :  3;
    uint    VBOOST_LVL              :  3;
    uint                            :  1;
    uint    TX_CLK_RDY_0            :  1;
    uint    TX_CLK_RDY_3_1          :  3;
    uint                            : 16;
} TX_GENCTRL1;

typedef union {
    uint                            nReg;
    TX_GENCTRL1                     bReg;
} XS_PMA_TX_GENCTRL1_U;
/*}}}*/
//--------------------------------------------------------------
// TX_GENCTRL2 : PHY Tx General-2 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    TX_REQ_0                :  1;
    uint    TX_REQ_3_1              :  3;
    uint    TX_LPD_0                :  1;
    uint    TX_LPD_3_1              :  3;
    uint    TX0_WIDTH               :  2;
    uint    TX1_WIDTH               :  2;
    uint    TX2_WIDTH               :  2;
    uint    TX3_WIDTH               :  2;
    uint                            : 16;
} TX_GENCTRL2;

typedef union {
    uint                            nReg;
    TX_GENCTRL2                     bReg;
} XS_PMA_TX_GENCTRL2_U;
/*}}}*/
//--------------------------------------------------------------
// TX_BOOST_CTRL : PHY Tx Boost Control Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    TX0_IBOOST              :  4;
    uint    TX1_IBOOST              :  4;
    uint    TX2_IBOOST              :  4;
    uint    TX3_IBOOST              :  4;
    uint                            : 16;
} TX_BOOST_CTRL;

typedef union {
    uint                            nReg;
    TX_BOOST_CTRL                   bReg;
} XS_PMA_TX_BOOST_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// TX_RATE_CTRL : PHY Tx Rate Control Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    TX0_RATE                :  3;
    uint                            :  1;
    uint    TX1_RATE                :  3;
    uint                            :  1;
    uint    TX2_RATE                :  3;
    uint                            :  1;
    uint    TX3_RATE                :  3;
    uint                            :  1;
    uint                            : 16;
} TX_RATE_CTRL;

typedef union {
    uint                            nReg;
    TX_RATE_CTRL                    bReg;
} XS_PMA_TX_RATE_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// TX_PWR_STS_CTRL : PHY Tx Power State Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    TX0_PSTATE              :  2;
    uint    TX1_PSTATE              :  2;
    uint    TX2_PSTATE              :  2;
    uint    TX3_PSTATE              :  2;
    uint    TX_DISABLE_0            :  1;
    uint    TX_DISABLE_3_1          :  3;
    uint                            :  4;
    uint                            : 16;
} TX_PWR_STS_CTRL;

typedef union {
    uint                            nReg;
    TX_PWR_STS_CTRL                 bReg;
} XS_PMA_TX_PWR_STS_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// TX_EQ_CTRL0 : PHY Tx Equalization Control 0 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    TX_EQ_PRE               :  6;
    uint                            :  2;
    uint    TX_EQ_MAIN              :  6;
    uint                            :  2;
    uint                            : 16;
} TX_EQ_CTRL0;

typedef union {
    uint                            nReg;
    TX_EQ_CTRL0                     bReg;
} XS_PMA_TX_EQ_CTRL0_U;
/*}}}*/
//--------------------------------------------------------------
// TX_EQ_CTRL1 : PHY Tx Equalization Control 1 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    TX_EQ_POST              :  6;
    uint    TX_EQ_OVR_RIDE          :  1;
    uint    TX_EQ_DEF_CTRL          :  1;
    uint    CA_TX_EQ                :  1;
    uint                            :  7;
    uint                            : 16;
} TX_EQ_CTRL1;

typedef union {
    uint                            nReg;
    TX_EQ_CTRL1                     bReg;
} XS_PMA_TX_EQ_CTRL1_U;
/*}}}*/
//--------------------------------------------------------------
// TX_GENCTRL3 : PHY TX General Control 3 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    TXUP_TERM_OFFSET        :  9;
    uint                            :  7;
    uint                            : 16;
} TX_GENCTRL3;

typedef union {
    uint                            nReg;
    TX_GENCTRL3                     bReg;
} XS_PMA_TX_GENCTRL3_U;
/*}}}*/
//--------------------------------------------------------------
// TX_GENCTRL4 : PHY TX General Control 4 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    TXDN_TERM_OFFSET        :  9;
    uint                            :  7;
    uint                            : 16;
} TX_GENCTRL4;

typedef union {
    uint                            nReg;
    TX_GENCTRL4                     bReg;
} XS_PMA_TX_GENCTRL4_U;
/*}}}*/
//--------------------------------------------------------------
// TX_MISC_CTRL0 : PHY TX Miscellaneous Control 0 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    TX0_MISC                :  8;
    uint    TX1_MISC                :  8;
    uint                            : 16;
} TX_MISC_CTRL0;

typedef union {
    uint                            nReg;
    TX_MISC_CTRL0                   bReg;
} XS_PMA_TX_MISC_CTRL0_U;
/*}}}*/
//--------------------------------------------------------------
// TX_STS : PHY Tx Status Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    TX_ACK_0                :  1;
    uint    TX_ACK_3_1              :  3;
    uint    DETRX_RSLT_0            :  1;
    uint    DETRX_RSLT_3_1          :  3;
    uint                            :  8;
    uint                            : 16;
} TX_STS;

typedef union {
    uint                            nReg;
    TX_STS                          bReg;
} XS_PMA_TX_STS_U;
/*}}}*/
//--------------------------------------------------------------
// RX_GENCTRL0 : PHY Rx General Control 0 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    RX_TERM_EN_0            :  1;
    uint    RX_TERM_EN_3_1          :  3;
    uint    RX_ALIGN_EN_0           :  1;
    uint    RX_ALIGN_EN_3_1         :  3;
    uint    RX_DT_EN_0              :  1;
    uint    RX_DT_EN_3_1            :  3;
    uint    RX_CLKSFT_0             :  1;
    uint    RX_CLKSFT_3_1           :  3;
    uint                            : 16;
} RX_GENCTRL0;

typedef union {
    uint                            nReg;
    RX_GENCTRL0                     bReg;
} XS_PMA_RX_GENCTRL0_U;
/*}}}*/
//--------------------------------------------------------------
// RX_GENCTRL1 : PHY Rx General Control 1 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    RX_INV_0                :  1;
    uint    RX_INV_3_1              :  3;
    uint    RX_RST_0                :  1;
    uint    RX_RST_3_1              :  3;
    uint    RX_TERM_ACDC_0          :  1;
    uint    RX_TERM_ACDC_3_1        :  3;
    uint    RX_DIV16P5_CLK_EN_0     :  1;
    uint    RX_DIV16P5_CLK_EN_3_1   :  3;
    uint                            : 16;
} RX_GENCTRL1;

typedef union {
    uint                            nReg;
    RX_GENCTRL1                     bReg;
} XS_PMA_RX_GENCTRL1_U;
/*}}}*/
//--------------------------------------------------------------
// RX_GENCTRL2 : Rx General Control 2 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    RX_REQ_0                :  1;
    uint    RX_REQ_3_1              :  3;
    uint    RX_LPD_0                :  1;
    uint    RX_LPD_3_1              :  3;
    uint    RX_WIDTH_0              :  2;
    uint    RX_WIDTH_1              :  2;
    uint    RX_WIDTH_2              :  2;
    uint    RX_WIDTH_3              :  2;
    uint                            : 16;
} RX_GENCTRL2;

typedef union {
    uint                            nReg;
    RX_GENCTRL2                     bReg;
} XS_PMA_RX_GENCTRL2_U;
/*}}}*/
//--------------------------------------------------------------
// RX_GENCTRL3 : Rx General Control 3 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    RX_TRSHLD_0             :  3;
    uint    RX_TRSHLD_1             :  3;
    uint    RX_TRSHLD_2             :  3;
    uint    RX_TRSHLD_3             :  3;
    uint    RX_LFPS_EN_0            :  1;
    uint    RX_LFPS_EN_3_1          :  3;
    uint                            : 16;
} RX_GENCTRL3;

typedef union {
    uint                            nReg;
    RX_GENCTRL3                     bReg;
} XS_PMA_RX_GENCTRL3_U;
/*}}}*/
//--------------------------------------------------------------
// RX_RATE_CTRL : PHY Rx Rate Control Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    RX0_RATE                :  2;
    uint                            :  1;
    uint                            :  1;
    uint    RX1_RATE                :  2;
    uint                            :  1;
    uint                            :  1;
    uint    RX2_RATE                :  2;
    uint                            :  1;
    uint                            :  1;
    uint    RX3_RATE                :  2;
    uint                            :  1;
    uint                            :  1;
    uint                            : 16;
} RX_RATE_CTRL;

typedef union {
    uint                            nReg;
    RX_RATE_CTRL                    bReg;
} XS_PMA_RX_RATE_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// RX_PWR_STS_CTRL : PHY Rx Power State Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    RX0_PSTATE              :  2;
    uint    RX1_PSTATE              :  2;
    uint    RX2_PSTATE              :  2;
    uint    RX3_PSTATE              :  2;
    uint    RX_DISABLE_0            :  1;
    uint    RX_DISABLE_3_1          :  3;
    uint    EEE_OVR_RIDE            :  1;
    uint                            :  3;
    uint                            : 16;
} RX_PWR_STS_CTRL;

typedef union {
    uint                            nReg;
    RX_PWR_STS_CTRL                 bReg;
} XS_PMA_RX_PWR_STS_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// RX_CDR_CTRL : PHY Rx CDR Control Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    CDR_TRACK_EN_0          :  1;
    uint    CDR_TRACK_EN_3_1        :  3;
    uint    CDR_SSC_EN_0            :  1;
    uint    CDR_SSC_EN_3_1          :  3;
    uint    VCO_LOW_FREQ_0          :  1;
    uint    VCO_LOW_FREQ_3_1        :  3;
    uint                            :  4;
    uint                            : 16;
} RX_CDR_CTRL;

typedef union {
    uint                            nReg;
    RX_CDR_CTRL                     bReg;
} XS_PMA_RX_CDR_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// RX_ATTN_CTRL : PHY Rx Attenuation Control Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    RX0_EQ_ATT_LVL          :  3;
    uint                            :  1;
    uint    RX1_EQ_ATT_LVL          :  3;
    uint                            :  1;
    uint    RX2_EQ_ATT_LVL          :  3;
    uint                            :  1;
    uint    RX3_EQ_ATT_LVL          :  3;
    uint                            :  1;
    uint                            : 16;
} RX_ATTN_CTRL;

typedef union {
    uint                            nReg;
    RX_ATTN_CTRL                    bReg;
} XS_PMA_RX_ATTN_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// RX_EQ_CTRL0 : PHY Rx Equalization Control 0 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    CTLE_BOOST_0            :  5;
    uint    CTLE_POLE_0             :  2;
    uint                            :  1;
    uint    VGA2_GAIN_0             :  3;
    uint                            :  1;
    uint    VGA1_GAIN_0             :  3;
    uint                            :  1;
    uint                            : 16;
} RX_EQ_CTRL0;

typedef union {
    uint                            nReg;
    RX_EQ_CTRL0                     bReg;
} XS_PMA_RX_EQ_CTRL0_U;
/*}}}*/
//--------------------------------------------------------------
// RX_EQ_CTRL4 : PHY Rx Equalization Control 4 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    CONT_ADAPT_0            :  1;
    uint    CONT_ADAPT_3_1          :  3;
    uint    CONT_OFF_CAN_0          :  1;
    uint    CONT_OFF_CAN_3_1        :  3;
    uint    SEQ_EQ_EN               :  1;
    uint    PING_PONG_EN            :  1;
    uint    SELF_MAIN_EN            :  1;
    uint    RX_EQ_STRT_CTRL         :  1;
    uint    RX_AD_REQ               :  1;
    uint                            :  3;
    uint                            : 16;
} RX_EQ_CTRL4;

typedef union {
    uint                            nReg;
    RX_EQ_CTRL4                     bReg;
} XS_PMA_RX_EQ_CTRL4_U;
/*}}}*/
//--------------------------------------------------------------
// RX_EQ_CTRL5 : PHY Rx Equalization Control 5 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    RX_ADPT_SEL_0           :  1;
    uint    RX_ADPT_SEL_3_1         :  3;
    uint    RX0_ADPT_MODE           :  2;
    uint    RX1_ADPT_MODE           :  2;
    uint    RX2_ADPT_MODE           :  2;
    uint    RX3_ADPT_MODE           :  2;
    uint    RX_AD_PROG_0            :  1;
    uint    RX_AD_PROG_3_1          :  3;
    uint                            : 16;
} RX_EQ_CTRL5;

typedef union {
    uint                            nReg;
    RX_EQ_CTRL5                     bReg;
} XS_PMA_RX_EQ_CTRL5_U;
/*}}}*/
//--------------------------------------------------------------
// DFE_TAP_CTRL0 : PHY DFE Tap Control 0 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    DFE_TAP1_0              :  8;
    uint    DFE_TAP1_1              :  8;
    uint                            : 16;
} DFE_TAP_CTRL0;

typedef union {
    uint                            nReg;
    DFE_TAP_CTRL0                   bReg;
} XS_PMA_DFE_TAP_CTRL0_U;
/*}}}*/
//--------------------------------------------------------------
// RX_STS : PHY Rx Status Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    RX_ACK_0                :  1;
    uint    RX_ACK_3_1              :  3;
    uint    LF_SD_0                 :  1;
    uint    LF_SD_3_1               :  3;
    uint    HF_SD_0                 :  1;
    uint    HF_SD_3_1               :  3;
    uint                            :  4;
    uint                            : 16;
} RX_STS;

typedef union {
    uint                            nReg;
    RX_STS                          bReg;
} XS_PMA_RX_STS_U;
/*}}}*/
//--------------------------------------------------------------
// RX_PPM_STS0 : PHY Rx PPM Status 0 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    RX0_PPM_DRIFT           :  6;
    uint                            :  1;
    uint    RX0_PPM_DRIFT_VLD       :  1;
    uint    RX1_PPM_DRIFT           :  6;
    uint                            :  1;
    uint    RX1_PPM_DRIFT_VLD       :  1;
    uint                            : 16;
} RX_PPM_STS0;

typedef union {
    uint                            nReg;
    RX_PPM_STS0                     bReg;
} XS_PMA_RX_PPM_STS0_U;
/*}}}*/
//--------------------------------------------------------------
// RX_CDR_CTRL1 : PHY Rx CDR Control1 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    VCO_TEMP_COMP_EN_0      :  1;
    uint    VCO_TEMP_COMP_EN_3_1    :  3;
    uint    VCO_STEP_CTRL_0         :  1;
    uint    VCO_STEP_CTRL_3_1       :  3;
    uint    VCO_FRQBAND_0           :  2;
    uint    VCO_FRQBAND_1           :  2;
    uint    VCO_FRQBAND_2           :  2;
    uint    VCO_FRQBAND_3           :  2;
    uint                            : 16;
} RX_CDR_CTRL1;

typedef union {
    uint                            nReg;
    RX_CDR_CTRL1                    bReg;
} XS_PMA_RX_CDR_CTRL1_U;
/*}}}*/
//--------------------------------------------------------------
// RX_PPM_CTRL0 : PHY Rx PPM Control 0 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    RX0_CDR_PPM_MAX         :  5;
    uint                            :  3;
    uint    RX1_CDR_PPM_MAX         :  5;
    uint                            :  3;
    uint                            : 16;
} RX_PPM_CTRL0;

typedef union {
    uint                            nReg;
    RX_PPM_CTRL0                    bReg;
} XS_PMA_RX_PPM_CTRL0_U;
/*}}}*/
//--------------------------------------------------------------
// RX_GENCTRL4 : PHY Rx General Control 4 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    RX_TERM_OFFSET          :  5;
    uint                            :  3;
    uint    RX_DFE_BYP_0            :  1;
    uint    RX_DFE_BYP_3_1          :  3;
    uint    RX_125MHZ_CLK_EN_0      :  1;
    uint    RX_125MHZ_CLK_EN_3_1    :  3;
    uint                            : 16;
} RX_GENCTRL4;

typedef union {
    uint                            nReg;
    RX_GENCTRL4                     bReg;
} XS_PMA_RX_GENCTRL4_U;
/*}}}*/
//--------------------------------------------------------------
// RX_MISC_CTRL0 : PHY RX Miscellaneous Control 0 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    RX0_MISC                :  8;
    uint    RX1_MISC                :  8;
    uint                            : 16;
} RX_MISC_CTRL0;

typedef union {
    uint                            nReg;
    RX_MISC_CTRL0                   bReg;
} XS_PMA_RX_MISC_CTRL0_U;
/*}}}*/
//--------------------------------------------------------------
// RX_IQ_CTRL0 : PHY RX IQ Control 0 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    RX0_MARGIN_IQ           :  7;
    uint                            :  1;
    uint    RX0_DELTA_IQ            :  4;
    uint                            :  4;
    uint                            : 16;
} RX_IQ_CTRL0;

typedef union {
    uint                            nReg;
    RX_IQ_CTRL0                     bReg;
} XS_PMA_RX_IQ_CTRL0_U;
/*}}}*/
//--------------------------------------------------------------
// MPLL_CMN_CTRL : PHY MPLL Common Control Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    MPLL_EN_0               :  1;
    uint    MPLL_EN_3_1             :  3;
    uint    MPLLB_SEL_0             :  1;
    uint    MPLLB_SEL_3_1           :  3;
    uint                            :  8;
    uint                            : 16;
} MPLL_CMN_CTRL;

typedef union {
    uint                            nReg;
    MPLL_CMN_CTRL                   bReg;
} XS_PMA_MPLL_CMN_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// MPLL_CTRL0 : PHY MPLLA/B Control-0 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    MPLL_MULTIPLIER         :  8;
    uint    MPLL_SSC_CLK_SEL        :  3;
    uint                            :  1;
    uint    FRAC_EN                 :  1;
    uint    FR_CFG_UP_EN            :  1;
    uint    PMIX_EN                 :  1;
    uint    MPLL_CAL_DISABLE        :  1;
    uint                            : 16;
} MPLL_CTRL0;

typedef union {
    uint                            nReg;
    MPLL_CTRL0                      bReg;
} XS_PMA_MPLL_CTRL0_U;
/*}}}*/
//--------------------------------------------------------------
// MPLL_CTRL1 : MPLLA/B Control-1 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    MPLL_SSC_EN             :  1;
    uint                            :  3;
    uint    MPLL_SSC_CLK_SEL        :  1;
    uint    MPLL_FRACN_CTRL         : 11;
    uint                            : 16;
} MPLL_CTRL1;

typedef union {
    uint                            nReg;
    MPLL_CTRL1                      bReg;
} XS_PMA_MPLL_CTRL1_U;
/*}}}*/
//--------------------------------------------------------------
// MPLL_CTRL2 : PHY MPLLA Control-2 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    MPLL_DIV_MULT           :  7;
    uint    MPLL_DIV_CLK_EN         :  1;
    uint    MPLL_DIV8_CLK_EN        :  1;
    uint    MPLL_DIV10_CLK_EN       :  1;
    uint    MPLL_DIV16P5_CLK_EN     :  1;
    uint    MPLL_TX_CLK_DIV         :  2;
    uint    MPLL_RECAL_BANK_SEL     :  2;
    uint    MPLL_WRD_DIV2_EN        :  1;
    uint                            : 16;
} MPLL_CTRL2;

typedef union {
    uint                            nReg;
    MPLL_CTRL2                      bReg;
} XS_PMA_MPLL_CTRL2_U;
/*}}}*/
//--------------------------------------------------------------
// MPLLB_CTRL2 : PHY MPLLB Control-2 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    MPLL_DIV_MULT           :  7;
    uint    MPLL_DIV_CLK_EN         :  1;
    uint    MPLL_DIV8_CLK_EN        :  1;
    uint    MPLL_DIV10_CLK_EN       :  1;
    uint                            :  1;
    uint    MPLL_TX_CLK_DIV         :  2;
    uint    MPLL_RECAL_BANK_SEL     :  2;
    uint                            :  1;
    uint                            : 16;
} MPLLB_CTRL2;

typedef union {
    uint                            nReg;
    MPLLB_CTRL2                     bReg;
} XS_PMA_MPLLB_CTRL2_U;
/*}}}*/
//--------------------------------------------------------------
// MPLL_CTRL3 : PHY MPLLA/B Control-3 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    MPLL_BANDWIDTH          : 16;
    uint                            : 16;
} MPLL_CTRL3;

typedef union {
    uint                            nReg;
    MPLL_CTRL3                      bReg;
} XS_PMA_MPLL_CTRL3_U;
/*}}}*/
//--------------------------------------------------------------
// MPLL_CTRL4 : PHY MPLLA/B Control-4 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    MPLL_SSC_FRQ_CNT_INT    : 12;
    uint                            :  4;
    uint                            : 16;
} MPLL_CTRL4;

typedef union {
    uint                            nReg;
    MPLL_CTRL4                      bReg;
} XS_PMA_MPLL_CTRL4_U;
/*}}}*/
//--------------------------------------------------------------
// MPLL_CTRL5 : PHY MPLLA/B Control-5 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    MPLL_SSC_FRQ_CNT_PK     :  8;
    uint    MPLL_SSC_SPD_EN         :  1;
    uint                            :  7;
    uint                            : 16;
} MPLL_CTRL5;

typedef union {
    uint                            nReg;
    MPLL_CTRL5                      bReg;
} XS_PMA_MPLL_CTRL5_U;
/*}}}*/
//--------------------------------------------------------------
// MISC_CTRL0 : PHY Miscellaneous Control 0 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    TX2RX_LB_EN_0           :  1;
    uint    TX2RX_LB_EN_3_1         :  3;
    uint    RX2TX_LB_EN_0           :  1;
    uint    RX2TX_LB_EN_3_1         :  3;
    uint    RX_VREF_CTRL            :  5;
    uint    RTUNE_REQ               :  1;
    uint    CR_PARA_SEL             :  1;
    uint    PLL_CTRL                :  1;
    uint                            : 16;
} MISC_CTRL0;

typedef union {
    uint                            nReg;
    MISC_CTRL0                      bReg;
} XS_PMA_MISC_CTRL0_U;
/*}}}*/
//--------------------------------------------------------------
// REF_CLK_CTRL : PHY Reference Control Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    REF_CLK_EN              :  1;
    uint    REF_USE_PAD             :  1;
    uint    REF_CLK_DIV2            :  1;
    uint    REF_RANGE               :  3;
    uint    REF_MPLLA_DIV2          :  1;
    uint    REF_MPLLB_DIV2          :  1;
    uint    REF_RPT_CLK_EN          :  1;
    uint    ALT_LP_CLK_SEL          :  1;
    uint    REF_MPLLA_DIV           :  3;
    uint    REF_MPLLB_DIV           :  3;
    uint                            : 16;
} REF_CLK_CTRL;

typedef union {
    uint                            nReg;
    REF_CLK_CTRL                    bReg;
} XS_PMA_REF_CLK_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// VCO_CAL_LD0 : PHY VCO Calibration Load 0 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    VCO_LD_VAL_0            : 13;
    uint                            :  3;
    uint                            : 16;
} VCO_CAL_LD0;

typedef union {
    uint                            nReg;
    VCO_CAL_LD0                     bReg;
} XS_PMA_VCO_CAL_LD0_U;
/*}}}*/
//--------------------------------------------------------------
// VCO_CAL_REF0 : PHY VCO Calibration Reference 0 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    VCO_REF_LD_0            :  7;
    uint                            :  1;
    uint    VCO_REF_LD_1            :  7;
    uint                            :  1;
    uint                            : 16;
} VCO_CAL_REF0;

typedef union {
    uint                            nReg;
    VCO_CAL_REF0                    bReg;
} XS_PMA_VCO_CAL_REF0_U;
/*}}}*/
//--------------------------------------------------------------
// MISC_STS : PHY Miscellaneous Status Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    FOM                     :  8;
    uint    RTUNE_ACK               :  1;
    uint    MPLLA_STS               :  1;
    uint    MPLLB_STS               :  1;
    uint    REF_CLKDET_RESULT       :  1;
    uint    RX_ADPT_ACK             :  1;
    uint                            :  3;
    uint                            : 16;
} MISC_STS;

typedef union {
    uint                            nReg;
    MISC_STS                        bReg;
} XS_PMA_MISC_STS_U;
/*}}}*/
//--------------------------------------------------------------
// MISC_CTRL1 : PHY Miscellaneous Control 1 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    RX_LNK_UP_TIME          : 16;
    uint                            : 16;
} MISC_CTRL1;

typedef union {
    uint                            nReg;
    MISC_CTRL1                      bReg;
} XS_PMA_MISC_CTRL1_U;
/*}}}*/
//--------------------------------------------------------------
// SRAM : PHY SRAM Register. Note: This is a special register...{{{
//--------------------------------------------------------------
typedef struct {
    uint    INIT_DN                 :  1;
    uint    EXT_LD_DONE             :  1;
    uint    BTLD_BYP                :  1;
    uint                            :  1;
    uint                            : 12;
    uint                            : 16;
} SRAM;

typedef union {
    uint                            nReg;
    SRAM                            bReg;
} XS_PMA_SRAM_U;
/*}}}*/
//--------------------------------------------------------------
// MISC_CTRL2 : PHY Miscellaneous Control 2 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    SUP_MISC                :  8;
    uint    REF_CLK_DET_EN          :  1;
    uint                            :  7;
    uint                            : 16;
} MISC_CTRL2;

typedef union {
    uint                            nReg;
    MISC_CTRL2                      bReg;
} XS_PMA_MISC_CTRL2_U;
/*}}}*/
//--------------------------------------------------------------
// SNPS_CR_CTRL : PHY CR Control Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    START_BUSY              :  1;
    uint    WR_RDN                  :  1;
    uint                            : 14;
    uint                            : 16;
} SNPS_CR_CTRL;

typedef union {
    uint                            nReg;
    SNPS_CR_CTRL                    bReg;
} XS_PMA_SNPS_CR_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// SNPS_CR_ADDR : PHY CR Address Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    ADDR                    : 16;
    uint                            : 16;
} SNPS_CR_ADDR;

typedef union {
    uint                            nReg;
    SNPS_CR_ADDR                    bReg;
} XS_PMA_SNPS_CR_ADDR_U;
/*}}}*/
//--------------------------------------------------------------
// SNPS_CR_DATA : CR Data Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    DATA                    : 16;
    uint                            : 16;
} SNPS_CR_DATA;

typedef union {
    uint                            nReg;
    SNPS_CR_DATA                    bReg;
} XS_PMA_SNPS_CR_DATA_U;
/*}}}*/
//--------------------------------------------------------------
// XS_PMA_MMD register bank structure
//--------------------------------------------------------------
typedef struct {
  XS_PMA_RX_LSTS_U          uRX_LSTS                            ;// 0x20080
  uint                      undef_pma0[((0x00c0-0x0080)/4)-1]   ;// 0x20084~0x200bc
  XS_PMA_TX_GENCTRL0_U      uTX_GENCTRL0                        ;// 0x200c0
  XS_PMA_TX_GENCTRL1_U      uTX_GENCTRL1                        ;// 0x200c4
  XS_PMA_TX_GENCTRL2_U      uTX_GENCTRL2                        ;// 0x200c8
  XS_PMA_TX_BOOST_CTRL_U    uTX_BOOST_CTRL                      ;// 0x200cc
  XS_PMA_TX_RATE_CTRL_U     uTX_RATE_CTRL                       ;// 0x200d0
  XS_PMA_TX_PWR_STS_CTRL_U  uTX_PWR_STS_CTRL                    ;// 0x200d4
  XS_PMA_TX_EQ_CTRL0_U      uTX_EQ_CTRL0                        ;// 0x200d8
  XS_PMA_TX_EQ_CTRL1_U      uTX_EQ_CTRL1                        ;// 0x200dc
  uint                      undef_pma1[((0x00f0-0x00dc)/4)-1]   ;// 0x200e0~0x200ec
  XS_PMA_TX_GENCTRL3_U      uTX_GENCTRL3                        ;// 0x200f0
  XS_PMA_TX_GENCTRL4_U      uTX_GENCTRL4                        ;// 0x200f4
  XS_PMA_TX_MISC_CTRL0_U    uTX_MISC_CTRL0                      ;// 0x200f8
  uint                      undef_pma2[1]                       ;// 0x200fc
  XS_PMA_TX_STS_U           uTX_STS                             ;// 0x20100
  uint                      undef_pma3[((0x0140-0x0100)/4)-1]   ;// 0x20104~0x2013c
  XS_PMA_RX_GENCTRL0_U      uRX_GENCTRL0                        ;// 0x20140
  XS_PMA_RX_GENCTRL1_U      uRX_GENCTRL1                        ;// 0x20144
  XS_PMA_RX_GENCTRL2_U      uRX_GENCTRL2                        ;// 0x20148
  XS_PMA_RX_GENCTRL3_U      uRX_GENCTRL3                        ;// 0x2014c
  XS_PMA_RX_RATE_CTRL_U     uRX_RATE_CTRL                       ;// 0x20150
  XS_PMA_RX_PWR_STS_CTRL_U  uRX_PWR_STS_CTRL                    ;// 0x20154
  XS_PMA_RX_CDR_CTRL_U      uRX_CDR_CTRL                        ;// 0x20158
  XS_PMA_RX_ATTN_CTRL_U     uRX_ATTN_CTRL                       ;// 0x2015c
  XS_PMA_RX_EQ_CTRL0_U      uRX_EQ_CTRL0                        ;// 0x20160
  uint                      undef_pma4[3]                       ;// 0x20164~0x2016c
  XS_PMA_RX_EQ_CTRL4_U      uRX_EQ_CTRL4                        ;// 0x20170
  XS_PMA_RX_EQ_CTRL5_U      uRX_EQ_CTRL5                        ;// 0x20174
  XS_PMA_DFE_TAP_CTRL0_U    uDFE_TAP_CTRL0                      ;// 0x20178
  uint                      undef_pma5[1]                       ;// 0x2017c
  XS_PMA_RX_STS_U           uRX_STS                             ;// 0x20180
  XS_PMA_RX_PPM_STS0_U      uRX_PPM_STS0                        ;// 0x20184
  uint                      undef_pma6[((0x0190-0x0184)/4)-1]   ;// 0x20188~0x2018c
  XS_PMA_RX_CDR_CTRL1_U     uRX_CDR_CTRL1                       ;// 0x20190
  XS_PMA_RX_PPM_CTRL0_U     uRX_PPM_CTRL0                       ;// 0x20194
  uint                      undef_pma7[2]                       ;// 0x20198~0x2019c
  XS_PMA_RX_GENCTRL4_U      uRX_GENCTRL4                        ;// 0x201a0
  XS_PMA_RX_MISC_CTRL0_U    uRX_MISC_CTRL0                      ;// 0x201a4
  uint                      undef_pma8[1]                       ;// 0x201a8
  XS_PMA_RX_IQ_CTRL0_U      uRX_IQ_CTRL0                        ;// 0x201ac
  uint                      undef_pma9[4]                       ;// 0x201b0~0x201bc
  XS_PMA_MPLL_CMN_CTRL_U    uMPLL_CMN_CTRL                      ;// 0x201c0
  XS_PMA_MPLL_CTRL0_U       uMPLLA_CTRL0                        ;// 0x201c4
  XS_PMA_MPLL_CTRL1_U       uMPLLA_CTRL1                        ;// 0x201c8
  XS_PMA_MPLL_CTRL2_U       uMPLLA_CTRL2                        ;// 0x201cc
  XS_PMA_MPLL_CTRL0_U       uMPLLB_CTRL0                        ;// 0x201d0
  XS_PMA_MPLL_CTRL1_U       uMPLLB_CTRL1                        ;// 0x201d4
  XS_PMA_MPLLB_CTRL2_U      uMPLLB_CTRL2                        ;// 0x201d8
  XS_PMA_MPLL_CTRL3_U       uMPLLA_CTRL3                        ;// 0x201dc
  XS_PMA_MPLL_CTRL3_U       uMPLLB_CTRL3                        ;// 0x201e0
  XS_PMA_MPLL_CTRL4_U       uMPLLA_CTRL4                        ;// 0x201e4
  XS_PMA_MPLL_CTRL5_U       uMPLLA_CTRL5                        ;// 0x201e8
  XS_PMA_MPLL_CTRL4_U       uMPLLB_CTRL4                        ;// 0x201ec
  XS_PMA_MPLL_CTRL5_U       uMPLLB_CTRL5                        ;// 0x201f0
  uint                      undef_pma10[((0x0240-0x01f0)/4)-1]  ;// 0x201f4~0x2023c
  XS_PMA_MISC_CTRL0_U       uMISC_CTRL0                         ;// 0x20240
  XS_PMA_REF_CLK_CTRL_U     uREF_CLK_CTRL                       ;// 0x20244
  XS_PMA_VCO_CAL_LD0_U      uVCO_CAL_LD0                        ;// 0x20248
  uint                      undef_pma11[3]                      ;// 0x2024c~0x20254
  XS_PMA_VCO_CAL_REF0_U     uVCO_CAL_REF0                       ;// 0x20258
  uint                      undef_pma12[1]                      ;// 0x2025c
  XS_PMA_MISC_STS_U         uMISC_STS                           ;// 0x20260
  XS_PMA_MISC_CTRL1_U       uMISC_CTRL1                         ;// 0x20264
  uint                      undef_pma13[1]                      ;// 0x20268
  XS_PMA_SRAM_U             uSRAM                               ;// 0x2026c
  XS_PMA_MISC_CTRL2_U       uMISC_CTRL2                         ;// 0x20270
  uint                      undef_pma14[3]                      ;// 0x20274~0x2027c
  XS_PMA_SNPS_CR_CTRL_U     uSNPS_CR_CTRL                       ;// 0x20280
  XS_PMA_SNPS_CR_ADDR_U     uSNPS_CR_ADDR                       ;// 0x20284
  XS_PMA_SNPS_CR_DATA_U     uSNPS_CR_DATA                       ;// 0x20288
} XS_PMA_MMD;
/*}}}*/
//============================================================================================================================
// SX_PCS_MMD : PCS MMD /DTE XS MMD /PHY XS MMD Standard (SR) & Vendor Specific (VR) Registers address block{{{
//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
//--------------------------------------------------------------
// PCS_CTRL1 : PCS MMD Control1 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint                            :  2;
    uint    SS_5_2                  :  4;
    uint    SS6                     :  1;
    uint                            :  2;
    uint    XAUI_STOP               :  1;
    uint    CS_EN                   :  1;
    uint    LPM                     :  1;
    uint                            :  1;
    uint    SS13                    :  1;
    uint    LBE                     :  1;
    uint    RST                     :  1;
    uint                            : 16;
} PCS_CTRL1;

typedef union {
    uint                            nReg;
    PCS_CTRL1                       bReg;
} XS_PCS_CTRL1_U;
/*}}}*/
//--------------------------------------------------------------
// PCS_STS : PCS MMD Status1 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint                            :  1;
    uint    LPMS                    :  1;
    uint    RLU                     :  1;
    uint                            :  3;
    uint    CSC                     :  1;
    uint    FLT                     :  1;
    uint    RXLPII                  :  1;
    uint    TXLPII                  :  1;
    uint    RXLPIR                  :  1;
    uint    TXLPIR                  :  1;
    uint                            :  4;
    uint                            : 16;
} PCS_STS;

typedef union {
    uint                            nReg;
    PCS_STS                         bReg;
} XS_PCS_STS_U;
/*}}}*/
//--------------------------------------------------------------
// PCS_CTRL2 : PCS Control2 Register This register is applicable only for the PCS MMD.{{{
//--------------------------------------------------------------
typedef struct {
    uint    PCS_TYPE_SEL            :  4;
    uint                            : 12;
    uint                            : 16;
} PCS_CTRL2;

typedef union {
    uint                            nReg;
    PCS_CTRL2                       bReg;
} XS_PCS_CTRL2_U;
/*}}}*/
//--------------------------------------------------------------
// PCS_DIG_CTRL1 : PCS MMD Digital Control1 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    DSKBYP                  :  1;
    uint    BYP_PWRUP               :  1;
    uint    EN_2_5G_MODE            :  1;
    uint    CR_CJN                  :  1;
    uint    DTXLANED_0              :  1;
    uint    DTXLANED_3_1            :  3;
    uint    INIT                    :  1;
    uint    USXG_EN                 :  1;
    uint    USRA_RST                :  1;
    uint    PWRSV                   :  1;
    uint    CL37_BP                 :  1;
    uint    EN_VSMMD1               :  1;
    uint    R2TLBE                  :  1;
    uint    VR_RST                  :  1;
    uint                            : 16;
} PCS_DIG_CTRL1;

typedef union {
    uint                            nReg;
    PCS_DIG_CTRL1                   bReg;
} XS_PCS_DIG_CTRL1_U;
/*}}}*/
//--------------------------------------------------------------
// PCS_XAUI_CTRL : PCS MMD XAUI Mode Control Register This register is present only when the DWC_xpcs is configured for RXAUI{{{
//--------------------------------------------------------------
typedef struct {
    uint    XAUI_MODE               :  1;
    uint    MRVL_RXAUI              :  1;
    uint                            : 14;
    uint                            : 16;
} PCS_XAUI_CTRL;

typedef union {
    uint                            nReg;
    PCS_XAUI_CTRL                   bReg;
} XS_PCS_XAUI_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// PCS_DEBUG_CTRL : PCS MMD Debug Control Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    RESTAR_SYNC_0           :  1;
    uint    RESTAR_SYNC_3_1         :  3;
    uint    SUPRESS_LOS_DET         :  1;
    uint    SUPRESS_EEE_LOS_DET     :  1;
    uint    RX_DT_EN_CTL            :  1;
    uint    RX_SYNC_CTL             :  1;
    uint    TX_PMBL_CTL             :  1;
    uint    RX_PMBL_CTL             :  1;
    uint    SS_CORE_EN              :  1;
    uint                            :  2;
    uint                            :  3;
    uint                            : 16;
} PCS_DEBUG_CTRL;

typedef union {
    uint                            nReg;
    PCS_DEBUG_CTRL                  bReg;
} XS_PCS_DEBUG_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// PCS_KR_CTRL : PCS 10GBASE-R Control Register This register is present only with the PCS MMD in the following configurations{{{
//--------------------------------------------------------------
typedef struct {
    uint    VR_TP_EN                :  1;
    uint    PR_DATA                 :  3;
    uint    NVAL_SEL                :  3;
    uint    PRBS9RXEN               :  1;
    uint    DIS_SCR                 :  1;
    uint    DIS_DESCR               :  1;
    uint    USXG_MODE               :  3;
    uint    USXG_2PT5G_GMII         :  1;
    uint    CSTM_AMLK               :  1;
    uint                            :  1;
    uint                            : 16;
} PCS_KR_CTRL;

typedef union {
    uint                            nReg;
    PCS_KR_CTRL                     bReg;
} XS_PCS_KR_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// PCS_DIG_STS : PCS MMD Digital Status Register{{{
//--------------------------------------------------------------
typedef struct {
    uint                            :  1;
    uint    LB_ACTIVE               :  1;
    uint    PSEQ_STATE              :  3;
    uint    RXFIFO_UNDF             :  1;
    uint    RXFIFO_OVF              :  1;
    uint    INV_XGM_SOP             :  1;
    uint    INV_XGM_T               :  1;
    uint    INV_XGM_CHAR            :  1;
    uint    LRX_STATE               :  3;
    uint    LTX_STATE               :  3;
    uint                            : 16;
} PCS_DIG_STS;

typedef union {
    uint                            nReg;
    PCS_DIG_STS                     bReg;
} XS_PCS_DIG_STS_U;
/*}}}*/
//--------------------------------------------------------------
// PCS_SFTY_TMR_CTRL : PCS MMD Safety Timer Control Register {{{
//--------------------------------------------------------------
typedef struct {
    uint    SFTY_1US_MULT           :  8;
    uint    RXFPEI                  :  1;
    uint                            :  1;
    uint    FSM_TO_SEL              :  2;
    uint                            :  4;
    uint                            : 16;
} PCS_SFTY_TMR_CTRL;

typedef union {
    uint                            nReg;
    PCS_SFTY_TMR_CTRL               bReg;
} XS_PCS_SFTY_TMR_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// SX_PCS_MMD register bank structure
//--------------------------------------------------------------
typedef struct {
  XS_PCS_CTRL1_U            uCTRL1                                  ;// 0x40000
  XS_PCS_STS_U              uPCS_STS                                ;// 0x40004
  uint                      undef_pcs0[((0x4001c-0x40004)/4)-1]     ;// 0x40008~0x40018
  XS_PCS_CTRL2_U            uCTRL2                                  ;// 0x4001c
  uint                      undef_pcs1[((0x60000-0x4001c)/4)-1]     ;// 0x40020~0x5fffC
  XS_PCS_DIG_CTRL1_U        uDIG_CTRL1                              ;// 0x60000
  uint                      undef_pcs2[((0x60010-0x60000)/4)-1]     ;// 0x60004~0x6000C
  XS_PCS_XAUI_CTRL_U        uXAUI_CTRL                              ;// 0x60010
  XS_PCS_DEBUG_CTRL_U       uDEBUG_CTRL                             ;// 0x60014
  uint                      undef_pcs3[1]                           ;// 0x60018
  XS_PCS_KR_CTRL_U          uKR_CTRL                                ;// 0x6001c
  uint                      undef_pcs4[8]                           ;// 0x60020~0x6003c
  XS_PCS_DIG_STS_U          uDIG_STS                                ;// 0x60040
  uint                      undef_pcs5[((0x603d4-0x60040)/4)-1]     ;// 0x60044~0x6003d
  XS_PCS_SFTY_TMR_CTRL_U    uSFTY_TMR_CTRL                          ;// 0x603d4
} XS_PCS_MMD;
/*}}}*/
//============================================================================================================================
// VS_MMD1 : Vendor Specific MMD1 Registers address block {{{
//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
//--------------------------------------------------------------
// PMA_ID1 : SR Control MMD PMA Device Identifier Register 1{{{
//--------------------------------------------------------------
typedef struct {
    uint    PMADOUI_3_18            : 16;
    uint                            : 16;
} PMA_ID1;

typedef union {
    uint                            nReg;
    PMA_ID1                         bReg;
} VSMMD_PMA_ID1_U;
/*}}}*/
//--------------------------------------------------------------
// VS_MMD register bank structure
//--------------------------------------------------------------
typedef struct {
    VSMMD_PMA_ID1_U         uPMA_ID1                                ;// 0x80000
    uint                    undef_mmd0[((0x8001c-0x80000)/4)-1]     ;// 0x80004~0x80018
} VS_MMD1;
/*}}}*/
//============================================================================================================================
// SR_MII_MMD : Vendor Specific MII MMD Standard (SR) Registers address block{{{
//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
//--------------------------------------------------------------
// MII_CTRL : SR MII MMD Control Register The host can use this register to control (enable or disable) some of the features {{{
//            supported by the DWC_xpcs with 1G (1000BASE-X) or USXGMII support) and Clause 37 auto-negotiation support.
//--------------------------------------------------------------
typedef struct {
    uint                            :  5;
    uint    SS5                     :  1;
    uint    SS6                     :  1;
    uint                            :  1;
    uint    DUPLEX_MODE             :  1;
    uint    RESTART_AN              :  1;
    uint                            :  1;
    uint    LPM                     :  1;
    uint    AN_ENABLE               :  1;
    uint    SS13                    :  1;
    uint    LBE                     :  1;
    uint    RST                     :  1;
    uint                            : 16;
} MII_CTRL;

typedef union {
    uint                            nReg;
    MII_CTRL                        bReg;
} MII_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// MII_AN_ADV : SR MII MMD AN Advertisement Register, The host uses this register to advertise the abilities and status of {{{
//              the local device to its link partner through Clause 37 auto-negotiation protocol.
//--------------------------------------------------------------
typedef struct {
    uint                            :  5;
    uint    FD                      :  1;
    uint    HD                      :  1;
    uint    PAUSE                   :  2;
    uint                            :  3;
    uint    RF                      :  2;
    uint                            :  1;
    uint    NP                      :  1;
    uint                            : 16;
} MII_AN_ADV;

typedef union {
    uint                            nReg;
    MII_AN_ADV                      bReg;
} MII_AN_ADV_U;
/*}}}*/
//--------------------------------------------------------------
// SR_MII_MMD register bank structure
//--------------------------------------------------------------
typedef struct {
  MII_CTRL_U            uMII_CTRL                                   ;// 0xc0000
  uint                  undef_mii0[((0xc0010-0xc0000)/4)-1]         ;// 0xc0004~0xc000c
  MII_AN_ADV_U          uMII_AN_ADV                                 ;// 0xc0010
  uint                  undef_mii1[((0xc0040-0xc0010)/4)-1]         ;// 0xc0014~0xc003c
} SR_MII_MMD;
/*}}}*/
//============================================================================================================================
// VR_MMI_MMD : Vendor Specific (VR) Registers address block{{{
//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
//--------------------------------------------------------------
// MII_DIG_CTRL1 : VR MII MMD Digital Control1 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    PHY_MODE_CTRL           :  1;
    uint    BYP_PWRUP               :  1;
    uint    EN_2_5G_MODE            :  1;
    uint    CL37_TMR_OVR_RIDE       :  1;
    uint    DTXLANED_0              :  1;
    uint    EN_100M                 :  1;
    uint    PRE_EMP                 :  1;
    uint    MSK_RD_ERR              :  1;
    uint    INIT                    :  1;
    uint    MAC_AUTO_SW             :  1;
    uint    CS_EN                   :  1;
    uint    PWRSV                   :  1;
    uint    CL37_BP                 :  1;
    uint    EN_VSMMD1               :  1;
    uint    R2TLBE                  :  1;
    uint    VR_RST                  :  1;
    uint                            : 16;
} MII_DIG_CTRL1;

typedef union {
    uint                            nReg;
    MII_DIG_CTRL1                   bReg;
} MII_DIG_CTRL1_U;
/*}}}*/
//--------------------------------------------------------------
// AN_CTRL : VR MII MMD AN Control Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    MII_AN_INTR_EN          :  1;
    uint    PCS_MODE                :  2;
    uint    TX_CONFIG               :  1;
    uint    SGMII_LINK_STS          :  1;
    uint                            :  3;
    uint    MII_CTRL                :  1;
    uint    IND_TX_EN               :  1;
    uint                            :  6;
    uint                            : 16;
} AN_CTRL;

typedef union {
    uint                            nReg;
    AN_CTRL                         bReg;
} AN_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// AN_INTR_STS : VR MII MMD AN Interrupt and Status Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    CL37_ANCMPLT_INTR       :  1;
    uint    CL37_ANSGM_STS          :  4;
    uint    LP_EEE_CAP              :  1;
    uint    LP_CK_STP               :  1;
    uint                            :  1;
    uint    USXG_AN_STS             :  7;
    uint                            :  1;
    uint                            : 16;
} AN_INTR_STS;

typedef union {
    uint                            nReg;
    AN_INTR_STS                     bReg;
} AN_INTR_STS_U;
/*}}}*/
//--------------------------------------------------------------
// MII_DIG_CTRL3 : VR MII MMD Digital Control 3 Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    TICD                    :  1;
    uint    RICE                    :  1;
    uint    CICD                    :  1;
    uint                            : 13;
    uint                            : 16;
} MII_DIG_CTRL3;

typedef union {
    uint                            nReg;
    MII_DIG_CTRL3                   bReg;
} MII_DIG_CTRL3_U;
/*}}}*/
//--------------------------------------------------------------
// LINK_TIMER_CTRL : VR MII MMD Link Timer Control Register{{{
//--------------------------------------------------------------
typedef struct {
    uint    CL37_LINK_TIME          : 16;
    uint                            : 16;
} LINK_TIMER_CTRL;

typedef union {
    uint                            nReg;
    LINK_TIMER_CTRL                 bReg;
} LINK_TIMER_CTRL_U;
/*}}}*/
//--------------------------------------------------------------
// VR_MMI_MMD register bank structure
//--------------------------------------------------------------
typedef struct {
    MII_DIG_CTRL1_U     uMII_DIG_CTRL1                              ;// 0xe0000
    AN_CTRL_U           uAN_CTRL                                    ;// 0xe0004
    AN_INTR_STS_U       uAN_INTR_STS                                ;// 0xe0008
    uint                undef_mii0[((0xe0010-0xe0008)/4)-1]         ;// 0xe000c
    MII_DIG_CTRL3_U     uMII_DIG_CTRL3                              ;// 0xe0010
    uint                undef_mii1[((0xe0028-0xe0010)/4)-1]         ;// 0xe0014~0xe0024
    LINK_TIMER_CTRL_U   uLINK_TIMER_CTRL                            ;// 0xe0028
} VR_MII_MMD;
/*}}}*/



void Serdes_init_2p5G(void);
void Serdes_init_5p0G(void);
void Serdes_init_XpXG(void);
void SerDes_register_dump(void);
void check_Link_sts(void);
void tpa_csr_dump(void);
void phy_register_dump(void);


