/**
 * @file MRVL_AMG_API_Debug.c
 * @brief Marvell Multi-gig Automotive Ethernet PHY Debug API for capturing the debug information
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */

#include "MRVL_AMG_API_CMD.h"
#include "MRVL_AMG_API_Debug.h"
#include "MRVL_AMG_REG_MAIN.h"


/* **************** Trace log related **************** */

/**
 * @brief read processor memory
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] aMemAdd	address (byte Aligned)
 * @param[in] aLength	number of words to be read
 * @param[out] vRetWord	
 * @return MRVL_APHY_STATUS
 */
STATIC MRVL_APHY_STATUS MRVL_AMG_Trace_ReadProcessorMemoryAdv(MRVL_DEV_PTR device, MRVL_APHY_U32 aMemAdd, MRVL_APHY_U16 aLength, MRVL_APHY_U32 vRetWord[])
{
	MRVL_APHY_U8 aSize; /*unsigned short int */
	MRVL_APHY_U8 vNumLeadingPadBytes;
	MRVL_APHY_U32 vStartingAddrAligned;
	MRVL_APHY_U32 vEndingAddr;
	MRVL_APHY_U32 vEndingAddrAligned;
	MRVL_APHY_U32 vNumWords;

	MRVL_APHY_BOOL vReadWordParametersValid;
	MRVL_APHY_U32 mRegRaw;
	MRVL_APHY_STATUS status;
	/* MRVL_APHY_U32 vAddrLo; */
	/* MRVL_APHY_U32 vAddrHi; */
	MRVL_APHY_U32 i;
	MRVL_APHY_U32 j = 0;
	MRVL_APHY_U32 *vWordsRead;
	/* MRVL_APHY_U8 *vBytesReadtmp; */
	MRVL_APHY_U8 *vBytesRead;
	MRVL_APHY_U32 start, timed;

	aSize = 2; /* unsigned short int */
	vNumLeadingPadBytes = (MRVL_APHY_U8)(aMemAdd % 4);
	vStartingAddrAligned = aMemAdd - vNumLeadingPadBytes;
	vEndingAddr = (MRVL_APHY_U32)(((MRVL_APHY_U32)aSize * (MRVL_APHY_U32)aLength) + aMemAdd);
	vEndingAddrAligned = vEndingAddr + (3 - (vEndingAddr % 4));
	vNumWords = (vEndingAddrAligned + 1 - vStartingAddrAligned) / 4;

	/* vReadWordParametersValid = MRVL_APHY_TRUE; */
	mRegRaw = 0;
	status = MRVL_APHY_STATUS_OK;

	/* vAddrLo = vStartingAddrAligned; */
	/* vAddrHi = vStartingAddrAligned + vNumWords * 4 - 1; */

	MRVL_AMG_DBG_CMD("MRVL_AMG_Trace_readProcessorMemoryAdv: vNumWords=%u, vStartingAddrAligned=0x%x, vEndingAddrAligned=0x%x\n", aLength, vNumWords, vStartingAddrAligned, vEndingAddrAligned);
	
	MRVL_AMG_Clock(&start);

	vReadWordParametersValid = ((vStartingAddrAligned >= MRVL_AMG_CMD_hostBuffAddrMin) 
		&& (vEndingAddrAligned < MRVL_AMG_CMD_hostBuffAddrMax) 
		&& (vEndingAddrAligned >= vStartingAddrAligned))
		? MRVL_APHY_TRUE : MRVL_APHY_FALSE;

	if (vReadWordParametersValid == MRVL_APHY_FALSE) {
		MRVL_AMG_DBG_WARNING("MRVL_AMG_Trace_readProcessorMemoryAdv warning: invalid parameters: vNumWords=%u, vStartingAddrAligned=0x%x, vEndingAddrAligned=0x%x\n", vNumWords, vStartingAddrAligned, vEndingAddrAligned);
		status |= MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
	}

	else
	{

		status |= MRVL_AMG_ReadReg32(device, MRVL_AMG_CMD_MB_CTRL, &mRegRaw);
		if ((mRegRaw & 0x10U) == 0x10) 
		{
			if ((mRegRaw & 0x20U) == 0) 
			{
				MRVL_AMG_DBG_WARNING("MRVL_AMG_Trace_readProcessorMemoryAdv warning: command init failed, force execute to be cleared: mRegRaw=0x%x\n", mRegRaw);
				/* mRegRaw |= 0x20; */
				status |= MRVL_APHY_STATUS_ERROR_GENERAL;
			}
			else
			{
				mRegRaw &= ~(0x10U);
				status |= MRVL_AMG_WriteReg32(device, MRVL_AMG_CMD_MB_CTRL, mRegRaw);
			}
		}
		
		if (status == MRVL_APHY_STATUS_OK) 
		{
			vWordsRead = (MRVL_APHY_U32*)MRVL_AMG_MemoryAllocation((MRVL_APHY_U32)(vNumWords * sizeof(MRVL_APHY_U32)));
			vBytesRead = (MRVL_APHY_U8*)MRVL_AMG_MemoryAllocation((MRVL_APHY_U32)(vNumWords * sizeof(MRVL_APHY_U32)/sizeof(MRVL_APHY_U8)));


			if (vWordsRead == NULL || vBytesRead == NULL) 
			{
				MRVL_AMG_DBG_ERROR("MRVL_AMG_Trace_readProcessorMemoryAdv error: Memory not allocated.\n");
				status |= MRVL_APHY_STATUS_ERROR_GENERAL;
			}
			else
			{
				for (i = 0; i < vNumWords; i++)
				{
					vBytesRead[i] = 0;
					vWordsRead[i] = 0;
				}

				status |= MRVL_AMG_CMD_ReadWords(device, vStartingAddrAligned, (MRVL_APHY_U16)vNumWords, vWordsRead);
				if (status == MRVL_APHY_STATUS_OK)
				{
					for (i = 0; i < vNumWords; i++) 
					{
						for (j = 0; j < sizeof(MRVL_APHY_U32); j++) 
						{
							vBytesRead[i*sizeof(MRVL_APHY_U32) + j] = (MRVL_APHY_U8)((vWordsRead[i] >> (8 * j)) & 0xFFU);
						}
					}

					for (i = 0; i < aLength; i++) 
					{
						vRetWord[i] = vBytesRead[i * aSize + vNumLeadingPadBytes];
						vRetWord[i] |= (MRVL_APHY_U32)(vBytesRead[i * aSize + 1 + vNumLeadingPadBytes]) << 8;
					}
				}

				MRVL_AMG_FreeMemory((void*)vWordsRead);
				MRVL_AMG_FreeMemory((void*)vBytesRead);
				vBytesRead = NULL;
				vWordsRead = NULL;
			}							
		}
	}
	

	if (status == MRVL_APHY_STATUS_OK)
	{
		MRVL_AMG_Clock(&timed);
		MRVL_AMG_DBG_CMD("MRVL_AMG_Trace_readProcessorMemoryAdv: completed wordsToRead=%d wordsRead:%d wordSize=%d time=%dms\n", aLength, vNumWords* aSize, aSize, (timed - start));
	}
		
	return status;
}

/**
 * @brief send Data Request 
 * @param[in] device	pointer to MRVL_DEV
 * @return MRVL_APHY_STATUS
 */
STATIC MRVL_APHY_STATUS MRVL_AMG_Trace_BufferDataRequestSend(MRVL_DEV_PTR device)
{
	MRVL_AMG_DBG_CMD("BufferDataRequestSend: Sending data request=0x%x\n", MRVL_AMG_CMD_DebugSendRequest);
	return MRVL_AMG_WriteReg32(device, MRVL_AMG_CMD_controlStatus, MRVL_AMG_CMD_DebugSendRequest);
}

/**
 * @brief check previously sent data request status: init, corrupted, pending or confirmed
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] result	pointer to MRVL_AMG_Trace_ResultDict
 * @param[in] timeout	wait timeout
 * @return MRVL_APHY_STATUS
 */
STATIC MRVL_APHY_STATUS MRVL_AMG_Trace_BufferCheckIfDataRequestGranted(MRVL_DEV_PTR device, MRVL_AMG_TRACE_ResultDict* result, MRVL_APHY_U16 timeout) 
{
	MRVL_APHY_U32 traceStatus, vRequestId, vRequestFieldInStatus, vResponseFieldInStatus;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32 start, end;

	MRVL_AMG_Clock(&start);

	end = start;
	while (1) 
	{
		status |= MRVL_AMG_ReadReg32(device, MRVL_AMG_CMD_controlStatus, &traceStatus);
		result->ResultDict_traceStatus = traceStatus;
		vRequestId = (MRVL_AMG_CMD_DebugSendRequest & MRVL_AMG_CMD_DebugRequestMask) >> MRVL_AMG_CMD_DebugRequestShift;
		vRequestFieldInStatus = (traceStatus & MRVL_AMG_CMD_DebugRequestMask) >> MRVL_AMG_CMD_DebugRequestShift;
		vResponseFieldInStatus = (traceStatus & MRVL_AMG_CMD_DebugStatusMask) >> MRVL_AMG_CMD_DebugStatusShift;
		if (traceStatus == 0) {
			result->ResultDict_requestStatus = MRVL_AMG_TRC_RequestStatus_init;
		}
		else if (vRequestFieldInStatus != vRequestId) 
		{
			result->ResultDict_requestStatus = MRVL_AMG_TRC_RequestStatus_corruption;
		}
		else if (vResponseFieldInStatus == 0) 
		{
			result->ResultDict_requestStatus = MRVL_AMG_TRC_RequestStatus_pending;
		}
		else 
		{
			if (vResponseFieldInStatus == vRequestId) 
			{				
				result->ResultDict_requestStatus = MRVL_AMG_TRC_RequestStatus_confirmed;
			}
			else 
			{
				result->ResultDict_requestStatus = MRVL_AMG_TRC_RequestStatus_corruption;
			}
		}
		
		if (result->ResultDict_requestStatus == MRVL_AMG_TRC_RequestStatus_corruption) 
		{
			MRVL_AMG_DBG_ERROR("MRVL_AMG_Trace_BufferCheckIfDataRequestGranted error: Incoherent response to request. IC reset might be in progress: request=0x%x response=0x%x\n", MRVL_AMG_CMD_DebugSendRequest, traceStatus);
			status |= MRVL_APHY_STATUS_ERROR_GENERAL;
			break;
		}
		else if(result->ResultDict_requestStatus == MRVL_AMG_TRC_RequestStatus_init)
		{
			MRVL_AMG_DBG_CMD("MRVL_AMG_Trace_BufferCheckIfDataRequestGranted: Firmware reinitialized: request=0x%x response=0x%x\n", MRVL_AMG_CMD_DebugSendRequest, traceStatus);
			status |= MRVL_APHY_STATUS_OK;
			break;
		}
		else if (result->ResultDict_requestStatus == MRVL_AMG_TRC_RequestStatus_confirmed) 
		{
			status|= MRVL_APHY_STATUS_OK;
			break;
		}
		else if (result->ResultDict_requestStatus == MRVL_AMG_TRC_RequestStatus_pending) 
		{
			status|= MRVL_APHY_STATUS_OK;
			/* keep waiting */
		}
		else 
		{
			MRVL_AMG_DBG_ERROR("MRVL_AMG_Trace_BufferCheckIfDataRequestGranted error: Unsupported status: request=0x%x response=0x%x\n", MRVL_AMG_CMD_DebugSendRequest, traceStatus);
			status |= MRVL_APHY_STATUS_ERROR_GENERAL;
			break;
		}

		MRVL_AMG_Clock(&end);		
		if ((end - start) > timeout) 
		{
			break;
		}			
	}
	
	if ((end - start) > timeout)
	{
		result->ResultDict_requestStatus = MRVL_AMG_TRC_RequestStatus_timeout;
		MRVL_AMG_DBG_ERROR("MRVL_AMG_Trace_BufferCheckIfDataRequestGranted error: timeout: request=0x%x response=0x%x\n", MRVL_AMG_CMD_DebugSendRequest, traceStatus);
		status |= MRVL_APHY_STATUS_ERROR_TIMEOUT;
	} 

	return status;	
}

/**
 * @brief retrive debug trace raw data from memory
 * @param[in] device	pointer to MRVL_DEV
 * @param[out] result	pointer to MRVL_AMG_Trace_ResultDict
 * @return MRVL_APHY_STATUS
 */
STATIC MRVL_APHY_STATUS MRVL_AMG_Trace_GetTraceRaw(MRVL_DEV_PTR device, MRVL_AMG_TRACE_ResultDict *result)
{
	MRVL_APHY_U32 bytesToReadInFirmwareBuffer, bytesToReadInHostBuffer, bytesToRead;
	MRVL_APHY_U32 hostBuffAddr, lswAddr, mswAddr;
	MRVL_APHY_U16 vResponseFlags, vResponseFieldInStatus, wordsToRead;
	MRVL_APHY_BOOL vStatusResync = MRVL_APHY_FALSE;
	MRVL_APHY_BOOL vStatusOverflow = MRVL_APHY_FALSE;
	/* MRVL_APHY_BOOL vValidRange = MRVL_APHY_TRUE; */
	const MRVL_APHY_U8 vMaxTries = 2;
	MRVL_APHY_U8 vNumTries = 0;
	MRVL_APHY_U16 vDataRequestTimeout = 0;
	/* MRVL_APHY_U16 cnt = 0; */
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	MRVL_APHY_U32* traceRawBuffer;

	status |= MRVL_AMG_ReadReg32(device, MRVL_AMG_CMD_DebugBufferDepthAddr, &bytesToReadInFirmwareBuffer);
	status |= MRVL_AMG_ReadReg32(device, MRVL_AMG_CMD_hostBuffDataLevel, &bytesToReadInHostBuffer);
	MRVL_AMG_DBG_CMD("MRVL_AMG_Trace_GetTraceRaw: bytesToReadInHostBuffer=%u bytesToReadInFirmwareBuffer=%u\n", bytesToReadInHostBuffer, bytesToReadInFirmwareBuffer);

	if (bytesToReadInHostBuffer == 0)
	{
		status |= MRVL_AMG_Trace_BufferDataRequestSend(device);
		if (bytesToReadInFirmwareBuffer > 0) 
		{
			vDataRequestTimeout = MRVL_AMG_RequestTimeoutWhenDataIsAvailible_MS;
		}
	}

	while (1) {
		status |= MRVL_AMG_Trace_BufferCheckIfDataRequestGranted(device, result, vDataRequestTimeout);
		if (result->ResultDict_requestStatus != MRVL_AMG_TRC_RequestStatus_confirmed) 
		{
			if (bytesToReadInHostBuffer != 0) {
				result->ResultDict_requestStatus = MRVL_AMG_TRC_RequestStatus_confirmed;
				result->ResultDict_returnStatus = MRVL_AMG_TRC_ReturntStatus_Success;
			}
			else if (result->ResultDict_requestStatus == MRVL_AMG_TRC_RequestStatus_init || result->ResultDict_requestStatus == MRVL_AMG_TRC_RequestStatus_corruption) {
				MRVL_AMG_DBG_CMD("MRVL_AMG_Trace_GetTraceRaw: Re-issusing data request\n");
				status |= MRVL_AMG_Trace_BufferDataRequestSend(device);

				vNumTries += 1;
				if (vNumTries < vMaxTries) {
					status |= MRVL_AMG_ReadReg32(device, MRVL_AMG_CMD_DebugBufferDepthAddr, &bytesToReadInFirmwareBuffer);
					if (bytesToReadInFirmwareBuffer > 0) 
					{
						vDataRequestTimeout = MRVL_AMG_RequestTimeoutWhenDataIsAvailible_MS;
					}
					continue;
				}

				if (result->ResultDict_requestStatus == MRVL_AMG_TRC_RequestStatus_corruption) 
				{
					result->ResultDict_returnStatus = MRVL_AMG_TRC_ReturntStatus_Error_TraceDataCorrupted;
				}
				else 
				{
					result->ResultDict_returnStatus = MRVL_AMG_TRC_ReturntStatus_Warning_NoData;
				}

			}
			else {
				result->ResultDict_returnStatus = MRVL_AMG_TRC_ReturntStatus_Warning_NoData; 
			}
			if (result->ResultDict_returnStatus == MRVL_AMG_TRC_ReturntStatus_Warning_NoData) 
			{
				/* no data, buffer is empty, call back later */
				status |=  MRVL_APHY_STATUS_OK;
				break;
			}
			if (result->ResultDict_returnStatus != MRVL_AMG_TRC_ReturntStatus_Success) 
			{
				status |=  MRVL_APHY_STATUS_ERROR_GENERAL;
				break;
			}
		}
		else {
			result->ResultDict_returnStatus = MRVL_AMG_TRC_ReturntStatus_Success;
		}

		break;
	}

	status |= MRVL_AMG_ReadReg32(device, MRVL_AMG_CMD_DebugBufferDepthAddr, &bytesToReadInFirmwareBuffer);
	status |= MRVL_AMG_ReadReg32(device, MRVL_AMG_CMD_hostBuffDataLevel, &bytesToReadInHostBuffer);


	MRVL_AMG_DBG_CMD("MRVL_AMG_Trace_GetTraceRaw: bytesToReadInHostBuffer=%u bytesToReadInFirmwareBuffer=%u\n", bytesToReadInHostBuffer, bytesToReadInFirmwareBuffer);

	vResponseFlags = (MRVL_APHY_U16)((result->ResultDict_traceStatus & MRVL_AMG_CMD_DebugStatusFlagsMask) >> MRVL_AMG_CMD_DebugStatusFlagsShift);
	vResponseFieldInStatus = (MRVL_APHY_U16)((result->ResultDict_traceStatus & MRVL_AMG_CMD_DebugStatusMask) >> MRVL_AMG_CMD_DebugStatusShift);

	vStatusResync = (vResponseFlags & MRVL_AMG_CMD_DebugStatusFlagDataGrantedWithResync) != 0 ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;
	if (vStatusResync == MRVL_APHY_TRUE) 
	{
		MRVL_AMG_DBG_WARNING("MRVL_AMG_Trace_GetTraceRaw warning: Debug Trace Buffer was reinitialized! TraceStatus=0x%x\n", result->ResultDict_traceStatus);
		result->ResultDict_returnStatus = MRVL_AMG_TRC_ReturntStatus_Warning_Resync;
	}

	vStatusOverflow = ((vResponseFlags & MRVL_AMG_CMD_DebugStatusFlagDataGrantedWithOverflow) != 0) 
					|| ((vResponseFieldInStatus & MRVL_AMG_CMD_DebugStatusDataGrantedWithOverflow_Legacy) != 0) ? MRVL_APHY_TRUE : MRVL_APHY_FALSE;

	if (vStatusOverflow == MRVL_APHY_TRUE) 
	{
		MRVL_AMG_DBG_WARNING("MRVL_AMG_Trace_GetTraceRaw warning: Debug Trace Buffer Overflow! TraceStatus=0x%x\n", result->ResultDict_traceStatus);
		result->ResultDict_returnStatus = MRVL_AMG_TRC_ReturntStatus_Warning_Overflow;
	}

	status |= MRVL_AMG_ReadReg32(device, MRVL_AMG_CMD_hostBuffAddrLsw, &lswAddr);
	status |= MRVL_AMG_ReadReg32(device, MRVL_AMG_CMD_HostBuffAddrMsw, &mswAddr);
	hostBuffAddr = (lswAddr | (mswAddr << 16));
	bytesToRead = bytesToReadInHostBuffer;

	MRVL_AMG_DBG_CMD("MRVL_AMG_Trace_GetTraceRaw: Reading trace data: bytesToRead=%d\n", bytesToRead);
	
	/* Read debug trace host buffer(short integers) */
	wordsToRead = (MRVL_APHY_U16)(bytesToRead / 2); 
	result->ResultDict_length = wordsToRead;
	MRVL_AMG_Time(&result->ResultDict_timestamp);

	traceRawBuffer = (MRVL_APHY_U32*)MRVL_AMG_MemoryAllocation((MRVL_APHY_U32)(wordsToRead * sizeof(MRVL_APHY_U32)));
	result->ResultDict_rawMessages_ptr = traceRawBuffer;

	status |= MRVL_AMG_Trace_ReadProcessorMemoryAdv(device, hostBuffAddr, wordsToRead, traceRawBuffer);

	if (status != MRVL_APHY_STATUS_OK) {
		result->ResultDict_returnStatus = MRVL_AMG_TRC_ReturntStatus_Error_TraceDataCouldNotBeExtracted;
		result->ResultDict_requestStatus = MRVL_AMG_TRC_RequestStatus_corruption;
		result->ResultDict_length = 0;
	}

	status |= MRVL_AMG_WriteReg32(device, MRVL_AMG_CMD_hostBuffDataLevel, 0);
	
	return status;
}

/******************************************************************************
 *      Debug Trace
 ******************************************************************************/

/**
 * @brief get trace log from memory buffer and append it to a file. Require little-endian (LE) host machines.
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] filename	file directory
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_DEBUG
 */
MRVL_APHY_STATUS MRVL_AMG_Trace_SaveTraceData(MRVL_DEV_PTR device, const char* filename) {
	MRVL_AMG_TRACE_ResultDict result;
	MRVL_APHY_STATUS status = MRVL_APHY_STATUS_OK;
	FILE* filePtr;
	MRVL_APHY_U16 i;
	char buffer[PRINT_BUFFER_SIZE] = "";
	char resultStatus[SMALL_BUFFER_SIZE];
	char timestamp[SMALL_BUFFER_SIZE];
	char message[MESSAGE_BUFFER_SIZE];

	filePtr = MRVL_AMG_FileOpen(filename);
	if (filePtr == NULL) {
		MRVL_AMG_DBG_ERROR("MRVL_AMG_Trace_SaveTraceData error: File Not Found.\n");
		status = MRVL_APHY_STATUS_ERROR_GENERAL;
	}
	else
	{
		result.ResultDict_length = 0;
		result.ResultDict_requestStatus = MRVL_AMG_TRC_RequestStatus_init;
		result.ResultDict_returnStatus = MRVL_AMG_TRC_ReturntStatus_Reserved;

		status |= MRVL_AMG_Trace_GetTraceRaw(device, &result);

		MRVL_AMG_DBG_INFO("MRVL_AMG_Trace_SaveTraceData: ResultDict: read=%d(16-bit) requestStatus=%d returnStatus=%d traceStatus=0x%x status=0x%x\n", result.ResultDict_length, result.ResultDict_requestStatus, result.ResultDict_returnStatus, result.ResultDict_traceStatus, status);

		if (result.ResultDict_returnStatus == MRVL_AMG_TRC_ReturntStatus_Warning_NoData) {
			MRVL_AMG_DBG_INFO("MRVL_AMG_Trace_SaveTraceData: No data in buffer, read back later.\n");
			MRVL_AMG_FileClose(filePtr);
			status |= MRVL_APHY_STATUS_ERROR_TIMEOUT;
		}
		else 
		{
			if (status == MRVL_APHY_STATUS_OK && result.ResultDict_length > 0) 
			{
				MRVL_AMG_StringCat(buffer, "{\"status\": 0, \"confirmed\": true, \"rawMessages\": [");

				// MRVL_AMG_PrintToFile(device, filePtr, buffer);

				for (i = 0; i < result.ResultDict_length - 1; i++) 
				{
					MRVL_AMG_UintToString(message, result.ResultDict_rawMessages_ptr[i]);
					MRVL_AMG_StringCat(buffer, message);
					MRVL_AMG_StringCat(buffer, ", ");
				}

				MRVL_AMG_UintToString(message, result.ResultDict_rawMessages_ptr[result.ResultDict_length - 1]);
				MRVL_AMG_StringCat(buffer, message);
				MRVL_AMG_StringCat(buffer, " ],");
				MRVL_AMG_UintToString(resultStatus, result.ResultDict_traceStatus);
				MRVL_AMG_FloatToString(timestamp, result.ResultDict_timestamp);				
				MRVL_AMG_StringCat(buffer, " \"traceStatus\": ");
				MRVL_AMG_StringCat(buffer, resultStatus);
				MRVL_AMG_StringCat(buffer, ", \"dataRequestStatus\": \"confirmed\", \"errMessages\": \"\", \"dbgRawRemainder\": [], \"timestamp\": ");
				MRVL_AMG_StringCat(buffer, timestamp);
				MRVL_AMG_StringCat(buffer, "}\n");
				MRVL_AMG_PrintToFile(filePtr, buffer);

				MRVL_AMG_FileClose(filePtr);
			}
			else 
			{
				MRVL_AMG_DBG_ERROR("MRVL_AMG_Trace_SaveTraceData error:  trace data was not read correctly: ResultDict: length=%d requestStatus=%d returnStatus=%d traceStatus=0x%x status=0x%x\n", result.ResultDict_length, result.ResultDict_requestStatus, result.ResultDict_returnStatus, result.ResultDict_traceStatus, status);
				MRVL_AMG_FileClose(filePtr);
				status |= MRVL_APHY_STATUS_ERROR_GENERAL;
			}
		}
	}
	
	return status;
}
