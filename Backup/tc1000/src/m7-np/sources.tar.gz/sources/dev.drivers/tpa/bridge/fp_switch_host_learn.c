// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_switch_host_learn.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    implemets switch learning API's
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                      Include Files
 **********************************************************************/
 #include "fp_library.h"
 #include "fp_switch.h"
 #include "hw_2field_hash_table.h"
 #include "hw_vlan_hash_table.h"
 #include "fp_os_shim.h"

/**********************************************************************
 *                                     Extern Files
 **********************************************************************/

/******************************************************************n
 * Function Name  : fp_init_field_entries
 * Description    : initialize the mac-5 filed registers
 * Inputs         :
 * Parameters     : pktBuf_t *
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a fp_init_field_entries(uint8 *mac,
				uint32a vlanid,
				uint32a *field_entries)
{
	uint32a *entry = (uint32a *)mac;

	/* need to updated field entries valid filed basis */
	field_entries[0] = entry[0];
	field_entries[1] = entry[1] & 0xFFFF;
	field_entries[1] |= (vlanid << 16);
	field_entries[2] = 0;
	field_entries[3] = 0;
	field_entries[4] = 0;
	FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO, "%s: mac1 %x mac2 %x\n",
				__func__, field_entries[0], field_entries[1]);
	FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO,
				"HW_MAC_ADDR: %x:%x:%x:%x:%x:%x\n", mac[0],
				mac[1], mac[2], mac[3], mac[4], mac[5]);
	return 0;
}
#if 0
/******************************************************************
 * Function Name  : getFwdPortList
 * Description    : serach for DMAC entry in mac hash table
 *                  if not found use vlan table to get the fwd port list
 * Inputs         :
 * Parameters     : pktBuf_t *
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ********************************************************************/
int32a getFwdPortList(pktHdrs_t *pktHdr, uint32a vlanid)
{
	uint8 *mac;
	uint32a action_entry = -1;
	uint32a fwdPortList = 0;
	uint32a field_entries[5];
	uint32a field_valids = BIT_SET_MAC_2F_MACTBL;
	uint32a fwd_action = -1;
	struct ethhdr *ethHdr = (struct ethhdr *)pktHdr->data;

	if (GetBaseAddr() == NULL) {
		printk("%s: pci_mem base is NULL", __func__);
		return 0;
	}
	mac = ethHdr->h_source;
	fp_init_field_entries(mac, vlanid, &field_entries[0]);
	/* update vlan field valid for mac table */
	field_valids |= BIT_SET_VLAN_2F_MACTBL;

	/* search for dmac entry*/
	action_entry = hw_hash_table_search(field_entries,field_valids);
	if (-1 != action_entry) {
		/* dmac entry found */
		/* Get fwd action from bridge table entry */
		fwd_action = (action_entry & BRENTRY_UCAST_HIT_ACT_MASK) >>
		BRENTRY_UCAST_HIT_ACT_START_POS;
		fwdPortList = fwd_action << 16;
		fwdPortList |= (action_entry & FWD_PORT_LIST_MASK);
	} else {
		/* dmac entry not found */
		if (0 != vlanid) {
			action_entry = -1;
			action_entry = wsp_vlan_entry_search(vlanid);
			if (-1 == action_entry) {
				/* brentry not found */
				/* Un handeled bridge entry,
				take fwd action of fp_global br entry */
				fwd_action = fp_global.fallback_bd_entry.
							ucast_miss_action;
				fwdPortList = fwd_action << 16;
				/* get the forward port list from
							fp_global br entry */
				fwdPortList |= (fp_global.fallback_bd_entry.
					forward_list &
					BRENTRY_FWD_PORT_LIST_MASK);
			} else {
				/* brentry found */
				/* Get fwd action from bridge table entry */
				fwd_action = (action_entry &
					BRENTRY_UCAST_MISS_ACT_MASK) >>
					BRENTRY_UCAST_MISS_ACT_START_POS;

				fwdPortList = fwd_action << 16;
				/* get the forward port list from
							vlan table entry */
				fwdPortList |= (action_entry &
						BRENTRY_FWD_PORT_LIST_MASK);
			}
		}
	}
	return fwdPortList;
}
#endif

static int32a fp_switch_host_learn_entry(	uint8 *mac,
					uint32a vlanid,
					uint32a phy_port,
					uint32a punt_reason,
					uint32a act_discard,
					uint32a static_entry)
{
	int32a ret = -1;
	uint32a fwd_action = 0;
	uint32a action_entry = 0;
	uint32a field_entries[5];
	uint32a field_valids = BIT_SET_MAC_2F_MACTBL;
	uint32a action_portno = 0;

	/* initialize required filed valids for mac table learning/searching */
	fp_init_field_entries(mac, vlanid, &field_entries[0]);
	/* update vlan field valid for mac table */
	field_valids |= BIT_SET_VLAN_2F_MACTBL;
	/* check for for already entry existence */
	ret = hw_hash_table_search(field_entries, field_valids);
	if (-1 == ret) {
		/* fill action_entry's fresh bit */
		action_entry = FRESH_FLAG_SET;
		if (static_entry)
			action_entry |= STATIC_FLAG_SET;
		FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_CRIT, "%s: Search Fail\n", __func__);
		/* Add SMAC entry with action entry & valid fields */
		/* update action entry with port info on which it arrived */
		action_entry |= ((0x1 << phy_port) & FWD_PORT_LIST_MASK);
		/* Get bridge action entry */
		ret = wsp_vlan_entry_search(vlanid);
		if (-1 == ret) {
			/* Un handled bridge entry,
			 * take fwd action of fp_global br entry */
			fwd_action = fp_global.fallback_bd_entry.ucast_hit_action;
			return 0;
		} else {
			/* Get bridge action entry's
					unicast hit fwd action */
			fwd_action =
				(ret & BRENTRY_UCAST_HIT_ACT_MASK) >>
				BRENTRY_UCAST_HIT_ACT_START_POS;
		}
		/* Update mac action entry's fwd action */
		action_entry = (action_entry & ~MAC_2F_ENTRY_FWD_ACT_MASK) |
				(fwd_action << MAC_2F_ENTRY_FWD_ACT_START_POS);
		if (act_discard)
			action_entry |= (ACT_DISCARD << MAC_2F_ENTRY_FWD_ACT_START_POS);
		FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO, "%s: action_entry %x\n",
							__func__, action_entry);
		/* add mac entry */
		ret = hw_hash_table_add(field_entries, phy_port,
					action_entry, field_valids);
		if (ret == -1) {
			FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_CRIT, "Learn Fail\n");
			/* if learn fails just fwd the pkt according to
				egress port list return -1; */
		}
	} else {
		action_entry = ret;
		/* mac hash entry found */
		switch (punt_reason) {
		case PUNT_SA_IS_ACTIVE:
			if (action_entry & FRESH_FLAG_MASK)
				action_entry = fp_update_mac_refresh_bit(action_entry);
			else
				return 0;
		/* update new phyno into mac hash table */
		ret = hw_hash_table_update(	field_entries,
						action_entry,
						field_valids);
		break;

		case PUNT_SA_RELEARN:
			/* validate relearn:                        *
			* check for ingress port match
					with action entry port num */
			action_portno = (ret & (FWD_PORT_LIST_MASK &
							(1 << phy_port)));
			if (!((1 << phy_port) & action_portno)) {
				action_entry = action_entry &
						(~FWD_PORT_LIST_MASK);
				/* reset old phyno and
					update new phyno into action entry */
				action_entry |= ((0x1 << phy_port) &
							FWD_PORT_LIST_MASK);
			}
			/* update new phyno into mac hash table */
			ret = hw_hash_table_update(	field_entries,
							action_entry,
							field_valids);
		break;

		default:
		break;
		} /* End of switch - (pktHdr->punt_reason) */

		FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_CRIT,
				"%s: Update called\n", __func__);
	}
	fp_rc_stats.fwd_cnt++;
	return 0;
}
/******************************************************************************
 * Function Name  : fp_switch_host_learn
 * Description    : lookup on Dest Mac, search fails learn dest mac
			into Hash Mac Table
 * Inputs         :
 * Parameters     : pktBuf_t *
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 *****************************************************************************/
int32a fp_switch_host_learn(pktHdrs_t *pktHdr)
{
	uint32a vlanid = 0;
	uint32a phy_port = pktHdr->phyno;
	uint32a punt_reason = pktHdr->punt_reason;
	struct ethhdr *ethHdr = (struct ethhdr *)pktHdr->data;
	uint8 *mac = ethHdr->h_source;

	FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO, "\n");
	/* Assign vlanid of pkt if it is present,
			else assign port's fallback bdid */
	if ((pktHdr->vlanid == fp_port[pktHdr->phyno].fallback_bd_id)
	||  (pktHdr->vlanid == 0)) {
		vlanid = fp_port[pktHdr->phyno].fallback_bd_id;
	} else {
		vlanid = pktHdr->vlanid;
	}
	FP_DEBUG(DBGP_FEAT_BRIDGE, FP_LOG_INFO, "%s: vlanid %x\n",
						__func__, pktHdr->vlanid);
	fp_switch_host_learn_entry(mac, vlanid, phy_port, punt_reason, 0, 0);
	return 0;
}

/*******************************************************************************
 * Function Name  : fp_switch_host_mac_refresh
 * Description    : update mac refresh bit
 * Inputs         :
 * Parameters     : uint32a
 * Outputs        :
 * Parameters     : -
 * Returns        : int
 ******************************************************************************/
uint32a fp_update_mac_refresh_bit(uint32a action_entry)
{
	action_entry = (action_entry & ~FRESH_FLAG_MASK);
	return action_entry;
}

