// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_pci_bm.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    contais interrupt handlers and pci bus master tx/rx routines
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifdef __linux__
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                      Include Files
 **********************************************************************/
#include <linux/spinlock_types.h>
#endif

#include "platform.h"
#include "reg_hal.h"
#include "fp_macros.h"
#include "fp_pre_header.h"
#include "fp_net_driver.h"
#include "fp_bd_api.h"
#include "fp_hif_reg.h"
#include "global_address_map_fpga.h"
#include "tables_config.h"

//void init_tlite_context_memory(void);
#define DEFAULT_HIF_NUM (0)
#define DEFAULT_HIF_CHANNEL (HIF_CHNUM_NP)

static struct tasklet_data fp_rx_info[NUM_TOTAL_HIF][NUM_HIF_CHANNELS];
static struct tasklet_data fp_tx_info[NUM_TOTAL_HIF][NUM_HIF_CHANNELS];

static int32a handle_hif(struct hif_base *hif);
static int32a handle_channel(struct hif_base *hif, uint32a ch_index);

#if 0
/**********************************************************************
 * Function Name  : fp_rx_tasklet
 * Description    : tasklet handler scheduled under bottom-half context,
 *                  this handler will called when everr tasklet is scheduled
 *                  to process rx packets, copy the packets from rx bd ring
 *                  to the kernel space as sk_buff's, deliver the packet
 *                  fp_phy interfaces based on phyno of the packet received,
 *                  extract necessary data from packet start data to update in
 *                  hooks, from now packet will processed as a regular path
 *                  handle by network stack
 * Inputs
 *   Parameters   : uint32 - fast path private data structure
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void fp_rx_tasklet(uint32 data)
{
}
#endif

/* return :
	>0 : received size
	==0 : no more data
	<0 : error */
int32a fp_receive_ethframe(void *fpHandle, uint8 *buffer, uint16 buffer_size)
{
	struct tasklet_data *rxptr = (struct tasklet_data *)&fp_rx_info[DEFAULT_HIF_NUM][DEFAULT_HIF_CHANNEL];
	//struct fp_private *fp = (struct fp_private *)rxptr->fp;
	struct fp_private *fp = (struct fp_private *)fpHandle;
	struct bd_ring *rxring;
	struct bd *rxbd;
	//struct sk_buff *skb;
	uint8 *ptr;
	uint32a len = 0;
	uint32a curr_bd_index = 0;
	uint32a rx_ctrl = 0;
	uint32a wb_buflen = 0;
	uint32a hif_index = rxptr->hif_index;
	uint32a ch_index = rxptr->ch_index;
	int32a ret = 0;
	static uint32a rx_count;
	volatile struct hif_regs *regs = fp->hif[hif_index].regs;
	int32a receive_size = 0;

	(void)rx_count;
	#if 0
	FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO,
		"RX Tasklet: hif_index %u ch_index %d\n", hif_index, ch_index);
	#endif
	rxring = fp->hif[hif_index].ch[ch_index].rxring;
	if (rxring == NULL) {
		FP_DEBUG(DBGP_FEAT_ERR, FP_LOG_EMERG,
				"%s: null rxring ptr\n", __func__);
		return -1;
	}
	spin_lock_bh(&fp->rx_lock);

	rxbd = fp_deque_bd(rxring, &wb_buflen);
	if (rxbd != NULL)
	{
		FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO,
				"RX Count: %u\n", ++rx_count);
		/* Get the curr rx bd buf length */
		len = wb_buflen;
		wb_buflen = 0;
		/* Get the curr rx bd index */
		curr_bd_index = fp_get_curr_bd_index(rxring, rxbd);
		/* Get the virtual address of the frame */
		ptr = (uint8 *)((uint32)rxring->bd_buff_va +
					(curr_bd_index * MAX_FRAME_SIZE));
		FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO,
			 "LEN: %u index %d rxbd %px rx_buf_ptr %px\n",
				len, curr_bd_index, rxbd, ptr);
		/* Fetching more will not hurt */
		#if 0
		memcpy(skb->data, ptr, len);
		#else
		//platform_memcpy_sw(skb->data, ptr, len);
		/* Skip Rx Header */
		platform_memcpy_sw(buffer, ptr+FP_RX_HDR_LEN, len-FP_RX_HDR_LEN);
		#endif
		#ifdef TC_DEBUG_PACKET_DATA
		printk("[%s] dump packet buffer\n", __func__);
		dump_byte(buffer, len-FP_RX_HDR_LEN);
		#endif

		receive_size = len-FP_RX_HDR_LEN;

		//skb_put(skb, len);
		//skb->dev = fp->dev;
		//fp->netstats.rx_bytes += skb->len;
		//fp_process_rx_header(skb);
		//fp->netstats.rx_packets++;
		/* Enable per packet receive interrupt */
		{
			/* workaround to avoid unhandled page fault error */
			#if 1
			struct bd temp_bd;
			struct bd *local_rxbd = &temp_bd;
			platform_memcpy_sw(local_rxbd, rxbd, sizeof(struct bd));
			local_rxbd->bd_ctrl = 0;
			local_rxbd->bd_buflen = MAX_FRAME_SIZE;
			local_rxbd->bd_ctrl = BD_CTRL_PKT_INT_EN | BD_CTRL_CBD_INT_EN |
					BD_CTRL_DIR;
			platform_memcpy_sw(rxbd, local_rxbd, sizeof(struct bd));
			#else
			rxbd->bd_ctrl = 0;
			rxbd->bd_buflen = MAX_FRAME_SIZE;
			rxbd->bd_ctrl = BD_CTRL_PKT_INT_EN | BD_CTRL_CBD_INT_EN |
					BD_CTRL_DIR;
			#endif
		}
		/* enqueue the above rx free bd to hardware freebd list*/
		ret = fp_enque_bd(rxring, rxbd);
		if (ret < 0) {
			FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_EMERG,
					"rx bd not avail this should"
					"never happen\n");
			//break;
		}
	}
	else
	{

		/* init the DMA */
		rx_ctrl = RegRead(
					(uint32)&regs->ch[ch_index].hif_ctrl_ch);
		rx_ctrl |= HIF_CH_RX_CTRL_DMA_EN;
		RegWrite((uint32)&regs->ch[ch_index].hif_ctrl_ch, rx_ctrl);
		rx_ctrl = RegRead(
				(uint32)&regs->ch[ch_index].hif_rx_ch_start);
		rx_ctrl |= HIF_CH_RX_START;
		RegWrite((uint32)&regs->ch[ch_index].hif_rx_ch_start, rx_ctrl);
		/* Re-Enable interrupts */
		RegWrite((uint32)&regs->ch[ch_index].hif_ch_int_en,
				HIF_CH_INT_EN | HIF_CH_RXPKT_INT_EN |
				HIF_CH_TXPKT_INT_EN);
	}
	spin_unlock_bh(&fp->rx_lock);

	return receive_size;
}

/* return :
	0 : success
	-1 : tx_busy = queue full
	-2 : not enough room for header
*/
int32a fp_send_ethframe(void *fpHandle, uint8 *buffer, uint16 size)
{
	struct fp_private *fp = (struct fp_private *)fpHandle;
	int32a tx_ctrl, ret = 0;
	volatile struct hif_regs *regs;
	struct bd_ring *txring;
	struct bd *txbd;
	uint32a pkt_len, curr_bd_index = 0;
	uint8 *ptr, *ptr1;
	//struct tx_header txhdr;
	uint32a hif_index = 0;
	uint32a ch_index = DEFAULT_HIF_CHANNEL;

	spin_lock_bh(&fp->lock);

	regs = fp->hif[hif_index].regs;
	txring = fp->hif[hif_index].ch[ch_index].txring;

	/* check for free tx bd avail or not */
	txbd = fp_get_next_free_bd(txring);
	if (txbd == NULL) {
		printk("Tx Queue Full\n");
		spin_unlock_bh(&fp->lock);
		return (-1);
	}
	/* get curr bd index */
	curr_bd_index = fp_get_curr_bd_index(txring, txbd);
	FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO, "BD Index %d buff_va %p\n",
					curr_bd_index, txring->bd_buff_va);
	/* Get the virtual address of the frame */
	ptr1 = (uint8 *)(txring->bd_buff_va);
	ptr =  ptr1 + (curr_bd_index * MAX_FRAME_SIZE);

	/* Prepend the tx header to transmit packet */
	/* TSNC note : temporary, fill zero. Later, fp_add_prepend_tx_header() could be invoked. */
	platform_memset(ptr, 0x0, FP_TX_HDR_LEN);
	/* copy packet data into dma buffer */
	platform_memcpy(ptr + FP_TX_HDR_LEN, buffer, size);
	pkt_len = FP_TX_HDR_LEN + size;

	/* update the ctrl word necessary proper bd flags */
	txbd->bd_ctrl |= (BD_CTRL_PKT_INT_EN | BD_CTRL_CBD_INT_EN | BD_CTRL_LIFM);
	txbd->bd_buflen = pkt_len;

	/* enqueue bd to hardware */
	ret = fp_enque_bd(txring, txbd);
	if (ret < 0) {
		FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO,
			"tx bd not avail this should never happen\n");
	}

#ifdef TC_DEBUG_PACKET_DATA
		printk("[%s] dump &txbd[%d] = %px\n", __func__, curr_bd_index, &txbd[curr_bd_index]);
		dump_mem((uint8*)txbd, 0x10);
		dump_byte((uint8*)txbd, 0x10);
		printk("ctrl	%x seqnum  %x\n",txbd->bd_ctrl, txbd->bd_seqnum);
		printk("buflen	%x rsvd    %x\n",txbd->bd_buflen, txbd->rsvd);
		printk("bufaddr %x nextptr %x\n",txbd->bd_bufaddr,txbd->bd_nextptr);

	#if 1
		printk("[%s] dump packet buffer\n", __func__);
		dump_byte(ptr, pkt_len);
	#endif
#endif

	tx_ctrl = RegRead((uint32)&regs->ch[ch_index].hif_ctrl_ch);
	tx_ctrl |= HIF_CH_TX_BDP_POLL_CNTR_EN;
	tx_ctrl |= HIF_CH_TX_CTRL_DMA_EN;
	RegWrite((uint32)&regs->ch[ch_index].hif_ctrl_ch, tx_ctrl);
	tx_ctrl = HIF_CH_TX_START;
	RegWrite((uint32)&regs->ch[ch_index].hif_tx_ch_start, tx_ctrl);
	//fp->netstats.tx_packets++;
	//fp->netstats.tx_bytes += pkt_len;
	spin_unlock_bh(&fp->lock);

	return 0;
}

void fp_tx_tasklet(uint32 data)
{
	#if 0
	//struct tasklet_data *txptr = (struct tasklet_data *)data;
	#else
	struct tasklet_data *txptr = &fp_tx_info[0][DEFAULT_HIF_CHANNEL];
	#endif
	struct fp_private *fp = (struct fp_private *)txptr->fp;
	struct bd_ring *txring;
	struct bd *txbd;
	uint32a wb_buflen = 0;
	uint32a hif_index = txptr->hif_index;
	uint32a ch_index = txptr->ch_index;

	//struct netdev_queue *queue = netdev_get_tx_queue(fp->dev, ch_index);
	FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO,
			"TX Tasklet: hif_index %u ch_index %d\n",
			hif_index, ch_index);
	/* hif_index = 0; ch_index = 0; */
	txring = fp->hif[hif_index].ch[ch_index].txring;
	if (txring == NULL) {
		FP_DEBUG(DBGP_FEAT_ERR, FP_LOG_EMERG,
			"%s: null txring ptr\n", __func__);
		return;
	}

	spin_lock_bh(&fp->lock);
	while (1) {
		/* Process tx write back bds upon tx interrupt */
		txbd = fp_deque_bd(txring, &wb_buflen);
		if (txbd == NULL) {
			//FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO,
			//	"TX wb bd not ready\n");
			break;
		}
		//if (netif_tx_queue_stopped(queue))
		//	netif_tx_wake_queue(queue);
	}
	RegWrite(
		(uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_ch_int_en,
				HIF_CH_INT_EN | HIF_CH_RXPKT_INT_EN |
				HIF_CH_TXPKT_INT_EN);
	spin_unlock_bh(&fp->lock);
}



#if 1
int32a fp_interrupt(void *fpHandle)
{
	int32a packet_int_flag = 0;
	struct fp_private *fp = (struct fp_private *)fpHandle;
	struct hif_base *hif = &fp->hif[0];
	volatile struct hif_regs *regs = hif->regs;
	uint32a hif_index = 0;
	uint32a hif_int_src = RegRead((uint32)&regs->hif_int_src);

	if(hif_int_src&(1<<HIF_CHNUM_NP))
	{
		//printk("recvd hif interrupt \n");
		/* Handle hif interrupt, if interrupt source is set */
		for (hif_index = 0; hif_index < NUM_TOTAL_HIF; hif_index++) {
			packet_int_flag = handle_hif(&fp->hif[hif_index]);
		}
	}
	platform_clear_interrupt();
	return packet_int_flag;
}

#else
irqreturn_t fp_interrupt(int32a irq, void *dev)
{
	struct fp_private *fp = (struct fp_private *)netdev_priv(dev);
	struct hif_base *hif = &fp->hif[0];
	volatile struct hif_regs *regs = hif->regs;
	uint32a hif_index = 0;
	uint32a safety_src = RegRead(WSP_SAFETY_INTERRUPT_SOURCE);
	uint32a fs_src = RegRead(WSP_FAILSTOP_INTERRUPT_SOURCE);
	uint32a hif_int_src = RegRead((uint32)&regs->hif_int_src);
	uint32a gpt_status = RegRead(0x60cc04);
	uint32a gpt2_status = RegRead(0x60ce04);


	if (gpt_status & 0x1)
	{
		printk("recvd gpt interrupt \n");
		//fp_send_ccm_frame((struct net_device *)dev, 2);
		RegWrite(0x60cc04,  0x101);
		return IRQ_HANDLED;
	}
	if (gpt2_status & 1)
	{
		printk("recvd gpt2 interrupt \n");
		//printk("received gpt2 interrupt \n");
		RegWrite(0x60ce04,  0x101);
		return IRQ_HANDLED;
	}
	if(hif_int_src)
	{
		//printk("recvd hif interrupt \n");
		/* Handle hif interrupt, if interrupt source is set */
		for (hif_index = 0; hif_index < NUM_TOTAL_HIF; hif_index++)
			handle_hif(&fp->hif[hif_index]);
	}
	if (safety_src || fs_src)
	{
		printk("recvd safety interrupt \n");
		/* Handle safety interrupt, if src is set */
		fp_handle_safety_interrupt(fp);
	//	return IRQ_HANDLED;
	}
	// ENSURE this is handled by the platform.c source module
	platform_clear_interrupt();
	return IRQ_HANDLED;
}
#endif

static int32a handle_hif(struct hif_base *hif)
{
	uint32a ch_index = 0;
	volatile struct hif_regs *regs = hif->regs;
	uint32a hif_int_src = RegRead((uint32)&regs->hif_int_src);
	int32a packet_int_flag = 0;

	/* return if interrupt is not ours */
	if( (hif_int_src&(1<<HIF_CHNUM_NP)) == 0)
	{
		return packet_int_flag;
	}

	/* disable all hif channel interrupts */
	fp_disable_hif_ch_interrupts(hif);

	ch_index = HIF_CHNUM_NP; //for (ch_index = 0; ch_index < NUM_HIF_CHANNELS; ch_index++)
	{
		if (hif_int_src & (HIF_CH_INT << ch_index)) {
			packet_int_flag = handle_channel(hif, ch_index);
		}
	}

	/* enable all hif channel interrupts */
	fp_enable_hif_ch_interrupts(hif);
	RegWrite((uint32)&regs->hif_int_src, (1<<HIF_CHNUM_NP));
	return packet_int_flag;
}

/* return : 1 : rxpkt_int received */
/*          0 : no received packet */
static int32a handle_channel(struct hif_base *hif, uint32a ch_index)
{
	int32a packet_int_flag = 0;
	volatile struct hif_regs *regs = hif->regs;
	uint32a hif_ch_int_src = RegRead(
		(uint32)&regs->ch[ch_index].hif_ch_int_src);

	if (hif_ch_int_src & HIF_CH_RXPKT_INT) {
		FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO,
			"%s: RX: GOT CALLED, INTSRC IS 0x%x\n",
			  __func__, hif_ch_int_src);
		fpGlobal->num_hif_rx_interrupts++;
		packet_int_flag |= 0x1;
		/* Schedule the deferred intr processing routine */
		#ifdef __linux__
		tasklet_schedule(&hif->ch[ch_index].rx_tasklet);
		#endif
	}
	if (hif_ch_int_src & HIF_CH_TXPKT_INT) {
		FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO,
			"%s: TX: GOT CALLED, INTSRC IS 0x%x\n",
			__func__, hif_ch_int_src);
		fpGlobal->num_hif_tx_interrupts++;
		#ifdef __linux__
		tasklet_schedule(&hif->ch[ch_index].tx_tasklet);
		//#else
		//fp_tx_tasklet((uint32)&fp_tx_info[0][ch_index]);
		#endif
		packet_int_flag |= 0x2;
	}
	/* Clear ch[ch_index] interrupt register */
	RegWrite((uint32)&regs->ch[ch_index].hif_ch_int_src,
		hif_ch_int_src);

	return packet_int_flag;
}

void fp_disable_hif_ch_interrupts(struct hif_base *hif)
{
	uint32a ch_index = 0;
	volatile struct hif_regs *regs = hif->regs;

	ch_index = HIF_CHNUM_NP; //for (ch_index = 0; ch_index < NUM_HIF_CHANNELS; ch_index++)
	{
		RegWrite((uint32)&regs->ch[ch_index].hif_ch_int_en, 0);
	}
}

void fp_enable_hif_ch_interrupts(struct hif_base *hif)
{
	uint32a ch_index = 0;
	volatile struct hif_regs *regs = hif->regs;

	ch_index = HIF_CHNUM_NP; //for (ch_index = 0; ch_index < NUM_HIF_CHANNELS; ch_index++)
	{
		RegWrite((uint32)&regs->ch[ch_index].hif_ch_int_en,
		(HIF_CH_INT_EN | HIF_CH_RXPKT_INT_EN | HIF_CH_TXPKT_INT_EN));
	}
}

/**********************************************************************
 * Function Name  : fp_disable_interrupts
 * Description    : clear all pending interrupts
 * Inputs
 *   Parameters   : struct fp_private *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void fp_disable_interrupts(struct fp_private *fp)
{
	uint32a  int_src;
	volatile struct hif_regs *regs;
	uint32a hif_index = 0;
	uint32a ch_index = 0;

	for (hif_index = 0; hif_index < NUM_TOTAL_HIF; hif_index++)
	{
		regs = fp->hif[hif_index].regs;
		ch_index = HIF_CHNUM_NP; //for (ch_index = 0; ch_index < NUM_HIF_CHANNELS; ch_index++)
		{
			/* disable the channel[ch_index] interrupt enable */
			RegWrite((uint32)&regs->ch[ch_index].hif_ch_int_en, 0);

			/* Clear the channel[ch_index] pending interrupt sources */
			int_src = RegRead((uint32)&regs->ch[ch_index].hif_ch_int_src);
			RegWrite((uint32)&regs->ch[ch_index].hif_ch_int_src, int_src);
		}
	}
	FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_INFO,
				"%s: int_src is 0x%x\n", __func__, int_src);
}

void fp_enable_interrupts(struct fp_private *fp)
{
	volatile struct hif_regs *regs;
	uint32a hif_index = 0;
	uint32a ch_index = 0;

	for (hif_index = 0; hif_index < NUM_TOTAL_HIF; hif_index++) {
		regs = fp->hif[hif_index].regs;
		ch_index = HIF_CHNUM_NP; //for (ch_index = 0; ch_index < NUM_HIF_CHANNELS; ch_index++)
		{
			/* Enable all hif channel interrupts */
			RegWrite((uint32)&regs->ch[ch_index].hif_ch_int_en,
				(HIF_CH_INT_EN | HIF_CH_RXPKT_INT_EN |
				HIF_CH_TXPKT_INT_EN));
		}
	}
}

#if 1
void fp_init_rx_tasklet(struct fp_private *fp)
{
	uint32a hif_index = 0;
	uint32a ch_index = 0;

	for (hif_index = 0; hif_index < NUM_TOTAL_HIF; hif_index++) {
		for (ch_index = 0; ch_index < NUM_HIF_CHANNELS; ch_index++) {
			fp_rx_info[hif_index][ch_index].fp = fp;
			fp_rx_info[hif_index][ch_index].hif_index = hif_index;
			fp_rx_info[hif_index][ch_index].ch_index = ch_index;
			#ifdef __linux__
			tasklet_init(&fp->hif[hif_index].
				ch[ch_index].rx_tasklet, fp_rx_tasklet,
				(uint32)&fp_rx_info[hif_index][ch_index]);
			#endif
		}
	}
}

void fp_init_tx_tasklet(struct fp_private *fp)
{
	uint32a hif_index = 0;
	uint32a ch_index = 0;

	for (hif_index = 0; hif_index < NUM_TOTAL_HIF; hif_index++) {
		for (ch_index = 0; ch_index < NUM_HIF_CHANNELS; ch_index++) {
			fp_tx_info[hif_index][ch_index].fp = fp;
			fp_tx_info[hif_index][ch_index].hif_index = hif_index;
			fp_tx_info[hif_index][ch_index].ch_index = ch_index;
			#ifdef __linux__
			tasklet_init(&fp->hif[hif_index].
				ch[ch_index].tx_tasklet, fp_tx_tasklet,
				(uint32)&fp_tx_info[hif_index][ch_index]);
			#endif
		}
	}
}
#endif

void fp_init_bdp_base_reg(struct fp_private *fp)
{
	uint32a hif_index = 0;
	uint32a ch_index = 0;

	for (hif_index = 0; hif_index < NUM_TOTAL_HIF; hif_index++) {
		ch_index = HIF_CHNUM_NP; //for (ch_index = 0; ch_index < NUM_HIF_CHANNELS; ch_index++)
		{
			/* Program the RX WRBK BD reg */
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_rx_bdp_wr_low_addr_ch,
				fp->hif[hif_index].ch[ch_index].rxring->wb_bd_tbl_pa);
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_rx_bdp_wr_high_addr_ch, 0x0);
			/* Program the RXBD reg */
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_rx_bdp_rd_low_addr_ch,
				fp->hif[hif_index].ch[ch_index].rxring->bd_tbl_pa);
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_rx_bdp_rd_high_addr_ch, 0x0);
			/* Program the TX WRBK BD reg */
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_tx_bdp_wr_low_addr_ch,
				fp->hif[hif_index].ch[ch_index].txring->wb_bd_tbl_pa);
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_tx_bdp_wr_high_addr_ch, 0x0);
			/* Program the TXBD reg */
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_tx_bdp_rd_low_addr_ch,
				fp->hif[hif_index].ch[ch_index].txring->bd_tbl_pa);
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_tx_bdp_rd_high_addr_ch, 0x0);
			/* Program the RX WRBK buff size */
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_rx_wrbk_bd_ch_buffer_size, NUM_RX_WB_DESCR);
			/* Program the TX WRBK buff size */
			RegWrite((uint32)&fp->hif[hif_index].regs->ch[ch_index].hif_tx_wrbk_bd_ch_buffer_size, NUM_TX_WB_DESCR);
		}

		/* Program the sequence num check  start in MISC reg */
		//RegWrite((uint32)&fp->hif[hif_index].regs->hif_misc, 0x1003f);
	}
}
