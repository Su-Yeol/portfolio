/*
 * fp_ing_qos.h- Ingress qos functionality
 *
 * Copyright (c) 2007-2009, Naksha Technologies, Inc.
 * Copyright (c) 2010-2012, Posedge Technologies, Inc.
 * Copyright (c) 2013-2020, Imagination Technologies Ltd.
 * All rights reserved.
 */

#ifndef _FP_ING_QOS_H_
#define _FP_ING_QOS_H_

#define		ING_QOS_MAX_WT				0x7FF
#define		ING_QOS_MAX_CLKDEV			256
#define		ING_QOS_SHIFT_BY8			8
#endif
