#include "reg_hal.h"		/* brings in "InitBaseAddr()" */
#include "platform.h"
#include "global_base_address.h"
#include "global_address_map_fpga.h"
#include "tpa_csr.h"

static int debud_reg_write=1;

#define reg_rd32(addr, data) {data = RegAbsRead(addr);}
#define reg_wr32(addr, data) { \
	if(debud_reg_write) mcu_printf("Write ADDR : %8X, DATA %08X\n", addr, data); \
	RegAbsWrite(addr,data); }

#define delay_ns(x) udelay(1)

void set_tpa_csr(void)
{
	unsigned long addr;
	unsigned int data;
	
    //DIVIDER 2,4 ENABLE & REQ
//    reg_wr32(0x46D3900C, 0xF07); // already set on serdes init

	/* Setting for GMAC 0 */
    addr = 0x46D32000;//GMAC0_DLY_CFG0
    reg_rd32(addr,data);
	data |= (0x1F<<8); // TXCLKO delay max
	data |= (1<<7);    // TXCLKI_INV = invert
    reg_wr32(addr,data);

    addr = 0x46D32008;//GMAC0_DLY_CFG2
    reg_rd32(addr,data);
    //data = data|(1<<7);//7bit 1 mask //RXCLKI_INV
    data = data&(~(1<<7));//7bit 1 clear //RXCLKI_INV //for AXON EVM
    reg_wr32(addr,data);
    
    addr = 0x46D31004;//GMAC0_CFG1 CLKEN to 1
    reg_rd32(addr,data);
    data = data|(1<<28);//28bit 1 mask
    reg_wr32(addr,data);
    
    addr = 0x46D31004;//GMAC0_CFG1 RGMII INFSEL
    reg_rd32(addr,data);
    data = data&(0xF9FFFFFF);//26,25bit 0 mask
    data = data|(1<<24);     //24 bit to 1 ==> RGMII
    reg_wr32(addr,data);
    
    addr = 0x46D31000;//GMAC0_CFG0 TR,RR enable
    reg_rd32(addr,data);
    data = data&(0xEFFFEFFF);//28bit, 12bit 0 mask
    reg_wr32(addr,data);

    addr = 0x46D31004;//GMAC0_CFG1 CLKEN to 0
    reg_rd32(addr,data);
    data = data&(0xEFFFFFFF);//28bit 0 mask
    reg_wr32(addr,data);

    addr = 0x46D31000;//GMAC0_CFG0 TxDIV, RxDIV set
    reg_rd32(addr,data);
    data = data|(1<<22);//22bit 1 mask (25:20) 0 -> 4
    reg_wr32(addr,data);

    addr = 0x46D31004;//GMAC0_CFG1 TXCLKOEN to 1
    reg_rd32(addr,data);
    data = data|(1<<16);//16bit 1 mask
    reg_wr32(addr,data);

    addr = 0x46D31004;//GMAC0_CFG1 CLKEN to 1
    reg_wr32(addr,0x11010000);

	/* Setting for GMAC 1 */
	addr = 0x46D34000;//GMAC1_DLY_CFG0
    reg_rd32(addr,data);
	data |= (0x1F<<8); // TXCLKO delay max
	data |= (1<<7);    // TXCLKI_INV = invert
    reg_wr32(addr,data);
    
    addr = 0x46D34008;//GMAC1_DLY_CFG2
    reg_rd32(addr,data);
    //data = data|(1<<7);//7bit 1 mask
    data = data&(~(1<<7));//7bit 1 clear //RXCLKI_INV //for AXON EVM
    reg_wr32(addr,data);
    
    addr = 0x46D33004;//GMAC1_CFG1 CLKEN to 1
    reg_rd32(addr,data);
    data = data|(1<<28);//28bit 1 mask
    reg_wr32(addr,data);
    
    addr = 0x46D33004;//GMAC1_CFG1 RGMII INFSEL
    reg_rd32(addr,data);
    data = data&(0xF9FFFFFF);//26,25bit 0 mask
    data = data|(1<<24);//24bit 1 mask
    reg_wr32(addr,data);
    
    addr = 0x46D33000;//GMAC1_CFG0 TR,RR enable
    reg_rd32(addr,data);
    data = data&(0xEFFFEFFF);//28bit, 12bit 0 mask
    reg_wr32(addr,data);

    addr = 0x46D33004;//GMAC1_CFG1 CLKEN to 0
    reg_rd32(addr,data);
    data = data&(0xEFFFFFFF);//28bit 0 mask
    reg_wr32(addr,data);

    addr = 0x46D33000;//GMAC1_CFG0 TxDIV, RxDIV set
    reg_rd32(addr,data);
    data = data|(1<<22);//22bit 1 mask (25:20) 0 -> 4 (9:4) 0-> 0
    reg_wr32(addr,data);

    addr = 0x46D33004;//GMAC1_CFG1 TXCLKOEN to 1
    reg_rd32(addr,data);
    data = data|(1<<16);//16bit 1 mask
    reg_wr32(addr,data);

    addr = 0x46D33004;//GMAC1_CFG1 CLKEN to 1
    reg_wr32(addr,0x11010000);

    addr = 0x46D30004;//TPA CFG swreset
    reg_wr32(addr,0x60);
    delay_ns(100);
    reg_wr32(addr,0x7f);
}
