/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          fp_bridge_table.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    bridge data strctures
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifndef  _FP_BRIDGE_TABLE_H_
#define  _FP_BRIDGE_TABLE_H_

#include <linux/if_ether.h>

#include "fp_types.h"
#include "fp_pktbuff.h"
#include "nc_conf.h"

#define FP_MAX_BRIDGE_GROUP_NAME    16
#define FP_MAX_BRIDGE_GROUPS        (MAX_PHY_PORTS * MAX_LOGICAL_IFS)
#define FP_BRIDGE_GROUP_INVALID  -1
#define FP_BR_LKUP_SENT_PKT_HOST    2

typedef struct fp_mac_address_s{
	/*uint32a mac_address_lsb:32;
	uint32a mac_address_msb:16; */
	uint8	macAddr[6];
	uint32a	entry_type:2;
	uint32a	entry_addr_type:2;
	uint32a	agebit:1;
	uint32a	portmask:6;
	uint32a	priority:3;
	uint32a	reserved:2;
}fp_mac_addr_t;
/* Bridge entry structure */
typedef struct fp_br_entry_s {
	/* bridge filtering related information */
	void		*pPhyPort;
	void		*pIfPort;
	fp_mac_addr_t 	macEntry;
	uint16 vlanId;
	/* actions to be done on the packet and related info */
	uint8	flowActionFlags;
	uint8	entryState;
	uint32a	pktCount;
	uint32a	egrPort;
	struct fp_br_entry_s *next;
}fp_bridgeEntry_t;

/* Bridge Table structure */
typedef struct fp_bridgeTable_s {
	int32a tbl_size;			/* size of the table */
	int32a num_entries;		/* number of entries in this table */
	//int32a refcnt;			/* number of references to this table */
	fp_bridgeEntry_t **table;	/* table elements */
}fp_bridgeTable_t;
/* VLan header */
typedef struct vlanEthhdr_s {
	uint8 h_dest[ETH_ALEN];		/* destination eth addr */
	uint8 h_source[ETH_ALEN];	/* source ether addr */
	uint16 h_vlan_proto;		/* Should always be 0x8100 */
	uint16 h_vlan_TCI;		/* Encapsulates priority and VLAN ID */
	uint16 h_vlan_encap_proto;	/* pkt type ID field (or len) */
}vlanEthhdr_t;

/**/
extern fp_bridgeTable_t *fp_bridge_hash_table;

/* create a bridge hash table*/
extern void fp_create_bridge_table(int32a tbl_size);

/* add bridge table entry for to hash table */
extern int32a
fp_add_bridge_table_entry(	uint16 in_usHashValue,
				fp_bridgeEntry_t *in_Entry,
				fp_bridgeTable_t *in_hashTable, pktBuf_t *);

extern fp_bridgeEntry_t *fp_search_bridge_table_entry (	fp_bridgeEntry_t *inEntry,
							fp_bridgeTable_t *brTable);

/* delete bridge table entry from hash table */
extern int32a fp_delete_bridge_table_entry(uint16 in_usHashValue,
					fp_bridgeEntry_t *in_Entry,
					fp_bridgeTable_t *,int32a);

 /*delete bridge table */
extern void fp_delete_bridge_table(fp_bridgeTable_t *bridge_table, int32a);
extern void fp_delete_vlan_bridge_table (fp_bridgeTable_t *vlan_table, int32a );
void fp_bridge_learn_mac(	fp_bridgeEntry_t *addBridgeEntry,
				fp_bridgeTable_t *brTable,
				pktBuf_t *pkt_buff);

void fp_bridge_flood_packet(pktBuf_t* pkt);

extern void fp_add_static_bridge_tables (void);
extern int32a fp_add_dev_promisc(int8 *name, uint32a pidx, uint32a ifidx);
extern int32a fp_bridge_lookup(pktBuf_t *pkt_buff);

int32a updateBridgeEntry(fp_bridgeEntry_t *srcEntry,  nc_bridge_entry_t *br_entry);

#endif /*End of _FP_BRIDGE_TABLE_H_*/


