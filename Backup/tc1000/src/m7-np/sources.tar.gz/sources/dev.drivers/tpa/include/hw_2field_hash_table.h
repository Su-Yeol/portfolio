/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
@File
@Title          hw_2field_hash_table.h
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    API for hash table
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#ifndef  _HW_HASH_TABLE_H_
#define  _HW_HASH_TABLE_H_

#include "fp_global_addr_map.h"
#include "tables_config.h"

/* HW MAC TABLE CMDS */
#define CMD_INIT	1
#define CMD_ADD		2
#define CMD_DEL		3
#define CMD_UPDATE	4
#define CMD_SEARCH	5
#define CMD_MEM_READ	6
#define CMD_MEM_WRITE	7
#define CMD_FLUSH	8

#define CLR_STATUS_REG         0xFFFFFFFF
/* ----------------------------------------------------*/
//* moved to config/N4900R22p*/include/tables_config.h */
//#define TWO_FIELD_HASH_ENTRIES     0x200
//#define TWO_FIELD_COLL_ENTRIES     0x200
//#define TWO_FIELD_INIT_HEAD_PTR    0x200
//#define TWO_FIELD_INIT_TAIL_PTR    0x3FF
/* ----------------------------------------------------*/


/* 2-filed mac table valid defines */
#define BIT_SET_MAC_2F_MACTBL     0x00000100
#define BIT_SET_VLAN_2F_MACTBL    0x00000200

/*!
 Initialize hardware MAC hash table.

 @param wsp_base_addr       base address of the WSP registers
 **/
extern void hw_hash_table_init(uint32a table_num);

/*!
 Search the table for a MAC address

 @param wsp_base_addr       base address of the WSP registers
 @param field_entries       MAC,VLAN to search for (see format below)
 @param field_valids        field valid flags (see format below)
 @return                    32-bit brentry (see format below)

 @code
        MAC/VLAN fields parameter format

===================================================
          |  31:24  |  23:16  |  15:8   |   7:0   |
===================================================
fields[0] |     first 4 bytes of MAC adddress     |
===================================================
fields[1] |    VLAN [11:0]    |  last 2 bytes MAC |
===================================================
fields[2] |    unused (set to zero)               |
===================================================
fields[3] |    unused (set to zero)               |
===================================================
fields[4] |    unused (set to zero)               |
===================================================
 @endcode

 The field valid flags is a bit-coded integer which indicates which of
 the MAC/VLAN fields have been populated to do the hash search.

 BIT_SET_MAC_2F_MACTBL when set, means the MAC field is populated
 BIT_SET_VLAN_2F_MACTBL when set, means the VLAN field is populated

 An 802.1Q switch, when operating in IVL mode, will set both flags.
 A switch operating in SVL mode will set only the MAC flag.

 @code
    MAC Hash table brentry (action entry) format

   [07:00]           - forward port list
   [10:8]            - TC
   [13:11]           - fwd_action (ACTION FIELD)
   [28:14]           - Reserved
   [29]              - fresh
   [30]              - static
 @endcode
 **/
extern int32a hw_hash_table_search(uint32a field_entries[5], uint32a field_valids);

/*!
 Add a MAC address to the table

 @param wsp_base_addr       base address of the WSP registers
 @param fields              MAC,VLAN to add (see hw_hash_table_search())
 @param iport               input port number
 @param brentry             action entry (see hw_hash_table_search())
 @param field_valids        hash based on MAC address or VLAN or both
 @return status code:       0=success, -1=failure
 **/
extern int32a hw_hash_table_add(uint32a fields[5],
				uint32a iport,
				uint32a brentry,
				uint32a field_valids);

/*!
 Delete a MAC address from the table

 @param wsp_base_addr       base address of the WSP registers
 @param entry1              same as fields[0]  (see hw_hash_table_search())
 @param entry2              same as fields[1]  (see hw_hash_table_search())
 @return status code:       0=success, -1=failure
 **/
extern int32a hw_hash_table_delete(uint32a entry1, uint32a entry2);

/*!
 Update an existing MAC address entry

 @param wsp_base_addr       base address of the WSP registers
 @param field_entries       MAC,VLAN entry to update (see hw_hash_table_search())
 @param brentry             action entry (see hw_hash_table_search())
 @param field_valids        field valid flags (see hw_hash_table_search())
 @return status code:       0=success, -1=failure
 **/
extern int32a hw_hash_table_update(uint32a field_entries[5], uint32a brentry, uint32a field_valids);

void proc_SetHifnum(uint32a num);
uint32a proc_GetHifnum(void);
int32a proc_GetHifCounts(uint32a *cnt_array);

#endif /*End of _HW_HASH_TABLE_H_*/

