/*
 * Copyright Telechips Inc.
 *
 * TCC Version 1.0
 *
 * This source code contains confidential information of Telechips.
 *
 * Any unauthorized use without a written permission of Telechips including not
 * limited to re-distribution in source or binary form is strictly prohibited.
 *
 * This source code is provided "AS IS" and nothing contained in this source code
 * shall constitute any express or implied warranty of any kind, including without
 * limitation, any warranty of merchantability, fitness for a particular purpose
 * or non-infringement of any patent, copyright or other third party intellectual
 * property right.
 * No warranty is made, express or implied, regarding the information's accuracy,
 * completeness, or performance.
 *
 * In no event shall Telechips be liable for any claim, damages or other
 * liability arising from, out of or in connection with this source code or
 * the use in the source code.
 *
 * This source code is provided subject to the terms of a Mutual Non-Disclosure
 * Agreement between Telechips and Company.
 */

#include <string.h>
#include "tpa_drv.h"
#include "platform.h"
#include "fp_hif_reg.h"
#include "fp_net_driver.h"
#include "tpautil.h"
#include "xpcs_define.h"
#include "MRVL_MVQ3244_API.h"

/****************************************
 *		  Variable Definitions			*
 ****************************************/
#define ENABLE_INTERRUPT_SERVICE

#define TPA_INTPOLL_TASK_PROIRITY  (SAL_PRIO_IPC_CONTROL) // give same priority as IPC control, no reason
#define TPA_INTPOLL_TASK_STACK_SIZE	(1024)
static uint32 TpaIntPollTaskStack[TPA_INTPOLL_TASK_STACK_SIZE];

#define TPA_TXPOSTPROCESS_TASK_PROIRITY  (SAL_PRIO_IPC_CONTROL) // give same priority as IPC control, no reason
#define TPA_TXPOSTPROCESS_TASK_STACK_SIZE	(1024)
static uint32 TpaTxPostProcessTaskStack[TPA_TXPOSTPROCESS_TASK_STACK_SIZE];

typedef struct
{
	void *fpHandle;
	uint32 TpaIntPollTaskId;
	TaskHandle_t appRxTaskHandler;

	uint32 TpaTxPostProcessTaskId;
	TaskHandle_t tpaTxPostProcessTaskHandler;
	uint32 fTPAReady;
} TPA_Inst_t;

static TPA_Inst_t stTPAInst;
static TPA_Inst_t *pTPAInst = &stTPAInst;


/***************************************************
*          Local function prototypes               *
****************************************************/

/***************************************************
*			function definition				       *
****************************************************/
static void tpa_tx_post_process_task(void *pArg)
{
	TPA_Inst_t *tpa_inst = (TPA_Inst_t *)pArg;
	//void *fpHandle = (void *)tpa_inst->fpHandle;
	int task_run_flag=1;

	tpa_inst->tpaTxPostProcessTaskHandler = xTaskGetCurrentTaskHandle();
	pTPAInst->fTPAReady = 1;
	while(task_run_flag)
	{
		ulTaskNotifyTake( pdTRUE, portMAX_DELAY );
		//TPA_D("receive tx signal.\n");
		fp_tx_tasklet(0);
	}
}


#ifndef ENABLE_INTERRUPT_SERVICE
/* TSNC note : Interrupt polling task (temporary code for FPGA test) */
static void tpa_int_poll_task(void *pArg)
{
	TPA_Inst_t *tpa_inst = (TPA_Inst_t *)pArg;
	void *fpHandle = (void *)tpa_inst->fpHandle;
	int32a packet_int_flag;

	while(1)
	{
		//TPA_D("check interrupt\n");
		packet_int_flag = fp_interrupt(fpHandle);
		if( (packet_int_flag&0x1)!=0 )
		{
			/* signal */
			//TPA_D("Poll : incoming packet!\n");
			if(tpa_inst->appRxTaskHandler != NULL) {
				(void)xTaskNotifyGive(tpa_inst->appRxTaskHandler);
			}
		}
		if( (packet_int_flag&0x2)!=0 )
		{
			//TPA_D("Poll : Tx post process!\n");
			if(tpa_inst->tpaTxPostProcessTaskHandler != NULL) {
				(void)xTaskNotifyGive(tpa_inst->tpaTxPostProcessTaskHandler);
			}
		}

		/* sleep or yield */
		(void) SAL_TaskSleep(10);
	}

}
#endif

#ifdef ENABLE_INTERRUPT_SERVICE
static void tpa_irq_handler(void)
{
	TPA_Inst_t *tpa_inst = (TPA_Inst_t *)pTPAInst;
	void *fpHandle = (void *)tpa_inst->fpHandle;
	BaseType_t xHigherPriorityTaskWoken = pdFALSE;
	int32a packet_int_flag; /*bit[1]=tx_int, bit[0]=rx_int */

	(void)fpHandle;

	packet_int_flag = fp_interrupt(fpHandle);
	if( (packet_int_flag&0x1)!=0 )
	{
		/* signal */
		//TPA_D("incoming packet!\n");
		if(tpa_inst->appRxTaskHandler != NULL) {
			(void)vTaskNotifyGiveFromISR(tpa_inst->appRxTaskHandler, &xHigherPriorityTaskWoken);
		}
	}

	if( (packet_int_flag&0x2)!=0 )
	{
		if(tpa_inst->tpaTxPostProcessTaskHandler != NULL) {
			(void)vTaskNotifyGiveFromISR(tpa_inst->tpaTxPostProcessTaskHandler, &xHigherPriorityTaskWoken);
		}
	}
}

static eTPA_RET_t tpa_request_irq(void)
{
	eTPA_RET_t ret = (int32)eTPA_RET_OK;
	SALRetCode_t sal_ret;

	sal_ret = NVIC_IntVectSet(TPA_EPP_INT1_IRQn, (IrqHandler_t)&tpa_irq_handler);
	if(sal_ret != SAL_RET_SUCCESS) {
		TPA_E("Failed to set IRQ handler\n");
		ret = (int32)eTPA_RET_ERROR_INT_REG_HANDLER;
	}
	else {
		TPA_D("Success to register handler.\n");
		sal_ret = NVIC_IntSrcEn(TPA_EPP_INT1_IRQn);
		if(sal_ret != SAL_RET_SUCCESS) {
			TPA_E("Failed to enable IRQ.\n");
			ret = (int32)eTPA_RET_ERROR_INT_ENABLE;
		}
		else {
			TPA_D("Success to enable IRQ\n");
		}
	}

	return ret;
}
#endif

/* allocate H/W resource, initialize */
eTPA_RET_t tpa_init(void)
{
	eTPA_RET_t ret = (int32)eTPA_RET_OK;

	pTPAInst->fTPAReady=0;
	pTPAInst->TpaIntPollTaskId = 0;
	pTPAInst->TpaTxPostProcessTaskId = 0;
	pTPAInst->appRxTaskHandler = NULL;
	pTPAInst->fpHandle = 0;

	platform_init();
	fp_net_init();

	return ret;
}

/* release H/W resource */
eTPA_RET_t tpa_deinit(void)
{
	eTPA_RET_t ret = (int32)eTPA_RET_OK;

	return ret;
}

eTPA_RET_t tpa_open(TaskHandle_t appRxTaskHandler)
{
	eTPA_RET_t ret = (int32)eTPA_RET_OK;
	SALRetCode_t sal_ret;

	/* TSNC note : avoid warning : defined but not used */
	(void)sal_ret;
	(void)TpaIntPollTaskStack;

	pTPAInst->appRxTaskHandler = appRxTaskHandler;

	/* init EPP */
	pTPAInst->fpHandle = fpGlobal;

	//mcu_printf("[%s] wait for main init\n", __func__);
	wait_init_done_signal_to_main_ap();
	mcu_printf("[%s] received done signal.\n", __func__);

	fp_net_open();

	/* init MAC/PHY */

#ifdef ENABLE_INTERRUPT_SERVICE
	/* register interrupt handler */
	ret = tpa_request_irq();
#else
	/* create task for interrupt polling */
	sal_ret = SAL_TaskCreate( &pTPAInst->TpaIntPollTaskId, \
	                          (const uint8 *)"TPAIntPollTask", \
                             (SALTaskFunc)&tpa_int_poll_task, \
                             &(TpaIntPollTaskStack[0]), \
                             (uint32)TPA_INTPOLL_TASK_STACK_SIZE, \
                             TPA_INTPOLL_TASK_PROIRITY, \
                             (void*)pTPAInst );
	if(sal_ret!=SAL_RET_SUCCESS)
	{
		TPA_E("Create TPAIntPoll Task : FAIL.\n");
		ret = (int32)eTPA_RET_FAIL_TO_CREATE;
	}
#endif

	/* create task for post processing of tx packet */
	sal_ret = SAL_TaskCreate( &pTPAInst->TpaTxPostProcessTaskId, \
	                          (const uint8 *)"TPATxPostProcessTask", \
                             (SALTaskFunc)&tpa_tx_post_process_task, \
                             &(TpaTxPostProcessTaskStack[0]), \
                             (uint32)TPA_TXPOSTPROCESS_TASK_STACK_SIZE, \
                             TPA_TXPOSTPROCESS_TASK_PROIRITY, \
                             (void*)pTPAInst );
	return ret;
}

eTPA_RET_t tpa_close(void)
{
	eTPA_RET_t ret = (int32)eTPA_RET_OK;

	return ret;
}

eTPA_RET_t tpa_write(uint8 *buffer, uint16 size)
{
	eTPA_RET_t ret = (int32)eTPA_RET_OK;
	int32a tx_result;

	(void)tx_result;
	if(pTPAInst->fTPAReady != 1)
	{
		mcu_printf("[%s] TPA not ready. discard %d byte!\n", __func__, size);
		return ret;
	}

	if(buffer==NULL)
	{
		ret = eTPA_RET_INVALID_PARAM;
	}
	else
	{
		tx_result = fp_send_ethframe(pTPAInst->fpHandle, buffer, size);
		if( tx_result<0 )
		{
			switch(tx_result)
			{
				case (-1):
					ret = eTPA_RET_NOT_ENOUGH_BUFFER;
					break;
				default:
					ret = eTPA_RET_UNKNOWN_ERROR;
					break;
			}
		}
	}

	return ret;
}

/* ret>0 : size, ret<=0 error result
   ret=0 : no more packet
   ret<0 : error status

   buffer : data buffer to get received ethernet frame
   buffer_size : size of data buffer
   read_size : pointer. received data size will be returned.

   to received all packet, call this api repeatdly until ret=0

return :
	eTPA_RET_OK : read data success, value in read_size is valid.
	eTPA_RET_NO_DATA : no data received.
	eTPA_RET_NOT_ENOUGH_BUFFER : buffer_size is not enough
*/

eTPA_RET_t tpa_read(uint8 *buffer, uint16 buffer_size, uint16 *read_size)
{
	eTPA_RET_t ret = (int32)eTPA_RET_OK;
	int32a rx_result;

	if((buffer==NULL) || (read_size==NULL))
	{
		ret = eTPA_RET_INVALID_PARAM;
	}
	else
	{
		*read_size = 0;

		rx_result = fp_receive_ethframe(pTPAInst->fpHandle, buffer, buffer_size);
		if( rx_result>0 )
		{
			*read_size = rx_result;
		}
		else if( rx_result==0 )
		{
			/* no more data */
			ret = eTPA_RET_NO_DATA;
		}
		else if( rx_result<0 )
		{
			switch(rx_result)
			{
				case (-1):
					ret = eTPA_RET_NOT_ENOUGH_BUFFER;
					break;
				default:
					ret = eTPA_RET_UNKNOWN_ERROR;
					break;
			}
		}
	}

	return ret;
}

void tpa_reg_dump_xgmac(int id)
{
	TPA_D("[%s]\n", __func__);
	dump_reg_xgmac_debug(id);
}

void tpa_reg_dump(void)
{
	TPA_D("[%s]\n", __func__);

	dump_reg_debug();
}

void tpa_serdes_reg_dump(void)
{
	SerDes_register_dump();
}

void tpa_phy_status(int num)
{

	switch(num)
	{
		case 1:
			break;
		case 2:
			break;
		case 3:
			/* 2.5G - XGMAC1 - EMAC3 */
			PHY_MVQ3244_Check(1);
			break;
		case 4:
			/* 5G - XGMAC0 - EMAC4 */
			PHY_MVQ3244_Check(0);
			break;
		default:
			TPA_D("[%s] unsupported PHY index[%d]. Should be (1~4).\n", __func__, num);
			break;
	}
	
}

