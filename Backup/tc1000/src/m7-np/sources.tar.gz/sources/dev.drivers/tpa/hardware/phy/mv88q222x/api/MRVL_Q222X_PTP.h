/**
 * @file MRVL_Q222X_PTP.h
 * @brief Q222X PTP API Header File
 * DUT PTP configuration and status checking
  *
 * @par Copyright and Version
 * See MRVL_Q222X_Copyright_and_Version.h
 */

#ifndef MRVL_Q222X_PTP_H
#define MRVL_Q222X_PTP_H

#include "MRVL_Q222X_PTPTypes.h"

/** @defgroup PTP_Top PTP control top-level group */

/******************************************************************************
 *     PTP initialization
 ******************************************************************************/
/** @defgroup PTP_INIT PTP initialization
 * @ingroup PTP_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_initPTP(MRVL_DEV_PTR device);

EXPORT_FUNC MRVL_APHY_STATUS q222x_disablePTP(MRVL_DEV_PTR device);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setPTPFixedLatency(MRVL_DEV_PTR device, MRVL_APHY_U32 fixLatency, MRVL_APHY_BOOL isPTPTx);

/******************************************************************************
 *     PTP Protocol Configuration
 ******************************************************************************/
/** @defgroup PTP_PROTOCOL PTP Protocol Configuration
 * @ingroup PTP_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_configPTP1588v2(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIME_ARRAY_INDEX taIndex, MRVL_Q222X_PTP_MODE mode, MRVL_Q222X_PTP_STEP step);

EXPORT_FUNC MRVL_APHY_STATUS q222x_configPTP8021as(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIME_ARRAY_INDEX taIndex, MRVL_Q222X_PTP_RELAY_MODE relayMode);

EXPORT_FUNC MRVL_APHY_STATUS q222x_configPTP8021as2020(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIME_ARRAY_INDEX taIndex, MRVL_Q222X_PTP_RELAY_MODE relayMode);

EXPORT_FUNC MRVL_APHY_STATUS q222x_configPTPIgrAdvTS8021as(MRVL_DEV_PTR device);

/******************************************************************************
 *     PTP TOD Operation
 ******************************************************************************/
/** @defgroup PTP_TOD_OP PTP TOD Operation
 * @ingroup PTP_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_capturePTPToD(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIME_ARRAY_INDEX taIndex, MRVL_Q222X_PTP_TIME_ARRAY* ta);

EXPORT_FUNC MRVL_APHY_STATUS q222x_storePTPToDAll(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIME_ARRAY_INDEX taIndex, MRVL_Q222X_PTP_TIME_ARRAY* ta);

EXPORT_FUNC MRVL_APHY_STATUS q222x_storePTPToDCompensation(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIME_ARRAY_INDEX taIndex, MRVL_APHY_U32 todCompensation);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getPTPToDBusyStatus(MRVL_DEV_PTR device, MRVL_APHY_BOOL* busyBit);

EXPORT_FUNC MRVL_APHY_STATUS q222x_getPTPGlobalTime(MRVL_DEV_PTR device, MRVL_APHY_U32* globalTime);

/******************************************************************************
 *    Register TimeStamp
 ******************************************************************************/
/** @defgroup REG_TIME_STAMP  PTP Register TimeStamp
 * @ingroup PTP_Top
*/
EXPORT_FUNC MRVL_APHY_STATUS q222x_getPTPTimestamp(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIMESTAMP_SELECT tsSelect, MRVL_Q222X_PTP_TIMESTAMP* ts);

EXPORT_FUNC MRVL_APHY_STATUS q222x_clearPTPTimestampValid(MRVL_DEV_PTR device, MRVL_Q222X_PTP_TIMESTAMP_SELECT tsSelect);

/******************************************************************************
 *    1PPS
 ******************************************************************************/
/** @defgroup PTP_1PPS  PTP 1PPS
 * @ingroup PTP_Top
*/

EXPORT_FUNC MRVL_APHY_STATUS q222x_getPTP1PPSControl(MRVL_DEV_PTR device, MRVL_Q222X_PTP_1PPS_CONTROL* config);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setPTP1PPSControl(MRVL_DEV_PTR device, MRVL_Q222X_PTP_1PPS_CONTROL* config);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setPTP1PPSGpioPin(MRVL_DEV_PTR device);

EXPORT_FUNC MRVL_APHY_STATUS q222x_setPTP1PPSLedPin(MRVL_DEV_PTR device);

#endif  /* defined MRVL_Q222X_PTP_H */

