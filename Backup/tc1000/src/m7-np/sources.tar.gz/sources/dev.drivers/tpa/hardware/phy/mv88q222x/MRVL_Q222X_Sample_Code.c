/**
 * @example MRVL_Q222X_Sample_Code.c
 * Sample code to show possible use cases of PHY mode and status API.
 * User should adapt based on individual system requirements.
 *
 * - Device detection sample:
 * @code
 * Sample_Code_Assign_Device_PTR
 * @endcode
 *
 * - PHY mode configuration samples:
 * @code
 * Sample_Code_Init_FixedSpeed
 * Sample_Code_Init_Autoneg
 * @endcode
 *
 * @copyright
 * Copyright (c) 2023 Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement by and between
 * Marvell and you, your employer or other entity on behalf of whom you act.
 * In the absence of such license agreement the following file is subject to
 * Marvell’s standard Limited Use License Agreement.
 */

//#include <stdio.h>
#include <stdint.h>
#include "MRVL_porting.h"
#include "MRVL_Q222X.h"
#include "reg_hal.h"
#include "MRVL_Q222X_API.h"

#define DUT_PHY_ADDR 0
#define DUT_SMI_PORT 0
#define DUT_OPMODE (MRVL_APHY_OP_SLAVE)//(MRVL_APHY_OP_MASTER)//
#define DUT_SPEED (MRVL_APHY_SPEED_1000)//(MRVL_APHY_SPEED_100)//

static MRVL_APHY_STATUS Sample_Code_readReg(MRVL_DEV_PTR phy, MRVL_APHY_U16 portAddr, uint16_t devAddr, uint16_t regAddr, uint16_t* data);
static MRVL_APHY_STATUS Sample_Code_writeReg(MRVL_DEV_PTR phy, MRVL_APHY_U16 portAddr, uint16_t devAddr, uint16_t regAddr, uint16_t data);
static MRVL_APHY_STATUS Sample_Code_wait(MRVL_DEV_PTR phy, uint16_t delayTime);
static MRVL_APHY_STATUS Sample_Code_Assign_Device_PTR(MRVL_DEV_PTR DUT);


/**
 * @brief Read out a 16-bit value from a register through SMI interface CL45.
 *
 * @param phy
 * @param portAddr port address, Q111X has single port, portAddr is equvalent to phy->phyAddr
 * @param devAddr device address/MMD (Ex: 0x07 : Auto-Neg registers)
 * @param regAddr register address within MMD
 * @param data 16-bit to write into register
 * @return MRVL_APHY_STATUS
 */
static MRVL_APHY_STATUS Sample_Code_readReg(MRVL_DEV_PTR phy, MRVL_APHY_U16 portAddr, uint16_t devAddr, uint16_t regAddr, uint16_t* data)
{
	MRVL_APHY_STATUS ret = MRVL_APHY_STATUS_OK;
	int32_t readValue;
	uint32_t emac_idx;

	(void)ret;
	/* system-dependent Implementation */
	/* e.g. *data = XMDIOReadRegister(portAddr, devAddr, regAddr); */

	/* TC configuration :
		88Q2220(1Gbps)	  : emac_idx = 1, phy_addr = 5
		88Q2220(1Gbps)	  : emac_idx = 2, phy_addr = 5   (MDIO inteface of emac2 and emac3 are tied)
		MV_Q3244(2.5Gbps) : emac_idx = 3, phy_addr = 0
		88Q5192(5Gbps,switch) : emac_idx = 4, phy_addr = ?
	*/
		emac_idx = phy->smiPort-1;
		readValue = XMdioRegRead(emac_idx, portAddr, devAddr, regAddr);
		if(readValue<0)
		{
			/* if error return MRVL_APHY_STATUS_ERROR_MDIO */
			ret = MRVL_APHY_STATUS_ERROR_MDIO;
		}
		else
		{
			*data = (uint16_t)readValue;
		}


	return MRVL_APHY_STATUS_OK;
	/* if error return MRVL_APHY_STATUS_ERROR_MDIO */
}


/**
 * @brief  Write a 16-bit value from a register through SMI interface CL45.
 *
 * @param phy
 * @param portAddr port address, Q111X has single port, portAddr is equvalent to phy->phyAddr
 * @param devAddr device address/MMD (Ex: 0x07 : Auto-Neg registers)
 * @param regAddr register address within MMD
 * @param data 16-bit to write into register
 * @return MRVL_APHY_STATUS
 */
static MRVL_APHY_STATUS Sample_Code_writeReg(MRVL_DEV_PTR phy, MRVL_APHY_U16 portAddr, uint16_t devAddr, uint16_t regAddr, uint16_t data)
{
	MRVL_APHY_STATUS ret = MRVL_APHY_STATUS_OK;
	int32_t writtenValue;
	uint32_t emac_idx;

	(void)ret;
	/* system-dependent Implementation */
	/* e.g. *data = XMDIOWriteRegister(portAddr, devAddr, regAddr); */
	emac_idx = phy->smiPort-1;
	writtenValue = XMdioRegWrite(emac_idx, portAddr, devAddr, regAddr, data);
	if(writtenValue<0)
	{
		/* if error return MRVL_APHY_STATUS_ERROR_MDIO */
		ret = MRVL_APHY_STATUS_ERROR_MDIO;
	}
	return MRVL_APHY_STATUS_OK;
}


/**
 * @brief Delay for specified number of milliseconds.
 *
 * @param phy
 * @param delayTime delay to implement
 * @return MRVL_APHY_STATUS
 */
static MRVL_APHY_STATUS Sample_Code_wait(MRVL_DEV_PTR phy, uint16_t delayTime)
{
	/* system-dependent Implementation */

	MRVL_PRINT_DEBUG("delay %dms\n", delayTime);
	udelay(10);

	return MRVL_APHY_STATUS_OK;
}


/******************************************************************************
 *      The following functions demonstrate possible use cases
 * 		of basic PHY Control API.
 ******************************************************************************/
/** @defgroup Sample_PHY Sample - PHY CTRL Demo
 * @ingroup Sample_Top
*/

/**
 * @brief Sample code before system initialization: detect device
 *
 * @param[in,out] DUT
 * @return MRVL_APHY_STATUS
 *
 * @ingroup Sample_PHY
 */
static MRVL_APHY_STATUS Sample_Code_Assign_Device_PTR(MRVL_DEV_PTR DUT)
{
	MRVL_APHY_STATUS status;
	/* 1) assign ptr */
	//DUT->smiPort = DUT_SMI_PORT; // emac number
	//DUT->phyAddr = DUT_PHY_ADDR; // phy addr
	DUT->readReg = Sample_Code_readReg;
	DUT->writeReg = Sample_Code_writeReg;
	DUT->wait = Sample_Code_wait;

	/* check device ID, rev ID and package Num */
	status = q222x_getDeviceInfo(DUT);

	MRVL_PRINT_DEBUG("modelNum : 0x%04x\n", DUT->modelNum);
	MRVL_PRINT_DEBUG("packageNum : 0x%04x\n", DUT->packageNum);
	MRVL_PRINT_DEBUG("revNum   : 0x%02x\n", DUT->revNum);

	if (status != MRVL_APHY_STATUS_OK)
	{
		MRVL_PRINT_ERROR("Unknown device. Error code %u\n", status);
	}
	else if ((DUT->revNum != MRVL_Q222X_B0) && (DUT->revNum != MRVL_Q222X_B1))
	{
		status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
		MRVL_PRINT_ERROR("Not B0 device. Error code %u\n", status);
	}
	else
	{
		switch (DUT->packageNum)
		{
		case MRVL_Q222X_PACKAGE_ID_Q2220M:
			/* MACsec */
			MRVL_PRINT_DEBUG("package : MRVL_Q222X_PACKAGE_ID_Q2220M\n");
			break;
		case MRVL_Q222X_PACKAGE_ID_Q2221M:
			/* MACsec + SGMII */
			MRVL_PRINT_DEBUG("package : MRVL_Q222X_PACKAGE_ID_Q2221M\n");
			break;
		case MRVL_Q222X_PACKAGE_ID_Q1210M:
			/* MACsec */
			break;
		case MRVL_Q222X_PACKAGE_ID_Q1211M:
			/* MACsec + SGMII */
			break;
		case MRVL_Q222X_PACKAGE_ID_Q2220:

			break;
		case MRVL_Q222X_PACKAGE_ID_Q2221:
			/* SGMII */
			break;
		case MRVL_Q222X_PACKAGE_ID_Q1210:

			break;
		case MRVL_Q222X_PACKAGE_ID_Q1211:
			/* SGMII */
			break;
		case MRVL_Q222X_PACKAGE_ID_Q2233M_P0:
			/* MACsec + SGMII + Two ports
			Current poirt is P0
			Change phyAddr to control P1
			or create seperate MRVL_DEV_PTR for P1
			*/
			break;
		case MRVL_Q222X_PACKAGE_ID_Q2233M_P1:
			/* MACsec + SGMII + Two ports
			Current poirt is P1
			Change phyAddr to control P0
			or create seperate MRVL_DEV_PTR for P0
			*/
			break;
		case MRVL_Q222X_PACKAGE_ID_Q2233_P0:
			/* SGMII + Two ports
			Current poirt is P0
			Change phyAddr to control P1
			or create seperate MRVL_DEV_PTR for P1
			*/
			break;
		case MRVL_Q222X_PACKAGE_ID_Q2233_P1:
			/* SGMII + Two ports
			Current poirt is P1
			Change phyAddr to control P0
			or create seperate MRVL_DEV_PTR for P0
			*/
			break;
		default:
			MRVL_PRINT_ERROR("Uuknown package. Error code %u\n", status);
			status = MRVL_APHY_STATUS_ERROR_NOTSUPPORT;
		}
	}
	return status;
}

/**
 * @brief Sample code during system initialization: init device and check status
 *
 * @param[in,out] DUT
 * @return MRVL_APHY_STATUS
 *
 * @ingroup Sample_PHY
 */
MRVL_APHY_STATUS Sample_Code_Init_FixedSpeed(MRVL_DEV_PTR DUT) {
	MRVL_APHY_BOOL isLinkup;
	MRVL_APHY_BOOL isMaster;
	MRVL_APHY_SPEED speed;
	MRVL_APHY_STATUS ret;

	(void)ret;
	/* 1) Call Sample_Code_Assign_Device_PTR if device has not been checked */
	ret = Sample_Code_Assign_Device_PTR(DUT);

	#if 0 
	/* 1-1) check status before init */
	MRVL_PRINT_DEBUG("\nCheck current status\n");
	q222x_checkLink(DUT, &isLinkup);
	q222x_checkIsMaster(DUT, &isMaster);
	q222x_getSpeed(DUT, &speed);
	MRVL_PRINT_DEBUG(">> Link Status: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
	q222x_getLatchedLinkStatus(DUT, &isLinkup);
	MRVL_PRINT_DEBUG(">> Latched Link Status 1: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
	q222x_getRealTimeLinkStatus(DUT, &isLinkup);
	MRVL_PRINT_DEBUG(">> Real Time Link Status: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
	q222x_getLatchedLinkStatus(DUT, &isLinkup);
	MRVL_PRINT_DEBUG(">> Latched Link Status 2: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
	MRVL_PRINT_DEBUG(">> Master/Slave: %s\n", MRVL_APHY_TRUE == isMaster ? "Master" : "Slave");
	MRVL_PRINT_DEBUG(">> Speed: %s\n", MRVL_APHY_SPEED_1000 == speed ? "GE/1000" : "FE/100");
	MRVL_PRINT_DEBUG("\nStart Init\n");
	#endif

	/* 2) apply mode */
	if (DUT_SPEED == MRVL_APHY_SPEED_1000) {
		q222x_initQ222XGe(DUT, DUT_OPMODE);
	}
	else {
		q222x_initQ222XFe(DUT, DUT_OPMODE);
	}

	/* 3) wait for linkup, 100ms */
	DUT->wait(DUT, 100);

	/* 4) check status */
	q222x_checkLink(DUT, &isLinkup);
	q222x_checkIsMaster(DUT, &isMaster);
	q222x_getSpeed(DUT, &speed);
	MRVL_PRINT_DEBUG(">> Link Status: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
	q222x_getLatchedLinkStatus(DUT, &isLinkup);
	MRVL_PRINT_DEBUG(">> Latched Link Status 1: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
	q222x_getRealTimeLinkStatus(DUT, &isLinkup);
	MRVL_PRINT_DEBUG(">> Real Time Link Status: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
	q222x_getLatchedLinkStatus(DUT, &isLinkup);
	MRVL_PRINT_DEBUG(">> Latched Link Status 2: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
	MRVL_PRINT_DEBUG(">> Master/Slave: %s\n", MRVL_APHY_TRUE == isMaster ? "Master" : "Slave");
	MRVL_PRINT_DEBUG(">> Speed: %s\n", MRVL_APHY_SPEED_1000 == speed ? "GE/1000" : "FE/100");

	if (MRVL_APHY_TRUE != isLinkup) {
		return MRVL_APHY_STATUS_ERROR_GENERAL;
	}
	return MRVL_APHY_STATUS_OK;
}


/**
 * @brief Sample code with aneg: enable device aneg and check status
 *
 * @param[in,out] DUT
 * @return MRVL_APHY_STATUS
 *
 * @ingroup Sample_PHY
 */
MRVL_APHY_STATUS Sample_Code_Init_Autoneg(MRVL_DEV_PTR DUT) {
	MRVL_APHY_BOOL isLinkup;
	MRVL_APHY_BOOL isMaster;
	MRVL_APHY_BOOL anegDone;
	MRVL_APHY_SPEED speed;
	MRVL_APHY_STATUS ret;

	(void)ret;
	/* 1) Call Sample_Code_Assign_Device_PTR if device has not been checked */
	ret = Sample_Code_Assign_Device_PTR(DUT);

	/* 2) enable aneg */
	if (DUT_SPEED == MRVL_APHY_SPEED_1000) {
		q222x_setAneg(DUT, DUT_OPMODE, MRVL_Q222X_AN_GE_ABILITY);
		/* Or advertise both speeds
		setAneg(DUT, DUT_OPMODE, MRVL_Q222X_AN_FE_ABILITY | MRVL_Q222X_AN_GE_ABILITY);
		*/
	}
	else {
		q222x_setAneg(DUT, DUT_OPMODE, MRVL_Q222X_AN_FE_ABILITY);
		/* Or advertise both speeds
		setAneg(DUT, DUT_OPMODE, MRVL_Q222X_AN_FE_ABILITY | MRVL_Q222X_AN_GE_ABILITY);
		*/
	}

	/* 3) wait for linkup, 100ms */
	DUT->wait(DUT, 100);

	/* 4) check status */
	q222x_getAnegDone(DUT, &anegDone);
	q222x_checkLink(DUT, &isLinkup);
	q222x_checkIsMaster(DUT, &isMaster);
	q222x_getSpeed(DUT, &speed);
	MRVL_PRINT_DEBUG(">> Aneg Finished: %s\n", MRVL_APHY_TRUE == anegDone ? "Yes" : "No");
	MRVL_PRINT_DEBUG(">> Link Status: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
	q222x_getLatchedLinkStatus(DUT, &isLinkup);
	MRVL_PRINT_DEBUG(">> Latched Link Status 1: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
	q222x_getRealTimeLinkStatus(DUT, &isLinkup);
	MRVL_PRINT_DEBUG(">> Real Time Link Status: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
	q222x_getLatchedLinkStatus(DUT, &isLinkup);
	MRVL_PRINT_DEBUG(">> Latched Link Status 2: %s\n", MRVL_APHY_TRUE == isLinkup ? "Up" : "Down");
	MRVL_PRINT_DEBUG(">> Master/Slave: %s\n", MRVL_APHY_TRUE == isMaster ? "Master" : "Slave");
	MRVL_PRINT_DEBUG(">> Speed: %s\n", MRVL_APHY_SPEED_1000 == speed ? "GE/1000" : "FE/100");

	if (MRVL_APHY_TRUE != isLinkup) {
		return MRVL_APHY_STATUS_ERROR_GENERAL;
	}
	return MRVL_APHY_STATUS_OK;
}

