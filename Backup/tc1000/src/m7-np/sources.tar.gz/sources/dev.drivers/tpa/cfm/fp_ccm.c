// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_ccm.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    ccm functionality implementation
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                     Include Files
 **********************************************************************/
#ifdef FP_CFM
#include <linux/version.h>
#include <linux/netdevice.h>
#include <linux/pci.h>
#include <linux/interrupt.h>
#include <linux/if_vlan.h>

#include <fp_types.h>
#include <fp_library.h>
#include <fp_macros.h>
#include "fp_global_addr_map.h"

#define CFM_VER 0

#define CFM_CCM 0x01
#define CFM_LBR 0x02
#define CFM_LBM 0x03
#define CFM_LTR 0x04
#define CFM_LTM 0x05

#define CFM_ETH_TYPE 0x8902

#define MD_NAME_CHAR_STRING 0x4
#define MA_NAME_CHAR_STRING 0x2

#define TLV_PORT_STATUS_TYPE 2
#define TLV_INTERFACE_STATUS_TYPE 4
#define TLV_END_TYPE 0

#define PS_UP 2
#define IS_UP 1


/********************** GPT1  ADDRESS MAP *************************/
#define GPT1_VERSION                            (GPT1_BASE_ADDR + 0x00)
#define GPT1_STATUS                             (GPT1_BASE_ADDR + 0x04)
#define GPT1_CONFIG                             (GPT1_BASE_ADDR + 0x08)
#define GPT1_COUNTER                            (GPT1_BASE_ADDR + 0x0C)
#define GPT1_PERIOD                             (GPT1_BASE_ADDR + 0x10)
#define GPT1_WIDTH                              (GPT1_BASE_ADDR + 0x14)

/********************** GPT2  ADDRESS MAP *************************/
#define GPT2_VERSION                            (GPT2_BASE_ADDR + 0x00)
#define GPT2_STATUS                             (GPT2_BASE_ADDR + 0x04)
#define GPT2_CONFIG                             (GPT2_BASE_ADDR + 0x08)
#define GPT2_COUNTER                            (GPT2_BASE_ADDR + 0x0C)
#define GPT2_PERIOD                             (GPT2_BASE_ADDR + 0x10)
#define GPT2_WIDTH                              (GPT2_BASE_ADDR + 0x14)

uint32a enable_ccm = 1;

int32a fp_send_frame(struct net_device *dev, uint8 *data,
                                uint32a pkt_len, uint32a port);
typedef struct
{
	uint8 type;
	uint16 len;
	uint8 status;
} __attribute__((packed)) ptlv_t;


typedef struct
{
	uint8 pre_header[16];
	uint8 dst_mac[6];
	uint8 src_mac[6];
	uint16 eth_type;
	uint8 cfm_md_level_ver;
	uint8 cfm_opcode;
	uint8 flags;
	uint8 first_tlv_off;
	uint32a seq_num;
	uint16 mep_id;
	uint8 ma_id[48];

	uint32a tx_fcf;
	uint32a rx_fcb;
	uint32a tx_fcb;
	uint32a reserved;

	ptlv_t tlv_port_status;
	ptlv_t tlv_interface_status;
	uint8 tlv_end_type;

} __attribute__((packed)) ccm_t;

#define CCM_FIRST_TLV_OFF 0x46
uint8 cfm_dst_mac[] = {0x01, 0x80, 0xc2, 0x00, 0x00, 0x33};

uint32a seq_num = 0;
//uint32a seq_num = 21113; // temp
int32a frame_ccm(ccm_t *packet)
{
	uint8 src_mac[6] = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05};
	uint8 cfm_md_level = 0x3; // 0x7;
	uint8 cfm_rdi = 0x0;
	uint8 ccm_interval = 0x4; // 1 sec
	uint8 enable_ccm_seq_num = 1;
	//uint8 enable_ccm_seq_num = 0;
	uint8 mep_id = 0x2;
	//uint8 ma_id = 0x2;
	uint8 md_name_format = MD_NAME_CHAR_STRING;
	uint8 ma_name_format = MA_NAME_CHAR_STRING;
	uint8 md_name[] = "md1";
	uint16 md_name_len = 3;
	uint8 ma_name[] = "ma1";
	uint16 ma_name_len = 3;
	uint8 port_status = PS_UP;
	uint8 interface_status = IS_UP;

	uint32a off;
	uint8 *ptr;

	memcpy(packet->dst_mac, cfm_dst_mac, 6);

	memcpy(packet->src_mac, src_mac, 6);

	packet->eth_type = htons(CFM_ETH_TYPE);

	packet->cfm_md_level_ver = CFM_VER | (cfm_md_level << 5);
	packet->cfm_opcode = CFM_CCM;

	packet->flags = (cfm_rdi << 7) | (ccm_interval & 0x7);

	packet->first_tlv_off = CCM_FIRST_TLV_OFF;
	if(enable_ccm_seq_num)
		packet->seq_num = htonl(seq_num++);
	else
		packet->seq_num = 0;
	packet->mep_id = htons(mep_id);
	ptr = packet->ma_id;

	memset(packet->ma_id, 0, sizeof(packet->ma_id));
	if(md_name_format == MD_NAME_CHAR_STRING) {
		off = 0;
		*ptr = md_name_format;
		*(ptr+1) = md_name_len;
		off +=  2;
		memcpy(ptr+off, md_name, md_name_len);
		off += md_name_len;
	}
	if(ma_name_format == MA_NAME_CHAR_STRING) {
		*(ptr+off) = ma_name_format;
		*(ptr+off+1) = ma_name_len;
		off +=  2;
		memcpy(ptr+off, ma_name, ma_name_len);
	}
	packet->tx_fcf = 0;
	packet->rx_fcb = 0;
	packet->tx_fcb = 0;
	packet->reserved = 0;

	packet->tlv_port_status.type = TLV_PORT_STATUS_TYPE;
	packet->tlv_port_status.len = htons(1);
	packet->tlv_port_status.status = port_status;

	packet->tlv_interface_status.type = TLV_INTERFACE_STATUS_TYPE;
	packet->tlv_interface_status.len = htons(1);
	packet->tlv_interface_status.status = interface_status;

	packet->tlv_end_type = TLV_END_TYPE;

	return 0;
}
int32a fp_send_ccm_frame(struct net_device *dev, uint32a port)
{
        ccm_t ccm_packet;

	if(!enable_ccm)
		return 0;

        frame_ccm(&ccm_packet);
        fp_send_frame(dev, (uint8 *)&ccm_packet, sizeof(ccm_t), port);

	return 0;
}

void fp_handle_ccm_packet(uint8 *data)
{
	ccm_t *packet = (ccm_t *)(data - 16);
	uint8 md_level;
	uint8 cfm_rdi;
	uint8 ccm_interval;
	//printk("eth_type = %x\n", packet->eth_type);
	//printk("cfm_opcode = %x\n", packet->cfm_opcode);
	if(packet->cfm_opcode == CFM_CCM) {
		md_level = packet->cfm_md_level_ver >> 5;
		cfm_rdi = ((packet->flags >> 7) & 0x1);
		ccm_interval = packet->flags & 0x7;

		printk("md_level = %x\n", md_level);
		printk("ccm_interval = %x\n", ccm_interval);
		printk("cfm_rdi = %x\n", cfm_rdi);
		printk("seq_num = %x\n", ntohl(packet->seq_num));
		printk("mep_id = %x\n", ntohs(packet->mep_id));
		if(packet->ma_id[0] == MD_NAME_CHAR_STRING) {
			uint8 md_name[48] = {0};
			uint32a len;
			len = packet->ma_id[1];
			printk("md_len = %d\n", len);
			if(len <= 46) {
				memcpy(md_name, &packet->ma_id[2], len);
				printk("md_name = %s\n", md_name);
			}
			if(packet->ma_id[len+2] == MA_NAME_CHAR_STRING) {
				uint8 ma_name[48] = {0};
				uint32a ma_len;
				ma_len = packet->ma_id[len+3];
				printk("ma_len = %d\n", ma_len);
				if(len <= 46) {
					memcpy(ma_name, &packet->ma_id[len+4], ma_len);
					printk("ma_name = %s\n", ma_name);
				}
			}
		}
	}
}


//#define GPT_PERIODIC_TIMER_VAL (15625/2)
#define GPT_PERIODIC_TIMER_VAL (15625000/2) // 1sec

void fp_ccm_init(uint8 *wsp_base_addr)
{

#if 0
	// start gpt timer 1
	CSR_REG_WRITE(wsp_base_addr, GPT1_STATUS, 0x0);
	CSR_REG_WRITE(wsp_base_addr, GPT1_PERIOD, GPT_PERIODIC_TIMER_VAL*2);
	CSR_REG_WRITE(wsp_base_addr, GPT1_WIDTH, GPT_PERIODIC_TIMER_VAL);
	CSR_REG_WRITE(wsp_base_addr, GPT1_CONFIG, 0x3d);
	//CSR_REG_WRITE(wsp_base_addr, GPT1_CONFIG, 0x1d);
	CSR_REG_WRITE(wsp_base_addr, GPT1_STATUS, 0x100);

// start gpt timer 2
	CSR_REG_WRITE(wsp_base_addr, GPT2_STATUS, 0x0);
	//CSR_REG_WRITE(wsp_base_addr, GPT2_PERIOD, 0x100000);
	//CSR_REG_WRITE(wsp_base_addr, GPT2_WIDTH, 0x50000);
	CSR_REG_WRITE(wsp_base_addr, GPT2_PERIOD, GPT_PERIODIC_TIMER_VAL*2);
	CSR_REG_WRITE(wsp_base_addr, GPT2_WIDTH, GPT_PERIODIC_TIMER_VAL);
	CSR_REG_WRITE(wsp_base_addr, GPT2_CONFIG, 0x1d);
	CSR_REG_WRITE(wsp_base_addr, GPT2_STATUS, 0x100);
#endif

}
#else
void fp_handle_ccm_packet(uint8 *data)
{
}
#endif
