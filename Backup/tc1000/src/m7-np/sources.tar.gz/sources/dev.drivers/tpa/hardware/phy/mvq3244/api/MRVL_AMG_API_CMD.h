/**
 * @file MRVL_AMG_API_CMD.h
 * @brief Marvell Multi-gig Automotive Ethernet PHY internal header for command and memory accessing
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */

#ifndef MRVL_AMG_CMD_H
#define MRVL_AMG_CMD_H

#include "MRVL_AMG_HwInterface.h"

/** @defgroup PHY_CMD Internal Command and Memory Access */

#define MRVL_AMG_RequestTimeoutWhenDataIsAvailible_MS 50 /* 50ms */
#define MRVL_AMG_RW_TIMEOUT_MS 300 /* 300ms */
#define MRVL_AMG_RW_WaitForIdle_MS 0 /* 0ms */

#define MRVL_AMG_CMD_controlStatus  0x40780880 /* FwMmd1eSet0DbgBufferControlStatus */
#define MRVL_AMG_CMD_hostBuffAddrLsw  0x4078088c /* FwMmd1eSet0DbgBufferHostBufferAddressLsw */
#define MRVL_AMG_CMD_HostBuffAddrMsw  0x40780890 /* FwMmd1eSet0DbgBufferHostBufferAddressMsw */
#define MRVL_AMG_CMD_hostBuffDataLevel  0x40780898 /* FwMmd1eSet0DbgBufferHostBufferDataLevel */
#define MRVL_AMG_CMD_DebugBufferAddrLsw  0x4078089c /* FwMmd1eSet0DbgBufferTraceBufferAddressLsw */
#define MRVL_AMG_CMD_DebugBufferAddrMsw  0x407808a0 /* FwMmd1eSet0DbgBufferTraceBufferAddressMsw */
#define MRVL_AMG_CMD_DebugBufferLenAddr  0x407808a4 /* FwMmd1eSet0DbgBufferTraceBufferSize */
#define MRVL_AMG_CMD_DebugBufferDepthAddr  0x407808a8 /* FwMmd1eSet0DbgBufferTraceBufferDataLevel */
#define MRVL_AMG_CMD_DebugBufferRdPtrAddr  0x407808ac /* FwMmd1eSet0DbgBufferTraceBufferReadIndex */

#define MRVL_AMG_CMD_hostBuffAddrMin  0x28000000
#define MRVL_AMG_CMD_hostBuffAddrMax  0x28000000 + 1024 * 442


#define MRVL_AMG_CMD_DebugSendRequest  0x1U
#define MRVL_AMG_CMD_DebugRestartRequest  0x3U
#define MRVL_AMG_CMD_DebugSendFreeze  0x4U
#define MRVL_AMG_CMD_DebugSendUnFreeze  0x5U

#define MRVL_AMG_CMD_DebugIcResetting 0xF

#define MRVL_AMG_CMD_DebugRequestMask 0x000fU
#define MRVL_AMG_CMD_DebugRequestShift 0
#define MRVL_AMG_CMD_DebugRequestFlagsMask 0x00f0U
#define MRVL_AMG_CMD_DebugRequestFlagsShift 4
#define MRVL_AMG_CMD_DebugStatusMask	0x0f00U
#define MRVL_AMG_CMD_DebugStatusShift 8
#define MRVL_AMG_CMD_DebugStatusFlagsMask 0xf000U
#define MRVL_AMG_CMD_DebugStatusFlagsShift 12


#define MRVL_AMG_CMD_DebugStatusDataGrantedWithOverflow_Legacy 0x2U
#define MRVL_AMG_CMD_DebugStatusFlagDataGrantedWithOverflow 0x1U
#define MRVL_AMG_CMD_DebugStatusFlagDataGrantedWithResync 0x2U

#define MRVL_AMG_CMD_MaxNumDataWords 8

/**
 * @brief command op code
 * 
 */
enum MRVL_AMG_CMD_CODE
{
	MRVL_AMG_CMD_CODE_Reserved = 0,
	MRVL_AMG_CMD_CODE_GetLastStatus = 1,
	MRVL_AMG_CMD_CODE_GetSetMailboxOpParams = 2,
	MRVL_AMG_CMD_CODE_Reset = 3,
	MRVL_AMG_CMD_CODE_SetRdAddrAndRdWords = 4,
	MRVL_AMG_CMD_CODE_SetWrAddrAndWrWords = 5,
	MRVL_AMG_CMD_CODE_RdWords = 6,
	MRVL_AMG_CMD_CODE_WrWords = 7,
	MRVL_AMG_CMD_CODE_StartImage = 8,
	MRVL_AMG_CMD_CODE_ReadSha = 9,
	MRVL_AMG_CMD_CODE_WriteImage = 10,
	MRVL_AMG_CMD_CODE_ResourceAccess = 11,
	MRVL_AMG_CMD_CODE_CmdExpansion = 15,
	MRVL_AMG_CMD_CODE_Max,
};

/**
 * @brief Structure of command codes and mapping fields
 * 
 */
typedef struct
{
	/*
	enum eCmd_t
	{
		eCmd_Get = 0,
		eCmd_Set = 1,
	};
	*/

	union {
		struct {
			MRVL_APHY_U32 mCmd : 4;
			MRVL_APHY_U32 mExecute : 1;
			MRVL_APHY_U32 mStatus : 1;
			MRVL_APHY_U32 mResetCrc : 1;
			MRVL_APHY_U32 mResetSha : 1;
			MRVL_APHY_U32 mNumWordsMinus1 : 5;
			MRVL_APHY_U32 mPostInc : 1;
			MRVL_APHY_U32 mIncInHash : 1;
			MRVL_APHY_U32 mSecure : 1;
			MRVL_APHY_U32 mReserved0 : 16;
		};
		MRVL_APHY_U32 mAsUint32;
	};
}MRVL_AMG_CMD_SetReadOrWriteWords;

/**
 * @brief Structure of command
 * 
 */
typedef struct
{
	MRVL_AMG_CMD_SetReadOrWriteWords mSetRdAddrAndRdWordsCmd;
	MRVL_APHY_U32 mAddrLo;
	MRVL_APHY_U32 mAddrHi;
	MRVL_APHY_U32 mCrc16;
	MRVL_APHY_U32 mData[MRVL_AMG_CMD_MaxNumDataWords];
}MRVL_AMG_CMD_SetRdAddrAndRdWords;



/* **************** CMD related **************** */

/**
 * @brief issues a command by writing the contents of buffer
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] apCmdDesc	Pointer to buffer containing the command
 * @param[in] aNumBytes	Number of bytes (size of the command) in the apCmdDesc buffer
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_CMD
 */
MRVL_APHY_STATUS MRVL_AMG_CMD_IssueCommand(MRVL_DEV_PTR device, void* apCmdDesc, MRVL_APHY_U16 aNumWords);

/**
 * @brief extract data from Mailbox registers into a buffer, taking into account whether the mailbox is a 16-bit or 32-bit mailbox.
 * @param[in] device		pointer to MRVL_DEV
 * @param[in] apDestAsWords	Destination buffer in RAM
 * @param[in] aNumWords		Number of 32-bit slot words to write.
 * @param[in] aStartRegSlotNdx	The index of the register slot to start reading at
 * @param[in] aStartRegSlotNdxForDataPacking	Index at which the funciton should
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_CMD
 */
MRVL_APHY_STATUS MRVL_AMG_CMD_ExtractFromRegs(MRVL_DEV_PTR device, void* apDestAsWords, MRVL_APHY_U16 aNumRegs, MRVL_APHY_U16 aStartRegSlotNdx, MRVL_APHY_U16 aStartRegSlotNdxForDataPacking);

/**
 * @brief read mData section of the command from registers into buffer.
 * @param[in] device			pointer to MRVL_DEV
 * @param[in] apDestAsWords		Destination buffer
 * @param[in] aNumFullDataWords	How many full 32-bit words of data to extract (actual *2)
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_CMD
 */
MRVL_APHY_STATUS MRVL_AMG_CMD_ExtractRdWrCmdDataWordsFromRegs(MRVL_DEV_PTR device, MRVL_APHY_U32 apDestAsWords[], MRVL_APHY_U16 aNumFullDataWords);

/**
 * @brief read a block of CPU memory into buffer 
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] aCpuAddr	Destination buffer
 * @param[in] aNumWords	Number of 32-bit words to read
 * @param[in] apDest	Pointer to buffer where to store the data.
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_CMD
 */
MRVL_APHY_STATUS MRVL_AMG_CMD_ReadWords(MRVL_DEV_PTR device, MRVL_APHY_U32 aCpuAddr, MRVL_APHY_U16 aNumWords, MRVL_APHY_U32 apDest[]);



/* **************** Virture reg read/write via command mailbox **************** */

#define MRVL_AMG_CMD_MB_CTRL  0x40780800U
#define MRVL_AMG_CMD_MB_INFO  0x40780808U
#define MRVL_AMG_FW_Reg_First	0x1F8000U
#define MRVL_AMG_FW_Reg_Last	0x1FFFFFU
#define MRVL_AMG_CMD_MB_READ  0x4U
#define MRVL_AMG_CMD_MB_WRITE  0x5U

typedef enum
{
   CMD_MB_RESERVED = 0,
   CMD_MB_GET_LAST_STATUS,
   CMD_MB_GET_SET_MAILBOX_OPT_PARAMETERS,
   CMD_MB_REBOOT,
   CMD_MB_SET_READ_ADDR_READ_WORDS,
   CMD_MB_SET_WRITE_ADDR_WRITE_WORDS,
   CMD_MB_READ_WORDS,
   CMD_MB_WRITE_WORDS,
   CMD_MB_RUN_START,
   CMD_MB_READ_SHA,
   CMD_MB_WRITE_IMAGE,
   CMD_MB_RESOURCE_ACCESS,
} MRVL_AMG_MboxCmd;

/**
 * @brief check if reg is in virtual reg space, used in MRVL_AMG_Virtual_read/writeReg32
 * @param[in] regAddr	address
 * @return MRVL_APHY_BOOL: True, is virtual register; False, is not virtual reg
 * 
 * @ingroup PHY_CMD
 */
MRVL_APHY_BOOL MRVL_AMG_isVirtualReg(MRVL_APHY_U32 regaddr);

/**
 * @brief check command mailbox transection status, used in MRVL_AMG_Virtual_read/writeReg32
 * @param[in] device	pointer to MRVL_DEV
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_CMD
 */
MRVL_APHY_STATUS MRVL_AMG_Virtual_getStatus(MRVL_DEV_PTR device);

/**
 * @brief force clear command mailbox transection status
 * @param[in] device	pointer to MRVL_DEV
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_CMD
 */
MRVL_APHY_STATUS MRVL_AMG_Virtual_clearStatus(MRVL_DEV_PTR device);

/**
 * @brief virtual reg read function
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] regAddr	address in virtual register space
 * @param[in] regVal	pointer to value
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_CMD
 */
MRVL_APHY_STATUS MRVL_AMG_Virtual_readReg32(MRVL_DEV_PTR device, MRVL_APHY_U32 regaddr, MRVL_APHY_U32* regVal);

/**
 * @brief virtual reg write function
 * @param[in] device	pointer to MRVL_DEV
 * @param[in] regAddr	address in virtual register space
 * @param[in]: regVal	value to be set
 * @return MRVL_APHY_STATUS
 * 
 * @ingroup PHY_CMD
 */
MRVL_APHY_STATUS MRVL_AMG_Virtual_writeReg32(MRVL_DEV_PTR device, MRVL_APHY_U32 regaddr, MRVL_APHY_U32 regVal);

MRVL_APHY_STATUS MRVL_AMG_enterServiceMode(MRVL_DEV_PTR device);

MRVL_APHY_STATUS MRVL_AMG_waitForServiceModeEnable(MRVL_DEV_PTR device);
MRVL_APHY_STATUS MRVL_AMG_setCommandAndExecute(MRVL_DEV_PTR device, MRVL_APHY_U8 command);
MRVL_APHY_BOOL MRVL_AMG_CmdMboxBusy(MRVL_DEV_PTR device);



#endif /* MRVL_AMG_CMD_H */
