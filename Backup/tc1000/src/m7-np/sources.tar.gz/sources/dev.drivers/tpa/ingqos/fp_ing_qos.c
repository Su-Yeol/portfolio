// SPDX-License-Identifier: GPL-2.0 OR MIT
/*************************************************************************/ /*!
@File           fp_ing_qos.c
@Title          Ingress qos configuration file
@Copyright      Copyright (c) 2007-2009, Naksha Technologies, Inc.
@Copyright      Copyright (c) 2010-2012, Posedge Technologies, Inc.
@Copyright      Copyright (c) 2013-2020, Imagination Technologies Ltd.
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    Functions to configure CB entries
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                     Include Files
 **********************************************************************/
#include "reg_hal.h"
#include "fp_macros.h"
#include "fp_ing_qos.h"
#include "global_address_map_fpga.h"
#include "tables_config.h"
#include "gpi_csr.h"

/***********************************************************************
 *                              Global Declarations                    *
 ***********************************************************************/
uint32a qos_data[128][8];

/*************************************************************************
 * Description: To get ingress shaper config parameters calculated based on
 *                : rate and frequency
 *************************************************************************/
int32a fp_ingqos_shaper_config_parameters(uint32a rate_units, uint32a rate,
				uint32a clk_frequency, uint32a *intwt,
				uint32a *frcwt, uint32a *clkd)
{
	uint32a wt = 0, sysclk_khz = 0, temp = 0;
	uint32a clkdiv = 0, trydiv = 0, w_i = 0, w_f = 0;

	/*Clock division intial value*/
	clkdiv = 2;

	/* Changing Mhz to KHz */
	sysclk_khz = clk_frequency * 1023;

	/* find the clkdiv value that gives us the largest valid wt value */
	while (clkdiv < ING_QOS_MAX_CLKDEV) {
		trydiv = clkdiv << 1;
		wt = (((rate * trydiv)/sysclk_khz) * (256 / 8));
		if (wt > ING_QOS_MAX_WT)
			break;
		clkdiv = trydiv;
		temp++;
	}
	/*	2^12  = 4096
	 *	2^8   = 256
	 */
	wt = (((rate * clkdiv)/sysclk_khz) * (256 / 8));
	w_i = wt >> ING_QOS_SHIFT_BY8;
	w_f = wt & 0xff;
	pr_info("%x:bps Shaper wt -----\n", wt);
	pr_info("%x:bps Clk div -----\n", clkdiv);
	pr_info("%x:bps temp -----\n", temp);
	/*Updating values*/
	/* *clkd = clkdiv; */
	*clkd = temp;
	*frcwt = w_f;
	*intwt = w_i;
	return 0;
}

/**********************************************************************
 * Function Name  : fp_ingqos_table_init
 * Description    : Ingress qos entry table init
 * Inputs
 *   Parameters   : -
 * Outputs        :
 *   Parameters   : -
 *   Returns      : int
 * Changes        :
 *********************************************************************/

int32a fp_ingqos_table_init(void)
{
#ifdef NPU_ING_QOS
	int32a i = 0, j = 0, cmd_done = 0;
	for (i=0; i<FP_MAX_PORTS; i++) {
		if ((EMAC_PORT_LIST_MASK >> i) & 0x1) {
			RegWrite(egpi_base_addr[i]+GPI_CSR_CSR_IGQOS_CONTROL        , 1);
			RegWrite(egpi_base_addr[i]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG0, 0);
			RegWrite(egpi_base_addr[i]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG1, 0);
			RegWrite(egpi_base_addr[i]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG2, 0);
			RegWrite(egpi_base_addr[i]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG3, 0);
			RegWrite(egpi_base_addr[i]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG4, 0);
			RegWrite(egpi_base_addr[i]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG5, 0);
			RegWrite(egpi_base_addr[i]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG6, 0);
			RegWrite(egpi_base_addr[i]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG7, 0);
			/*Fill EGPI entry table information*/
			for (j = 0; j < 128; j++) {
				RegWrite(egpi_base_addr[i]+GPI_CSR_CSR_IGQOS_ENTRY_CMDCNTRL,
					(1 | (j<<8)));
				do {
					cmd_done = RegRead(egpi_base_addr[i]
						+ GPI_CSR_CSR_IGQOS_ENTRY_CMDSTATUS);
				} while (0 == (cmd_done & 1));
			}
		}
	}
#endif
	return 0;
}
/**********************************************************************
 * Function Name  : fp_ingqos_write_config
 * Description    : Singe Entry configuaration
 * Inputs
 *   Parameters   : int , uint32a *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : int
 * Changes        :
 *********************************************************************/
int32a fp_ingqos_write_config(int32a portno, int32a index, uint32a *data)
{
#ifdef NPU_ING_QOS
//	uint32a *addr;
//	uint32a value = 0;
	int32a cmd_done = 0;
	RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG0, data[0]);
	RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG1, data[1]);
	RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG2, data[2]);
	RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG3, data[3]);
	RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG4, data[4]);
	RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG5, data[5]);
	RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG6, data[6]);
	RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG7, data[7]);
	RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_CMDCNTRL,
		(0x00000001|index<<8));
	do {
		cmd_done = RegRead(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_CMDSTATUS);
	} while (0 == (cmd_done & 1));
#endif
	return 0;
}
/**********************************************************************
 * Function Name  : fp_ingqos_read_config
 * Description    : Read Entrytable configuaration
 * Inputs
 *   Parameters   : uint32a *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : int
 * Changes        :
 *********************************************************************/
int32a fp_ingqos_read_config(int32a portno)
{
#ifdef NPU_ING_QOS
	int32a i = 0, cmd_done = 0;
	memset(qos_data, 0, sizeof(qos_data));

	/* Read EMAC Configuaration */
	for (i = 0; i < 128; i++) {
		RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG0, 0);
		RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG1, 0);
		RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG2, 0);
		RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG3, 0);
		RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG4, 0);
		RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG5, 0);
		RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG6, 0);
		RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG7, 0);
		RegWrite(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_CMDCNTRL , 2 | (i<<8));
		do {
			cmd_done = RegRead(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_CMDSTATUS);
		} while (0 == (cmd_done & 1));
		qos_data[i][0] = RegRead(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG0);
		qos_data[i][1] = RegRead(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG1);
		qos_data[i][2] = RegRead(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG2);
		qos_data[i][3] = RegRead(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG3);
		qos_data[i][4] = RegRead(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG4);
		qos_data[i][5] = RegRead(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG5);
		qos_data[i][6] = RegRead(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG6);
		qos_data[i][7] = RegRead(egpi_base_addr[portno]+GPI_CSR_CSR_IGQOS_ENTRY_DATA_REG7);
	}
#endif
	return 0;
}
