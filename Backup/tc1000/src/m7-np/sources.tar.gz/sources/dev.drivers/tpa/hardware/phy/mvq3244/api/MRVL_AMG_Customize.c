/**
 * @file MRVL_AMG_Customize.c
 * @brief Customizable source file for API interfacing with registers and replacement for standard library functions
 * This is used for including system-dependent XMDIO/CL45 implementations in order to access PHY device.
 * Modify this file to add:
 * 		Catch return code (MRVL_APHY_STATUS)
 * 		Log/dump registers accesses
 * 		Util/std functions 
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */

#include "MRVL_AMG_Customize.h"
#include "time.h"
#include "stdlib.h"
#include "string.h"
#include "math.h"

#ifdef MRVL_AMG_DEBUG 

MRVL_AMG_DBG_LEVEL MRVL_AMG_debug_level_global = MRVL_AMG_DBG_INF_LVL;

#if 0
/**
 * @brief debug info print
 * @param[in]	debug_level   allows control of how much is printed
 * 
 * @ingroup Customize_Lib
 */
void mAMGphyDbgPrint(
	FILE* stream,
	MRVL_AMG_DBG_LEVEL debug_level,
	const char* format, ...
)
{
	va_list argP;
	char dbgStr[1000] = "";

	if (debug_level != MRVL_AMG_DBG_OFF_LVL)
	{
		if (debug_level <= MRVL_AMG_debug_level_global)
		{
			va_start(argP, format);

			vsprintf_s(dbgStr, 1000, format, argP);

			fprintf(stream, dbgStr);

			va_end(argP);
		}
	}

}
#endif
#else 

/* All printing code removed */

#endif /* MRVL_AMG_DEBUG */


MRVL_APHY_BOOL MRVL_AMG_FLASH_BYPASS_CHECK = MRVL_APHY_FALSE; /* set to TRUE to speed up flash loading process with the cost of robustness*/


/******************************************************************************
 *      customizable Hardware Interface functions
 ******************************************************************************/

/**
 * @brief Read out a 16-bit value from IEEE register through XMDIO interface.
 * A wrapper function for _MRVL_DEV readReg
 *
 * @param[in]	device   MRVL_DEV
 * @param[in]	portAddr phy/port address
 * @param[in]	devAddr  Device address
 * @param[in]	regAddr  Register address within section
 * @param[out]	data     Register value
 *
 * @ingroup Customize_Lib_HWI
 */
MRVL_APHY_STATUS MRVL_AMG_ReadReg16_IMP(MRVL_DEV_PTR device, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16* regVal)
{
	return device->readReg(device, portAddr, devAddr, regAddr, regVal);
	/* customization: override this function for xmdio interface */
}

/**
 * @brief Write a 16-bit value to IEEE register through XMDIO interface.
 * A wrapper function for _MRVL_DEV writeReg
 *
 * @param[in]	device   MRVL_DEV
 * @param[in]	portAddr phy/port address
 * @param[in]	devAddr  Device address
 * @param[in]	regAddr  Register address within section
 * @param[in]	data     Register value
 *
 * @ingroup Customize_Lib_HWI
 */
MRVL_APHY_STATUS MRVL_AMG_WriteReg16_IMP(MRVL_DEV_PTR device, MRVL_APHY_U16 portAddr, MRVL_APHY_U16 devAddr, MRVL_APHY_U16 regAddr, MRVL_APHY_U16 regVal)
{
	return device->writeReg(device, portAddr, devAddr, regAddr, regVal);
	/* customization: override this function for xmdio interface */
}

/**
 * @brief Read out a 32-bit value from proprietary register through XMDIO or SPI interface.
 * A wrapper function for _MRVL_DEV readReg32
 *
 * @param[in]	device   MRVL_DEV
 * @param[in]	portAddr phy/port address
 * @param[in]	devAddr  Device address
 * @param[in]	regAddr  Register address within section
 * @param[out]	data     Register value
 *
 * @ingroup Customize_Lib_HWI
 */
MRVL_APHY_STATUS MRVL_AMG_ReadReg32_IMP(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U32* regVal)
{

	return device->readReg32(device, regAddr, regVal);
	/* customization: override this function for XMDIO or SPI interface */
}

/**
 * @brief Write a 32-bit value to proprietary register through XMDIO or SPI interface.
 * A wrapper function for _MRVL_DEV writeReg32
 *
 * @param[in]	device   MRVL_DEV
 * @param[in]	portAddr phy/port address
 * @param[in]	devAddr  Device address
 * @param[in]	regAddr  Register address within section
 * @param[in]	data     Register value
 *
 * @ingroup Customize_Lib_HWI
 */
MRVL_APHY_STATUS MRVL_AMG_WriteReg32_IMP(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U32 regVal)
{
	
	return device->writeReg32(device, regAddr, regVal); 
	/* customization: override this function for XMDIO or SPI interface */
}

/**
 * @brief Delay for specified number of milliseconds.
 * A wrapper function for _MRVL_DEV wait
 *
 * @param[in]	device   MRVL_DEV
 * @param[in]	waitTime wait time in milliseconds
 *
 * @ingroup Customize_Lib_HWI
 */
MRVL_APHY_STATUS MRVL_AMG_Wait_IMP(MRVL_DEV_PTR device, MRVL_APHY_U16 waitTime)
{
	return device->wait(device, waitTime);
	/* customization: override this function for wait function */
}

#if 0
/******************************************************************************
 *      customizable std utility functions
 ******************************************************************************/

/**
 * @brief Returns the current processing time.
 *
 * @param[in]	device   MRVL_DEV
 * @param[out]	clock processing time
 *
 * @ingroup Customize_Lib_STD
 */
void MRVL_AMG_Clock(MRVL_APHY_U32* curTime)
{
	*curTime = (MRVL_APHY_U32) clock();
	return;
}

/**
 * @brief Returns the current real time.
 *
 * @param[in]	device   MRVL_DEV
 * @param[out]	clock real time
 *
 * @ingroup Customize_Lib_STD
 */
void MRVL_AMG_Time(double* curTime)
{
	*curTime = (double) time(NULL);
	return;
}

/**
 * @brief Open file
 *
 * @param[in]	device   MRVL_DEV
 * @return FILE pointer or NULL
 * 
 * @ingroup Customize_Lib_STD
 */
FILE* MRVL_AMG_FileOpen(const char* filename)
{

	return fopen(filename, "a");
	
}

/**
 * @brief Close file
 *
 * @param[in]	filePtr   file
 *
 * @ingroup Customize_Lib_STD
 */
void MRVL_AMG_FileClose(FILE* filePtr)
{
	fclose(filePtr);
	return;
}

/**
 * @brief Print to file
 *
 * @param[in]	filePtr  file
 * @param[in]	toPrint  string
 *
 * @ingroup Customize_Lib_STD
 */
void MRVL_AMG_PrintToFile(FILE* filePtr, char* toPrint)
{
	fprintf(filePtr, toPrint);
	return;
}

/**
 * @brief Memroty allocation
 *
 * @param[in]	size mem block size
 *
 * @ingroup Customize_Lib_STD
 */
void* MRVL_AMG_MemoryAllocation(MRVL_APHY_U32 size)
{
	return malloc(size);
}

/**
 * @brief Free memory
 *
 * @param[in]	allocated  memory block
 *
 * @ingroup Customize_Lib_STD
 */
void MRVL_AMG_FreeMemory(void* allocated)
{
	free(allocated);
	return;
}

/**
 * @brief covert uint to string
 *
 * @param[inout] buffer  string
 * @param[in]	number
 *
 * @ingroup Customize_Lib_STD
 */
void MRVL_AMG_UintToString(char* buffer, MRVL_APHY_U32 number)
{
	sprintf(buffer, "%u", number);
	return;
}

/**
 * @brief covert float to string
 *
 * @param[inout] buffer  string
 * @param[in]	number
 *
 * @ingroup Customize_Lib_STD
 */
void MRVL_AMG_FloatToString(char* buffer, double number)
{
	sprintf(buffer, "%f", number);
	return;
}

/**
 * @brief appends string
 *
 * @param[inout]	buffer  destination string
 * @param[in]		str 	string to be appended
 *
 * @ingroup Customize_Lib_STD
 */
void MRVL_AMG_StringCat(char* buffer, const char* str)
{
	strcat(buffer, str);
	return;
}

/**
 * @brief math power 
 *
 * @param[in]	X  base value 
 * @param[in]	Y  power value
 * @return a double number, power raised to the base number
 *
 * @ingroup Customize_Lib_STD
 */
MRVL_APHY_DOUBLE MRVL_AMG_Pow(MRVL_APHY_DOUBLE X, MRVL_APHY_DOUBLE Y)
{
	return (MRVL_APHY_DOUBLE) pow(X,Y);
}

#endif
