// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
 * @File
 * @Title        fp_static_cfg.c
 * @Copyright    Copyright (c) Imagination Technologies Ltd. All Rights Reserved
 * @Description  static configuration routines for fast path module
 * @License      Dual MIT/GPLv2
 *
 * The contents of this file are subject to the MIT license as set out below.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * the GNU General Public License Version 2 ("GPL") in which case the provisions
 * of GPL are applicable instead of those above.
 *
 * If you wish to allow use of your version of this file only under the terms of
 * GPL, and not to allow others to use your version of this file under the terms
 * of the MIT license, indicate your decision by deleting the provisions above
 * and replace them with the notice and other provisions required by GPL as set
 * out in the file called "GPL-COPYING" included in this distribution. If you do
 * not delete the provisions above,a recipient may use your version of this file
 * under the terms of either the MIT license or GPL.
 *
 * This License is also included in this distribution in the file called
 * "MIT-COPYING".
 *
 * EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 * PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */ /**************************************************************************/

/**********************************************************************
 *                                  Include Files
 **********************************************************************/
#include "fp_library.h"
#include "fp_macros.h"
#include "fp_poolalloc.h"
#include "fp_router.h"
#include "fp_app_init.h"

/**********************************************************************
 * Function Name  : fp_add_static_route_tables
 * Description    : Helper routine to create route tables
 * Inputs
 *   Parameters   : -
 * Outputs        :
 *   Parameters   : fp_route_hash_table
 *   Returns      : -
 * Changes        :
 *********************************************************************/
void fp_add_static_route_tables(void)
{
#ifdef HASH_ARR_EN
	int32a i = 0;
	struct cacheFlow *rt_hash_arr = fp_get_route_hash_array();

	/* Getting router hash table */
	fp_router_hash_table = fp_create_router_table(ROUTE_HASH_SIZE);

	for(i = 0; i < ROUTE_HASH_SIZE; i++)
	{
		rt_hash_arr[i].vflag = 0;
		rt_hash_arr[i].next = 0;
	}
#endif
}
