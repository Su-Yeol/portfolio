/* SPDX-License-Identifier: GPL-2.0 OR MIT */

/*************************************************************************/ /*!
 * @File
 * @Title        fp_sa.h
 * @Copyright    Copyright (c) 2007-2009, Naksha Technologies, Inc.
 * @Copyright    Copyright (c) 2010-2012, Posedge Technologies, Inc.
 * @Copyright    Copyright (c) 2013-2020, Imagination Technologies Ltd.
 * @Copyright    Copyright (c) Imagination Technologies Ltd. All Rights Reserved
 * @Description  IPSec info
 * @License      Dual MIT/GPLv2
 *
 * The contents of this file are subject to the MIT license as set out below.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * the GNU General Public License Version 2 ("GPL") in which case the provisions
 * of GPL are applicable instead of those above.
 *
 * If you wish to allow use of your version of this file only under the terms of
 * GPL, and not to allow others to use your version of this file under the terms
 * of the MIT license, indicate your decision by deleting the provisions above
 * and replace them with the notice and other provisions required by GPL as set
 * out in the file called "GPL-COPYING" included in this distribution. If you do
 * not delete the provisions above,a recipient may use your version of this file
 * under the terms of either the MIT license or GPL.
 *
 * This License is also included in this distribution in the file called
 * "MIT-COPYING".
 *
 * EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 * PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */ /**************************************************************************/
#ifndef FP_SA_H
#define FP_SA_H

#define FP_IP_HDR_LEN 20
#define FP_IP6_HDR_LEN 40
#define FP_SA_IP_OPTIONS_LEN 40
#define FP_SA_IP6_EXT_HDR_LEN 16
#define FP_SA_MAX_ENC_KEY_SIZE  32
#define FP_SA_MAX_AUTH_KEY_SIZE 64

#define FP_SA_MAX_IV_SIZE  8
#define FP_SA_MAX_SPI_SIZE  4
#define FP_SA_MAX_SALT_SIZE 4

#define FP_KEY_SIZE_128 0x0
#define FP_KEY_SIZE_192 0x1
#define FP_KEY_SIZE_256 0x2

#define FP_MAX_SA_SIZE_REQUIRED 72

#define FP_SA_ALGO_MODE_SHIFT 0
#define FP_SA_MULTI_TASK_SHIFT 4
#define FP_SA_KEY_SIZE_SHIFT 7
#define FP_SA_ENCRYPT_FLAG_SHIFT 10
#define FP_SA_ENC_ALGO_SHIFT 11
#define FP_SA_AUTH_ALGO_SHIFT 15
#define FP_SA_ENABLE_HMAC_SHIFT 19
#define FP_SA_NEXT_HDR_SHIFT 22
#define FP_SA_PAD_PATTERN_SHIFT 30

#define FP_SA_DIR_SHIFT (48 % 32)
#define FP_SA_AH_PROTO_SHIFT (49 % 32)
#define FP_SA_TUNNEL_MODE_SHIFT (50 % 32)
#define FP_SA_SA_FRESH_SHIFT (51 % 32)
#define FP_SA_V6_SHIFT (52 % 32)
#define FP_SA_ENC_AUTH_MODE_SHIFT (53 % 32)
#define FP_SA_NEXT_PTR_SHIFT (55 % 32)


struct fp_sa {

	/* IPSec Control fields */

	int8    salt[FP_SA_MAX_SALT_SIZE];
	uint32a spi;
	uint32a next_ptr : 9;
	uint32a esp_enc_auth_mode : 2;
	uint32a v6 : 1;
	uint32a sa_fresh : 1;
	uint32a tunnel_mode : 1;
	uint32a ah_proto : 1;
	uint32a dir : 1;
	uint32a ext_hdr_len : 16;

	uint32a pad_pattern : 2;
	uint32a next_hdr : 8;
	uint32a ext_seq_number : 1;
	uint32a rsvd3 : 1;
	uint32a enable_hmac : 1;
	uint32a auth_algo : 4;
	uint32a enc_algo : 4;
	uint32a encrypt_flag : 1;
	uint32a key_size : 3;
	uint32a multi_task : 3;
	uint32a algo_mode : 4;

	/* IV data */
	int8	IV[FP_SA_MAX_IV_SIZE];

	/* salt SPI seq number */
	int32a     seq[2];


	/* outer IP header for tunnel mode */
	union {
		/* Ipv4 header */
		struct {
			int8    hdr[FP_IP_HDR_LEN];
			int8	options[FP_SA_IP_OPTIONS_LEN];
		} v4;
		/* Ipv6 header */
		struct {
			int8     hdr[FP_IP6_HDR_LEN];
			int32a     rsrvd[2];
			int8	ext_hdr[FP_SA_IP6_EXT_HDR_LEN];
		} v6;
	} outer_ip;
//	struct fp_sa *next;

	/* key */
	int8    ekey[FP_SA_MAX_ENC_KEY_SIZE];
	int8    akey[FP_SA_MAX_AUTH_KEY_SIZE];
};

struct fp_ipsec_tuple {
	uint32a  spi;
	uint8 proto;
};

/* Hash Table Structure */
struct fp_ipsec_sa_table {

	int32a     tbl_size;         /* size of the table */
	int32a     num_entries;      /* number of entries in this table */
	int32a     refcnt;           /* number of references to this table */
	struct fp_sa **table;  /* table elements */
};


#define FP_ECB          0x0
#define FP_CBC          0x1
#define FP_CFB          0x2
#define FP_OFB          0x3
#define FP_CBC_MAC      0x4
#define FP_CTR          0x5
#define FP_AES_GCM      0x6

#define FP_AES  0x4
#define FP_DES  0x1
#define FP_TDES  0x2


#define FP_ALGO_MD5 0x01
#define FP_ALGO_SHA1 0x02
#define FP_ALGO_SHA384 0x03
#define FP_ALGO_SHA256 0x04
#define FP_ALGO_SHA512 0x05
#define FP_ALGO_AES_GMAC 0x08


#define FP_XFRM_ALIGN4(len)        (((len) + 3) & ~3)
#define FP_XFRM_ALIGN8(len)        (((len) + 7) & ~7)
#define FP_XFRM_ALIGN16(len)        (((len) + 15) & ~15)


#define FP_APPLY_ENC 0x01
#define FP_APPLY_HASH 0x02

#define FP_PROTO_ESP 0x32
#define FP_PROTO_AH 0x33

extern struct fp_sa *fp_add_sad_table_entry(struct fp_sa *in_Entry);
extern int32a fp_delete_sad_table_entry(struct fp_sa *in_Entry);
extern void fp_init_ipsec(void);
extern struct fp_ipsec_sa_table *fp_create_ipsec_sa_table(int32a tbl_size);

#endif
