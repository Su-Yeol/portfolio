// SPDX-License-Identifier: GPL-2.0 OR MIT

/*************************************************************************/ /*!
@File
@Title          fp_pci_driver.c
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    base pci driver for fastpath module
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/
#include <linux/module.h>
MODULE_LICENSE("Dual MIT/GPL");

/**********************************************************************
 *                                     Include Files
 **********************************************************************/
#include <linux/netdevice.h>

#include "fp_library.h"
#include "fp_pci_driver.h"
#include "fp_net_driver.h"
#include "platform.h"

struct net_device  *fp_netdev_init(uint8 *membase, uint32a irq);
void fp_netdev_exit(void);

/**********************************************************************
 * Function Name  : fp_pci_probe
 * Description    : pci dev probe routine called when pci dev is
 * Inputs
 *   Parameters   : struct pci_dev *, struct pci_device_id *
 * Outputs        :
 *   Parameters   : -
 *   Returns      : struct net_device_stats *
 * Changes        :
 *********************************************************************/
static int32a fp_pci_probe(struct pci_dev *pdev, const struct pci_device_id *ent)
{
	int32a rc = 0;

	pr_info("[%s] invoke pci_enable_device()\n",__func__);
	rc = pci_enable_device(pdev);
	if (rc < 0) {
		printk("\n PCI dev enable failure");
		pci_set_drvdata(pdev, NULL);
		return 0;
	}
	// call platform specific init routine
	pr_info("[%s] invoke platform_init()\n",__func__);
	rc = platform_init(pdev);
	if (0 == rc)
	{
		printk("fp_pci_probe failed");
	}

	pr_info("[%s] exit\n",__func__);
	return 0;
}

void fp_pci_remove(struct pci_dev *pdev)
{
	struct net_device *dev = pci_get_drvdata(pdev);
	struct fp_private *fp = netdev_priv(dev);

	if (fp == NULL)
		return;
	fp_netdev_exit();
	FP_DEBUG(DBGP_FEAT_HIF, FP_LOG_EMERG, "<0> Cleaning Up the Module\n");
	pci_clear_master(pdev);
	if (fp->pcimem_base)
		iounmap(fp->pcimem_base);
	pci_disable_msi(pdev);
	pci_release_regions(pdev);
	pci_disable_device(pdev);
	pci_set_drvdata(pdev, NULL);
	return;
}

static struct pci_device_id fp_pci_tbl[] =
{
    { 0x0700, 0x8011, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0 },
    { 0x0700, 0x1107, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0 },
    { 0x10ee, 0x0007, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0 },
    { 0x10ee, 0x9031, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0 }, /* Telechips FPGA */
    { 0x10ee, 0x9034, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0 }, /* Telechips FPGA */
    { 0x1aee, 0x1030, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0 },
    { 0x1aee, 0x1010, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0 },
    { 0 },
};


static struct pci_driver fp_pci_driver = {
	.name		= MODULENAME,
	.id_table	= fp_pci_tbl,
	.probe		= fp_pci_probe,
	.remove		= fp_pci_remove,
};

int32a fp_pci_init(void)
{
	pr_info("[%s] invoke pci_register_driver()\n",__func__);
	return pci_register_driver(&fp_pci_driver);
}

void fp_pci_exit(void)
{
	pr_info("[%s] invoke pci_unregister_driver()\n",__func__);
	pci_unregister_driver(&fp_pci_driver);
}
