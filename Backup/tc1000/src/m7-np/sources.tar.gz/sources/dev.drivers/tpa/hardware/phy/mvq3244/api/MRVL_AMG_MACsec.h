/**
 * @file MRVL_AMG_MACsec.h
 * @brief Marvell Multi-gig Automotive Ethernet PHY MAC and MACsec API header File 
 * DUT MACsec configuration and status checking
 * 
 * @par Copyright and Version
 * See MRVL_AMG_Copyright_and_Version.h
 */

#ifndef MRVL_AMG_MACSEC_H
#define MRVL_AMG_MACSEC_H

#include "MRVL_AMG_MACsecTypes.h"
#include "MRVL_AMG_HwInterface.h"

/** @defgroup MACsec_Top MAC and MACsec CTRL Top */

/******************************************************************************
 *      MAC 32 and 64 bits register access
 ******************************************************************************/
/** @defgroup MCS_Reg_Access MACsec Register Access
 * @ingroup MACsec_Top
 */
EXPORT_FUNC void MRVL_AMG_MCS_ReadReg16(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U16* data);

EXPORT_FUNC void MRVL_AMG_MCS_ReadReg32(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U32* data);

EXPORT_FUNC void MRVL_AMG_MCS_ReadReg64(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U64* data);

EXPORT_FUNC void MRVL_AMG_MCS_WriteReg16(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U16 data);

EXPORT_FUNC void MRVL_AMG_MCS_WriteReg32(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U32 data);

EXPORT_FUNC void MRVL_AMG_MCS_WriteReg64(MRVL_DEV_PTR device, MRVL_APHY_U32 regAddr, MRVL_APHY_U64 data);

/******************************************************************************
 *      General Control for MACsec operation
 ******************************************************************************/
/** @defgroup MSC_CTRL MACsec General Control 
 * @ingroup MACsec_Top
 */
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_Init(MRVL_DEV_PTR device, MRVL_AMG_MAC_POWER_MODE powerMode, MRVL_AMG_MAC_FWD_MODE fwdMode);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_Disable(MRVL_DEV_PTR device);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetMCSPower(MRVL_DEV_PTR device, MRVL_AMG_MCS_POWER power);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetMCSPower(MRVL_DEV_PTR device, MRVL_AMG_MCS_POWER* power);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetDataPath(MRVL_DEV_PTR device, MRVL_AMG_MCS_DATAPATH path);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetDataPath(MRVL_DEV_PTR device, MRVL_AMG_MCS_DATAPATH* path);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_DisableAllEntry(MRVL_DEV_PTR device);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetChannelEnable(MRVL_DEV_PTR device, MRVL_APHY_BOOL isEnable);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetChannelEnable(MRVL_DEV_PTR device, MRVL_APHY_BOOL* isEnable);


/******************************************************************************
 *      MAC Control
 ******************************************************************************/
/** @defgroup MAC_CTRL Mode Configuration 
 * @ingroup MACsec_Top
 */
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MAC_Init(MRVL_DEV_PTR device, MRVL_AMG_MAC_POWER_MODE powerMode, MRVL_AMG_MAC_FWD_MODE fwdMode);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MAC_Disable(MRVL_DEV_PTR device);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MAC_SetMACPower(MRVL_DEV_PTR device, MRVL_AMG_MAC_POWER power);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MAC_GetMACPower(MRVL_DEV_PTR device, MRVL_AMG_MAC_POWER *power);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MAC_SetDataPath(MRVL_DEV_PTR device, MRVL_AMG_MAC_DATAPATH path);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MAC_GetDataPath(MRVL_DEV_PTR device, MRVL_AMG_MAC_DATAPATH *path);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MAC_SetPowerMode(MRVL_DEV_PTR device, MRVL_AMG_MAC_POWER_MODE powerMode);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MAC_GetPowerMode(MRVL_DEV_PTR device, MRVL_AMG_MAC_POWER_MODE* powerMode);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MAC_SetFwdMode(MRVL_DEV_PTR device, MRVL_AMG_MAC_FWD_MODE fwdMode);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MAC_GetFwdMode(MRVL_DEV_PTR device, MRVL_AMG_MAC_FWD_MODE* fwdMode);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MAC_SoftReset(MRVL_DEV_PTR device);


/******************************************************************************
 *      Rule
 ******************************************************************************/
/** @defgroup MSC_RULE_CNFG MACsec Rule Configuration 
 * @ingroup MACsec_Top
 */
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetRule(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 ruleIndex, MRVL_AMG_MCS_RULE* rule);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetRule(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 ruleIndex, MRVL_AMG_MCS_RULE* rule);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetRuleEnable(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 ruleIndex,  MRVL_APHY_BOOL isEnable);


/******************************************************************************
 *      SecY Map
 ******************************************************************************/
/** @defgroup MSC_SECY_MAP_CNFG MACsec SecY Map Configuration 
 * @ingroup MACsec_Top
 */
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetRxSecYMap(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_AMG_MCS_RX_SECY_MAP* secyMap);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxSecYMap(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_AMG_MCS_RX_SECY_MAP* secyMap);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetTxSecYMap(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_AMG_MCS_TX_SECY_MAP* secyMap);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxSecYMap(MRVL_DEV_PTR device, MRVL_APHY_U8 ruleIndex, MRVL_AMG_MCS_TX_SECY_MAP* secyMap);


/******************************************************************************
 *      SecY
 ******************************************************************************/
/** @defgroup MSC_SECY_CNFG MACsec SecY Configuration 
 * @ingroup MACsec_Top
 */
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetRxSecY(MRVL_DEV_PTR device, MRVL_APHY_U8 secyIndex, MRVL_AMG_MCS_RX_SECY* secy);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxSecY(MRVL_DEV_PTR device, MRVL_APHY_U8 secyIndex, MRVL_AMG_MCS_RX_SECY* secy);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetTxSecY(MRVL_DEV_PTR device, MRVL_APHY_U8 secyIndex, MRVL_AMG_MCS_TX_SECY* secy);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxSecY(MRVL_DEV_PTR device, MRVL_APHY_U8 secyIndex, MRVL_AMG_MCS_TX_SECY* secy);


/******************************************************************************
 *      SC
 ******************************************************************************/
/** @defgroup MSC_SC_CNFG MACsec SC Configuration 
 * @ingroup MACsec_Top
 */
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetRxSC(MRVL_DEV_PTR device, MRVL_APHY_U8 rxscIndex, MRVL_AMG_MCS_RX_SC* sc);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxSC(MRVL_DEV_PTR device, MRVL_APHY_U8 rxscIndex, MRVL_AMG_MCS_RX_SC* sc);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetTxSC(MRVL_DEV_PTR device, MRVL_APHY_U8 txscIndex, MRVL_AMG_MCS_TX_SC* sc);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxSC(MRVL_DEV_PTR device, MRVL_APHY_U8 txscIndex, MRVL_AMG_MCS_TX_SC* sc);

/******************************************************************************
 *      SA Policy
 ******************************************************************************/
/** @defgroup MSC_SA_CNFG MACsec SA Configuration 
 * @ingroup MACsec_Top
 */
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetRxSAPolicy(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_AMG_MCS_RX_SA_PLCY* saPlcy);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxSAPolicy(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_AMG_MCS_RX_SA_PLCY* saPlcy);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetTxSAPolicy(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_AMG_MCS_TX_SA_PLCY* saPlcy);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxSAPolicy(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_AMG_MCS_TX_SA_PLCY* saPlcy);


/******************************************************************************
 *      PN and PN Threshold
 ******************************************************************************/
/** @defgroup MSC_PN_TH_CNFG MACsec PN Threshold Configuration 
 * @ingroup MACsec_Top
 */
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetRxSANextPN(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_APHY_U64 pn);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetTxSANextPN(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_APHY_U64 pn);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxSACurrentPN(MRVL_DEV_PTR device, MRVL_APHY_U8 rxsaIndex, MRVL_APHY_U64* pn);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxSACurrentPN(MRVL_DEV_PTR device, MRVL_APHY_U8 txsaIndex, MRVL_APHY_U64* pn);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetRxPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U32 pnThreshold);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetRxXPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U64 pnThreshold);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U32* pnThreshold);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxXPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U64* pnThreshold);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetTxPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U32 pnThreshold);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetTxXPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U64 pnThreshold);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U32* pnThreshold);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxXPNThreshold(MRVL_DEV_PTR device, MRVL_APHY_U64* pnThreshold);


/******************************************************************************
 *      Default SCI
 ******************************************************************************/
/** @defgroup MSC_SCI_CNFG MACsec Default SCI Configuration 
 * @ingroup MACsec_Top
 */
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetDefaultSCI(MRVL_DEV_PTR device, MRVL_APHY_U64 sci);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetDefaultSCI(MRVL_DEV_PTR device, MRVL_APHY_U64* sci);


/******************************************************************************
 *      Statistics
 ******************************************************************************/
/** @defgroup MSC_STATS_CTRL MACsec Statistics Control
 * @ingroup MACsec_Top
 */
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MAC_GetRxSMCStats(MRVL_DEV_PTR device, MRVL_AMG_MAC_RX_SMC_STATS* stats);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MAC_GetTxSMCStats(MRVL_DEV_PTR device, MRVL_AMG_MAC_TX_SMC_STATS* stats);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MAC_GetRxWMCStats(MRVL_DEV_PTR device, MRVL_AMG_MAC_RX_WMC_STATS* stats);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MAC_GetTxWMCStats(MRVL_DEV_PTR device, MRVL_AMG_MAC_TX_WMC_STATS* stats);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MAC_ClearMIBStats(MRVL_DEV_PTR device);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxSecYStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_AMG_MCS_RX_SECY_COUNTER* stats);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxSecYStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_AMG_MCS_TX_SECY_COUNTER* stats);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxSCStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_AMG_MCS_RX_SC_COUNTER* stats);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxSCStats(MRVL_DEV_PTR device, MRVL_APHY_U8 index, MRVL_AMG_MCS_TX_SC_COUNTER* stats);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetRxPortStats(MRVL_DEV_PTR device, MRVL_AMG_MCS_RX_PORT_COUNTER* stats);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetTxPortStats(MRVL_DEV_PTR device, MRVL_AMG_MCS_TX_PORT_COUNTER* stats);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_ClearMCSStats(MRVL_DEV_PTR device);


/******************************************************************************
 *      Custom/VLAN Tag
 ******************************************************************************/
/** @defgroup MSC_TAG_CNFG MACsec Custom/VLAN Tag Configuration
 * @ingroup MACsec_Top
 */

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetCustomVLANTag(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CUSTOM_TAG* tag);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetCustomVLANTag(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CUSTOM_TAG* tag);


/******************************************************************************
 *      Control Packet
 ******************************************************************************/
/** @defgroup MSC_CTRL_PCKT_CNFG MACsec Control Packet Configuration
 * @ingroup MACsec_Top
 */
EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetCtrlPckt_EthType(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CTRL_PCKT_ETYPE* classification);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetCtrlPckt_EthType(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CTRL_PCKT_ETYPE* classification);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetCtrlPckt_DA(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CTRL_PCKT_DA* classification);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetCtrlPckt_DA(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CTRL_PCKT_DA* classification);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetCtrlPckt_DARange(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CTRL_PCKT_DA_RANGE* classification);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetCtrlPckt_DARange(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CTRL_PCKT_DA_RANGE* classification);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_SetCtrlPckt_COMBO(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CTRL_PCKT_COMBO* classification);

EXPORT_FUNC MRVL_APHY_STATUS MRVL_AMG_MCS_GetCtrlPckt_COMBO(MRVL_DEV_PTR device, MRVL_AMG_MCS_DIR direction, MRVL_APHY_U8 index, MRVL_AMG_MCS_CTRL_PCKT_COMBO* classification);


#endif  /* defined MRVL_AMG_MACSEC_H */ 

