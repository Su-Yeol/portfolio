/*
***************************************************************************************************
*
*   FileName : udma.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

//#include <gic.h>

#include "udma.h"
#include "nvic.h"
#include "clock.h"
#include "clock_dev.h"
#include "reg_phys.h"
#include "mpu.h"


/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/
// UART DMA Controllers
#define UDMA_CON_0                      (0U)
#define UDMA_CON_1                      (1U)
#define UDMA_CON_2                      (2U)
#define UDMA_CON_3                      (3U)
#define UDMA_CON_MAX                    (4U)

// UART DMA Base Address
#define UDMA_CON0_BASE                  (SIC_BSP_UDMA_BASE)
#define UDMA_CON1_BASE                  (SIC_BSP_UDMA_BASE + 0x10000UL)
#define UDMA_CON2_BASE                  (SIC_BSP_UDMA_BASE + 0x20000UL)
#define UDMA_CON3_BASE                  (SIC_BSP_UDMA_BASE + 0x30000UL)

#define UDMA_CON_BASE(x)                ((uint32)SIC_BSP_UDMA_BASE + ((x) * 0x10000UL))

// UART DMA Register offsets
#define UDMA_INTSR                      (0x00UL)  // Interrupt Status Register
#define UDMA_ITCSR                      (0x04UL)  // Interrupt Terminal Count Status Register
#define UDMA_ITCCR                      (0x08UL)  // Interrupt Terminal Count Clear Register
#define UDMA_IESR                       (0x0CUL)  // Interrupt Error Status Register
#define UDMA_IECR                       (0x10UL)  // Interrupt Error Clear Register
#define UDMA_RITCSR                     (0x14UL)  // Raw Interrupt Terminal Count Status Register
#define UDMA_REISR                      (0x18UL)  // Raw Error Interrupt Status Register
#define UDMA_ECR                        (0x1CUL)  // Enabled Channel Register
#define UDMA_SBRR                       (0x20UL)  // Software Burst Request Register
#define UDMA_SSRR                       (0x24UL)  // Software Single Request Register
#define UDMA_SLBRR                      (0x28UL)  // Software Last Burst Request Register
#define UDMA_SLSRR                      (0x2CUL)  // Software Last Single Request Register
#define UDMA_CR                         (0x30UL)  // Configuration Register

#define UDMA_CH_SRC_ADDR(x)             (((uint32)0x100UL + ((x) * 0x20UL)))
#define UDMA_CH_DST_ADDR(x)             (((uint32)0x104UL + ((x) * 0x20UL)))
#define UDMA_CH_LLI(x)                  (((uint32)0x108UL + ((x) * 0x20UL)))
#define UDMA_CH_CON(x)                  (((uint32)0x10CUL + ((x) * 0x20UL)))
#define UDMA_CH_CONFIG(x)               (((uint32)0x110UL + ((x) * 0x20UL)))

#define UDMA_CH0_FLAG                   ((uint32)1UL << 0UL)
#define UDMA_CH1_FLAG                   ((uint32)1UL << 1UL)


typedef struct UDMA_CONTROLLER
{
    uint32                              cController;
    UDMAInformation_t *                 cCh[2];
} UDMAController_t;


static UDMAController_t udma_con_table[UDMA_CON_MAX] =
{
	{0UL, {NULL_PTR, NULL_PTR}},
	{1UL, {NULL_PTR, NULL_PTR}},
	{2UL, {NULL_PTR, NULL_PTR}},
	{3UL, {NULL_PTR, NULL_PTR}}
};

/*
***************************************************************************************************
                                     STATIC FUNCTIONS
***************************************************************************************************
*/

static void UDMA_ISR
(
    uint32                              udma_con
);

static void UDMA_SetFlowControl
(
    const UDMAInformation_t *           sDmacon,
    uint32                              uiFlow
);

static void UDMA_SetAddrIncrement
(
    const UDMAInformation_t *           sDmacon,
    uint8                               ucDestInc,
    uint32                              uiSrcInc
);

static void UDMA_SetBurstSize
(
    const UDMAInformation_t *           sDmacon,
    uint8                               ucDestBurst,
    uint32                              uiSrcBurst
);

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/

static void UDMA_ISR
(
    uint32                              udma_con
)
{
    uint32              status;
    uint32              uiAddr;
    uint32              udma_cnt  = 0U;
    UDMAController_t *  pConTable = &udma_con_table[udma_con];
    UDMAInformation_t * dmacon    = NULL_PTR;

    if(pConTable != NULL_PTR)
    {
        uiAddr = UDMA_CON_BASE(udma_con) + UDMA_ITCSR;
        status = SAL_ReadReg(uiAddr);

        if (status != 0UL)
        {
            pConTable->cController &= 0x7U;
            if ((status & UDMA_CH0_FLAG) != 0UL)    // Rx DMA
            {
                dmacon = (UDMAInformation_t *)pConTable->cCh[0UL];

                if (dmacon != NULL_PTR)
                {
                    dmacon->iCon &= 0x7U;

                    // Clear terminal count interrupt
                    uiAddr = UDMA_CON_BASE(udma_con) + UDMA_ITCCR;
                    SAL_WriteReg(UDMA_CH0_FLAG, uiAddr);

                    // Disable UDMA Channel
                    UDMA_ChannelDisable(dmacon);

                    // break loop if the FIFO is not empty, time out.
                    // p.s. 19000 loops are approximately 1ms, based on 400MHz which is max clock speed for Cortex-M7.
                    uiAddr = UDMA_CON_BASE(udma_con) + UDMA_CH_CONFIG(0UL);
                    while (udma_cnt <= 1900UL) // 1900 : 0.1ms. worst case
                    {
                        // check the Active flag
                        // 0 = there is no data in the FIFO of the channel
                        if ((SAL_ReadReg(uiAddr) & (0x20000UL)) == 0UL)
                        {
                            break;
                        }

                        udma_cnt += 1UL;
                    }

                    UDMA_SetSrcAddr(dmacon, (uint32)dmacon->iSrcAddr);
                	UDMA_SetDestAddr(dmacon, (uint32)dmacon->iDestAddr);
                	UDMA_InterruptEnable(dmacon);
                	UDMA_SetTransferWidth(dmacon, UDMA_TRANSFER_SIZE_BYTE, UDMA_TRANSFER_SIZE_BYTE);
                	UDMA_SetTransferSize(dmacon, dmacon->iBufSize);

                	// Run DMA
                	UDMA_ChannelEnable(dmacon);

                    dmacon->iIsRun = 0UL;
                }
            }
            else if ((status & UDMA_CH1_FLAG) != 0UL)   // Tx DMA
            {
                dmacon = (UDMAInformation_t *)pConTable->cCh[1UL];

                if (dmacon != NULL_PTR)
                {
                    dmacon->iCon &= 0x7U;

                    // Clear terminal count interrupt
                    uiAddr = UDMA_CON_BASE(udma_con) + UDMA_ITCCR;
                    SAL_WriteReg(UDMA_CH1_FLAG, uiAddr);

                    // Disable UDMA Channel
                    UDMA_ChannelDisable(dmacon);

                    // break loop if the FIFO is not empty, time out.
                    // p.s. 19000 loops are approximately 1ms, based on 400MHz which is max clock speed for Cortex-M7.
                    uiAddr = UDMA_CON_BASE(udma_con) + UDMA_CH_CONFIG(1UL);
                    while (udma_cnt <= 1900UL) // 1900 : 0.1ms. worst case
                    {
                        // check the Active flag
                        // 0 = there is no data in the FIFO of the channel
                        if ((SAL_ReadReg(uiAddr) & (0x20000UL)) == 0UL)
                        {
                            break;
                        }

                        udma_cnt += 1UL;
                    }

    			    dmacon->iIsRun = 0UL;
                }
            }
        }
    }
}

static void UDMA_0_ISR
(
    void
)
{
    UDMA_ISR(UDMA_CON_0);
}

static void UDMA_1_ISR
(
    void
)
{
    UDMA_ISR(UDMA_CON_1);
}

static void UDMA_2_ISR
(
    void
)
{
    UDMA_ISR(UDMA_CON_2);
}

static void UDMA_3_ISR
(
    void
)
{
    UDMA_ISR(UDMA_CON_3);
}

static void UDMA_SetFlowControl
(
    const UDMAInformation_t *           sDmacon,
    uint32                              uiFlow
)
{
    uint32 uiAddr;
    uint32 uiValue;

    if (sDmacon != NULL_PTR)
    {
        uiAddr  = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CH_CONFIG(sDmacon->iCh);
        uiValue = SAL_ReadReg(uiAddr);
        uiValue &= ~(0x7UL << 11UL);
        uiValue |= ((uiFlow & 0x7UL) << 11UL);
        SAL_WriteReg(uiValue, uiAddr);
    }
}

static void UDMA_SetAddrIncrement
(
    const UDMAInformation_t *           sDmacon,
    uint8                               ucDestInc,
    uint32                              uiSrcInc
)
{
    uint32 inc;
    uint32 uiAddr;
    uint32 uiValue;

    if (sDmacon != NULL_PTR)
    {
        uiAddr  = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CH_CON(sDmacon->iCh);
        uiValue = SAL_ReadReg(uiAddr);
        //clear desc, src increment
        uiValue &= ~(0x3UL << 26UL);

        inc     = (((uint32)ucDestInc & 0x1UL) << 1UL) | (uiSrcInc & 0x1UL);
        uiValue |= (inc << 26UL);

        SAL_WriteReg(uiValue, uiAddr);
    }
}

static void UDMA_SetBurstSize
(
    const UDMAInformation_t *           sDmacon,
    uint8                               ucDestBurst,
    uint32                              uiSrcBurst
)
{
    uint32 burst_size;
    uint32 uiAddr;
    uint32 uiValue;

    if (sDmacon != NULL_PTR)
    {
        uiAddr  = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CH_CON(sDmacon->iCh);
        uiValue = SAL_ReadReg(uiAddr);
        //clear desc, src burst size
        uiValue     &= ~(0x3FUL << 12UL);
        burst_size  = (((uint32)ucDestBurst & 0x7UL) << 3UL) | (uiSrcBurst & 0x7UL);
        uiValue     |= (burst_size << 12UL);

        SAL_WriteReg(uiValue, uiAddr);
    }
}

/*
***************************************************************************************************
*                                         INTERFACE FUNCTIONS
***************************************************************************************************
*/

void UDMA_InterruptEnable
(
    const UDMAInformation_t *           sDmacon
)
{
    uint32 uiAddr;
    uint32 uiValue;

    if (sDmacon != NULL_PTR)
    {
        // Enable terminal count interrupt
        uiAddr  = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CH_CON(sDmacon->iCh);
        uiValue = (uint32)SAL_ReadReg(uiAddr) | ((uint32)1UL << 31UL);

        SAL_WriteReg(uiValue,uiAddr);

        // Mask terminal count interrupt
        uiAddr  = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CH_CONFIG(sDmacon->iCh);
        uiValue = (uint32)SAL_ReadReg(uiAddr) | ((uint32)1UL << 15UL);
        SAL_WriteReg(uiValue,uiAddr);
    }
}

void UDMA_InterruptDisable
(
    const UDMAInformation_t *           sDmacon
)
{
    uint32 uiAddr;
    uint32 uiValue;

    if (sDmacon != NULL_PTR)
    {
        // Disable terminal count interrupt
        uiAddr  = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CH_CON(sDmacon->iCh);
        uiValue = (uint32)SAL_ReadReg(uiAddr) & ~((uint32)1UL << 31UL);
        SAL_WriteReg(uiValue,uiAddr);

        // Unask terminal count interrupt
        uiAddr  = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CH_CONFIG(sDmacon->iCh);
        uiValue = (uint32)SAL_ReadReg(uiAddr) & ~((uint32)1UL << 15UL);
        SAL_WriteReg(uiValue,uiAddr);
    }
}

void UDMA_SetTransferWidth
(
    const UDMAInformation_t *           sDmacon,
    uint8                               ucDestWidth,
    uint32                              uiSrcWidth
)
{
    uint32 transfer_width;
    uint32 uiAddr;
    uint32 uiValue;

    if (sDmacon != NULL_PTR)
    {
        uiAddr  = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CH_CON(sDmacon->iCh);
        uiValue = SAL_ReadReg(uiAddr);
        //clear desc, src transfer width
        uiValue         &= ~(0x3FUL << 18UL);
        transfer_width  = (((uint32)ucDestWidth & 0x7UL) << 3UL) | (uiSrcWidth & 0x7UL);
        uiValue         |= (transfer_width << 18UL);

        SAL_WriteReg(uiValue, uiAddr);
    }
}

void UDMA_SetTransferSize
(
    const UDMAInformation_t *           sDmacon,
    uint32                              uiTransferSize
)
{
    uint32 uiAddr;
    uint32 uiValue;

    if (sDmacon != NULL_PTR)
    {
        uiAddr  = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CH_CON(sDmacon->iCh);
        uiValue = SAL_ReadReg(uiAddr);
        //clear transfer size
        uiValue &= ~(0xFFFUL);
        uiValue |= (uiTransferSize & 0xFFFUL);
        SAL_WriteReg(uiValue, uiAddr);
    }
}


void UDMA_SetParam
(
    const UDMAInformation_t *           sDmacon,
    uint8                               uiTxRx
)
{
    switch (uiTxRx)
    {
        case UDMA_PERI_TX:
            UDMA_SetFlowControl(sDmacon, UDMA_FLOW_TYPE_M2P);
            UDMA_SetAddrIncrement(sDmacon, UDMA_NO_INC, UDMA_INC);
            UDMA_SetBurstSize(sDmacon, UDMA_BURST_SIZE_1, UDMA_BURST_SIZE_1);
            break;
        case UDMA_PERI_RX:
            UDMA_SetFlowControl(sDmacon, UDMA_FLOW_TYPE_P2M);
            UDMA_SetAddrIncrement(sDmacon, UDMA_INC, UDMA_NO_INC);
            UDMA_SetBurstSize(sDmacon, UDMA_BURST_SIZE_1, UDMA_BURST_SIZE_1);
            break;
        default:
            UDMA_SetFlowControl(sDmacon, UDMA_FLOW_TYPE_M2P);
            UDMA_SetAddrIncrement(sDmacon, UDMA_NO_INC, UDMA_INC);
            UDMA_SetBurstSize(sDmacon, UDMA_BURST_SIZE_1, UDMA_BURST_SIZE_1);
            break;
    }
}

/*
***************************************************************************************************
*                                          UDMA_Reset
*
* Function to reset UDMA Channel.
*
* @param    ucCh [in]       : Value of channel to control
* @return   SAL_RET_SUCCESS or SAL_ERR
* Notes
*
***************************************************************************************************
*/

SALRetCode_t UDMA_Reset
(
    uint8                               ucCh
)
{
    sint32  ret;
    sint32  iClkBusId;
    SALRetCode_t tRet;

    tRet = SAL_RET_SUCCESS;
    ret = NULL;

    iClkBusId   = (sint32)CLOCK_IOBUS_UART0_DMA + (sint32)ucCh;

    /* SW reset */
    ret = CLOCK_SetSwReset(iClkBusId, TRUE);

    if(ret != (sint32)NULL)
    {
        tRet = SAL_RET_FAILED;
    }
    else
    {
        /* Bit Clear */
        ret = CLOCK_SetSwReset(iClkBusId, FALSE);

        if(ret != (sint32)NULL)
        {
            tRet = SAL_RET_FAILED;
        }
    }

    return tRet;
}

void UDMA_SetPeri
(
    UDMAInformation_t *                 sDmacon,
    uint8                               ucDestPeri,
    uint8                               ucSrcPeri
)
{
    uint32 uiAddr;
    uint32 uiValue;

    sDmacon->iCon &= 0x7U;
    sDmacon->iCh &= 0x3U;
    uiAddr  = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CH_CONFIG(sDmacon->iCh);
    uiValue = SAL_ReadReg(uiAddr);
    uiValue &= ~(0x7FEUL);
    uiValue |= ((uint32)ucDestPeri & 0xFUL) << 6UL;
    uiValue |= ((uint32)ucSrcPeri  & 0xFUL) << 1UL;
    SAL_WriteReg(uiValue, uiAddr);
}

uint32 UDMA_GetTransferSize
(
    UDMAInformation_t *                 sDmacon
)
{
    uint32 size;
    uint32 uiAddr;
    uint32 uiValue;

    sDmacon->iCon &= 0x7U;
    sDmacon->iCh &= 0x3U;
    uiAddr  = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CH_CON(sDmacon->iCh);
    uiValue = SAL_ReadReg(uiAddr);
    size    = (uiValue & (0xFFFFUL));

    return size;
}

void UDMA_ChannelEnable
(
    const UDMAInformation_t *           sDmacon
)
{
    uint32 uiAddr;
    uint32 uiValue;

    if (sDmacon != NULL_PTR)
    {
        uiAddr  = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CH_CONFIG(sDmacon->iCh);
        uiValue = SAL_ReadReg(uiAddr);
        uiValue &= ~(1UL << 18UL);  // enable DMA requests
        uiValue |= (1UL << 0UL);    // channel enabled

        SAL_WriteReg(uiValue, uiAddr);
    }
}

void UDMA_ChannelDisable
(
    const UDMAInformation_t *           sDmacon
)
{
    uint32 uiAddr;
    uint32 uiValue;

    if (sDmacon != NULL_PTR)
    {
        uiAddr  = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CH_CONFIG(sDmacon->iCh);
        uiValue = SAL_ReadReg(uiAddr);
        uiValue |= (1UL << 18UL);   // ignore subsequent source DMA requests
        uiValue &= ~(1UL << 0UL);   // channel disabled

        SAL_WriteReg(uiValue, uiAddr);
    }
}

void UDMA_SetSrcAddr
(
    const UDMAInformation_t *           sDmacon,
    uint32                              uiAddr
)
{
    uint32 uiRegAddr;

    if (sDmacon != NULL_PTR)
    {
        uiRegAddr = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CH_SRC_ADDR(sDmacon->iCh);
        SAL_WriteReg(uiAddr, uiRegAddr);
    }
}

void UDMA_SetDestAddr
(
    const UDMAInformation_t *           sDmacon,
    uint32                              uiAddr
)
{
    uint32 uiRegAddr;

    if (sDmacon != NULL_PTR)
    {
        uiRegAddr = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CH_DST_ADDR(sDmacon->iCh);
        SAL_WriteReg(uiAddr, uiRegAddr);
    }
}

void UDMA_SetlliAddr
(
    const UDMAInformation_t *           sDmacon,
    uint32                              uiLLIAddr
)
{
    uint32 uiAddr;

    if (sDmacon != NULL_PTR)
    {
        uiAddr = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CH_LLI(sDmacon->iCh);
        SAL_WriteReg(uiLLIAddr, uiAddr);
    }
}

uint32 UDMA_GetDestAddr
(
    const UDMAInformation_t *           sDmacon
)
{
    uint32 ret;
    uint32 uiAddr;

    ret = 0UL;

    if (sDmacon != NULL_PTR)
    {
        uiAddr = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CH_DST_ADDR(sDmacon->iCh);
        ret = SAL_ReadReg(uiAddr);
    }

    return ret;
}

sint32 UDMA_Init
(
    UDMAInformation_t *                 sDmacon
)
{
    sint32 ret;
    uint32 uiAddr;
    uint32 uiValue;
    sint32 iClkId;

    ret     = -1;
    iClkId  = 0;

    if (sDmacon != NULL_PTR)
    {
        sDmacon->iCon &= 0x7U;
	    iClkId = (sint32)CLOCK_IOBUS_UART0_DMA + (sint32)sDmacon->iCon;
        (void)CLOCK_EnableIobus(iClkId, SALEnabled);
		
        udma_con_table[sDmacon->iCon].cController = sDmacon->iCon;
	    udma_con_table[sDmacon->iCon].cCh[sDmacon->iCh] = sDmacon;
        uiAddr = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CR;

            if((SAL_ReadReg(uiAddr) & 0x1UL) == 0UL)   // DMA enable
            {
                // Disable DMA Contorller
                uiValue = SAL_ReadReg(uiAddr);
                SAL_WriteReg(uiValue & ~(0x1UL), uiAddr);

                // Clear Interrupt
                uiAddr = UDMA_CON_BASE(sDmacon->iCon) + UDMA_ITCCR;
                SAL_WriteReg(0xFFUL, uiAddr);
                uiAddr = UDMA_CON_BASE(sDmacon->iCon) + UDMA_IECR;
                SAL_WriteReg(0xFFUL, uiAddr);

                switch(sDmacon->iCon)
                {
                    case UDMA_CON_0:
                        (void)NVIC_IntVectSet((UART_DMA_C0_IRQn), (IrqHandler_t)&UDMA_0_ISR);
                        (void)NVIC_IntSrcEn(UART_DMA_C0_IRQn);
                        break;
                    case UDMA_CON_1:
                        (void)NVIC_IntVectSet((UART_DMA_C1_IRQn), (IrqHandler_t)&UDMA_1_ISR);
                        (void)NVIC_IntSrcEn(UART_DMA_C1_IRQn);
                        break;
                    case UDMA_CON_2:
                        (void)NVIC_IntVectSet((UART_DMA_C2_IRQn), (IrqHandler_t)&UDMA_2_ISR);
                        (void)NVIC_IntSrcEn(UART_DMA_C2_IRQn);
                        break;
                    case UDMA_CON_3:
                        (void)NVIC_IntVectSet((UART_DMA_C3_IRQn), (IrqHandler_t)&UDMA_3_ISR);
                        (void)NVIC_IntSrcEn(UART_DMA_C3_IRQn);
                        break;
                }

                // Enable DMA Controller
                uiAddr = UDMA_CON_BASE(sDmacon->iCon) + UDMA_CR;
                SAL_WriteReg(0x1UL, uiAddr);
                ret = (sint32)SAL_RET_SUCCESS;
            }
        }


    return ret;
}

