/*
***************************************************************************************************
*
*   FileName : clock_dev.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_CLOCK_DEV_HEADER
#define SIC_BSP_CLOCK_DEV_HEADER

#include <sal_internal.h>

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/

#define CLOCK_XIN_CLK_RATE              (24000000UL)    // 24MHz
#define CLOCK_XTIN_CLK_RATE             (32768UL)   // 32.768kHz

/* PLL channel index */
typedef enum CLOCK_PLL
{
    CLOCK_PLL_MICOM_0                   = 0,
    CLOCK_PLL_MICOM_1                   = 1,
    CLOCK_PLL_MICOM_2                   = 2,
    CLOCK_PLL_MICOM_3                   = 3
} CLOCKPll_t;

/* MICOM pll source channel index */
typedef enum CLOCK_M_PLL
{
    CLOCK_MPLL_0                        = 0,
    CLOCK_MPLL_1                        = 1,
    CLOCK_MPLL_2                        = 2,
    CLOCK_MPLL_3                        = 3,
    CLOCK_MPLL_DIV_0                    = 4,
    CLOCK_MPLL_DIV_1                    = 5,
    CLOCK_MPLL_DIV_2                    = 6,
    CLOCK_MPLL_DIV_3                    = 7,
    CLOCK_MPLL_XIN                      = 8,
    CLOCK_MPLL_XIN_DIV                  = 9,
    CLOCK_MPLL_XTIN                     = 10,
    CLOCK_MPLL_XTIN_DIV                 = 11,
    CLOCK_MPLL_MAX_NUM                  = 12
}CLOCKMpll_t;

typedef enum CLOCK_M_BUS
{
    CLOCK_MBUS_SMU_SUBSYS               = 0,
    CLOCK_MBUS_CPU_SUBSYS               = 1,
    CLOCK_MBUS_MCU_0                    = 2,
    CLOCK_MBUS_MCU_1                    = 3,
    CLOCK_MBUS_MCU_2                    = 4,
    CLOCK_MBUS_LPDDR                    = 5,
    CLOCK_MBUS_HSIO_SUBSYS              = 6,
    CLOCK_MBUS_EPP_SYS                  = 7,
    CLOCK_MBUS_NET_SUBSYS               = 8,
    CLOCK_MBUS_IO_SUBSYS                = 9,
    CLOCK_MBUS_HSM_SUBSYS               = 10,
    CLOCK_MBUS_PCIE                     = 11,
    CLOCK_MBUS_SDMMC                    = 12,
    CLOCK_MBUS_MAX_NUM                  = 13
}CLOCKMbus_t;

typedef enum CLOCK_PCLK_CTRL_SEL
{
    CLOCK_PCLKCTRL_SEL_PLL0             = 0,
    CLOCK_PCLKCTRL_SEL_PLL1             = 1,
    CLOCK_PCLKCTRL_SEL_PLL2             = 2,
    CLOCK_PCLKCTRL_SEL_PLL3             = 3,

    CLOCK_PCLKCTRL_SEL_XIN              = 5,
    CLOCK_PCLKCTRL_SEL_XTIN             = 6,


    CLOCK_PCLKCTRL_SEL_PLL0DIV          = 9,
    CLOCK_PCLKCTRL_SEL_PLL1DIV          = 10,
    CLOCK_PCLKCTRL_SEL_PLL2DIV          = 11,
    CLOCK_PCLKCTRL_SEL_PLL3DIV          = 12,
    CLOCK_PCLKCTRL_SEL_XINDIV           = 13,
    CLOCK_PCLKCTRL_SEL_XTINDIV          = 14,

    CLOCK_PCLKCTRL_SEL_EXTCLKIN0        = 16,
    CLOCK_PCLKCTRL_SEL_EXTCLKIN1        = 17,
    CLOCK_PCLKCTRL_SEL_EXTCLKIN2        = 18,
    CLOCK_PCLKCTRL_SEL_EXTCLKIN3        = 19,
    CLOCK_PCLKCTRL_SEL_EXTCLKIN4        = 20,
    CLOCK_PCLKCTRL_SEL_EXTCLKIN5        = 21,
    CLOCK_PCLKCTRL_SEL_EXTCLKIN6        = 22,
    CLOCK_PCLKCTRL_SEL_EXTCLKIN7        = 23,
    CLOCK_PCLKCTRL_SEL_EXTCLKIN8        = 24,
    CLOCK_PCLKCTRL_SEL_EXTCLKIN9        = 25,
    CLOCK_PCLKCTRL_SEL_EXTCLKIN10       = 26,
    CLOCK_PCLKCTRL_SEL_EXTCLKIN11       = 27,
    CLOCK_PCLKCTRL_SEL_EXTCLKIN12       = 28,
    CLOCK_PCLKCTRL_SEL_EXTCLKIN13       = 29,
    CLOCK_PCLKCTRL_SEL_EXTCLKIN14       = 30,
    CLOCK_PCLKCTRL_SEL_EXTCLKIN15       = 31,
}CLOCKPclkctrlSel_t;

/* Peripheral Clocks */
typedef enum CLOCK_PERI
{/* Peri. Name */
    // MICOM Peri
    CLOCK_PERI_TIMER0_XCLK              =  0UL, //XCLK of Timer/Counter0 Peripheral Clock Generation
    CLOCK_PERI_TIMER0_TCLK              =  1UL, //TCLK of Timer/Counter0 Peripheral Clock Generation
    CLOCK_PERI_TIMER0_ZCLK              =  2UL, //ZCLK of Timer/Counter0 Peripheral Clock Generation
    CLOCK_PERI_TIMER1_XCLK              =  3UL, //XCLK of Timer/Counter1 Peripheral Clock Generation
    CLOCK_PERI_TIMER1_TCLK              =  4UL, //TCLK of Timer/Counter1 Peripheral Clock Generation
    CLOCK_PERI_TIMER1_ZCLK              =  5UL, //ZCLK of Timer/Counter1 Peripheral Clock Generation
    CLOCK_PERI_GTC                      =  6UL, //GTC Peripheral Clock Generation
    CLOCK_PERI_GMAC0                    =  7UL, //GMAC-0 Peripheral Clock Generation
    CLOCK_PERI_GMAC0_TS                 =  8UL, //GMAC-0 Timestamp Peripheral Clock Generation
    CLOCK_PERI_GMAC1                    =  9UL, //GMAC-0 Peripheral Clock Generation
    CLOCK_PERI_GMAC1_TS                 = 10UL, //GMAC-1 Timestamp Peripheral Clock Generation
    CLOCK_PERI_GPSB0                    = 11UL, //Core Clock of GPSB-0 Generation
    CLOCK_PERI_GPSB1                    = 12UL, //Core Clock of GPSB-1 Generation
    CLOCK_PERI_GPSB2                    = 13UL, //Core Clock of GPSB-2 Generation
    CLOCK_PERI_GPSB3                    = 14UL, //Core Clock of GPSB-3 Generation
    CLOCK_PERI_GPSB4                    = 15UL, //Core Clock of GPSB-4 Generation
    CLOCK_PERI_GPSB5                    = 16UL, //Core Clock of GPSB-5 Generation
    CLOCK_PERI_I2C0                     = 17UL, //Core Clock of I2C-0 Generation
    CLOCK_PERI_I2C1                     = 18UL, //Core Clock of I2C-1 Generation
    CLOCK_PERI_I2C2                     = 19UL, //Core Clock of I2C-2 Generation
    CLOCK_PERI_I2C3                     = 20UL, //Core Clock of I2C-3 Generation
    CLOCK_PERI_I2C4                     = 21UL, //Core Clock of I2C-4 Generation
    CLOCK_PERI_UART0                    = 22UL, //Core Clock of UART-0 Generation
    CLOCK_PERI_UART1                    = 23UL, //Core Clock of UART-1 Generation
    CLOCK_PERI_UART2                    = 24UL, //Core Clock of UART-2 Generation
    CLOCK_PERI_UART3                    = 25UL, //Core Clock of UART-3 Generation
    CLOCK_PERI_CAN0                     = 26UL, //Core Clock of CAN-0 Generation
    CLOCK_PERI_CAN1                     = 27UL, //Core Clock of CAN-1 Generation
    CLOCK_PERI_CAN2                     = 28UL, //Core Clock of CAN-2 Generation
    CLOCK_PERI_CAN3                     = 29UL, //Core Clock of CAN-3 Generation
    CLOCK_PERI_ADC                      = 30UL, //Clock of ADC Generation
    CLOCK_PERI_PDM                      = 31UL, //Clock of PDM Generation
    CLOCK_PERI_ICTC0                    = 32UL, //Clock of ICTC-0 Generation
    CLOCK_PERI_ICTC1                    = 33UL, //Clock of ICTC-1 Generation
    CLOCK_PERI_ICTC2                    = 34UL, //Clock of ICTC-2 Generation
    CLOCK_PERI_TPA_GMAC0                = 35UL, //Clock of GMAC-0 Generation
    CLOCK_PERI_TPA_GMAC1                = 36UL, //Clock of GMAC-1 Generation
    CLOCK_PERI_TPA_TS                   = 37UL, //Clock of Timestamp Generation
    CLOCK_PERI_LPA                      = 38UL, //Clock of LPA Generation
    CLOCK_PERI_SFMC0                    = 39UL, //SFMC-0 Peripheral Clock Generation
    CLOCK_PERI_SFMC1                    = 40UL, //SFMC-1 Peripheral Clock Generation
    CLOCK_PERI_SFMC0_1600               = 41UL, //SFMC-0 Peripheral Clock 1600MHz Generation
    CLOCK_PERI_SFMC1_1600               = 42UL, //SFMC-1 Peripheral Clock 1600MHz Generation
    CLOCK_PERI_PCIE_PHY                 = 43UL, //PCIe PHY CR Peripheral Clock Generation
    CLOCK_PERI_HSM_GPSB                 = 44UL, //Clock of HSM GPSB Clock Generation
    CLOCK_PERI_SYNC_EXT0                = 45UL, //Sync.Clock of Ext.Port 0 Generation
    CLOCK_PERI_SYNC_EXT1                = 46UL, //Sync.Clock of Ext.Port 1 Generation
    CLOCK_PERI_SYNC_EXT2                = 47UL, //Sync.Clock of Ext.Port 2 Generation
    CLOCK_PERI_SYNC_EXT3                = 48UL, //Sync.Clock of Ext.Port 3 Generation
    CLOCK_PERI_SYNC_EXT4                = 49UL, //Sync.Clock of Ext.Port 4 Generation
    CLOCK_PERI_SYNC_EXT5                = 50UL, //Sync.Clock of Ext.Port 5 Generation
    CLOCK_PERI_SYNC_EXT6                = 51UL, //Sync.Clock of Ext.Port 6 Generation
    CLOCK_PERI_SYNC_EXT7                = 52UL, //Sync.Clock of Ext.Port 7 Generation
    CLOCK_PERI_SYNC_EXT8                = 53UL, //Sync.Clock of Ext.Port 8 Generation
    CLOCK_PERI_SYNC_EXT9                = 54UL, //Sync.Clock of Ext.Port 9 Generation
    CLOCK_PERI_SYNC_EXT10               = 55UL, //Sync.Clock of Ext.Port 10 Generation
    CLOCK_PERI_SYNC_EXT11               = 56UL, //Sync.Clock of Ext.Port 11 Generation
    CLOCK_PERI_SYNC_EXT12               = 57UL, //Sync.Clock of Ext.Port 12 Generation
    CLOCK_PERI_SYNC_EXT13               = 58UL, //Sync.Clock of Ext.Port 13 Generation
    CLOCK_PERI_SYNC_EXT14               = 59UL, //Sync.Clock of Ext.Port 14 Generation
    CLOCK_PERI_SYNC_EXT15               = 60UL, //Sync.Clock of Ext.Port 15 Generation

    CLOCK_PERI_MAX                      = 61UL
}CLOCKPeri_t;

#define CLOCK_PERI_FIRST                (CLOCK_PERI_TIMER0_XCLK)

/* I/O Bus pwdn/swreset */
typedef enum CLOCK_IO_BUS
{
    CLOCK_IOBUS_CAN_WRAP                = 0,
    CLOCK_IOBUS_CAN0                   = 1,
    CLOCK_IOBUS_CAN1                   = 2,
    CLOCK_IOBUS_CAN2                   = 3,
    CLOCK_IOBUS_CAN3                   = 4,
    CLOCK_IOBUS_CAN_CONF                = 5,
    CLOCK_IOBUS_GPSB_WRAP               = 6,
    CLOCK_IOBUS_GPSB0                  = 7,
    CLOCK_IOBUS_GPSB1                  = 8,
    CLOCK_IOBUS_GPSB2                  = 9,
    CLOCK_IOBUS_GPSB3                  = 10,
    CLOCK_IOBUS_GPSB4                  = 11,
    CLOCK_IOBUS_GPSB5                  = 12,
    CLOCK_IOBUS_GPSB_SM                 = 13,
    CLOCK_IOBUS_GPSB_CONF               = 14,
    CLOCK_IOBUS_ADC                     = 15,
    CLOCK_IOBUS_PDM                     = 16,
    CLOCK_IOBUS_ICTC_WRAP               = 17,
    CLOCK_IOBUS_ICTC0                  = 18,
    CLOCK_IOBUS_ICTC1                  = 19,
    CLOCK_IOBUS_ICTC2                  = 20,

    CLOCK_IOBUS_UART_WRAP               = 21,
    CLOCK_IOBUS_UART0                  = 22,
    CLOCK_IOBUS_UART1                  = 23,
    CLOCK_IOBUS_UART2                  = 24,
    CLOCK_IOBUS_UART3                  = 25,
    CLOCK_IOBUS_UART0_DMA              = 26,
    CLOCK_IOBUS_UART1_DMA              = 27,
    CLOCK_IOBUS_UART2_DMA              = 28,
    CLOCK_IOBUS_UART3_DMA              = 29,
    CLOCK_IOBUS_UART_CONF               = 30,
    CLOCK_IOBUS_I2C_WRAP                = 31,
    CLOCK_IOBUS_I2C0                   = 32,
    CLOCK_IOBUS_I2C1                   = 33,
    CLOCK_IOBUS_I2C2                   = 34,
    CLOCK_IOBUS_I2C3                   = 35,
    CLOCK_IOBUS_I2C4                   = 36,
    CLOCK_IOBUS_I2C_CONF                = 37,
    CLOCK_IOBUS_MAX                     = 38
}CLOCKIobus_t;

#define CLOCK_IOBUS_FIRST_0             (CLOCK_IOBUS_CAN_WRAP)
#define CLOCK_IOBUS_LAST_0              (CLOCK_IOBUS_ICTC2)
#define CLOCK_IOBUS_FIRST_1             (CLOCK_IOBUS_UART_WRAP)
#define CLOCK_IOBUS_LAST_1              (CLOCK_IOBUS_I2C_CONF)

typedef struct CLOCK_PMS
{
    uint32  uiFpll;
    uint32  uiEn;
    uint32  uiP;
    uint32  uiM;
    uint32  uiS;
    uint32  uiSrc;
} CLOCKPms_t;

typedef struct CLOCK_CLK_CTRL
{
    uint32  uiFreq;
    uint32  uiEn;
    uint32  uiConf;
    uint32  uiSel;
} CLOCKClkCtrl_t;

typedef struct CLOCK_PCLK_CTRL
{
    uint32  uiPeriName;
    uint32  uiFreq;
    uint32  uiMd;
    uint32  uiEn;
    uint32  uiSel;
    uint32  uiDivVal;
} CLOCKPclkCtrl_t;

#endif /* __SIC_BSP_CLOCK_DEV_HEADER__ */

