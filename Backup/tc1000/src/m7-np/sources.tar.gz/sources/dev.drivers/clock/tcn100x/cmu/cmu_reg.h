/*
***************************************************************************************************
*
*   FileName : cmu_reg.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_CMU_REG_HEADER
#define SIC_BSP_CMU_REG_HEADER

#define CMU_BASE_ADDR                 (SIC_BSP_CMU_BASE)

/*
 * CMU Register Offsets
 */
#define PLL0_FOUT_CTRL                  (0x000UL)
#define PLL0_FOUT_LIMIT                 (0x004UL)
#define PLL1_FOUT_CTRL                  (0x008UL)
#define PLL1_FOUT_LIMIT                 (0x00CUL)
#define CPU_CLK_CTRL                    (0x010UL)
#define CPU_CLK_LIMIT                   (0x014UL)
#define BUS_CLK_CTRL                    (0x018UL)
#define BUS_CLK_LIMIT                   (0x01CUL)
#define PERI_CLK0_CTRL                  (0x020UL)
#define PERI_CLK0_LIMIT                 (0x024UL)
#define PERI_CLK1_CTRL                  (0x028UL)
#define PERI_CLK1_LIMIT                 (0x02CUL)
#define PERI_CLK2_CTRL                  (0x030UL)
#define PERI_CLK2_LIMIT                 (0x034UL)
#define PERI_CLK3_CTRL                  (0x038UL)
#define PERI_CLK3_LIMIT                 (0x03CUL)
#define PERI_CLK4_CTRL                  (0x040UL)
#define PERI_CLK4_LIMIT                 (0x044UL)
#define PERI_CLK5_CTRL                  (0x048UL)
#define PERI_CLK5_LIMIT                 (0x04CUL)
#define PERI_CLK6_CTRL                  (0x050UL)
#define PERI_CLK6_LIMIT                 (0x054UL)
#define PERI_CLK7_CTRL                  (0x058UL)
#define PERI_CLK7_LIMIT                 (0x05CUL)
#define PERI_CLK8_CTRL                  (0x060UL)
#define PERI_CLK8_LIMIT                 (0x064UL)
#define PERI_CLK9_CTRL                  (0x068UL)
#define PERI_CLK9_LIMIT                 (0x06CUL)
#define PERI_CLK10_CTRL                 (0x070UL)
#define PERI_CLK10_LIMIT                (0x074UL)
#define CLK_FAULT_CTRL                  (0x120UL)
#define CLK_FAULT_STS                   (0x124UL)
#define TIMEOUT_STS0                    (0x128UL)
#define TIMEOUT_STS1                    (0x12CUL)
#define CLKSTOP_STS0                    (0x130UL)
#define CLKSTOP_STS1                    (0x134UL)
#define PERI_CLK_MON_EN                 (0x138UL)
#define CMU_CFG_WR_PW                   (0x13CUL)
#define SF_CHK_GRP_EN0                  (0x1D0UL)
#define SF_CHK_GRP_EN1                  (0x1D4UL)
#define SF_CHK_GRP_EN2                  (0x1D8UL)
#define SF_CHK_GRP_STS0                 (0x1E0UL)
#define SF_CHK_GRP_STS1                 (0x1E4UL)
#define SF_CHK_GRP_STS2                 (0x1E8UL)
#define SF_CTRL_CFG                     (0x1F0UL)
#define PLL0FOUT_CNT                    (0x200UL)
#define PLL1FOUT_CNT                    (0x204UL)
#define CPUCLK_CNT                      (0x208UL)
#define BUSCLK_CNT                      (0x20CUL)
#define PERICLK0_CNT                    (0x210UL)
#define PERICLK1_CNT                    (0x214UL)
#define PERICLK2_CNT                    (0x218UL)
#define PERICLK3_CNT                    (0x21CUL)
#define PERICLK4_CNT                    (0x220UL)
#define PERICLK5_CNT                    (0x224UL)
#define PERICLK6_CNT                    (0x228UL)
#define PERICLK7_CNT                    (0x22CUL)
#define PERICLK8_CNT                    (0x230UL)
#define PERICLK9_CNT                    (0x234UL)
#define PERICLK10_CNT                   (0x238UL)


#define CMU_REG(off)                    (*(SALReg32 *)((CMU_BASE_ADDR)+(off)))

#define CMU_SET(off,lsb,msk,val)        { \
                                            (*(SALReg32 *)((CMU_BASE_ADDR)+(CMU_CFG_WR_PW))) = 0x5AFEACE5UL; \
                                            (*(SALReg32 *)((CMU_BASE_ADDR)+(off))) &= ~(msk << lsb); \
                                            (*(SALReg32 *)((CMU_BASE_ADDR)+(CMU_CFG_WR_PW))) = 0x5AFEACE5UL; \
                                            (*(SALReg32 *)((CMU_BASE_ADDR)+(off))) |= (val << lsb); \
                                        }

#define CMU_GET(off)                    (*(SALReg32 *)((CMU_BASE_ADDR)+(off)))

#endif /* __SIC_BSP__CMU_REG_HEADER__ */

