/*
***************************************************************************************************
*
*   FileName : clock_dev.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include <string.h>
#include "reg_phys.h"
#include "clock.h"
#include "clock_dev.h"
#include "clock_reg.h"

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/

#define CLOCK_CLKDIV_0_ADDR             (CLOCK_BASE_ADDR + CLOCK_MCKC_CLKDIVC)
#define CLOCK_CLKDIV_1_ADDR             (CLOCK_BASE_ADDR + CLOCK_MCKC_CLKDIVC1)
#define CLOCK_CLKCTRL_ADDR              (CLOCK_BASE_ADDR + CLOCK_MCKC_CLKCTRL)
#define CLOCK_CLKHCLK_0_ADDR            (SIC_BSP_IO_SUBSYS_BASE + CLOCK_MCKC_HCLK0)
#define CLOCK_CLKHCLK_1_ADDR            (SIC_BSP_IO_SUBSYS_BASE + CLOCK_MCKC_HCLK1)
#define CLOCK_CLKHCLKSW_0_ADDR          (SIC_BSP_IO_SUBSYS_BASE + CLOCK_MCKC_HCLKSWR0)
#define CLOCK_CLKHCLKSW_1_ADDR          (SIC_BSP_IO_SUBSYS_BASE + CLOCK_MCKC_HCLKSWR1)

/***************************************************************************************************
*                                             LOCAL VARIABLES
***************************************************************************************************/
typedef struct CLOCKPeriAddr
{
    uint32 addr[CLOCK_PERI_MAX];
} *CLOCKPeriReg;
static uint32                           stMicomClockSource[CLOCK_SRC_MAX_NUM];
static CLOCKPeriReg                     puiClkPeriCtl = (CLOCKPeriReg) (CLOCK_BASE_ADDR + CLOCK_MCKC_PCLKCTRL);
static uint32*                          puiClkPll0Pms = (uint32 *) (CLOCK_BASE_ADDR + CLOCK_MCKC_PLL0PMS);
static uint32*                          puiClkPll1Pms = (uint32 *) (CLOCK_BASE_ADDR + CLOCK_MCKC_PLL1PMS);
static uint32*                          puiClkPll2Pms = (uint32 *) (CLOCK_BASE_ADDR + CLOCK_MCKC_PLL2PMS);
static uint32*                          puiClkPll3Pms = (uint32 *) (CLOCK_BASE_ADDR + CLOCK_MCKC_PLL3PMS);
/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/

static void   CLOCK_DevWritePll
(
    uint32*                             uiReg,
    uint32                              uiEn,
    uint32                              uiP,
    uint32                              uiM,
    uint32                              uiS
);

static void   CLOCK_DevWritePclkCtrl
(
    SALAddr*                            uiReg,
    uint32                              uiMd,
    uint32                              uiEn,
    uint32                              uiSel,
    uint32                              uiDiv,
    uint32                              uiType
);

static sint32 CLOCK_DevFindPms
(
    CLOCKPms_t*                         psPll,
    uint32                              uiSrcFreq
);

static sint32 CLOCK_DevSetPllRate
(
    SALAddr*                            uiReg,
    uint32                              uiRate
);

static uint32 CLOCK_DevGetPllRate
(
    const SALAddr*                      uiReg
);

static uint32 CLOCK_DevGetPllDiv
(
    sint32                              iId
);

static uint32 CLOCK_DevCalPclkDiv
(
    const CLOCKPclkCtrl_t*              psPclkCtrl,
    uint32*                             puiClkDiv,
    const uint32                        uiSrcClk,
    CLOCKDivMax_t                       uiDivMax
);

#if 0
static sint32 CLOCK_DevFindPclk
(
    CLOCKPclkCtrl_t *                   psPclkCtrl,
    CLOCKPclkCtrlType_t                 eType
);
#endif

static void   CLOCK_DevResetClkSrc
(
    sint32                              iId
);

/* PLL Configuration Macro */
static void CLOCK_DevWritePll
(
    uint32*                             uiReg,
    uint32                              uiEn,
    uint32                              uiP,
    uint32                              uiM,
    uint32                              uiS
)
{
    const uint32    uiTimeout  = 4000000000UL;
    uint32          uiDelay;
    uint32          uiTryCnt;

    uiDelay     = 0;
    uiTryCnt    = 0;

    if(uiReg != NULL)
    {
        if (uiEn != 0UL)
        {
            if((uiReg == puiClkPll0Pms) || (uiReg == puiClkPll1Pms))
            {
                *uiReg |= (0UL | (1UL << (uint32)CLOCK_PLL_LOCKEN_SHIFT) |
                        (2UL << (uint32)CLOCK_PLL_CHGPUMP_SHIFT));
            }

            *uiReg |= ((((uiS) & (uint32)CLOCK_PLL_S_MASK) << (uint32)CLOCK_PLL_S_SHIFT) |
                    (((uiM) & (uint32)CLOCK_PLL_M_MASK) << (uint32)CLOCK_PLL_M_SHIFT) |
                    (((uiP) & (uint32)CLOCK_PLL_P_MASK) << (uint32)CLOCK_PLL_P_SHIFT));

            for (uiDelay = 100UL ; uiDelay > 0UL ; uiDelay--)
            {
                ;  /* if cpu clokc is 1HGz then loop 100. */
            }

            *uiReg |= (((uiEn) & 1UL) << (uint32)CLOCK_PLL_EN_SHIFT);

            if((uiReg == puiClkPll0Pms) || (uiReg == puiClkPll1Pms))
            {
                while((*uiReg & (1UL << (uint32)CLOCK_PLL_LOCKST_SHIFT)) == 0UL)
                {
                    uiTryCnt++;

                    if(uiTryCnt > uiTimeout)
                    {
                        break;
                    }
                }
            }
        }
        else
        {
            *uiReg &= (~(1UL << (uint32)CLOCK_PLL_EN_SHIFT));
        }
    }
}

static void CLOCK_DevWritePclkCtrl
(
    SALAddr*                            uiReg,
    uint32                              uiMd,
    uint32                              uiEn,
    uint32                              uiSel,
    uint32                              uiDiv,
    uint32                              uiType
)
{
    if (uiType == (uint32)CLOCK_PCLKCTRL_TYPE_XXX)
    {
        *uiReg &= (~(1UL << (uint32)CLOCK_PCLKCTRL_OUTEN_SHIFT));
        *uiReg &= (~(1UL << (uint32)CLOCK_PCLKCTRL_DIVEN_SHIFT));
        *uiReg = (*uiReg & (~((uint32) CLOCK_PCLKCTRL_DIV_XXX_MASK << (uint32)CLOCK_PCLKCTRL_DIVEN_SHIFT))) |
                 ((uiDiv & (uint32) CLOCK_PCLKCTRL_DIV_XXX_MASK) << (uint32) CLOCK_PCLKCTRL_DIVEN_SHIFT);
        *uiReg = (*uiReg & (~((uint32)CLOCK_PCLKCTRL_SEL_MASK << (uint32)CLOCK_PCLKCTRL_SEL_SHIFT))) |
                 ((uiSel & (uint32) CLOCK_PCLKCTRL_SEL_MASK) << (uint32)CLOCK_PCLKCTRL_SEL_SHIFT);
        *uiReg = (*uiReg & ~(1UL << (uint32)CLOCK_PCLKCTRL_DIVEN_SHIFT)) | ((uiEn & 1UL) << (uint32)CLOCK_PCLKCTRL_DIVEN_SHIFT);
        *uiReg = (*uiReg & ~(1UL << (uint32)CLOCK_PCLKCTRL_OUTEN_SHIFT)) | ((uiEn & 1UL) << (uint32)CLOCK_PCLKCTRL_OUTEN_SHIFT);
    }
    else if (uiType == (uint32)CLOCK_PCLKCTRL_TYPE_YYY)
    {
        *uiReg &= (~(1UL << (uint32)CLOCK_PCLKCTRL_DIVEN_SHIFT));
        *uiReg = (*uiReg & (~((uint32)CLOCK_PCLKCTRL_DIV_YYY_MASK << (uint32)CLOCK_PCLKCTRL_DIVEN_SHIFT))) |
                 ((uiDiv&(uint32)CLOCK_PCLKCTRL_DIV_YYY_MASK) << (uint32)CLOCK_PCLKCTRL_DIVEN_SHIFT);
        *uiReg = (*uiReg & (~((uint32)CLOCK_PCLKCTRL_SEL_MASK << (uint32)CLOCK_PCLKCTRL_SEL_SHIFT))) |
                 ((uiSel&(uint32)CLOCK_PCLKCTRL_SEL_MASK) << (uint32)CLOCK_PCLKCTRL_SEL_SHIFT);
        *uiReg = (*uiReg & (~(1UL << (uint32)CLOCK_PCLKCTRL_OUTST_SHIFT))) | ((uiMd&1UL) << (uint32)CLOCK_PCLKCTRL_OUTST_SHIFT);
        *uiReg = (*uiReg & (~(1UL << (uint32)CLOCK_PCLKCTRL_DIVEN_SHIFT))) | ((uiEn&1UL) << (uint32)CLOCK_PCLKCTRL_DIVEN_SHIFT);
    }
    else
    {
        ; //empty statement
    }
}

static sint32 CLOCK_DevFindPms
(
    CLOCKPms_t *                        psPll,
    uint32                              uiSrcFreq
)
{
    uint64 ullPll;
    uint64 ullSrc;
    uint64 ullFvco;
    uint64 ullSrchP;
    uint64 ullSrchM;
    uint64 ullTemp;
    uint64 ullSrchPll;

    uint32 uiErr;
    uint32 uiSrchErr;

    sint32  iSrchS;
    sint32  ret;

    ret = 0L;

    if (psPll != NULL)
    {
        if (psPll->uiFpll != 0UL)
        {
            ullPll = (uint64)psPll->uiFpll;
            ullSrc = (uint64)uiSrcFreq;
            uiErr       = 0xFFFFFFFFUL;

            for (iSrchS = (sint32)CLOCK_PLL_S_MIN ; iSrchS <= (sint32)CLOCK_PLL_S_MAX ; iSrchS++)
            {
                ullFvco = ullPll << (uint64)iSrchS;

                if ((ullFvco >= (uint64)CLOCK_PLL_VCO_MIN) && (ullFvco <= (uint64)CLOCK_PLL_VCO_MAX))
                {
                    for (ullSrchP = (uint64)CLOCK_PLL_P_MIN \
                            ; ullSrchP <= (uint64)CLOCK_PLL_P_MAX \
                            ; ullSrchP++)
                    {
                        ullSrchM    = ullFvco*ullSrchP;
                        (void)SAL_CoreDiv64To32(&(ullSrchM), (uint32)uiSrcFreq, NULL);

                        if ((ullSrchM < (uint64)CLOCK_PLL_M_MIN) || (ullSrchM > (uint64)CLOCK_PLL_M_MAX))
                        {
                            continue;
                        }

                        ullTemp = ullSrchM*ullSrc;
                        (void)SAL_CoreDiv64To32(&(ullTemp), (uint32)ullSrchP, NULL);
                        ullSrchPll  = (ullTemp>>(uint64)iSrchS);

                        if ((ullSrchPll < (uint64)CLOCK_PLL_MIN_RATE) \
                                || (ullSrchPll > (uint64)CLOCK_PLL_MAX_RATE))
                        {
                            continue;
                        }

                        uiSrchErr = (uint32)((ullSrchPll > ullPll) ? (ullSrchPll - ullPll) \
                                : (ullPll - ullSrchPll));

                        if (uiSrchErr < uiErr)
                        {
                            uiErr       = uiSrchErr;
                            psPll->uiP  = (uint32)ullSrchP;
                            psPll->uiM  = (uint32)ullSrchM;
                            psPll->uiS  = (uint32)iSrchS;
                        }
                    }
                }
            }

            if (uiErr < 0xFFFFFFFFUL)
            {
                ullTemp = ullSrc * (uint64)psPll->uiM;
                (void)SAL_CoreDiv64To32(&(ullTemp), (uint32)(psPll->uiP), NULL);
                psPll->uiFpll   = (uint32) ((ullTemp >> ((psPll->uiS > (uint32) CLOCK_PLL_S_MAX) ? (uint32) CLOCK_PLL_S_MAX : psPll->uiS)) & 0xFFFFFFFFUL);
                psPll->uiEn     = 1;
            }
            else
            {
                ret = -1L;
            }
        }
        else
        {
            psPll->uiEn = 0;
        }
    }

    return ret;
}

static sint32 CLOCK_DevSetPllRate
(
    SALAddr*                            uiReg,
    uint32                              uiRate
)
{
    CLOCKPms_t  sPll = {0, };
    uint64      ullCalM;
    sint32      iErr;

    iErr    = 0;
    sPll.uiFpll = uiRate;

    if (CLOCK_DevFindPms(&sPll, CLOCK_XIN_CLK_RATE) != 0L)
    {
        //goto tcc_ckc_setpll2_failed;
        ullCalM = (uint64)CLOCK_PLL_P_MIN * (uint64)CLOCK_PLL_VCO_MIN;
        ullCalM += (uint64)CLOCK_XIN_CLK_RATE;
        ullCalM /= (uint64)CLOCK_XIN_CLK_RATE;
        CLOCK_DevWritePll(                  \
                uiReg,                      \
                0UL,                        \
                (uint32)CLOCK_PLL_P_MIN,    \
                (uint32)ullCalM,            \
                (uint32)CLOCK_PLL_S_MIN     \
                );
        iErr = -1;
    }
    else
    {
        CLOCK_DevWritePll(uiReg, sPll.uiEn, sPll.uiP, sPll.uiM, sPll.uiS);
    }

    return iErr;
}

static uint32 CLOCK_DevGetPllRate
(
    const SALAddr*                      uiReg
)
{
    uint32      uiRegVa;
    CLOCKPms_t  sPllCfg;
    uint64      ullTemp;
    uint32      ret;

    ret = 0UL;

    if(uiReg != NULL)
    {
        uiRegVa = (*uiReg);
        sPllCfg.uiP     = (uiRegVa >> (uint32)CLOCK_PLL_P_SHIFT) & ((uint32)CLOCK_PLL_P_MASK);
        sPllCfg.uiM     = (uiRegVa >> (uint32)CLOCK_PLL_M_SHIFT) & ((uint32)CLOCK_PLL_M_MASK);
        sPllCfg.uiS     = (uiRegVa >> (uint32)CLOCK_PLL_S_SHIFT) & ((uint32)CLOCK_PLL_S_MASK);
        ullTemp         = (uint64)CLOCK_XIN_CLK_RATE * (uint64)sPllCfg.uiM;
        (void)SAL_CoreDiv64To32(&ullTemp, (uint32)(sPllCfg.uiP), NULL);
        ret = (uint32) ((ullTemp >> ((sPllCfg.uiS > (uint32) CLOCK_PLL_S_MAX) ? (uint32) CLOCK_PLL_S_MAX : sPllCfg.uiS)) & 0xFFFFFFFFUL);
    }
    else
    {
        ret = 0UL;
    }

    return ret;
}

static uint32 CLOCK_DevGetPllDiv
(
    sint32                              iId
)
{
    uint32              uiRet;
    CLOCKMpll_t         uiMpllId;
    SALAddr*      uiReg;
    uint32              uiOffSet;
    uint32              uiRegVa;

    uiRet       = 0;
    uiMpllId    = (CLOCKMpll_t)iId;
    uiRegVa     = 0;

    switch(uiMpllId)
    {
        case CLOCK_MPLL_0:
            {
                uiReg       = (SALAddr*)CLOCK_CLKDIV_0_ADDR;
                uiOffSet    = 16UL;
                break;
            }
        case CLOCK_MPLL_1:
            {
                uiReg       = (SALAddr*)CLOCK_CLKDIV_0_ADDR;
                uiOffSet    = 8UL;
                break;
            }
        case CLOCK_MPLL_2:
            {
                uiReg       = (SALAddr*)CLOCK_CLKDIV_0_ADDR;
                uiOffSet    = 0UL;
                break;
            }
        case CLOCK_MPLL_3:
            {
                uiReg       = (SALAddr*)CLOCK_CLKDIV_1_ADDR;
                uiOffSet    = 24UL;
                break;
            }

        case CLOCK_MPLL_XIN:
            {
                uiReg       = (SALAddr*)CLOCK_CLKDIV_1_ADDR;
                uiOffSet    = 8UL;
                break;
            }
        case CLOCK_MPLL_XTIN:
            {
                uiReg       = (SALAddr*)CLOCK_CLKDIV_1_ADDR;
                uiOffSet    = 0UL;
                break;
            }
            default:
            {
                uiOffSet = 0xFFFFFFFFUL;
                break;
            }

    }

    uiRegVa = (*uiReg);

    if(uiOffSet != 0xFFFFFFFFUL)
    {
        uiRet = ((uiRegVa >> uiOffSet) & 0x3FUL);

        if(uiRet == 0UL)
        {
            uiRet++;
        }
    }

    return uiRet;
}

static uint32 CLOCK_DevCalPclkDiv
(
    const CLOCKPclkCtrl_t *             psPclkCtrl,
    uint32 *                            puiClkDiv,
    const uint32                        uiSrcClk,
    CLOCKDivMax_t                       uiDivMax
)
{
    uint32 uiClkRate1;
    uint32 uiClkRate2;
    uint32 uiErr1;
    uint32 uiErr2;
    uint32 ret;

    ret = 0UL;

    if(psPclkCtrl != NULL)
    {
        if(puiClkDiv != NULL)
        {
            if (uiSrcClk <= psPclkCtrl->uiFreq)
            {
                *puiClkDiv = 1UL;
            }
            else
            {
                *puiClkDiv = uiSrcClk/psPclkCtrl->uiFreq;
            }

            if ((*puiClkDiv) > (uint32) uiDivMax)
            {
                *puiClkDiv = (uint32) uiDivMax;
            }

            uiClkRate1  = (uiSrcClk) / (*puiClkDiv);
            uiClkRate2  = (uiSrcClk) / (((*puiClkDiv) < ((uint32) uiDivMax)) ? ((*puiClkDiv) + 1UL) : (*puiClkDiv));
            uiErr1      = (uiClkRate1 > psPclkCtrl->uiFreq) ? (uiClkRate1 - psPclkCtrl->uiFreq) \
                          : (psPclkCtrl->uiFreq - uiClkRate1);
            uiErr2      = (uiClkRate2 > psPclkCtrl->uiFreq) ? (uiClkRate2 - psPclkCtrl->uiFreq) \
                          : (psPclkCtrl->uiFreq - uiClkRate2);

            if (uiErr1 > uiErr2)
            {
                *puiClkDiv += 1UL;
            }

            ret = (uiErr1 < uiErr2) ? uiErr1 : uiErr2;
        }
    }


    return ret;
}

#if 0
static sint32 CLOCK_DevFindPclk
(
    CLOCKPclkCtrl_t *                   psPclkCtrl,
    CLOCKPclkCtrlType_t                 eType
)
{
    sint32              iRet;
    sint32              iLastIdx;
    sint32              iIdx;
    CLOCKDivMax_t       uiDivMax;
    uint32              uiSrchSrc;
    uint32              uiErrDiv;
    uint32              uiMd;
    uint32              uiDiv[CLOCK_SRC_MAX_NUM] = {0UL, };
    uint32              uiErr[CLOCK_SRC_MAX_NUM] = {0UL, };
    uint32              uiDivDiv;
    sint32              ret;
    CLOCKPclkCtrlMode_t tPclkSel;

    uiDivDiv    = CLOCK_PCLKCTRL_DIV_MIN;
    tPclkSel    = CLOCK_PCLKCTRL_MODE_DIVIDER;
    iRet        = 0L;
    ret         = 0L;

    if(psPclkCtrl != NULL)
    {
        psPclkCtrl->uiMd    = (uint32)tPclkSel;
        uiDivMax            = CLOCK_PCLKCTRL_DIV_XXX_MAX_PLUS;

        uiSrchSrc   = 0xFFFFFFFFUL;
        iLastIdx    = (sint32)CLOCK_SRC_MAX_NUM - 1L;

        for (iIdx = iLastIdx ; iIdx >= 0L ; iIdx--)
        {
            if (stMicomClockSource[iIdx] == 0UL)
            {
                continue;
            }

            if ((stMicomClockSource[iIdx] >= (uint32)CLOCK_PCLKCTRL_MAX_FCKS) \
                    && (eType == CLOCK_PCLKCTRL_TYPE_XXX) )
            {
                continue;
            }

            /* divider mode */
            uiErrDiv = CLOCK_DevCalPclkDiv(psPclkCtrl, &uiDivDiv, stMicomClockSource[iIdx], uiDivMax);

            uiErr[iIdx] = uiErrDiv;
            uiDiv[iIdx] = uiDivDiv;
            uiMd        = (uint32)tPclkSel;

            if (uiSrchSrc == 0xFFFFFFFFUL)
            {
                uiSrchSrc           = (uint32)iIdx;
                psPclkCtrl->uiMd    = uiMd;
            }
            else
            {
                /* find similar clock */
                if (uiErr[iIdx] < uiErr[uiSrchSrc])
                {
                    uiSrchSrc           = (uint32)iIdx;
                    psPclkCtrl->uiMd    = uiMd;
                }
                else
                {
                    ;
                }
            }
        }

        switch(uiSrchSrc)
        {
            case (uint32)CLOCK_MPLL_0:
            {
                psPclkCtrl->uiSel = (uint32)CLOCK_MPCLKCTRL_SEL_PLL0;
                break;
            }
            case (uint32)CLOCK_MPLL_1:
            {
                psPclkCtrl->uiSel = (uint32)CLOCK_MPCLKCTRL_SEL_PLL1;
                break;
            }
            case (uint32)CLOCK_MPLL_2:
            {
                psPclkCtrl->uiSel = (uint32)CLOCK_MPCLKCTRL_SEL_PLL2;
                break;
            }
            case (uint32)CLOCK_MPLL_3:
            {
                psPclkCtrl->uiSel = (uint32)CLOCK_MPCLKCTRL_SEL_PLL3;
                break;
            }
            case (uint32)CLOCK_MPLL_DIV_0:
            {
                psPclkCtrl->uiSel = (uint32)CLOCK_MPCLKCTRL_SEL_PLL0DIV;
                break;
            }

            case (uint32)CLOCK_MPLL_DIV_1:
            {
                psPclkCtrl->uiSel = (uint32)CLOCK_MPCLKCTRL_SEL_PLL1DIV;
                break;
            }
            case (uint32)CLOCK_MPLL_DIV_2:
            {
                psPclkCtrl->uiSel = (uint32)CLOCK_MPCLKCTRL_SEL_PLL2DIV;
                break;
            }
            case (uint32)CLOCK_MPLL_DIV_3:
            {
                psPclkCtrl->uiSel = (uint32)CLOCK_MPCLKCTRL_SEL_PLL3DIV;
                break;
            }

            case (uint32)CLOCK_MPLL_XIN:
            {
                psPclkCtrl->uiSel = (uint32)CLOCK_MPCLKCTRL_SEL_XIN;
                break;
            }

            default:
            {
                iRet = -1;
                break;
            }
        }

        if(iRet == 0)
   	    {
            psPclkCtrl->uiDivVal    = uiDiv[uiSrchSrc];

            if ((psPclkCtrl->uiDivVal >= ((uint32)CLOCK_PCLKCTRL_DIV_MIN + 1UL)) && \
                    (psPclkCtrl->uiDivVal <= ((uint32) uiDivMax)))
            {
                psPclkCtrl->uiDivVal -= 1UL;
                psPclkCtrl->uiFreq  = stMicomClockSource[uiSrchSrc]/(psPclkCtrl->uiDivVal + 1UL);
            }
            else
            {
                ret = -1L;
            }
        }
        else
        {
            ret = -1L;
        }
    }
    else
    {
        ret = -1L;
    }

    return ret;
}
#endif

static void CLOCK_DevResetClkSrc
(
    sint32                              iId
)
{
    if ((iId >= 0) && (iId < CLOCK_PLL_MAX_NUM))
    {
        stMicomClockSource[iId] = CLOCK_GetPllRate(iId);
        stMicomClockSource[CLOCK_PLL_MAX_NUM + iId] = stMicomClockSource[iId] / (CLOCK_DevGetPllDiv(iId) + 1UL);
    }
}

void CLOCK_Init
(
    void
)
{
    static sint32 iInitialized = 0;
    uint32 uiIdx;

    if (iInitialized == 0L)
    {
        (void)CLOCK_SetPllDiv((sint32) CLOCK_MPLL_0, 2);
        (void)CLOCK_SetPllDiv((sint32) CLOCK_MPLL_1, 2);
        (void)CLOCK_SetPllDiv((sint32) CLOCK_MPLL_2, 2);
        (void)CLOCK_SetPllDiv((sint32) CLOCK_MPLL_3, 2);
        (void)CLOCK_SetPllDiv((sint32) CLOCK_MPLL_XIN, 2);
        (void)CLOCK_SetPllDiv((sint32) CLOCK_MPLL_XTIN, 2);

        for(uiIdx = 0UL; uiIdx < (uint32)CLOCK_SRC_MAX_NUM ; uiIdx++)
        {
            stMicomClockSource[uiIdx] = CLOCK_GetPllRate(uiIdx);
        }
        iInitialized = 1;
    }
}

sint32 CLOCK_SetPllDiv
(
    sint32                              iId,
    uint32                              uiPllDiv
)
{
    SALAddr*    uiReg;
    CLOCKMpll_t uiMpllId;
    CLOCKMpll_t uiMpllDivId;
    uint32      uiOffSet;
    uint32      uiRegVa;
    uint32      uiRealPllDiv;
    sint32      ret;

    uiMpllId        = (CLOCKMpll_t)iId;

    uiRegVa         = 0UL;
    uiRealPllDiv    = ((uiPllDiv > 1UL) ? (uiPllDiv - 1UL) : (0UL));
    ret             = 0L;

    switch(uiMpllId)
    {
        case CLOCK_MPLL_0:
        {
            uiReg    = (SALAddr *) CLOCK_CLKDIV_0_ADDR;
            uiOffSet    = 16UL;
            uiMpllDivId = CLOCK_MPLL_DIV_0;
            break;
        }
        case CLOCK_MPLL_1:
        {
            uiReg    = (SALAddr *) CLOCK_CLKDIV_0_ADDR;
            uiOffSet    = 8UL;
            uiMpllDivId = CLOCK_MPLL_DIV_1;
            break;
        }
        case CLOCK_MPLL_2:
        {
            uiReg    = (SALAddr *) CLOCK_CLKDIV_0_ADDR;
            uiOffSet    = 0UL;
            uiMpllDivId = CLOCK_MPLL_DIV_2;
            break;
        }
        case CLOCK_MPLL_3:
        {
            uiReg    = (SALAddr *) CLOCK_CLKDIV_1_ADDR;
            uiOffSet    = 24UL;
            uiMpllDivId = CLOCK_MPLL_DIV_3;
            break;
        }

        case CLOCK_MPLL_XIN:
        {
            uiReg    = (SALAddr *) CLOCK_CLKDIV_1_ADDR;
            uiOffSet = 8UL;
            uiMpllDivId = CLOCK_MPLL_XIN_DIV;
            break;
        }
        case CLOCK_MPLL_XTIN:
        {
            uiReg    = (SALAddr *) CLOCK_CLKDIV_1_ADDR;
            uiOffSet = 0UL;
            uiMpllDivId = CLOCK_MPLL_XTIN_DIV;
            break;
        }

        default:
        {
		    uiOffSet = 0xFFFFFFFFUL;
            break;
        }
    }

    if(uiOffSet != 0xFFFFFFFFUL)
   	{
        uiRegVa = (uint32)(*uiReg) & (~(((uint32)0xFFUL << uiOffSet)));
        *uiReg = uiRegVa;

        if (uiRealPllDiv != 0UL)
        {
            uiRegVa |= (0x80UL | (uiRealPllDiv & 0x3FUL)) << uiOffSet;
        }
        else
        {
            uiRegVa |= (((uint32)0x01UL) << uiOffSet);
        }

        *uiReg = uiRegVa;

        stMicomClockSource[(uint32)uiMpllDivId] = CLOCK_GetPllRate((sint32)uiMpllDivId);
    }
    else
    {
        ret = -1L;
    }

    return ret;
}

uint32 CLOCK_GetPllRate
(
    sint32                              iId
)
{
    CLOCKMpll_t  uiId;
    uint32      ret;

    ret     = 0UL;
    uiId = (CLOCKMpll_t)iId;

    switch(uiId)
    {
        case CLOCK_MPLL_0:
            {
                ret = CLOCK_DevGetPllRate((SALAddr *) (puiClkPll0Pms));

                break;
            }
        case CLOCK_MPLL_1:
            {
                ret = CLOCK_DevGetPllRate((SALAddr* ) (puiClkPll1Pms));
                break;
            }
        case CLOCK_MPLL_2:
            {
                ret = CLOCK_DevGetPllRate((SALAddr* ) (puiClkPll2Pms));
                break;
            }
        case CLOCK_MPLL_3:
            {
                ret = CLOCK_DevGetPllRate((SALAddr* ) (puiClkPll3Pms));
                break;
            }
        case CLOCK_MPLL_DIV_0:
            {
                ret = CLOCK_DevGetPllRate((SALAddr *) (puiClkPll0Pms))/
                    (CLOCK_DevGetPllDiv((sint32)CLOCK_MPLL_0)+1UL);
                break;
            }
        case CLOCK_MPLL_DIV_1:
            {
                ret = CLOCK_DevGetPllRate((SALAddr *) (puiClkPll1Pms))/
                    (CLOCK_DevGetPllDiv((sint32)CLOCK_MPLL_1)+1UL);
                break;
            }
        case CLOCK_MPLL_DIV_2:
            {
                ret = CLOCK_DevGetPllRate((SALAddr *) (puiClkPll2Pms))/
                    (CLOCK_DevGetPllDiv((sint32)CLOCK_MPLL_2)+1UL);
                break;
            }
        case CLOCK_MPLL_DIV_3:
            {
                ret = CLOCK_DevGetPllRate((SALAddr *) (puiClkPll3Pms))/
                    (CLOCK_DevGetPllDiv((sint32)CLOCK_MPLL_3)+1UL);
                break;
            }
        case CLOCK_MPLL_XIN:
            {
                ret = CLOCK_XIN_CLK_RATE;
                break;
            }
        case CLOCK_MPLL_XIN_DIV:
            {
                ret = CLOCK_XIN_CLK_RATE/(CLOCK_DevGetPllDiv((sint32)CLOCK_MPLL_XIN)+1UL);
                break;
            }
        case CLOCK_MPLL_XTIN:
            {
                ret = CLOCK_XTIN_CLK_RATE;
                break;
            }
        case CLOCK_MPLL_XTIN_DIV:
            {
                ret = CLOCK_XTIN_CLK_RATE/(CLOCK_DevGetPllDiv((sint32)CLOCK_MPLL_XTIN)+1UL);
                break;
            }
        default:
            {
                break;
            }
    }

    return ret;
}

sint32 CLOCK_SetPllRate
(
    sint32                              iId,
    uint32                              uiRate
)
{
    sint32              ret;
    CLOCKMpll_t          uiPllId;

    ret = 0L;
    uiPllId = (CLOCKMpll_t) iId;

    if (uiPllId == CLOCK_MPLL_0)
    {
        (void)CLOCK_DevSetPllRate((SALAddr *) (puiClkPll0Pms), uiRate);
    }
    else if (uiPllId == CLOCK_MPLL_1)
    {
        (void)CLOCK_DevSetPllRate((SALAddr *) (puiClkPll1Pms), uiRate);
    }
    else if (uiPllId == CLOCK_MPLL_2)
    {
        (void)CLOCK_DevSetPllRate((SALAddr *) (puiClkPll2Pms), uiRate);
    }
    else if (uiPllId == CLOCK_MPLL_3)
    {
        (void)CLOCK_DevSetPllRate((SALAddr *) (puiClkPll3Pms), uiRate);
    }
    else
    {
        ret = -1L;
    }

    if(ret == 0L)
    {
        stMicomClockSource[iId] = CLOCK_GetPllRate(iId);
    }

    return ret;
}

sint32 CLOCK_SetClkCtrlRate
(
    sint32                              iId,
    uint32                              uiRate
)
{
    SALAddr*    uiReg;
    uint32 uiRegVa;
    sint32 iRet;
    uint32 uiIdx;
    uint32 uiDivVa;
    uint32 uiSelVa;


    iRet = -1L;
    uiDivVa = 0UL;

    if(uiRate == 0UL)
    {
        if(iId < (sint32)CLOCK_MBUS_MAX_NUM)
        {
            uiReg = (SALAddr *) (CLOCK_CLKCTRL_ADDR + ((uint32)iId * 0x4UL));
            uiRegVa = (*uiReg);

            uiRegVa &= ~(0x1<<CLOCK_MCLKCTRL_EN_SHIFT);
            *uiReg = uiRegVa;
        }
    }
    else
    {
        for(uiIdx = 0UL; uiIdx < (uint32)CLOCK_SRC_MAX_NUM ; uiIdx++)
        {
            if((uiIdx != (uint32)CLOCK_MPLL_XTIN) && (uiIdx != (uint32)CLOCK_MPLL_XTIN_DIV))
            {
                if((stMicomClockSource[uiIdx] % uiRate) == 0UL)
                {
                    uiDivVa = stMicomClockSource[uiIdx] / uiRate;

                    if(uiDivVa <= CLOCK_MCLKCTRL_CONFIG_MASK)
                    {
                        break;
                    }
                    else
                    {
                        uiDivVa = 0UL;
                    }
                }
            }
        }

        if(uiDivVa > 0UL)
        {
            if(iId < (sint32)CLOCK_MBUS_MAX_NUM)
            {
                uiReg = (SALAddr *) (CLOCK_CLKCTRL_ADDR + ((uint32)iId * 0x4UL));
                uiRegVa = (*uiReg);

                uiRegVa &= ~(0x1<<CLOCK_MCLKCTRL_EN_SHIFT);
                *uiReg = uiRegVa;

                uiRegVa &= ~(CLOCK_MCLKCTRL_CONFIG_MASK << CLOCK_MCLKCTRL_CONFIG_SHIFT);
                uiRegVa &= ~(CLOCK_MCLKCTRL_SEL_MASK << CLOCK_MCLKCTRL_SEL_SHIFT);


                uiRegVa |= ((uiDivVa-1UL) << CLOCK_MCLKCTRL_CONFIG_SHIFT);

                switch(uiIdx)
                {
                    case CLOCK_MPLL_0:
                        {
                            uiSelVa = CLOCK_MCLKCTRL_SEL_PLL0;
                            break;
                        }
                    case CLOCK_MPLL_1:
                        {
                            uiSelVa = CLOCK_MCLKCTRL_SEL_PLL1;
                            break;
                        }
                    case CLOCK_MPLL_2:
                        {
                            uiSelVa = CLOCK_MCLKCTRL_SEL_PLL2;
                            break;
                        }
                    case CLOCK_MPLL_3:
                        {
                            uiSelVa = CLOCK_MCLKCTRL_SEL_PLL3;
                            break;
                        }
                    case CLOCK_MPLL_DIV_0:
                        {
                            uiSelVa = CLOCK_MCLKCTRL_SEL_PLL0DIV;
                            break;
                        }
                    case CLOCK_MPLL_DIV_1:
                        {
                            uiSelVa = CLOCK_MCLKCTRL_SEL_PLL1DIV;
                            break;
                        }
                    case CLOCK_MPLL_DIV_2:
                        {
                            uiSelVa = CLOCK_MCLKCTRL_SEL_PLL2DIV;
                            break;
                        }
                    case CLOCK_MPLL_DIV_3:
                        {
                            uiSelVa = CLOCK_MCLKCTRL_SEL_PLL3DIV;
                            break;
                        }
                    case CLOCK_MPLL_XIN:
                        {
                            uiSelVa = CLOCK_MCLKCTRL_SEL_XIN;
                            break;
                        }
                    case CLOCK_MPLL_XIN_DIV:
                        {
                            uiSelVa = CLOCK_MCLKCTRL_SEL_XINDIV;
                            break;
                        }
                    default:
                        {
                            break;
                        }
                }

                uiRegVa |= (uiSelVa << CLOCK_MCLKCTRL_CONFIG_SHIFT);
                *uiReg = uiRegVa;

                uiRegVa = (*uiReg);
                uiRegVa |= (0x1<<CLOCK_MCLKCTRL_EN_SHIFT);
                *uiReg = uiRegVa;

                iRet = 0L;
            }
        }
    }

    return iRet;
}

uint32 CLOCK_GetClkCtrlRate
(
    sint32                              iId
)
{
    SALAddr*    uiReg;
    uint32 uiRegVa;
    uint32 uiEn;
    uint32 uiSel;
    uint32 uiDiv;
    int32 iMSel;
    uint32 uiRet;

    uiRet = 0UL;

    if(iId < (sint32)CLOCK_MBUS_MAX_NUM)
    {
        uiReg = (SALAddr *) (CLOCK_CLKCTRL_ADDR + ((uint32)iId * 0x4UL));
        uiRegVa = (*uiReg);
        uiEn = (uint32)(((uiRegVa) >> CLOCK_MCLKCTRL_EN_SHIFT) & 0x1UL);

        if(uiEn > 0UL)
        {
            uiSel = (uint32)(((uiRegVa) >> CLOCK_MCLKCTRL_SEL_SHIFT) & CLOCK_MCLKCTRL_SEL_MASK);
            uiDiv = (uint32)(((uiRegVa) >> CLOCK_MCLKCTRL_CONFIG_SHIFT) & CLOCK_MCLKCTRL_CONFIG_MASK);

            switch((CLOCKMclkCtrlSel_t)uiSel)
            {
                case CLOCK_MCLKCTRL_SEL_PLL0    :
                    {
                        iMSel = (sint32)CLOCK_MPLL_0;
                        break;
                    }
                case CLOCK_MCLKCTRL_SEL_PLL1    :
                    {
                        iMSel = (sint32)CLOCK_MPLL_1;
                        break;
                    }
                case CLOCK_MCLKCTRL_SEL_PLL2    :
                    {
                        iMSel = (sint32)CLOCK_MPLL_2;
                        break;
                    }
                case CLOCK_MCLKCTRL_SEL_PLL3    :
                    {
                        iMSel = (sint32)CLOCK_MPLL_3;
                        break;
                    }
                case CLOCK_MCLKCTRL_SEL_XIN     :
                    {
                        iMSel = (sint32)CLOCK_MPLL_XIN;
                        break;
                    }
                case CLOCK_MCLKCTRL_SEL_PLL0DIV :
                    {
                        iMSel = (sint32)CLOCK_MPLL_DIV_0;
                        break;
                    }
                case CLOCK_MCLKCTRL_SEL_PLL1DIV :
                    {
                        iMSel = (sint32)CLOCK_MPLL_DIV_1;
                        break;
                    }
                case CLOCK_MCLKCTRL_SEL_PLL2DIV :
                    {
                        iMSel = (sint32)CLOCK_MPLL_DIV_2;
                        break;
                    }
                case CLOCK_MCLKCTRL_SEL_PLL3DIV :
                    {
                        iMSel = (sint32)CLOCK_MPLL_DIV_3;
                        break;
                    }
                case CLOCK_MCLKCTRL_SEL_XINDIV  :
                    {
                        iMSel = (sint32)CLOCK_MPLL_XIN_DIV;
                        break;
                    }
            }

            uiRet = CLOCK_GetPllRate(iMSel)/(uiDiv+1UL);
        }
    }

    return uiRet;
}


sint32 CLOCK_IsPeriEnabled
(
    sint32                              iId
)
{
    sint32 ret;
    const SALAddr* uiReg;

    if ((iId < (sint32) CLOCK_PERI_MAX) && (iId >= (sint32) CLOCK_PERI_FIRST))
    {
        uiReg = (SALAddr *) (&puiClkPeriCtl->addr[iId - (sint32) CLOCK_PERI_FIRST]);
        ret = (((*uiReg) & (1UL << (uint32)CLOCK_PCLKCTRL_OUTEN_SHIFT)) != 0UL) ? 1L : 0L;
    }
    else
    {
        ret = -1L;
    }

    return ret;
}

sint32 CLOCK_EnablePeri
(
    sint32                              iId
)
{
    sint32      ret;
    SALAddr*    uiReg;

    ret = 0L;

    if ((iId < (sint32) CLOCK_PERI_MAX) && (iId >= (sint32) CLOCK_PERI_FIRST))
    {
        uiReg = (SALAddr *) (&puiClkPeriCtl->addr[iId - (sint32) CLOCK_PERI_FIRST]);
        *uiReg |= (1UL << (uint32)CLOCK_PCLKCTRL_DIVEN_SHIFT);
        *uiReg |= (1UL << (uint32)CLOCK_PCLKCTRL_OUTEN_SHIFT);
    }
    else
    {
        ret = -1L;
    }

    return ret;
}

sint32 CLOCK_DisablePeri
(
    sint32                              iId
)
{
    sint32      ret;
    SALAddr*    uiReg;

    ret             = 0L;

    if ((iId < (sint32) CLOCK_PERI_MAX) && (iId >= (sint32) CLOCK_PERI_FIRST))
    {
        uiReg = (SALAddr *) (&puiClkPeriCtl->addr[iId - (sint32) CLOCK_PERI_FIRST]);
        *uiReg &= (~(1UL << (uint32)CLOCK_PCLKCTRL_DIVEN_SHIFT));
        *uiReg &= (~(1UL << (uint32)CLOCK_PCLKCTRL_OUTEN_SHIFT));
    }
    else
    {
        ret = -1L;
    }

    return ret;
}

uint32 CLOCK_GetPeriRate
(
    sint32                              iId
)
{
    const SALAddr*      uiReg;
    uint32              uiRegVa;
    uint32              uiSrcFreq;
    uint32              uiRet;
    CLOCKPclkCtrl_t     sPclkCtrl;
    CLOCKPclkctrlSel_t  uiPclkSel;

    uiRet = 0L;

    if ((iId < (sint32) CLOCK_PERI_MAX) && (iId >= (sint32) CLOCK_PERI_FIRST))
    {
        uiReg           = (SALAddr *) (&puiClkPeriCtl->addr[iId - (sint32) CLOCK_PERI_FIRST]);
        uiRegVa         = (*uiReg);
        sPclkCtrl.uiSel = (uiRegVa & ((uint32)CLOCK_PCLKCTRL_SEL_MASK \
                    << (uint32)CLOCK_PCLKCTRL_SEL_SHIFT)) >> (uint32)CLOCK_PCLKCTRL_SEL_SHIFT;

        uiPclkSel = (CLOCKPclkctrlSel_t)(sPclkCtrl.uiSel);

        switch(uiPclkSel)
        {
            case CLOCK_PCLKCTRL_SEL_PLL0:
            {
                uiSrcFreq = CLOCK_GetPllRate((sint32)CLOCK_MPLL_0);
                break;
            }
            case CLOCK_PCLKCTRL_SEL_PLL1:
            {
                uiSrcFreq = CLOCK_GetPllRate((sint32)CLOCK_MPLL_1);
                break;
            }
            case CLOCK_PCLKCTRL_SEL_PLL2:
            {
                uiSrcFreq = CLOCK_GetPllRate((sint32)CLOCK_MPLL_2);
                break;
            }
            case CLOCK_PCLKCTRL_SEL_PLL3:
            {
                uiSrcFreq = CLOCK_GetPllRate((sint32)CLOCK_MPLL_3);
                break;
            }
            case CLOCK_PCLKCTRL_SEL_XIN:
            {
                uiSrcFreq = CLOCK_GetPllRate((sint32)CLOCK_MPLL_XIN);
                break;
            }
            case CLOCK_PCLKCTRL_SEL_XTIN:
            {
                uiSrcFreq = CLOCK_GetPllRate((sint32)CLOCK_MPLL_XTIN);
                break;
            }
            case CLOCK_PCLKCTRL_SEL_PLL0DIV:
            {
                uiSrcFreq = CLOCK_GetPllRate((sint32)CLOCK_MPLL_DIV_0);
                break;
            }
            case CLOCK_PCLKCTRL_SEL_PLL1DIV:
            {
                uiSrcFreq = CLOCK_GetPllRate((sint32)CLOCK_MPLL_DIV_1);
                break;
            }
            case CLOCK_PCLKCTRL_SEL_PLL2DIV:
            {
                uiSrcFreq = CLOCK_GetPllRate((sint32)CLOCK_MPLL_DIV_2);
                break;
            }
            case CLOCK_PCLKCTRL_SEL_PLL3DIV:
            {
                uiSrcFreq = CLOCK_GetPllRate((sint32)CLOCK_MPLL_DIV_3);
                break;
            }
            case CLOCK_PCLKCTRL_SEL_XINDIV:
            {
                uiSrcFreq = CLOCK_GetPllRate((sint32)CLOCK_MPLL_XIN_DIV);
                break;
            }
            case CLOCK_PCLKCTRL_SEL_XTINDIV:
            {
                uiSrcFreq = CLOCK_GetPllRate((sint32)CLOCK_MPLL_XTIN_DIV);
                break;
            }
            default :
            {
                uiSrcFreq = 0UL;
                break;
            }
        }

        if(uiSrcFreq > 0UL)
        {
            sPclkCtrl.uiFreq    = 0;
            sPclkCtrl.uiDivVal  = (uiRegVa & ((uint32)CLOCK_PCLKCTRL_DIV_XXX_MASK <<    \
                                 (uint32)CLOCK_PCLKCTRL_DIV_SHIFT)) >>                  \
                                 (uint32)CLOCK_PCLKCTRL_DIV_SHIFT;
            sPclkCtrl.uiFreq    = uiSrcFreq / (sPclkCtrl.uiDivVal + 1UL);
            uiRet               = (uint32)sPclkCtrl.uiFreq;
        }
    }
    else
    {
        ; //
    }

    return uiRet;
}

sint32 CLOCK_SetPeriRate
(
    sint32                              iId,
    uint32                              uiRate
)
{
    SALAddr*        uiReg;
    sint32          iErr;
    //CLOCKPclkCtrl_t sPclkCtrl;
    uint32 uiIdx;
    uint32 uiDivVa;
    uint32 uiSelVa;
    uint32 uiRegVa;

    uiDivVa = 0UL;

    if ((iId < (sint32) CLOCK_PERI_MAX) && (iId >= (sint32) CLOCK_PERI_FIRST))
    {
        uiReg                   = (SALAddr *) (&puiClkPeriCtl->addr[iId - (sint32) CLOCK_PERI_FIRST]);
#if 0
        iErr                    = 0;
        sPclkCtrl.uiFreq        = uiRate;
        sPclkCtrl.uiPeriName    = (uint32) iId;
        sPclkCtrl.uiDivVal      = 0;
        sPclkCtrl.uiMd          = (uint32)CLOCK_PCLKCTRL_MODE_DIVIDER;
        sPclkCtrl.uiSel         = (uint32)CLOCK_MPCLKCTRL_SEL_XIN;

        if (CLOCK_DevFindPclk(&sPclkCtrl, CLOCK_PCLKCTRL_TYPE_XXX) != 0L)
        {
            //goto tcc_ckc_setperi_failed;
            CLOCK_DevWritePclkCtrl(                         \
                    uiReg,                                  \
                    (uint32)CLOCK_PCLKCTRL_MODE_DIVIDER,    \
                    (uint32)SALDisabled,                    \
                    (uint32)CLOCK_MPCLKCTRL_SEL_XIN,        \
                    1UL,                                    \
                    (uint32)CLOCK_PCLKCTRL_TYPE_XXX         \
                    );
            iErr = -1L;
        }
        else
        {
            CLOCK_DevWritePclkCtrl(                 \
                    uiReg,                          \
                    sPclkCtrl.uiMd,                 \
                    1UL,                            \
                    sPclkCtrl.uiSel,                \
                    sPclkCtrl.uiDivVal,             \
                    (uint32)CLOCK_PCLKCTRL_TYPE_XXX \
                    );
        }
#else
        iErr = -1;

        for(uiIdx = 0UL; uiIdx < (uint32)CLOCK_SRC_MAX_NUM ; uiIdx++)
        {
            if((stMicomClockSource[uiIdx] % uiRate) == 0UL)
            {
                uiDivVa = stMicomClockSource[uiIdx] / uiRate;

                if(uiDivVa <= CLOCK_PCLKCTRL_DIV_XXX_MASK)
                {
                    break;
                }
                else
                {
                    uiDivVa = 0UL;
                }
            }
        }

        if(uiDivVa > 0UL)
        {
            uiReg           = (SALAddr *) (&puiClkPeriCtl->addr[iId - (sint32) CLOCK_PERI_FIRST]);
            uiRegVa         = (*uiReg);

            switch(uiIdx)
            {
                case CLOCK_MPLL_0:
                    {
                        uiSelVa = CLOCK_PCLKCTRL_SEL_PLL0;
                        break;
                    }
                case CLOCK_MPLL_1:
                    {
                        uiSelVa = CLOCK_PCLKCTRL_SEL_PLL1;
                        break;
                    }
                case CLOCK_MPLL_2:
                    {
                        uiSelVa = CLOCK_PCLKCTRL_SEL_PLL2;
                        break;
                    }
                case CLOCK_MPLL_3:
                    {
                        uiSelVa = CLOCK_PCLKCTRL_SEL_PLL3;
                        break;
                    }
                case CLOCK_MPLL_DIV_0:
                    {
                        uiSelVa = CLOCK_PCLKCTRL_SEL_PLL0DIV;
                        break;
                    }
                case CLOCK_MPLL_DIV_1:
                    {
                        uiSelVa = CLOCK_PCLKCTRL_SEL_PLL1DIV;
                        break;
                    }
                case CLOCK_MPLL_DIV_2:
                    {
                        uiSelVa = CLOCK_PCLKCTRL_SEL_PLL2DIV;
                        break;
                    }
                case CLOCK_MPLL_DIV_3:
                    {
                        uiSelVa = CLOCK_PCLKCTRL_SEL_PLL3DIV;
                        break;
                    }
                case CLOCK_MPLL_XIN:
                    {
                        uiSelVa = CLOCK_PCLKCTRL_SEL_XIN;
                        break;
                    }
                case CLOCK_MPLL_XIN_DIV:
                    {
                        uiSelVa = CLOCK_PCLKCTRL_SEL_XINDIV;
                        break;
                    }
                case CLOCK_MPLL_XTIN:
                    {
                        uiSelVa = CLOCK_PCLKCTRL_SEL_XTIN;
                        break;
                    }
                case CLOCK_MPLL_XTIN_DIV:
                    {
                        uiSelVa = CLOCK_PCLKCTRL_SEL_XTINDIV;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

            uiRegVa &= ~((uint32)CLOCK_PCLKCTRL_SEL_MASK << (uint32)CLOCK_PCLKCTRL_SEL_SHIFT);
            uiRegVa &= ~((uint32)CLOCK_PCLKCTRL_DIV_XXX_MASK << (uint32)CLOCK_PCLKCTRL_DIV_SHIFT);
            uiRegVa |= (uiSelVa << (uint32)CLOCK_PCLKCTRL_SEL_SHIFT);
            uiRegVa |= ((uiDivVa-1UL) << (uint32)CLOCK_PCLKCTRL_DIV_SHIFT);

            (*uiReg) = uiRegVa;
            iErr = 0L;
        }
#endif
    }
    else
    {
        iErr = -1L;
    }

    return iErr;
}

sint32 CLOCK_IsIobusPwdn
(
    sint32                              iId
)
{
    sint32 ret;
    SALAddr * uiReg;
    uint32 uiShift;


    if(iId <= CLOCK_IOBUS_LAST_0)
    {
        ret = 0L;
        uiReg = (SALAddr *) (CLOCK_CLKHCLK_0_ADDR);
        uiShift = (uint32)iId;
    }
    else if(iId <= CLOCK_IOBUS_LAST_1)
    {
        ret = 0L;
        uiReg = (SALAddr *) (CLOCK_CLKHCLK_1_ADDR);
        uiShift = (uint32)(iId - CLOCK_IOBUS_FIRST_1);
    }
    else
    {
        ret = -1L;
    }

    if(ret == 0L)
    {
        if((((*uiReg) >> uiShift) & 0x1UL) == 1UL)
        {
            ret = 0L;
        }
        else
        {
            ret = 1L;
        }
    }

    return ret;
}

sint32 CLOCK_EnableIobus
(
    sint32                              iId,
    boolean                             bEn
)
{
    sint32 iRet;

    if(bEn == SALEnabled)
    {
        if(CLOCK_SetIobusPwdn(iId, SALDisabled) == 0L)
        {
            iRet = CLOCK_SetSwReset(iId, SALDisabled);
        }
        else
        {
            iRet = -1;
        }
    }
    else
    {
        if(CLOCK_SetSwReset(iId, SALEnabled) == 0L)
        {
            iRet = CLOCK_SetIobusPwdn(iId, SALEnabled);
        }
        else
        {
            iRet = -1;
        }
    }

    return iRet;
}

sint32 CLOCK_SetIobusPwdn
(
    sint32                              iId,
    boolean                             bEn
)
{
    sint32          ret;
    SALAddr*        uiReg;
    sint32          iRest;
    CLOCKIobus_t    tIobus;

    ret     = 0L;
    tIobus  = (CLOCKIobus_t)iId;

    if (tIobus <= CLOCK_IOBUS_LAST_0)
    {
        uiReg = (SALAddr *) CLOCK_CLKHCLK_0_ADDR;
        iRest = (sint32)tIobus;
    }
    else if (tIobus <= CLOCK_IOBUS_LAST_1)
    {
        uiReg = (SALAddr *) CLOCK_CLKHCLK_1_ADDR;
        iRest = (sint32)tIobus - (sint32)CLOCK_IOBUS_FIRST_1;
    }
    else
    {
        uiReg = NULL;
    }

    if (uiReg != NULL)
    {
        if (bEn == SALEnabled)
        {
            *uiReg &= (~((uint32)1UL << (uint32)iRest));
        }
        else
        {
            *uiReg |= ((uint32)1UL << (uint32)iRest);
        }
    }
    else
    {
        ret = -1L;
    }

    return ret;
}

sint32 CLOCK_SetSwReset
(
    sint32                              iId,
    boolean                             bReset
)
{
    sint32          ret;
    uint32*         uiReg;
    sint32          iRest;
    CLOCKIobus_t    tIobus;

    ret = 0L;
    tIobus  = (CLOCKIobus_t)iId;

    if (tIobus <= CLOCK_IOBUS_LAST_0)
    {
        uiReg = (SALAddr *) CLOCK_CLKHCLKSW_0_ADDR;
        iRest = (sint32)tIobus;
    }
    else if (tIobus <= CLOCK_IOBUS_LAST_1)
    {
        uiReg = (SALAddr *) CLOCK_CLKHCLKSW_1_ADDR;
        iRest = (sint32)tIobus - (sint32)CLOCK_IOBUS_FIRST_1;
    }
    else
    {
        uiReg = NULL;
    }

    if (uiReg != NULL)
    {
        if (bReset == SALEnabled)
        {
            *uiReg &= (~((uint32)1UL << (uint32)iRest));
        }
        else
        {
            *uiReg |= ((uint32)1UL << (uint32)iRest);
        }
    }
    else
    {
        ret = -1L;
    }

    return ret;
}

