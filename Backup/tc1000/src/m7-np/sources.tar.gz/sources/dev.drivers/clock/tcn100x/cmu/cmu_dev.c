/*
***************************************************************************************************
*
*   FileName : cmu_dev.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/
#include <string.h>
#include <debug.h>
#include <reg_phys.h>
#include <clock_mon.h>
#include "cmu_dev.h"
#include "cmu_reg.h"

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/
#if defined(DEBUG_ENABLE)
    #define CMU_D(args...)                  { \
                                                mcu_printf("[CMU][%s:%d] ",__func__, __LINE__); \
                                                mcu_printf(args); \
                                            }
#else
    #define CMU_D(args...)
#endif

#define CMU_E(args...)                      { \
                                                mcu_printf("[CMU][%s:%d] Error ! ", __func__, __LINE__); \
                                                mcu_printf(args); \
                                            }


#define CMU_OVER_RANGE(v,r)                      ((uint32)v & (~((uint32)r)))

#define CMU_CLK_TYPE_PERI0                  (CMU_CLK_TYPE_SFMC)
/***************************************************************************************************
*                                             LOCAL VARIABLES
***************************************************************************************************/
/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/
static void CMU_CheckSfChkGrpSts
(
    void
);

static void CMU_GetOffset
(
    CmuClkTypes_t tClkType,
    uint32* puiCtrlOffset,
    uint32* puiLimitOffset,
    uint32* puiFaultReqBit
);



/*
***************************************************************************************************
*                                         IMPLEMENTATION
***************************************************************************************************
*/

static void CMU_CheckSfChkGrpSts
(
    void
)
{
    uint32 uiSts0;
    uint32 uiSts1;

    uiSts0 = CMU_GET(SF_CHK_GRP_STS0);
    uiSts1 = CMU_GET(SF_CHK_GRP_STS1);

    if( (uiSts0 > 0UL) || (uiSts1 > 0UL))
    {
        CMU_E("Soft Fault Check Group status x%08x, x%08x\n", uiSts0, uiSts1);
    }
}

static void CMU_GetOffset
(
    CmuClkTypes_t tClkType,
    uint32* puiCtrlOffset,
    uint32* puiLimitOffset,
    uint32* puiFaultReqBit
)
{
    switch(tClkType)
    {
        case CMU_CLK_TYPE_PLL0   :
            {
                if(puiCtrlOffset != NULL_PTR)
                {
                    puiCtrlOffset[0]  = PLL0_FOUT_CTRL;
                }

                if(puiLimitOffset != NULL_PTR)
                {
                    puiLimitOffset[0] = PLL0_FOUT_LIMIT;
                }

                if(puiFaultReqBit != NULL_PTR)
                {
                    puiFaultReqBit[0] = 24UL;
                }
                break;
            }
        case CMU_CLK_TYPE_PLL1   :
            {
                if(puiCtrlOffset != NULL_PTR)
                {
                    puiCtrlOffset[0]  = PLL1_FOUT_CTRL;
                }

                if(puiLimitOffset != NULL_PTR)
                {
                    puiLimitOffset[0] = PLL1_FOUT_LIMIT;
                }

                if(puiFaultReqBit != NULL_PTR)
                {
                    puiFaultReqBit[0] = 25UL;
                }
                break;
            }
        case CMU_CLK_TYPE_CPU    :
            {
                if(puiCtrlOffset != NULL_PTR)
                {
                    puiCtrlOffset[0]  = CPU_CLK_CTRL;
                }

                if(puiLimitOffset != NULL_PTR)
                {
                    puiLimitOffset[0] = CPU_CLK_LIMIT;
                }

                if(puiFaultReqBit != NULL_PTR)
                {
                    puiFaultReqBit[0] = 26UL;
                }
                break;
            }
        case CMU_CLK_TYPE_BUS    :
            {
                if(puiCtrlOffset != NULL_PTR)
                {
                    puiCtrlOffset[0]  = BUS_CLK_CTRL;
                }

                if(puiLimitOffset != NULL_PTR)
                {
                    puiLimitOffset[0] = BUS_CLK_LIMIT;
                }

                if(puiFaultReqBit != NULL_PTR)
                {
                    puiFaultReqBit[0] = 27UL;
                }
                break;
            }
        default                  :
            {
                if(puiCtrlOffset != NULL_PTR)
                {
                    puiCtrlOffset[0]  = PERI_CLK0_CTRL + \
                                        (((uint32)tClkType - (uint32)CMU_CLK_TYPE_PERI0) * 0x8UL);
                }

                if(puiLimitOffset != NULL_PTR)
                {
                    puiLimitOffset[0] = PERI_CLK0_LIMIT + \
                                        (((uint32)tClkType - (uint32)CMU_CLK_TYPE_PERI0) * 0x8UL);
                }

                if(puiFaultReqBit != NULL_PTR)
                {
                    puiFaultReqBit[0] = 28UL;
                }
                break;
            }
    }
}

void CMU_Init
(
    void
)
{
    static sint8 iInitialized = 0;

    if (iInitialized == 0)
    {
        iInitialized = 1;

        CMU_SET(SF_CHK_GRP_EN0, 0, 0xFFFFFFFFUL, 0xFFFFFFFFUL);
        CMU_CheckSfChkGrpSts();

        CMU_SET(SF_CHK_GRP_EN1, 0, 0x1, 0x1UL);
        CMU_CheckSfChkGrpSts();

        CMU_SET(SF_CTRL_CFG, 0, 0x1, 0x1UL);
        CMU_CheckSfChkGrpSts();
    }

}

void CMU_SetMonCtrl
(
    CmuClkTypes_t tClkType,
    uint32 uiDiv,
    uint32 uiCaptureTime,
    uint32 uiMinLimit,
    uint32 uiMaxLimit
)
{
    uint32 uiCtrlOffset;
    uint32 uiLimitOffset;

    if((uint32)tClkType >= (uint32)CMU_CLK_TYPE_MAX_NUM)
    {
        CMU_E("Wrong Parameter 1\n");
    }
    else if( CMU_OVER_RANGE(uiDiv, CMU_PLL_DIV_MASK) )
    {
        CMU_E("Wrong Parameter 2\n");
    }
    else if( CMU_OVER_RANGE(uiCaptureTime, CMU_CAPTURE_TIME_MASK) )
    {
        CMU_E("Wrong Parameter 3\n");
    }
    else if( CMU_OVER_RANGE(uiMinLimit, CMU_MIN_LIMIT_MASK) )
    {
        CMU_E("Wrong Parameter 4\n");
    }
    else if( CMU_OVER_RANGE(uiMaxLimit, CMU_MAX_LIMIT_MASK) )
    {
        CMU_E("Wrong Parameter 5\n");
    }
    else
    {
        CMU_GetOffset(tClkType, &uiCtrlOffset, &uiLimitOffset, NULL_PTR);

        if((tClkType == CMU_CLK_TYPE_CPU) || (tClkType == CMU_CLK_TYPE_BUS))
        {
            if(uiDiv > 0UL)
            {
                uiDiv = 0UL;
                CMU_D("No DIV value required.\n");
            }
        }
        else
        {
            CMU_SET(uiCtrlOffset,   16, CMU_PLL_DIV_MASK,       uiDiv           );
            CMU_CheckSfChkGrpSts();
        }

        CMU_SET(uiCtrlOffset,   24, CMU_CAPTURE_TIME_MASK,  uiCaptureTime   );
        CMU_CheckSfChkGrpSts();

        CMU_SET(uiLimitOffset,  0,  CMU_MIN_LIMIT_MASK,     uiMinLimit      );
        CMU_CheckSfChkGrpSts();

        CMU_SET(uiLimitOffset,  16, CMU_MAX_LIMIT_MASK,     uiMaxLimit      );
        CMU_CheckSfChkGrpSts();
    }
}

void CMU_SetMonEn
(
    CmuClkTypes_t tClkType,
    uint32 uiEn
)
{
    uint32 uiCtrlOffset;
    uint32 uiFaultReqBit;

    if((uint32)tClkType >= (uint32)CMU_CLK_TYPE_MAX_NUM)
    {
        CMU_E("Wrong Parameter 1\n");
    }
    else if( uiEn > 1UL)
    {
        CMU_E("Wrong Parameter 2\n");
    }
    else
    {
        CMU_GetOffset(tClkType, &uiCtrlOffset, NULL_PTR, &uiFaultReqBit);

        CMU_SET(CLK_FAULT_CTRL, uiFaultReqBit, 1, uiEn);
        CMU_CheckSfChkGrpSts();

        CMU_SET(uiCtrlOffset, 31, 1, uiEn);
        CMU_CheckSfChkGrpSts();
    }
}

uint32 CMU_GetErrSts
(
    CmuClkTypes_t* tClkFaultTypes,
    CmuClkTypes_t* tTimeoutTypes,
    CmuClkTypes_t* tClkStopTypes
)
{
    uint32 uiClkFaultSts;
    uint32 uiTimeoutSts;
    uint32 uiClkStopSts;
    uint32 uiIdx;
    uint32 uiClkFaultIdx;
    uint32 uiTimeoutIdx;
    uint32 uiClkStopIdx;
    uint32 uiErrNum;

    uiClkFaultSts = CMU_GET(CLK_FAULT_STS);

    uiTimeoutSts  =  CMU_GET(TIMEOUT_STS0) & 0xFUL;
    uiTimeoutSts |= (CMU_GET(TIMEOUT_STS1) << ((uint32)CMU_CLK_TYPE_PERI0 - 1UL) );

    uiClkStopSts  =  CMU_GET(CLKSTOP_STS0) & 0xFUL;
    uiClkStopSts |= (CMU_GET(CLKSTOP_STS1) << ((uint32)CMU_CLK_TYPE_PERI0 - 1UL) );

    uiClkFaultIdx = 0UL;
    uiTimeoutIdx = 0UL;
    uiClkStopIdx = 0UL;
    uiErrNum = 0UL;

    for(uiIdx = 0UL ; uiIdx < (uint32)CMU_CLK_TYPE_MAX_NUM ; uiIdx++)
    {
        if(tClkFaultTypes != NULL_PTR)
        {
            tClkFaultTypes[uiIdx] = CMU_CLK_TYPE_NONE;

            if( (uiClkFaultSts & (1UL << uiIdx)) > 0UL )
            {
                tClkFaultTypes[uiClkFaultIdx] = (CmuClkTypes_t)((uint32)CMU_CLK_TYPE_PERI0 + uiIdx);
                uiClkFaultIdx++;
                uiErrNum++;
            }
        }

        if(tTimeoutTypes != NULL_PTR)
        {
            tTimeoutTypes[uiIdx] = CMU_CLK_TYPE_NONE;

            if( (uiTimeoutSts & (1UL << uiIdx)) > 0UL )
            {
                tTimeoutTypes[uiTimeoutIdx] = (CmuClkTypes_t)((uint32)CMU_CLK_TYPE_PLL0 + uiIdx);
                uiTimeoutIdx++;
                uiErrNum++;
            }
        }

        if(tClkStopTypes != NULL_PTR)
        {
            tClkStopTypes[uiIdx] = CMU_CLK_TYPE_NONE;

            if( (uiClkStopSts & (1UL << uiIdx)) > 0UL )
            {
                tClkStopTypes[uiClkStopIdx] = (CmuClkTypes_t)((uint32)CMU_CLK_TYPE_PLL0 + uiIdx);
                uiClkStopIdx++;
                uiErrNum++;
            }
        }
    }

    return uiErrNum;
}
