/*
***************************************************************************************************
*
*   FileName : cmu.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SIC_BSP_CMU_HEADER
#define SIC_BSP_CMU_HEADER

#include <sal_internal.h>

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/
typedef enum{
    CMU_CLK_TYPE_NONE                   = 0UL,

    CMU_CLK_TYPE_PLL0                   = 1UL,
    CMU_CLK_TYPE_PLL1                   = 2UL,
    CMU_CLK_TYPE_CPU                    = 3UL,
    CMU_CLK_TYPE_BUS                    = 4UL,
    CMU_CLK_TYPE_SFMC                   = 5UL,  //PERI0
    CMU_CLK_TYPE_GPSB0                  = 6UL,  //PERI1
    CMU_CLK_TYPE_GPSB1                  = 7UL,  //PERI2
    CMU_CLK_TYPE_GPSB2                  = 8UL,  //PERI3
    CMU_CLK_TYPE_UART0                  = 9UL,  //PERI4
    CMU_CLK_TYPE_TIMER0                 = 10UL, //PERI5
    CMU_CLK_TYPE_TIMER1                 = 11UL, //PERI6
    CMU_CLK_TYPE_TIMER2                 = 12UL, //PERI7
    CMU_CLK_TYPE_TIMER3                 = 13UL, //PERI8
    CMU_CLK_TYPE_TIMER4                 = 14UL, //PERI9
    CMU_CLK_TYPE_TIMER5                 = 15UL, //PERI10

    CMU_CLK_TYPE_MAX_NUM                = 16UL
}CmuClkTypes_t;

/*
***************************************************************************************************
*                                         FUNCTION PROTOTYPES
***************************************************************************************************
*/

void CMU_Init
(
    void
);

void CMU_SetMonCtrl
(
    CmuClkTypes_t tClkType,
    uint32 uiDiv,
    uint32 uiCaptureTime,
    uint32 uiMinLimit,
    uint32 uiMaxLimit
);

void CMU_SetMonEn
(
    CmuClkTypes_t tClkType,
    uint32 uiEn
);

uint32 CMU_GetErrSts
(
    CmuClkTypes_t* tClkFaultTypes,
    CmuClkTypes_t* tTimeoutTypes,
    CmuClkTypes_t* tClkStopTypes
);
#endif /* SIC_BSP_CMU_HEADER*/

