/*
***************************************************************************************************
*
*   FileName : i2c_reg.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include <i2c_reg.h>

/*                                                                                                 */
/***************************************************************************************************/
/*                                             LOCAL VARIABLES                                     */
/***************************************************************************************************/

I2CDev_t i2c[I2C_CH_NUM] =
{
    {
        400,                            /* I2C Clock                */
        I2C_CH0_BASE,                   /* Channel Base Address     */
        I2C_PORT_CFG_0,                 /* I2C Configuration        */
        (uint32)CLOCK_PERI_I2C0,        /* Peri clock index         */
        (sint32)CLOCK_IOBUS_I2C0,       /* I/O Bus index            */
        NULL,                           /* SDA                      */
        NULL,                           /* SCL                      */
        NULL,                           /* Port number              */
        {0, },
        {0, },
        I2C_STATE_DISABLED              /* I2C State                */
    },
    {
        400,
        I2C_CH1_BASE,
        I2C_PORT_CFG_1,
        (uint32)CLOCK_PERI_I2C1,
        (sint32)CLOCK_IOBUS_I2C1,
        NULL,
        NULL,
        NULL,
        {0, },
        {0, },
        I2C_STATE_DISABLED
    },
    {
        400,
        I2C_CH2_BASE,
        I2C_PORT_CFG_2,
        (uint32)CLOCK_PERI_I2C2,
        (sint32)CLOCK_IOBUS_I2C2,
        NULL,
        NULL,
        NULL,
        {0, },
        {0, },
        I2C_STATE_DISABLED
    },
    {
        400,
        I2C_CH3_BASE,
        I2C_PORT_CFG_3,
        (uint32)CLOCK_PERI_I2C3,
        (sint32)CLOCK_IOBUS_I2C3,
        NULL,
        NULL,
        NULL,
        {0, },
        {0, },
        I2C_STATE_DISABLED
    },
    {
        400,
        I2C_CH4_BASE,
        I2C_PORT_CFG_4,
        (uint32)CLOCK_PERI_I2C4,
        (sint32)CLOCK_IOBUS_I2C4,
        NULL,
        NULL,
        NULL,
        {0, },
        {0, },
        I2C_STATE_DISABLED
    },
};

const I2CPortConfig_t i2cPortCfg[I2C_PORT_NUM] =
{
//  Port Idx,   SCL,                SDA,                Function
    { 0UL,      GPIO_GPA(15UL),     GPIO_GPA(16UL),     GPIO_FUNC(4UL)},
    { 1UL,      GPIO_GPA(19UL),     GPIO_GPA(20UL),     GPIO_FUNC(4UL)},

    { 2UL,      GPIO_GPB(15UL),     GPIO_GPB(16UL),     GPIO_FUNC(4UL)},
    { 3UL,      GPIO_GPB(19UL),     GPIO_GPA(20UL),     GPIO_FUNC(4UL)},

    { 4UL,      GPIO_GPC(15UL),     GPIO_GPC(16UL),     GPIO_FUNC(4UL)},
    { 5UL,      GPIO_GPC(19UL),     GPIO_GPA(20UL),     GPIO_FUNC(4UL)},

    { 6UL,      GPIO_GPD(15UL),     GPIO_GPD(16UL),     GPIO_FUNC(4UL)},
    { 7UL,      GPIO_GPD(19UL),     GPIO_GPD(20UL),     GPIO_FUNC(4UL)},

    { 8UL,      GPIO_GPE(0UL),      GPIO_GPE(1UL),      GPIO_FUNC(4UL)},
    { 9UL,      GPIO_GPE(4UL),      GPIO_GPE(5UL),      GPIO_FUNC(4UL)},
    { 10UL,     GPIO_GPE(6UL),      GPIO_GPE(7UL),      GPIO_FUNC(4UL)},
    { 11UL,     GPIO_GPE(10UL),     GPIO_GPE(11UL),     GPIO_FUNC(4UL)},
    { 12UL,     GPIO_GPE(14UL),     GPIO_GPE(15UL),     GPIO_FUNC(4UL)},

    { 13UL,     GPIO_GPF(0UL),      GPIO_GPF(1UL),      GPIO_FUNC(4UL)},
    { 14UL,     GPIO_GPF(4UL),      GPIO_GPF(5UL),      GPIO_FUNC(4UL)},
    { 15UL,     GPIO_GPF(6UL),      GPIO_GPF(7UL),      GPIO_FUNC(4UL)},
    { 16UL,     GPIO_GPF(10UL),     GPIO_GPF(11UL),     GPIO_FUNC(4UL)},
    { 17UL,     GPIO_GPF(14UL),     GPIO_GPF(15UL),     GPIO_FUNC(4UL)},

    { 18UL,     GPIO_GPG(0UL),      GPIO_GPG(1UL),      GPIO_FUNC(4UL)},
    { 19UL,     GPIO_GPG(4UL),      GPIO_GPG(5UL),      GPIO_FUNC(4UL)},
    { 20UL,     GPIO_GPG(6UL),      GPIO_GPG(7UL),      GPIO_FUNC(4UL)},
    { 21UL,     GPIO_GPG(10UL),     GPIO_GPG(11UL),     GPIO_FUNC(4UL)},
    { 22UL,     GPIO_GPG(14UL),     GPIO_GPG(15UL),     GPIO_FUNC(4UL)},

    { 23UL,     GPIO_GPH(0UL),      GPIO_GPH(1UL),      GPIO_FUNC(4UL)},
    { 24UL,     GPIO_GPH(4UL),      GPIO_GPH(5UL),      GPIO_FUNC(4UL)},
    { 25UL,     GPIO_GPH(6UL),      GPIO_GPH(7UL),      GPIO_FUNC(4UL)},
    { 26UL,     GPIO_GPH(10UL),     GPIO_GPH(11UL),     GPIO_FUNC(4UL)},
    { 27UL,     GPIO_GPH(14UL),     GPIO_GPH(15UL),     GPIO_FUNC(4UL)},

    { 28UL,     GPIO_GPI(0UL),      GPIO_GPI(1UL),      GPIO_FUNC(4UL)},
    { 29UL,     GPIO_GPI(4UL),      GPIO_GPI(5UL),      GPIO_FUNC(4UL)},
    { 30UL,     GPIO_GPI(6UL),      GPIO_GPI(7UL),      GPIO_FUNC(4UL)},
    { 31UL,     GPIO_GPI(10UL),     GPIO_GPI(11UL),     GPIO_FUNC(4UL)},
    { 32UL,     GPIO_GPI(14UL),     GPIO_GPI(15UL),     GPIO_FUNC(4UL)},

    { 33UL,     GPIO_GPJ(0UL),      GPIO_GPJ(1UL),      GPIO_FUNC(4UL)},
    { 34UL,     GPIO_GPJ(4UL),      GPIO_GPJ(5UL),      GPIO_FUNC(4UL)},
    { 35UL,     GPIO_GPJ(6UL),      GPIO_GPJ(7UL),      GPIO_FUNC(4UL)},
    { 36UL,     GPIO_GPJ(10UL),     GPIO_GPJ(11UL),     GPIO_FUNC(4UL)},
    { 37UL,     GPIO_GPJ(12UL),     GPIO_GPJ(13UL),     GPIO_FUNC(4UL)},

    { 38UL,     GPIO_GPL(0UL),      GPIO_GPL(1UL),      GPIO_FUNC(4UL)},
    { 39UL,     GPIO_GPL(4UL),      GPIO_GPL(5UL),      GPIO_FUNC(4UL)},
    { 40UL,     GPIO_GPL(6UL),      GPIO_GPL(7UL),      GPIO_FUNC(4UL)},
    { 41UL,     GPIO_GPL(10UL),     GPIO_GPL(11UL),     GPIO_FUNC(4UL)},
    { 42UL,     GPIO_GPL(12UL),     GPIO_GPL(13UL),     GPIO_FUNC(4UL)},
    { 43UL,     GPIO_GPL(16UL),     GPIO_GPL(17UL),     GPIO_FUNC(4UL)},
};

