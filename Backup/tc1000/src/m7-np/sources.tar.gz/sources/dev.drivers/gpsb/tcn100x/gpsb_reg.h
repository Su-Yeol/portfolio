/*
***************************************************************************************************
*
*   FileName : gpsb_reg.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

/*
***************************************************************************************************
*                                             INCLUDE FILES
***************************************************************************************************
*/

#include <gpsb.h>
#include <clock_dev.h>

/*
***************************************************************************************************
*                                             DEFINITIONS
***************************************************************************************************
*/

#define GPSB_SCLK                       (uint32)(0UL)
#define GPSB_CS                         (uint32)(1UL)
#define GPSB_SDO                        (uint32)(2UL)
#define GPSB_SDI                        (uint32)(3UL)
#define GPSB_FUNC                       (uint32)(4UL)

#define DEDICATED_DMA_NUM               (uint32)(6UL)

#define GPSB_CH_0                       (0UL)
#define GPSB_CH_1                       (1UL)
#define GPSB_CH_2                       (2UL)
#define GPSB_CH_3                       (3UL)
#define GPSB_CH_4                       (4UL)
#define GPSB_CH_5                       (5UL)

/* GPSB register address */
#define GPSB0_BASE                      ((uint32)SIC_BSP_GPSB_BASE + (uint32)0x00000UL)
#define GPSB1_BASE                      ((uint32)SIC_BSP_GPSB_BASE + (uint32)0x10000UL)
#define GPSB2_BASE                      ((uint32)SIC_BSP_GPSB_BASE + (uint32)0x20000UL)
#define GPSB3_BASE                      ((uint32)SIC_BSP_GPSB_BASE + (uint32)0x30000UL)
#define GPSB4_BASE                      ((uint32)SIC_BSP_GPSB_BASE + (uint32)0x40000UL)
#define GPSB5_BASE                      ((uint32)SIC_BSP_GPSB_BASE + (uint32)0x50000UL)

//#define GPSB_PCFG_BASE                  ((uint32)SIC_BSP_GPSB_BASE + (uint32)0x60000UL)
#define GPSB_IO_MONITOR_BASE            ((uint32)SIC_BSP_GPSB_BASE + (uint32)0xE0000UL)	/* GPSB_MON */
#define GPSB_WRAP_BASE                  ((uint32)SIC_BSP_GPSB_BASE + (uint32)0xF0000UL)	/* GPSB_WRAP_SCR */

//#define GPSB_PORT_CFG(x)                (GPSB_PCFG_BASE + (0x4UL * (x)))
#define GPSB_CH_BASE(x)                 (SIC_BSP_GPSB_BASE + ((x) * 0x10000UL))

/*
The purpose of GPSB_TXBASE_H, GPSB_RXBASE_H is setting the full address.
As AXON uses 36 bits memory address, GPSB also needs 4-bit extended address.
Fortunately, GPSB's base address is located lower than maximum of 32bits.
Which means  4-bit extended address doesn't necessary to access GPSB's RX_BASE and TX_BASE
*/
/* GPSB Control register */
#define GPSB_PORT                       (uint32)(0x00UL) /* Data port */
#define GPSB_STAT                       (uint32)(0x04UL) /* Status register */
#define GPSB_INTEN                      (uint32)(0x08UL) /* Interrupt enable */
#define GPSB_MODE                       (uint32)(0x0CUL) /* Mode register */
#define GPSB_CTRL                       (uint32)(0x10UL) /* Control register */
#define GPSB_EVTCTRL                    (uint32)(0x14UL) /* Counter and Ext. Event Control */
#define GPSB_CCV                        (uint32)(0x18UL) /* Counter current value */
#define GPSB_TXBASE                     (uint32)(0x20UL) /* TX base address register */
#define GPSB_TXBASE_H                   (uint32)(0x24UL) /* TX base address register (H) */
#define GPSB_RXBASE                     (uint32)(0x28UL) /* RX base address register */
#define GPSB_RXBASE_H                   (uint32)(0x2CUL) /* RX base address register (H) */
#define GPSB_PACKET                     (uint32)(0x30UL) /* Packet register */
#define GPSB_DMACTR                     (uint32)(0x34UL) /* DMA control register */
#define GPSB_DMASTR                     (uint32)(0x38UL) /* DMA status register */
#define GPSB_DMAICR                     (uint32)(0x3CUL) /* DMA interrupt control register */

/* GPSB Port Configuration */
//#define GPSB_PORT_SEL0                  (uint32)(0x00UL) /* GPSB 0/1/2 */
//#define GPSB_PORT_SEL1		            (uint32)(0x04UL)
//#define GPSB_SDM_RVC_CTRL_SEL           (uint32)(0x08UL)
#define GPSB_LB_CFG                     (uint32)(0x00UL)
#define GPSB_PCFG_WR_PW                 (uint32)(0x04UL)
#define GPSB_PCFG_WR_LOCK               (uint32)(0x08UL)
#define GPSB_PCFG_WR_EN_BIT             (BSP_BIT_00)

/* GPSB IO Monitor */
#define GPSB0_IOMON                     (uint32)(0x00UL)
#define GPSB1_IOMON                     (uint32)(0x04UL)
#define GPSB2_IOMON                     (uint32)(0x08UL)
#define GPSB3_IOMON                     (uint32)(0x0CUL)
#define GPSB4_IOMON                     (uint32)(0x10UL)
#define GPSB5_IOMON                     (uint32)(0x14UL)
#define GPSB_IOMON_CLR                  (uint32)(0x18UL)

/* IO monitor errors */
#define GPSB_SM_ERR_NONE                (uint32)(0x0UL)
#define GPSB_SM_ERR_STUCK               (uint32)(0x1UL)
#define GPSB_SM_ERR_PROTOCOL            (uint32)(0x2UL)
#define GPSB_SM_ERR_ALL                 (uint32)(0x3UL)

#define GPSB_PORT_PSWD                  (uint32)(0x5AFEACE5UL)

#define GPSB_CH_NUM                     (uint32)(6UL)
#define GPSB_PORT_NUM                   (uint32)(19UL)

/* Write Lock */
#define GPSB_BIT_WR_LOCK                (uint32)(0x1UL)

/* GPSB Tx/Rx FIFO Threshold for irq/dma req. */
#define GPSB_CFGWTH                     (uint32)(1UL)
#define GPSB_CFGRTH                     (uint32)(0UL)

/* Default clock divider load value */
#define GPSB_DEF_DIVLDV                 (uint32)(0UL)

extern GPSBDev_t                gpsb[GPSB_CH_NUM];
extern const GPSBSafetyBase_t   gpsb_sm[GPSB_CH_NUM];
extern const uint32             gpsbport[GPSB_PORT_NUM][5];

static void GPSB_Isr0
(
    void
);

static void GPSB_Isr1
(
    void
);

static void GPSB_Isr2
(
    void
);

static void GPSB_Isr3
(
    void
);

static void GPSB_Isr4
(
    void
);

static void GPSB_Isr5
(
    void
);


static void GPSB_DmaIsr0
(
    void
);

static void GPSB_DmaIsr1
(
    void
);

static void GPSB_DmaIsr2
(
    void
);

static void GPSB_DmaIsr3
(
    void
);

static void GPSB_DmaIsr4
(
    void
);

static void GPSB_DmaIsr5
(
    void
);

/*
***************************************************************************************************
*                                          GPSB_TargetInit
*
* Registers the GPSB interrupt handler functions and enables the GPSB interrupts.
*
* @return
* Notes
*
***************************************************************************************************
*/

void GPSB_TargetInit
(
    void
);

/*
***************************************************************************************************
*                                          GPSB_TargetDeinit
*
* Resets the GPSB channel in IOBUS.
*
* @return
* Notes
*
***************************************************************************************************
*/

void GPSB_TargetDeinit
(
    void
);

void GPSB_SetPortCFG
(
    uint32  uiCh,
    uint32  uiPort

);

void GPSB_ClearPortCFG
(
    uint32  uiCh
);

/*
***************************************************************************************************
*                                          GPSB_SafetyEnableLock
*
* Function to enable write lock.
*
* @return
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_SafetyEnableLock
(
    void
);

/*
***************************************************************************************************
*                                          GPSB_SafetyDisableLock
*
* Function to disable write lock.
*
* @return
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_SafetyDisableLock
(
    void
);

/*
***************************************************************************************************
*                                          GPSB_SafetyEnableLoopback
*
* Function to enable loopback between master & slave channel.
*
* @param    uiMstCh [in] : Master channel index
* @param    uiSlvCh [in] : Slave channel index
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_SafetyEnableLoopback
(
    uint32                              uiMstCh,
    uint32                              uiSlvCh
);

/*
***************************************************************************************************
*                                          GPSB_SafetyDisableLoopback
*
* Function to disable loopback between master & slave channel.
*
* @param    uiMstCh [in] : Master channel index
* @param    uiSlvCh [in] : Slave channel index
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_SafetyDisableLoopback
(
    uint32                              uiMstCh,
    uint32                              uiSlvCh
);

/*
***************************************************************************************************
*                                          GPSB_SafetyEnableMonitor
*
* Function to enable safety monitor.
*
* @param    uiCh [in]       : Value of channel to control
* @param    uiMonMode[in]   : Select Protocol/Data stuck monitor
* @param    uiMonWidth      : Value of width of monitor
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_SafetyEnableMonitor
(
    uint32                              uiCh,
    uint32                              uiMonMode,
    uint32                              uiMonWidth
);

/*
***************************************************************************************************
*                                          GPSB_SafetyDisableMonitor
*
* Function to disable safety monitor.
*
* @param    uiCh [in]       : Value of channel to control
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_SafetyDisableMonitor
(
    uint32                              uiCh
);

/*
***************************************************************************************************
*                                          GPSB_SafetyGetStatus
* Function to get safety monitor status.
*
* @param    uiCh [in]       : Value of channel to control
* @return   GPSB_SM_ERR_NONE or GPSB_SM_ERR
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_SafetyGetStatus
(
    uint32                              uiCh
);

