/*
***************************************************************************************************
*
*   FileName : gpsb_reg.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include <gpsb_reg.h>

/*                                                                                                 */
/***************************************************************************************************/
/*                                             LOCAL VARIABLES                                     */
/***************************************************************************************************/


GPSBDev_t gpsb[GPSB_CH_NUM] =
{
    {
        0,                              /* GPSB channel */
        GPSB0_BASE,                     /* GPSB base address */
        GPSB_WRAP_BASE,                 /* GPSB Port Configuration address */
        (uint32)CLOCK_PERI_GPSB0,       /* Peri. clock number */
        (sint32)CLOCK_IOBUS_GPSB0,      /* IOBUS number */
        TRUE,                           /* GPSB mode (Master or Slave) */
        NULL,                           /* SDO */
        NULL,                           /* SDI */
        NULL,                           /* SCLK */
        NULL,                           /* PORT */
        0, //GIC_PRIORITY_NO_MEAN,      /* Interrupt priority */
        FALSE,                          /* support dma */
        {NULL, },
        {NULL, },
        NULL_PTR,                       /* async pio tx buffer address */
        NULL_PTR,                       /* async pio rx buffer address */
        NULL,                           /* async pio tx buffer size */
        NULL,                           /* async pio rx buffer size */
        NULL,
        {NULL_PTR, },
    },
    {
        1,                              /* GPSB channel */
        GPSB1_BASE,                     /* GPSB base address */
        GPSB_WRAP_BASE,                 /* GPSB Port Configuration address */
        (uint32)CLOCK_PERI_GPSB1,       /* Peri.clock nmumber */
        (sint32)CLOCK_IOBUS_GPSB1,      /* IOBUS number */
        TRUE,                           /* GPSB mode (Master or Slave) */
        NULL,                           /* SDO */
        NULL,                           /* SDI */
        NULL,                           /* SCLK */
        NULL,                           /* PORT */
        0, //GIC_PRIORITY_NO_MEAN,      /* Interrupt priority */
        FALSE,
        {NULL, },
        {NULL, },
        NULL_PTR,                       /* async pio tx buffer address */
        NULL_PTR,                       /* async pio rx buffer address */
        NULL,                           /* async pio tx buffer size */
        NULL,                           /* async pio rx buffer size */
        NULL,
        {NULL_PTR, },
    },
    {
        2,
        GPSB2_BASE,                     /* GPSB channel */
        GPSB_WRAP_BASE,                 /* GPSB Port Configuration address */
        (uint32)CLOCK_PERI_GPSB2,       /* GPSB base address */
        (sint32)CLOCK_IOBUS_GPSB2,      /* Peri.clock number */
        TRUE,                           /* GPSB mode (Master or Slave) */
        NULL,                           /* SDO */
        NULL,                           /* SDI */
        NULL,                           /* SCLK */
        NULL,                           /* PORT */
        0, //GIC_PRIORITY_NO_MEAN,      /* Interrupt priority */
        FALSE,
        {NULL, },
        {NULL, },
        NULL_PTR,                       /* async pio tx buffer address */
        NULL_PTR,                       /* async pio rx buffer address */
        NULL,                           /* async pio tx buffer size */
        NULL,                           /* async pio rx buffer size */
        NULL,
        {NULL_PTR, },
    },
    {
        3,
        GPSB3_BASE,                     /* GPSB channel */
        GPSB_WRAP_BASE,                 /* GPSB Port Configuration address */
        (uint32)CLOCK_PERI_GPSB3,       /* GPSB base address */
        (sint32)CLOCK_IOBUS_GPSB3,      /* Peri.clock number */
        TRUE,                           /* GPSB mode (Master or Slave) */
        NULL,                           /* SDO */
        NULL,                           /* SDI */
        NULL,                           /* SCLK */
        NULL,                           /* PORT */
        0, //GIC_PRIORITY_NO_MEAN,      /* Interrupt priority */
        FALSE,
        {NULL, },
        {NULL, },
        NULL_PTR,                       /* async pio tx buffer address */
        NULL_PTR,                       /* async pio rx buffer address */
        NULL,                           /* async pio tx buffer size */
        NULL,                           /* async pio rx buffer size */
        NULL,
        {NULL_PTR, },
    },
    {
        4,
        GPSB4_BASE,                     /* GPSB channel */
        GPSB_WRAP_BASE,                 /* GPSB Port Configuration address */
        (uint32)CLOCK_PERI_GPSB4,       /* GPSB base address */
        (sint32)CLOCK_IOBUS_GPSB4,      /* Peri.clock number */
        TRUE,                           /* GPSB mode (Master or Slave) */
        NULL,                           /* SDO */
        NULL,                           /* SDI */
        NULL,                           /* SCLK */
        NULL,                           /* PORT */
        0, //GIC_PRIORITY_NO_MEAN,      /* Interrupt priority */
        FALSE,
        {NULL, },
        {NULL, },
        NULL_PTR,                       /* async pio tx buffer address */
        NULL_PTR,                       /* async pio rx buffer address */
        NULL,                           /* async pio tx buffer size */
        NULL,                           /* async pio rx buffer size */
        NULL,
        {NULL_PTR, },
    },
    {
        5,
        GPSB5_BASE,                     /* GPSB channel */
        GPSB_WRAP_BASE,                 /* GPSB Port Configuration address */
        (uint32)CLOCK_PERI_GPSB5,       /* GPSB base address */
        (sint32)CLOCK_IOBUS_GPSB5,      /* Peri.clock number */
        TRUE,                           /* GPSB mode (Master or Slave) */
        NULL,                           /* SDO */
        NULL,                           /* SDI */
        NULL,                           /* SCLK */
        NULL,                           /* PORT */
        0, //GIC_PRIORITY_NO_MEAN,      /* Interrupt priority */
        FALSE,
        {NULL, },
        {NULL, },
        NULL_PTR,                       /* async pio tx buffer address */
        NULL_PTR,                       /* async pio rx buffer address */
        NULL,                           /* async pio tx buffer size */
        NULL,                           /* async pio rx buffer size */
        NULL,
        {NULL_PTR, },
    },
};

/*
Chip Specification
3.3.1.4 General Purpose I/O
*/
const uint32 gpsbport[GPSB_PORT_NUM][5] =
{
    //  GSCK                GSCMD           GSDO            GSDI            FUNC
    {GPIO_GPA(17UL)	 ,  GPIO_GPA(18UL)  , GPIO_GPA(19UL) , GPIO_GPA(20UL) , GPIO_FUNC(2UL)},    // 0
    {GPIO_GPB(17UL)	 ,  GPIO_GPB(18UL)  , GPIO_GPB(19UL) , GPIO_GPB(20UL) , GPIO_FUNC(2UL)},
    {GPIO_GPC(17UL)	 ,  GPIO_GPC(18UL)  , GPIO_GPC(19UL) , GPIO_GPC(20UL) , GPIO_FUNC(2UL)},
    {GPIO_GPD(17UL)	 ,  GPIO_GPD(18UL)  , GPIO_GPD(19UL) , GPIO_GPD(20UL) , GPIO_FUNC(2UL)},

    {GPIO_GPE(2UL)	 ,  GPIO_GPE(3UL)   , GPIO_GPE(4UL)  , GPIO_GPE(5UL)  , GPIO_FUNC(2UL)},	// 4
    {GPIO_GPE(8UL)	 ,  GPIO_GPE(9UL)   , GPIO_GPE(10UL) , GPIO_GPE(11UL) , GPIO_FUNC(2UL)},

    {GPIO_GPF(2UL)	 ,  GPIO_GPF(3UL)   , GPIO_GPF(4UL)  , GPIO_GPF(5UL)  , GPIO_FUNC(2UL)},	// 6
    {GPIO_GPF(8UL)	 ,  GPIO_GPF(9UL)   , GPIO_GPF(10UL) , GPIO_GPF(11UL) , GPIO_FUNC(2UL)},

    {GPIO_GPG(2UL)	 ,  GPIO_GPG(3UL)   , GPIO_GPG(4UL)  , GPIO_GPG(5UL)  , GPIO_FUNC(2UL)},	// 8
    {GPIO_GPG(8UL)	 ,  GPIO_GPG(9UL)   , GPIO_GPG(10UL) , GPIO_GPG(11UL) , GPIO_FUNC(2UL)},

    {GPIO_GPH(2UL)	 ,  GPIO_GPH(3UL)   , GPIO_GPH(4UL)  , GPIO_GPH(5UL)  , GPIO_FUNC(2UL)},	// 10
    {GPIO_GPH(8UL)	 ,  GPIO_GPH(9UL)   , GPIO_GPH(10UL) , GPIO_GPH(11UL) , GPIO_FUNC(2UL)},

    {GPIO_GPI(2UL)	 ,  GPIO_GPI(3UL)   , GPIO_GPI(4UL)  , GPIO_GPI(5UL)  , GPIO_FUNC(2UL)},	// 12
    {GPIO_GPI(8UL)	 ,  GPIO_GPI(9UL)   , GPIO_GPI(10UL) , GPIO_GPI(11UL) , GPIO_FUNC(2UL)},

    {GPIO_GPJ(2UL)	 ,  GPIO_GPJ(3UL)   , GPIO_GPJ(4UL)  , GPIO_GPJ(5UL)  , GPIO_FUNC(2UL)},	// 14
    {GPIO_GPJ(8UL)	 ,  GPIO_GPJ(9UL)   , GPIO_GPJ(10UL) , GPIO_GPJ(11UL) , GPIO_FUNC(2UL)},

    {GPIO_GPL(2UL)	 ,  GPIO_GPL(3UL)   , GPIO_GPL(4UL)  , GPIO_GPL(5UL)  , GPIO_FUNC(2UL)},
    {GPIO_GPL(8UL)	 ,  GPIO_GPL(9UL)   , GPIO_GPL(10UL) , GPIO_GPL(11UL) , GPIO_FUNC(2UL)},
    {GPIO_GPL(14UL)	 ,  GPIO_GPL(15UL)  , GPIO_GPL(16UL) , GPIO_GPL(17UL) , GPIO_FUNC(2UL)},    // 18
};

/*
GPSB_MON
*/
const GPSBSafetyBase_t gpsb_sm[GPSB_CH_NUM] =
{
    {
        (GPSB_IO_MONITOR_BASE + GPSB0_IOMON),
    },
    {
        (GPSB_IO_MONITOR_BASE + GPSB1_IOMON),
    },
    {
        (GPSB_IO_MONITOR_BASE + GPSB2_IOMON),
    },
    {
        (GPSB_IO_MONITOR_BASE + GPSB3_IOMON),
    },
    {
        (GPSB_IO_MONITOR_BASE + GPSB4_IOMON),
    },
    {
        (GPSB_IO_MONITOR_BASE + GPSB5_IOMON),
    },
};

/*
***************************************************************************************************
*                                          GPSB_Isr0
*
* Function to process interrupt about channel 0.
*
* @param    pArg
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_Isr0
(
    void
)
{
    GPSB_D("%s: enter ISR0\n", __func__);
    GPSB_Isr(0);
}

/*
***************************************************************************************************
*                                          GPSB_Isr1
*
* Function to process interrupt about channel 1.
*
* @param    pArg
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_Isr1
(
    void
)
{
    GPSB_D("%s: enter ISR1\n", __func__);
    GPSB_Isr(1);
}

/*
***************************************************************************************************
*                                          GPSB_Isr2
*
* Function to process interrupt about channel 2.
*
* @param    pArg
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_Isr2
(
    void
)
{
    GPSB_D("%s: enter ISR2\n", __func__);
    GPSB_Isr(2);
}

/*
***************************************************************************************************
*                                          GPSB_Isr3
*
* Function to process interrupt about channel 3.
*
* @param    pArg
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_Isr3
(
    void
)
{
    GPSB_D("%s: enter ISR3\n", __func__);
    GPSB_Isr(3);
}

/*
***************************************************************************************************
*                                          GPSB_Isr4
*
* Function to process interrupt about channel 4.
*
* @param    pArg
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_Isr4
(
    void
)
{
    GPSB_D("%s: enter ISR4\n", __func__);
    GPSB_Isr(4);
}

/*
***************************************************************************************************
*                                          GPSB_Isr5
*
* Function to process interrupt about channel 5.
*
* @param    pArg
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_Isr5
(
    void
)
{
    GPSB_D("%s: enter ISR5\n", __func__);
    GPSB_Isr(5);
}


/*
***************************************************************************************************
*                                          GPSB_DmaIsr0
*
* Function to process dma interrupt about channel 0.
*
* @param    pArg
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_DmaIsr0
(
    void
)
{
    GPSB_D("%s: enter DMA-ISR0\n", __func__);
    GPSB_Isr(0);
}

/*
***************************************************************************************************
*                                          GPSB_DmaIsr1
*
* Function to process dma interrupt about channel 1.
*
* @param    pArg
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_DmaIsr1
(
    void
)
{
    GPSB_D("%s: enter DMA-ISR1\n", __func__);
    GPSB_Isr(1);
}

/*
***************************************************************************************************
*                                          GPSB_DmaIsr2
*
* Function to process dma interrupt about channel 2.
*
* @param    pArg
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_DmaIsr2
(
    void
)
{
    GPSB_D("%s: enter DMA-ISR2\n", __func__);
    GPSB_Isr(2);
}

/*
***************************************************************************************************
*                                          GPSB_DmaIsr3
*
* Function to process dma interrupt about channel 3.
*
* @param    pArg
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_DmaIsr3
(
    void
)
{
    GPSB_D("%s: enter DMA-ISR3\n", __func__);
    GPSB_Isr(3);
}

/*
***************************************************************************************************
*                                          GPSB_DmaIsr4
*
* Function to process dma interrupt about channel 4.
*
* @param    pArg
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_DmaIsr4
(
    void
)
{
    GPSB_D("%s: enter DMA-ISR4\n", __func__);
    GPSB_Isr(4);
}

/*
***************************************************************************************************
*                                          GPSB_DmaIsr5
*
* Function to process dma interrupt about channel 5.
*
* @param    pArg
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_DmaIsr5
(
    void
)
{
    GPSB_D("%s: enter DMA-ISR5\n", __func__);
    GPSB_Isr(5);
}

/*
***************************************************************************************************
*                                          GPSB_TargetInit
*
* Registers the GPSB interrupt handler functions and enables the GPSB interrupts.
*
* @return
* Notes
*
***************************************************************************************************
*/

void GPSB_TargetInit
(
    void
)
{
    /* Register gpsb irq handler */
	NVIC_IntVectSet(GPSB_C0_IRQn, (IrqHandler_t)&GPSB_Isr0);
	NVIC_IntSrcEn(GPSB_C0_IRQn);

	NVIC_IntVectSet(GPSB_C1_IRQn, (IrqHandler_t)&GPSB_Isr1);
	NVIC_IntSrcEn(GPSB_C1_IRQn);

	NVIC_IntVectSet(GPSB_C2_IRQn, (IrqHandler_t)&GPSB_Isr2);
	NVIC_IntSrcEn(GPSB_C2_IRQn);

    NVIC_IntVectSet(GPSB_C3_IRQn, (IrqHandler_t)&GPSB_Isr3);
	NVIC_IntSrcEn(GPSB_C3_IRQn);

	NVIC_IntVectSet(GPSB_C4_IRQn, (IrqHandler_t)&GPSB_Isr4);
	NVIC_IntSrcEn(GPSB_C4_IRQn);

	NVIC_IntVectSet(GPSB_C5_IRQn, (IrqHandler_t)&GPSB_Isr5);
	NVIC_IntSrcEn(GPSB_C5_IRQn);

	/* DMA */
	NVIC_IntVectSet(GPSB_DMA_C0_IRQn, (IrqHandler_t)&GPSB_DmaIsr0);
	NVIC_IntSrcEn(GPSB_DMA_C0_IRQn);

	NVIC_IntVectSet(GPSB_DMA_C1_IRQn, (IrqHandler_t)&GPSB_DmaIsr1);
	NVIC_IntSrcEn(GPSB_DMA_C1_IRQn);

	NVIC_IntVectSet(GPSB_DMA_C2_IRQn, (IrqHandler_t)&GPSB_DmaIsr2);
	NVIC_IntSrcEn(GPSB_DMA_C2_IRQn);

    NVIC_IntVectSet(GPSB_DMA_C3_IRQn, (IrqHandler_t)&GPSB_DmaIsr3);
    NVIC_IntSrcEn(GPSB_DMA_C3_IRQn);

    NVIC_IntVectSet(GPSB_DMA_C4_IRQn, (IrqHandler_t)&GPSB_DmaIsr4);
    NVIC_IntSrcEn(GPSB_DMA_C4_IRQn);

    NVIC_IntVectSet(GPSB_DMA_C5_IRQn, (IrqHandler_t)&GPSB_DmaIsr5);
    NVIC_IntSrcEn(GPSB_DMA_C5_IRQn);

    return;
}

/*
***************************************************************************************************
*                                          GPSB_TargetDeinit
*
* Disables all the GPSB interrupts.
*
* @return
* Notes
*
***************************************************************************************************
*/

void GPSB_TargetDeinit(void)
{

	(void)NVIC_IntSrcDis(GPSB_C0_IRQn);
	(void)NVIC_IntSrcDis(GPSB_C1_IRQn);
	(void)NVIC_IntSrcDis(GPSB_C2_IRQn);
	(void)NVIC_IntSrcDis(GPSB_C3_IRQn);
	(void)NVIC_IntSrcDis(GPSB_C4_IRQn);
	(void)NVIC_IntSrcDis(GPSB_C5_IRQn);

	/* DMA */
	(void)NVIC_IntSrcDis(GPSB_DMA_C0_IRQn);
	(void)NVIC_IntSrcDis(GPSB_DMA_C1_IRQn);
	(void)NVIC_IntSrcDis(GPSB_DMA_C2_IRQn);
    (void)NVIC_IntSrcDis(GPSB_DMA_C3_IRQn);
    (void)NVIC_IntSrcDis(GPSB_DMA_C4_IRQn);
    (void)NVIC_IntSrcDis(GPSB_DMA_C5_IRQn);

    return;
}

void GPSB_SetPortCFG
(
    uint32  uiCh,
    uint32  uiPort
)
{
    (void) GPIO_PortSel(uiCh + GPIO_GPMUX_GPSB_0, uiPort);
}

void GPSB_ClearPortCFG
(
    uint32  uiCh
)
{
    (void) GPIO_PortSel(uiCh + GPIO_GPMUX_GPSB_0, 0x1F);
}

/*
***************************************************************************************************
*                                          GPSB_SafetyEnableLock
*
* Function to enable write lock.
*
* @return
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_SafetyEnableLock
(
    void
)
{
    SALRetCode_t    ret;
    uint32          tmp;

    ret = SAL_RET_SUCCESS;
    tmp = 0;

    if(gpsb[0].dCfgAddr < (UINT_MAX_VALUE - GPSB_PCFG_WR_PW))
    {
        SAL_WriteReg(GPSB_PORT_PSWD, (uint32)(gpsb[0].dCfgAddr + GPSB_PCFG_WR_PW));
    }

    if(gpsb[0].dCfgAddr < (UINT_MAX_VALUE - GPSB_PCFG_WR_LOCK))
    {
        SAL_WriteReg(GPSB_PCFG_WR_EN_BIT, (uint32)(gpsb[0].dCfgAddr + GPSB_PCFG_WR_LOCK));
        tmp = SAL_ReadReg((uint32)(gpsb[0].dCfgAddr + GPSB_PCFG_WR_LOCK));
    }

    if ((tmp & GPSB_PCFG_WR_EN_BIT) != GPSB_PCFG_WR_EN_BIT)
    {
        GPSB_D("GPSB write lock fail : %d\n", tmp);
        ret = SAL_RET_FAILED;
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_SafetyDisableLock
*
* Function to disable write lock.
*
* @return
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_SafetyDisableLock
(
    void
)
{
    SALRetCode_t    ret;
    uint32          tmp;

    ret = SAL_RET_SUCCESS;
    tmp = 0;

    if(gpsb[0].dCfgAddr < (UINT_MAX_VALUE - GPSB_PCFG_WR_PW))
    {
        SAL_WriteReg(GPSB_PORT_PSWD, (uint32)(gpsb[0].dCfgAddr + GPSB_PCFG_WR_PW));
    }

    if(gpsb[0].dCfgAddr < (UINT_MAX_VALUE - GPSB_PCFG_WR_LOCK))
    {
        SAL_WriteReg(~(GPSB_PCFG_WR_EN_BIT), (uint32)(gpsb[0].dCfgAddr + GPSB_PCFG_WR_LOCK));
        tmp = SAL_ReadReg((uint32)(gpsb[0].dCfgAddr + GPSB_PCFG_WR_LOCK));
    }

    if ((tmp & GPSB_PCFG_WR_EN_BIT) == GPSB_PCFG_WR_EN_BIT)
    {
        GPSB_D("GPSB write lock fail : 0x%08x\n", tmp);
        ret = SAL_RET_FAILED;
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_SafetyEnableLoopback
*
* Function to enable loopback between master & slave channel.
*
* @param    uiMstCh [in] : Master channel index
* @param    uiSlvCh [in] : Slave channel index
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_SafetyEnableLoopback
(
    uint32                              uiMstCh,
    uint32                              uiSlvCh
)
{
    SALRetCode_t    ret;
    uint32          tmp;

    ret = SAL_RET_SUCCESS;
    tmp = 0UL;

    GPSB_D("loopback: ch%d(m) -> ch%d(s)\n", uiMstCh, uiSlvCh);

    if ((uiMstCh >= (GPSB_CH_NUM)) || (uiSlvCh >= (GPSB_CH_NUM)))
    {
        GPSB_D("loopback supports max %d channels.\n", (GPSB_CH_NUM));
        ret = SAL_RET_FAILED;
    }

	/*
	This will set GPSB Loopback Configuration Register.
	LB_CFG
	uiMstCh << ((uiSlvCh * 4UL) + 1UL
	- this will set Master channel
	((uint32)0x1UL << (uiSlvCh * 4UL))
	- this will enable the channel
	*/
    if (ret == SAL_RET_SUCCESS)
    {
        // tmp = (uiMstCh << ((uiSlvCh * 4UL) + 1UL)) | ( (uint32)0x1UL << (uiSlvCh * 4UL));
		tmp = (uiMstCh << ((uiSlvCh * 4UL) + 1UL)) | ( (uint32)0x1UL << (uiSlvCh * 4UL));

        if(gpsb[0].dCfgAddr < (UINT_MAX_VALUE - GPSB_LB_CFG))
        {
            SAL_WriteReg(tmp, (uint32)(gpsb[0].dCfgAddr + GPSB_LB_CFG));
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_SafetyDisableLoopback
*
* Function to disable loopback between master & slave channel.
*
* @param    uiMstCh [in] : Master channel index
* @param    uiSlvCh [in] : Slave channel index
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_SafetyDisableLoopback
(
    uint32                              uiMstCh,
    uint32                              uiSlvCh
)
{
    SALRetCode_t    ret;
    uint32          tmp;

    ret = SAL_RET_SUCCESS;
    tmp = 0UL;

    if ((uiMstCh >= (GPSB_CH_NUM)) || (uiSlvCh >= (GPSB_CH_NUM)))
    {
        GPSB_D("loopback supports max %d channels.\n", (GPSB_CH_NUM-1UL));
        ret = SAL_RET_FAILED;
    }

    if (ret == SAL_RET_SUCCESS)
    {
        if(gpsb[0].dCfgAddr < (UINT_MAX_VALUE - GPSB_LB_CFG))
        {
            tmp = SAL_ReadReg((uint32)(gpsb[0].dCfgAddr + GPSB_LB_CFG));
            tmp &= (~((0x3UL << 1UL) << (uiSlvCh * 4UL)));
            SAL_WriteReg(tmp, (uint32)(gpsb[0].dCfgAddr + GPSB_LB_CFG));
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_SafetyEnableMonitor
*
* Function to enable safety monitor.
*
* @param    uiCh [in]       : Value of channel to control
* @param    uiMonMode[in]   : Select Protocol/Data stuck monitor
* @param    uiMonWidth      : Value of width of monitor
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_SafetyEnableMonitor
(
    uint32                              uiCh,
    uint32                              uiMonMode,
    uint32                              uiMonWidth
)
{
    SALRetCode_t    ret;
    uint32          tmp;

    ret = SAL_RET_SUCCESS;
    tmp = 0UL;

    if (uiCh >= GPSB_CH_NUM)
    {
        GPSB_D("IO monitor doesn't support ch %d.\n", uiCh);
        ret = SAL_RET_FAILED;
    }
    else
    {
        /* Enable I/O monitor */
		/*
		GPSB-n SPI Protocol Error
		Protocol Error	: 8/16/32
		Stuck Error		: 8

		BSP_BIT_16
		- SPI_EN
			- this will enable GPSB Monitoring.
		*/
        tmp = BSP_BIT_16 | uiMonWidth; // Protocol & monitor enable

		/*
		only for GPSB-n GSDI Stuck Error Test
		BSP_BIT_20
		- SDI_1
			- GPSB data stuck-at-1 monitoring
		BSP_BIT_21
		- SDI_0
			- GPSB data stuck-at-0 monitoring
		*/
        if(uiMonMode == (uint32)GPSB_SM_MON_STUCK_BOTH)
        {
            tmp |= BSP_BIT_20 | BSP_BIT_21;
        }
        else if(uiMonMode == (uint32)GPSB_SM_MON_STUCK_HIGH)
        {
            tmp |= BSP_BIT_20;
        }
        else if(uiMonMode == (uint32)GPSB_SM_MON_STUCK_LOW)
        {
            tmp |= BSP_BIT_21;
        }
        else
        {
            GPSB_D("%s : unknown GPSB_SM_MODE.\n",__func__);
        }

		/*
		Read GPSB_MODE
		BSP_BIT_16
		- PCK
			- Polarity control for serial clock
			- 0x0: SCK0 starts from "low" for SPI timing 0
			- 0x1: SCK0 starts from "1" for SPI timing 2 and 3
		
		Set GPSB_MON
		BSP_BIT_17
		- SCK_POL
			- 0x0: SPI Timing-0 or SPI Timing-3. Capture at rising edge
			- 0x1: SPI Timing-1 or SPI Timing-2. Capture at falling edge
		*/
        if((SAL_ReadReg((uint32)(GPSB_CH_BASE(uiCh)+GPSB_MODE)) & BSP_BIT_16) > 0UL)
        {
            tmp |= BSP_BIT_17; // SCK Polarity set
        }
        else
        {
            tmp &= ~(BSP_BIT_17); // Clear SCK_POL
        }

		/*
		Write GPSB_MON.
		*/
        SAL_WriteReg(tmp, gpsb_sm[uiCh].sbBaseAddr);
        GPSB_D("Set IO Mon value Ch %d : 0x%x \n", uiCh , SAL_ReadReg(gpsb_sm[uiCh].sbBaseAddr));

    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_SafetyDisableMonitor
*
* Function to disable safety monitor.
*
* @param    uiCh [in]       : Value of channel to control
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_SafetyDisableMonitor
(
    uint32                              uiCh
)
{
    SALRetCode_t    ret;

    ret = SAL_RET_SUCCESS;

    if (uiCh >= GPSB_CH_NUM)
    {
        GPSB_D("IO monitor doesn't supports ch %d.\n", uiCh);
        ret = SAL_RET_FAILED;
    }
    else
    {
        /* Disable I/O monitor */
        SAL_WriteReg(0x0, gpsb_sm[uiCh].sbBaseAddr);
        SAL_WriteReg((uint32)((uint32)0x1UL << (uint32)uiCh) , (uint32)(GPSB_IO_MONITOR_BASE + GPSB_IOMON_CLR));
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_SafetyGetStatus
* Function to get safety monitor status.
*
* @param    uiCh [in]       : Value of channel to control
* @return   GPSB_SM_ERR_NONE or GPSB_SM_ERR
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_SafetyGetStatus
(
    uint32                              uiCh
)
{
    SALRetCode_t    ret;
    uint32          tmp;

    ret = SAL_RET_SUCCESS;
    tmp = 0;

    if (uiCh >= GPSB_CH_NUM)
    {
        GPSB_D("GPSB-sm support max %d channels.\n", GPSB_CH_NUM);
        ret = SAL_RET_FAILED;
    }

    if (ret == SAL_RET_SUCCESS)
    {
        /* Read status */
        tmp = SAL_ReadReg(gpsb_sm[uiCh].sbBaseAddr);
        GPSB_D("Get IO Monitor value [ch : %d] : 0x%x \n", uiCh ,tmp);

		/*
		Read GPSB_MON
		STATUS[0]: GPSB-n SPI Protocol Error
		STATUS[1]: GPSB-n SPI GSDI Stuck Error
		*/
        if ((tmp & BSP_BIT_24) > 0UL)
        {
            mcu_printf("SM MONITOR : PROTOCOL ERROR \n");
        }

        if ((tmp & BSP_BIT_25) > 0UL)
        {
            mcu_printf("SM MONITOR : STUCK ERROR \n");
        }
    }

    return ret;
}


