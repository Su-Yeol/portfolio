/*
***************************************************************************************************
*
*   FileName : gpsb.c
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#include <gpsb_reg.h>

/*
***************************************************************************************************
*                                         DEFINITIONS
***************************************************************************************************
*/

/*************************************************************************************************/
/*                                      LOCAL VARIABLES                                          */
/*************************************************************************************************/
static uint32                           dma_tx_dummy[8] = {0};
static uint32                           dma_rx_dummy[8] = {0};
/*
***************************************************************************************************
*                                      FUNCTION PROTOTYPES
***************************************************************************************************
*/

static void GPSB_BitSClear
(
    uint32                              uiAddr,
    uint32                              uiSmask,
    uint32                              uiCmask
);

static void GPSB_DmaStart
(
    uint32                              uiCh
);

static void GPSB_DmaStop
(
    uint32                              uiCh
);

static SALRetCode_t GPSB_DmaSetAddr
(
    uint32                              uiCh,
    const uint32 *                      uiTx,
    const uint32 *                      uiRx
);

static SALRetCode_t GPSB_SetPort
(
    uint32                              uiCh,
    uint32                              uiPort
);

static void GPSB_SetXferState
(
    uint32                              uiCh,
    uint32                              uiState
);

static uint32 GPSB_FifoWrite
(
    uint32                              uiCh,
    const uint32 *                      puiTxBuf,
    uint32                              uiTxBufSize
);

static uint32 GPSB_FifoRead
(
    uint32                              uiCh,
    uint32 *                            puiRxBuf,
    uint32                              uiRxBufSize
);

static uint32 GPSB_GetBpw
(
    uint32                              uiCh
);

static SALRetCode_t GPSB_SetCs
(
    int32                               iCs,
    uint32                              uiEnable,
    uint32                              uiCsHigh
);

static SALRetCode_t GPSB_WaitRxFifoValid
(
    uint32                              uiCh
);

static SALRetCode_t GPSB_FifoSyncXfer8
(
    uint32                              uiCh,
    const uint8 *                       pTx,
    uint8 *                             pRx,
    uint32                              uiDataSize
);

static SALRetCode_t GPSB_FifoSyncXfer16
(
    uint32                              uiCh,
    const uint8 *                       pTx,
    uint8 *                             pRx,
    uint32                              uiDataSize
);

static SALRetCode_t GPSB_FifoSyncXfer32
(
    uint32                              uiCh,
    const uint8 *                       pTx,
    uint8 *                             pRx,
    uint32                              uiDataSize
);

static SALRetCode_t GPSB_FiFoAsyncXfer
(
    uint32                              uiCh,
    const uint32 *                      pTx,
    uint32 *                            pRx,
    uint32                              uiDataSize
);

static SALRetCode_t GPSB_DmaAsyncXfer
(
    uint32                              uiCh,
    const uint32 *                      pTx,
    uint32 *                            pRx,
    uint32                              uiDataSize
);

static void GPSB_HwInit
(
    uint32                              uiCh
);

static uint32 GPSB_CheckIsrStatus
(
    uint32 uiCh,
    uint32 status
);

static void GPSB_IsrError
(
    uint32                              uiCh,
    uint32                              uiStatus
);

static void GPSB_IsrAsyncFifo
(
    uint32                              uiCh
);

static uint32 GPSB_IsMaster
(
    uint32                              uiCh
);

static void GPSB_Enable
(
    uint32                              uiCh
);

static void GPSB_Disable
(
    uint32                              uiCh
);

static void GPSB_EnableIntr
(
    uint32                              uiCh
);

static void GPSB_DisableIntr
(
    uint32                              uiCh
);

#ifdef GPSB_DEBUG
static void GPSB_RegDump
(
    uint32                              uiCh
);
#endif

/*
***************************************************************************************************
*                                          GPSB_RegDump
*
* Function to dump all of GPSB register about selected channel.
*
* @param    uiCh [in]       : Value of channel to control
* @return
* Notes
*
***************************************************************************************************
*/

#ifdef GPSB_DEBUG
void GPSB_RegDump
(
    uint32                              uiCh
)
{


    GPSB_D("##### GPSB REG DUMP CH %d (@0x%X)#####\n", uiCh, gpsb[uiCh].dBase);
    GPSB_D("STAT    0x%08X\n", SAL_ReadReg(gpsb[uiCh].dBase + GPSB_STAT));
    GPSB_D("INTEN   0x%08X\n", SAL_ReadReg(gpsb[uiCh].dBase + GPSB_INTEN));
    GPSB_D("MODE    0x%08X\n", SAL_ReadReg(gpsb[uiCh].dBase + GPSB_MODE));
    GPSB_D("CTRL    0x%08X\n", SAL_ReadReg(gpsb[uiCh].dBase + GPSB_CTRL));
    GPSB_D("TXBASE  0x%08X\n", SAL_ReadReg(gpsb[uiCh].dBase + GPSB_TXBASE));
    GPSB_D("RXBASE  0x%08X\n", SAL_ReadReg(gpsb[uiCh].dBase + GPSB_RXBASE));
    GPSB_D("PACKET  0x%08X\n", SAL_ReadReg(gpsb[uiCh].dBase + GPSB_PACKET));
    GPSB_D("DMACTR  0x%08X\n", SAL_ReadReg(gpsb[uiCh].dBase + GPSB_DMACTR));
    GPSB_D("DMASTAT 0x%08X\n", SAL_ReadReg(gpsb[uiCh].dBase + GPSB_DMASTR));
    GPSB_D("DMAICR  0x%08X\n", SAL_ReadReg(gpsb[uiCh].dBase + GPSB_DMAICR));
    GPSB_D("PCFG    0x%08X\n", SAL_ReadReg((uint32)GPSB_PORT_CFG(0)));
}
#endif

/*
***************************************************************************************************
*                                          GPSB_BitCSet
*
* Function to clear & set bit in GPSB register.
*
* @param    addr [in]       : Value of Register Address
*           cmask [in]      : Value of clear bit mask
*           smask [in]      : Value of set bit mask
* @return
* Notes
*
***************************************************************************************************
*/

void GPSB_BitCSet
(
    uint32                              uiAddr,
    uint32                              uiCmask,
    uint32                              uiSmask
)
{
    uint32  val;

    val = (uint32)SAL_ReadReg(uiAddr);
    BSP_BitClr32(val, uiCmask);
    BSP_BitSet32(val, uiSmask);
    SAL_WriteReg(val, uiAddr);

    return;
}

/*
***************************************************************************************************
*                                          GPSB_BitSClear
*
* Function to set & clear bit in GPSB register.
*
* @param    addr [in]       : Value of Register Address
*           smask [in]      : Value of set bit mask
*           cmask [in]      : Value of clear bit mask*
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_BitSClear
(
    uint32                              uiAddr,
    uint32                              uiSmask,
    uint32                              uiCmask
)
{
    uint32  val;

    val = (uint32)SAL_ReadReg(uiAddr);
    BSP_BitSet32(val, uiSmask);
    BSP_BitClr32(val, uiCmask);
    SAL_WriteReg(val, uiAddr);

    return;
}

/*
***************************************************************************************************
*                                          GPSB_IsMaster
*
* Function to check gpsb chanel is master.
*
* @param    uiCh [in]       : Value of GPSB Channel.
* @return   TRUE or FALSE
* Notes
*
***************************************************************************************************
*/

static uint32 GPSB_IsMaster
(
    uint32                              uiCh
)
{
    uint32 ret;

    if(gpsb[uiCh].dIsSlave == (uint32)FALSE)
    {
        ret = 1UL;
    }
    else
    {
        ret = 0UL;
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_Enable
*
* Function to check gpsb chanel is master.
*
* @param    uiCh [in]       : Value of GPSB Channel.
* @return   TRUE or FALSE
* Notes
*
***************************************************************************************************
*/

static void GPSB_Enable
(
    uint32                              uiCh
)
{
    uint32 paddr;
    uint32 reg;

    paddr = 0UL;
    reg = 0UL;

    if(gpsb[(uiCh)].dBase < (UINT_MAX_VALUE - GPSB_MODE))
    {
        /* Enable GPSB operation */
        paddr = (uint32)gpsb[(uiCh)].dBase + GPSB_MODE;
        reg = SAL_ReadReg(paddr) | (BSP_BIT_03);
        SAL_WriteReg(reg, paddr);
    }

    return;
}

/*
***************************************************************************************************
*                                          GPSB_Disable
*
* Function to disable gpsb chanel.
*
* @param    uiCh [in]       : Value of GPSB Channel.
* @return   TRUE or FALSE
* Notes
*
***************************************************************************************************
*/

static void GPSB_Disable
(
    uint32                              uiCh
)
{
    uint32 paddr = 0;
    uint32 reg;

    reg = 0UL;

    if(gpsb[(uiCh)].dBase < (UINT_MAX_VALUE - GPSB_MODE))
    {
        paddr = (uint32)gpsb[(uiCh)].dBase + GPSB_MODE;

        /* Disable GPSB operation */
        reg = SAL_ReadReg(paddr) & (~BSP_BIT_03);
        SAL_WriteReg(reg, paddr);
    }

    return;
}

/*
***************************************************************************************************
*                                          GPSB_EnableIntr
*
* Function to enable interrupt for gpsb chanel.
*
* @param    uiCh [in]       : Value of GPSB Channel.
* @return   TRUE or FALSE
* Notes
*
***************************************************************************************************
*/

static void GPSB_EnableIntr
(
    uint32                              uiCh
)
{
    uint32 paddr;
    uint32 reg;

    paddr = 0UL;
    paddr = 0UL;

    if(gpsb[(uiCh)].dBase < (UINT_MAX_VALUE - GPSB_INTEN))
    {
        /* Enable GPSB Interrupt */
        paddr = (uint32)gpsb[(uiCh)].dBase + GPSB_INTEN;
        reg = SAL_ReadReg(paddr) | (BSP_BIT_00);
        SAL_WriteReg(reg, paddr);
    }

    return;
}

/*
***************************************************************************************************
*                                          GPSB_DisableIntr
*
* Function to disable interrupt for gpsb chanel.
*
* @param    uiCh [in]       : Value of GPSB Channel.
* @return   TRUE or FALSE
* Notes
*
***************************************************************************************************
*/

static void GPSB_DisableIntr
(
    uint32                              uiCh
)
{
    uint32 paddr;
    uint32 reg;

    paddr = 0UL;
    reg = 0UL;

    if(gpsb[(uiCh)].dBase < (UINT_MAX_VALUE - GPSB_INTEN))
    {
        paddr = (uint32)gpsb[(uiCh)].dBase + GPSB_INTEN;

        /* Disable GPSB Interrupt */
        reg = SAL_ReadReg(paddr) & (~BSP_BIT_00);
        SAL_WriteReg(reg, paddr);
    }

    return;
}

/*
 ***************************************************************************************************
*                                          GPSB_DmaStart
*
* Function to start dma.
*
* @param    uiCh [in]       : Value of channel to control
* @return
* Notes
*           Now we support dma operation for channel 0 to 4 only
*           Start dma operation
*
***************************************************************************************************
*/

static void GPSB_DmaStart
(
    uint32                              uiCh
)
{
    uint32 addr;
    uint32 reg;

    addr = 0UL;
    reg  = 0UL;

    /* Setup GPSB DMA */
    if(uiCh < DEDICATED_DMA_NUM)
    {
        /* Set GPSB DMA Address mode - Multiple address mode */
        if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_INTEN))
        {
            /* Enable DMA request for TX/RX FIFO */
            addr = (uint32)gpsb[(uiCh)].dBase + GPSB_INTEN;
            reg = SAL_ReadReg(addr) | (BSP_BIT_31 | BSP_BIT_30);
            SAL_WriteReg(reg, addr);
        }

        if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_DMACTR))
        {
            /* Enable DMA Tx and Rx request */
            addr = (uint32)gpsb[(uiCh)].dBase + GPSB_DMACTR;
            reg = SAL_ReadReg(addr) | (BSP_BIT_31 | BSP_BIT_30);
            SAL_WriteReg(reg, addr);
        }

        if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_DMAICR))
        {
            /* Enbale DMA done interrupt and Disable DMA packet interrupt */
            GPSB_BitSClear((uint32)gpsb[uiCh].dBase + GPSB_DMAICR, BSP_BIT_17, BSP_BIT_16);

            /* Set DMA Rx interrupt */
            addr = gpsb[uiCh].dBase + GPSB_DMAICR;
            reg = SAL_ReadReg(addr) & ~(BSP_BIT_20);
            SAL_WriteReg(reg, addr);
        }

        if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_DMACTR))
        {
            /* Enable GPSB DMA operation */
            addr = (uint32)gpsb[(uiCh)].dBase + GPSB_DMACTR;
            reg = SAL_ReadReg(addr) | (BSP_BIT_00);
            SAL_WriteReg(reg, addr);
        }
    }

    return;
}

/*
***************************************************************************************************
*                                          GPSB_DmaStop
*
* Function to Stop dma.
*
* @param    uiCh [in]       : Value of channel to control
* @return
* Notes
*           Stop dma operation and clear interrupt status
*
***************************************************************************************************
*/

static void GPSB_DmaStop
(
    uint32                              uiCh
)
{
    uint32  addr;
    uint32  reg;

    addr = 0UL;
    reg = 0UL;

    if(uiCh < DEDICATED_DMA_NUM)
    {
        if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_INTEN))
        {
            /* Disable DMA request for TX/RX FIFO */
            addr = gpsb[uiCh].dBase + GPSB_INTEN;
            reg = SAL_ReadReg(addr) & ~(BSP_BIT_31 | BSP_BIT_30);
            SAL_WriteReg(reg, addr);
        }

        if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_DMACTR))
        {
            /* Disable DMA Tx and Rx request */
            addr = gpsb[uiCh].dBase + GPSB_DMACTR;
            reg = SAL_ReadReg(addr) & ~(BSP_BIT_31 | BSP_BIT_30);
            SAL_WriteReg(reg, addr);
        }

        if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_DMAICR))
        {
            /* Clear DMA done and packet interrupt status */
            addr = (uint32)gpsb[(uiCh)].dBase + GPSB_DMAICR;
            reg = SAL_ReadReg(addr) | (BSP_BIT_29 | BSP_BIT_28);
            SAL_WriteReg(reg, addr);
        }

        if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_DMACTR))
        {
            /* Disable GPSB DMA operation */
            addr = gpsb[uiCh].dBase + GPSB_DMACTR;
            reg = SAL_ReadReg(addr) & (~BSP_BIT_00);
            SAL_WriteReg(reg, addr);
        }
    }
    else
    {
        /* Nothing to do */
    }

    return;
}

/*
***************************************************************************************************
*                                          GPSB_DmaSetAddr
*
* Function to set dma buffer address.
*
* @param    uiCh [in]       : Value of channel to control
* @param    uiTx [in]       : TX dma buffer address
* @param    uiRx [in]       : RX dma buffer address
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

static SALRetCode_t GPSB_DmaSetAddr
(
    uint32                              uiCh,
    const uint32 *                      uiTx,
    const uint32 *                      uiRx
)
{
    const uint32 * tx = uiTx;
    const uint32 * rx = uiRx;
    const uint32 * rx_dummy;
    SALRetCode_t    ret;
    uint32          addr;
    uint32          reg;

    addr    = 0UL;
    reg     = 0UL;
    ret     = SAL_RET_SUCCESS;

    if(uiCh > DEDICATED_DMA_NUM)
    {
        GPSB_D("ch %x is not support dma operation\n", uiCh);

        ret = SAL_RET_FAILED;
    }
    else
    {
        /* Set TXBASE and RXBASE */
        if(uiTx != NULL_PTR)
        {
            /* Set multiple packet address mode */
            tx = uiTx;

            if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_DMACTR))
            {
                addr = gpsb[uiCh].dBase + GPSB_DMACTR;
                reg = SAL_ReadReg(addr) & ~(BSP_BIT_17 | BSP_BIT_16);
                SAL_WriteReg(reg, addr);
            }
        }
        else
        {
            /* Set fixed address mode */
            rx_dummy   = dma_tx_dummy;
            tx      = rx_dummy;

            if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_DMACTR))
            {
                GPSB_BitCSet(gpsb[uiCh].dBase + GPSB_DMACTR, BSP_BIT_17 | BSP_BIT_16, BSP_BIT_16);
            }
        }

        if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_TXBASE))
        {
            SAL_WriteReg((uint32)tx, (uint32)(gpsb[uiCh].dBase + GPSB_TXBASE));
#ifdef GPSB_TXBASE_H
            SAL_WriteReg(0x0, (uint32)(gpsb[uiCh].dBase + GPSB_TXBASE_H));  // 32-bit address
#endif
        }

        if(uiRx != NULL_PTR)
        {
            /* Set multiple packet address mode */
            rx = uiRx;
            addr = gpsb[uiCh].dBase + GPSB_DMACTR;
            reg = SAL_ReadReg(addr) & ~(BSP_BIT_15 | BSP_BIT_14);
            SAL_WriteReg(reg, addr);
        }
        else
        {
            /* Set fixed address mode */
            rx_dummy   = dma_rx_dummy;
            rx      = rx_dummy;
            GPSB_BitCSet(gpsb[uiCh].dBase + GPSB_DMACTR, BSP_BIT_15 | BSP_BIT_14, BSP_BIT_14);
        }

        SAL_WriteReg((uint32)rx, (uint32)(gpsb[uiCh].dBase + GPSB_RXBASE));
#ifdef GPSB_RXBASE_H
        SAL_WriteReg(0x0, (uint32)(gpsb[uiCh].dBase + GPSB_RXBASE_H));
#endif
        /* Set Tx and Rx FIFO threshold for interrupt/DMA request */
        GPSB_BitCSet((gpsb[uiCh].dBase + (uint32)GPSB_INTEN), ((uint32)0x7UL << 16UL),
                (((uint32)GPSB_CFGRTH & (uint32)0x7UL) << 16UL));
        GPSB_BitCSet((gpsb[uiCh].dBase + (uint32)GPSB_INTEN), ((uint32)0x7UL << 20UL),
                (((uint32)GPSB_CFGWTH & (uint32)0x7UL) << 20UL));

        ret = SAL_RET_SUCCESS;

    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_Reset
*
* Resets the GPSB channel in IOBUS.
*
* @param    uiCh [in]       : Value of channel to be controlled
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_Reset
(
    uint32                              uiCh
)
{

    sint32  err;
    SALRetCode_t ret;

    err = 0;

    ret = SAL_RET_SUCCESS;

    /* SW reset */
    err = CLOCK_SetSwReset((sint32)(gpsb[uiCh].dIobusName), TRUE);

    if(err != 0)
    {
        ret = SAL_RET_FAILED;
    }
    else
    {
        err = CLOCK_SetSwReset((sint32)(gpsb[uiCh].dIobusName), FALSE);

        if(err != 0)
        {
            ret = SAL_RET_FAILED;
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_SetPort
*
* Function to set hw port info.
*
* @param    uiCh [in]       : Value of channel to control
* @param    uiPort [in]     : GPSB port index
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/
static SALRetCode_t GPSB_SetPort
(
    uint32                              uiCh,
    uint32                              uiPort
)
{

    SALRetCode_t    ret;
    uint32          i;
    uint32          port;
	
    ret         = SAL_RET_SUCCESS;
    port        = 0;
/*
Author:	James.Jang
Date:		24.07.26
Purpose:	If without below initialize with arguement, GPSB communicate with only Port 0.
TCS:		TMBSPG-1308
*/
	port		= uiPort;

    if(uiPort < GPSB_PORT_NUM)
    {
        for (i = 0 ; i < GPSB_CH_NUM ; i++)
        {
            if ((i != uiCh) && (gpsb[i].dPort == port) && (gpsb[i].dPort != (uint32)NULL))
            {
                GPSB_D("%s: 0x%x port is already used by ch 0x%x\n", __func__, port, i);
                ret = SAL_RET_FAILED;
                break;
            }
        }

        if(ret == SAL_RET_SUCCESS)
        {
            // Default CTF mode (Peripheral CS signal control)
            ret = (SALRetCode_t)GPIO_Config((uint32)gpsbport[port][GPSB_CS], (uint32)(gpsbport[port][GPSB_FUNC] | GPIO_OUTPUT));

            if(ret == SAL_RET_SUCCESS)
            {
                ret = (SALRetCode_t)GPIO_Config((uint32)gpsbport[port][GPSB_SDO], (uint32)(gpsbport[port][GPSB_FUNC] | GPIO_OUTPUT));

                if(ret == SAL_RET_SUCCESS)
                {
                    ret = (SALRetCode_t)GPIO_Config((uint32)gpsbport[port][GPSB_SDI], (uint32)((gpsbport[port][GPSB_FUNC] | GPIO_INPUT) | GPIO_INPUTBUF_EN));

                    if(ret == SAL_RET_SUCCESS)
                    {
                        ret = (SALRetCode_t)GPIO_Config((uint32)gpsbport[port][GPSB_SCLK], (uint32)(gpsbport[port][GPSB_FUNC] | GPIO_OUTPUT));

                        if(ret == SAL_RET_SUCCESS)
                        {
                        #if 0
                            cbit = (uint32)GPSB_PORT_SEL_MASK << ((uiCh % 4UL) * 8UL);
                            sbit = gpsb[uiCh].dPort << ((uiCh % 4UL) * 8UL);

                            GPSB_BitCSet(GPSB_PCFG_BASE , cbit, sbit);
                            GPSB_D("%s: PCFG 0x%08x\n", __func__, SAL_ReadReg(GPSB_PCFG_BASE));
                        #endif
							GPSB_SetPortCFG(uiCh, gpsb[uiCh].dPort);
                        }
                    }
                }
            }
        }
    }
    else
    {
        GPSB_D("%s: GPSB gpsb port is wrong\n", __func__);
        ret = SAL_RET_FAILED;
    }

    return ret;
}


/*
***************************************************************************************************
*                                          GPSB_SetXferState
*
* Function to change xfer state.
*
* @param    uiCh [in]       : Value of channel to control
* @param    uiState [in]    : Xfer state (GPSB_XFER_STATE_DISABLED/IDLE/RUNNING)
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_SetXferState
(
    uint32                              uiCh,
    uint32                              uiState
)
{
    switch(uiState)
    {
        case GPSB_XFER_STATE_DISABLED:
        case GPSB_XFER_STATE_IDLE:
        case GPSB_XFER_STATE_RUNNING:
        {
            //GPSB_D("%s: ch %d xfer state is set to 0x%x\n", __func__, uiCh, uiState);
            gpsb[uiCh].dState = (uint8)uiState;
            break;
        }

        default:
        {
            GPSB_E("%s: state is not supported!\n", __func__);
            break;
        }
    }

    return;
}

/*
***************************************************************************************************
*                                          GPSB_FifoWrite
*
* Function to write data to PORT regitster with interrupt xfer mode.
*
* @param    uiCh [in]       : Value of channel to control
* @param    puiTxBuf [in]   : TX data buff
* @param    uiTxBufSize [in]: TX data size
* @return   write data size
* Notes
*
***************************************************************************************************
*/

static uint32 GPSB_FifoWrite
(
    uint32                              uiCh,
    const uint32 *                      puiTxBuf,
    uint32                              uiTxBufSize
)
{
    uint32          i;
    uint32          j;
    uint32          word_size;
    const uint32 *  tx;
    uint32          cnt;
    uint32          write_data;
    uint32          ret;

    word_size   = 0;
    tx          = NULL;
    cnt         = 0;
    write_data  = 0;
    ret         = 0;

    if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_MODE))
    {
        word_size = (uint32)((SAL_ReadReg((uint32)(gpsb[uiCh].dBase + GPSB_MODE)) >> 8UL) & 0x1FUL) + 1UL;
    }

    word_size   = word_size / 8UL;

    if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_STAT))
    {
        /* Get empty fifo count */
        cnt = (SAL_ReadReg((uint32)(gpsb[uiCh].dBase + GPSB_STAT)) >> 24UL) & 0xFUL;
    }

    if(word_size > 2UL)
    {
        /*
         * With BPW=32 and higher speed, ROR error occurs.
         * In order to prevent ROR error, we limit FIFO size (8->4).
         * We confirmed operation at speed up to 25 MHz.
         * We recommend DMA transfer at high speed.
         */
        cnt = 4UL - cnt;
    }
    else
    {
        cnt = 8UL - cnt;
    }

    tx = puiTxBuf;

    for(i = 0 ; i < cnt ; i++)
    {
        write_data  = 0;

        if(tx != (uint32 *)NULL_PTR)
        {
            if(word_size <= 1UL)
            {
                write_data = tx[0];
            }
            else if(word_size <= 2UL)
            {
                write_data = (((uint32)tx[1] << 8UL) | (uint32)tx[0]);
            }
            else
            {
                write_data = (((uint32)tx[3] << 24UL) | ((uint32)tx[2] << 16UL)
                               |((uint32)tx[1] << 8UL) | ((uint32)tx[0] << 0));
            }

            for(j = 0 ; j < word_size ; j++)
            {
                tx++;
            }
        }

        if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_PORT))
        {
            SAL_WriteReg(write_data, (uint32)(gpsb[uiCh].dBase + GPSB_PORT));
        }
        ret += word_size;

        if(ret >= uiTxBufSize)
        {
            break;
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_FifoRead
*
* Function to read data to PORT regitster with interrupt xfer mode.
*
* @param    uiCh [in]       : Value of channel to control
* @param    puiRxBuf [out]  : RX data buff
* @param    uiRxBufSize [in]: RX data size
* @return   read data size
* Notes
*
***************************************************************************************************
*/

static uint32 GPSB_FifoRead
(
    uint32                              uiCh,
    uint32 *                            puiRxBuf,
    uint32                              uiRxBufSize
)
{
    uint32      i;
    uint32      j;
    uint32      word_size;
    uint32 *    rx;
    uint32      cnt;
    uint32      read_data;
    uint32      ret;

    word_size   = 0;
    rx          = NULL_PTR;
    cnt         = 0;
    read_data   = 0;
    ret         = 0;

    /* Get empty fifo count */
    if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_STAT))
    {
        cnt         = (SAL_ReadReg((uint32)(gpsb[uiCh].dBase + GPSB_STAT)) >> 16UL) & 0xFUL;
    }

    if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_MODE))
    {
        word_size   = (((SAL_ReadReg((uint32)(gpsb[uiCh].dBase + GPSB_MODE)) >> 8UL) & 0x1FUL) + 1UL);
    }

    word_size   = word_size / (uint32)8UL;
    rx          = puiRxBuf;

    for(i = 0 ; i < cnt ; i++)
    {
        if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_PORT))
        {
            read_data = SAL_ReadReg((uint32)(gpsb[uiCh].dBase + GPSB_PORT));
        }

        if(rx != (uint32 *)NULL_PTR)
        {
            if(word_size <= (uint32)1UL)
            {
                rx[0] = (uint32)(read_data & 0xFFUL);
            }
            else if(word_size <= (uint32)2UL)
            {
                rx[0] = (uint32)(read_data & 0xFFUL);
                rx[1] = (uint32)((read_data >> 8UL) & 0xFFUL);
            }
            else
            {
                rx[0] = (uint32)(read_data & 0xFFUL);
                rx[1] = (uint32)((read_data >> 8UL) & 0xFFUL);
                rx[2] = (uint32)((read_data >> 16UL) & 0xFFUL);
                rx[3] = (uint32)((read_data >> 24UL) & 0xFFUL);
            }

            for(j = 0 ; j < word_size ; j++)
            {
                rx++;
            }
        }

        ret += word_size;

        if(ret >= uiRxBufSize)
        {
            break;
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_SetSpeed
*
* Sets GPSB operating clock speed.
*
* @param    uiCh [in]       : Value of channel to be controlled
* @param    uiSpeedInHz [in]: SCLK speed
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_SetSpeed
(
    uint32                              uiCh,
    uint32                              uiSpeedInHz
)
{
    uint32  pclk;
    uint32  divldv;
    sint32  result;
    SALRetCode_t ret;

    pclk    = 0;
    divldv  = 0;
    result  = 0;
    ret     = SAL_RET_SUCCESS;

    if(gpsb[uiCh].dBase < (UINT_MAX_VALUE -GPSB_MODE))
    {
        divldv  = ((SAL_ReadReg((uint32)(gpsb[uiCh].dBase + (uint32)GPSB_MODE)) >> 24UL) & 0xFFUL);
    }

    if(uiSpeedInHz < ((UINT_MAX_VALUE / 2UL)/(divldv + 1UL)))
    {
        pclk    = uiSpeedInHz * (divldv + 1UL) * 2UL;
    }

    GPSB_D("%s: speed: %d / divldv: %d / pclk: %d\n", __func__, uiSpeedInHz, divldv, pclk);

    if(gpsb[uiCh].dPeriName < (uint32)CLOCK_PERI_MAX)
    {
        result  = CLOCK_SetPeriRate((sint32)gpsb[uiCh].dPeriName, pclk);

    if(result != 0)
    {
        GPSB_D("%s: ch %d failed to set peri. clock\n", __func__, uiCh);

        ret = SAL_RET_FAILED;
    }
    else
    {
        if(gpsb[uiCh].dPeriName < (uint32)CLOCK_PERI_MAX)
        {
            (void)CLOCK_EnablePeri((sint32)(gpsb[uiCh].dPeriName));
        }

        ret = SAL_RET_SUCCESS;
    }
    }
    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_SetBpw
*
* Sets the BPW value. Valid BPW value is 8, 16, or 32.
*
* @param    uiCh [in]       : Value of channel to control
* @param    uiBpw [in]      : Bit per word
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_SetBpw
(
    uint32                              uiCh,
    uint32                              uiBpw
)
{
    SALRetCode_t    ret;
    uint32          addr;
    uint32          reg;

    addr = 0UL;
    reg  = 0UL;
    ret = SAL_RET_SUCCESS;

    if(((uiBpw != (uint32)8UL) && (uiBpw != (uint32)16UL)) && (uiBpw != (uint32)32UL))
    {
        GPSB_D("%s: ch %d bpw is not supported\n", __func__, uiBpw);
        ret = SAL_RET_FAILED;
    }
    else
    {
        if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_MODE))
        {
            GPSB_BitCSet((gpsb[uiCh].dBase + GPSB_MODE) , (0x1FUL << 8UL), (((uiBpw - 1UL) & 0x1FUL) << 8UL));
        }

        /*
         * According to bits per word, Tx/Rx half-word and byte swap should be set
         */

        if(uiBpw == 8UL)
        {
            if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_INTEN))
            {
                addr = gpsb[uiCh].dBase + GPSB_INTEN;
                reg = SAL_ReadReg(addr) & ~(BSP_BIT_24 | BSP_BIT_25 | BSP_BIT_26 | BSP_BIT_27);
                SAL_WriteReg(reg, addr);
            }
        }
        else if(uiBpw == 16UL)
        {
            if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_INTEN))
            {
                GPSB_BitCSet(gpsb[uiCh].dBase + GPSB_INTEN, (BSP_BIT_24 | BSP_BIT_25 | BSP_BIT_26 | BSP_BIT_27), (BSP_BIT_24 | BSP_BIT_26));
            }
        }
        else
        {
            if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_INTEN))
            {
                addr = (uint32)gpsb[(uiCh)].dBase + GPSB_INTEN;
                reg = SAL_ReadReg(addr) | (BSP_BIT_24 | BSP_BIT_25 | BSP_BIT_26 | BSP_BIT_27);
                SAL_WriteReg(reg, addr);
            }
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_GetBpw
*
* Function to set transfer bpw value.
*
* @param    uiCh [in]       : Value of channel to control
* @return   bpw value from register read value.
* Notes
*
***************************************************************************************************
*/

static uint32 GPSB_GetBpw
(
    uint32                              uiCh
)
{
    uint32  bpw;

    bpw = ((SAL_ReadReg((uint32)(gpsb[uiCh].dBase) + GPSB_MODE) >> 8UL) & 0x1FUL);

    return (bpw + 1UL);
}

/*
***************************************************************************************************
*                                          GPSB_SetMode
*
* Sets the GPSB operating mode.
*
* @param    uiCh [in]       : Value of channel to control
* @param    uiMode [in]     : Mode
* @return
* Notes
*
***************************************************************************************************
*/

void GPSB_SetMode
(
    uint32                              uiCh,
    uint32                              uiMode
)
{
    uint32  addr;
    uint32  reg;

    addr    = 0UL;
    reg     = 0UL;

    if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_MODE))
    {
        if((uiMode & GPSB_CPOL) != (uint32)NULL)
        {
            addr = (uint32)gpsb[(uiCh)].dBase + GPSB_MODE;
            reg = SAL_ReadReg(addr) | (BSP_BIT_16);
            SAL_WriteReg(reg, addr);
        }
        else
        {
            addr = gpsb[uiCh].dBase + GPSB_MODE;
            reg = SAL_ReadReg(addr) & (~BSP_BIT_16);
            SAL_WriteReg(reg, addr);
        }

        if((uiMode & GPSB_CPHA) != (uint32)NULL)
        {
            addr = (uint32)gpsb[(uiCh)].dBase + GPSB_MODE;
            reg = SAL_ReadReg(addr) | (BSP_BIT_18 | BSP_BIT_17);
            SAL_WriteReg(reg, addr);
        }
        else
        {
            addr = gpsb[uiCh].dBase + GPSB_MODE;
            reg = SAL_ReadReg(addr) & ~(BSP_BIT_18|BSP_BIT_17);
            SAL_WriteReg(reg, addr);
        }

        if((uiMode & GPSB_CS_HIGH) != (uint32)NULL)
        {
            addr = (uint32)gpsb[(uiCh)].dBase + GPSB_MODE;
            reg = SAL_ReadReg(addr) | (BSP_BIT_20 | BSP_BIT_19);
            SAL_WriteReg(reg, addr);
        }
        else
        {
            addr = gpsb[uiCh].dBase + GPSB_MODE;
            reg = SAL_ReadReg(addr) & ~(BSP_BIT_20 | BSP_BIT_19);
            SAL_WriteReg(reg, addr);
        }

        if((uiMode & GPSB_LSB_FIRST) != (uint32)NULL)
        {
            addr = (uint32)gpsb[(uiCh)].dBase + GPSB_MODE;
            reg = SAL_ReadReg(addr) | (BSP_BIT_07);
            SAL_WriteReg(reg, addr);
        }
        else
        {
            addr = gpsb[uiCh].dBase + GPSB_MODE;
            reg = SAL_ReadReg(addr) & (~BSP_BIT_07);
            SAL_WriteReg(reg, addr);
        }

        if((uiMode & GPSB_LOOP) != (uint32)NULL)
        {
            addr = (uint32)gpsb[(uiCh)].dBase + GPSB_MODE;
            reg = SAL_ReadReg(addr) | (BSP_BIT_06);
            SAL_WriteReg(reg, addr);
        }
        else
        {
            addr = gpsb[uiCh].dBase + GPSB_MODE;
            reg = SAL_ReadReg(addr) & (~BSP_BIT_06);
            SAL_WriteReg(reg, addr);
        }

        if((uiMode & GPSB_SLAVE) != (uint32)NULL)
        {
            addr = (uint32)gpsb[(uiCh)].dBase + GPSB_MODE;
            reg = SAL_ReadReg(addr) | (BSP_BIT_02);
            SAL_WriteReg(reg, addr);
        }
        else
        {
            addr = gpsb[uiCh].dBase + GPSB_MODE;
            reg = SAL_ReadReg(addr) & (~BSP_BIT_02);
            SAL_WriteReg(reg, addr);
        }

        GPSB_D("%s: ch %d GPSB MODE 0x%x\n", __func__, uiCh, SAL_ReadReg((uint32)(gpsb[uiCh].dBase + GPSB_MODE)));
    }

    return;
}

/*
***************************************************************************************************
*                                          GPSB_CsAlloc
*
* Configures the CS GPIO.
*
* @param    uiCh [in]       : Value of channel to be controlled
* @param    uiCs [in]       : CS GPIO index
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_CsAlloc
(
    uint32                              uiCh,
    uint32                              uiCs
)
{
#if 0
    SALRetCode_t    ret;
    sint32          gfb_cs;

    ret     = SAL_RET_SUCCESS;
    gfb_cs  = 0;

    /* Configure CS_GPIO as gpio function */
    if(uiCs > 0UL)
    {
        gfb_cs = (sint32)GPIO_ToNum(uiCs);

        if(gfb_cs == (sint32)SAL_RET_FAILED)
        {
            ret = SAL_RET_FAILED;
        }
        else
        {
            /* Configure CS_GPIO as GFB function and GPSB controls CS */
            ret = GPIO_Config((uint32)uiCs, (uint32)(GPIO_FUNC((uint32)6UL) | GPIO_OUTPUT));

            if(ret != SAL_RET_SUCCESS)
            {
                GPSB_E("%s : GPIO config fail. GPSB channel %d is closed. \n", __func__, uiCh);
                (void)GPSB_Close(uiCh);

                ret = SAL_RET_FAILED;
            }
        }
    }
    else
    {
    }

    return ret;
#else
    return SAL_RET_SUCCESS;
#endif
}

/*
***************************************************************************************************
*                                          GPSB_SetCs
*
* Function to set CS value to high or low.
*
* @param    iCs [in]        : CS GPIO index
* @param    uiEnable [in]   : Active or Deactive
* @param    uiCsHigh [in]   : Default high or low (active high or active low)
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

static SALRetCode_t GPSB_SetCs
(
    int32                               iCs,
    uint32                              uiEnable,
    uint32                              uiCsHigh
)
{
    SALRetCode_t    ret;
    uint32          enable;

    ret     = SAL_RET_SUCCESS;
    enable  = uiEnable;

    if(iCs < 0)
    {
        ret = SAL_RET_FAILED;
    }
    else
    {
        if(uiCsHigh != (uint32)FALSE)
        {
            (void)GPIO_Set((uint32)iCs, enable);
        }
        else
        {
            if(uiEnable > 0UL)
            {
                enable = (uint32)FALSE;
            }
            else
            {
                enable = (uint32)TRUE;
            }

            (void)GPIO_Set((uint32)iCs, enable);
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_CsInit
*
* Initializes CS GPIO to default config.
*
* @param    uiCh [in]       : Value of channel to be controlled
* @param    uiCs [in]       : CS GPIO index
* @param    uiCsHigh [in]   : default high or low
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_CsInit
(
    uint32                              uiCh,
    uint32                              uiCs,
    uint32                              uiCsHigh
)
{
    SALRetCode_t    ret;

    ret = SAL_RET_SUCCESS;

    /* Configure CS_GPIO as gpio function */
    if(uiCs < GPIO_GP_MAX)
    {
        ret = GPIO_Config((uint32)uiCs, (uint32)(GPIO_FUNC((uint32)0UL) | GPIO_OUTPUT));

        if(ret == SAL_RET_SUCCESS)
        {
            /* Initial state is deactivated state */
            ret = GPSB_SetCs((int32)uiCs, (uint32)FALSE, uiCsHigh);

            if(ret != SAL_RET_SUCCESS)
            {
                GPSB_D("%s: ch %d deactivating cs_gpios(%d) is failed\n", __func__, uiCh, uiCs);
				mcu_printf("%s: ch %d deactivating cs_gpios(%d) is failed\n", __func__, uiCh, uiCs);
            }
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_CsActivate
*
* Activates the CS GPIO.
*
* @param    uiCh [in]       : Value of channel to be controlled
* @param    uiCs [in]       : CS GPIO index
* @param    uiCsHigh        : Default High or Low
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_CsActivate
(
    uint32                              uiCh,
    uint32                              uiCs,
    uint32                              uiCsHigh
)
{
    SALRetCode_t    ret;

    ret = SAL_RET_SUCCESS;

    if(uiCs < GPIO_GP_MAX)
    {
        ret = GPSB_SetCs((int32)uiCs, (uint32)TRUE, uiCsHigh);

        if(ret != SAL_RET_SUCCESS)
        {
            GPSB_E("%s Fail. GPSB channel %d is closed.\n", __func__, uiCh);
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_CsDeactivate
*
* Deactivates the CS GPIO.
*
* @param    uiCh [in]       : Value of channel to control
* @param    uiCs [in]       : CS GPIO index
* @param    uiCsHigh [in]   : Default High or Low
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_CsDeactivate
(
    uint32                              uiCh,
    uint32                              uiCs,
    uint32                              uiCsHigh
)
{
    SALRetCode_t    ret;

    ret = SAL_RET_SUCCESS;

    if(uiCs < GPIO_GP_MAX)
    {
        ret = GPSB_SetCs((int32)uiCs, (uint32)FALSE, uiCsHigh);

        if(ret != SAL_RET_SUCCESS)
        {
            GPSB_E("%s Fail. GPSB channel %d is closed.\n", __func__, uiCh);
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_WaitRxFifoValid
*
* Function to check RX FIFO count is valid after TX data transfer.
*
* @param    uiCh [in]       : Value of channel to control
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

static SALRetCode_t GPSB_WaitRxFifoValid
(
    uint32                              uiCh
)
{
    uint32  cnt;
    SALRetCode_t ret;

    cnt = 0;
    ret = SAL_RET_SUCCESS;

    if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_STAT))
    {
        while(((SAL_ReadReg((uint32)(gpsb[uiCh].dBase + GPSB_STAT)) & BSP_BIT_00) == 0UL))
        {
            cnt++;

            if(cnt > GPSB_POLL_TIMEOUT)
            {
                GPSB_D("%s ch %d pio polling mode timeout err\n", __func__, uiCh);

                ret = SAL_RET_FAILED;
                break;
            }
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_FifoSyncXfer8
*
* Function to Write/Read data with 8 BPW.
*
* @param    uiCh [in]       : Value of channel to control
* @param    pTx [in]        : TX data buffer
* @param    pRx [out]       : RX data buffer
* @param    uiDataSize [in] : Write/Read data size
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

static SALRetCode_t GPSB_FifoSyncXfer8
(
    uint32                              uiCh,
    const uint8 *                       pTx,
    uint8 *                             pRx,
    uint32                              uiDataSize
)
{
    uint32          data_num;
    uint32          i;
    uint32          rx_dummy;
    const uint8 *   tx;
    uint8 *         rx;
    SALRetCode_t    ret;

    tx          = (const uint8 *)pTx;
    rx          = (uint8 *)pRx;
    data_num    = 0;
    rx_dummy       = 0;
    ret         = SAL_RET_SUCCESS;

    if(uiCh >= GPSB_CH_NUM)
    {
        GPSB_D("%s %d channel is wrong\n", __func__, uiCh);
        ret = SAL_RET_FAILED;
    }
    else
    {
        GPSB_Enable(uiCh);
        data_num = uiDataSize;

        for(i = 0 ; i < data_num ; i++)
        {
            /* Write data to TXFIFO */
            if(tx != (uint8 *)NULL_PTR)
            {
                SAL_WriteReg(tx[i],(uint32)(gpsb[uiCh].dBase + GPSB_PORT));
            }

            /* Wait until Read FIFO is valid */
            ret = GPSB_WaitRxFifoValid(uiCh);

            if(ret != SAL_RET_SUCCESS)
            {
                GPSB_D("%s ch %d wait rx fifo valid ret %d\n", __func__, uiCh, ret);
                break;
            }

            /* Read data from RX FIFO */
            rx_dummy = SAL_ReadReg((uint32)(gpsb[uiCh].dBase + GPSB_PORT));

            if(rx != (uint8 *)NULL_PTR)
            {
                rx[i] = (uint8)(rx_dummy & 0xFFUL);
            }
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_FifoSyncXfer16
*
* Function to Write/Read data with 16 BPW.
*
* @param    uiCh [in]       : Value of channel to control
* @param    pTx [in]        : TX data buffer
* @param    pRx [out]       : RX data buffer
* @param    uiDataSize [in] : Write/Read data size
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* @return
* Notes
*
***************************************************************************************************
*/

static SALRetCode_t GPSB_FifoSyncXfer16
(
    uint32                              uiCh,
    const uint8 *                       pTx,
    uint8 *                             pRx,
    uint32                              uiDataSize
)
{
    uint32          i;
    uint32          rx_dummy;
    const uint8 *   tx;
    uint8 *         rx;
    SALRetCode_t    ret;
    uint16          tx_data;

    tx          = pTx;
    rx          = pRx;
    rx_dummy    = 0;
    tx_data     = 0;
    ret         = SAL_RET_SUCCESS;

    if(uiCh >= GPSB_CH_NUM)
    {
        GPSB_D("%s %d channel is wrong\n", __func__, uiCh);
        ret = SAL_RET_FAILED;
    }
    else
    {
        if((uiDataSize % 2UL) != 0UL)
        {
            GPSB_D("%s ch %d data size(%d) is not alligned\n", __func__, uiCh, uiDataSize);
            ret = SAL_RET_FAILED;
        }
        else
        {
            GPSB_Enable(uiCh);

            for(i = 0 ; i < uiDataSize ; i=i+2)
            {
                /* Write data to TXFIFO */
                if(tx != NULL_PTR)
                {
                    tx_data = (uint16)tx[i];
                    tx_data |= (uint16)((tx[i+1UL] & 0xFFUL) << 8);

                    SAL_WriteReg(tx_data, (uint32)(gpsb[uiCh].dBase + GPSB_PORT));
                }

                /* Wait until Read FIFO is valid */
                ret = GPSB_WaitRxFifoValid(uiCh);

                if(ret != SAL_RET_SUCCESS)
                {
                    GPSB_D("%s ch %d wait rx fifo valid ret %d\n", __func__, uiCh, ret);
                    break;
                }

                /* Read data from RX FIFO */
                rx_dummy = SAL_ReadReg((uint32)(gpsb[uiCh].dBase + GPSB_PORT));

                if(rx != NULL_PTR)
                {
                    rx[i] = (uint8)(rx_dummy & 0xFFUL);
                    rx[i+1UL] = (uint8)((rx_dummy & 0xFF00UL) >> 8);
                }
            }
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_FifoSyncXfer32
*
* Function to Write/Read data with 32 BPW.
*
* @param    uiCh [in]       : Value of channel to control
* @param    pTx [in]        : TX data buffer
* @param    pRx [out]       : RX data buffer
* @param    uiDataSize [in] : Write/Read data size
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

static SALRetCode_t GPSB_FifoSyncXfer32
(
    uint32                              uiCh,
    const uint8 *                       pTx,
    uint8 *                             pRx,
    uint32                              uiDataSize
)
{
    uint32          i;
    uint32          rx_dummy;
    const uint8 *   tx;
    uint8 *         rx;
    uint32          tx_data;
    SALRetCode_t    ret;

    tx          = pTx;
    rx          = pRx;
    rx_dummy    = 0;
    tx_data     = 0;
    ret         = SAL_RET_SUCCESS;

    if(uiCh >= GPSB_CH_NUM)
    {
        GPSB_D("%s %d channel is wrong\n", __func__, uiCh);

        ret = SAL_RET_FAILED;
    }
    else
    {

        if((uiDataSize % 4UL) != 0UL)
        {
            GPSB_D("%s ch %d data size(%d) is not alligned\n", __func__, uiCh, uiDataSize);

            ret = SAL_RET_FAILED;
        }
        else
        {
            GPSB_Enable(uiCh);

            for(i = 0 ; i < uiDataSize ; i=i+4)
            {
                /* Write data to TXFIFO */
                if(tx != NULL_PTR)
                {
                    tx_data = tx[i];
                    tx_data |= (uint32)((tx[i+1UL] & 0xFFUL) << 8);
                    tx_data |= (uint32)((tx[i+2UL] & 0xFFUL) << 16);
                    tx_data |= (uint32)((tx[i+3UL] & 0xFFUL) << 24);
                    SAL_WriteReg(tx_data, (uint32)(gpsb[uiCh].dBase + GPSB_PORT));
                }
                else
                {
                    SAL_WriteReg(0, (uint32)(gpsb[uiCh].dBase + GPSB_PORT));
                }

                /* Wait until Read FIFO is valid */
                ret = GPSB_WaitRxFifoValid(uiCh);

                if(ret != SAL_RET_SUCCESS)
                {
                    GPSB_D("%s ch %d wait rx fifo valid ret %d\n", __func__, uiCh, ret);
                    break;
                }

                //delay1us(1);

                /* Read data from RX FIFO */
                rx_dummy   = SAL_ReadReg((uint32)(gpsb[uiCh].dBase + GPSB_PORT));

                if(rx != NULL_PTR)
                {
                    rx[i]     = (uint8)(rx_dummy & 0xFFUL);
                    rx[i+1UL] = (uint8)((rx_dummy & 0xFF00UL) >> 8);
                    rx[i+2UL] = (uint8)((rx_dummy & 0xFF0000UL) >> 16);
                    rx[i+3UL] = (uint8)((rx_dummy & 0xFF000000UL) >> 24);
                }
            }
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_FiFoAsyncXfer
*
* Function to Async transfer with FIFO(PIO) mode.
*
* @param    uiCh [in]       : Value of channel to control
* @param    pTx [in]        : TX data buffer
* @param    pRx [out]       : RX data buffer
* @param    uiDataSize [in] : Write/Read data size
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

static SALRetCode_t GPSB_FiFoAsyncXfer
(
    uint32                              uiCh,
    const uint32 *                      pTx,
    uint32 *                            pRx,
    uint32                              uiDataSize
)
{
    uint32  ret;
    uint32  i;
    SALRetCode_t ret2;

    ret = 0;
    ret2 = SAL_RET_SUCCESS;

    GPSB_D("%s: ch %d\n", __func__, uiCh);

    if((pTx == NULL_PTR) || (pRx == NULL_PTR))
    {
        ret2 = SAL_RET_FAILED;
    }
    else
    {

        gpsb[uiCh].dAsyncTxBuf      = pTx;
        gpsb[uiCh].dAsyncRxBuf      = pRx;
        gpsb[uiCh].dAsyncTxDataSize = uiDataSize;
        gpsb[uiCh].dAsyncRxDataSize = uiDataSize;

        /* Write data to FIFO */
        ret = GPSB_FifoWrite(uiCh, gpsb[uiCh].dAsyncTxBuf, gpsb[uiCh].dAsyncTxDataSize);

        if(gpsb[uiCh].dAsyncTxBuf != NULL_PTR)
        {
            for(i = 0 ; i < ret ; i++)
            {
                gpsb[uiCh].dAsyncTxBuf++;
            }
        }

        if(gpsb[uiCh].dAsyncTxDataSize > ret)
        {
            gpsb[uiCh].dAsyncTxDataSize -= ret;
        }

        /* Enable operation */
        GPSB_EnableIntr(uiCh);
        GPSB_Enable(uiCh);
    }

    return ret2;
}

/*
***************************************************************************************************
*                                          GPSB_DmaAsyncXfer
*
* Function to transfer data with dma mode.
*
* @param    uiCh [in]       : Value of channel to control
* @param    pTx [in]        : TX data buffer
* @param    pRx [out]       : RX data buffer
* @param    uiDataSize [in] : Write/Read data size
* @return
* Notes
*
***************************************************************************************************
*/

static SALRetCode_t GPSB_DmaAsyncXfer
(
    uint32                              uiCh,
    const uint32 *                      pTx,
    uint32 *                            pRx,
    uint32                              uiDataSize
)
{
    uint32  copy_length;
    uint32  bpw;
    uint32  addr;
    uint32  reg;
    SALRetCode_t ret;

    copy_length = 0;
    bpw         = 0;
    addr        = 0UL;
    reg         = 0UL;
    ret         = SAL_RET_SUCCESS;

    /* Check wrong GPSB channel number */
    if (uiCh >= GPSB_CH_NUM)
    {
        GPSB_D("%d channel is wrong\n", uiCh);

        ret = SAL_RET_FAILED;
    }
    else
    {
        if(gpsb[uiCh].dSupportDma != (uint32)TRUE)
        {
            GPSB_D("%s ch %d does not support dma transfer\n", __func__, uiCh);

            ret = SAL_RET_FAILED;
        }
        else
        {
            /*
             * For channels which is able to use a dedicated dma,
             * set byte endian mode according to bits per word.
             */
            bpw = GPSB_GetBpw(uiCh);

            if(bpw != 32UL)
            {
                addr = (uint32)gpsb[(uiCh)].dBase + GPSB_DMACTR;
                reg = SAL_ReadReg(addr) | (BSP_BIT_28);
                SAL_WriteReg(reg, addr);
            }
            else
            {
                /* When bits per word is equal to 32, disable half-word and byte */
                addr = gpsb[uiCh].dBase + GPSB_INTEN;
                reg = SAL_ReadReg(addr) & ~(BSP_BIT_24 | BSP_BIT_25 | BSP_BIT_26 | BSP_BIT_27);
                SAL_WriteReg(reg, addr);

                addr = gpsb[uiCh].dBase + GPSB_DMACTR;
                reg = SAL_ReadReg(addr) & (~BSP_BIT_28);
                SAL_WriteReg(reg, addr);

            }

            /* Clear packet counter (CH 0-2) */
            addr = (uint32)gpsb[(uiCh)].dBase + GPSB_DMACTR;
            reg = SAL_ReadReg(addr) | (BSP_BIT_02);
            SAL_WriteReg(reg, addr);

            addr = gpsb[uiCh].dBase + GPSB_DMACTR;
            reg = SAL_ReadReg(addr) & (~BSP_BIT_02);
            SAL_WriteReg(reg, addr);

            if(uiDataSize > gpsb[uiCh].dTxDma.dbSize)
            {
                copy_length = gpsb[uiCh].dTxDma.dbSize;
            }
            else
            {
                copy_length = uiDataSize;
            }

            if(pTx != NULL_PTR)
            {
                (void)SAL_MemCopy(gpsb[uiCh].dTxDma.dbAddr, pTx, copy_length);
            }

            /* Set DMA TXBASE and RXBASE */
            (void)GPSB_DmaSetAddr(uiCh, gpsb[uiCh].dTxDma.dbAddr, gpsb[uiCh].dRxDma.dbAddr);

            /* Set Packet size and count */
            SAL_WriteReg((uint32)((copy_length & 0x1FFFUL) << 0UL), (uint32)(gpsb[uiCh].dBase + GPSB_PACKET));

            gpsb[uiCh].dAsyncTxBuf      = pTx;
            gpsb[uiCh].dAsyncRxBuf      = pRx;
            gpsb[uiCh].dAsyncTxDataSize = uiDataSize;
            gpsb[uiCh].dAsyncRxDataSize = 0;

            /* Enable dma operation */
            GPSB_DmaStart(uiCh);
            GPSB_Enable(uiCh);

            ret = SAL_RET_SUCCESS;
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_AsyncXfer
*
* Function to transfer data. this function can be called from application.
*
* @param    uiCh [in]       : Value of channel to be controlled
* @param    pTx [in]        : TX data buffer
* @param    pRx [out]       : RX data buffer
* @param    uiDataSize [in] : Write/Read data size
* @param    uiXferMode [in] : Transfer mode (DMA/PIO , Interrupt/Non-Interrupt)
* @return   SAl_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/
SALRetCode_t GPSB_AsyncXfer
(
    uint32                              uiCh,
    const uint32 *                      pTx,
    uint32 *                            pRx,
    uint32                              uiDataSize,
    uint32                              uiXferMode
)
{
    SALRetCode_t    ret;
    uint32          bpw;
    uint32          word_size;
    uint32          addr;
    uint32          reg;

    ret         = SAL_RET_SUCCESS;
    bpw         = 0;
    word_size   = 0;
    addr        = 0UL;
    reg         = 0UL;

    if (uiCh >= GPSB_CH_NUM)
    {
        GPSB_D("%d channel is wrong\n", uiCh);

        ret = SAL_RET_FAILED;
    }
    else
    {
        if(gpsb[uiCh].dState != GPSB_XFER_STATE_IDLE)
        {
            GPSB_D("%s: ch %d is not in idle state : %d\n", __func__, uiCh, gpsb[uiCh].dState);
			mcu_printf("%s: ch %d is not in idle state : %d\n", __func__, uiCh, gpsb[uiCh].dState);

            if(gpsb[uiCh].dState != GPSB_XFER_STATE_IDLE)
            {
                ret = SAL_RET_FAILED;
            }
        }

        if(ret == SAL_RET_SUCCESS)
        {
            /* Check data length and bpw */
            if(uiDataSize == 0UL)
            {
                GPSB_D("%s: ch %d data size is zero\n", __func__, uiCh);
				mcu_printf("%s: ch %d data size is zero\n", __func__, uiCh);

                ret = SAL_RET_FAILED;
            }
            else
            {
                bpw = GPSB_GetBpw(uiCh);

                if(bpw <= 8UL)
                {
                    word_size = 1UL;
                }
                else if(bpw <= 16UL)
                {
                    word_size = 2UL;
                }
                else
                {
                    word_size = 4UL;
                }

                if((uiDataSize % word_size) != 0UL)
                {
                    GPSB_D("%s: ch %d data size(%d) is not aligned by word size(%d)\n",
                            __func__, uiCh, uiDataSize, word_size);
					mcu_printf("%s: ch %d data size(%d) is not aligned by word size(%d)\n",
                            __func__, uiCh, uiDataSize, word_size);

                    ret = SAL_RET_FAILED;
                }
                else
                {
                    /*
                     * Set GPSB CTF(Continuous Transfer mode) according to the flag.
                     * In case of transfer without CTF mode, you should configure
                     * GPSB PCFG FRM settings by using tcc_GPSB_master_alloc_cs() before
                     * transfer.
                     * In case of transfer with CTF mode, you can control CS as GPIO
                     * or assign CS to GPSB FRM.
                     */
                    if((uiXferMode & GPSB_XFER_MODE_WITHOUT_CTF) != 0UL)
                    {
                        addr = gpsb[uiCh].dBase + GPSB_MODE;
                        reg = SAL_ReadReg(addr) & (~BSP_BIT_04);
                        SAL_WriteReg(reg, addr);
                    }
                    else
                    {
                        addr = (uint32)gpsb[(uiCh)].dBase + GPSB_MODE;
                        reg = SAL_ReadReg(addr) | (BSP_BIT_04);
                        SAL_WriteReg(reg, addr);
                    }

                    /* Start transfer according to xfer mode */
                    if((uiXferMode & GPSB_XFER_MODE_WITH_INTERRUPT) != 0UL)
                    {
                        /* w/ interrupt mode (support non-bloning mode only) */

                        GPSB_SetXferState(uiCh, GPSB_XFER_STATE_RUNNING);

                        if((uiXferMode & GPSB_XFER_MODE_DMA) != 0UL)
                        {
                            /* DMA mode */
                            ret = GPSB_DmaAsyncXfer(uiCh, pTx, pRx, uiDataSize);
                        }
                        else
                        {
                            /* Non-DMA mode */
                            ret = GPSB_FiFoAsyncXfer(uiCh, pTx, pRx, uiDataSize);
                        }

                    }
                    else
                    {
                        GPSB_D("%s: ch %d unsupported transfer mode 0x%x\n", __func__, uiCh, uiXferMode);
						mcu_printf("%s: ch %d unsupported transfer mode 0x%x\n", __func__, uiCh, uiXferMode);

                        ret = SAL_RET_FAILED;
                    }
                }
            }
        }
    }

    return ret;

}
/*
***************************************************************************************************
*                                          GPSB_Xfer
*
* Transmits data.
*
* @param    uiCh [in]       : Value of channel to be controlled
* @param    pTx [in]        : TX data buffer
* @param    pRx [out]       : RX data buffer
* @param    uiDataSize [in] : Write/Read data size
* @param    uiXferMode [in] : Transfer mode (DMA/PIO , Interrupt/Non-Interrupt)
* @return   SAl_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_Xfer
(
    uint32                              uiCh,
    const uint8 *                       pTx,
    uint8 *                             pRx,
    uint32                              uiDataSize,
    uint32                              uiXferMode
)
{
    SALRetCode_t    ret;
    uint32          bpw;
    uint32          word_size;
    uint32          addr;
    uint32          reg;

    ret         = SAL_RET_SUCCESS;
    bpw         = 0;
    word_size   = 0;
    addr        = 0UL;
    reg         = 0UL;

    if (uiCh >= GPSB_CH_NUM)
    {
        GPSB_D("%d channel is wrong\n", uiCh);

        ret = SAL_RET_FAILED;
    }
    else
    {
        if(gpsb[uiCh].dState != GPSB_XFER_STATE_IDLE)
        {
            GPSB_D("%s: ch %d is not in idle state : %d\n", __func__, uiCh, gpsb[uiCh].dState);

            if(gpsb[uiCh].dState != GPSB_XFER_STATE_IDLE)
            {
                ret = SAL_RET_FAILED;
				mcu_printf("%s error. gpsb channel state:\t GPSB_XFER_STATE_IDLE\n", __func__);
            }
        }

        if(ret == SAL_RET_SUCCESS)
        {
            /* Check data length and bpw */
            if(uiDataSize == 0UL)
            {
                GPSB_D("%s: ch %d data size is zero\n", __func__, uiCh);

                ret = SAL_RET_FAILED;
				mcu_printf("%s error. uiDataSize \n", __func__);
            }
            else
            {

                bpw = GPSB_GetBpw(uiCh);

                if(bpw <= 8UL)
                {
                    word_size = 1UL;
                }
                else if(bpw <= 16UL)
                {
                    word_size = 2UL;
                }
                else
                {
                    word_size = 4UL;
                }

                if((uiDataSize % word_size) != 0UL)
                {
                    GPSB_D("%s: ch %d data size(%d) is not aligned by word size(%d)\n",
                            __func__, uiCh, uiDataSize, word_size);

                    ret = SAL_RET_FAILED;
					mcu_printf("%s error. bpw error \n", __func__);
                }
                else
                {
                    /*
                     * Set GPSB CTF(Continuous Transfer mode) according to the flag.
                     * In case of transfer without CTF mode, you should configure
                     * GPSB PCFG FRM settings by using tcc_GPSB_master_alloc_cs() before
                     * transfer.
                     * In case of transfer with CTF mode, you can control CS as GPIO
                     * or assign CS to GPSB FRM.
                     */
                    if((uiXferMode & GPSB_XFER_MODE_WITHOUT_CTF) != 0UL)
                    {
                        addr = gpsb[uiCh].dBase + GPSB_MODE;
                        reg = SAL_ReadReg(addr) & (~BSP_BIT_04);
                        SAL_WriteReg(reg, addr);
                    }
                    else
                    {
                        addr = (uint32)gpsb[(uiCh)].dBase + GPSB_MODE;
                        reg  = SAL_ReadReg(addr) | (BSP_BIT_04);
                        SAL_WriteReg(reg, addr);
                    }

                    if((uiXferMode & GPSB_XFER_MODE_WITHOUT_INTERRUPT) != 0UL)
                    {
                        GPSB_SetXferState(uiCh, GPSB_XFER_STATE_RUNNING);
                        /* w/o interrupt mode (support blocking mode only) */
                        if(bpw <= 8UL)
                        {
                            ret = GPSB_FifoSyncXfer8(uiCh, pTx, pRx, uiDataSize);
                        }
                        else if(bpw <= 16UL)
                        {
                            ret = GPSB_FifoSyncXfer16(uiCh, pTx, pRx, uiDataSize);
                        }
                        else
                        {
                            ret = GPSB_FifoSyncXfer32(uiCh, pTx, pRx, uiDataSize);
                        }

                        if(ret == SAL_RET_SUCCESS)
                        {
                            GPSB_Disable(uiCh);
                            GPSB_SetXferState(uiCh, GPSB_XFER_STATE_IDLE);
                        }
                    }
                    else
                    {
                        GPSB_D("%s: ch %d unsupported transfer mode 0x%x\n", __func__, uiCh, uiXferMode);

                        ret = SAL_RET_FAILED;
						mcu_printf("%s error. unsupported transfer mode \n", __func__);
                    }
                }
            }
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_HwInit
*
* Function to set default hw settings.
*
* @param    uiCh [in]       : Value of channel to control
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_HwInit
(
    uint32                              uiCh
)
{
    sint32  ret;

    ret = 0;

    /* Enable iobus */
    ret = CLOCK_SetIobusPwdn((gpsb[uiCh].dIobusName), FALSE);

    if(ret != 0)
    {
        GPSB_D("%s: ch %d failed to enable iobus pwdn\n", __func__, uiCh);
    }
    else
    {
        /* Disable operation */
        GPSB_Disable(uiCh);

        /* Set GPSB DIVLDV */
        if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_MODE))
        {
            GPSB_BitCSet(gpsb[uiCh].dBase + GPSB_MODE, (0xFFUL << 24UL), ((GPSB_DEF_DIVLDV & 0xFFUL) << 24UL));

            /* Set GPSB MODE register */
            GPSB_BitCSet(gpsb[uiCh].dBase + GPSB_MODE,
                        ((BSP_BIT_02 | BSP_BIT_01) | BSP_BIT_00),  /* Set GPSB master */
                        (BSP_BIT_04));                             /* Set CTF mode */
        }

        if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_INTEN))
        {
            /* Set interrup for handle error status (for ROR, WUR, RUR, WOR) */
#if 0   // Disable Error interrupt
            GPSB_BitCSet(gpsb[uiCh].dBase + GPSB_INTEN, (0x3FFUL),
                        (BSP_BIT_05 | BSP_BIT_06 | BSP_BIT_07 | BSP_BIT_08));
#endif

            /* Set GPSB FIFO Theshold for generating interrupt request */
            GPSB_BitCSet(gpsb[uiCh].dBase + GPSB_INTEN, (0x7UL << 20UL), (GPSB_CFGWTH << 20UL));
            GPSB_BitCSet(gpsb[uiCh].dBase + GPSB_INTEN, (0x7UL << 16UL), (GPSB_CFGRTH << 16UL));
        }
    }

}

/*
***************************************************************************************************
*                                          GPSB_Open
*
* Function to initialize GPSB channel.
*
* @param    uiCh [in]           : Value of channel to control
* @param    OpenParam [in]      : Parameter of GPSB configuration
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_Open
(
    uint32                              uiCh,
    GPSBOpenParam_t                     OpenParam
)
{
    SALRetCode_t    ret;

    ret = SAL_RET_SUCCESS;

    /* Check wrong GPSB channel number */
    if(uiCh >= GPSB_CH_NUM)
    {
        GPSB_D("%s: %d channel is wrong\n", __func__, uiCh);

        ret = SAL_RET_FAILED;
    }
    else
    {
        if(gpsb[uiCh].dState != GPSB_XFER_STATE_DISABLED)
        {
            GPSB_D("%s: %d channel is already opened , state : %d\n", __func__, uiCh, gpsb[uiCh].dState);

            ret = SAL_RET_FAILED;
        }
        else
        {
            gpsb[uiCh].dState = GPSB_XFER_STATE_IDLE;

            /* Initialize the gpsb structure */
            gpsb[uiCh].dPort                    = OpenParam.uiPort;
            gpsb[uiCh].dComplete.xcCallback     = OpenParam.fbCallback;
            gpsb[uiCh].dComplete.xcArg          = OpenParam.pArg;
            gpsb[uiCh].dSupportDma              = (uint32)FALSE;
            gpsb[uiCh].dTxDma.dbAddr            = NULL;
            gpsb[uiCh].dTxDma.dbSize            = 0;

            if((OpenParam.uiDmaBufSize != (uint32)NULL) && ((OpenParam.pDmaAddrTx != (uint32 *)NULL_PTR) || (OpenParam.pDmaAddrRx != (uint32 *)NULL_PTR)))
            {
                gpsb[uiCh].dSupportDma = (uint32)TRUE;

                if(OpenParam.pDmaAddrTx != (uint32 *)NULL_PTR)
                {
                    gpsb[uiCh].dTxDma.dbAddr = OpenParam.pDmaAddrTx;
                    gpsb[uiCh].dTxDma.dbSize = OpenParam.uiDmaBufSize;
                    GPSB_D("%s: tx_dma.paddr: 0x%08X      / size: %d\n",
                            __func__, gpsb[uiCh].dTxDma.dbAddr,
                            gpsb[uiCh].dTxDma.dbSize);
                }

                if(OpenParam.pDmaAddrRx != NULL_PTR)
                {
                    gpsb[uiCh].dRxDma.dbAddr = OpenParam.pDmaAddrRx;
                    gpsb[uiCh].dRxDma.dbSize = OpenParam.uiDmaBufSize;
                    GPSB_D("%s: rx_dma.Addr: 0x%08X\n",
                            __func__, gpsb[uiCh].dRxDma.dbAddr,
                            gpsb[uiCh].dRxDma.dbSize);
                }
            }

            /* Reset GPSB block */
            ret = GPSB_Reset(uiCh);

            if(ret != SAL_RET_SUCCESS)
            {
                GPSB_D("%s: ch %d failed to reset gpsb ret %d\n", __func__, uiCh, ret);
            }
            else
            {
                /* Set port and gpio configuration */
                ret = GPSB_SetPort(uiCh, gpsb[uiCh].dPort);

                if(ret != SAL_RET_SUCCESS)
                {
                    GPSB_D("%s: ch %d gpsb set port failed ret %d\n", __func__, uiCh, ret);
                }
                else
                {
                    /* Stop dma operation */
                    GPSB_DmaStop(uiCh);

                    /* Initialize GPSB for GPSB master*/
                    GPSB_HwInit(uiCh);

                    /* Set gpsb init and mode state */
                    gpsb[uiCh].dIsSlave = (uint32)FALSE;

                    GPSB_SetXferState(uiCh, GPSB_XFER_STATE_IDLE);
                }
            }
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_Close
*
* De-initializes GPSB channel.
*
* @param    uiCh [in]       : Value of channel to be controlled
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_Close
(
    uint32                              uiCh
)
{
    sint32  err;
    SALRetCode_t ret;

    err     = 0;
    ret     = SAL_RET_SUCCESS;

    /* Check wrong GPSB channel number */
    if(uiCh >= GPSB_CH_NUM)
    {
        GPSB_D("%s %d channel is wrong\n", __func__, uiCh);

        ret = SAL_RET_FAILED;
    }
    else
    {
        (void)SAL_CoreCriticalEnter();

        if(gpsb[uiCh].dState == GPSB_XFER_STATE_DISABLED)
        {
            (void)SAL_CoreCriticalExit();
            GPSB_D("%s %d channel is already closed\n", __func__, uiCh);

            ret = SAL_RET_SUCCESS;
        }
        else
        {
            gpsb[uiCh].dState = GPSB_XFER_STATE_DISABLED;
            (void)SAL_CoreCriticalExit();

            /* Stop the operation */
            GPSB_DmaStop(uiCh);
            GPSB_DisableIntr(uiCh);
            GPSB_Disable(uiCh);

            /* Disable iobus */
            err = CLOCK_SetIobusPwdn(gpsb[uiCh].dIobusName, TRUE);
		    //err = 0;
            if(err != NULL)
            {
                GPSB_D("%s ch %d failed to disable iobus pwdn\n", __func__, uiCh);

                ret = SAL_RET_FAILED;
            }
            else
            {
                gpsb[uiCh].dPort = NULL;
#if 0
                if(uiCh < (GPSB_CH_NUM-1UL))
                {
                    cbit = (uint32)GPSB_PORT_SEL_MASK << (uiCh * 8UL);
                }
                else
                {
                    cbit = (uint32)GPSB_PORT_SEL_MASK << ((uiCh-4UL) * 8UL);
                }

                {
                    addr = GPSB_PCFG_BASE;
                    reg = SAL_ReadReg(addr) & (~cbit);
                    SAL_WriteReg(reg, addr);
                }
#endif
                GPSB_ClearPortCFG(uiCh);

                GPSB_SetXferState(uiCh, GPSB_XFER_STATE_DISABLED);

                ret = SAL_RET_SUCCESS;
            }
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_CheckIsrStatus
*
* Function to check isr status register value.
*
* @param    uiCh [in]       : Value of channel to control
* @param    status [in]     : Value of status register
* @return
* Notes
*
***************************************************************************************************
*/

static uint32 GPSB_CheckIsrStatus
(
    uint32 uiCh,
    uint32 status
)
{
    uint32 event;

    event = 0;

    GPSB_D("%s: ch %d error status occur status 0x%08x\n", __func__, uiCh, status);

    if((status & BSP_BIT_05) != 0UL)
    {
        event |= (uint32)GPSB_EVENT_ERR_ROR;
        GPSB_D("%s: ch %d read fifo over-run error\n", __func__, uiCh);
    }

    if((status & BSP_BIT_06) != 0UL)
    {
        event |= (uint32)GPSB_EVENT_ERR_WUR;
        GPSB_D("%s: ch %d write fifo under-run error\n", __func__, uiCh);
    }

    if((status & BSP_BIT_07) != 0UL)
    {
        event |= (uint32)GPSB_EVENT_ERR_RUR;
        GPSB_D("%s: ch %d read fifo under-run error\n", __func__, uiCh);
    }

    if((status & BSP_BIT_08) != 0UL)
    {
        event |= (uint32)GPSB_EVENT_ERR_WOR;
        GPSB_D("%s: ch %d write fifo over-run error\n", __func__, uiCh);
    }

    return event;
}

/*
***************************************************************************************************
*                                          GPSB_IsrDone
*
* Function to process isr complete.
*
* @param    uiCh [in]       : Value of channel to control
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_IsrDone(uint32 uiCh)
{
    GPSB_Disable(uiCh);
    GPSB_DmaStop(uiCh);
    GPSB_SetXferState(uiCh, GPSB_XFER_STATE_IDLE);
}

/*
***************************************************************************************************
*                                          GPSB_IsrError
*
* Function to process isr error.
*
* @param    uiCh [in]       : Value of channel to control
* @param    uiStatus [in]   : Value of status register.
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_IsrError(uint32 uiCh, uint32 uiStatus)
{
    uint32 event;
    uint32 addr;
    uint32 reg;

    event = GPSB_CheckIsrStatus(uiCh, uiStatus);
    addr = 0UL;
    reg  = 0UL;

    GPSB_IsrDone(uiCh);

    if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_STAT))
    {
        /* Clear error status */
        addr = (uint32)gpsb[(uiCh)].dBase + GPSB_STAT;
        reg  = SAL_ReadReg(addr) | (BSP_BIT_05 | BSP_BIT_06 | BSP_BIT_07 | BSP_BIT_08);
        SAL_WriteReg(reg, addr);
    }

    /* Notify error status */
    if(gpsb[uiCh].dComplete.xcCallback != NULL_PTR)
    {
        gpsb[uiCh].dComplete.xcCallback(uiCh, event, gpsb[uiCh].dComplete.xcArg);
    }
}

/*
***************************************************************************************************
*                                          GPSB_IsrAsyncFifo
*
* Function to process Async fifo transfer.
*
* @param    uiCh [in]       : Value of channel to control
* @return
* Notes
*
***************************************************************************************************
*/

static void GPSB_IsrAsyncFifo
(
    uint32                              uiCh
)
{
    uint32 ret;
    uint32 i;
    uint32 event;

    GPSB_D("%s: ch %d async pio transfer\n", __func__, uiCh);

    ret = GPSB_FifoRead(uiCh, gpsb[uiCh].dAsyncRxBuf, gpsb[uiCh].dAsyncRxDataSize);

    if(gpsb[uiCh].dAsyncRxBuf != NULL_PTR)
    {
        for(i = 0 ; i < ret ; i++)
        {
            gpsb[uiCh].dAsyncRxBuf++;
        }
    }

    if(gpsb[uiCh].dAsyncRxDataSize >= ret)
    {
        gpsb[uiCh].dAsyncRxDataSize -= ret;
    }

    if(gpsb[uiCh].dAsyncTxDataSize > 0UL)
    {
        ret = GPSB_FifoWrite(uiCh, gpsb[uiCh].dAsyncTxBuf, gpsb[uiCh].dAsyncTxDataSize);

        if(gpsb[uiCh].dAsyncTxBuf != NULL_PTR)
        {
            for(i = 0 ; i < ret ; i++)
            {
                gpsb[uiCh].dAsyncTxBuf++;
            }
        }

        if(gpsb[uiCh].dAsyncTxDataSize >= ret)
        {
            gpsb[uiCh].dAsyncTxDataSize -= ret;
        }
    }

    if(gpsb[uiCh].dAsyncRxDataSize <= 0UL)
    {
        GPSB_D("%s: ch %d complete async pio transfer\n", __func__, uiCh);

        gpsb[uiCh].dAsyncTxBuf      = NULL;
        gpsb[uiCh].dAsyncRxBuf      = NULL;
        gpsb[uiCh].dAsyncTxDataSize = 0;

        GPSB_DisableIntr(uiCh);
        GPSB_Disable(uiCh);
        gpsb[uiCh].dState = GPSB_XFER_STATE_IDLE;

        /* Notify the completion of transfer */
        event = GPSB_EVENT_COMPLETE;

        if(gpsb[uiCh].dComplete.xcCallback != NULL_PTR)
        {
            gpsb[uiCh].dComplete.xcCallback(uiCh, event, gpsb[uiCh].dComplete.xcArg);
        }
    }
}

/*
 ***************************************************************************************************
*                                          GPSB_Isr
*
* Function to process GPSB interrupt.
*
* @param    uiCh [in]       : Value of channel to control
* @return
* Notes
*
***************************************************************************************************
*/

void GPSB_Isr
(
    uint32                              uiCh
)
{
    uint32  dmaicr;
    uint32  status;
    uint32  event;
    uint32  copy_length;
    uint32  data_size;
    uint32  i;
    const void *  buffaddr;

    buffaddr    = (void *)gpsb[uiCh].dRxDma.dbAddr;
    dmaicr      = 0;
    status      = 0;
    event       = 0;
    copy_length = 0;
    data_size   = 0;

    if((GPSB_IsMaster(uiCh)) > 0UL)
    {
        /* Check error status */
        if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_STAT))
        {
            status = SAL_ReadReg((uint32)(gpsb[uiCh].dBase + GPSB_STAT));
        }
#if 0
        if((status & (0xFUL << 5UL)) != 0UL)
        {
            GPSB_IsrError(uiCh, status);
        }
        else
#endif
        {
            if((status & BSP_BIT_00) != 0UL)
            {
                GPSB_IsrAsyncFifo(uiCh);
            }

            if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_DMAICR))
            {
                dmaicr = SAL_ReadReg((uint32)(gpsb[uiCh].dBase + GPSB_DMAICR));
            }

            if((dmaicr & BSP_BIT_29) != 0UL)
            {
                GPSB_D("%s: ch %d dma done interrupt\n", __func__, uiCh);

                if(gpsb[uiCh].dBase < (UINT_MAX_VALUE - GPSB_DMAICR))
                {
                    SAL_WriteReg(dmaicr, (uint32)(gpsb[uiCh].dBase + GPSB_DMAICR));
                }

                data_size = gpsb[uiCh].dAsyncTxDataSize;

                if(data_size > gpsb[uiCh].dTxDma.dbSize)
                {
                    copy_length = gpsb[uiCh].dTxDma.dbSize;
                }
                else
                {
                    copy_length = data_size;
                }

                if(gpsb[uiCh].dAsyncRxBuf != NULL_PTR)
                {
                    //(void)SAL_MemCopy(gpsb[uiCh].dAsyncRxBuf, (void *)(gpsb[uiCh].dRxDma.dbAddr), copy_length);
                    (void)SAL_MemCopy(gpsb[uiCh].dAsyncRxBuf, buffaddr, copy_length);
                }


                if(gpsb[uiCh].dAsyncTxDataSize >= copy_length)
                {
                    gpsb[uiCh].dAsyncTxDataSize -= copy_length;
                }

                for(i = 0 ; i < copy_length ; i++)
                {
                    gpsb[uiCh].dAsyncTxBuf++;
                    gpsb[uiCh].dAsyncRxBuf++;
                }

                GPSB_D("%s: ch %d xfer in this time %d remainder %d\n",
                        __func__, uiCh, copy_length, gpsb[uiCh].dAsyncTxDataSize);

                if(gpsb[uiCh].dAsyncTxDataSize != 0UL)
                {
                    data_size = gpsb[uiCh].dAsyncTxDataSize;

                    if(data_size > gpsb[uiCh].dTxDma.dbSize)
                    {
                        copy_length = gpsb[uiCh].dTxDma.dbSize;
                    }
                    else
                    {
                        copy_length = data_size;
                    }

                    if(gpsb[uiCh].dAsyncTxBuf  != NULL_PTR)
                    {
                        (void)SAL_MemCopy((void *)(gpsb[uiCh].dTxDma.dbAddr), gpsb[uiCh].dAsyncTxBuf, copy_length);
                    }

                    /* Set Packet size and count */
                    SAL_WriteReg(((copy_length & 0x1FFFUL) << 0UL), (uint32)(gpsb[uiCh].dBase + GPSB_PACKET));

                    /* Re-start DMA for transferring remainder */
                    GPSB_DmaStart(uiCh);

                }
                else
                {
                    gpsb[uiCh].dAsyncTxBuf      = NULL;
                    gpsb[uiCh].dAsyncRxBuf      = NULL;
                    gpsb[uiCh].dAsyncTxDataSize = 0;
                    gpsb[uiCh].dAsyncRxDataSize = 0;

                    GPSB_IsrDone(uiCh);

                    /* Notify the completion of transfer */
                    event = GPSB_EVENT_COMPLETE;

                    if(gpsb[uiCh].dComplete.xcCallback != NULL_PTR)
                    {
                        gpsb[uiCh].dComplete.xcCallback(uiCh, event, gpsb[uiCh].dComplete.xcArg);
                    }
                }
            }
        }
    }
}

/*
***************************************************************************************************
*                                          GPSB_SetLbCfg
*
* Function to set channel to enable loopback.
*
* @param    uiMstCh [in]    : Master Channel index
* @param    uiLoopCh [in]   : Loopback Channel index
* @param    uiEnable [in]   : Loopback enable
* @return   SAL_RET_SUCCESS or SAL_RET_FAILED
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_SetLbCfg
(
    uint32                              uiMstCh,
    uint32                              uiLoopCh,
    uint32                              uiEnable
)
{
    uint32  reg;
    SALRetCode_t ret;

    reg = 0UL;
    ret = SAL_RET_SUCCESS;

    if((uiMstCh >= GPSB_CH_NUM) || (uiLoopCh >= GPSB_CH_NUM))
    {
        GPSB_D("Invaild Channel value. \n");

        ret = SAL_RET_FAILED;
    }
    else
    {
        if(gpsb[0].dCfgAddr < (UINT_MAX_VALUE - GPSB_LB_CFG))
        {
            reg = SAL_ReadReg((uint32)(gpsb[0].dCfgAddr + GPSB_LB_CFG));

            if(uiEnable < 2UL)
            {
                reg |= (((uiEnable + ((uiMstCh & 0x7UL) << 1UL))) << uiLoopCh) * 4UL;
            }

            SAL_WriteReg(reg, (uint32)(gpsb[0].dCfgAddr + (uint32)GPSB_LB_CFG));

            GPSB_D("GPSB LB_CFG : %x\n", reg);
        }
    }

    return ret;
}

/*
***************************************************************************************************
*                                          GPSB_ClearLbCfg
*
* Function to unset channel to disable loopback.
*
* @return   SAL_RET_SUCCESS
* Notes
*
***************************************************************************************************
*/

SALRetCode_t GPSB_ClearLbCfg
(
    void
)
{
    if(gpsb[0].dCfgAddr < (UINT_MAX_VALUE - GPSB_LB_CFG))
    {
        SAL_WriteReg(0x0UL , (uint32)(gpsb[0].dCfgAddr + GPSB_LB_CFG));

        GPSB_D("Done.Clear LB_CFG : %x \n", SAL_ReadReg((uint32)(gpsb[0].dCfgAddr + GPSB_LB_CFG)));
    }

    return SAL_RET_SUCCESS;
}


/*
***************************************************************************************************
*                                          GPSB_Init
*
* Registers the GPSB interrupt handler functions and enables the GPSB interrupts.
*
* @return
* Notes
*
***************************************************************************************************
*/

void GPSB_Init
(
    void
)
{
    GPSB_TargetInit();

    for(uint8 channel = 0; channel < GPSB_CH_NUM; channel++)
    {
        GPSB_Reset(channel);
    }

    return;
}

/*
***************************************************************************************************
*                                          GPSB_Deinit
*
* Disables all the GPSB interrupts.
*
* @return
* Notes
*
***************************************************************************************************
*/

void GPSB_Deinit(void)
{
    GPSB_TargetDeinit();
    return;
}


