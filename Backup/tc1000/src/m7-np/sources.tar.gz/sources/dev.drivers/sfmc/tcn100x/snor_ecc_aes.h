/*
***************************************************************************************************
*
*   FileName : snor_ecc_aes.h
*
*   Copyright (c) Telechips Inc.
*
*   Description :
*
*
***************************************************************************************************
*
*   TCC Version 1.0
*
*   This source code contains confidential information of Telechips.
*
*   Any unauthorized use without a written permission of Telechips including not limited to
*   re-distribution in source or binary form is strictly prohibited.
*
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty of
*   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
*   or other third party intellectual property right. No warranty is made, express or implied,
*   regarding the information's accuracy,completeness, or performance.
*
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
*   Telechips and Company.
*   This source code is provided "AS IS" and nothing contained in this source code shall constitute
*   any express or implied warranty of any kind, including without limitation, any warranty
*   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
*   copyright or other third party intellectual property right. No warranty is made, express or
*   implied, regarding the information's accuracy, completeness, or performance.
*   In no event shall Telechips be liable for any claim, damages or other liability arising from,
*   out of or in connection with this source code or the use in the source code.
*   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
*   between Telechips and Company.
*
***************************************************************************************************
*/

#ifndef SNOR_ECC_AES_H
#define SNOR_ECC_AES_H

#define SFMC_ECCAES_ADDR(DRVIDX)                ((0x45501000u) + (((DRVIDX) * 0x100000u)))

#define SFMC_IDENTIFIER(DRVIDX)                 (SFMC_ECCAES_ADDR(DRVIDX) + 0x0000u)  //R
#define SFMC_VERSION(DRVIDX)                    (SFMC_ECCAES_ADDR(DRVIDX) + 0x0004u)  //R

#define SFMC_AUTO_ECC_CFG(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX) + 0x0020u)
#define SFMC_AUTO_ECC_BASE_ADDR(DRVIDX)         (SFMC_ECCAES_ADDR(DRVIDX) + 0x0024u)
#define SFMC_AUTO_ECC_FAULT_INJ_DATA0(DRVIDX)   (SFMC_ECCAES_ADDR(DRVIDX) + 0x0028u)
#define SFMC_AUTO_ECC_FAULT_INJ_DATA1(DRVIDX)   (SFMC_ECCAES_ADDR(DRVIDX) + 0x002cu)
#define SFMC_AUTO_ECC_FAULT_INJ_ECC(DRVIDX)     (SFMC_ECCAES_ADDR(DRVIDX) + 0x0030u)
/*
REGION#_KEY_SEL
31 : KEY_ENABLE ; AES region key enable
0 :  KEY_SEL ;  0 - HW key, 1 - SW key
*/
#define SFMC_REGION0_KEY_SEL(DRVIDX)            (SFMC_ECCAES_ADDR(DRVIDX) + 0x0040u)
#define SFMC_REGION1_KEY_SEL(DRVIDX)            (SFMC_ECCAES_ADDR(DRVIDX) + 0x0044u)
#define SFMC_REGION2_KEY_SEL(DRVIDX)            (SFMC_ECCAES_ADDR(DRVIDX) + 0x0048u)
#define SFMC_REGION3_KEY_SEL(DRVIDX)            (SFMC_ECCAES_ADDR(DRVIDX) + 0x004cu)
/*
DEVICE_KEY_SEL
31 : DEVICE_KEY_ENABLE ; AES region key enable
0 :  DEVICE_KEY_SEL ;  0 - HW key, 1 - SW key
*/
#define SFMC_DEVICE_KEY_SEL(DRVIDX)             (SFMC_ECCAES_ADDR(DRVIDX) + 0x0050u)
/*
OFFSET_ADDRESS_MASK
31:0 : AES offset address mask
       Value of (read address & ~offset_address_mask) is used to AES decryption.
*/
#define SFMC_OFFSET_ADDRESS_MASK(DRVIDX)        (SFMC_ECCAES_ADDR(DRVIDX) + 0x0054u)

/*
AES 128bit key
REGION#_KEY0
31:0 : AES region key[31:0]
REGION#_KEY1
31:0 : AES region key[63:32]
...
*/
#define SFMC_REGION0_KEY0(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX) + 0x0060u)
#define SFMC_REGION0_KEY1(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX) + 0x0064u)
#define SFMC_REGION0_KEY2(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX) + 0x0068u)
#define SFMC_REGION0_KEY3(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX) + 0x006cu)
/*
REGION#_KEY_VALID
0 : KEY_VALID ; AES region key valid
*/
#define SFMC_REGION0_KEY_VALID(DRVIDX)          (SFMC_ECCAES_ADDR(DRVIDX) + 0x0070u)
/*
REGION#_KEY_LOCK
0 : KEY_LOCK ; 0 - No Lock, 1 - Read/Write Lock
*/
#define SFMC_REGION0_KEY_LOCK(DRVIDX)           (SFMC_ECCAES_ADDR(DRVIDX) + 0x007cu)

#define SFMC_REGION1_KEY0(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX) + 0x0080u)
#define SFMC_REGION1_KEY1(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX) + 0x0084u)
#define SFMC_REGION1_KEY2(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX) + 0x0088u)
#define SFMC_REGION1_KEY3(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX) + 0x008cu)
#define SFMC_REGION1_KEY_VALID(DRVIDX)          (SFMC_ECCAES_ADDR(DRVIDX) + 0x0090u)
#define SFMC_REGION1_KEY_LOCK(DRVIDX)           (SFMC_ECCAES_ADDR(DRVIDX) + 0x009cu)

#define SFMC_REGION2_KEY0(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX) + 0x00a0u)
#define SFMC_REGION2_KEY1(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX) + 0x00a4u)
#define SFMC_REGION2_KEY2(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX) + 0x00a8u)
#define SFMC_REGION2_KEY3(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX) + 0x00acu)
#define SFMC_REGION2_KEY_VALID(DRVIDX)          (SFMC_ECCAES_ADDR(DRVIDX) + 0x00b0u)
#define SFMC_REGION2_KEY_LOCK(DRVIDX)           (SFMC_ECCAES_ADDR(DRVIDX) + 0x00bcu)

#define SFMC_REGION3_KEY0(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX)+0x00c0u)
#define SFMC_REGION3_KEY1(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX)+0x00c4u)
#define SFMC_REGION3_KEY2(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX)+0x00c8u)
#define SFMC_REGION3_KEY3(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX)+0x00ccu)
#define SFMC_REGION3_KEY_VALID(DRVIDX)          (SFMC_ECCAES_ADDR(DRVIDX)+0x00d0u)
#define SFMC_REGION3_KEY_LOCK(DRVIDX)           (SFMC_ECCAES_ADDR(DRVIDX)+0x00dcu)

/*
AES 128bit key
DEVICE_KEY0
31:0 : AES device key[31:0]
DEVICE_KEY1
31:0 : AES device key[63:32]
...
*/
#define SFMC_DEVICE_KEY0(DRVIDX)                (SFMC_ECCAES_ADDR(DRVIDX) + 0x00e0u)
#define SFMC_DEVICE_KEY1(DRVIDX)                (SFMC_ECCAES_ADDR(DRVIDX) + 0x00e4u)
#define SFMC_DEVICE_KEY2(DRVIDX)                (SFMC_ECCAES_ADDR(DRVIDX) + 0x00e8u)
#define SFMC_DEVICE_KEY3(DRVIDX)                (SFMC_ECCAES_ADDR(DRVIDX) + 0x00ecu)
/*
DEVICE_KEY_VALID
0 : DEVICE_KEY_VALID ; AES region key valid
*/
#define SFMC_DEVICE_KEY_VALID(DRVIDX)           (SFMC_ECCAES_ADDR(DRVIDX) + 0x00f0)
/*
DEVICE_KEY_LOCK
0 : DEVICE_KEY_LOCK ; 0 - No Lock, 1 - Read/Write Lock
*/
#define SFMC_DEVICE_KEY_LOCK(DRVIDX)            (SFMC_ECCAES_ADDR(DRVIDX) + 0x00f4)

#define SFMC_REGION0_START_ADDR(DRVIDX)         (SFMC_ECCAES_ADDR(DRVIDX) + 0x0100)
#define SFMC_REGION0_END_ADDR(DRVIDX)           (SFMC_ECCAES_ADDR(DRVIDX) + 0x0104)
/*
REGION#_MASTER_FILTER
31:0 : MASTER_FILTER ; AES region master filter 0 - Disallow, 1 - allow
Note 1: Each master can access decrypted data when REGION#_MASTER_ADDR <= ARADDR <= REGION#_END_ADDR && (REGION#_MASTER_FILTER[ARMASTER]==1)
Note 2: Setting REGION#_MASTER_FILTER to 0xFFFFFFFF means that all masters can access target region.
Note 3: Setting REGION#_MASTER_FILTER to 0x00000000 means that all masters can not access target region

*/
//0: Cortex-M0P, 1: CoreSight, 2:AP AXI block-0, 3:AP AHB bllock-0, 4: DMB, AHB master-0, 5: DMA, AHB master-01, 6: GPSB, GPSB master-1, 7: UART DMA
#define SFMC_REGION0_MASTER_FILTER(DRVIDX)      (SFMC_ECCAES_ADDR(DRVIDX) + 0x0108)
/*
REGION#_FILTER_LOCK
0 : FILTER_LOCK ; AES region filter lock, 0 - No Lock, 1 - Write Lock
Note: If this register is set to 1, REGION#_START_ADDR, REGION#_END_ADDR, and REGION#_FILTER_LOCK registers can not be modified.
*/
#define SFMC_REGION0_FILTER_LOCK(DRVIDX)        (SFMC_ECCAES_ADDR(DRVIDX) + 0x010c)

#define SFMC_REGION1_START_ADDR(DRVIDX)         (SFMC_ECCAES_ADDR(DRVIDX) + 0x0120u)
#define SFMC_REGION1_END_ADDR(DRVIDX)           (SFMC_ECCAES_ADDR(DRVIDX) + 0x0124u)
#define SFMC_REGION1_MASTER_FILTER(DRVIDX)      (SFMC_ECCAES_ADDR(DRVIDX) + 0x0128u)
#define SFMC_REGION1_FILTER_LOCK(DRVIDX)        (SFMC_ECCAES_ADDR(DRVIDX) + 0x012cu)

#define SFMC_REGION2_START_ADDR(DRVIDX)         (SFMC_ECCAES_ADDR(DRVIDX) + 0x0140u)
#define SFMC_REGION2_END_ADDR(DRVIDX)           (SFMC_ECCAES_ADDR(DRVIDX) + 0x0144u)
#define SFMC_REGION2_MASTER_FILTER(DRVIDX)      (SFMC_ECCAES_ADDR(DRVIDX) + 0x0148u)
#define SFMC_REGION2_FILTER_LOCK(DRVIDX)        (SFMC_ECCAES_ADDR(DRVIDX) + 0x014cu)

#define SFMC_REGION3_START_ADDR(DRVIDX)         (SFMC_ECCAES_ADDR(DRVIDX) + 0x0160u)
#define SFMC_REGION3_END_ADDR(DRVIDX)           (SFMC_ECCAES_ADDR(DRVIDX) + 0x0164u)
#define SFMC_REGION3_MASTER_FILTER(DRVIDX)      (SFMC_ECCAES_ADDR(DRVIDX) + 0x0168u)
#define SFMC_REGION3_FILTER_LOCK(DRVIDX)        (SFMC_ECCAES_ADDR(DRVIDX) + 0x016cu)

/*
FAULT_STATUS
6 : AUTO_DECODE
5 : AUTO_2BIT
4 : AUTO_1BIT
3: FIFO_ERROR4
2: FIFO_ERROR3
1: FIFO_ERROR2
0: FIFO_ERROR1

When writing 1 to FAULT_CLEAR, the corresponding status is cleared
*/
#define SFMC_FAULT_STATUS(DRVIDX)               (SFMC_ECCAES_ADDR(DRVIDX) + 0x0200)  //R
/*
FAULT_MASK
6 : AUTO_DECODE
5 : AUTO_2BIT
4 : AUTO_1BIT
3: FIFO_ERROR4
2: FIFO_ERROR3
1: FIFO_ERROR2
0: FIFO_ERROR1
0 - Request disable, 1 - Reguest enable, Enable - report to FMU
*/
#define SFMC_FAULT_MASK(DRVIDX)                 (SFMC_ECCAES_ADDR(DRVIDX) + 0x0204)
#define SFMC_FAULT_CLEAR(DRVIDX)                (SFMC_ECCAES_ADDR(DRVIDX) + 0x0208)  //W
/*
FIFO_ECC_ERR_ADDR
6:0 : SFMC Buffer Memory ECC Error Address
*/
#define SFMC_FIFO_ECC_ERR_ADDR(DRVIDX)          (SFMC_ECCAES_ADDR(DRVIDX) + 0x0210)  //R
#define SFMC_AUTO_ECC_ERR_ADDR(DRVIDX)          (SFMC_ECCAES_ADDR(DRVIDX) + 0x0214)  //R
/*
ECC_ERR_REQ_ACK_CFG
16 : FAULT_REQ_INIT ; ECC Fault Request Handler Synchronous Reset
11:0 : FAULT_TIMEOUT_VALUE ; forcibly initializes the request signal
                              if an acknowledgement is not received for the request signal within
                              (FAULT_ACK_TIMEOUT + 1) × 16 cycles after the soft fault request signal is output.
*/
#define SFMC_ECC_ERR_REQ_ACK_CFG(DRVIDX)        (SFMC_ECCAES_ADDR(DRVIDX) + 0x0218)
/*
16 : ECC_FAULT_ACK
0  : ECC_FAULT_REQ
*/
#define SFMC_ECC_ERR_REQ_ACK_STS(DRVIDX)        (SFMC_ECCAES_ADDR(DRVIDX) + 0x021c)  //R























#endif
