###################################################################################################
#
#   FileName : ruls.mk
#
#   Copyright (c) Telechips Inc.
#
#   Description :
#
#
###################################################################################################
#
#   TCC Version 1.0
#
#   This source code contains confidential information of Telechips.
#
#   Any unauthorized use without a written permission of Telechips including not limited to
#   re-distribution in source or binary form is strictly prohibited.
#
#   This source code is provided "AS IS" and nothing contained in this source code shall constitute
#   any express or implied warranty of any kind, including without limitation, any warranty of
#   merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
#   or other third party intellectual property right. No warranty is made, express or implied,
#   regarding the information's accuracy,completeness, or performance.
#
#   In no event shall Telechips be liable for any claim, damages or other liability arising from,
#   out of or in connection with this source code or the use in the source code.
#
#   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement between
#   Telechips and Company.
#   This source code is provided "AS IS" and nothing contained in this source code shall constitute
#   any express or implied warranty of any kind, including without limitation, any warranty
#   (of merchantability, fitness for a particular purpose or non-infringement of any patent,
#   copyright or other third party intellectual property right. No warranty is made, express or
#   implied, regarding the information's accuracy, completeness, or performance.
#   In no event shall Telechips be liable for any claim, damages or other liability arising from,
#   out of or in connection with this source code or the use in the source code.
#   This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
#   between Telechips and Company.
#
###################################################################################################

SIC_BSP_DEV_DRIVERS_PATH := $(SIC_BSP_BUILD_CURDIR)

# CLOCK Control Unit
include $(SIC_BSP_DEV_DRIVERS_PATH)/clock/rules.mk

# Controller Area Network
ifeq ($(SIC_BSP_DEV_DRV_CAN), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/can/rules.mk
endif

# Common
include $(SIC_BSP_DEV_DRIVERS_PATH)/common/rules.mk

# NVIC
include $(SIC_BSP_DEV_DRIVERS_PATH)/nvic/rules.mk

# Fault Management Unut
ifeq ($(SIC_BSP_DEV_DRV_FMU), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/fmu/rules.mk
endif

# Direct Memory Access
ifeq ($(SIC_BSP_DEV_DRV_GDMA), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/gdma/rules.mk
endif

# General Purpose I/O
include $(SIC_BSP_DEV_DRIVERS_PATH)/gpio/rules.mk

# Internal Memory Controller
include $(SIC_BSP_DEV_DRIVERS_PATH)/imc/rules.mk
# Low-Voltage Differential Signaling
#include $(SIC_BSP_DEV_DRIVERS_PATH)/lvds/rules.mk

# Mail-Box
ifeq ($(SIC_BSP_DEV_DRV_MBOX), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/mailbox/rules.mk
endif

# Memory Protection Unit
include $(SIC_BSP_DEV_DRIVERS_PATH)/mpu/rules.mk

# ADC Controller
ifeq ($(SIC_BSP_DEV_DRV_ADC), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/adc/rules.mk
endif

# Ethernet MAC
ifeq ($(SIC_BSP_DEV_DRV_ETH), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/eth/rules.mk
endif

# Serial Peripheral Interface
ifeq ($(SIC_BSP_DEV_DRV_GPSB), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/gpsb/rules.mk
endif

# Pulse Density Modulation
ifeq ($(SIC_BSP_DEV_DRV_PDM), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/pdm/rules.mk
endif

# Input Capture Timer Counter
ifeq ($(SIC_BSP_DEV_DRV_ICTC), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/ictc/rules.mk
endif

# Timer
ifeq ($(SIC_BSP_DEV_DRV_TIMER), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/timer/rules.mk
endif

# Unuversal Asynchronous Receiver/Transimitter
ifeq ($(SIC_BSP_DEV_DRV_UART), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/uart/rules.mk
endif

# Ultra Direct Memory Access
include $(SIC_BSP_DEV_DRIVERS_PATH)/udma/rules.mk

# Windowed Watchdog Timer
ifeq ($(SIC_BSP_DEV_DRV_WDT), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/wdt/rules.mk
endif

# Default Slave Error
ifeq ($(SIC_BSP_DEV_DRV_DSE), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/dse/rules.mk
endif

# Power Manager Unit
ifeq ($(SIC_BSP_DEV_DRV_PMU), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/pmu/rules.mk
endif

# sfmc
ifeq ($(SIC_BSP_DEV_DRV_SFMC), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/sfmc/rules.mk
endif

# System Safety Mechanism (SSM)
ifeq ($(SIC_BSP_DEV_DRV_SSM), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/ssm/rules.mk
endif

# Safety Watchdog
ifeq ($(SIC_BSP_DEV_DRV_SWDT), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/safety.watchdog/rules.mk
endif

# I2C Controller
ifeq ($(SIC_BSP_DEV_DRV_I2C), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/i2c/rules.mk
endif

# PMIO Controller
ifeq ($(SIC_BSP_DEV_DRV_PMIO), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/pmio/rules.mk
endif

# RTC Controller
ifeq ($(SIC_BSP_DEV_DRV_RTC), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/rtc/rules.mk
endif

# LPA driver
ifeq ($(SIC_BSP_DEV_DRV_LPA), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/lpa/rules.mk
endif

# TPA driver
ifeq ($(SIC_BSP_DEV_DRV_TPA), y)
include $(SIC_BSP_DEV_DRIVERS_PATH)/tpa/rules.mk
endif
