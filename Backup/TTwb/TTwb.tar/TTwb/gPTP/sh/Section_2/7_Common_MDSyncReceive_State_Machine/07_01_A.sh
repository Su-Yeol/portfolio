cd ../../../
./daemon_cl_log pfe0 -F ./conf/Section_2/7_Common_MDSyncReceive_State_Machine/07_01_A.ini
