XCODE_PRODUCT_TYPE
------------------

Set the Xcode ``productType`` attribute on its reference to a
target.  CMake computes a default based on target type but
can be told explicitly with this property.

See also :prop_tgt:`XCODE_EXPLICIT_FILE_TYPE`.
