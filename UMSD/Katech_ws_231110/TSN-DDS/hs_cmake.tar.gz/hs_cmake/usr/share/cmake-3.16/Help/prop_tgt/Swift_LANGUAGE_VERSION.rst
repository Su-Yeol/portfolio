Swift_LANGUAGE_VERSION
----------------------

This property sets the language version for the Swift sources in the target.  If
one is not specified, it will default to ``<CMAKE_Swift_LANGUAGE_VERSION>`` if
specified, otherwise it is the latest version supported by the compiler.
