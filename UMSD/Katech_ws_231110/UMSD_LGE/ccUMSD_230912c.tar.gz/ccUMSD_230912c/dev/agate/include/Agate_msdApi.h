/**********************************************************************************************
* Copyright (c) 2022 Marvell.
* All rights reserved.
* Use of this source code is governed by a BSD3 license that
* can be found in the LICENSE file and also at https://opensource.org/licenses/BSD-3-Clause
**********************************************************************************************/

/********************************************************************************
* Agate_msdApi.h
*
* DESCRIPTION:
*       API definitions for QuarterDeck Device
*
* DEPENDENCIES:
*
* FILE REVISION NUMBER:
*
*******************************************************************************/

#ifndef __Agate_msdApi_h
#define __Agate_msdApi_h
#ifdef __cplusplus
extern "C" {
#endif

/* minimum need header files*/

/* add modules whatever you needed */
#include <agate/include/api/Agate_msdBrgFdb.h>
#include <agate/include/api/Agate_msdVct.h>
#include <agate/include/api/Agate_msdBrgStu.h>
#include <agate/include/api/Agate_msdBrgVtu.h>
#include <agate/include/api/Agate_msdPhyCtrl.h>
#include <agate/include/api/Agate_msdPIRL.h>
#include <agate/include/api/Agate_msdPortCtrl.h>
#include <agate/include/api/Agate_msdPortPrioMap.h>
#include <agate/include/api/Agate_msdPortRmon.h>
#include <agate/include/api/Agate_msdEEPROM.h>
#include <agate/include/api/Agate_msdQueueCtrl.h>
#include <agate/include/api/Agate_msdSysCtrl.h>
#include <agate/include/api/Agate_msdQav.h>
#include <agate/include/api/Agate_msdPTP.h>
#include <agate/include/api/Agate_msdTCAM.h>
#include <agate/include/api/Agate_msdRMU.h>
#include <agate/include/api/Agate_msdLed.h>
#include <agate/include/driver/Agate_msdHwAccess.h>
#ifdef __cplusplus
}
#endif

#endif /* __Agate_msdApi_h */
