#include "../include/driver/eth3/eth3_msdSysConfig.h"
#include "../include/msdApi.h"
#include "include/driver/msdHwAccess.h"
#include "../dev/fir/include/driver/Fir_msdDrvSwRegs.h"

MSD_U8 portNum;
MSD_BOOL master = MSD_TRUE;

MSD_BOOL checkParam(int argc, char **argv)
{
	MSD_BOOL paramValid = MSD_TRUE;

	if(argc != 3) {
		MSD_DBG_ERROR(("Unexpected number of arguments\n"));
		paramValid = MSD_FALSE;
	}  

	portNum = (MSD_U8) atoi(argv[1]);
	if(portNum < 1 || portNum > 9) {
		MSD_DBG_ERROR(("Out of range value of port\n"));
		paramValid = MSD_FALSE;
	} 

	if(strcmp(argv[2], "master") && strcmp(argv[2], "slave")) {
		MSD_DBG_ERROR(("Undefined role\n"));
		paramValid = MSD_FALSE;
	}

	if(!strcmp(argv[2], "slave")) {
		master = MSD_FALSE;
	}

	if(paramValid == MSD_FALSE) {
		MSD_DBG_ERROR(("Usage : phyCfg_ctrl <port> <master/slave>\n"));
		MSD_DBG_ERROR(("   ex : phyCfg_ctrl 2 slave\n"));
	} 

	return paramValid;
}


int main(int argc, char **argv) 
{
	MSD_STATUS status;

	MSD_U8 devNum = FIR_GLOBAL2_DEV_ADDR;
	MSD_QD_DEV* dev;

	MSD_U8 devAddr = 0x1; // Always 0x1 for PHY registers?
// portNum	MSD_U8 phyAddr = 0x2;
	MSD_U16 regAddr = 0x0834;
	MSD_U16 msCfg = 14;

	MSD_U16 data;

	msdDbgLvlSet(MSD_DBG_ALL_LVL);

	if(checkParam(argc, argv) == MSD_FALSE)
	{
		return -1;
	}

	if((status = qdStart_SingleDevice_SMI_SC(devNum)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum %d is NULL. Driver load failed. \n", devNum));
		return -1;
	} 

	dev = sohoDevGet(devNum);
	if (NULL == dev)
	{
		MSD_DBG_ERROR(("Dev is NULL for devNum %d.\n", devNum));
		return MSD_FAIL;
	} 

	if((status = msdGetSMIC45PhyReg(devNum, devAddr, portNum, regAddr, &data)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("msdSetSMIC45PhyReg failed. \n"));
		return -1;
	} 
	else
	{
		MSD_DBG_INFO(("Current phyCfg_ctrl for port #%d is %s\n", portNum, (data & (0x1 << msCfg)) ? "master" : "slave"));
	}

	if(master) 
	{
		data |= 0x1 << msCfg;
	}
	else
	{
		data &= ~(0x1 << msCfg);
	}
	
	if((status = msdSetSMIC45PhyReg(devNum, devAddr, portNum, regAddr, data)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("msdSetSMIC45PhyReg failed. \n"));
		return -1;
	} 

	MSD_DBG_INFO(("Now, phyCfg_ctrl for port #%d is changed to %s\n", portNum, (master == MSD_TRUE) ? "master" : "slave"));

	return 0;
}


