/**********************************************************************************************
* Copyright (c) 2022 Marvell.
* All rights reserved.
* Use of this source code is governed by a BSD3 license that
* can be found in the LICENSE file and also at https://opensource.org/licenses/BSD-3-Clause
**********************************************************************************************/

/*******************************************************************************
* Fir_msdPolicyIntf.c
*
* DESCRIPTION:
*       API for Marvell policy.
*
* DEPENDENCIES:
*       None.
*
* FILE REVISION NUMBER:
*******************************************************************************/

#ifdef J_INC_PATH
#include "dev/fir/include/api/Fir_msdPolicy.h"
#else
#include <fir/include/api/Fir_msdPolicy.h>
#endif

/*todo*/
