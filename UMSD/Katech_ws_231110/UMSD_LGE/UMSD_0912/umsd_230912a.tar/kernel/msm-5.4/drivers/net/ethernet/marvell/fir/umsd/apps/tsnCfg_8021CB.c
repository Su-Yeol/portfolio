#include <string.h>

#include "../include/driver/eth3/eth3_msdSysConfig.h"
#include "../include/msdApi.h"
#include "../dev/fir/include/driver/Fir_msdDrvSwRegs.h"

MSD_BOOL talker = MSD_FALSE;

MSD_STATUS initialzeDrivers(MSD_LPORT p1, MSD_LPORT p2, MSD_LPORT p3) 
{
	MSD_STATUS status;

	if((status = qdStart_SingleDevice_SMI_SC(p1)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", p1));
		return status;
	}

	if((status = qdStart_SingleDevice_SMI_SC(p2)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", p2));
		return status;
	}

	if((status = qdStart_SingleDevice_SMI_SC(p3)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", p3));
		return status;
	}

	if((status = qdStart_SingleDevice_SMI_SC(FIR_GLOBAL1_DEV_ADDR)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", FIR_GLOBAL1_DEV_ADDR));
		return status;
	} 

	if((status = qdStart_SingleDevice_SMI_SC(FIR_GLOBAL2_DEV_ADDR)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", FIR_GLOBAL2_DEV_ADDR));
		return status;
	}  

	if((status = qdStart_SingleDevice_SMI_SC(FIR_TCAM_DEV_ADDR)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", FIR_TCAM_DEV_ADDR));
		return status;
	} 

	return status;
}


MSD_STATUS addVlanEntry(MSD_LPORT p1, MSD_LPORT p2, MSD_LPORT p3) 
{
	MSD_STATUS status;

	MSD_U8  devNum = FIR_GLOBAL1_DEV_ADDR; 
	MSD_QD_DEV* dev;

	MSD_VTU_ENTRY vtuEntry;

	dev = sohoDevGet(devNum);

	if (NULL == dev)
	{
		MSD_DBG_ERROR(("Dev is NULL for devNum %d.\n", dev->devNum));
		return MSD_FAIL;
	} 

  if ((status = msdVlanAllDelete(dev->devNum)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdVlanAllDelete returned fail.\n"));
		return status;
	}

	msdMemSet(&vtuEntry,0,sizeof(MSD_VTU_ENTRY)); /* Set all bit to 0 by default */

	if(!talker) {
		vtuEntry.fid = 2;
	}
	vtuEntry.vid = 5;

	for(int i=0; i<dev->numOfPorts; i++)
	{
		vtuEntry.memberTagP[i] = 3;
	}
	vtuEntry.memberTagP[p1] = 2;
	vtuEntry.memberTagP[p2] = 2;
	vtuEntry.memberTagP[p3] = 2;

	if ((status = msdVlanEntryAdd(dev->devNum, &vtuEntry)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdVlanEntryAdd returned fail.\n"));
	}

	return status;
}


MSD_STATUS set8021qMode(MSD_LPORT p1, MSD_LPORT p2, MSD_LPORT p3) 
{
	MSD_STATUS status;

	MSD_8021Q_MODE qMode = MSD_8021Q_CHECK;

	if ((status = msdPort8021qModeSet(p1, p1, qMode)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPort8021qModeSet returned fail. port# = %d\n", p1));
		return status;
	}

	if ((status = msdPort8021qModeSet(p2, p2, qMode)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPort8021qModeSet returned fail. port# = %d\n", p2));
		return status;
	}

	if ((status = msdPort8021qModeSet(p3, p3, qMode)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPort8021qModeSet returned fail. port# = %d\n", p3));
		return status;
	}

	return status;
} 


MSD_STATUS setPortBasedVlanMap(MSD_LPORT ingress1, MSD_LPORT ingress2) 
{
	MSD_STATUS status;
	MSD_LPORT ports[10]; // TODO: 10 -> dev.numOfPorts 
	MSD_U8 portsLen, nportsLen;

	if ((status = msdPortBasedVlanMapGet(ingress1, ingress1, ports, &portsLen)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPortBasedVlanMapGet returned fail. port# = %d\n", ingress1));
		return status;
	}
	else
	{
		MSD_DBG_INFO(("portBasedVlanMap(%d) : portsLen=%d\n", ingress1, portsLen));

		MSD_U8 p=0, np=0;
		while(p < portsLen)
		{
			MSD_DBG_INFO(("p[%d]=%d\n", p, ports[p]));
			if((ingress1 == ports[p]) || (ingress2 == ports[p]))
			{
				p++; continue;
			}
			ports[np++] = ports[p++];
		}
		nportsLen = np;
		MSD_DBG_INFO(("\n"));

		MSD_DBG_INFO(("nportBasedVlanMap(%d) : nportsLen=%d\n", ingress1, nportsLen));
		for(MSD_U8 p=0; p<nportsLen; p++)
		{
			MSD_DBG_INFO(("np[%d]=%d\n", p, ports[p]));
		}
		MSD_DBG_INFO(("\n"));

		if ((status = msdPortBasedVlanMapSet(ingress1, ingress1, ports, nportsLen)) != MSD_OK)
		{
			MSD_DBG_ERROR(("msdPortBasedVlanMapSet returned fail. port# = %d\n", ingress1));
			return status;
		}
	}

	if ((status = msdPortBasedVlanMapGet(ingress2, ingress2, ports, &portsLen)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPortBasedVlanMapGet returned fail. port# = %d\n", ingress2));
		return status;
	}
	else
	{
		MSD_DBG_INFO(("portBasedVlanMap(%d) : portsLen=%d\n", ingress2, portsLen));

		MSD_U8 p=0, np=0;
		while(p < portsLen)
		{
			MSD_DBG_INFO(("p[%d]=%d\n", p, ports[p]));
			if((ingress1 == ports[p]) || (ingress2 == ports[p]))
			{
				p++; continue;
			}
			ports[np++] = ports[p++];
		}
		nportsLen = np;
		MSD_DBG_INFO(("\n"));


		MSD_DBG_INFO(("nportBasedVlanMap(%d) : nportsLen=%d\n", ingress2, nportsLen));
		for(MSD_U8 p=0; p<nportsLen; p++)
		{
			MSD_DBG_INFO(("np[%d]=%d\n", p, ports[p]));
		}
		MSD_DBG_INFO(("\n"));

		if ((status = msdPortBasedVlanMapSet(ingress2, ingress2, ports, nportsLen)) != MSD_OK)
		{
			MSD_DBG_ERROR(("msdPortBasedVlanMapSet returned fail. port# = %d\n", ingress2));
			return status;
		}
	} 


	return status;
}


MSD_STATUS setTcamIngressSingle(MSD_LPORT p1, MSD_LPORT p2, MSD_LPORT p3)
{
	MSD_STATUS     status;

	MSD_U8  devNum = FIR_TCAM_DEV_ADDR;

	MSD_U32        IgrTcamPointer = 0;
	MSD_TCAM_DATA  IgrTcamData;

	MSD_TCAM_MODE tcamMode = MSD_TCAM_MODE_ENABLE_48; /* enable 48 bytes match tcam mode, single entry match */ 

	if(talker) 
	{
		if ((status = msdPortTcamModeSet(p3, p3, tcamMode)) != MSD_OK)
		{
			MSD_DBG_ERROR(("msdPortTcamModeSet returned fail.\n"));
			return status;
		}
	}
	else 
	{
		if ((status = msdPortTcamModeSet(p1, p1, tcamMode)) != MSD_OK)
		{
			MSD_DBG_ERROR(("msdPortTcamModeSet returned fail.\n"));
			return status;
		}

		if ((status = msdPortTcamModeSet(p2, p2, tcamMode)) != MSD_OK)
		{
			MSD_DBG_ERROR(("msdPortTcamModeSet returned fail.\n"));
			return status;
		} 
	}

 	if ((status = msdTcamAllDelete(devNum)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdTcamAllDelete returned fail.\n"));
		return status;
	}

	msdMemSet(&IgrTcamData,0,sizeof(MSD_TCAM_DATA)); /* Set all bit to 0 by default */

	if(talker)
	{
		IgrTcamData.spvMask = 0xfff;
		IgrTcamData.spv |= 1 << p3;

		IgrTcamData.dpvMode = 0x3; /*  Replace the frames DPV with the TCAM Entry��s DPV Data */
		IgrTcamData.dpvData |= 1 << p1;
		IgrTcamData.dpvData |= 1 << p2;

		IgrTcamData.frerSeqGenEn = 1;
		IgrTcamData.frerIndvRcvyId = 0xf; 
	}
	else
	{

		IgrTcamData.spvMask = 0x3ff; // 11 1111 1111
		IgrTcamData.spvMask ^= 1 << p1;
		IgrTcamData.spvMask ^= 1 << p2;
		IgrTcamData.spv = 0; 

		IgrTcamData.frerSctrInc = 1;
		IgrTcamData.frerSctrIndex = 0xf;

		IgrTcamData.frerSeqEncType = 1;
		IgrTcamData.frerSeqRcvyEn = 1;
		IgrTcamData.frerSeqRcvyIndex = 0xf; 

//		IgrTcamData.interrupt = 0x1; // added

	}

//	IgrTcamData.frameTypeMask = 0x3; // added

//	IgrTcamData.frameOctetMask[0] = 0xff;
//	IgrTcamData.frameOctet[0] = 0x00;
	IgrTcamData.frameOctetMask[1] = 0xff;
	IgrTcamData.frameOctet[1] = 0x22;
//	IgrTcamData.frameOctetMask[1] = 0xff;
//	IgrTcamData.frameOctet[2] = 0x22;
//	IgrTcamData.frameOctetMask[1] = 0xff;
//	IgrTcamData.frameOctet[3] = 0x22;
//	IgrTcamData.frameOctetMask[1] = 0xff;
//	IgrTcamData.frameOctet[4] = 0x22;
//	IgrTcamData.frameOctetMask[1] = 0xff;
//	IgrTcamData.frameOctet[5] = 0x22;
	
	if ((status = msdTcamEntryAdd(devNum, IgrTcamPointer, &IgrTcamData)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdTcamEntryAdd returned fail.\n"));
		return status;
	}

	return MSD_OK;
}


MSD_STATUS addMacEntry(MSD_LPORT p3) 
{
	MSD_STATUS status;

	MSD_U8	devNum = FIR_GLOBAL1_DEV_ADDR;
	MSD_QD_DEV* dev;

	MSD_ATU_ENTRY macEntry;

	dev = sohoDevGet(devNum);

	if (NULL == dev)
	{
		MSD_DBG_ERROR(("Dev is NULL for devNum %d.\n", devNum));
		return MSD_FAIL;
	} 

	if ((status = msdFdbAllDelete(dev->devNum, MSD_FLUSH_ALL)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdFdbAllDelete returned fail.\n"));
		return status;
	}

	msdMemSet(&macEntry,0,sizeof(MSD_ATU_ENTRY)); /* Set all bit to 0 by default */

	macEntry.macAddr.arEther[0] = 0x00;
	macEntry.macAddr.arEther[1] = 0x22;
	macEntry.macAddr.arEther[2] = 0x22;
	macEntry.macAddr.arEther[3] = 0x22;
	macEntry.macAddr.arEther[4] = 0x22;
	macEntry.macAddr.arEther[5] = 0x22;

	macEntry.portVec = 1 << p3;     /* Set the portVector matching with Port 6, the frame with DA as above address will be forwarded to port 2. */

	macEntry.fid = 0;	/* Refer to the fid of VLAN entry ! */
	macEntry.entryState = 0xE;      /* Static entry. */

	if ((status = msdFdbMacEntryAdd(dev->devNum, &macEntry)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdFdbMacEntryAdd returned fail.\n"));
	}

	return status;
}


MSD_STATUS setSeqRcvy(MSD_LPORT p3)
{
	MSD_STATUS status;

	MSD_U8 devNum = FIR_GLOBAL2_DEV_ADDR;

	MSD_FRER_SEQRCVY seqRcvyData;
	MSD_FRER_BANK1_CONFIG bk1ConfigData;

	if ((status = msdFrerSeqRcvyFlushAll(devNum)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdFrerSeqRcvyFlushAll returned fail.\n"));
		return status;
	}

	msdMemSet(&seqRcvyData,0,sizeof(MSD_FRER_SEQRCVY)); /* Set all bit to 0 by default */

	seqRcvyData.seqRcvyEn = 0x1;
	seqRcvyData.seqRcvyPort = p3;
	seqRcvyData.seqRcvyIndex = 0xf;
	seqRcvyData.seqRcvyAlg = 0x1;

	if ((status = msdFrerSeqRcvyLoad(devNum, &seqRcvyData)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdFrerSeqRcvyLoad returned fail.\n"));
		return status;
	}

	if ((status = msdFrerBank1SCtrFlushAll(devNum)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdFrerBank1SCtrFlushAll returned fail.\n"));
		return status;
	}

	msdMemSet(&bk1ConfigData,0,sizeof(MSD_FRER_BANK1_CONFIG)); /* Set all bit to 0 by default */

	bk1ConfigData.bk1SCtrId = 0xf; /* bank 1 stream counter id = 2 */
	bk1ConfigData.bk1SCtrEn = 0x1; /* enable bank 1 stream counter */
	bk1ConfigData.bk1SCtrPort = p3; /* counter port 3 frames */
	bk1ConfigData.bk1SCtrIndex = 0xf; /*bank 0 stream counter index = 2 */
	if ((status = msdFrerBank1SCtrLoad(devNum, &bk1ConfigData)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdFrerBank1SCtrLoad returned fail.\n"));
		return status;
	}

	return status;
}


int main(int argc, char **argv) 
{
	MSD_STATUS status;
	MSD_LPORT port1, port2, port3;

	msdDbgLvlSet(MSD_DBG_ALL_LVL);
	
	if(argc != 5) {
		MSD_DBG_ERROR(("Unexpected number of arguments\n"));
		MSD_DBG_ERROR(("Usage : tsnCfg_8021CB <talker/listener> <port 1> <port 2> <port3>\n"));
		MSD_DBG_ERROR(("   ex : tsnCfg_8021CB talker 6 7 9\n"));
		return 0;
	}  

	if(strcmp(argv[1], "talker") && strcmp(argv[1], "listener")) {
		MSD_DBG_ERROR(("Undefined role\n"));
		MSD_DBG_ERROR(("Usage : tsnCfg_8021CB <talker/listener> <port 1> <port 2> <port3>\n"));
		MSD_DBG_ERROR(("   ex : tsnCfg_8021CB talker 6 7 9\n"));
		return 0;
	} 

	if(!strcmp(argv[1], "talker")) {
		talker = MSD_TRUE;
	}
	
	port1 = atoi(argv[2]);
	port2 = atoi(argv[3]);
	port3 = atoi(argv[4]); // PCIe

	initialzeDrivers(port1, port2, port3);

  if ((status = addVlanEntry(port1, port2, port3)) != MSD_OK)
	{
		MSD_DBG_ERROR(("addVlanEntry returned fail.\n"));
		return status;
	}

	if(talker) 
	{
	  if ((status = set8021qMode(port1, port2, port3)) != MSD_OK)
		{
			MSD_DBG_ERROR(("set8021qMode returned fail.\n"));
			return status;
	  }

	  if ((status = addMacEntry(port3)) != MSD_OK)
		{
			MSD_DBG_ERROR(("addMacEntry returned fail.\n"));
			return status;
		} 
	}
	else
	{

		if ((status = setPortBasedVlanMap(port1, port2)) != MSD_OK)
		{
			MSD_DBG_ERROR(("setPortBasedVlanMap returned fail.\n"));
			return status;
		}

		if ((status = setSeqRcvy(port3)) != MSD_OK)
		{
			MSD_DBG_ERROR(("setSeqRcvy returned fail.\n"));
			return status;
		}
	}

	if ((status = setTcamIngressSingle(port1, port2, port3)) != MSD_OK)
	{
		MSD_DBG_ERROR(("setTcamIngressSingle returned fail.\n"));
		return status;
	} 

	return 0;
}


