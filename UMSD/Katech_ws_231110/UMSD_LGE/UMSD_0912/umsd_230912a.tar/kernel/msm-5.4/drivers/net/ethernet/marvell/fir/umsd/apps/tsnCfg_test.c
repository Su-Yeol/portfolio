#include "../include/driver/eth3/eth3_msdSysConfig.h"
#include "../include/msdApi.h"
#include "include/driver/msdHwAccess.h"
#include "../dev/fir/include/driver/Fir_msdDrvSwRegs.h"


int main(int argc, char **argv) 
{
	MSD_STATUS status;

	MSD_LPORT ingress1 = 2, ports[10];
	MSD_U8 portsLen = 9, nportsLen;

	msdDbgLvlSet(MSD_DBG_ALL_LVL);

	ports[0] = 0;
	ports[1] = 1;
	ports[2] = 2;
	ports[3] = 4;
	ports[4] = 5;
	ports[5] = 6;
	ports[6] = 7;
	ports[7] = 8;
	ports[8] = 9;

	MSD_DBG_ERROR(("msdPortBasedVlanMapGet(%d) : portsLen=%d\n", ingress1, portsLen));
	
	///////////////////////////////////////////////////////////////
	MSD_U8 p=0, np=0;
	while(p < portsLen)
	{
		MSD_DBG_ERROR(("p[%d]=%d\n", p, ports[p]));
		if(ingress1 == ports[p])
		{
			ports[np] = ports[++p];
		}
		p++; np++;
	}
	nportsLen = np;
	MSD_DBG_ERROR(("\n"));
	///////////////////////////////////////////////////////////////
	
	MSD_DBG_ERROR(("msdPortBasedVlanMapGet(%d) : nportsLen=%d\n", ingress1, nportsLen));
	for(MSD_U8 p=0; p<nportsLen; p++)
	{
		MSD_DBG_ERROR(("p[%d]=%d\n", p, ports[p]));
	}
	MSD_DBG_ERROR(("\n"));


	return 0;
}


