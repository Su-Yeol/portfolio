#ifndef Fir_common_h
#define Fir_common_h

#ifdef J_INC_PATH
#include "include/driver/msdApiTypes.h"
#include "include/driver/msdSysConfig.h"
#include "include/utils/msdUtils.h"
#else
#include <driver/msdApiTypes.h>
#include <driver/msdSysConfig.h>
#include <utils/msdUtils.h>
#endif

#endif
