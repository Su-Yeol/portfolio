/**********************************************************************************************
* Copyright (c) 2022 Marvell.
* All rights reserved.
* Use of this source code is governed by a BSD3 license that
* can be found in the LICENSE file and also at https://opensource.org/licenses/BSD-3-Clause
**********************************************************************************************/

/********************************************************************************
* sample_msdSysConfig.c
*
* DESCRIPTION:
*    This sample will demonstrate how to
*    1. Initialize driver for single device @ SMI single-chip mode
*    2. Initialize driver for single device @ SMI multi-chip mode
*    3. Initialize driver for single device @ RMU access mode
*    4. Initialize driver for multiple device
*
* DEPENDENCIES:   None.
*
* FILE REVISION NUMBER:
*
*******************************************************************************/
#include "sample/msdSample.h"
#include "include/driver/msdApiTypes.h"
#include "include/driver/msdSysConfig.h"

#ifdef J_DEBUG

#include <string.h>

#include <sys/socket.h>
#include <sys/ioctl.h>
#include <linux/if.h>

#include "../fir_ioc_reg.h"

const int IOCTL_CMD_STATUS_OK = 0;
const int IOCTL_CMD_STATUS_ERROR = 1;
const int IOCTL_CMD_STATUS_ERROR_INVALID_COMMAND = 2;
const int IOCTL_CMD_STATUS_ERROR_INVALID_NUM_CMDLINE_PARAMS = 3;
const int IOCTL_CMD_STATUS_ERROR_INVALID_CMDLINE_PARAMETER = 4;
const int IOCTL_CMD_STATUS_ERROR_ARGUMENT_NOT_FOUND = 5;
const int IOCTL_CMD_STATUS_ERROR_DUPLICATE_ARGUMENT = 6;
const int IOCTL_CMD_STATUS_ERROR_INVALID_DEVICE = 7;
const int IOCTL_CMD_STATUS_ERROR_TIMEOUT = 8;

uint32_t if_req_count;

int ioc_flag;
fir_ioc_reg ioc_data;

int fd;
struct ifreq ifr;

#endif

/*
 *    	sample_msdStart is the main function of this sample and customer should
 *    	register the required functions.(msdRegister API)
 *		1) readMii      -  BSP specific MII read function
 *						   (provided by BSP and required if you select SMI bus to configure DUT)
 *		2) writeMii     -  BSP specific MII write function
 *						   (provided by BSP and required if you select SMI bus to configure DUT)
 *      3) msdBspRmuTxRx -  BSP specific RMU Tx/Rx function
 *                         (provided by BSP and required if you select RMU bus to configure DUT)
 *		3) semCreate    -  OS specific semaphore create function.
 *						   (provided by BSP and required by All Device API)
 *		4) semDelete    -  OS specific semaphore delete function.
 *						   (provided by BSP and required by All Device API)
 *		5) semTake      -  OS specific semaphore take function.
 *						   (provided by BSP and required by All Device API)
 *		6) semGive      -  OS specific semaphore give function.
 *						   (provided by BSP and required by All Device API)
 */
MSD_STATUS msdBspReadMii(MSD_U8 devNum, MSD_U8 phyAddr, MSD_U8 MIIReg,
                        MSD_U16* value);
MSD_STATUS msdBspWriteMii(MSD_U8 devNum, MSD_U8 phyAddr, MSD_U8 MIIReg,
                        MSD_U16 value);

MSD_STATUS msdBspRmuTxRx(MSD_U8 *req_packet,MSD_U32 req_pktlen,MSD_U8 **rsp_packet,MSD_U32 *rsp_pktlen);

MSD_SEM osSemCreate( MSD_SEM_BEGIN_STATE state);
MSD_STATUS osSemDelete(MSD_SEM smid);
MSD_STATUS osSemWait(  MSD_SEM smid, MSD_U32 timeOut);
MSD_STATUS osSemSignal(MSD_SEM smid);


/********************************************************************************
* Sample #1: Initialize driver for single device @ SMI single-chip mode.
********************************************************************************/
MSD_STATUS qdStart_SingleDevice_SMI_SC (MSD_U8 devNum)
{
	MSD_STATUS status;
	MSD_SYS_CONFIG   cfg;
	MSD_QD_DEV       *dev;

	/* Check if device number our of range, it should be [0,31] */
	if (devNum > 31)
	{
		MSG_PRINT(("devNum %d is our of range, larger than 31. \n", devNum));
		return MSD_FAIL;
	}

    /*
     *  Register all the required functions to Driver.
    */
    msdMemSet((char*)&cfg,0,sizeof(MSD_SYS_CONFIG));

	cfg.InterfaceChannel = MSD_INTERFACE_SMI;
	cfg.devNum = devNum;		/* Device Number, 0~31 */
    cfg.baseAddr = 0;		    /* Physical Device Address. This value should be zero if the device is in single-chip mode. */

	cfg.BSPFunctions.readMii = msdBspReadMii;
    cfg.BSPFunctions.writeMii = msdBspWriteMii;
	
	/*
	* If this method been registered, the advance RMU feature (msdRMUAtuDump, msdRMUMib2Dump ...) can be used in this interface 
	* channel, the RMU setup should be done firstly, please reference the sample_msdRMU.c
	*/
	cfg.BSPFunctions.rmu_tx_rx = NULL;

#ifdef USE_SEMAPHORE
    cfg.BSPFunctions.semCreate = osSemCreate;
    cfg.BSPFunctions.semDelete = osSemDelete;
    cfg.BSPFunctions.semTake   = osSemWait;
    cfg.BSPFunctions.semGive   = osSemSignal;
#else
    cfg.BSPFunctions.semCreate = NULL;
    cfg.BSPFunctions.semDelete = NULL;
    cfg.BSPFunctions.semTake   = NULL;
    cfg.BSPFunctions.semGive   = NULL;
#endif

    if((status=msdLoadDriver(&cfg)) != MSD_OK)
    {
        MSG_PRINT(("msdLoadDriver return Failed\n"));
        return status;
    }

	dev = sohoDevGet(devNum);
	if (NULL == dev)
	{
		MSG_PRINT(("devNum %d is NULL. Driver load failed. \n", devNum));
		return MSD_FAIL;
	}
/*
	MSG_PRINT(("Device ID     : 0x%x\n",dev->deviceId));
	MSG_PRINT(("Base Reg Addr : 0x%x\n",dev->baseRegAddr));
	MSG_PRINT(("No of Ports   : %d\n",dev->numOfPorts));

	MSG_PRINT(("Driver has been started.\n"));
	MSG_PRINT(("sample_qdStart_SingleDevice_SMI_SC sample code success.\n"));
*/
	return MSD_OK;
}


/********************************************************************************
* Sample #2: Initialize driver for single device @ SMI Multi-chip mode.
********************************************************************************/
MSD_STATUS qdStart_SingleDevice_SMI_MC(MSD_U8 devNum, MSD_U8 devAddr)
{
	MSD_STATUS status;
	MSD_SYS_CONFIG   cfg;
	MSD_QD_DEV       *dev;

	/* Check if device number our of range, it should be [0,31] */
	if (devNum > 31)
	{
		MSG_PRINT(("devNum %d is our of range, larger than 31. \n", devNum));
		return MSD_FAIL;
	}

	/* Check if devAddr is non-zero */
	if (0 == devAddr)
	{
		MSG_PRINT(("devAddr is zero, only support single-chip mode. \n"));
		return MSD_FAIL;
	}

	/*
	*  Register all the required functions to Driver.
	*/
	msdMemSet((char*)&cfg, 0, sizeof(MSD_SYS_CONFIG));

	cfg.InterfaceChannel = MSD_INTERFACE_SMI_MULTICHIP;
	cfg.devNum = devNum;		/* Device Number, 0~31 */
	cfg.baseAddr = devAddr;		    /* Physical Device Address. This value should be non-zero if the device is in multi-chip mode. */

	cfg.BSPFunctions.readMii = msdBspReadMii;
	cfg.BSPFunctions.writeMii = msdBspWriteMii;

	/*
	* If this method been registered, the advance RMU feature (msdRMUAtuDump, msdRMUMib2Dump ...) can be used in this interface
	* channel, the RMU setup should be done firstly, please reference the sample_msdRMU.c
	*/
	cfg.BSPFunctions.rmu_tx_rx = NULL;

#ifdef USE_SEMAPHORE
	cfg.BSPFunctions.semCreate = osSemCreate;
	cfg.BSPFunctions.semDelete = osSemDelete;
	cfg.BSPFunctions.semTake = osSemWait;
	cfg.BSPFunctions.semGive = osSemSignal;
#else
	cfg.BSPFunctions.semCreate = NULL;
	cfg.BSPFunctions.semDelete = NULL;
	cfg.BSPFunctions.semTake = NULL;
	cfg.BSPFunctions.semGive = NULL;
#endif

	if ((status = msdLoadDriver(&cfg)) != MSD_OK)
	{
		MSG_PRINT(("msdLoadDriver return Failed\n"));
		return status;
	}

	dev = sohoDevGet(devNum);
	if (NULL == dev)
	{
		MSG_PRINT(("devNum %d is NULL. Driver load failed. \n", devNum));
		return MSD_FAIL;
	}

	MSG_PRINT(("Device ID     : 0x%x\n", dev->deviceId));
	MSG_PRINT(("Base Reg Addr : 0x%x\n", dev->baseRegAddr));
	MSG_PRINT(("No of Ports   : %d\n", dev->numOfPorts));

	MSG_PRINT(("Driver has been started.\n"));
	MSG_PRINT(("sample_qdStart_SingleDevice_SMI_MC sample code success.\n"));

	return MSD_OK;
}

/********************************************************************************
* Sample #3: Initialize driver for single device @ RMU bus.
********************************************************************************/
MSD_STATUS sample_qdStart_SingleDevice_RMU(MSD_U8 devNum)
{
	MSD_STATUS status;
	MSD_SYS_CONFIG   cfg;
	MSD_QD_DEV       *dev;

	/* Check if device number our of range, it should be [0,31] */
	if (devNum > 31)
	{
		MSG_PRINT(("devNum %d is our of range, larger than 31. \n", devNum));
		return MSD_FAIL;
	}

	/*
	*  Register all the required functions to Driver.
	*/
	msdMemSet((char*)&cfg, 0, sizeof(MSD_SYS_CONFIG));

	cfg.InterfaceChannel = MSD_INTERFACE_RMU;
	cfg.devNum = devNum;		                /* Device Number, 0~31 */
    cfg.rmuMode = MSD_RMU_ETHERT_TYPE_DSA_MODE; /* RMU mode*/
    cfg.eTypeValue = 0x9100;                    /* Ether Type value*/

	cfg.BSPFunctions.readMii = NULL;
	cfg.BSPFunctions.writeMii = NULL;

	cfg.BSPFunctions.rmu_tx_rx = msdBspRmuTxRx;

#ifdef USE_SEMAPHORE
	cfg.BSPFunctions.semCreate = osSemCreate;
	cfg.BSPFunctions.semDelete = osSemDelete;
	cfg.BSPFunctions.semTake = osSemWait;
	cfg.BSPFunctions.semGive = osSemSignal;
#else
	cfg.BSPFunctions.semCreate = NULL;
	cfg.BSPFunctions.semDelete = NULL;
	cfg.BSPFunctions.semTake = NULL;
	cfg.BSPFunctions.semGive = NULL;
#endif

	if ((status = msdLoadDriver(&cfg)) != MSD_OK)
	{
		MSG_PRINT(("msdLoadDriver return Failed\n"));
		return status;
	}

	dev = sohoDevGet(devNum);
	if (NULL == dev)
	{
		MSG_PRINT(("devNum %d is NULL. Driver load failed. \n", devNum));
		return MSD_FAIL;
	}

	MSG_PRINT(("Device ID     : 0x%x\n", dev->deviceId));
	MSG_PRINT(("Base Reg Addr : 0x%x\n", dev->baseRegAddr));
	MSG_PRINT(("No of Ports   : %d\n", dev->numOfPorts));

	MSG_PRINT(("Driver has been started.\n"));
	MSG_PRINT(("sample_qdStart_SingleDevice_RMU sample code success.\n"));

	return MSD_OK;
}

/********************************************************************************
* Sample #4: Initialize driver for multi device @ SMI Multi-chip mode.
********************************************************************************/
MSD_STATUS sample_qdStart_MultiDevice_SMI_MC(MSD_U8 numOfDevice)
{
	MSD_STATUS status;
	MSD_SYS_CONFIG   cfg;
	MSD_QD_DEV       *dev;
	MSD_U8	i;

	/* Maximum support 32 devices */
	if (numOfDevice > 32)
	{
		MSG_PRINT(("numOfDevice %d is our of range, larger than 32. \n", numOfDevice));
		return MSD_FAIL;
	}

	/*
	*  Register all the required functions to Driver. 
	*  Here supporse all device share the same hardware access bus: SMI Multi-chip access mode!
	*/
	for (i = 0; i < numOfDevice; i++)
	{
		MSG_PRINT(("\n------- Init Device Number %u -------\n", i));

		msdMemSet((char*)&cfg, 0, sizeof(MSD_SYS_CONFIG));

		cfg.InterfaceChannel = MSD_INTERFACE_SMI_MULTICHIP;
		cfg.devNum = i;		           /* Device Number, 0~31 */
		cfg.baseAddr = (i + 1);		   /* Physical Device Address. This value should be non-zero if the device is in multi-chip mode. */

		cfg.BSPFunctions.readMii = msdBspReadMii;
		cfg.BSPFunctions.writeMii = msdBspWriteMii;

		/*
		* If this method been registered, the advance RMU feature (msdRMUAtuDump, msdRMUMib2Dump ...) can be used in this interface
		* channel, the RMU setup should be done firstly, please reference the sample_msdRMU.c
		*/
		cfg.BSPFunctions.rmu_tx_rx = NULL;

#ifdef USE_SEMAPHORE
		cfg.BSPFunctions.semCreate = osSemCreate;
		cfg.BSPFunctions.semDelete = osSemDelete;
		cfg.BSPFunctions.semTake = osSemWait;
		cfg.BSPFunctions.semGive = osSemSignal;
#else
		cfg.BSPFunctions.semCreate = NULL;
		cfg.BSPFunctions.semDelete = NULL;
		cfg.BSPFunctions.semTake = NULL;
		cfg.BSPFunctions.semGive = NULL;
#endif

		if ((status = msdLoadDriver(&cfg)) != MSD_OK)
		{
			MSG_PRINT(("msdLoadDriver return Failed\n"));
			return status;
		}

		dev = sohoDevGet(i);
		if (NULL == dev)
		{
			MSG_PRINT(("devNum %d is NULL. Driver load failed. \n", i));
			return MSD_FAIL;
		}

		MSG_PRINT(("Device ID     : 0x%x\n", dev->deviceId));
		MSG_PRINT(("Base Reg Addr : 0x%x\n", dev->baseRegAddr));
		MSG_PRINT(("No of Ports   : %d\n", dev->numOfPorts));
		MSG_PRINT(("DevNum %u driver has been started.\n", i));
	}

	MSG_PRINT(("sample_qdStart_MultiDevice_SMI_MC sample code success.\n"));

	return MSD_OK;
}

/* 
Software Customization and Usage:
No matter chip is in single-chip mode or multi-chip mode, user should implement the basic MDC/MDIO register R/W functions.
*/

#ifdef J_DEBUG

int SetDevice(void) 
{
	char *if_name = "eth1";

	fd = socket(AF_INET, SOCK_DGRAM, 0);

	ifr.ifr_addr.sa_family = AF_INET;

//	MSG_PRINT(("SetDevice: %d, %d\n", strlen(dev), sizeof(ifr.ifr_name)));
	if (strlen(if_name) < sizeof(ifr.ifr_name)) {
		strcpy(ifr.ifr_name, if_name) ;
		return 1;
	}
	return 0;
}

int Ioctl(int cmd, caddr_t data) 
{
	int rc = -1 ;

	if (fd != -1) {
		ifr.ifr_data = (caddr_t) data;
		rc = ioctl(fd, cmd, (caddr_t) &ifr);
		if (rc != 0) {
			rc = IOCTL_CMD_STATUS_ERROR ;
		}
	}
	else {
		rc = IOCTL_CMD_STATUS_ERROR ;
	}

	return (rc) ; 
}

int WriteIO(MSD_U8 devNum, MSD_U8 phyAddr, MSD_U8 MIIReg, MSD_U16 value) 
{
	int ioc_cmd = FIR_IOCTL_REG_ESU_REQ; 

	ioc_data.error = -1;
	ioc_data.cmd = FIR_IOCTL_REG_WR;
	ioc_data.dev_no = devNum;
	ioc_data.offs = 0x60000 | MIIReg;
	ioc_data.data = value;

//	MSG_PRINT(("WriteIO : value=0x%x, data=0x%x\n", value, ioc_data.data));

	return (Ioctl(ioc_cmd, (caddr_t) &ioc_data)); 
}

int ReadIO(MSD_U8 devNum, MSD_U8 phyAddr, MSD_U8 MIIReg, MSD_U16* value) 
{
	int ioc_cmd = FIR_IOCTL_REG_ESU_REQ; 
	int err = IOCTL_CMD_STATUS_ERROR;
	MSD_U16 _value;

	ioc_data.error = -1;
	ioc_data.cmd = FIR_IOCTL_REG_RD;
	ioc_data.dev_no = devNum;
	ioc_data.offs = 0x60000 | MIIReg;

	err = Ioctl(ioc_cmd, (caddr_t) &ioc_data);

	_value = (MSD_U16) ioc_data.data;
	*value = _value;

//	MSG_PRINT(("ReadIO : data=0x%x, _value=0x%x, *value=0x%x\n", ioc_data.data, _value, *value));

	return err;
 }

#endif

/*****************************************************************************
*
* TODO by customers
*/
MSD_STATUS msdBspReadMii(MSD_U8 devNum, MSD_U8 phyAddr, MSD_U8 MIIReg,
                        MSD_U16* value)
{

#ifdef J_DEBUG

	uint32_t count = 0;
	int err = IOCTL_CMD_STATUS_ERROR;

	ioc_flag = 0 ;
	if_req_count = 0 ;

	count = if_req_count;

	if (SetDevice()) 
	{

#ifdef J_DEBUG
		for(int i=0; i<100; i++)
		{
			usleep(100);
			if((err = ReadIO(devNum, phyAddr, MIIReg, value)) == 0)
			{
				return MSD_OK;
			} 
		}
		return MSD_FAIL;
#else

		if((err = ReadIO(devNum, phyAddr, MIIReg, value)) == 0)
		{
#ifdef J_DEBUG
//			MSG_PRINT(("msdBspReadMii : phyAddr=0x%x, MIIReg=0x%x ==> data: 0x%x\n", phyAddr, MIIReg, ioc_data.data));
#endif
			return MSD_OK;
		} 
		else
		{
			MSG_PRINT(("msdBspReadMii : error=%d\n", ioc_data.error));
			return MSD_FAIL;
		}

#endif 

	} 
	else
	{
		return MSD_FAIL;
	}

#else

	/* TODO  */
    /*****************************************************************************************
    *   General hardware access function implementation depends on platform                  *
    *   Take Marvell USB2SMI adapter for example                                             *
    *   Using SMI MDIO protocol:                                                             *
    *       *value = MDIOReadRegister(usbport, phyAddr, MIIReg);                             *
    *   or XMDIO protocol (only amethyst support, devAddr default fixed as 3                 *
    *   and register has one 0x8000 offset)                                                  *
    *       *value = XMDIOReadRegister(usbport, phyAddr, 3, MIIReg | 0x8000);                *            
    ******************************************************************************************/

	return MSD_OK;

#endif
}

/*****************************************************************************
*
* TODO by customers
*/
MSD_STATUS msdBspWriteMii(MSD_U8 devNum, MSD_U8 phyAddr, MSD_U8 MIIReg,
                        MSD_U16 value)
{
#ifdef J_DEBUG

	uint32_t count = 0;
	int err = IOCTL_CMD_STATUS_ERROR;

#ifdef J_DEBUG
//	MSG_PRINT(("msdBspWriteMii : devNum=0x%x, phyAddr=0x%x, MIIReg=0x%x, value=0x%x\n", devNum, phyAddr, MIIReg, value));
#endif

	ioc_flag = 0 ;
	if_req_count = 0 ;

	count = if_req_count;

	if (SetDevice()) 
	{
		if((err = WriteIO(devNum, phyAddr, MIIReg, value)) == 0)
		{
#ifndef J_DEBUG 
			MSG_PRINT(("ioc_data.error: %d\n", ioc_data.error));
#endif
			return MSD_OK;
		} 
		else
		{
			return MSD_FAIL;
		}
	} 
	else
	{
		return MSD_FAIL;
	}	
#else

	/* TODO  */
    /*****************************************************************************************
    *   General hardware access function implementation depends on platform                  *
    *   Take Marvell USB2SMI adapter for example                                             *
    *   Using SMI MDIO protocol:                                                             *
    *       MDIOWriteRegister(usbport, phyAddr, MIIReg, value);                              *
    *   or XMDIO protocol (only amethyst support, devAddr default fixed as 3                 *
    *   and register has one 0x8000 offset)                                                  *
    *       XMDIOWriteRegister(usbport, phyAddr, 3, MIIReg | 0x8000, value);                 *
    ******************************************************************************************/
	return MSD_OK;

#endif
}

/*
Software Customization and Usage:
Our Driver Suite has defined abstract register R/W functions and semaphore functions and will provide them to upper applications.
But, for the detail implementation, it's Platform-Dependent, needs to be provided by customer themselves.
For general hardware access function here we define the low-level APIs (readMii, writeMii), 
customer should implement and register it based on the access interface:
SMI (no matter chip is in single chip mode or multi-chip mode);
Otherwise customers need to implement low-level API (rmu_tx_rx) if the access interface is through RMU.
*/
/* 
Software Customization and Usage:
This routine sens the raw RMU request frame and then waits to receive related raw L2 RMU response frame.
It's the responsibility for upper UMSD driver to package RMU request frame's payload (depends on different RMU commands).
For this API impementation, user needs to:
 1. Override RMU request frame's source MAC address with the CPU's MAC address.
  When RMU request frame is packed in upper UMSD driver layer, it has no idea about the outside CPU's MAC address,
  and then it fills in the RMU request frame's source MAC address to be 00:00:00:00:00, waiting to be overridden by upper application.
 2. Filter dummy Ethernet frames, and receive the RMU response frame.
  The rules to find out the correct RMU response is:
   1) Check if the incoming packet's DA MAC == CPU MAC
   2) Check if the incoming packet's tag value matches the format of RMU Response frame.
   3) Check if rsp_pkt Src_Dev == req_pkt Trg_Dev
   4) Check if rsp_pkt SeqNum == req_pkt SeqNum
   5) Check if rsp_pkt Format/Code == req_pkt Format/Code
   Please refer to register spec for the detail RMU Request/Response Frame information.
*/

/*****************************************************************************
*
* TODO by customers
*
* Description: 
*     This API is used to send RMU request and receive related RMU response frame.
*     Here is the detail requirement:
*     1) Update req_packet byte array, then send out packet
*        Override SA in req_packet with current CPU's source MAC address
*     2) Filter incoming ethernet packets and find our the right RMU response frame.       
*        req_packet: SA = CPU Mac, From_DSA_Tag: Trg_Dev+SeqNum
*        rsp_packet: DA = CPU Mac, To_DSA_Tag: Src_Dev+SeqNum
*        Check:
*          a) rsp_packet DA == CPU Mac
*          b) rsp_packet Src_Dev == req_packet Trg_Dev
*          c) rsp_packet SeqNum == req_packet SeqNum
*          d) rsp_packet RMU Format/Code = req_packet RMU Format/Code
*        If not match, return failed with empty resp packets length!
*
*/
MSD_STATUS msdBspRmuTxRx
(
	MSD_U8 *req_packet,
	MSD_U32 req_pktlen,
	MSD_U8 **rsp_packet,
	MSD_U32 *rsp_pktlen
)
{
	/* TODO  */
	return MSD_OK;
	}

/* 
Software Customization and Usage:
The readMii and writeMii or rmu_tx_rx functions are required based on the selected access interface before using any of the MS APIs:
However, semaphore related functions are OPTIONAL.
In the UMSD Suite, semaphores are used for accesses of the MAC Address Table (msdBrgFdb.c), 802.1Q VLAN Table (msdBrgVtu.c),
RMON Counter Table (msdPortRmon.c), PIRL Resource (msdPIRL.c), and SMI Access on Multi-Chip Addressing mode (msdHwAccess.c).
Therefore, if only one task is accessing any one of the above features at a given time, none of the optional semaphore functions are required.
*/
/*****************************************************************************
*
* TODO by customers
*/
MSD_SEM osSemCreate( MSD_SEM_BEGIN_STATE state)
{
	/* TODO  */
	return 1;
}

/*****************************************************************************
*
* TODO by customers
*/
MSD_STATUS osSemDelete(MSD_SEM smid)
{
	/* TODO  */
	return MSD_OK;
}

/*****************************************************************************
*
* TODO by customers
*/
MSD_STATUS osSemWait(  MSD_SEM smid, MSD_U32 timeOut)
{
	/* TODO  */
	return MSD_OK;
}

/*****************************************************************************
*
* TODO by customers
*/
MSD_STATUS osSemSignal(MSD_SEM smid)
{
	/* TODO  */
	return MSD_OK;
}

