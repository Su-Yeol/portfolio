#include "../include/driver/eth3/eth3_msdSysConfig.h"
#include "../include/msdApi.h"
#include "../dev/fir/include/driver/Fir_msdDrvSwRegs.h"


MSD_STATUS initialzeDrivers(MSD_LPORT ingress, MSD_LPORT egress1, MSD_LPORT egress2) 
{
	MSD_STATUS status;

/*
	if((status = qdStart_SingleDevice_SMI_SC(FIR_PORT_START_ADDR)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", FIR_PORT_START_ADDR));
		return status;
	} 
*/

	if((status = qdStart_SingleDevice_SMI_SC(ingress)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", ingress));
		return status;
	}

	if((status = qdStart_SingleDevice_SMI_SC(egress1)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", egress1));
		return status;
	}

	if((status = qdStart_SingleDevice_SMI_SC(egress2)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", egress2));
		return status;
	}

	if((status = qdStart_SingleDevice_SMI_SC(FIR_GLOBAL1_DEV_ADDR)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", FIR_GLOBAL1_DEV_ADDR));
		return status;
	} 

	if((status = qdStart_SingleDevice_SMI_SC(FIR_GLOBAL2_DEV_ADDR)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", FIR_GLOBAL2_DEV_ADDR));
		return status;
	} 

	if((status = qdStart_SingleDevice_SMI_SC(FIR_TCAM_DEV_ADDR)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", FIR_TCAM_DEV_ADDR));
		return status;
	} 

	return status;
}


MSD_STATUS getPortBasedVlanMap(MSD_LPORT ingress1, MSD_LPORT ingress2) 
{
	MSD_STATUS status;
	MSD_LPORT ports[10]; // TODO: 10 -> dev.numOfPorts 
	MSD_U8 portsLen;

	if ((status = msdPortBasedVlanMapGet(ingress1, ingress1, ports, &portsLen)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPortBasedVlanMapGet returned fail. port# = %d\n", ingress1));
		return status;
	}
	else
	{
		MSD_DBG_INFO(("msdPortBasedVlanMapGet(%d) : portsLen=%d", ingress1, portsLen));
		for(MSD_U8 p=0; p<portsLen; p++) 
		{
			MSD_DBG_INFO((", p[%d]=%d", p, ports[p]));
		}
		MSD_DBG_INFO(("\n"));
	}

	if ((status = msdPortBasedVlanMapGet(ingress2, ingress2, ports, &portsLen)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPortBasedVlanMapGet returned fail. port# = %d\n", ingress1));
		return status;
	}
	else
	{
		MSD_DBG_INFO(("msdPortBasedVlanMapGet(%d) : portsLen=%d", ingress2, portsLen));
		for(MSD_U8 p=0; p<portsLen; p++) 
		{
			MSD_DBG_INFO((", p[%d]=%d", p, ports[p]));
		}
		MSD_DBG_INFO(("\n"));
	}

	return status;
}


MSD_STATUS addVlanEntry(MSD_LPORT ingress1, MSD_LPORT ingress2, MSD_LPORT egress) 
{
	MSD_STATUS status;
	MSD_VTU_ENTRY vtuEntry;
	MSD_QD_DEV* dev;

	dev = sohoDevGet(FIR_GLOBAL1_DEV_ADDR);

	if (NULL == dev)
	{
		MSD_DBG_ERROR(("Dev is NULL for devNum %d.\n", dev->devNum));
		return MSD_FAIL;
	}

  if ((status = msdVlanAllDelete(dev->devNum)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdVlanAllDelete returned fail.\n"));
		return status;
	}

	vtuEntry.fid = 2;
	vtuEntry.vid = 5;
	vtuEntry.sid = 0;

	for(int i=0; i<dev->numOfPorts; i++)
	{
		vtuEntry.memberTagP[i] = 3;
	}
	vtuEntry.memberTagP[ingress1] = 2;
	vtuEntry.memberTagP[ingress2] = 2;
	vtuEntry.memberTagP[egress] = 2;

	vtuEntry.vidPolicy = MSD_FALSE;  /* VID Policy bit.*/
	vtuEntry.vidExInfo.useVIDFPri = MSD_FALSE; /* If device doesnot support VTU Frame Priority override, this field is ignored. */
	vtuEntry.vidExInfo.vidFPri = 0;           /* If device doesnot support VTU Frame Priority override, this field is ignored. */
	vtuEntry.vidExInfo.useVIDQPri = MSD_FALSE; /* If device doesnot support VTU Queue Priority override, this field is ignored. */
 	vtuEntry.vidExInfo.vidQPri = 0;           /* If device doesnot support VTU Queue Priority override, this field is ignored. */
	vtuEntry.vidExInfo.dontLearn = MSD_FALSE;  /* Do not learn the MAC address */
	vtuEntry.vidExInfo.filterUC = MSD_FALSE;  /* Determine whether or not to filter unicast frame */
	vtuEntry.vidExInfo.filterBC = MSD_FALSE;   /* Determine whether or not to filter broadcast frame */
	vtuEntry.vidExInfo.filterMC = MSD_FALSE;   /* Determine whether or not to filter multicast frame */

	if ((status = msdVlanEntryAdd(dev->devNum, &vtuEntry)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdVlanEntryAdd returned fail.\n"));
	}

	return status;
}


MSD_STATUS addMacEntry(MSD_QD_DEV* dev, MSD_LPORT ingress) 
{
	MSD_STATUS status;
	MSD_ATU_ENTRY macEntry;

	if ((status = msdFdbAllDelete(dev->devNum, MSD_FLUSH_ALL)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdFdbAllDelete returned fail.\n"));
		return status;
	}

	macEntry.macAddr.arEther[0] = 0x00;
	macEntry.macAddr.arEther[1] = 0x22;
	macEntry.macAddr.arEther[2] = 0x22;
	macEntry.macAddr.arEther[3] = 0x22;
	macEntry.macAddr.arEther[4] = 0x22;
	macEntry.macAddr.arEther[5] = 0x22;

	macEntry.trunkMemberOrLAG = 0;  /* No trunk. */

	macEntry.portVec = 1 << ingress;     /* Set the portVector matching with Port 6, the frame with DA as above address will be forwarded to port 2. */

	macEntry.fid = 0;	/* Refer to the fid of VLAN entry ! */
	macEntry.entryState = 0xE;      /* Static entry. */
	macEntry.exPrio.macFPri = 0;    /* If device doesnot support MAC Frame Priority override, this field is ignored. */
	macEntry.exPrio.macQPri = 0;    /* If device doesnot support MAC Queue Priority override, this field is ignored. */

	if ((status = msdFdbMacEntryAdd(dev->devNum, &macEntry)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdFdbMacEntryAdd returned fail.\n"));
	}

	return status;
}


MSD_STATUS setTcamIngressSingle(MSD_LPORT ingress1, MSD_LPORT ingress2, MSD_LPORT egress)
{
	MSD_STATUS     status;

	MSD_U32        IgrTcamPointer = 0;
	MSD_TCAM_DATA  IgrTcamData;

	MSD_U32 EgrTcamPointer = 0xf;
	MSD_TCAM_EGR_DATA EgrTcamData1;
	MSD_TCAM_EGR_DATA EgrTcamData2;

	MSD_LPORT port;
	MSD_TCAM_MODE tcamMode;

	MSD_QD_DEV *dev = sohoDevGet(FIR_TCAM_DEV_ADDR);
	if (dev == NULL)
	{
		MSD_DBG_ERROR(("Failed. Dev is Null.\n"));
		return MSD_FAIL;
	}

	if (MSD_TOPAZ == dev->devName)
	{
		return MSD_NOT_SUPPORTED;
	}

	tcamMode = MSD_TCAM_MODE_ENABLE_48; /* enable 48 bytes match tcam mode, single entry match */

	if ((status = msdPortTcamModeSet(ingress1, ingress1, tcamMode)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPortTcamModeSet returned fail.\n"));
		return status;
	}

	if ((status = msdPortTcamModeSet(ingress2, ingress2, tcamMode)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPortTcamModeSet returned fail.\n"));
		return status;
	}

	/*
	 *    Flush all entries for both ingress and egress TCAM table
	 */
/*
	if ((status = msdTcamAllDelete(devNum)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdTcamAllDelete returned fail.\n"));
		return status;
	}
*/

	/*
	 *    Initialize and load the Ingress TCAM Entry
	 */
	msdMemSet(&IgrTcamData,0,sizeof(MSD_TCAM_DATA)); /* Set all bit to 0 by default */

	IgrTcamData.spvMask = 0x3ff; // 11 1111 1111
	IgrTcamData.spvMask ^= 1 << ingress1;
	IgrTcamData.spvMask ^= 1 << ingress2;
	IgrTcamData.spv = 0;

	IgrTcamData.frameOctetMask[1] = 0xff;
	IgrTcamData.frameOctet[1] = 0x22;

	IgrTcamData.frerSctrInc = 1;
	IgrTcamData.frerSctrIndex = 0xf;

	IgrTcamData.frerSeqEncType = 1;
	IgrTcamData.frerSeqRcvyEn = 1;
	IgrTcamData.frerSeqRcvyIndex = 0xf;
	
	if ((status = msdTcamEntryAdd(dev->devNum, IgrTcamPointer, &IgrTcamData)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdTcamEntryAdd returned fail.\n"));
		return status;
	}

	return MSD_OK;
}


MSD_STATUS setQueueCtrl(MSD_LPORT ingress, MSD_LPORT egress) 
{
	MSD_STATUS status;
	MSD_U8 pointer = 0x0; // Port Schedule @ Table 122 
	MSD_PORT_SCHED_MODE schedule = MSD_PORT_SCHED_WRR_PRI4_3_2_1_0;
	MSD_U8 sch = (MSD_U8) schedule;

	if ((status = msdPortQueueCtrlSet(egress, egress, pointer, sch)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPortQueueCtrlSet returned fail.\n"));
		return status;
	}

	return status;
}


MSD_STATUS setAVBPolicy(void) 
{
	MSD_STATUS status;
	MSD_U16 data;
	MSD_U8 avbPolicyBlock = 0x1;

	// AVB Policy (TSN Block = 0x01)
	data = 0x3322;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, avbPolicyBlock, 0x1F, 0x0, data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	// AVB Policy (TSN Block = 0x01)
	data = 0x0000;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, avbPolicyBlock, 0x1F, 0x4, data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	// AVB Policy (TSN Block = 0x01)
	data = 0x8000;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, 
		avbPolicyBlock,
#ifdef J_DEBUG
		2, 
#else
		ingress,
#endif
		0x0, 
		data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	} 

	return status;
}


MSD_STATUS setQavTable(void) 
{
	MSD_STATUS status;
	MSD_U16 data;
 	MSD_U8 qavBlock = 0x2;


	// Qav (TSN Block = 0x10)
	data = 0x0064;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, qavBlock, 0x1F, 0x1, data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	// Qav (TSN Block = 0x10)
	data = 0x8064;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, qavBlock, 0x1F, 0x0, data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	// Qav (TSN Block = 0x10)
	data = 0x0509;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, 
		qavBlock,
#ifdef J_DEBUG
		6, 
#else
		egress,
#endif
		4,
		data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	return status;
}


MSD_STATUS setSeqRcvy(MSD_LPORT egress)
{
	MSD_STATUS status;
	MSD_FRER_SEQRCVY seqRcvyData;
	MSD_FRER_BANK1_CONFIG bk1ConfigData;

	MSD_U8 devNum = FIR_GLOBAL2_DEV_ADDR;

	/*
	*    Flush all sequence recovery instance.
	*/
/*
	if ((status = msdFrerSeqRcvyFlushAll(devNum)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdFrerSeqRcvyFlushAll returned fail.\n"));
		return status;
	}
*/
	/*
	*    Configure sequence recovery instance.
	*/
	msdMemSet(&seqRcvyData,0,sizeof(MSD_FRER_SEQRCVY)); /* Set all bit to 0 by default */
	seqRcvyData.seqRcvyEn = 0x1;
	seqRcvyData.seqRcvyPort = egress;
	seqRcvyData.seqRcvyIndex = 0xf;
	seqRcvyData.seqRcvyAlg = 0x1;

	if ((status = msdFrerSeqRcvyLoad(devNum, &seqRcvyData)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdFrerSeqRcvyLoad returned fail.\n"));
		return status;
	}

	/*
	*    Flush all bank 1 configurations and counters.
	*/
	if ((status = msdFrerBank1SCtrFlushAll(devNum)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdFrerBank1SCtrFlushAll returned fail.\n"));
		return status;
	}

	/*
	*     Configure bank 1 stream counters.
	*/
	msdMemSet(&bk1ConfigData,0,sizeof(MSD_FRER_BANK1_CONFIG)); /* Set all bit to 0 by default */
	bk1ConfigData.bk1SCtrId = 0xf; /* bank 1 stream counter id = 2 */
	bk1ConfigData.bk1SCtrEn = 0x1; /* enable bank 1 stream counter */
	bk1ConfigData.bk1SCtrPort = egress; /* counter port 3 frames */
	bk1ConfigData.bk1SCtrIndex = 0xf; /*bank 0 stream counter index = 2 */
	if ((status = msdFrerBank1SCtrLoad(devNum, &bk1ConfigData)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdFrerBank1SCtrLoad returned fail.\n"));
		return status;
	}

	return status;
}


int main(int argc, char **argv) 
{
	MSD_STATUS status;
	MSD_LPORT ingress1, ingress2, egress;

	msdDbgLvlSet(MSD_DBG_ALL_LVL);

#ifdef J_DEBUG
	if(argc != 3) {
		MSD_DBG_ERROR(("Unexpected number of arguments\n"));
		MSD_DBG_ERROR(("Usage : tsnCfg_8021CB_listener <ingress port 1> <ingress port 2>\n"));
		return 0;
	} 
	
	ingress1 = atoi(argv[1]);
	ingress2 = atoi(argv[2]);
#else
	ingress1 = 0x2; 
	ingress2 = 0x3;
#endif

	egress = 0x9;

	initialzeDrivers(ingress1, ingress2, egress);

  if ((status = getPortBasedVlanMap(ingress1, ingress2)) != MSD_OK)
	{
		MSD_DBG_ERROR(("getPortBasedVlanMap returned fail.\n"));
		return status;
	}


  if ((status = addVlanEntry(ingress1, ingress2, egress)) != MSD_OK)
	{
		MSD_DBG_ERROR(("addVlanEntry returned fail.\n"));
		return status;
	}

	if ((status = setTcamIngressSingle(ingress1, ingress2, egress)) != MSD_OK)
	{
		MSD_DBG_ERROR(("setTcamIngressSingle returned fail.\n"));
		return status;
	} 

	if ((status = setSeqRcvy(egress)) != MSD_OK)
	{
		MSD_DBG_ERROR(("setSeqRcvy returned fail.\n"));
		return status;
	} 

	return 0;
}


