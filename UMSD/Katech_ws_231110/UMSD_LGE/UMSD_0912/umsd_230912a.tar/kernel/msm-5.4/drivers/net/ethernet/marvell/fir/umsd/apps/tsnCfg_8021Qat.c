#include <stdio.h>
#include <errno.h>

#include "../include/driver/eth3/eth3_msdSysConfig.h"
#include "../include/msdApi.h"
#include "../dev/fir/include/driver/Fir_msdDrvSwRegs.h"


MSD_STATUS initialzeDrivers(MSD_LPORT ingress, MSD_LPORT egress) 
{
	MSD_STATUS status;

	if((status = qdStart_SingleDevice_SMI_SC(FIR_PORT_START_ADDR)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", FIR_PORT_START_ADDR));
		return status;
	} 

	if((status = qdStart_SingleDevice_SMI_SC(ingress)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", ingress));
		return status;
	}

	if((status = qdStart_SingleDevice_SMI_SC(egress)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", egress));
		return status;
	}


	if((status = qdStart_SingleDevice_SMI_SC(FIR_GLOBAL1_DEV_ADDR)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", FIR_GLOBAL1_DEV_ADDR));
		return status;
	} 

	if((status = qdStart_SingleDevice_SMI_SC(FIR_GLOBAL2_DEV_ADDR)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", FIR_GLOBAL2_DEV_ADDR));
		return status;
	} 

	if((status = qdStart_SingleDevice_SMI_SC(FIR_TCAM_DEV_ADDR)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", FIR_TCAM_DEV_ADDR));
		return status;
	} 

	return status;
}


MSD_STATUS addVlanEntry(MSD_QD_DEV* dev, MSD_LPORT ingress, MSD_LPORT egress) 
{
	MSD_STATUS status;
	MSD_VTU_ENTRY vtuEntry;

  if ((status = msdVlanAllDelete(dev->devNum)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdVlanAllDelete returned fail.\n"));
		return status;
	}

	vtuEntry.fid = 1;
	vtuEntry.vid = 1;
	vtuEntry.sid = 0;

	for(int i=0; i<dev->numOfPorts; i++)
	{
		vtuEntry.memberTagP[i] = 3;
	}
	vtuEntry.memberTagP[ingress] = 2;
	vtuEntry.memberTagP[egress] = 2;

	vtuEntry.vidPolicy = MSD_FALSE;  /* VID Policy bit.*/
	vtuEntry.vidExInfo.useVIDFPri = MSD_FALSE; /* If device doesnot support VTU Frame Priority override, this field is ignored. */
	vtuEntry.vidExInfo.vidFPri = 0;           /* If device doesnot support VTU Frame Priority override, this field is ignored. */
	vtuEntry.vidExInfo.useVIDQPri = MSD_FALSE; /* If device doesnot support VTU Queue Priority override, this field is ignored. */
 	vtuEntry.vidExInfo.vidQPri = 0;           /* If device doesnot support VTU Queue Priority override, this field is ignored. */
	vtuEntry.vidExInfo.dontLearn = MSD_FALSE;  /* Do not learn the MAC address */
	vtuEntry.vidExInfo.filterUC = MSD_FALSE;  /* Determine whether or not to filter unicast frame */
	vtuEntry.vidExInfo.filterBC = MSD_FALSE;   /* Determine whether or not to filter broadcast frame */
	vtuEntry.vidExInfo.filterMC = MSD_FALSE;   /* Determine whether or not to filter multicast frame */

	if ((status = msdVlanEntryAdd(dev->devNum, &vtuEntry)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdVlanEntryAdd returned fail.\n"));
	}

	return status;
}


MSD_STATUS addMacEntry(MSD_QD_DEV* dev) 
{
	MSD_STATUS status;
	MSD_ATU_ENTRY macEntry;

	if ((status = msdFdbAllDelete(dev->devNum, MSD_FLUSH_ALL)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdFdbAllDelete returned fail.\n"));
		return status;
	}

	macEntry.macAddr.arEther[0] = 0x00;
	macEntry.macAddr.arEther[1] = 0x00;
	macEntry.macAddr.arEther[2] = 0x5A;
	macEntry.macAddr.arEther[3] = 0x1D;
	macEntry.macAddr.arEther[4] = 0x13;
	macEntry.macAddr.arEther[5] = 0x2E;

	macEntry.trunkMemberOrLAG = 0;  /* No trunk. */

	macEntry.portVec = 1 << 6;     /* Set the portVector matching with Port 6, the frame with DA as above address will be forwarded to port 2. */

	macEntry.fid = 1;	/* Refer to the fid of VLAN entry ! */
	macEntry.entryState = 0xB;      /* Static entry. */
	macEntry.exPrio.macFPri = 0;    /* If device doesnot support MAC Frame Priority override, this field is ignored. */
	macEntry.exPrio.macQPri = 2;    /* If device doesnot support MAC Queue Priority override, this field is ignored. */

	if ((status = msdFdbMacEntryAdd(dev->devNum, &macEntry)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdFdbMacEntryAdd returned fail.\n"));
	}

	return status;
}


MSD_STATUS set8021qMode(MSD_LPORT ingress, MSD_LPORT egress) 
{
	MSD_STATUS status;

	if ((status = msdPort8021qModeSet(ingress, ingress, MSD_8021Q_CHECK)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPort8021qModeSet returned fail.\n"));
		return status;
	}

	if ((status = msdPort8021qModeSet(egress, egress, MSD_8021Q_CHECK)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPort8021qModeSet returned fail.\n"));
		return status;
	}

	return status;
}


MSD_STATUS setQueueCtrl(MSD_LPORT ingress, MSD_LPORT egress) 
{
	MSD_STATUS status;
	MSD_U8 pointer = 0x0; // Port Schedule @ Table 122 
	MSD_PORT_SCHED_MODE schedule = MSD_PORT_SCHED_WRR_PRI4_3_2_1_0;
	MSD_U8 sch = (MSD_U8) schedule;

	if ((status = msdPortQueueCtrlSet(egress, egress, pointer, sch)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPortQueueCtrlSet returned fail.\n"));
		return status;
	}

	return status;
}


MSD_STATUS setAVBPolicy(void) 
{
	MSD_STATUS status;
	MSD_U16 data;
	MSD_U8 avbPolicyBlock = 0x1;

	// AVB Policy (TSN Block = 0x01)
	data = 0x3322;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, avbPolicyBlock, 0x1F, 0x0, data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	// AVB Policy (TSN Block = 0x01)
	data = 0x0000;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, avbPolicyBlock, 0x1F, 0x4, data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	// AVB Policy (TSN Block = 0x01)
	data = 0x8000;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, 
		avbPolicyBlock,
#ifdef J_DEBUG
		2, 
#else
		ingress,
#endif
		0x0, 
		data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	} 

	return status;
}


MSD_STATUS setQavTable(void) 
{
	MSD_STATUS status;
	MSD_U16 data;
 	MSD_U8 qavBlock = 0x2;


	// Qav (TSN Block = 0x10)
	data = 0x0064;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, qavBlock, 0x1F, 0x1, data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	// Qav (TSN Block = 0x10)
	data = 0x8064;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, qavBlock, 0x1F, 0x0, data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	// Qav (TSN Block = 0x10)
	data = 0x0509;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, 
		qavBlock,
#ifdef J_DEBUG
		6, 
#else
		egress,
#endif
		4,
		data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	return status;
}


int main(int argc, char **argv) 
{
	MSD_STATUS status;
	MSD_QD_DEV* dev;
	MSD_LPORT ingress, egress;

	if(argc != 3)
	{
		fprintf(stderr, "\nusage: tsnCfg_8021Qat <ingress-port#> <egress-port#>\n Ex. tsnCfg_8021Qat 2 6\n\n");
		exit(1);
	}

	ingress = (MSD_LPORT) atoi(argv[1]);
	egress = (MSD_U8) atoi(argv[2]);

	MSD_DBG_INFO((" ==> tsnCfg_8021Qat %d %d \n", ingress, egress));

//	ingress = 0x2; 
//	egress = 0x6;

	msdDbgLvlSet(MSD_DBG_ALL_LVL);

	initialzeDrivers(ingress, egress);

	dev = sohoDevGet(FIR_GLOBAL1_DEV_ADDR);

	if (NULL == dev)
	{
		MSD_DBG_ERROR(("Dev is NULL for devNum %d.\n", FIR_GLOBAL1_DEV_ADDR));
		return MSD_FAIL;
	}

  if ((status = addVlanEntry(dev, ingress, egress)) != MSD_OK)
	{
		MSD_DBG_ERROR(("addVlanEntry returned fail.\n"));
		return status;
	}

  if ((status = addMacEntry(dev)) != MSD_OK)
	{
		MSD_DBG_ERROR(("addMacEntry returned fail.\n"));
		return status;
	}	

  if ((status = set8021qMode(ingress, egress)) != MSD_OK)
	{
		MSD_DBG_ERROR(("set8021qMode returned fail.\n"));
		return status;
	}

  if ((status = setQueueCtrl(ingress, egress)) != MSD_OK)
	{
		MSD_DBG_ERROR(("setQueueCtrl returned fail.\n"));
		return status;
	}

  if ((status = setAVBPolicy()) != MSD_OK)
	{
		MSD_DBG_ERROR(("setAVBPolicy returned fail.\n"));
		return status;
	}

  if ((status = setQavTable()) != MSD_OK)
	{
		MSD_DBG_ERROR(("setQavTable returned fail.\n"));
		return status;
	}

	return 0;
}


