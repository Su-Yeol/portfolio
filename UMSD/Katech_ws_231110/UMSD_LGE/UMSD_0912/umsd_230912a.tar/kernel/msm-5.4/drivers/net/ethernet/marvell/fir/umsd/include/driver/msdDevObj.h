/**********************************************************************************************
* Copyright (c) 2022 Marvell.
* All rights reserved.
* Use of this source code is governed by a BSD3 license that
* can be found in the LICENSE file and also at https://opensource.org/licenses/BSD-3-Clause
**********************************************************************************************/

/********************************************************************************
* msdDevObj.h
*
* DESCRIPTION:
*       API/Structure definitions for Marvell Device Object initialize.
*
* DEPENDENCIES:
*       None.
*
* FILE REVISION NUMBER:
*******************************************************************************/

#ifndef msdDevObj_h
#define msdDevObj_h

#ifdef J_INC_PATH
#include "msdApiTypes.h"
#else
#include <driver/msdApiTypes.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

MSD_STATUS InitDevObj(MSD_QD_DEV *dev);

#ifdef __cplusplus
}
#endif
#endif /* __msdDevObj_h */
