#include <stdio.h>
#include <errno.h>

#include "../include/driver/eth3/eth3_msdSysConfig.h"
#include "../include/msdApi.h"
#include "../dev/fir/include/driver/Fir_msdDrvSwRegs.h"


int main(int argc, char **argv) 
{
	MSD_STATUS status;
	MSD_LPORT egress;
	MSD_U8 qPri;
	MSD_U32 rate;

	if(argc != 4)
	{
		fprintf(stderr, "\nusage: tsnCfg_8021Qav <port#> <qPri> <rate>\n Ex. tsnCfg_8021Qav 2 1 20000\n\n");
		exit(1);
	}

	egress = (MSD_LPORT) atoi(argv[1]);
	qPri = (MSD_U8) atoi(argv[2]);
	rate = (MSD_U32) atoi(argv[3]);

	MSD_DBG_INFO((" ==> tsnCfg_8021Qav %d %d %d\n", egress, qPri, rate));

//	egress = 0x2;
//	qPri = 1; // Best Effort, PCP value = 0
//	rate = 40000; // 40M 

	msdDbgLvlSet(MSD_DBG_ALL_LVL);

	if((status = qdStart_SingleDevice_SMI_SC(FIR_GLOBAL2_DEV_ADDR)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", FIR_GLOBAL2_DEV_ADDR));
		return status;
	} 

	if ((status = msdQavPortQpriXRateSet(FIR_GLOBAL2_DEV_ADDR, egress, qPri, rate)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQavPortQpriXRateSet returned fail : status=%d\n", status));
		return -1;
	}

	return 0;
}


