#include "../msdApiTypes.h"


/********************************************************************************
* Sample #1: Initialize driver for single device @ SMI single-chip mode.
********************************************************************************/
MSD_STATUS qdStart_SingleDevice_SMI_SC (MSD_U8 devNum);

/********************************************************************************
* Sample #2: Initialize driver for single device @ SMI Multi-chip mode.
********************************************************************************/
MSD_STATUS qdStart_SingleDevice_SMI_MC(MSD_U8 devNum, MSD_U8 devAddr);

/********************************************************************************
* Sample #3: Initialize driver for single device @ RMU bus.
********************************************************************************/
MSD_STATUS qdStart_SingleDevice_RMU(MSD_U8 devNum);

/********************************************************************************
* Sample #4: Initialize driver for multi device @ SMI Multi-chip mode.
********************************************************************************/
MSD_STATUS qdStart_MultiDevice_SMI_MC(MSD_U8 numOfDevice);


