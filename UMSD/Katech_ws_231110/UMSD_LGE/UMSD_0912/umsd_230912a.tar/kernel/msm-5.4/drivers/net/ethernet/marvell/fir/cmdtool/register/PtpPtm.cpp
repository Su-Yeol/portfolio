/*******************************************************************************
 *
 *      LICENSE:
 *      (C)Copyright 2010-2011 Marvell.
 *
 *      All Rights Reserved
 *
 *      THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF MARVELL
 *      The copyright notice above does not evidence any
 *      actual or intended publication of such source code.
 *
 *      This Module contains Proprietary Information of Marvell
 *      and should be treated as Confidential.
 *
 *      The information in this file is provided for the exclusive use of
 *      the licensees of Marvell. Such users have the right to use, modify,
 *      and incorporate this code into products for purposes authorized by
 *      the license agreement provided they include this notice and the
 *      associated copyright notice with any such product.
 *
 *      The information in this file is provided "AS IS" without warranty.
 *	Author: A. Fischer (afischer@marvell.com)
 *      /LICENSE
 *
 ******************************************************************************/
#include "../CliFactory.h"

using namespace std;

#ifdef JTEST 
static CliArgs_t my_arg_list[] = {
        { "-if",	1, 1 },	// Interface name
        { "-getnow",	0, 0 },	// Interface name 
        { "-g",	0, 0 },	// Interface name 
        { "-v",		0, 0 },	// verbose option
} ;
#else
static CliArgs_t my_arg_list[] = {
        { "-if",	1, 1 },	// Interface name
        { "-v",		0, 0 },	// verbose option
} ;
#endif

/* *********************************************************************************//**
 * @defgroup CMDT_FILE  CMDT FILE I/O processing
 * *************************************************************************************/

/* *********************************************************************************//**
 * @addtogroup CMDT_FILE
 * @{
 * *************************************************************************************/

/* *********************************************************************************//**
 * @brief       Handle PCAP file contents
 * @details     PtpPtm::PtpPtm(int argc, char* argv[])
 * @details     Class contructor derived from class Cli matches command syntax.\n
 *              On successful command match set class member 'err' to IOCTL_CMD_STATUS_OK
 *              otherwise to IOCTL_CMD_STATUS_ERROR_INVALID_COMMAND.\n
 *              Used to read and dump the contents of a file specified in the command line.
 * @param [in]  argc command line argument count
 * @param [in]  argv command line argument vector
 * *************************************************************************************/

PtpPtm::PtpPtm(int argc, char* argv[]) : Cli(argc, argv)
{
	if_name = NULL ;
}

CliArgs_t * PtpPtm :: SetArgumentList(uint32_t *arg_list_size)
{
	// Set our own limited argument list

        *arg_list_size = sizeof(my_arg_list)/sizeof(CliArgs_t) ;
        return (my_arg_list) ;
}

#ifdef JTEST
int PtpPtm :: EvaluateArgumentList(int argc, char *argv[])
{
	uint32_t	pos, num ;

	err = ScanArgList(argc, argv, "-if", &pos, &num) ;
	if ((if_name == NULL) && (err != IOCTL_CMD_STATUS_OK)) {
		return (err) ;
	}
	else if (num > 0) {
		if_name = argv[pos] ;
	}

	err = ScanArgList(argc, argv, "-getnow", &pos, &num) ;
	if (err == IOCTL_CMD_STATUS_OK) {
		ioc_cmd = FIR_IOCTL_REG_PTPNOW_REQ ;
		ioc_data.offs = 0xA0000;
		goto end ;
	}

	err = ScanArgList(argc, argv, "-g", &pos, &num) ;
	if (err == IOCTL_CMD_STATUS_OK) {
		ioc_cmd = FIR_IOCTL_REG_ESU_REQ;
		goto end ;
	}

	err = ScanArgList(argc, argv, "-v", &pos, &num) ;
	if (err == IOCTL_CMD_STATUS_OK) {
		verbose = true ;
	}
	else if (err == IOCTL_CMD_STATUS_ERROR_ARGUMENT_NOT_FOUND) {
		err = IOCTL_CMD_STATUS_OK ;
	}
	
end:
	return (err) ;
}
#else
int PtpPtm :: EvaluateArgumentList(int argc, char *argv[])
{
	uint32_t	pos, num ;
	ioc_cmd = FIR_IOCTL_REG_PTPNOW_REQ ;
	ioc_data.offs = 0xA0000 ;

	err = ScanArgList(argc, argv, "-if", &pos, &num) ;

	if (err != IOCTL_CMD_STATUS_OK) {
		return (err) ;
	}
	else if (num > 0) {
		if_name = argv[pos] ;
	}

	err = ScanArgList(argc, argv, "-v", &pos, &num) ;
	if (err == IOCTL_CMD_STATUS_OK) {
		verbose = true ;
	}
        else if (err == IOCTL_CMD_STATUS_ERROR_ARGUMENT_NOT_FOUND) {
                err = IOCTL_CMD_STATUS_OK ;
        }

	return (err) ;
}
#endif

/* *********************************************************************************//**
 * @brief       Evaluate error code from command execution
 * @details     int PtpPtm::postAction(void)
 * @details     Checks internal 'err' variable. If IOCTL_CMD_STATUS_OK print
 *              the number of bytes read from file.
 * @return      just returns internal member variable 'err' for evaluation.
 * *************************************************************************************/
int PtpPtm::postAction(void)
{ 
#ifdef JFIX
	return IOCTL_CMD_STATUS_OK;
#else
	cout << "No return object from postAction" << endl;
	#error if you do not return, the segmentation fault will happen! 
#endif

}

int PtpPtm::Action(void)
{ 
	err = IOCTL_CMD_STATUS_ERROR ;

	if (if_name != NULL) {
		if (SetDevice(if_name) == true) {

			err = Ioctl(ioc_cmd, (caddr_t) &ioc_data) ;

			if (verbose == 1) {
			}

			if (ioc_data.error != 0) {
				cout << "IOC: failed with error: " << dec << ioc_data.error << endl ;
			}
			else 
			{
				cout << "IOC: time spec output : " << ioc_data.ts.tv_sec << " sec and " << ioc_data.ts.tv_nsec << " nsec." << endl ;
			}
			
		}
	}
	else {
		err = IOCTL_CMD_STATUS_ERROR_INVALID_DEVICE ;
	}
	return err ;
}

/* *********************************************************************************//**
 * @brief       Command verification.
 * @details     bool PtpPtm::isResponsible(int argc, char* argv[])
 * @param [in]  argc command line argument count
 * @param [in]  argv command line argument vector
 * @return      returns true on command match else false
 * *************************************************************************************/

bool PtpPtm::isResponsible(int argc, char* argv[])
{
	// cout << argv[0] << " " << argv[1] << endl ;
	if (argc >= 1) {
#if 1 // jay.choi
		if (strcmp(argv[1], "ptp") == 0 ) {
			return true;
		}
#else 
		if (strcmp(argv[1], "getptpnow") == 0 ) {
			return true;
		}
#endif
	}

	return false;
}

/* *********************************************************************************//**
 * @}
 * *************************************************************************************/

/*******************************************************************************
 *
 * End of file
 *
 ******************************************************************************/
