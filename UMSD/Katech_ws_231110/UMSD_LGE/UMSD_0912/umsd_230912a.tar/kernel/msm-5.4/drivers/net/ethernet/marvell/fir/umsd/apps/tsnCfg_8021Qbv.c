#include <stdio.h>
#include <errno.h>

#include "../include/driver/eth3/eth3_msdSysConfig.h"
#include "../include/msdApi.h"
#include "../dev/fir/include/driver/Fir_msdDrvSwRegs.h"

#undef COMPACT_VER

static MSD_STATUS ptpTriggerGenClk(MSD_U8 devNum, MSD_U32 trigTime, MSD_U32 clkPeriod);

int main(int argc, char **argv) 
{
	MSD_STATUS status;
	MSD_LPORT portNum;
	MSD_U32 trigTime, clkPeriod;
	MSD_U16 data;

#if 1 // jay.choi.pointer
	MSD_U16 pointer = 0x0;
#endif

	MSD_U8 devNum = FIR_GLOBAL2_DEV_ADDR;
	MSD_U8 qbvBlock = 0x3;

	if(argc != 2)
	{
#ifdef COMPACT_VER
		fprintf(stderr, "\nusage: 2. tsnCfg_8021Qbv <port#>\n Ex. tsnCfg_8021Qbv 2\n\n");
#else
		fprintf(stderr, "\nusage: 1. tsnCfg_8021Qbv <port#>\n Ex. tsnCfg_8021Qbv 2\n\n");
#endif
		exit(1);
	}

	portNum = (MSD_LPORT) atoi(argv[1]);

	msdDbgLvlSet(MSD_DBG_ALL_LVL);

	MSD_DBG_INFO((" ==> tsnCfg_8021Qbv %d\n", portNum));

	if((status = qdStart_SingleDevice_SMI_SC(devNum)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", devNum));
		return status;
	} 

	status = msdGetPTPGlobalTime(devNum, &trigTime);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdGetPTPGlobalTime fail.\n"));
		return status;
	}

#if 1 // jay.choi.testing.cycle.time
//	clkPeriod = 0x17D7840; // 25,000,000 x 4ns = 100ms 
//	clkPeriod = 0x2625A0; // 2,500,000 x 4ns = 10ms
	clkPeriod = 0x3D090; // 250,000 x 4ns = 1ms /* PTP clock 250 MHz */ 
//	clkPeriod = 0x1E848; // 125,000 x 4ns = 500us
//	clkPeriod = 0x124F8; // 75,000 x 4ns = 300ns
#else
	clkPeriod = 0x3D090; /* PTP clock 250 MHz */
#endif

	status = ptpTriggerGenClk(devNum, trigTime, clkPeriod);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("ptpTriggerGenClk fail.\n"));
		return status;
	}

	/*********************** below is Qbv entry setting ***************************/
	/*Write priority 3, open window time 200us*/
	data = 0x61A8;
#if 1 // jay.choi.230705.Qbv
	status = msdQbvWrite(devNum, qbvBlock, portNum, 0x3, data);
#else
	status = msdQbvWrite(devNum, portNum, 0x3, data);
#endif
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

#if 1 // jay.choi.230705.Qbv
	data = (1 << 15) | (pointer++ << 8) | 0x8; 
	status = msdQbvWrite(devNum, qbvBlock, portNum, 0x2, data);
#else
	data = (1 << 15) | (0x0 << 8) | 0x8; 
	status = msdQbvWrite(devNum, portNum, 0x2, data);
#endif
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	/*Write other priority 2, open window time 100us*/
	data = 0x30D4;
#if 1 // jay.choi.230705.Qbv
	status = msdQbvWrite(devNum, qbvBlock, portNum, 0x3, data);
#else
	status = msdQbvWrite(devNum, portNum, 0x3, data);
#endif
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

#if 1 // jay.choi.230705.Qbv
	data = (1 << 15) | (pointer++ << 8) | 0x4;
	status = msdQbvWrite(devNum, qbvBlock, portNum, 0x2, data);
#else
	data = (1 << 15) | (0x1 << 8) | 0x4; 
	status = msdQbvWrite(devNum, portNum, 0x2, data);
#endif
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	/*Write other priority 1, open window time 50us*/
	data = 0x186A;
#if 1 // jay.choi.230705.Qbv
	status = msdQbvWrite(devNum, qbvBlock, portNum, 0x3, data);
#else
	status = msdQbvWrite(devNum, portNum, 0x3, data);
#endif
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

#if 1 // jay.choi.230705.Qbv
	data = (1 << 15) | (pointer++ << 8) | 0x2; 
	status = msdQbvWrite(devNum, qbvBlock, portNum, 0x2, data);
#else
	data = (1 << 15) | (0x2 << 8) | 0x2; 
	status = msdQbvWrite(devNum, portNum, 0x2, data);
#endif
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	/*Write other window time closed*/
	data = 0x0;
#if 1 // jay.choi.230705.Qbv
	status = msdQbvWrite(devNum, qbvBlock, portNum, 0x3, data);
#else
	status = msdQbvWrite(devNum, portNum, 0x3, data);
#endif
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

#if 1 // jay.choi.230705.Qbv
	data = (1 << 15) | (pointer++ << 8) | 0x0; 
	status = msdQbvWrite(devNum, qbvBlock, portNum, 0x2, data);
#else
	data = (1 << 15) | (0x3 << 8) | 0x0; 
	status = msdQbvWrite(devNum, portNum, 0x2, data);
#endif
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	MSD_DBG_INFO(("sample_msdQbv success.\n"));
	return MSD_OK;
}


static MSD_STATUS ptpTriggerGenClk(MSD_U8 devNum, MSD_U32 trigTime, MSD_U32 clkPeriod)
{
	MSD_STATUS status;
	MSD_U16 data;

#ifdef COMPACT_VER // jay.choi.testing

	data = clkPeriod & 0xffff;
	msdTaiRegSet(devNum, 0x2, data);

	data = (clkPeriod & 0xffff0000) >> 16;
	msdTaiRegSet(devNum, 0x3, data);

	data = trigTime & 0xffff;
	msdTaiRegSet(devNum, 0x10, data);

	data = (trigTime & 0xffff0000) >> 16;
	msdTaiRegSet(devNum, 0x11, data);

#else
	/* Write TAI TrigGenAmt*/
	{
		/*Access global2 offset 0x17 AVB/TSN Data Register*/
		status = msdSetAnyReg(devNum, 0x1C, 0x17, (clkPeriod & 0xffff));
		if (status != MSD_OK)
		{
			MSD_DBG_ERROR(("msdSetAnyReg returned fail.\n"));
			return status;
		}
		/*Access global2 offset 0x16 AVB/TSN Command Register(write TAI offset 0x2 TrigGenAmt)*/
		data = (1 << 15) | (3 << 13) | (0x1E << 8) | (0x0 << 5) | 0x2;
		status = msdSetAnyReg(devNum, 0x1C, 0x16, data);
		if (status != MSD_OK)
		{
			MSD_DBG_ERROR(("msdSetAnyReg returned fail.\n"));
			return status;
		}

		/*wait AVB/TSN busy bit cleared*/
		data = 1;
		while (data)
		{
			status = msdGetAnyRegField(devNum, 0x1C, 0x16, 15, 1, &data);
			if (status != MSD_OK)
			{
				MSD_DBG_ERROR(("msdGetAnyRegField returned fail.\n"));
				return status;
			}
		}

		/*Access global2 offset 0x17 AVB/TSN Data Register*/
		status = msdSetAnyReg(devNum, 0x1C, 0x17, ((clkPeriod & 0xffff0000) >> 16));
		if (status != MSD_OK)
		{
			MSD_DBG_ERROR(("msdSetAnyReg returned fail.\n"));
			return status;
		}
		/*Access global2 offset 0x16 AVB/TSN Command Register(write TAI offset 0x2 TrigGenAmt)*/
		data = (1 << 15) | (3 << 13) | (0x1E << 8) | (0x0 << 5) | 0x3;
		status = msdSetAnyReg(devNum, 0x1C, 0x16, data);
		if (status != MSD_OK)
		{
			MSD_DBG_ERROR(("msdSetAnyReg returned fail.\n"));
			return status;
		}

		/*wait AVB/TSN busy bit cleared*/
		data = 1;
		while (data)
		{
			status = msdGetAnyRegField(devNum, 0x1C, 0x16, 15, 1, &data);
			if (status != MSD_OK)
			{
				MSD_DBG_ERROR(("msdGetAnyRegField returned fail.\n"));
				return status;
			}
		}
	}

	/* Write TAI TrigGenTime*/
	{
		/*Access global2 offset 0x17 AVB/TSN Data Register*/
		status = msdSetAnyReg(devNum, 0x1C, 0x17, (trigTime & 0xffff));
		if (status != MSD_OK)
		{
			MSD_DBG_ERROR(("msdSetAnyReg returned fail.\n"));
			return status;
		}
		/*Access global2 offset 0x16 AVB/TSN Command Register(write TAI offset 0x2 TrigGenAmt)*/
		data = (1 << 15) | (3 << 13) | (0x1E << 8) | (0x0 << 5) | 0x10;
		status = msdSetAnyReg(devNum, 0x1C, 0x16, data);
		if (status != MSD_OK)
		{
			MSD_DBG_ERROR(("msdSetAnyReg returned fail.\n"));
			return status;
		}

		/*wait AVB/TSN busy bit cleared*/
		data = 1;
		while (data)
		{
			status = msdGetAnyRegField(devNum, 0x1C, 0x16, 15, 1, &data);
			if (status != MSD_OK)
			{
				MSD_DBG_ERROR(("msdGetAnyRegField returned fail.\n"));
				return status;
			}
		}

		/*Access global2 offset 0x17 AVB/TSN Data Register*/
		status = msdSetAnyReg(devNum, 0x1C, 0x17, ((trigTime & 0xffff0000) >> 16));
		if (status != MSD_OK)
		{
			MSD_DBG_ERROR(("msdSetAnyReg returned fail.\n"));
			return status;
		}
		/*Access global2 offset 0x16 AVB/TSN Command Register(write TAI offset 0x2 TrigGenAmt)*/
		data = (1 << 15) | (3 << 13) | (0x1E << 8) | (0x0 << 5) | 0x11;
		status = msdSetAnyReg(devNum, 0x1C, 0x16, data);
		if (status != MSD_OK)
		{
			MSD_DBG_ERROR(("msdSetAnyReg returned fail.\n"));
			return status;
		}

		/*wait AVB/TSN busy bit cleared*/
		data = 1;
		while (data)
		{
			status = msdGetAnyRegField(devNum, 0x1C, 0x16, 15, 1, &data);
			if (status != MSD_OK)
			{
				MSD_DBG_ERROR(("msdGetAnyRegField returned fail.\n"));
				return status;
			}
		}
	}

	/* Write TrigMode and TrigGenReq*/
	{
		/*Access global2 offset 0x16 AVB/TSN Command Register(read TAI offset 0x0)*/
		data = (1 << 15) | (0x0 << 13) | (0x1E << 8) | (0x0 << 5) | 0x0;
		status = msdSetAnyReg(devNum, 0x1C, 0x16, data);
		if (status != MSD_OK)
		{
			MSD_DBG_ERROR(("msdSetAnyReg returned fail.\n"));
			return status;
		}
		/*wait AVB/TSN busy bit cleared*/
		data = 1;
		while (data)
		{
			status = msdGetAnyRegField(devNum, 0x1C, 0x16, 15, 1, &data);
			if (status != MSD_OK)
			{
				MSD_DBG_ERROR(("msdGetAnyRegField returned fail.\n"));
				return status;
			}
		}

		/*Access global2 offset 0x17 AVB/TSN Data Register*/
		status = msdGetAnyReg(devNum, 0x1C, 0x17, &data);
		if (status != MSD_OK)
		{
			MSD_DBG_ERROR(("msdGetAnyReg returned fail.\n"));
			return status;
		}

		data = (data & 0xFFFC) | 0x1;
		/*Access global2 offset 0x17 AVB/TSN Data Register*/
		status = msdSetAnyReg(devNum, 0x1C, 0x17, data);
		if (status != MSD_OK)
		{
			MSD_DBG_ERROR(("msdSetAnyReg returned fail.\n"));
			return status;
		}
		/*Access global2 offset 0x16 AVB/TSN Command Register(write TAI offset 0x0)*/
		data = (1 << 15) | (3 << 13) | (0x1E << 8) | (0x0 << 5) | 0x0;
		status = msdSetAnyReg(devNum, 0x1C, 0x16, data);
		if (status != MSD_OK)
		{
			MSD_DBG_ERROR(("msdSetAnyReg returned fail.\n"));
			return status;
		}

		/*wait AVB/TSN busy bit cleared*/
		data = 1;
		while (data)
		{
			status = msdGetAnyRegField(devNum, 0x1C, 0x16, 15, 1, &data);
			if (status != MSD_OK)
			{
				MSD_DBG_ERROR(("msdGetAnyRegField returned fail.\n"));
				return status;
			}
		}

	}
#endif

	return MSD_OK;
}

