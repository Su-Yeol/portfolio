#include "../include/driver/eth3/eth3_msdSysConfig.h"
#include "../include/msdApi.h"
#include "../dev/fir/include/driver/Fir_msdDrvSwRegs.h"


MSD_STATUS initialzeDrivers(MSD_LPORT ingress, MSD_LPORT egress1, MSD_LPORT egress2) 
{
	MSD_STATUS status;

	if((status = qdStart_SingleDevice_SMI_SC(ingress)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", ingress));
		return status;
	}

	if((status = qdStart_SingleDevice_SMI_SC(egress1)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", egress1));
		return status;
	}

	if((status = qdStart_SingleDevice_SMI_SC(egress2)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", egress2));
		return status;
	}

	if((status = qdStart_SingleDevice_SMI_SC(FIR_GLOBAL1_DEV_ADDR)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", FIR_GLOBAL1_DEV_ADDR));
		return status;
	} 

	if((status = qdStart_SingleDevice_SMI_SC(FIR_TCAM_DEV_ADDR)) != MSD_OK) 
	{
		MSD_DBG_ERROR(("devNum 0x%x is NULL. Driver load failed. \n", FIR_TCAM_DEV_ADDR));
		return status;
	} 

	return status;
}


MSD_STATUS addVlanEntry(MSD_LPORT ingress, MSD_LPORT egress1, MSD_LPORT egress2) 
{
	MSD_STATUS status;
	MSD_VTU_ENTRY vtuEntry;
	MSD_QD_DEV* dev;

	dev = sohoDevGet(FIR_GLOBAL1_DEV_ADDR);

	if (NULL == dev)
	{
		MSD_DBG_ERROR(("Dev is NULL for devNum %d.\n", FIR_GLOBAL1_DEV_ADDR));
		return MSD_FAIL;
	} 

  if ((status = msdVlanAllDelete(dev->devNum)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdVlanAllDelete returned fail.\n"));
		return status;
	}

	vtuEntry.fid = 0;
	vtuEntry.vid = 5;
	vtuEntry.sid = 0;

	for(int i=0; i<dev->numOfPorts; i++)
	{
		vtuEntry.memberTagP[i] = 3;
	}
	vtuEntry.memberTagP[ingress] = 2;
	vtuEntry.memberTagP[egress1] = 2;
	vtuEntry.memberTagP[egress2] = 2;

	vtuEntry.vidPolicy = MSD_FALSE;  /* VID Policy bit.*/
	vtuEntry.vidExInfo.useVIDFPri = MSD_FALSE; /* If device doesnot support VTU Frame Priority override, this field is ignored. */
	vtuEntry.vidExInfo.vidFPri = 0;           /* If device doesnot support VTU Frame Priority override, this field is ignored. */
	vtuEntry.vidExInfo.useVIDQPri = MSD_FALSE; /* If device doesnot support VTU Queue Priority override, this field is ignored. */
 	vtuEntry.vidExInfo.vidQPri = 0;           /* If device doesnot support VTU Queue Priority override, this field is ignored. */
	vtuEntry.vidExInfo.dontLearn = MSD_FALSE;  /* Do not learn the MAC address */
	vtuEntry.vidExInfo.filterUC = MSD_FALSE;  /* Determine whether or not to filter unicast frame */
	vtuEntry.vidExInfo.filterBC = MSD_FALSE;   /* Determine whether or not to filter broadcast frame */
	vtuEntry.vidExInfo.filterMC = MSD_FALSE;   /* Determine whether or not to filter multicast frame */

	if ((status = msdVlanEntryAdd(dev->devNum, &vtuEntry)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdVlanEntryAdd returned fail.\n"));
	}

	return status;
}


MSD_STATUS addMacEntry(MSD_LPORT ingress) 
{
	MSD_STATUS status;
	MSD_ATU_ENTRY macEntry;
	MSD_QD_DEV* dev;

	dev = sohoDevGet(FIR_GLOBAL1_DEV_ADDR);

	if (NULL == dev)
	{
		MSD_DBG_ERROR(("Dev is NULL for devNum %d.\n", FIR_GLOBAL1_DEV_ADDR));
		return MSD_FAIL;
	} 

	if ((status = msdFdbAllDelete(dev->devNum, MSD_FLUSH_ALL)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdFdbAllDelete returned fail.\n"));
		return status;
	}

	macEntry.macAddr.arEther[0] = 0x00;
	macEntry.macAddr.arEther[1] = 0x22;
	macEntry.macAddr.arEther[2] = 0x22;
	macEntry.macAddr.arEther[3] = 0x22;
	macEntry.macAddr.arEther[4] = 0x22;
	macEntry.macAddr.arEther[5] = 0x22;

	macEntry.trunkMemberOrLAG = 0;  /* No trunk. */

	macEntry.portVec = 1 << ingress;     /* Set the portVector matching with Port 6, the frame with DA as above address will be forwarded to port 2. */

	macEntry.fid = 0;	/* Refer to the fid of VLAN entry ! */
	macEntry.entryState = 0xE;      /* Static entry. */
	macEntry.exPrio.macFPri = 0;    /* If device doesnot support MAC Frame Priority override, this field is ignored. */
	macEntry.exPrio.macQPri = 0;    /* If device doesnot support MAC Queue Priority override, this field is ignored. */

	if ((status = msdFdbMacEntryAdd(dev->devNum, &macEntry)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdFdbMacEntryAdd returned fail.\n"));
	}

	return status;
}


MSD_STATUS set8021qMode(MSD_LPORT ingress, MSD_LPORT egress1, MSD_LPORT egress2) 
{
	MSD_STATUS status;

	if ((status = msdPort8021qModeSet(ingress, ingress, MSD_8021Q_CHECK)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPort8021qModeSet returned fail. port# = %d\n", ingress));
		return status;
	}

	if ((status = msdPort8021qModeSet(egress1, egress1, MSD_8021Q_CHECK)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPort8021qModeSet returned fail. port# = %d\n", egress1));
		return status;
	}

	if ((status = msdPort8021qModeSet(egress2, egress2, MSD_8021Q_CHECK)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPort8021qModeSet returned fail. port# = %d\n", egress2));
		return status;
	}

	return status;
}


MSD_STATUS setTcamIngressSingle(MSD_LPORT ingress, MSD_LPORT egress1, MSD_LPORT egress2)
{
	MSD_STATUS     status;

	MSD_U32        IgrTcamPointer = 0;
	MSD_TCAM_DATA  IgrTcamData;

	MSD_U32 EgrTcamPointer = 0xf;
	MSD_TCAM_EGR_DATA EgrTcamData1;
	MSD_TCAM_EGR_DATA EgrTcamData2;

	MSD_LPORT port;
	MSD_TCAM_MODE tcamMode;

	MSD_QD_DEV *dev = sohoDevGet(FIR_TCAM_DEV_ADDR);
	if (dev == NULL)
	{
		MSD_DBG_ERROR(("Failed. Dev is Null.\n"));
		return MSD_FAIL;
	}

	if (MSD_TOPAZ == dev->devName)
	{
		return MSD_NOT_SUPPORTED;
	}


	tcamMode = MSD_TCAM_MODE_ENABLE_48; /* enable 48 bytes match tcam mode, single entry match */

	if ((status = msdPortTcamModeSet(ingress, ingress, tcamMode)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPortTcamModeSet returned fail.\n"));
		return status;
	}

	/*
	 *    Flush all entries for both ingress and egress TCAM table
	 */
 	if ((status = msdTcamAllDelete(FIR_TCAM_DEV_ADDR)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdTcamAllDelete returned fail.\n"));
		return status;
	}

	/*
	 *    Initialize and load the Ingress TCAM Entry
	 */
	msdMemSet(&IgrTcamData,0,sizeof(MSD_TCAM_DATA)); /* Set all bit to 0 by default */

	IgrTcamData.spvMask = 0xfff;
	IgrTcamData.spv |= 1 << ingress;

	IgrTcamData.frameOctetMask[1] = 0xff;
	IgrTcamData.frameOctet[1] = 0x22;

	IgrTcamData.dpvMode = 0x3; /*  Replace the frames DPV with the TCAM Entry��s DPV Data */
	IgrTcamData.dpvData |= 1 << egress1;
	IgrTcamData.dpvData |= 1 << egress2;

	IgrTcamData.frerSeqGenEn = 1;
	IgrTcamData.frerIndvRcvyId = 0xf;
	
	if ((status = msdTcamEntryAdd(FIR_TCAM_DEV_ADDR, IgrTcamPointer, &IgrTcamData)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdTcamEntryAdd returned fail.\n"));
		return status;
	}

	return MSD_OK;
}


MSD_STATUS setQueueCtrl(MSD_LPORT ingress, MSD_LPORT egress) 
{
	MSD_STATUS status;
	MSD_U8 pointer = 0x0; // Port Schedule @ Table 122 
	MSD_PORT_SCHED_MODE schedule = MSD_PORT_SCHED_WRR_PRI4_3_2_1_0;
	MSD_U8 sch = (MSD_U8) schedule;

	if ((status = msdPortQueueCtrlSet(egress, egress, pointer, sch)) != MSD_OK)
	{
		MSD_DBG_ERROR(("msdPortQueueCtrlSet returned fail.\n"));
		return status;
	}

	return status;
}


MSD_STATUS setAVBPolicy(void) 
{
	MSD_STATUS status;
	MSD_U16 data;
	MSD_U8 avbPolicyBlock = 0x1;

	// AVB Policy (TSN Block = 0x01)
	data = 0x3322;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, avbPolicyBlock, 0x1F, 0x0, data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	// AVB Policy (TSN Block = 0x01)
	data = 0x0000;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, avbPolicyBlock, 0x1F, 0x4, data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	// AVB Policy (TSN Block = 0x01)
	data = 0x8000;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, 
		avbPolicyBlock,
#ifdef J_DEBUG
		2, 
#else
		ingress,
#endif
		0x0, 
		data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	} 

	return status;
}


MSD_STATUS setQavTable(void) 
{
	MSD_STATUS status;
	MSD_U16 data;
 	MSD_U8 qavBlock = 0x2;


	// Qav (TSN Block = 0x10)
	data = 0x0064;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, qavBlock, 0x1F, 0x1, data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	// Qav (TSN Block = 0x10)
	data = 0x8064;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, qavBlock, 0x1F, 0x0, data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	// Qav (TSN Block = 0x10)
	data = 0x0509;
	status = msdQbvWrite(FIR_GLOBAL2_DEV_ADDR, 
		qavBlock,
#ifdef J_DEBUG
		6, 
#else
		egress,
#endif
		4,
		data);
	if (status != MSD_OK)
	{
		MSD_DBG_ERROR(("msdQbvWrite fail.\n"));
		return status;
	}

	return status;
}


int main(int argc, char **argv) 
{
	MSD_STATUS status;
	MSD_LPORT ingress, egress1, egress2;

	ingress = 0x9; 

	msdDbgLvlSet(MSD_DBG_ALL_LVL);
	
#ifdef J_DEBUG
	if(argc != 3) {
		MSD_DBG_ERROR(("Unexpected number of arguments\n"));
		MSD_DBG_ERROR(("Usage : tsnCfg_8021CB_talker <egress port 1> <egress port 2>\n"));
		return 0;
	}  

	egress1 = atoi(argv[1]);
	egress2 = atoi(argv[2]);
#else
	egress1 = 0x3;
	egress2 = 0x6; 
#endif
	
	MSD_DBG_INFO(("egress1 = %d, egress2 = %d\n", egress1, egress2));

	initialzeDrivers(ingress, egress1, egress2);

  if ((status = addVlanEntry(ingress, egress1, egress2)) != MSD_OK)
	{
		MSD_DBG_ERROR(("addVlanEntry returned fail.\n"));
		return status;
	}

  if ((status = set8021qMode(ingress, egress1, egress2)) != MSD_OK)
	{
		MSD_DBG_ERROR(("set8021qMode returned fail.\n"));
		return status;
	}

	if ((status = setTcamIngressSingle(ingress, egress1, egress2)) != MSD_OK)
	{
		MSD_DBG_ERROR(("setTcamIngressSingle returned fail.\n"));
		return status;
	} 

  if ((status = addMacEntry(ingress)) != MSD_OK)
	{
		MSD_DBG_ERROR(("addMacEntry returned fail.\n"));
		return status;
	}

	return 0;
}


