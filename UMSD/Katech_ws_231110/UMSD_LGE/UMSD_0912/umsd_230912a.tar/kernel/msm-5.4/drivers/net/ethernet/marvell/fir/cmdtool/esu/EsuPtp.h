/*******************************************************************************
 *
 *      LICENSE:
 *      (C)Copyright 2010-2011 Marvell.
 *
 *      All Rights Reserved
 *
 *      THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF MARVELL
 *      The copyright notice above does not evidence any
 *      actual or intended publication of such source code.
 *
 *      This Module contains Proprietary Information of Marvell
 *      and should be treated as Confidential.
 *
 *      The information in this file is provided for the exclusive use of
 *      the licensees of Marvell. Such users have the right to use, modify,
 *      and incorporate this code into products for purposes authorized by
 *      the license agreement provided they include this notice and the
 *      associated copyright notice with any such product.
 *
 *      The information in this file is provided "AS IS" without warranty.
 *	Author: A. Fischer (afischer@marvell.com)
 *      /LICENSE
 *
 ******************************************************************************/

#ifndef PTP_IO_H
#define PTP_IO_H

#include "Socket.h"
#ifdef JINCPATH
#include "../../fir_ioc_reg.h"
#else
#include "fir_ioc_reg.h"
#endif

#define PTP_PORT 0x1F
#define PTP_BLOCK 0x0

/* Type definitions included from file: register/RegisterIO.h
 */
typedef	REG_Field_t		PTP_Field_t ;
typedef	REG_Register_t		PTP_Register_t ;
typedef	REG_All_Registers_t	PTP_All_Registers_t ;

typedef struct
{
	uint32_t	ptpEType;
	uint32_t	msgIdTSEn;
	uint32_t	tsArrPtr; 
} PTP_GLOBAL_CONFIG;


class EsuPtp : public Esu
{
	public:
				EsuPtp(int argc, char* argv[]) ;
		CliArgs_t *	SetArgumentList(uint32_t *arg_list_size) ;
		void		SetIfName(char *ifn) { if_name = ifn ; }
		int 		EvaluateArgumentList(int argc, char *argv[]) ;
		int		postAction(void) ;
		int		Action(void) ;
//		int 		DoListTai() ;		

	static	bool		isResponsible(int argc, char* argv[]) ;

		int		ReadIO(uint32_t dev, uint32_t reg, uint32_t *data) ;
	protected:
		int 		ExecuteCmd(uint32_t rw, uint32_t block, uint32_t addr) ;
		int		WriteIO(uint32_t dev, uint32_t reg, uint32_t data) ;
		int 		WriteAllRegisterList(uint32_t port) ;

		char	*	if_name ;

		/* 0:normal register access, 1:read-modify-write-or, 2:read-modify-write-and */
		int		ioc_flag ;

	private:
		uint32_t	operation ;
		uint32_t	reg_off ;
		uint32_t	reg_val ;

		uint32_t	port;
		uint32_t	tsn_command;
		uint32_t	tsn_data;
		PTP_GLOBAL_CONFIG ptpGlobalCfg;

} ;

#endif // TAI_IO_H

/*******************************************************************************
 *
 * End of file
 *
 ******************************************************************************/
