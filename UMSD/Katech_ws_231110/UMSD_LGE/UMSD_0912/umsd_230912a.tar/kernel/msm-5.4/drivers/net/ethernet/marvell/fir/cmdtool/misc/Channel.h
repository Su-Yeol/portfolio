/*******************************************************************************
 *
 *      LICENSE:
 *      (C)Copyright 2010-2011 Marvell.
 *
 *      All Rights Reserved
 *
 *      THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF MARVELL
 *      The copyright notice above does not evidence any
 *      actual or intended publication of such source code.
 *
 *      This Module contains Proprietary Information of Marvell
 *      and should be treated as Confidential.
 *
 *      The information in this file is provided for the exclusive use of
 *      the licensees of Marvell. Such users have the right to use, modify,
 *      and incorporate this code into products for purposes authorized by
 *      the license agreement provided they include this notice and the
 *      associated copyright notice with any such product.
 *
 *      The information in this file is provided "AS IS" without warranty.
 *	Author: A. Fischer (afischer@marvell.com)
 *      /LICENSE
 *
 ******************************************************************************/

#ifndef CHANNEL_H
#define CHANNEL_H

#include "Socket.h"
#include "Cli.h"

#ifdef JINCPATH
#include "../../fir_ioc_stat.h"
#include "../../fir_unimac_desc.h"
#include "../../fir_channel_stat.h"
#else
#include "fir_ioc_stat.h"
#include "fir_unimac_desc.h"
#include "fir_channel_stat.h"
#endif

#define	MAX_NUMBER_OF_INPUT_FILES	16

class Channel : public Cli, public Socket
{
	public:
					Channel(int argc, char* argv[]) ;
		virtual int		preAction(void) ;
		virtual int		Action(void);

		virtual CliArgs_t *     SetArgumentList(uint32_t *arg_list_size) ;
                virtual int		EvaluateArgumentList(int argc, char *argv[]) ;

		static bool		isResponsible(int argc, char* argv[]);
	private:
		fir_chan_info		c_info ;

		void			DisplayRxChannel(uint32_t) ;
		void			DisplayTxChannel(uint32_t) ;
		void			DisplayRbChannel(uint32_t) ;
		void			DisplayChannelStatus() ;

	protected:
		fir_ioc_stat	ioc_data ;
		int		ioc_cmd ;
		char		*if_name ;
		uint32_t	count ;
};

#endif // CHANNEL_H

/*******************************************************************************
 *
 * End of file
 *
 ******************************************************************************/
