/*************************************************************************************************************
Copyright (c) 2012-2015, Symphony Teleca Corporation, a Harman International Industries, Incorporated company
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
 
1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS LISTED "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS LISTED BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 
Attributions: The inih library portion of the source code is licensed from 
Brush Technology and Ben Hoyt - Copyright (c) 2009, Brush Technology and Copyright (c) 2009, Ben Hoyt. 
Complete license and copyright information can be found at 
https://github.com/benhoyt/inih/commit/74d2ca064fb293bc60a77b0bd068075b293cf175.
*************************************************************************************************************/

/*
* MODULE SUMMARY : Talker implementation
*/

#include <stdlib.h>
#include "openavb_platform.h"
#include "openavb_trace.h"
#include "openavb_tl.h"
#include "openavb_avtp.h"
#include "openavb_talker.h"
// #include "openavb_time.h"

// jay.choi.230602 #ifdef AVB_FEATURE_NEUTRINO // jay.choi.fir
#include "emac.h"
// jay.choi.230602 #endif

// DEBUG Uncomment to turn on logging for just this module.
//#define AVB_LOG_ON	1

#define	AVB_LOG_COMPONENT	"Talker"
#include "openavb_log.h"

#include "openavb_debug.h"



bool talkerStartStream(tl_state_t *pTLState)
{
	AVB_TRACE_ENTRY(AVB_TRACE_TL);

	if (!pTLState) {
		AVB_LOG_ERROR("Invalid TLState");
		AVB_TRACE_EXIT(AVB_TRACE_TL);
		return FALSE;
	}

#ifndef NO_PPS_BASED_WAKEUP
	eventConfigData_t *pEventConfigData = NULL;
#endif

	openavb_tl_cfg_t *pCfg = &pTLState->cfg;
	talker_data_t *pTalkerData = pTLState->pPvtTalkerData;

	assert(!pTLState->bStreaming);

	pTalkerData->wakeFrames = pCfg->max_interval_frames * pCfg->batch_factor;

	// Set a max_transmit_deficit_usec default
	if (pCfg->max_transmit_deficit_usec == 0)
		pCfg->max_transmit_deficit_usec = 50000;

	openavbRC rc = openavbAvtpTxInit(pTLState->pMediaQ,
		&pCfg->map_cb,
		&pCfg->intf_cb,
		pTalkerData->ifname,
		&pTalkerData->streamID,
		pTalkerData->destAddr,
		pCfg->max_transit_usec,
		pTalkerData->fwmark,
		pTalkerData->vlanID,
		pTalkerData->vlanPCP,
		pTalkerData->wakeFrames * pCfg->raw_tx_buffers,
		&pTalkerData->avtpHandle);
	if (IS_OPENAVB_FAILURE(rc)) {
		AVB_LOG_ERROR("Failed to create AVTP stream");
		AVB_TRACE_EXIT(AVB_TRACE_TL);
		return FALSE;
	}

	avtp_stream_t *pStream = (avtp_stream_t *)(pTalkerData->avtpHandle);
	pStream->enable_debug_of_gptp_timestamps = pCfg->enable_debug_of_gptp_timestamps;

	if (!pStream->pMapCB->map_transmit_interval_cb(pTLState->pMediaQ)) {
		pTalkerData->wakeRate = pTalkerData->classRate / pCfg->batch_factor;
	}
	else {
		// Override the class observation interval with the one provided by the mapping module.
		pTalkerData->wakeRate = pStream->pMapCB->map_transmit_interval_cb(pTLState->pMediaQ) / pCfg->batch_factor;
	}

#ifndef NO_PPS_BASED_WAKEUP
	/* if wakeup_on_pps is enabled, initialise emac PPS feature */
	if (pTLState->cfg.enable_wakeup_on_pps) {
		if (pTLState->pEventConfigData = (eventConfigData_t *) calloc(1, sizeof(eventConfigData_t))) {
			pEventConfigData = (eventConfigData_t *)pTLState->pEventConfigData;
			if (pEventConfigData->ifacename = (char *) malloc (sizeof(char) * IFNAMSIZE)) {
				memcpy(pEventConfigData->ifacename,pTLState->cfg.ifname,strlen(pTLState->cfg.ifname)+1);
				pEventConfigData->sr_class = pTLState->cfg.sr_class;
				pEventConfigData->wakeRate = pTalkerData->wakeRate;

				if (!eventConfigure(pEventConfigData) && !pTLState->cfg.enable_wakeup_on_pps) {
					pTLState->cfg.enable_wakeup_on_pps = 0;
				}

				if (!eventInit(pEventConfigData) && !pTLState->cfg.enable_wakeup_on_pps) {
					pTLState->cfg.enable_wakeup_on_pps = 0;
				}

				if (pTLState->cfg.enable_wakeup_on_pps) {
					AVB_LOGF_INFO("Event based AVB pkts transmission Enabled, event wakeup status: %d",pTLState->cfg.enable_wakeup_on_pps);
				} else {
					AVB_LOGF_INFO("Legacy AVB pkts transmission Enabled, event wakeup status: %d",pTLState->cfg.enable_wakeup_on_pps);
				}
			} else {
				AVB_LOG_WARNING("Failed to allocate memory for interface name ");
				free(pTLState->pEventConfigData);
				pTLState->pEventConfigData = NULL;
				pTLState->cfg.enable_wakeup_on_pps = 0;
			}
		} else {
			AVB_LOG_WARNING("Failed to allocate event data ");
			pTLState->cfg.enable_wakeup_on_pps = 0;
		}
	}
#endif

	pTalkerData->sleepUsec = MICROSECONDS_PER_SECOND / pTalkerData->wakeRate;
	pTalkerData->intervalNS = NANOSECONDS_PER_SECOND / pTalkerData->wakeRate;
	pTalkerData->driftCurve = 0;
	U32 SRKbps = ((unsigned long)pTalkerData->classRate * (unsigned long)pCfg->max_interval_frames * (unsigned long)pStream->frameLen * 8L) / 1000;
	U32 DataKbps = ((unsigned long)pTalkerData->wakeRate * (unsigned long)pCfg->max_interval_frames * (unsigned long)pStream->frameLen * 8L) / 1000;

	AVB_LOGF_INFO(STREAMID_FORMAT", sr-rate=%" PRIu32 ", data-rate=%lu, frames=%" PRIu16 ", size=%" PRIu16 ", batch=%" PRIu32 ", sleep=%" PRIu64 "us, sr-Kbps=%d, data-Kbps=%d",
		STREAMID_ARGS(&pTalkerData->streamID), pTalkerData->classRate, pTalkerData->wakeRate,
		pTalkerData->tSpec.maxIntervalFrames, pTalkerData->tSpec.maxFrameSize,
		pCfg->batch_factor, pTalkerData->intervalNS / 1000, SRKbps, DataKbps);

	// number of intervals per report
	pTalkerData->wakesPerReport = pCfg->report_seconds * NANOSECONDS_PER_SECOND / pTalkerData->intervalNS;
	// counts of intervals and frames between reports
	pTalkerData->cntFrames = 0;
	pTalkerData->cntWakes = 0;

	// setup the initial times
	U64 nowNS;
	CLOCK_GETTIME64(OPENAVB_TIMER_CLOCK, &nowNS);

	// Align clock : allows for some performance gain
	nowNS = ((nowNS + (pTalkerData->intervalNS)) / pTalkerData->intervalNS) * pTalkerData->intervalNS;

	pTalkerData->nextReportNS = nowNS + (pCfg->report_seconds * NANOSECONDS_PER_SECOND);
	pTalkerData->nextSecondNS = nowNS + NANOSECONDS_PER_SECOND;
	pTalkerData->nextCycleNS = nowNS + pTalkerData->intervalNS;

	// Clear stats
	openavbTalkerClearStats(pTLState);

	// we're good to go!
	pTLState->bStreaming = TRUE;

	AVB_TRACE_EXIT(AVB_TRACE_TL);
	return TRUE;
}

void talkerStopStream(tl_state_t *pTLState)
{
	AVB_TRACE_ENTRY(AVB_TRACE_TL);

	if (!pTLState) {
		AVB_LOG_ERROR("Invalid TLState");
		AVB_TRACE_EXIT(AVB_TRACE_TL);
		return;
	}

	talker_data_t *pTalkerData = pTLState->pPvtTalkerData;
	if (!pTalkerData) {
		AVB_LOG_ERROR("Invalid listener data");
		AVB_TRACE_EXIT(AVB_TRACE_TL);
		return;
	}

#ifndef NO_PPS_BASED_WAKEUP 
	if (pTLState->cfg.enable_wakeup_on_pps) {
		eventConfigData_t *pEventConfigData = (eventConfigData_t *)pTLState->pEventConfigData;
		if (eventStop(pEventConfigData)) {
			pTLState->cfg.enable_wakeup_on_pps = 0;
			AVB_LOGF_INFO("Event based AVB pkts transmission Disabled/Stopped, event wakeup status: %d",pTLState->cfg.enable_wakeup_on_pps);
		}
	}
#endif

	void *rawsock = NULL;
	if (pTalkerData->avtpHandle) {
		rawsock = ((avtp_stream_t*)pTalkerData->avtpHandle)->rawsock;
	}

	openavbTalkerAddStat(pTLState, TL_STAT_TX_CALLS, pTalkerData->cntWakes);
	openavbTalkerAddStat(pTLState, TL_STAT_TX_FRAMES, pTalkerData->cntFrames);
//	openavbTalkerAddStat(pTLState, TL_STAT_TX_LATE, 0);		// Can't calulate at this time
	openavbTalkerAddStat(pTLState, TL_STAT_TX_BYTES, openavbAvtpBytes(pTalkerData->avtpHandle));

	AVB_LOGF_INFO("TX "STREAMID_FORMAT", Totals: calls=%" PRIu64 ", frames=%" PRIu64 ", late=%" PRIu64 ", bytes=%" PRIu64 ", TXOutOfBuffs=%ld",
		STREAMID_ARGS(&pTalkerData->streamID),
		openavbTalkerGetStat(pTLState, TL_STAT_TX_CALLS),
		openavbTalkerGetStat(pTLState, TL_STAT_TX_FRAMES),
		openavbTalkerGetStat(pTLState, TL_STAT_TX_LATE),
		openavbTalkerGetStat(pTLState, TL_STAT_TX_BYTES),
		openavbRawsockGetTXOutOfBuffers(rawsock)
		);

	if (pTLState->bStreaming) {
		openavbAvtpShutdown(pTalkerData->avtpHandle);
		pTLState->bStreaming = FALSE;
	}

	AVB_TRACE_EXIT(AVB_TRACE_TL);
}

static inline bool talkerDoStream(tl_state_t *pTLState)
{
	AVB_TRACE_ENTRY(AVB_TRACE_TL);

	if (!pTLState) {
		AVB_LOG_ERROR("Invalid TLState");
		AVB_TRACE_EXIT(AVB_TRACE_TL);
		return FALSE;
	}

	openavb_tl_cfg_t *pCfg = &pTLState->cfg;
	talker_data_t *pTalkerData = pTLState->pPvtTalkerData;
	bool bRet = FALSE;
	avtp_smoothning_data avtpdata;
	avtpdata.previousAvtpTime = pTalkerData->prevAVTPTime;
	avtpdata.currentAVTPReference = 0;
	avtpdata.intervalNS = pTalkerData->intervalNS;
	avtpdata.wakeFrames = pTalkerData->wakeFrames;
	avtpdata.driftCurve = pTalkerData->driftCurve;

	if (pTLState->bStreaming) {
		U64 nowNS;

		if (!pCfg->tx_blocking_in_intf) {
#ifndef NO_PPS_BASED_WAKEUP 
			if (!pCfg->enable_wakeup_on_pps) {
				// sleep until the next interval
				SLEEP_UNTIL_NSEC(pTalkerData->nextCycleNS);

				//AVB_DBG_INTERVAL(8000, TRUE);

				// send the frames for this interval
				int i;
				for (i = pTalkerData->wakeFrames; i > 0; i--) {
					if (IS_OPENAVB_SUCCESS(openavbAvtpTx(pTalkerData->avtpHandle, i == 1,
					                                     pCfg->tx_blocking_in_intf, i, &avtpdata)))
						pTalkerData->cntFrames++;
					else break;
				}
			}
			else {
				eventConfigData_t *pEventConfigData = (eventConfigData_t *)pTLState->pEventConfigData;
				if (eventWake(pEventConfigData) == true) {
					int i;
					for (i = pTalkerData->wakeFrames; i > 0; i--) {
						if (IS_OPENAVB_SUCCESS(openavbAvtpTx(pTalkerData->avtpHandle, i == 1,
						                                     pCfg->tx_blocking_in_intf, i, &avtpdata)))
							pTalkerData->cntFrames++;
						else break;
					}
				}
			}
#endif
		}
		else {
			// Interface module block option
			if (IS_OPENAVB_SUCCESS(openavbAvtpTx(pTalkerData->avtpHandle, TRUE,
			                                     pCfg->tx_blocking_in_intf, 1, &avtpdata)))
				pTalkerData->cntFrames++;
		}

		pTalkerData->prevAVTPTime = avtpdata.currentAVTPReference;
		pTalkerData->driftCurve = avtpdata.driftCurve;

		if (pTalkerData->cntWakes++ % pTalkerData->wakeRate == 0) {
			// time to service the endpoint IPC
			bRet = TRUE;
		}

		CLOCK_GETTIME64(OPENAVB_TIMER_CLOCK, &nowNS);

		if (pCfg->report_seconds > 0) {
			if (nowNS > pTalkerData->nextReportNS) {
			  
				S32 late = pTalkerData->wakesPerReport - pTalkerData->cntWakes;
				U64 bytes = openavbAvtpBytes(pTalkerData->avtpHandle);
				if (late < 0) late = 0;
				U32 txbuf = openavbAvtpTxBufferLevel(pTalkerData->avtpHandle);
				U32 mqbuf = openavbMediaQCountItems(pTLState->pMediaQ, TRUE);
			
				AVB_LOGRT_INFO(LOG_RT_BEGIN, LOG_RT_ITEM, FALSE, "TX UID:%d, ", LOG_RT_DATATYPE_U16, &pTalkerData->streamID.uniqueID);
				AVB_LOGRT_INFO(FALSE, LOG_RT_ITEM, FALSE, "calls=%ld, ", LOG_RT_DATATYPE_U32, &pTalkerData->cntWakes);
				AVB_LOGRT_INFO(FALSE, LOG_RT_ITEM, FALSE, "frames=%ld, ", LOG_RT_DATATYPE_U32, &pTalkerData->cntFrames);
				AVB_LOGRT_INFO(FALSE, LOG_RT_ITEM, FALSE, "late=%d, ", LOG_RT_DATATYPE_U32, &late);
				AVB_LOGRT_INFO(FALSE, LOG_RT_ITEM, FALSE, "bytes=%lld, ", LOG_RT_DATATYPE_U64, &bytes);
				AVB_LOGRT_INFO(FALSE, LOG_RT_ITEM, FALSE, "txbuf=%d, ", LOG_RT_DATATYPE_U32, &txbuf);
				AVB_LOGRT_INFO(FALSE, LOG_RT_ITEM, LOG_RT_END, "mqbuf=%d, ", LOG_RT_DATATYPE_U32, &mqbuf);

				openavbTalkerAddStat(pTLState, TL_STAT_TX_CALLS, pTalkerData->cntWakes);
				openavbTalkerAddStat(pTLState, TL_STAT_TX_FRAMES, pTalkerData->cntFrames);
				openavbTalkerAddStat(pTLState, TL_STAT_TX_LATE, late);
				openavbTalkerAddStat(pTLState, TL_STAT_TX_BYTES, bytes);

				pTalkerData->cntFrames = 0;
				pTalkerData->cntWakes = 0;
				pTalkerData->nextReportNS = nowNS + (pCfg->report_seconds * NANOSECONDS_PER_SECOND);  
			}
		}

		if (nowNS > pTalkerData->nextSecondNS) {
			pTalkerData->nextSecondNS += NANOSECONDS_PER_SECOND;
			bRet = TRUE;
		}

		if (!pCfg->tx_blocking_in_intf) {
			pTalkerData->nextCycleNS += pTalkerData->intervalNS;

			if ((pTalkerData->nextCycleNS + (pCfg->max_transmit_deficit_usec * 1000)) < nowNS) {
				// Hit max deficit time. Something must be wrong. Reset the cycle timer.	
				// Align clock : allows for some performance gain
				nowNS = ((nowNS + (pTalkerData->intervalNS)) / pTalkerData->intervalNS) * pTalkerData->intervalNS;
				pTalkerData->nextCycleNS = nowNS + pTalkerData->intervalNS;
			}				
		}
	}
	else {
		SLEEP_MSEC(10);
		// time to service the endpoint IPC
		bRet = TRUE;
	}

	AVB_TRACE_EXIT(AVB_TRACE_TL);
	return bRet;
}

#define WAIT_FOR_GPTP_LOOP_SLEEP_US 100

// Called from openavbTLThreadFn() which is started from openavbTLRun() 
void openavbTLRunTalker(tl_state_t *pTLState)
{
	AVB_TRACE_ENTRY(AVB_TRACE_TL);

	if (!pTLState) {
		AVB_LOG_ERROR("Invalid TLState");
		AVB_TRACE_EXIT(AVB_TRACE_TL);
		return;
	}

	// If we need to wait for GPTP to get a time, then keep
	// trying to the the GPTP time until we succeed or until the
	// app needs to close.
	if (pTLState->cfg.wait_for_gptp) {
		U64 gptpTime;
		bool errorPrinted = FALSE;
		while (pTLState->bRunning) {
			gptpTime = 0;
			if (CLOCK_GETTIME64(OPENAVB_CLOCK_WALLTIME,
					    &gptpTime) && gptpTime != 0) {
				break;
			}
			if (!errorPrinted) {
				errorPrinted = TRUE;
				AVB_LOG_WARNING("Waiting for the GPTP time");
			}
			usleep(WAIT_FOR_GPTP_LOOP_SLEEP_US);
		}
		if (!pTLState->bRunning) {
			AVB_LOG_ERROR("Could not acquire the GPTP time");
			return;
		}
	}

	pTLState->pPvtTalkerData = calloc(1, sizeof(talker_data_t));
	if (!pTLState->pPvtTalkerData) {
		AVB_LOG_WARNING("Failed to allocate talker data.");
		return;
	}

	// Create Stats Mutex
	{
		MUTEX_ATTR_HANDLE(mta);
		MUTEX_ATTR_INIT(mta);
		MUTEX_ATTR_SET_TYPE(mta, MUTEX_ATTR_TYPE_DEFAULT);
		MUTEX_ATTR_SET_NAME(mta, "TLStatsMutex");
		MUTEX_CREATE_ERR();
		MUTEX_CREATE(pTLState->statsMutex, mta);
		MUTEX_LOG_ERR("Could not create/initialize 'TLStatsMutex' mutex");
	}

	/* If using endpoint register talker,
	   else register with tpsec */
	pTLState->bConnected = openavbTLRunTalkerInit(pTLState); 

	if (pTLState->bConnected) {
		bool bServiceIPC;
		// Do until we are stopped or loose connection to endpoint
		while (pTLState->bRunning && pTLState->bConnected) {
			// Talk (or just sleep if not streaming.)
			bServiceIPC = talkerDoStream(pTLState);

			// TalkerDoStream() returns TRUE once per second,
			// so that we can service our IPC at that low rate.
			if (bServiceIPC) {
				// Look for messages from endpoint.  Don't block (timeout=0)
				if (!openavbEptClntService(pTLState->endpointHandle, 0)) {
					AVB_LOGF_WARNING("Lost connection to endpoint, will retry "STREAMID_FORMAT, STREAMID_ARGS(&(((talker_data_t *)pTLState->pPvtTalkerData)->streamID)));
					pTLState->bConnected = FALSE;
					pTLState->endpointHandle = 0;
				}
			}
		}

		// Stop streaming
		talkerStopStream(pTLState);

		{
			MUTEX_CREATE_ERR();
			MUTEX_DESTROY(pTLState->statsMutex); // Destroy Stats Mutex
			MUTEX_LOG_ERR("Error destroying mutex");
		}

		// withdraw our talker registration
		if (pTLState->bConnected)
			openavbEptClntStopStream(pTLState->endpointHandle, &(((talker_data_t *)pTLState->pPvtTalkerData)->streamID));

		openavbTLRunTalkerFinish(pTLState);
	}
	else {
		AVB_LOGF_WARNING("Failed to connect to endpoint"STREAMID_FORMAT, STREAMID_ARGS(&(((talker_data_t *)pTLState->pPvtTalkerData)->streamID)));
	}

	if (pTLState->pPvtTalkerData) {
		free(pTLState->pPvtTalkerData);
		pTLState->pPvtTalkerData = NULL;
	}

	AVB_TRACE_EXIT(AVB_TRACE_TL);
}

void openavbTLPauseTalker(tl_state_t *pTLState, bool bPause)
{
	AVB_TRACE_ENTRY(AVB_TRACE_TL);

	if (!pTLState) {
		AVB_LOG_ERROR("Invalid TLState");
		AVB_TRACE_EXIT(AVB_TRACE_TL);
		return;
	}

	talker_data_t *pTalkerData = pTLState->pPvtTalkerData;
	if (!pTalkerData) {
		AVB_LOG_ERROR("Invalid private talker data");
		AVB_TRACE_EXIT(AVB_TRACE_TL);
		return;
	}

	openavbAvtpPause(pTalkerData->avtpHandle, bPause);

	AVB_TRACE_EXIT(AVB_TRACE_TL);
}

void openavbTalkerClearStats(tl_state_t *pTLState)
{
	AVB_TRACE_ENTRY(AVB_TRACE_TL);

	if (!pTLState) {
		AVB_LOG_ERROR("Invalid TLState");
		AVB_TRACE_EXIT(AVB_TRACE_TL);
		return;
	}

	talker_data_t *pTalkerData = pTLState->pPvtTalkerData;
	if (!pTalkerData) {
		AVB_LOG_ERROR("Invalid private talker data");
		AVB_TRACE_EXIT(AVB_TRACE_TL);
		return;
	}

	LOCK_STATS();
	memset(&pTalkerData->stats, 0, sizeof(pTalkerData->stats));
	UNLOCK_STATS();

	AVB_TRACE_EXIT(AVB_TRACE_TL);
}

void openavbTalkerAddStat(tl_state_t *pTLState, tl_stat_t stat, U64 val)
{
	AVB_TRACE_ENTRY(AVB_TRACE_TL);

	if (!pTLState) {
		AVB_LOG_ERROR("Invalid TLState");
		AVB_TRACE_EXIT(AVB_TRACE_TL);
		return;
	}

	talker_data_t *pTalkerData = pTLState->pPvtTalkerData;
	if (!pTalkerData) {
		AVB_LOG_ERROR("Invalid private talker data");
		AVB_TRACE_EXIT(AVB_TRACE_TL);
		return;
	}

	LOCK_STATS();
	switch (stat) {
		case TL_STAT_TX_CALLS:
			pTalkerData->stats.totalCalls += val;
			break;
		case TL_STAT_TX_FRAMES:
			pTalkerData->stats.totalFrames += val;
			break;
		case TL_STAT_TX_LATE:
			pTalkerData->stats.totalLate += val;
			break;
		case TL_STAT_TX_BYTES:
			pTalkerData->stats.totalBytes += val;
			break;
		case TL_STAT_RX_CALLS:
		case TL_STAT_RX_FRAMES:
		case TL_STAT_RX_LOST:
		case TL_STAT_RX_BYTES:
			break;
	}
	UNLOCK_STATS();

	AVB_TRACE_EXIT(AVB_TRACE_TL);
}

U64 openavbTalkerGetStat(tl_state_t *pTLState, tl_stat_t stat)
{
	AVB_TRACE_ENTRY(AVB_TRACE_TL);
	U64 val = 0;

	if (!pTLState) {
		AVB_LOG_ERROR("Invalid TLState");
		AVB_TRACE_EXIT(AVB_TRACE_TL);
		return 0;
	}

	talker_data_t *pTalkerData = pTLState->pPvtTalkerData;
	if (!pTalkerData) {
		AVB_LOG_ERROR("Invalid private talker data");
		AVB_TRACE_EXIT(AVB_TRACE_TL);
		return 0;
	}

	LOCK_STATS();
	switch (stat) {
		case TL_STAT_TX_CALLS:
			val = pTalkerData->stats.totalCalls;
			break;
		case TL_STAT_TX_FRAMES:
			val = pTalkerData->stats.totalFrames;
			break;
		case TL_STAT_TX_LATE:
			val = pTalkerData->stats.totalLate;
			break;
		case TL_STAT_TX_BYTES:
			val = pTalkerData->stats.totalBytes;
			break;
		case TL_STAT_RX_CALLS:
		case TL_STAT_RX_FRAMES:
		case TL_STAT_RX_LOST:
		case TL_STAT_RX_BYTES:
			break;
	}
	UNLOCK_STATS();

	AVB_TRACE_EXIT(AVB_TRACE_TL);
	return val;
}

