 /*
  * Copyright (c) <2013>, Intel Corporation.
  *
  * This program is free software; you can redistribute it and/or modify it
  * under the terms and conditions of the GNU Lesser General Public License,
  * version 2.1, as published by the Free Software Foundation.
  *
  * This program is distributed in the hope it will be useful, but WITHOUT
  * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
  * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
  * more details.
  *
  * You should have received a copy of the GNU Lesser General Public License along with
  * this program; if not, write to the Free Software Foundation, Inc.,
  * 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  *
  */

#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <linux/ptp_clock.h>

#include <arpa/inet.h>

#include <linux/if.h>

#include <netinet/in.h>

#ifdef ANDROID
#include <linux/pci.h>
#else
#include <pci/pci.h>
#endif

#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/stat.h>

#include "avb.h"
#ifdef USE_GLIB
#include <glib.h>
#define strlcpy g_strlcpy
#define strlcat g_strlcat
#endif

#if AVB_FEATURE_GVM_MODE
#define GVM_SHM_NAME "/dev/gptp_shm"
#define GPTP_IPC_GVM_MODE
#define GPTP_GVM_SHM_SIZE 0x1000
#define HYP_HOST_MUTEX_SIZE 8
#endif

int gptpinit(int *shm_fd, char **memory_offset_buffer)
{
#ifdef ANDROID
	*shm_fd = open(SHM_NAME, O_RDWR, 0);
#elif defined(GPTP_IPC_GVM_MODE)
	*shm_fd = open(GVM_SHM_NAME, O_RDWR);
#else
	*shm_fd = shm_open(SHM_NAME, O_RDWR, 0);
#endif
	if (*shm_fd == -1) {
		perror("shm_open()");
		return false;
	}

#ifdef GPTP_IPC_GVM_MODE
	*memory_offset_buffer =
            (char *)mmap(NULL, GPTP_GVM_SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED,
                         *shm_fd, 0);
#else
	*memory_offset_buffer =
	    (char *)mmap(NULL, SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED,
			 *shm_fd, 0);
#endif
	if (*memory_offset_buffer == (char *)-1) {
		perror("mmap()");
		*memory_offset_buffer = NULL;
#ifdef ANDROID
		close(*shm_fd);
#elif defined(GPTP_IPC_GVM_MODE)
		close(*shm_fd);
#else
		shm_unlink(SHM_NAME);
#endif
		return false;
	}
	return true;
}

void gptpdeinit(int shm_fd, char *memory_offset_buffer)
{
	if (memory_offset_buffer != NULL) {
		munmap(memory_offset_buffer, SHM_SIZE);
	}
	if (shm_fd != -1) {
		close(shm_fd);
	}
}

int gptpscaling(gPtpTimeData * td, char *memory_offset_buffer)
{
	if (td == NULL)
		return true;

#ifndef GPTP_IPC_GVM_MODE
	pthread_mutex_lock((pthread_mutex_t *) memory_offset_buffer);
	memcpy(td, memory_offset_buffer + sizeof(pthread_mutex_t), sizeof(*td));
	pthread_mutex_unlock((pthread_mutex_t *) memory_offset_buffer);
#else
	memcpy(td, memory_offset_buffer + HYP_HOST_MUTEX_SIZE, sizeof(*td));
#endif

	return true;
}

bool gptplocaltime(const gPtpTimeData * td, uint64_t* now_local)
{
	struct timespec sys_time;
	uint64_t now_system;
	uint64_t system_time;
	int64_t delta_local;
	int64_t delta_system;

	if (!td || !now_local)
		return false;

	if (clock_gettime(CLOCK_REALTIME, &sys_time) != 0)
		return false;

	now_system = (uint64_t)sys_time.tv_sec * 1000000000ULL + (uint64_t)sys_time.tv_nsec;

	system_time = td->local_time + td->ls_phoffset;
	delta_system = now_system - system_time;
	delta_local = td->ls_freqoffset * delta_system;
	*now_local = td->local_time + delta_local;

	return true;
}

// Use HW
//#define LLONG_MAX ((long long)(~0ULL>>1))
#define MAX_NSEC 1000000000
#define CPTP_DEVICE "/dev/ptp0"
static inline struct ptp_clock_time cpct_diff( struct ptp_clock_time *a, struct ptp_clock_time *b )
{
	struct ptp_clock_time result;
	if( a->nsec >= b->nsec ) {
		result.nsec = a->nsec - b->nsec;
	} else {
		--a->sec;
		result.nsec = (MAX_NSEC - b->nsec) + a->nsec;
	}
	result.sec = a->sec - b->sec;

	return result;
}

static inline int64_t cpctns(struct ptp_clock_time t)
{
	return t.sec * 1000000000LL + t.nsec;
}

bool gptp_hw_curr_time(uint64_t *system_time, uint64_t *device_time)
{
	unsigned int i;
	int fd;
	char *device = CPTP_DEVICE;

	struct ptp_clock_time *pct;
	struct ptp_clock_time *system_time_l = NULL, *device_time_l = NULL;
	int64_t interval = LLONG_MAX;
	struct ptp_sys_offset offset;

	fd = open(device, O_RDWR);
	if (fd < 0) {
		fprintf(stderr, "opening %s: %s\n", device, strerror(errno));
		return false;
	}
	memset( &offset, 0, sizeof(offset));
	offset.n_samples = PTP_MAX_SAMPLES;
	if( ioctl(fd, PTP_SYS_OFFSET, &offset ) == -1 ) {
		close(fd);
		return false;
	}
	pct = &offset.ts[0];
	for( i = 0; i < offset.n_samples; ++i ) {
		int64_t interval_t;
		interval_t = cpctns(cpct_diff( pct+2*i+2, pct+2*i ));
		if( interval_t < interval ) {
			system_time_l = pct+2*i;
			device_time_l = pct+2*i+1;
			interval = interval_t;
		}
	}

	if (device_time_l != NULL && system_time_l != NULL) {
		*device_time = device_time_l->sec * 1000000000LL + device_time_l->nsec;
		*system_time = system_time_l->sec * 1000000000LL + system_time_l->nsec;
		close(fd);
		return true;
	} else {
		close(fd);
		return false;
	}
}

/* setters & getters for seventeen22_header */
void avb_set_1722_cd_indicator(seventeen22_header *h1722, uint64_t cd_indicator)
{
	h1722->cd_indicator = cd_indicator;
}

uint64_t avb_get_1722_cd_indicator(seventeen22_header *h1722)
{
	return h1722->cd_indicator;
}

void avb_set_1722_subtype(seventeen22_header *h1722, uint64_t subtype)
{
	h1722->subtype = subtype;
}

uint64_t avb_get_1722_subtype(seventeen22_header *h1722)
{
	return h1722->subtype;
}

void avb_set_1722_sid_valid(seventeen22_header *h1722, uint64_t sid_valid)
{
	h1722->sid_valid = sid_valid;
}

uint64_t avb_get_1722_sid_valid(seventeen22_header *h1722)
{
	return h1722->sid_valid;
}

void avb_set_1722_version(seventeen22_header *h1722, uint64_t version)
{
	h1722->version = version;
}

uint64_t avb_get_1722_version(seventeen22_header *h1722)
{
	return h1722->version;
}

void avb_set_1722_reset(seventeen22_header *h1722, uint64_t reset)
{
	h1722->reset = reset;
}

uint64_t avb_get_1722_reset(seventeen22_header *h1722)
{
	return h1722->reset;
}

void avb_set_1722_reserved0(seventeen22_header *h1722, uint64_t reserved0)
{
	h1722->reserved0 = reserved0;
}

uint64_t avb_get_1722_reserved0(seventeen22_header *h1722)
{
	return h1722->reserved0;
}

void avb_set_1722_gateway_valid(seventeen22_header *h1722, uint64_t gateway_valid)
{
	h1722->gateway_valid = gateway_valid;
}

uint64_t avb_get_1722_gateway_valid(seventeen22_header *h1722)
{
	return h1722->gateway_valid;
}

void avb_set_1722_timestamp_valid(seventeen22_header *h1722, uint64_t timestamp_valid)
{
	h1722->timestamp_valid = timestamp_valid;
}

uint64_t avb_get_1722_timestamp_valid(seventeen22_header *h1722)
{
	return h1722->timestamp_valid;
}

void avb_set_1722_reserved1(seventeen22_header *h1722, uint64_t reserved1)
{
	h1722->reserved1 = reserved1;
}

uint64_t avb_get_1722_reserved1(seventeen22_header *h1722)
{
	return h1722->reserved1;
}

void avb_set_1722_stream_id(seventeen22_header *h1722, uint64_t stream_id)
{
	h1722->stream_id = stream_id;
}

uint64_t avb_get_1722_stream_id(seventeen22_header *h1722)
{
	return h1722->stream_id;
}

void avb_set_1722_seq_number(seventeen22_header *h1722, uint64_t seq_number)
{
	h1722->seq_number = seq_number;
}

uint64_t avb_get_1722_seq_number(seventeen22_header *h1722)
{
	return h1722->seq_number;
}

void avb_set_1722_timestamp_uncertain(seventeen22_header *h1722, uint64_t timestamp_uncertain)
{
	h1722->timestamp_uncertain = timestamp_uncertain;
}

uint64_t avb_get_1722_timestamp_uncertain(seventeen22_header *h1722)
{
	return h1722->timestamp_uncertain;
}

void avb_set_1722_timestamp(seventeen22_header *h1722, uint64_t timestamp)
{
	h1722->timestamp = timestamp;
}

uint64_t avb_get_1722_timestamp(seventeen22_header *h1722)
{
	return h1722->timestamp;
}

void avb_set_1722_gateway_info(seventeen22_header *h1722, uint64_t gateway_info)
{
	h1722->gateway_info = gateway_info;
}

uint64_t avb_get_1722_gateway_info(seventeen22_header *h1722)
{
	return h1722->gateway_info;
}

void avb_set_1722_length(seventeen22_header *h1722, uint64_t length)
{
	h1722->length = length;
}

uint64_t avb_get_1722_length(seventeen22_header *h1722)
{
	return h1722->length;
}

/* setters & getters for six1883_header */

void avb_set_61883_packet_channel(six1883_header *h61883, uint16_t packet_channel)
{
	h61883->packet_channel = packet_channel;
}

uint16_t avb_get_61883_length(six1883_header *h61883)
{
	return h61883->packet_channel;
}

void avb_set_61883_format_tag(six1883_header *h61883, uint16_t format_tag)
{
	h61883->format_tag = format_tag;
}

uint16_t avb_get_61883_format_tag(six1883_header *h61883)
{
	return h61883->format_tag;
}

void avb_set_61883_app_control(six1883_header *h61883, uint16_t app_control)
{
	h61883->app_control = app_control;
}

uint16_t avb_get_61883_app_control(six1883_header *h61883)
{
	return h61883->app_control;
}

void avb_set_61883_packet_tcode(six1883_header *h61883, uint16_t packet_tcode)
{
	h61883->packet_tcode = packet_tcode;
}

uint16_t avb_get_61883_packet_tcode(six1883_header *h61883)
{
	return h61883->packet_tcode;
}

void avb_set_61883_source_id(six1883_header *h61883, uint16_t source_id)
{
	h61883->source_id = source_id;
}

uint16_t avb_get_61883_source_id(six1883_header *h61883)
{
	return h61883->source_id;
}

void avb_set_61883_reserved0(six1883_header *h61883, uint16_t reserved0)
{
	h61883->reserved0 = reserved0;
}

uint16_t avb_get_61883_reserved0(six1883_header *h61883)
{
	return h61883->reserved0;
}

void avb_set_61883_data_block_size(six1883_header *h61883, uint16_t data_block_size)
{
	h61883->data_block_size = data_block_size;
}

uint16_t avb_get_61883_data_block_size(six1883_header *h61883)
{
	return h61883->data_block_size;
}

void avb_set_61883_reserved1(six1883_header *h61883, uint16_t reserved1)
{
	h61883->reserved1 = reserved1;
}

uint16_t avb_get_61883_reserved1(six1883_header *h61883)
{
	return h61883->reserved1;
}

void avb_set_61883_source_packet_header(six1883_header *h61883, uint16_t source_packet_header)
{
	h61883->source_packet_header = source_packet_header;
}

uint16_t avb_get_61883_source_packet_header(six1883_header *h61883)
{
	return h61883->source_packet_header;
}

void avb_set_61883_quadlet_padding_count(six1883_header *h61883, uint16_t quadlet_padding_count)
{
	h61883->quadlet_padding_count = quadlet_padding_count;
}

uint16_t avb_get_61883_quadlet_padding_count(six1883_header *h61883)
{
	return h61883->quadlet_padding_count;
}

void avb_set_61883_fraction_number(six1883_header *h61883, uint16_t fraction_number)
{
	h61883->fraction_number = fraction_number;
}

uint16_t avb_get_61883_fraction_number(six1883_header *h61883)
{
	return h61883->fraction_number;
}

void avb_set_61883_data_block_continuity(six1883_header *h61883, uint16_t data_block_continuity)
{
	h61883->data_block_continuity = data_block_continuity;
}

uint16_t avb_get_61883_data_block_continuity(six1883_header *h61883)
{
	return h61883->data_block_continuity;
}

void avb_set_61883_format_id(six1883_header *h61883, uint16_t format_id)
{
	h61883->format_id = format_id;
}

uint16_t avb_get_61883_format_id(six1883_header *h61883)
{
	return h61883->format_id;
}

void avb_set_61883_eoh(six1883_header *h61883, uint16_t eoh)
{
	h61883->eoh = eoh;
}

uint16_t avb_get_61883_eoh(six1883_header *h61883)
{
	return h61883->eoh;
}

void avb_set_61883_format_dependent_field(six1883_header *h61883, uint16_t format_dependent_field)
{
	h61883->format_dependent_field = format_dependent_field;
}

uint16_t avb_get_61883_format_dependent_field(six1883_header *h61883)
{
	return h61883->format_dependent_field;
}

void avb_set_61883_syt(six1883_header *h61883, uint16_t syt)
{
	h61883->syt = syt;
}

uint16_t avb_get_61883_syt(six1883_header *h61883)
{
	return h61883->syt;
}

void * avb_create_packet(uint32_t payload_len)
{
	void *avb_packet = NULL;
	uint32_t size;

	size = sizeof(six1883_header);
	size += sizeof(eth_header) + sizeof(seventeen22_header) + payload_len;

	avb_packet = calloc(size, sizeof(uint8_t));
	if (!avb_packet)
		return NULL;

	return avb_packet;
}

void avb_initialize_h1722_to_defaults(seventeen22_header *h1722)
{
	avb_set_1722_subtype(h1722, 0x0);
	avb_set_1722_cd_indicator(h1722, 0x0);
	avb_set_1722_timestamp_valid(h1722, 0x0);
	avb_set_1722_gateway_valid(h1722, 0x0);
	avb_set_1722_reserved0(h1722, 0x0);
	avb_set_1722_sid_valid(h1722, 0x0);
	avb_set_1722_reset(h1722, 0x0);
	avb_set_1722_version(h1722, 0x0);
	avb_set_1722_sid_valid(h1722, 0x0);
	avb_set_1722_timestamp_uncertain(h1722, 0x0);
	avb_set_1722_reserved1(h1722, 0x0);
	avb_set_1722_timestamp(h1722, 0x0);
	avb_set_1722_gateway_info(h1722, 0x0);
	avb_set_1722_length(h1722, 0x0);
}

void avb_initialize_61883_to_defaults(six1883_header *h61883)
{
	avb_set_61883_packet_channel(h61883, 0x0);
	avb_set_61883_format_tag(h61883, 0x0);
	avb_set_61883_app_control(h61883, 0x0);
	avb_set_61883_packet_tcode(h61883, 0x0);
	avb_set_61883_source_id(h61883, 0x0);
	avb_set_61883_reserved0(h61883, 0x0);
	avb_set_61883_data_block_size(h61883, 0x0);
	avb_set_61883_reserved1(h61883, 0x0);
	avb_set_61883_source_packet_header(h61883, 0x0);
	avb_set_61883_quadlet_padding_count(h61883, 0x0);
	avb_set_61883_fraction_number(h61883, 0x0);
	avb_set_61883_data_block_continuity(h61883, 0x0);
	avb_set_61883_format_id(h61883, 0x0);
	avb_set_61883_eoh(h61883, 0x0);
	avb_set_61883_format_dependent_field(h61883, 0x0);
	avb_set_61883_syt(h61883, 0x0);
}

int32_t avb_get_iface_mac_address(int8_t *iface, uint8_t *addr)
{
	struct ifreq ifreq;
	int fd, ret;

	/* Create a socket */
	fd = socket(PF_PACKET, SOCK_RAW, htons(0x800));
	if (fd < 0)
		return -1;

	memset(&ifreq, 0, sizeof(ifreq));

	strlcpy(ifreq.ifr_name, (const char*)iface, sizeof(ifreq.ifr_name));
	ret = ioctl(fd, SIOCGIFHWADDR, &ifreq);
	if (ret < 0) {
		close(fd);
		return -1;
	}

	memcpy(addr, ifreq.ifr_hwaddr.sa_data, ETH_ALEN);
	close(fd);

	return 0;
}

void avb_1722_set_eth_type(eth_header *eth_header) {

	eth_header->h_protocol[0] = 0x22;
	eth_header->h_protocol[1] = 0xf0;

	return;
}

int32_t
avb_eth_header_set_mac(eth_header *ethernet_header, uint8_t *addr, int8_t *iface)
{
	uint8_t source_mac[ETH_ALEN];

	if (!addr || !iface)
		return -EINVAL;

	if (avb_get_iface_mac_address(iface, source_mac))
		return -EINVAL;

	memcpy(ethernet_header->h_dest, addr, ETH_ALEN);
	memcpy(ethernet_header->h_source, source_mac, ETH_ALEN);

	return 0;
}
