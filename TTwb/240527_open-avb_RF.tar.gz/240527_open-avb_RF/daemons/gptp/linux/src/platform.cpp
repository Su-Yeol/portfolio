/******************************************************************************

  Copyright (c) 2012 Intel Corporation 
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions are met:
  
   1. Redistributions of source code must retain the above copyright notice, 
      this list of conditions and the following disclaimer.
  
   2. Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in the 
      documentation and/or other materials provided with the distribution.
  
   3. Neither the name of the Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived from 
      this software without specific prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.

******************************************************************************/

#include <platform.hpp>
#include <arpa/inet.h>
#include <time.h>

#ifdef USE_GLIB
#include <glib.h>

uint32_t PLAT_strlcpy(char *dest, const char *src, uint32_t max) {
       return g_strlcpy(dest, src, max);
}
#endif


uint16_t PLAT_htons( uint16_t s ) {
	return htons( s );
}
uint32_t PLAT_htonl( uint32_t l ) {
	return htonl( l );
}
uint16_t PLAT_ntohs( uint16_t s ) {
	return ntohs( s );
}
uint32_t PLAT_ntohl( uint32_t l ) {
	return ntohl( l );
}
uint64_t PLAT_htonll(uint64_t x)
{
	return ( (htonl(1) == 1) ? x : ((uint64_t)htonl((x) & 0xFFFFFFFF) << 32) | htonl((x) >> 32) );
}
uint64_t PLAT_ntohll(uint64_t x)
{
	return( (ntohl(1) == 1) ? x : ((uint64_t)ntohl((x) & 0xFFFFFFFF) << 32) | ntohl((x) >> 32) );
}
int PLAT_localtime(const time_t * inTime, struct tm * outTm)
{
  if (localtime_r(inTime, outTm)) {
    return 0;
  } else {
    return -1;
  }
}
